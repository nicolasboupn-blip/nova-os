package app.novaos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * The wizard's castle, a pixel-art picture that sits on the home screen next to the clock. At night the windows
 * glow, by day it turns to sunlit stone. The rock under it crumbles into little cubes that drift off, some in the
 * theme colour. The wizard lives inside: tap the castle and he comes out, tap it again and he goes home.
 */
final class CastleView extends View {
    static final int SW = 140;      // sprite size in pixels
    static final int SH = 194;
    private static final int DOOR_X = 56;   // middle of the door, in sprite pixels
    private static final int DOOR_TOP = 108;
    private static final int DOOR_BOTTOM = 117;
    private static final int ROCK_FROM = 124; // rows from here down are the crumbling rock

    private static final class Cube {
        float x, y, vx, vy, size, life, age;
        int color;
    }

    private final NovaActivity host;
    private final Bitmap night;
    private final Bitmap day;
    private final int sc;
    private final Paint p = new Paint();
    private final Rect src = new Rect(0, 0, SW, SH);
    private final Rect dst = new Rect();
    private final Random rnd = new Random();
    private final List<Cube> cubes = new ArrayList<>();
    private final int[] rockX = new int[SW * (SH - ROCK_FROM)];
    private final int[] rockY = new int[SW * (SH - ROCK_FROM)];
    private int rockN;
    private final long born = System.nanoTime();
    private long last = System.nanoTime();
    private float spawnDebt;
    private float dayness;
    private long dayChecked;

    CastleView(NovaActivity host) {
        super(host);
        this.host = host;
        night = load("castle_night");
        day = load("castle_day");
        int w = host.getResources().getDisplayMetrics().widthPixels;
        sc = Math.max(2, Math.round(w * 0.44f / SW));
        p.setFilterBitmap(false);
        p.setAntiAlias(false);
        if (night != null) {
            for (int y = ROCK_FROM; y < SH; y++) {
                for (int x = 0; x < SW; x++) {
                    if (night.getPixel(x, y) >>> 24 > 0) {
                        rockX[rockN] = x;
                        rockY[rockN] = y;
                        rockN++;
                    }
                }
            }
        }
    }

    private Bitmap load(String name) {
        int id = getContext().getResources().getIdentifier(name, "drawable", getContext().getPackageName());
        if (id == 0) {
            return null;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeResource(getContext().getResources(), id, o);
    }

    int spriteW() {
        return SW * sc;
    }

    int spriteH() {
        return SH * sc;
    }

    /** Where it goes in the home screen: top right, level with the clock. */
    FrameLayout.LayoutParams params() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(spriteW(), spriteH(),
                android.view.Gravity.TOP | android.view.Gravity.END);
        lp.topMargin = Theme.dp(host, 52);
        lp.rightMargin = Theme.dp(host, 6);
        return lp;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        host.castle = this;
    }

    @Override
    protected void onDetachedFromWindow() {
        if (host.castle == this) {
            host.castle = null;
        }
        super.onDetachedFromWindow();
    }

    /** 0 at night, 1 in daylight, eased around sunrise and sunset. */
    private float computeDay() {
        Calendar c = Calendar.getInstance();
        float h = c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f;
        return smooth(5.5f, 8f, h) * (1f - smooth(18f, 20.5f, h));
    }

    private static float smooth(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    /** The door, bottom middle, in the coordinates of the given parent. */
    float[] door(View parent) {
        int[] a = new int[2];
        int[] b = new int[2];
        getLocationOnScreen(a);
        parent.getLocationOnScreen(b);
        float sx = getScaleX();
        return new float[] {a[0] - b[0] + DOOR_X * sc * sx, a[1] - b[1] + DOOR_BOTTOM * sc * sx};
    }

    /** True if a screen touch lands on the castle itself (not the empty air around it). */
    boolean hit(float rawX, float rawY) {
        int[] a = new int[2];
        getLocationOnScreen(a);
        int px = (int) ((rawX - a[0]) / sc);
        int py = (int) ((rawY - a[1]) / sc);
        if (night == null) {
            return false;
        }
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int x = px + dx;
                int y = py + dy;
                if (x >= 0 && y >= 0 && x < SW && y < SH && night.getPixel(x, y) >>> 24 > 128) {
                    return true;
                }
            }
        }
        return false;
    }

    /** A little burst of cubes at the door, when the wizard goes in or out. */
    void puff() {
        for (int i = 0; i < 22; i++) {
            Cube c = new Cube();
            c.x = (DOOR_X + rnd.nextFloat() * 4f - 2f) * sc;
            c.y = (DOOR_BOTTOM - rnd.nextFloat() * 6f) * sc;
            c.vx = (rnd.nextFloat() - 0.5f) * 90f * sc / 3f;
            c.vy = -rnd.nextFloat() * 70f * sc / 3f;
            c.size = sc * (1 + rnd.nextInt(2));
            c.life = 0.8f + rnd.nextFloat() * 0.8f;
            c.color = rnd.nextBoolean() ? 0xFFFFD84D : Theme.ACCENT;
            cubes.add(c);
        }
    }

    private void spawnCrumb() {
        if (rockN == 0 || cubes.size() > 70) {
            return;
        }
        int i = rnd.nextInt(rockN);
        Cube c = new Cube();
        c.x = rockX[i] * sc;
        c.y = rockY[i] * sc;
        c.vx = (rnd.nextFloat() - 0.4f) * 14f * sc / 3f;
        c.vy = 8f * sc / 3f + rnd.nextFloat() * 22f * sc / 3f;
        c.size = sc * (rnd.nextInt(5) == 0 ? 2 : 1);
        c.life = 2.2f + rnd.nextFloat() * 2.6f;
        if (rnd.nextInt(100) < 28) {
            c.color = Theme.ACCENT;
        } else {
            Bitmap b = dayness > 0.5f && day != null ? day : night;
            c.color = b.getPixel(rockX[i], rockY[i]) | 0xFF000000;
        }
        cubes.add(c);
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        float t = (now - born) / 1e9f;
        if (night == null) {
            return;
        }
        if (now - dayChecked > 20_000_000_000L || dayChecked == 0) {
            dayness = computeDay();
            dayChecked = now == 0 ? 1 : now;
        }
        dst.set(0, 0, SW * sc, SH * sc);
        p.setAlpha(255);
        c.drawBitmap(night, src, dst, p);
        if (dayness > 0.01f && day != null) {
            p.setAlpha((int) (255 * dayness));
            c.drawBitmap(day, src, dst, p);
            p.setAlpha(255);
        }
        // the wizard's light in the doorway while he is at home
        if (host.wizInside && dayness < 0.9f) {
            float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.6);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (210 * pulse * (1f - dayness)) << 24) | 0xFFC04D);
            c.drawRect((DOOR_X - 2) * sc, (DOOR_TOP + 3) * sc, (DOOR_X + 2) * sc, DOOR_BOTTOM * sc, p);
        }
        // crumbling cubes
        spawnDebt += dt * 11f;
        while (spawnDebt >= 1f) {
            spawnDebt -= 1f;
            spawnCrumb();
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = cubes.size() - 1; i >= 0; i--) {
            Cube q = cubes.get(i);
            q.age += dt;
            if (q.age >= q.life) {
                cubes.remove(i);
                continue;
            }
            q.x += q.vx * dt + (float) Math.sin(t * 2f + i) * 0.15f * sc;
            q.y += q.vy * dt;
            float a = 1f - q.age / q.life;
            p.setColor((q.color & 0x00FFFFFF) | ((int) (230 * a) << 24));
            c.drawRect(q.x, q.y, q.x + q.size, q.y + q.size, p);
        }
        if (isShown()) {
            postInvalidateDelayed(33);
        }
    }
}
