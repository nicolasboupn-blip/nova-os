package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Four real alternative home screens (Settings > UI STYLE > Home screen layout). They are not colour themes: each one
 * arranges NOVA in a different way. BENTO: a board of tiles. ORBIT: apps on turning rings around the clock.
 * FEED: a scrolling feed of cards with search. CONSOLE: big tiles in one row like a game console.
 * The classic home screen stays the default, and every look (Aurora, Terminal, Block, My style) works with all of them.
 */
abstract class AltHome extends FrameLayout {
    static final String K_LAYOUT = "ui_layout";
    static final String[] NAMES = {"Classic", "Bento", "Orbit", "Feed", "Console"};

    final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            tick();
            ui.postDelayed(this, tickMs());
        }
    };

    static AltHome create(NovaActivity host, int layout) {
        switch (layout) {
            case 2:
                return new Orbit(host);
            case 3:
                return new Feed(host);
            case 4:
                return new Console(host);
            default:
                return new Bento(host);
        }
    }

    AltHome(NovaActivity host) {
        super(host);
        this.host = host;
    }

    long tickMs() {
        return 1000;
    }

    void tick() {
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.removeCallbacks(loop);
        ui.post(loop);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacks(loop);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ shared helpers

    int dp(float v) {
        return Theme.dp(host, v);
    }

    TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    List<AppEntry> pinned() {
        host.repo.ensureFresh();
        List<AppEntry> out = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                out.add(e);
            }
        }
        return out;
    }

    /** Pinned apps first, then the rest, up to n. */
    List<AppEntry> appsFor(int n) {
        List<AppEntry> out = pinned();
        for (AppEntry e : host.repo.all) {
            if (out.size() >= n) {
                break;
            }
            if (!out.contains(e)) {
                out.add(e);
            }
        }
        return out.size() > n ? new ArrayList<>(out.subList(0, n)) : out;
    }

    String clock() {
        return new SimpleDateFormat(Prefs.getBool("clock_12h", false) ? "h:mm" : "HH:mm", Locale.getDefault())
                .format(new Date());
    }

    String date() {
        return new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date());
    }

    int battery() {
        try {
            BatteryManager bm = (BatteryManager) host.getSystemService(Context.BATTERY_SERVICE);
            return Math.max(0, Math.min(100, bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g = h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
        String n = Profile.name();
        return g + ", " + n;
    }

    View appTile(final AppEntry e, int iconDp, boolean label) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4), dp(8), dp(4), dp(8));
        ImageView iv = new ImageView(host);
        iv.setImageDrawable(Theme.tint(host, e.icon));
        Upgrades.shapeIcon(iv);
        c.addView(iv, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));
        if (label) {
            TextView t = text(e.label, 10f, Theme.TEXT);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(4);
            c.addView(t, lp);
        }
        c.setClickable(true);
        Theme.ripple(c);
        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.appMenu(e);
            return true;
        });
        return c;
    }

    TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    /** APPS, TERMINAL, SETTINGS along the bottom of every layout. */
    View bar() {
        LinearLayout b = new LinearLayout(host);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(6), dp(12), dp(14));
        String[] names = {"APPS", "PROFILE", "TERMINAL", "SETTINGS"};
        Runnable[] acts = {() -> host.showDrawer(), () -> host.showOverlay(new ProfileScreen(host)),
            () -> host.showTerminal(), () -> host.showSettings()};
        for (int i = 0; i < names.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            b.addView(chip(names[i], acts[i]), lp);
        }
        return b;
    }

    FrameLayout card(String title, View content) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        box.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        if (title != null) {
            TextView t = text(title, 9f, Theme.DIM);
            t.setGravity(Gravity.START);
            t.setLetterSpacing(0.15f);
            box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout f = new FrameLayout(host);
        f.addView(box, new FrameLayout.LayoutParams(-1, -2));
        return f;
    }

    // ================================================================== BENTO

    /** A board of tiles: big clock, small status tiles, widgets, then your apps as square tiles. */
    static final class Bento extends AltHome {
        private final TextView time;
        private final TextView day;
        private final TextView batt;

        Bento(NovaActivity host) {
            super(host);
            LinearLayout page = new LinearLayout(host);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(dp(12), dp(46), dp(12), dp(12));

            LinearLayout r1 = new LinearLayout(host);
            LinearLayout clockTile = tile();
            clockTile.setGravity(Gravity.CENTER_VERTICAL);
            time = text(clock(), 44f, Theme.TEXT);
            time.setGravity(Gravity.START);
            clockTile.addView(time);
            day = text(date(), 12f, Theme.DIM);
            day.setGravity(Gravity.START);
            clockTile.addView(day);
            r1.addView(clockTile, lp(0, dp(150), 3f, 0, 0, 6));

            LinearLayout side = new LinearLayout(host);
            side.setOrientation(LinearLayout.VERTICAL);
            LinearLayout scene = tile();
            scene.setGravity(Gravity.CENTER);
            TextView st = text(Scenes.status().isEmpty() ? "SCENE\ntap" : Scenes.status(), 12f, Theme.ACCENT);
            st.setGravity(Gravity.CENTER);
            scene.addView(st);
            scene.setOnClickListener(v -> host.showOverlay(new ScenesScreen(host)));
            side.addView(scene, lp(-1, 0, 1f, 0, 0, 6));
            LinearLayout bt = tile();
            bt.setGravity(Gravity.CENTER);
            batt = text(battery() + "%", 20f, Theme.TEXT);
            bt.addView(batt);
            bt.addView(text("BATTERY", 8f, Theme.DIM));
            side.addView(bt, lp(-1, 0, 1f, 0, 0, 0));
            r1.addView(side, lp(0, dp(150), 2f, 0, 0, 0));
            page.addView(r1, new LinearLayout.LayoutParams(-1, -2));

            page.addView(card("SONGS", new SongsWidget(host)), top(10));
            page.addView(card(null, new ProfileWidget(host)), top(10));

            List<AppEntry> apps = appsFor(11);
            LinearLayout row = null;
            for (int i = 0; i <= apps.size(); i++) {
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    page.addView(row, top(10));
                }
                View t;
                if (i == apps.size()) {
                    TextView all = text("ALL\nAPPS", 11f, Theme.ACCENT);
                    all.setGravity(Gravity.CENTER);
                    all.setOnClickListener(v -> host.showDrawer());
                    LinearLayout w = tile();
                    w.setGravity(Gravity.CENTER);
                    w.addView(all);
                    w.setOnClickListener(v -> host.showDrawer());
                    t = w;
                } else {
                    LinearLayout w = tile();
                    w.setGravity(Gravity.CENTER);
                    w.setPadding(0, 0, 0, 0);
                    w.addView(appTile(apps.get(i), 40, true));
                    t = w;
                }
                row.addView(t, lp(0, dp(84), 1f, 3, 0, 3));
            }
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(page);
            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
            all.addView(bar());
            addView(all, new FrameLayout.LayoutParams(-1, -1));
        }

        private LinearLayout tile() {
            LinearLayout t = new LinearLayout(host);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setPadding(dp(14), dp(10), dp(14), dp(10));
            t.setBackground(Theme.rounded(Theme.PANEL, 20f, host));
            t.setClickable(true);
            return t;
        }

        private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h == 0 ? 0 : h, weight);
            if (w == -1) {
                p = new LinearLayout.LayoutParams(-1, 0, weight);
            }
            if (h == dp(150)) {
                p = new LinearLayout.LayoutParams(w, h, weight);
            }
            p.setMargins(dp(l), dp(t), dp(r), 0);
            return p;
        }

        private LinearLayout.LayoutParams top(int m) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(m);
            return p;
        }

        @Override
        void tick() {
            time.setText(clock());
            day.setText(date());
            batt.setText(battery() + "%");
        }
    }

    // ================================================================== ORBIT

    /** Apps sit on two rings around the clock. Drag to turn the rings, tap an app to open it, tap the middle for all apps. */
    static final class Orbit extends AltHome {
        private final OrbitView view;

        Orbit(NovaActivity host) {
            super(host);
            view = new OrbitView(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(view, new LinearLayout.LayoutParams(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        long tickMs() {
            return 15000;
        }

        @Override
        void tick() {
            view.invalidate();
        }

        private final class OrbitView extends View {
            private final List<AppEntry> inner = new ArrayList<>();
            private final List<AppEntry> outer = new ArrayList<>();
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float a1;
            private float a2;
            private float lastAngle;
            private float downX;
            private float downY;
            private boolean moved;
            private float vel;
            private long lastT;
            private final float slop = ViewConfiguration.get(host).getScaledTouchSlop();
            private final Runnable longPress = new Runnable() {
                @Override
                public void run() {
                    AppEntry e = hit(downX, downY);
                    if (e != null && !moved) {
                        host.appMenu(e);
                        moved = true;
                    }
                }
            };
            private final Runnable spin = new Runnable() {
                @Override
                public void run() {
                    if (Math.abs(vel) < 0.02f) {
                        return;
                    }
                    a1 += vel;
                    a2 -= vel * 0.7f;
                    vel *= 0.94f;
                    invalidate();
                    postOnAnimation(this);
                }
            };

            OrbitView(Context c) {
                super(c);
                List<AppEntry> apps = appsFor(16);
                for (int i = 0; i < apps.size(); i++) {
                    (i < 6 ? inner : outer).add(apps.get(i));
                }
            }

            private float cx() {
                return getWidth() / 2f;
            }

            private float cy() {
                return getHeight() / 2f;
            }

            private float r1() {
                return Math.min(getWidth(), getHeight()) * 0.27f;
            }

            private float r2() {
                return Math.min(getWidth(), getHeight()) * 0.43f;
            }

            private float[] pos(int ring, int i) {
                List<AppEntry> l = ring == 0 ? inner : outer;
                double a = (ring == 0 ? a1 : a2) + i * 2 * Math.PI / Math.max(1, l.size());
                float r = ring == 0 ? r1() : r2();
                return new float[] {cx() + (float) Math.cos(a) * r, cy() + (float) Math.sin(a) * r};
            }

            private AppEntry hit(float x, float y) {
                for (int ring = 0; ring < 2; ring++) {
                    List<AppEntry> l = ring == 0 ? inner : outer;
                    for (int i = 0; i < l.size(); i++) {
                        float[] q = pos(ring, i);
                        float rad = dp(ring == 0 ? 30 : 24);
                        if ((q[0] - x) * (q[0] - x) + (q[1] - y) * (q[1] - y) < rad * rad) {
                            return l.get(i);
                        }
                    }
                }
                return null;
            }

            @Override
            protected void onDraw(Canvas cv) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                p.setColor(0x22FFFFFF);
                cv.drawCircle(cx(), cy(), r1(), p);
                cv.drawCircle(cx(), cy(), r2(), p);
                p.setStyle(Paint.Style.FILL);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x22000000);
                cv.drawCircle(cx(), cy(), r1() * 0.72f, p);
                p.setTypeface(Theme.MONO);
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(34));
                cv.drawText(clock(), cx(), cy() + dp(4), p);
                p.setColor(Theme.DIM);
                p.setTextSize(dp(11));
                cv.drawText(date(), cx(), cy() + dp(24), p);
                String st = Scenes.status();
                if (!st.isEmpty()) {
                    p.setColor(Theme.ACCENT);
                    cv.drawText(st, cx(), cy() + dp(42), p);
                }
                for (int ring = 0; ring < 2; ring++) {
                    List<AppEntry> l = ring == 0 ? inner : outer;
                    int size = dp(ring == 0 ? 52 : 42);
                    for (int i = 0; i < l.size(); i++) {
                        float[] q = pos(ring, i);
                        Drawable d = Theme.tint(host, l.get(i).icon);
                        d.setBounds((int) q[0] - size / 2, (int) q[1] - size / 2, (int) q[0] + size / 2,
                                (int) q[1] + size / 2);
                        d.draw(cv);
                    }
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float x = e.getX();
                float y = e.getY();
                float ang = (float) Math.atan2(y - cy(), x - cx());
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        removeCallbacks(spin);
                        vel = 0;
                        downX = x;
                        downY = y;
                        moved = false;
                        lastAngle = ang;
                        lastT = e.getEventTime();
                        postDelayed(longPress, 500);
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        if (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop) {
                            moved = true;
                            removeCallbacks(longPress);
                        }
                        float d = ang - lastAngle;
                        if (d > Math.PI) {
                            d -= 2 * Math.PI;
                        } else if (d < -Math.PI) {
                            d += 2 * Math.PI;
                        }
                        a1 += d;
                        a2 -= d * 0.7f;
                        long dt = Math.max(1, e.getEventTime() - lastT);
                        vel = d * 16f / dt;
                        lastAngle = ang;
                        lastT = e.getEventTime();
                        invalidate();
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        removeCallbacks(longPress);
                        if (!moved) {
                            AppEntry a = hit(x, y);
                            if (a != null) {
                                host.launch(a);
                            } else if ((x - cx()) * (x - cx()) + (y - cy()) * (y - cy()) < r1() * r1() * 0.6f) {
                                host.showDrawer();
                            }
                        } else {
                            vel = Math.max(-0.25f, Math.min(0.25f, vel));
                            postOnAnimation(spin);
                        }
                        return true;
                    default:
                        removeCallbacks(longPress);
                        return true;
                }
            }
        }
    }

    // ================================================================== FEED

    /** A scrolling feed of cards, with a search box. Typing shows matching apps instead of the feed. */
    static final class Feed extends AltHome {
        private final TextView time;
        private final LinearLayout feed;
        private final LinearLayout results;

        Feed(NovaActivity host) {
            super(host);
            LinearLayout page = new LinearLayout(host);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(dp(14), dp(46), dp(14), dp(12));

            TextView hi = text(greeting(), 12f, Theme.ACCENT);
            hi.setGravity(Gravity.START);
            page.addView(hi);
            time = text(clock() + "   " + date(), 20f, Theme.TEXT);
            time.setGravity(Gravity.START);
            page.addView(time);

            EditText search = new EditText(host);
            search.setHint("search apps");
            search.setHintTextColor(Theme.DIM);
            search.setTextColor(Theme.TEXT);
            search.setTextSize(14f);
            search.setSingleLine(true);
            search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            search.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
            search.setPadding(dp(16), dp(11), dp(16), dp(11));
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
            slp.topMargin = dp(12);
            page.addView(search, slp);

            results = new LinearLayout(host);
            results.setOrientation(LinearLayout.VERTICAL);
            results.setVisibility(GONE);
            page.addView(results, new LinearLayout.LayoutParams(-1, -2));

            feed = new LinearLayout(host);
            feed.setOrientation(LinearLayout.VERTICAL);
            page.addView(feed, new LinearLayout.LayoutParams(-1, -2));
            addCard("SCENES", new ScenesWidget(host));
            addCard("SONGS", new SongsWidget(host));
            addCard(null, new ProfileWidget(host));
            LinearLayout recent = new LinearLayout(host);
            for (AppEntry a : appsFor(5)) {
                recent.addView(appTile(a, 38, false), new LinearLayout.LayoutParams(0, -2, 1f));
            }
            addCard("YOUR APPS", recent);
            addCard("THIS PHONE", Widgets.create(host, "device"));

            search.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                    String q = s.toString().trim();
                    results.removeAllViews();
                    feed.setVisibility(q.isEmpty() ? VISIBLE : GONE);
                    results.setVisibility(q.isEmpty() ? GONE : VISIBLE);
                    if (q.isEmpty()) {
                        return;
                    }
                    List<AppEntry> found = host.repo.search(q);
                    for (int i = 0; i < found.size() && i < 12; i++) {
                        final AppEntry e = found.get(i);
                        LinearLayout r = new LinearLayout(host);
                        r.setGravity(Gravity.CENTER_VERTICAL);
                        r.setPadding(dp(6), dp(8), dp(6), dp(8));
                        ImageView iv = new ImageView(host);
                        iv.setImageDrawable(Theme.tint(host, e.icon));
                        r.addView(iv, new LinearLayout.LayoutParams(dp(36), dp(36)));
                        TextView t = text(e.label, 14f, Theme.TEXT);
                        t.setPadding(dp(12), 0, 0, 0);
                        r.addView(t);
                        r.setClickable(true);
                        Theme.ripple(r);
                        r.setOnClickListener(v -> host.launch(e));
                        results.addView(r);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(page);
            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
            all.addView(bar());
            addView(all, new FrameLayout.LayoutParams(-1, -1));
        }

        private void addCard(String title, View content) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(12);
            feed.addView(card(title, content), p);
        }

        @Override
        void tick() {
            time.setText(clock() + "   " + date());
        }
    }

    // ================================================================== CONSOLE

    /** Big tiles in one row, like a game console. The tile in the middle grows; the name shows underneath. */
    static final class Console extends AltHome {
        private final HorizontalScrollView hs;
        private final LinearLayout row;
        private final TextView name;
        private final TextView time;
        private final TextView info;
        private final List<View> tiles = new ArrayList<>();
        private final List<String> names = new ArrayList<>();

        Console(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(0, dp(46), 0, 0);

            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(20), 0, dp(20), 0);
            time = text(clock(), 22f, Theme.TEXT);
            top.addView(time, new LinearLayout.LayoutParams(0, -2, 1f));
            info = text(battery() + "%", 12f, Theme.DIM);
            top.addView(info);
            col.addView(top, new LinearLayout.LayoutParams(-1, -2));

            hs = new HorizontalScrollView(host) {
                @Override
                protected void onScrollChanged(int l, int t, int ol, int ot) {
                    super.onScrollChanged(l, t, ol, ot);
                    fit();
                }

                @Override
                public boolean onTouchEvent(MotionEvent ev) {
                    boolean r = super.onTouchEvent(ev);
                    if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                        postDelayed(Console.this::snap, 160);
                    }
                    return r;
                }
            };
            hs.setHorizontalScrollBarEnabled(false);
            hs.setClipChildren(false);
            hs.setClipToPadding(false);
            row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setClipChildren(false);
            hs.addView(row);
            col.addView(hs, new LinearLayout.LayoutParams(-1, 0, 1f));

            name = text("", 18f, Theme.TEXT);
            name.setGravity(Gravity.CENTER);
            name.setPadding(0, 0, 0, dp(10));
            col.addView(name, new LinearLayout.LayoutParams(-1, -2));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));

            for (AppEntry a : appsFor(7)) {
                add(a.label, appTile(a, 64, false), 150, null);
            }
            add("SONGS", new SongsWidget(host), 280, null);
            add("PROFILE", new ProfileWidget(host), 280, null);
            add("SCENES", new ScenesWidget(host), 280, null);
            add("ALL APPS", big("▦"), 150, () -> host.showDrawer());
            add("SETTINGS", big("⚙"), 150, () -> host.showSettings());
            post(this::snap);
        }

        private View big(String s) {
            TextView t = text(s, 44f, Theme.ACCENT);
            t.setGravity(Gravity.CENTER);
            return t;
        }

        private void add(String label, View content, int widthDp, Runnable open) {
            FrameLayout tile = new FrameLayout(host);
            tile.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
            tile.setPadding(dp(8), dp(8), dp(8), dp(8));
            tile.addView(content, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            if (open != null) {
                tile.setClickable(true);
                tile.setOnClickListener(v -> open.run());
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(widthDp > 200 ? 300 : 220));
            lp.setMargins(dp(8), 0, dp(8), 0);
            row.addView(tile, lp);
            tiles.add(tile);
            names.add(label);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            int pad = Math.max(0, w / 2 - dp(75));
            row.setPadding(pad, 0, pad, 0);
            fit();
        }

        private int centered() {
            float mid = hs.getScrollX() + hs.getWidth() / 2f;
            int best = 0;
            float bd = Float.MAX_VALUE;
            for (int i = 0; i < tiles.size(); i++) {
                View t = tiles.get(i);
                float d = Math.abs(t.getLeft() + t.getWidth() / 2f - mid);
                if (d < bd) {
                    bd = d;
                    best = i;
                }
            }
            return best;
        }

        private void fit() {
            if (tiles.isEmpty()) {
                return;
            }
            float mid = hs.getScrollX() + hs.getWidth() / 2f;
            for (View t : tiles) {
                float d = Math.abs(t.getLeft() + t.getWidth() / 2f - mid) / Math.max(1f, hs.getWidth() / 2f);
                float s = Math.max(0.78f, 1.08f - d * 0.35f);
                t.setScaleX(s);
                t.setScaleY(s);
                t.setAlpha(Math.max(0.45f, 1f - d * 0.5f));
            }
            int c = centered();
            if (c >= 0 && c < names.size()) {
                name.setText(names.get(c));
            }
        }

        private void snap() {
            if (tiles.isEmpty()) {
                return;
            }
            View t = tiles.get(centered());
            hs.smoothScrollTo(t.getLeft() + t.getWidth() / 2 - hs.getWidth() / 2, 0);
        }

        @Override
        void tick() {
            time.setText(clock());
            info.setText((Scenes.status().isEmpty() ? "" : Scenes.status() + "   ") + battery() + "%");
        }
    }
}
