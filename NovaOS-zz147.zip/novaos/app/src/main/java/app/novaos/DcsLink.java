package app.novaos;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Live DCS data for DCS COCKPIT. The PC script NovaExport.lua broadcasts the aircraft state 20 times a second and the
 * objects around it twice a second over Wi-Fi (UDP 41900). SIM mode makes up a whole flight instead (take-off, a
 * fight, a carrier approach) so every page and button can be tried without DCS.
 */
final class DcsLink {
    static final int PORT = 41900;

    /** Everything about your own aircraft. Distances in metres, speeds in m/s, angles in degrees. */
    static final class State {
        String name = "";
        float ias;
        float tas;
        float mach;
        float alt;
        float agl;
        float vs;
        float aoa;
        float g = 1;
        float hdg;
        float pitch;
        float bank;
        float fuel;
        float fuelExt;
        float rpmL;
        float rpmR;
        float gear;
        float flaps;
        float brake;
        float hook;
        float canopy;
        float wheel;
        int chaff = -1;
        int flare = -1;
        int shells = -1;
        int weapons = -1;
        int coal;
        double x;
        double y;
        double z;
        float lockDist = -1;
        float lockClose;
        String lockName = "";
        float lockAlt = -1;
    }

    /** Something around you: cat 1 air, 2 ground, 3 ship. hdg in degrees. */
    static final class Obj {
        String id;
        int cat;
        int coal;
        double x;
        double z;
        float alt;
        float hdg;
        String name;
    }

    static volatile State st = new State();
    static volatile List<Obj> objs = new ArrayList<>();
    static volatile long lastAt;
    static volatile long objAt;
    static volatile boolean sim;
    static volatile float maxG = 1;
    static volatile float throttle;
    private static final CopyOnWriteArrayList<Runnable> LISTENERS = new CopyOnWriteArrayList<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static int users;
    private static Thread rx;
    private static volatile boolean running;
    private static DatagramSocket socket;
    private static WifiManager.MulticastLock lock;
    private static boolean posted;

    private DcsLink() {
    }

    static boolean live() {
        return sim || SystemClock.elapsedRealtime() - lastAt < 2500;
    }

    static boolean objectsLive() {
        return sim || SystemClock.elapsedRealtime() - objAt < 4000;
    }

    static void listen(Runnable r) {
        LISTENERS.addIfAbsent(r);
    }

    static void unlisten(Runnable r) {
        LISTENERS.remove(r);
    }

    private static void changed() {
        if (posted) {
            return;
        }
        posted = true;
        MAIN.post(() -> {
            posted = false;
            for (Runnable r : LISTENERS) {
                r.run();
            }
        });
    }

    /** Starts listening for the PC (called when a DCS COCKPIT page is on screen). */
    static synchronized void start(Context c) {
        users++;
        if (running) {
            return;
        }
        running = true;
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("nova-dcs");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (RuntimeException ignored) {
            // broadcasts may still arrive
        }
        rx = new Thread(DcsLink::receive, "nova-dcs");
        rx.start();
    }

    static synchronized void stop() {
        users = Math.max(0, users - 1);
        if (users > 0) {
            return;
        }
        running = false;
        DatagramSocket s = socket;
        if (s != null) {
            s.close();
        }
        try {
            if (lock != null) {
                lock.release();
            }
        } catch (RuntimeException ignored) {
            // gone
        }
    }

    private static void receive() {
        byte[] buf = new byte[65507];
        while (running) {
            try {
                DatagramSocket s = new DatagramSocket(null);
                s.setReuseAddress(true);
                s.setBroadcast(true);
                s.bind(new InetSocketAddress(PORT));
                s.setSoTimeout(1000);
                socket = s;
                while (running) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        s.receive(p);
                    } catch (java.net.SocketTimeoutException t) {
                        continue;
                    }
                    if (sim) {
                        continue;
                    }
                    lastPc = p.getAddress();
                    parse(new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
                }
                s.close();
            } catch (Exception e) {
                if (running) {
                    SystemClock.sleep(1500);
                }
            }
        }
    }

    private static float f(String[] a, int i, float def) {
        if (i >= a.length || a[i].isEmpty()) {
            return def;
        }
        try {
            return Float.parseFloat(a[i]);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static void parse(String msg) {
        String[] a = msg.split(";", -1);
        if (a.length == 0) {
            return;
        }
        if (a[0].equals("N1") && a.length >= 35) {
            State s = new State();
            s.name = a[1];
            s.ias = f(a, 2, 0);
            s.tas = f(a, 3, 0);
            s.mach = f(a, 4, 0);
            s.alt = f(a, 5, 0);
            s.agl = f(a, 6, 0);
            s.vs = f(a, 7, 0);
            s.aoa = f(a, 8, 0);
            s.g = f(a, 9, 1);
            s.hdg = (float) Math.toDegrees(f(a, 10, 0));
            s.pitch = (float) Math.toDegrees(f(a, 11, 0));
            s.bank = (float) Math.toDegrees(f(a, 12, 0));
            s.fuel = f(a, 13, 0);
            s.fuelExt = f(a, 14, 0);
            s.rpmL = f(a, 15, 0);
            s.rpmR = f(a, 16, 0);
            s.gear = f(a, 17, 0);
            s.flaps = f(a, 18, 0);
            s.brake = f(a, 19, 0);
            s.hook = f(a, 20, 0);
            s.canopy = f(a, 21, 0);
            s.wheel = f(a, 22, 0);
            s.chaff = (int) f(a, 23, -1);
            s.flare = (int) f(a, 24, -1);
            s.shells = (int) f(a, 25, -1);
            s.x = f(a, 26, 0);
            s.y = f(a, 27, 0);
            s.z = f(a, 28, 0);
            s.lockDist = f(a, 29, -1);
            s.lockClose = f(a, 30, 0);
            s.lockName = a[31];
            s.lockAlt = f(a, 32, -1);
            s.weapons = (int) f(a, 33, -1);
            s.coal = (int) f(a, 34, 0);
            st = s;
            maxG = s.agl < 5 && s.ias < 20 ? 1 : Math.max(maxG, s.g);
            track(s);
            lastAt = SystemClock.elapsedRealtime();
            changed();
        } else if (a[0].equals("N2")) {
            List<Obj> out = new ArrayList<>();
            for (int i = 1; i < a.length; i++) {
                String[] o = a[i].split(",", -1);
                if (o.length < 8) {
                    continue;
                }
                Obj b = new Obj();
                b.id = o[0];
                b.cat = (int) f(o, 1, 0);
                b.coal = (int) f(o, 2, 0);
                b.x = f(o, 3, 0);
                b.z = f(o, 4, 0);
                b.alt = f(o, 5, 0);
                b.hdg = (float) Math.toDegrees(f(o, 6, 0));
                b.name = o[7];
                out.add(b);
            }
            objs = out;
            objAt = SystemClock.elapsedRealtime();
            changed();
        }
    }

    // ================================================================== carriers

    static boolean isCarrier(Obj o) {
        if (o.cat != 3 || o.name == null) {
            return false;
        }
        String n = o.name.toUpperCase(Locale.ROOT);
        return n.contains("CVN") || n.contains("STENNIS") || n.contains("KUZNE") || n.contains("CV_1143")
                || n.contains("FORRESTAL") || n.contains("LHA") || n.contains("TARAWA") || n.contains("VINSON");
    }

    /**
     * Where you are compared to the landing area of the nearest carrier: {distance along the approach (m, positive =
     * behind the deck), lineup offset (m, + = right of the centreline), height above the deck (m), glide slope error
     * (degrees, + = high), lineup error (degrees, + = right), carrier index in objs}. Null when there is no carrier.
     */
    static double[] approach(State s, List<Obj> list) {
        Obj best = null;
        double bd = Double.MAX_VALUE;
        for (Obj o : list) {
            if (isCarrier(o)) {
                double d = Math.hypot(o.x - s.x, o.z - s.z);
                if (d < bd) {
                    bd = d;
                    best = o;
                }
            }
        }
        if (best == null || bd > 25000) {
            return null;
        }
        // the landing area: about 70 m behind the middle of the ship, the angled deck points 9 degrees to the left
        double h = Math.toRadians(best.hdg);
        double tdx = best.x - Math.cos(h) * 70;
        double tdz = best.z - Math.sin(h) * 70;
        double deck = h - Math.toRadians(9);
        double ux = Math.cos(deck);
        double uz = Math.sin(deck);
        double dx = s.x - tdx;
        double dz = s.z - tdz;
        double along = -(dx * ux + dz * uz);
        // right of the landing direction is (-uz, ux) turned: for north = x, east = z, right of heading is +90 degrees
        double rx = Math.cos(deck + Math.PI / 2);
        double rz = Math.sin(deck + Math.PI / 2);
        double lateral = dx * rx + dz * rz;
        double height = s.alt - 19;
        double gs = along > 1 ? Math.toDegrees(Math.atan2(height, along)) - 3.5 : 0;
        double lu = along > 1 ? Math.toDegrees(Math.atan2(lateral, along)) : 0;
        return new double[] {along, lateral, height, gs, lu, list.indexOf(best)};
    }

    // ================================================================== autopilot, track, grades, log

    /** 0 off, 1 heading hold, 2 fly to a point on the map. */
    static volatile int apMode;
    static volatile float apHdg;
    static volatile float apAlt = 1500;
    static volatile boolean apAltOn = true;
    static volatile double apTx;
    static volatile double apTz;
    static volatile java.net.InetAddress lastPc;
    private static Thread apThread;
    private static int apOffSends;

    /** Heading the autopilot wants now (fly-to turns into a bearing). */
    static float apTarget() {
        if (apMode == 2) {
            State s = st;
            return (float) ((Math.toDegrees(Math.atan2(apTz - s.z, apTx - s.x)) + 360) % 360);
        }
        return apHdg;
    }

    static double apDistance() {
        State s = st;
        return Math.hypot(apTx - s.x, apTz - s.z);
    }

    static void setAp(int mode) {
        apMode = mode;
        if (mode == 0) {
            apOffSends = 5;
        }
        if (apThread == null) {
            apThread = new Thread(DcsLink::apLoop, "nova-dcs-ap");
            apThread.setDaemon(true);
            apThread.start();
        }
    }

    /** Sends the autopilot wish to the PC script 5 times a second (it lets go when the phone goes quiet). */
    private static void apLoop() {
        DatagramSocket out = null;
        while (true) {
            try {
                if (out == null) {
                    out = new DatagramSocket();
                }
                java.net.InetAddress pc = lastPc;
                if (!sim && pc != null && (apMode > 0 || apOffSends > 0)) {
                    if (apMode == 2 && apDistance() < 1500) {
                        // arrived: keep the heading you have now
                        apHdg = apTarget();
                        apMode = 1;
                    }
                    String m = apMode > 0 ? String.format(Locale.ROOT, "AP;1;%.1f;%.0f;%d", apTarget(), apAlt, apAltOn ? 1 : 0)
                            : "AP;0;0;0;0";
                    if (apMode == 0) {
                        apOffSends--;
                    }
                    byte[] b = m.getBytes(StandardCharsets.UTF_8);
                    out.send(new DatagramPacket(b, b.length, pc, PORT + 1));
                } else if (sim && apMode == 2 && apDistance() < 1500) {
                    apHdg = apTarget();
                    apMode = 1;
                }
            } catch (Exception e) {
                out = null;
            }
            SystemClock.sleep(200);
        }
    }

    /** The same autopilot for FREE SIM: {roll stick, pitch stick}. */
    private static double[] apFree() {
        double e = apTarget() - ((fhdg % 360 + 360) % 360);
        while (e > 180) {
            e -= 360;
        }
        while (e < -180) {
            e += 360;
        }
        double bankT = Math.max(-30, Math.min(30, e * 1.5));
        double roll = Math.max(-1, Math.min(1, (bankT - fbank) * 0.05));
        double pitchCmd = 0;
        if (apAltOn) {
            double vsT = Math.max(-15, Math.min(15, (apAlt - falt) * 0.08));
            double pitchT = Math.toDegrees(Math.asin(Math.max(-0.3, Math.min(0.3, vsT / Math.max(60, fv)))))
                    + (1 / Math.max(0.5, Math.cos(Math.toRadians(fbank))) - 1) * 4;
            pitchCmd = Math.max(-1, Math.min(1, (pitchT - fpitch) * 0.12));
        } else {
            pitchCmd = stickY;
        }
        return new double[] {roll, pitchCmd};
    }

    /** Where you flew (every second, last 15 minutes) and where you started. */
    static final List<double[]> TRAIL = new CopyOnWriteArrayList<>();
    static volatile double homeX = Double.NaN;
    static volatile double homeZ;
    private static long trailAt;
    private static boolean airborne;
    private static long airAt;
    private static float lastIas;
    private static long fastAt;
    private static double gsSum;
    private static double luSum;
    private static double gsMax;
    private static double luMax;
    private static int samples;
    static volatile long timeOver7;
    private static long lastTrack;

    private static void track(State s) {
        long now = SystemClock.elapsedRealtime();
        if (Double.isNaN(homeX)) {
            homeX = s.x;
            homeZ = s.z;
        }
        if (now - trailAt > 1000) {
            trailAt = now;
            TRAIL.add(new double[] {s.x, s.z});
            while (TRAIL.size() > 900) {
                TRAIL.remove(0);
            }
        }
        if (lastTrack > 0 && s.g > 7) {
            timeOver7 += now - lastTrack;
        }
        lastTrack = now;
        // flight log: take-off and landing
        if (!airborne && s.agl > 30 && s.ias > 50) {
            airborne = true;
            airAt = now;
            log("Take-off");
        } else if (airborne && s.agl < 3 && s.ias < 25) {
            airborne = false;
            log("Landed after " + Math.max(1, (now - airAt) / 60000) + " min");
        }
        // carrier approach: collect the glide slope and lineup in the last 3/4 mile for the grade
        double[] ap = approach(s, objs);
        if (ap != null && ap[0] > 30 && ap[0] < 1400 && s.gear > 0.5f) {
            gsSum += ap[3];
            luSum += ap[4];
            gsMax = Math.max(gsMax, Math.abs(ap[3]));
            luMax = Math.max(luMax, Math.abs(ap[4]));
            samples++;
        }
        // a trap in DCS: on the deck and stopped quickly
        if (s.ias > 50) {
            fastAt = now;
        }
        if (simMode != 2 && ap != null && ap[0] > -250 && ap[0] < 40 && s.alt < 30 && s.ias < 20 && lastIas >= 20
                && now - fastAt < 5000 && samples > 0) {
            grade(0);
        }
        lastIas = s.ias;
    }

    /** Grades the pass like an LSO. wire 1-4, 0 = unknown wire, -1 bolter, -2 crash. */
    static void grade(int wire) {
        String g;
        String cmt = "";
        double gs = samples > 0 ? gsSum / samples : 0;
        double lu = samples > 0 ? luSum / samples : 0;
        if (gs > 0.3) {
            cmt += "HIGH ";
        } else if (gs < -0.3) {
            cmt += "LOW ";
        }
        if (lu > 0.6) {
            cmt += "DRIFT RIGHT ";
        } else if (lu < -0.6) {
            cmt += "DRIFT LEFT ";
        }
        if (wire == -2) {
            g = "C";
            cmt += "CRASH";
        } else if (wire == -1) {
            g = "B";
            cmt += "BOLTER";
        } else if (gsMax < 0.45 && luMax < 0.8 && (wire == 3 || wire == 0)) {
            g = "_OK_";
        } else if (gsMax < 0.8 && luMax < 1.5 && wire != 1) {
            g = "OK";
        } else if (gsMax < 1.2 && luMax < 2.5) {
            g = "(OK)";
        } else {
            g = "—";
        }
        String line = new java.text.SimpleDateFormat("dd.MM HH:mm", Locale.ROOT).format(new java.util.Date()) + "|" + g + "|"
                + (wire > 0 ? wire + " wire" : wire == 0 ? "trap" : "") + "|" + cmt.trim() + "|" + (simMode == 2 ? "SIM" : "DCS");
        String old = Prefs.getString("dcs_greenie", "");
        Prefs.putString("dcs_greenie", line + "\n" + old);
        log("Carrier: " + g + " " + (wire > 0 ? wire + " wire " : "") + cmt.trim());
        gsSum = luSum = gsMax = luMax = 0;
        samples = 0;
    }

    static void log(String what) {
        if (simMode == 1) {
            return;
        }
        String line = new java.text.SimpleDateFormat("dd.MM HH:mm", Locale.ROOT).format(new java.util.Date()) + "|"
                + (st.name.isEmpty() ? "?" : st.name) + "|" + what + (sim ? " (SIM)" : "");
        String old = Prefs.getString("dcs_log", "");
        if (old.length() > 20000) {
            old = old.substring(0, 20000);
        }
        Prefs.putString("dcs_log", line + "\n" + old);
    }

    // ================================================================== SIM mode

    private static long simStart;
    private static final float[] TARGET = new float[5];
    private static final long[] TOUCHED = new long[5];
    private static final Runnable SIM_TICK = new Runnable() {
        @Override
        public void run() {
            if (!sim) {
                return;
            }
            if (simMode == 2) {
                freeStep();
            } else {
                simStep();
            }
            MAIN.postDelayed(this, 50);
        }
    };

    /** 0 off, 1 AUTO (watch a made-up flight), 2 FREE (you fly it). */
    static volatile int simMode;
    /** The stick in FREE mode, -1..1: x = roll right, y = pull (nose up). */
    static volatile float stickX;
    static volatile float stickY;
    /** Last thing that happened in FREE mode ("TRAP! 3 wire", "BOLTER"...) and when. */
    static volatile String event = "";
    static volatile long eventAt;

    static void setSim(int mode) {
        simMode = mode;
        if (mode == 2) {
            resetFree();
        }
        setSim(mode > 0);
    }

    static void setSim(boolean on) {
        sim = on;
        if (!on) {
            simMode = 0;
        }
        if (on) {
            simStart = SystemClock.elapsedRealtime();
            st = new State();
            maxG = 1;
            MAIN.removeCallbacks(SIM_TICK);
            MAIN.post(SIM_TICK);
        } else {
            st = new State();
            objs = new ArrayList<>();
            lastAt = 0;
            objAt = 0;
            changed();
        }
    }

    /** A button pressed in SIM: 0 gear, 1 flaps, 2 airbrake, 3 hook, 4 canopy. value -1 = toggle. */
    static void simPress(int part, float value) {
        State s = st;
        float now = new float[] {s.gear, s.flaps, s.brake, s.hook, s.canopy}[part];
        TARGET[part] = value >= 0 ? value : (now > 0.5f ? 0 : 1);
        TOUCHED[part] = SystemClock.elapsedRealtime();
    }

    // ------------------------------------------------------------------ FREE: you fly it

    private static double fx;
    private static double fz;
    private static double falt;
    private static double fhdg;
    private static double fpitch;
    private static double fbank;
    private static double fv;
    private static double ftime;
    private static double ffuel;
    private static int fphase;
    private static long fphaseAt;
    private static final float[] FPART = new float[5];

    /** Starts 4 nm behind the carrier, on the approach line at 1500 ft and 250 kt, gear and hook up. */
    static void resetFree() {
        ftime = 0;
        double deck = Math.toRadians(-9);
        double along = 7400;
        fx = -70 - Math.cos(deck) * along;
        fz = -Math.sin(deck) * along;
        falt = 460;
        fhdg = -9;
        fpitch = 0;
        fbank = 0;
        fv = 128;
        ffuel = 4500;
        fphase = 0;
        for (int i = 0; i < 5; i++) {
            FPART[i] = 0;
            TARGET[i] = 0;
            TOUCHED[i] = SystemClock.elapsedRealtime();
        }
        throttle = 0.55f;
        maxG = 1;
        event = "";
    }

    private static void fevent(String e) {
        event = e;
        eventAt = SystemClock.elapsedRealtime();
    }

    private static void freeStep() {
        double dt = 0.05;
        long now = SystemClock.elapsedRealtime();
        ftime += dt;
        // parts move toward what you pressed
        float[] rate = {0.017f, 0.025f, 0.08f, 0.06f, 0.015f};
        for (int i = 0; i < 5; i++) {
            FPART[i] = toward(FPART[i], TARGET[i], rate[i]);
        }
        float gear = FPART[0];
        float flaps = FPART[1];
        float brake = FPART[2];
        float hook = FPART[3];
        // the carrier sails north at 15 m/s; the landing area is 70 m behind its middle, the deck 9 degrees left
        double cx = ftime * 15;
        double tdx = cx - 70;
        double deck = Math.toRadians(-9);
        double ux = Math.cos(deck);
        double uz = Math.sin(deck);
        double rx = Math.cos(deck + Math.PI / 2);
        double rz = Math.sin(deck + Math.PI / 2);
        double along = -((fx - tdx) * ux + (fz) * uz);
        double lateral = (fx - tdx) * rx + fz * rz;
        boolean overDeck = along < 20 && along > -235 && Math.abs(lateral) < 18;
        double deckH = 19;
        if (fphase == 1) {
            // trapped: the wire stops you, you sail with the ship
            fv = Math.max(0, fv - 28 * dt);
            fx += 15 * dt + fv * Math.cos(Math.toRadians(fhdg)) * dt;
            fz += fv * Math.sin(Math.toRadians(fhdg)) * dt;
            falt = deckH;
            fpitch = 0;
            fbank = 0;
            if (now - fphaseAt > 7000) {
                resetFree();
            }
        } else if (fphase == 2) {
            // crashed or in the water: wait, then start again
            fv = Math.max(0, fv - 40 * dt);
            if (now - fphaseAt > 4000) {
                resetFree();
            }
        } else {
            // stick: roll and pitch rates
            double sx = stickX;
            double sy = stickY;
            if (apMode > 0) {
                double[] cmd = apFree();
                sx = cmd[0];
                sy = cmd[1];
            }
            fbank += sx * 85 * dt;
            if (Math.abs(sx) < 0.06) {
                fbank *= 1 - 0.25 * dt;
            }
            fbank = Math.max(-85, Math.min(85, fbank));
            fpitch += sy * 22 * dt * Math.min(1, fv / 80);
            fpitch = Math.max(-60, Math.min(60, fpitch));
            double v = Math.max(fv, 1);
            double nz = Math.cos(Math.toRadians(fpitch)) / Math.max(0.17, Math.cos(Math.toRadians(fbank)))
                    + sy * 1.6 * Math.min(1.5, v / 110);
            nz = Math.max(-3, Math.min(9.5, nz));
            fhdg += Math.toDegrees(9.81 * Math.tan(Math.toRadians(fbank)) / Math.max(40, v) * dt);
            // engine against drag (gear, flaps and the airbrake add drag) and gravity
            double thrust = throttle <= 0.8f ? throttle / 0.8 * 9.5 : 9.5 + (throttle - 0.8) / 0.2 * 8;
            double cd = 0.00058 + gear * 0.00035 + flaps * 0.0003 + brake * 0.0011;
            double acc = thrust - cd * v * v - 9.81 * Math.sin(Math.toRadians(fpitch));
            fv = Math.max(0, Math.min(620, fv + acc * dt));
            double vsp = fv * Math.sin(Math.toRadians(fpitch));
            double stall = flaps > 0.9f ? 55 : 68;
            if (fv < stall) {
                vsp -= (stall - fv) * 0.8;
                fpitch -= (stall - fv) * 0.08 * dt * 10;
            }
            double horiz = fv * Math.cos(Math.toRadians(fpitch));
            fx += horiz * Math.cos(Math.toRadians(fhdg)) * dt;
            fz += horiz * Math.sin(Math.toRadians(fhdg)) * dt;
            falt += vsp * dt;
            ffuel = Math.max(0, ffuel - (0.6 + throttle * (throttle > 0.8f ? 9 : 2.2)) * dt);
            if (ffuel <= 0) {
                throttle = 0;
            }
            State p = st;
            p.g = (float) nz;
            if (falt <= deckH && overDeck) {
                double sink = -vsp;
                if (sink > 7.5 || gear < 0.9f) {
                    fphase = 2;
                    fphaseAt = now;
                    fevent(gear < 0.9f ? "CRASH: gear was up!" : "CRASH: hit the deck too hard");
                    grade(-2);
                } else if (hook > 0.9f && along < 10 && along > -60) {
                    int wire = Math.max(1, Math.min(4, 1 + (int) ((10 - along) / 17)));
                    fphase = 1;
                    fphaseAt = now;
                    fevent("TRAP! " + wire + " wire" + (wire == 3 ? " ★ perfect" : ""));
                    grade(wire);
                } else {
                    falt = deckH;
                    fpitch = Math.max(fpitch, 0);
                    if (!event.startsWith("BOLTER") || now - eventAt > 4000) {
                        fevent(hook > 0.9f ? "BOLTER: missed the wires, full power!" : "BOLTER: hook was up!");
                        grade(-1);
                    }
                }
            } else if (falt <= 0) {
                fphase = 2;
                fphaseAt = now;
                fevent("IN THE WATER");
                grade(-2);
                falt = 0;
            }
        }
        // what the pages see
        State s = new State();
        s.name = "FA-18C_hornet";
        s.coal = 2;
        s.x = fx;
        s.z = fz;
        s.alt = (float) falt;
        s.agl = (float) (overDeck ? falt - deckH : falt);
        s.ias = (float) fv;
        s.tas = s.ias * 1.03f;
        s.mach = (float) (fv / 330);
        s.hdg = (float) ((fhdg % 360 + 360) % 360);
        s.pitch = (float) fpitch;
        s.bank = (float) fbank;
        s.vs = (float) (fv * Math.sin(Math.toRadians(fpitch)));
        double nzNow = st.g;
        s.g = fphase == 0 ? (float) nzNow : 1;
        double v = Math.max(fv, 1);
        s.aoa = fphase == 0 ? (float) Math.max(-4, Math.min(30, 8.1 * Math.pow(72 / v, 2) * Math.max(0.3, nzNow)
                * (flaps > 0.9f ? 1 : 1.3))) : 0;
        s.rpmL = s.rpmR = 62 + 38 * throttle;
        s.gear = gear;
        s.flaps = flaps;
        s.brake = brake;
        s.hook = hook;
        s.canopy = FPART[4];
        s.fuel = (float) ffuel;
        s.chaff = 60;
        s.flare = 60;
        s.shells = 578;
        s.weapons = 6;
        List<Obj> list = new ArrayList<>();
        Obj cvn = new Obj();
        cvn.id = "cvn";
        cvn.cat = 3;
        cvn.coal = 2;
        cvn.x = cx;
        cvn.z = 0;
        cvn.hdg = 0;
        cvn.name = "CVN_71";
        list.add(cvn);
        String[] names = {"S-3B Tanker", "E-2C", "MiG-29S"};
        for (int i = 0; i < names.length; i++) {
            Obj o = new Obj();
            o.id = "f" + i;
            o.cat = 1;
            o.coal = i < 2 ? 2 : 1;
            double ang = ftime / (30 + i * 10) + i * 2.1;
            double r = 12000 + i * 9000;
            o.x = cx + Math.cos(ang) * r;
            o.z = Math.sin(ang) * r;
            o.alt = 3000 + i * 1500;
            o.hdg = (float) Math.toDegrees(ang + Math.PI / 2);
            o.name = names[i];
            list.add(o);
        }
        st = s;
        if (fphase == 0) {
            maxG = Math.max(maxG, s.g);
        }
        track(s);
        objs = list;
        lastAt = now;
        objAt = now;
        changed();
    }

    private static float toward(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    private static void simStep() {
        float t = ((SystemClock.elapsedRealtime() - simStart) % 120000) / 1000f;
        long now = SystemClock.elapsedRealtime();
        State p = st;
        State s = new State();
        s.name = "FA-18C_hornet";
        s.coal = 2;
        // the carrier sails north at 15 m/s
        double total = (SystemClock.elapsedRealtime() - simStart) / 1000.0;
        double cx = (total % 120) * 15;
        float[] script = new float[5];
        List<Obj> list = new ArrayList<>();
        Obj cvn = new Obj();
        cvn.id = "cvn";
        cvn.cat = 3;
        cvn.coal = 2;
        cvn.x = cx;
        cvn.z = 0;
        cvn.hdg = 0;
        cvn.name = "CVN_71";
        list.add(cvn);
        if (t < 15) {
            // parked, canopy closes
            s.x = -20000;
            s.z = 3000;
            s.alt = 20;
            s.agl = 0;
            s.ias = 0;
            s.hdg = 0;
            script[0] = 1;
            script[1] = 0.5f;
            script[4] = t < 5 ? 1 : 0;
            s.rpmL = s.rpmR = 65;
        } else if (t < 35) {
            float k = (t - 15) / 20f;
            s.x = -20000 + k * k * 2600;
            s.z = 3000;
            s.ias = Math.min(170, k * 220) * (0.7f + 0.3f * throttle);
            s.alt = t < 24 ? 20 : 20 + (t - 24) * 90;
            s.agl = s.alt - 20;
            s.vs = t < 24 ? 0 : 60;
            s.pitch = t < 24 ? 0 : 12;
            s.aoa = t < 24 ? 0 : 7;
            s.hdg = 0;
            script[0] = t < 27 ? 1 : 0;
            script[1] = t < 30 ? 0.5f : 0;
            s.rpmL = s.rpmR = 99;
            s.g = t < 24 ? 1 : 1.4f;
        } else if (t < 70) {
            float k = t - 35;
            s.x = -17000 + k * 220;
            s.z = 3000 + 4000 * (float) Math.sin(k / 12);
            s.alt = 3000 + 300 * (float) Math.sin(k / 6);
            s.agl = s.alt;
            s.ias = 150 + 120 * throttle;
            s.mach = s.ias / 300;
            s.hdg = (float) (Math.toDegrees(Math.atan2(4000 * Math.cos(k / 12) / 12, 220)) + 360) % 360;
            s.bank = (float) (-30 * Math.sin(k / 12));
            s.aoa = 4;
            s.g = 1 + 3.5f * Math.abs((float) Math.sin(k / 3));
            s.rpmL = s.rpmR = 85 + 14 * throttle;
            String[] names = {"F-16C", "F-18C", "E-2C", "MiG-29S", "Su-27", "SA-11 Buk"};
            for (int i = 0; i < names.length; i++) {
                Obj o = new Obj();
                o.id = "c" + i;
                o.cat = i == 5 ? 2 : 1;
                o.coal = i < 3 ? 2 : 1;
                double ang = i * 1.05 + k / 20;
                double r = 8000 + i * 6000 - (i >= 3 ? k * 250 : 0);
                o.x = s.x + Math.cos(ang) * r;
                o.z = s.z + Math.sin(ang) * r;
                o.alt = i == 5 ? 0 : 2500 + i * 900;
                o.hdg = (float) Math.toDegrees(ang + Math.PI);
                o.name = names[i];
                list.add(o);
            }
            if (k > 15 && k < 32) {
                Obj tg = list.get(4);
                s.lockDist = (float) Math.hypot(tg.x - s.x, tg.z - s.z);
                s.lockClose = 320;
                s.lockName = tg.name;
                s.lockAlt = tg.alt;
            }
        } else if (t < 110) {
            // carrier approach from 9 km, a little high and drifting right, then corrected
            float k = (t - 70) / 40f;
            double along = 9000 * (1 - k);
            double lateral = 120 * Math.sin(k * 5.5) * (1 - k) + 6 * (1 - k);
            double deck = Math.toRadians(-9);
            double tdx = cx - 70;
            s.x = tdx - Math.cos(deck) * along + Math.cos(deck + Math.PI / 2) * lateral;
            s.z = -Math.sin(deck) * along + Math.sin(deck + Math.PI / 2) * lateral;
            double gsErr = 0.6 * Math.sin(k * 7) * (1 - k * 0.8);
            s.alt = (float) (19 + Math.tan(Math.toRadians(3.5 + gsErr)) * along);
            s.agl = s.alt;
            s.ias = 72;
            s.hdg = (float) ((Math.toDegrees(deck) + 360 - lateral / 40) % 360);
            s.aoa = 8.1f + 0.9f * (float) Math.sin(k * 9);
            s.vs = -4;
            s.g = 1;
            script[0] = t > 72 ? 1 : 0;
            script[3] = t > 74 ? 1 : 0;
            script[1] = t > 76 ? 1 : 0;
            s.rpmL = s.rpmR = 78;
        } else {
            // trapped
            s.x = cx - 40;
            s.z = 0;
            s.alt = 19;
            s.agl = 0;
            s.ias = Math.max(0, 72 - (t - 110) * 30);
            s.hdg = 351;
            script[0] = 1;
            script[3] = 1;
            script[1] = 1;
            s.rpmL = s.rpmR = 70;
        }
        float[] cur = {p.gear, p.flaps, p.brake, p.hook, p.canopy};
        float[] rate = {0.017f, 0.025f, 0.08f, 0.06f, 0.015f};
        for (int i = 0; i < 5; i++) {
            float want = now - TOUCHED[i] < 15000 ? TARGET[i] : script[i];
            cur[i] = toward(cur[i], want, rate[i]);
        }
        s.gear = cur[0];
        s.flaps = cur[1];
        s.brake = cur[2];
        s.hook = cur[3];
        s.canopy = cur[4];
        s.tas = s.ias * 1.05f;
        s.fuel = 4900 - t * 15;
        s.fuelExt = t < 70 ? 1200 : 0;
        s.chaff = 60 - (int) (t / 10);
        s.flare = 60 - (int) (t / 12);
        s.shells = 578;
        s.weapons = t < 60 ? 8 : 6;
        st = s;
        maxG = Math.max(maxG, s.g);
        objs = list;
        lastAt = now;
        objAt = now;
        changed();
    }
}
