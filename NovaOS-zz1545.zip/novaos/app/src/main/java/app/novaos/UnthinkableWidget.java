package app.novaos;

import android.annotation.SuppressLint;
import android.view.MotionEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

/**
 * UNTHINKABLE '75: the Cold War what-if war game as a home widget. The whole game is one offline page in assets;
 * its 3 save slots live in the WebView's own storage, so progress stays until you reset a slot.
 */
final class UnthinkableWidget extends NovaWidget {
    private final WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    UnthinkableWidget(NovaActivity host) {
        super(host);
        web = new WebView(host);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setBackgroundColor(0xFF0C110F);
        web.setOverScrollMode(OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        // the game scrolls itself, so keep the home page from stealing the swipe
        web.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
            }
            return false;
        });
        web.loadUrl("file:///android_asset/unthinkable75/index.html?widget=1");
        addView(web, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(560)));
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            web.onResume();
        } else {
            web.onPause();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        // each widget is a fresh view, so free this page when it goes away
        web.stopLoading();
        web.destroy();
    }
}
