package app.novaos;

import android.annotation.SuppressLint;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * UNTHINKABLE '75: the Cold War what-if war game as a home widget. The whole game is one offline page in assets;
 * its 3 save slots live in the WebView's own storage, so progress stays until you reset a slot.
 * The corner button opens the same game full screen.
 */
final class UnthinkableWidget extends NovaWidget {
    private static final String URL = "file:///android_asset/unthinkable75/index.html";
    private final WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    static WebView makeWeb(NovaActivity host, String query) {
        WebView w = new WebView(host);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        w.setBackgroundColor(0xFF0C110F);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setWebViewClient(new WebViewClient());
        // the game scrolls itself, so keep the home page from stealing the swipe
        w.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
            }
            return false;
        });
        w.loadUrl(URL + query);
        return w;
    }

    UnthinkableWidget(NovaActivity host) {
        super(host);
        web = makeWeb(host, "?widget=1");
        FrameLayout box = new FrameLayout(host);
        box.addView(web, new FrameLayout.LayoutParams(-1, -1));
        TextView fs = text("⛶", 20f, 0xFFF2B84B);
        fs.setGravity(Gravity.CENTER);
        fs.setBackground(Theme.rounded(0xCC0C110F, 12f, host));
        fs.setClickable(true);
        fs.setOnClickListener(v -> host.showOverlay(new Full(host)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END);
        lp.topMargin = dp(6);
        lp.rightMargin = dp(52);
        box.addView(fs, lp);
        addView(box, new LayoutParams(LayoutParams.MATCH_PARENT, dp(560)));
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            web.onResume();
        } else {
            web.onPause();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        web.stopLoading();
        web.destroy();
    }

    /** The same game on the whole screen. Saves are shared with the widget. */
    static final class Full extends FrameLayout implements BackAware {
        private final NovaActivity host;
        private final WebView w;

        @SuppressLint("JavascriptInterface")
        Full(NovaActivity host) {
            super(host);
            this.host = host;
            setBackgroundColor(0xFF0C110F);
            setClickable(true);
            w = makeWeb(host, "?full=1");
            w.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void close() {
                    host.runOnUiThread(host::hideOverlay);
                }
            }, "NovaHost");
            addView(w, new FrameLayout.LayoutParams(-1, -1));
            TextView x = new TextView(host);
            x.setText("✕");
            x.setTextSize(18f);
            x.setTextColor(0xFFF2B84B);
            x.setGravity(Gravity.CENTER);
            x.setBackground(Theme.rounded(0xCC0C110F, 12f, host));
            x.setClickable(true);
            x.setOnClickListener(v -> host.hideOverlay());
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Theme.dp(host, 40), Theme.dp(host, 40),
                Gravity.TOP | Gravity.END);
            lp.topMargin = Theme.dp(host, 38);
            lp.rightMargin = Theme.dp(host, 8);
            addView(x, lp);
        }

        @Override
        public boolean onBack() {
            host.hideOverlay();
            return true;
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            w.stopLoading();
            w.destroy();
        }
    }
}
