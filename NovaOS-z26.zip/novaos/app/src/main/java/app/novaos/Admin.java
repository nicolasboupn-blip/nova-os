package app.novaos;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Admin mode: switched on with the password, it unlocks the admin panel, free upgrades and secret terminal commands. */
final class Admin {
    static final String PASSWORD = "260423";

    private Admin() {}

    static boolean on() {
        return Castle.admin();
    }

    static boolean unlock(String pw) {
        if (PASSWORD.equals(pw == null ? "" : pw.trim())) {
            Prefs.putInt("admin_on", 1);
            log("admin mode on");
            return true;
        }
        return false;
    }

    static void lockOff() {
        log("admin mode off");
        Prefs.putInt("admin_on", 0);
    }

    static void log(String line) {
        String stamp = new SimpleDateFormat("dd.MM HH:mm", Locale.US).format(new Date());
        String old = Prefs.getString("adm_log", "");
        String[] rows = old.isEmpty() ? new String[0] : old.split("\n");
        StringBuilder sb = new StringBuilder();
        int from = Math.max(0, rows.length - 59);
        for (int i = from; i < rows.length; i++) {
            sb.append(rows[i]).append('\n');
        }
        sb.append(stamp).append("  ").append(line);
        Prefs.putString("adm_log", sb.toString());
    }

    static String getLog() {
        String l = Prefs.getString("adm_log", "");
        return l.isEmpty() ? "(empty)" : l;
    }

    /** Everything the panel does goes through here so it is logged. */
    static void setCoins(int n) {
        Prefs.putInt("slot_coins", Math.max(0, n));
        log("coins set to " + n);
    }

    static void completeQuests(NovaActivity host) {
        for (Quests.Def d : Quests.today3()) {
            if (!Quests.done(d)) {
                Prefs.putInt("q_p_" + d.id, d.target - 1);
                Quests.event(host, d.id);
            }
        }
        log("quests completed");
    }

    static void resetQuests() {
        Prefs.removePrefix("q_");
        log("quests reset");
    }

    static void unlockAllBadges(NovaActivity host) {
        for (Badges.Badge b : Badges.ALL) {
            Prefs.putInt("badge_" + b.id, 1);
        }
        log("all badges unlocked");
    }

    static void resetBadges() {
        Prefs.removePrefix("badge_");
        Prefs.removePrefix("stat_");
        log("badges reset");
    }

    static void fakeTime(int hour) {
        Prefs.putInt("adm_hour", hour);
        log("fake hour " + hour);
    }

    static void forceWeather(int kind) {
        Prefs.putInt("adm_wx", kind);
        log("castle weather " + kind);
    }

    static void unlockPets() {
        Prefs.putInt("pet_lock", 0);
        log("pet lock removed");
    }

    static void setPet(int food, int joy) {
        Prefs.putInt("pet_food", food);
        Prefs.putInt("pet_food_t", Castle.nowMin());
        Prefs.putInt("pet_joy", joy);
        log("pet food " + food + " joy " + joy);
    }

    static void resetFeature(String prefix, String name) {
        Prefs.removePrefix(prefix);
        Castle.changed();
        log("reset " + name);
    }

    /** All settings as text, for backup. */
    static String exportAll() {
        StringBuilder sb = new StringBuilder("NOVA-BACKUP\n");
        java.util.TreeMap<String, Object> m = new java.util.TreeMap<>(Prefs.all());
        for (java.util.Map.Entry<String, Object> e : m.entrySet()) {
            Object v = e.getValue();
            if (v == null || e.getKey().equals("s_pin") || e.getKey().startsWith("adm_log")) {
                continue;
            }
            String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : "s";
            sb.append(t).append('\t').append(e.getKey()).append('\t')
                    .append(String.valueOf(v).replace("\n", "\\n")).append('\n');
        }
        return sb.toString();
    }

    /** Restores a backup. Returns how many values were read, or -1 if it is not a backup. */
    static int importAll(String text) {
        if (text == null || !text.startsWith("NOVA-BACKUP")) {
            return -1;
        }
        int n = 0;
        for (String line : text.split("\n")) {
            String[] f = line.split("\t", 3);
            if (f.length < 3) {
                continue;
            }
            try {
                switch (f[0]) {
                    case "b":
                        Prefs.putBool(f[1], Boolean.parseBoolean(f[2]));
                        break;
                    case "i":
                        Prefs.putInt(f[1], Integer.parseInt(f[2]));
                        break;
                    case "s":
                        Prefs.putString(f[1], f[2].replace("\\n", "\n"));
                        break;
                    default:
                        continue;
                }
                n++;
            } catch (RuntimeException ignored) {
                // skip a bad line
            }
        }
        Castle.changed();
        log("backup restored, " + n + " values");
        return n;
    }

    /** Terminal commands that need admin. Returns the text to print, or null if it is not one of ours. */
    static String command(NovaActivity host, String name, String arg) {
        if (name.equals("admin")) {
            if (arg.equals("off")) {
                lockOff();
                return "admin mode off\n\n";
            }
            return unlock(arg) ? "admin mode on. type 'adm' for the commands.\n\n" : "wrong password\n\n";
        }
        if (!on()) {
            return null;
        }
        try {
            switch (name) {
                case "adm":
                    return "coins N | stage N | hour N|off | weather 0-3|off | dragon fly|fire|wake|sleep|home|coil|uncoil|say TEXT\n"
                            + "pig | quests done|reset | badges all|reset | saver on|off | battery N|off\n"
                            + "unlockpets | feed | starve | log | say TEXT | panel\n\n";
                case "coins":
                    setCoins(Integer.parseInt(arg));
                    return "coins = " + Coins.get() + "\n\n";
                case "stage":
                    Castle.setStage(host, Integer.parseInt(arg));
                    log("castle stage " + arg);
                    return "castle stage " + Castle.stage() + "\n\n";
                case "hour":
                    fakeTime(arg.equals("off") ? -1 : Integer.parseInt(arg));
                    return "ok\n\n";
                case "weather":
                    forceWeather(arg.equals("off") ? -1 : Integer.parseInt(arg));
                    return "ok\n\n";
                case "dragon":
                    if (arg.equals("coil") || arg.equals("uncoil")) {
                        Prefs.putInt("dr_coil", arg.equals("coil") ? 1 : 0);
                        Castle.changed();
                        log("dragon " + arg);
                        return "ok\n\n";
                    }
                    if (host.castle == null) {
                        return "the castle is not on screen\n\n";
                    }
                    host.castle.dragonDo(arg.equals("home") ? "home" : arg);
                    if (arg.startsWith("say ")) {
                        host.castle.dragonDo("say:" + arg.substring(4));
                    }
                    log("dragon " + arg);
                    return "ok\n\n";
                case "visitor":
                    if (host.castle == null) {
                        return "the castle is not on screen\n\n";
                    }
                    host.castle.callVisitor(arg.startsWith("m") ? Visitors.MERCHANT : arg.startsWith("t") ? Visitors.THIEF
                            : Visitors.KNIGHT);
                    log("visitor " + arg);
                    return "ok (knight, merchant or thief)\n\n";
                case "pig":
                    Prefs.putInt("dr_pig_t", 0);
                    return Castle.orderPig(host) ? "pig on its way\n\n" : "no dragon yet (stage 10)\n\n";
                case "quests":
                    if (arg.equals("reset")) {
                        resetQuests();
                    } else {
                        completeQuests(host);
                    }
                    return "ok\n\n";
                case "badges":
                    if (arg.equals("reset")) {
                        resetBadges();
                    } else {
                        unlockAllBadges(host);
                    }
                    return "ok\n\n";
                case "saver":
                    Prefs.putInt("adm_saver", arg.equals("on") ? 1 : 0);
                    Saver.refresh();
                    log("saver " + arg);
                    return "ok\n\n";
                case "battery":
                    Prefs.putInt("adm_batt", arg.equals("off") ? -1 : Integer.parseInt(arg));
                    Saver.refresh();
                    log("fake battery " + arg);
                    return "ok\n\n";
                case "unlockpets":
                    unlockPets();
                    return "ok\n\n";
                case "feed":
                    setPet(100, 100);
                    return "ok\n\n";
                case "starve":
                    setPet(5, 5);
                    return "ok\n\n";
                case "log":
                    return getLog() + "\n\n";
                case "say":
                    host.wizardSay(arg);
                    log("wizard says: " + arg);
                    return "ok\n\n";
                case "panel":
                    AdminPanel.open(host);
                    return "";
                default:
                    return null;
            }
        } catch (NumberFormatException e) {
            return "that needs a number\n\n";
        }
    }
}
