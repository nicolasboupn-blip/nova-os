package app.novaos;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** What the wizard says the first time you discover something, and what he says when you tap him. */
final class Tips {
    private Tips() {
    }

    /** The tip that belongs to what you are looking at now. Tapping the wizard repeats it. */
    static String context = "home";
    private static final Random RND = new Random();

    static final String[] PAGE_TIPS = {
        "System: battery, memory and storage at a glance.",
        "Network: your connection and speed.",
        "Music: control your player here. It needs notification access once, in Settings.",
        "Battery today: how your charge went down, as a graph.",
        "App usage: which apps ate your day.",
        "Slots! Three 7s is the only jackpot, and it is rare. The coins are shared with the whole casino.",
        "Ten mini-games on two pages (tap MORE). Tap a box and it grows to full screen. Beat your best!",
        "A stopwatch with laps.",
        "A timer. It keeps ringing even when NOVA is closed.",
        "A calendar. The days with events glow.",
        "Quick note: jot something down without leaving home.",
        "Badges! Unlock them by playing, spinning and finishing games.",
        "A private browser. It wipes itself when you leave. It is not Tor, just DuckDuckGo with no traces.",
        "VPN: shows whether one is active and opens CyberGhost for you. NOVA has no VPN of its own.",
        "The casino: roulette, blackjack, dice, scratch cards, and a party wheel with no bets.",
        "Weather for your city. Tap the city to change it.",
        "Sunrise and sunset, worked out for you.",
        "Quick switches: flashlight, ringer and shortcuts to Wi-Fi, Bluetooth and more.",
        "A unit and currency converter.",
        "A calculator. The terminal has one too: calc 2+2.",
        "Countdowns to the days that matter.",
        "Crypto prices, live from the internet.",
        "Quests: three small goals every day. Finish them for coins, and keep a streak going.",
        "Your companion! Feed it with coins and play with it. It lives in my castle.",
        "Castle: upgrade it with coins. Water wheel, lava, a banner, a dragon and more.",
        "To-do and habits. Finish a task for 5 coins, tick a habit daily to build a streak.",
        "Focus timer: 25 minutes of work pays coins, then a 5 minute break.",
        "Shop: a free lucky spin every day, and the Coin Shop with potions, hats, titles and a bank. Tap your character to dress him up.",
        "Map: tap LOCATE to see where you are on a map. Your position is never saved."};

    private static final String[] RANDOM = {
        "Tap the panel's title to jump to any of its pages.",
        "Double-tap an empty spot on home to draw on the background.",
        "Long-press an empty spot and draw a shape: I can teach it to open an app or spin the wheel.",
        "Shake the phone twice for a golden coin flip.",
        "Say \"Hey Nova\" and a command, like \"spin roulette\". Turn it on in Settings first.",
        "Try the terminal: 8ball, calc, weather. It likes visitors.",
        "The animated wallpapers in Settings change the whole mood.",
        "Cheat mode in Settings has a secret about the roulette. Shh.",
        "Holographic icons shimmer as you tilt the phone.",
        "Charge the phone and leave it alone: the night clock will glow.",
        "A wizard is never late, nor early. He arrives when you tap him.",
        "Odds are odds: the casino here is fair, and the house still wins over time. Spend wisely, traveller."
    };

    private static String text(String id) {
        if (id.startsWith("page")) {
            try {
                int n = Integer.parseInt(id.substring(4));
                if (n >= 0 && n < PAGE_TIPS.length) {
                    return PAGE_TIPS[n];
                }
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        switch (id) {
            case "hello":
                return "Greetings, traveller! I am Merlo. I will explain things the first time you find them. Tap me any time. Drag me if I stand in your way.";
            case "home":
                return "Welcome home! The panel swipes sideways, and its title opens a page list. Hold an empty spot to draw a shape.";
            case "dragon":
                return "That is Ember, my dragon. He naps on the tower, breathes fire, and flies a loop now and then. Poke him if you dare.";
            case "castle":
                return "My castle! Tap it and I come out. Tap it again and I go home. At night the windows glow.";
            case "drawer":
                return "The drawer: every app on your phone lives here.";
            case "terminal":
                return "A terminal! Type help to see every command. Try 8ball, calc 2+2 or weather paris.";
            case "notes":
                return "Your notes live here.";
            case "settings":
                return "Settings. Everything about NOVA bends to your will here. Scroll, there is a lot.";
            case "shade":
                return "The control shade: quick switches and your notifications. Low-priority ones fold into one row.";
            case "draw":
                return "Draw mode! Scribble on the background. UNDO, CLEAR and DONE are at the bottom.";
            case "gesture":
                return "Draw a shape and I will learn it. It can open an app or run an action, like spinning the wheel.";
            case "shake":
                return "A golden coin! Heads or tails, decided fairly before it flips.";
            case "voice":
                return "Hey Nova listens only while NOVA is on screen. Say Hey Nova, then a command.";
            case "badge":
                return "A badge! Find them all on the BADGES page.";
            case "nightclock":
                return "The night clock: it appears when you charge and leave the phone alone. Touch the screen to wake it.";
            case "game_roulette":
                return "Roulette: place chips on the table, then SPIN. Zero beats every outside bet. Straight numbers pay 35 to 1.";
            case "game_blackjack":
                return "Blackjack: get closer to 21 than the dealer without going over. A natural pays 3 to 2.";
            case "game_dice":
                return "Dice duel: roll higher than the house and win x1.9. Ties push.";
            case "game_scratch":
                return "Scratch the card clear with your finger. Prizes go up to x25.";
            case "game_party":
                return "The party wheel: no bets, no coins. Just tap the wheel. Made for friends.";
            case "game_other":
                return "A mini-game! Beat your best score. The X closes it.";
            case "phone":
                return "NOVA's own phone: a dial pad and your contacts. Calls still run through Android.";
            case "gallery":
                return "Your photos, in NOVA style. Tap one to see it big, swipe to move between them.";
            case "camera":
                return "NOVA's own camera. If it ever misbehaves, STOCK opens your normal camera.";
            case "setup":
                return "All set! You can run this setup again from Settings.";
            default:
                return null;
        }
    }

    /** Shows the tip for an id the first time only. Always remembers it as the current context. */
    static void discover(NovaActivity host, String id) {
        context = id;
        if (!Prefs.wizard() || Prefs.getInt("tip_" + id, 0) != 0) {
            return;
        }
        String t = text(id);
        if (t == null) {
            return;
        }
        Prefs.putInt("tip_" + id, 1);
        host.wizardSay(t);
    }

    /** What the wizard says when you tap him: this screen's tip again, or something random. */
    static String forTap() {
        String t = text(context);
        if (t != null && RND.nextInt(3) != 0) {
            return t;
        }
        return RANDOM[RND.nextInt(RANDOM.length)];
    }

    static String hello() {
        return text("hello");
    }

    static void screen(NovaActivity host, int which) {
        switch (which) {
            case NovaActivity.HOME:
                discover(host, "home");
                break;
            case NovaActivity.DRAWER:
                discover(host, "drawer");
                break;
            case NovaActivity.TERMINAL:
                discover(host, "terminal");
                break;
            case NovaActivity.NOTES:
                discover(host, "notes");
                break;
            case NovaActivity.SETTINGS:
                discover(host, "settings");
                break;
            default:
                break;
        }
    }

    /** All the tip ids, so the settings can reset them. */
    static List<String> allIds() {
        List<String> l = new ArrayList<>();
        for (int i = 0; i < PAGE_TIPS.length; i++) {
            l.add("page" + i);
        }
        for (String s : new String[] {"hello", "home", "drawer", "terminal", "notes", "settings", "shade", "draw",
            "gesture", "shake", "voice", "badge", "nightclock", "game_roulette", "game_blackjack", "game_dice",
            "game_scratch", "game_party", "game_other", "phone", "gallery", "camera", "setup", "castle", "dragon"}) {
            l.add(s);
        }
        return l;
    }
}
