package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Status panel page: a small map of where you are, from OpenStreetMap tiles. Your position is only read when you
 * tap, and is never saved. Only the tile numbers (roughly where you are) go to the tile server.
 */
final class MapPage extends LinearLayout {
    private static final String FINE = android.Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COARSE = android.Manifest.permission.ACCESS_COARSE_LOCATION;

    private final NovaActivity host;
    private final ImageView img;
    private final TextView info;
    private final TextView zoomLabel;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private double lat;
    private double lon;
    private boolean have;
    private int zoom = 15;
    private boolean dark = true;
    private boolean busy;
    private int gen;

    MapPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        setPadding(Theme.dp(host, 16), Theme.dp(host, 4), Theme.dp(host, 16), Theme.dp(host, 4));
        img = new ImageView(host);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(Theme.rounded(0x22FFFFFF, 14f, host));
        img.setClipToOutline(true);
        img.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(android.view.View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Theme.dp(host, 14));
            }
        });
        addView(img, new LayoutParams(-1, Theme.dp(host, 150)));
        info = new TextView(host);
        info.setTypeface(Theme.MONO);
        info.setTextSize(10f);
        info.setTextColor(Theme.DIM);
        info.setGravity(Gravity.CENTER);
        info.setText("Tap LOCATE to see where you are");
        info.setPadding(0, Theme.dp(host, 4), 0, Theme.dp(host, 4));
        addView(info);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.addView(chip("LOCATE", true, v -> locate()));
        row.addView(chip("-", false, v -> zoomBy(-1)));
        zoomLabel = chip("Z15", false, null);
        row.addView(zoomLabel);
        row.addView(chip("+", false, v -> zoomBy(1)));
        row.addView(chip("DARK", false, v -> {
            dark = !dark;
            draw();
        }));
        addView(row);
    }

    private TextView chip(String s, boolean main, OnClickListener l) {
        TextView b = new TextView(host);
        b.setText(s);
        b.setTypeface(Theme.MONO);
        b.setTextSize(11f);
        b.setTextColor(main ? Theme.BG : Theme.TEXT);
        b.setBackground(Theme.rounded(main ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        b.setPadding(Theme.dp(host, 11), Theme.dp(host, 6), Theme.dp(host, 11), Theme.dp(host, 6));
        LayoutParams lp = new LayoutParams(-2, -2);
        lp.leftMargin = lp.rightMargin = Theme.dp(host, 3);
        b.setLayoutParams(lp);
        if (l != null) {
            b.setClickable(true);
            b.setOnClickListener(l);
        }
        return b;
    }

    private void zoomBy(int d) {
        int z = Math.max(12, Math.min(17, zoom + d));
        if (z == zoom) {
            return;
        }
        zoom = z;
        zoomLabel.setText("Z" + zoom);
        if (have) {
            draw();
        }
    }

    // ------------------------------------------------------------------ location

    private void locate() {
        if (busy) {
            return;
        }
        host.ask(new String[] {FINE, COARSE}, this::readLocation, () -> info.setText(
                "Location is off for NOVA. Allow it in Android settings > Apps > NOVA > Permissions."));
    }

    private void readLocation() {
        final LocationManager lm = (LocationManager) host.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isLocationEnabled()) {
            info.setText("Switch on Location in the quick settings first.");
            return;
        }
        busy = true;
        info.setText("Finding you...");
        Location best = null;
        try {
            for (String prov : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (best == null || l.getTime() > best.getTime())) {
                    best = l;
                }
            }
        } catch (SecurityException e) {
            busy = false;
            return;
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < 10 * 60 * 1000L) {
            got(best);
            return;
        }
        final Location stale = best;
        final LocationListener ll = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                lm.removeUpdates(this);
                got(l);
            }
        };
        try {
            String prov = lm.getProviders(true).contains(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER
                    : LocationManager.NETWORK_PROVIDER;
            lm.requestSingleUpdate(prov, ll, Looper.getMainLooper());
        } catch (RuntimeException e) {
            busy = false;
            if (stale != null) {
                got(stale);
            } else {
                info.setText("Couldn't get a position.");
            }
            return;
        }
        ui.postDelayed(() -> {
            if (busy) {
                lm.removeUpdates(ll);
                if (stale != null) {
                    got(stale);
                } else {
                    busy = false;
                    info.setText("No position yet. Try outside or near a window.");
                }
            }
        }, 15000);
    }

    private void got(Location l) {
        busy = false;
        lat = l.getLatitude();
        lon = l.getLongitude();
        have = true;
        draw();
    }

    // ------------------------------------------------------------------ tiles

    private void draw() {
        final int my = ++gen;
        final double la = lat;
        final double lo = lon;
        final int z = zoom;
        final boolean dk = dark;
        info.setText("Loading map...");
        new Thread(() -> {
            final Bitmap bmp = render(la, lo, z, dk);
            ui.post(() -> {
                if (my != gen) {
                    return;
                }
                if (bmp == null) {
                    info.setText("Couldn't load the map. Check your connection.");
                } else {
                    img.setImageBitmap(bmp);
                    info.setText(String.format(java.util.Locale.US, "%.4f, %.4f   © OpenStreetMap contributors", la, lo));
                }
            });
        }).start();
    }

    private static Bitmap render(double la, double lo, int z, boolean dk) {
        double n = Math.pow(2, z);
        double fx = (lo + 180.0) / 360.0 * n;
        double latRad = Math.toRadians(la);
        double fy = (1.0 - Math.log(Math.tan(latRad) + 1.0 / Math.cos(latRad)) / Math.PI) / 2.0 * n;
        int tx = (int) Math.floor(fx);
        int ty = (int) Math.floor(fy);
        Bitmap out = Bitmap.createBitmap(768, 768, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(0xFF202028);
        int got = 0;
        int max = (int) n;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = ((tx + dx) % max + max) % max;
                int y = ty + dy;
                if (y < 0 || y >= max) {
                    continue;
                }
                byte[] b = Http.bytes("https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png");
                if (b == null) {
                    continue;
                }
                Bitmap t = BitmapFactory.decodeByteArray(b, 0, b.length);
                if (t != null) {
                    c.drawBitmap(t, (dx + 1) * 256, (dy + 1) * 256, null);
                    got++;
                }
            }
        }
        if (got == 0) {
            return null;
        }
        // centre the view on the exact spot inside the middle tile
        float cx = (float) ((fx - tx) * 256 + 256);
        float cy = (float) ((fy - ty) * 256 + 256);
        Bitmap view = Bitmap.createBitmap(512, 300, Bitmap.Config.ARGB_8888);
        Canvas vc = new Canvas(view);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (dk) {
            p.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[] {
                -0.9f, 0, 0, 0, 235, 0, -0.9f, 0, 0, 235, 0, 0, -0.9f, 0, 245, 0, 0, 0, 1, 0})));
        }
        vc.drawBitmap(out, 256 - cx, 150 - cy, p);
        // the pin
        Paint pin = new Paint(Paint.ANTI_ALIAS_FLAG);
        pin.setColor(0x55000000);
        vc.drawOval(256 - 9, 150 - 3, 256 + 9, 150 + 5, pin);
        Path drop = new Path();
        drop.moveTo(256, 150);
        drop.cubicTo(256 - 22, 150 - 22, 256 - 14, 150 - 40, 256, 150 - 40);
        drop.cubicTo(256 + 14, 150 - 40, 256 + 22, 150 - 22, 256, 150);
        pin.setColor(Theme.ACCENT);
        vc.drawPath(drop, pin);
        pin.setColor(0xFFFFFFFF);
        vc.drawCircle(256, 150 - 26, 5, pin);
        return view;
    }
}
