package app.novaos;

/**
 * You, as a pixel art figure. Everything is chosen by small numbers saved in Prefs and drawn in code. Pure Java so it
 * can be previewed on a desktop. Facing the front, W x H pixels, feet on the bottom row.
 */
final class Avatar {
    static final int W = 16, H = 30;

    static final String[] SKIN_NAMES = {"Light", "Fair", "Tan", "Brown", "Dark", "Deep"};
    static final int[] SKIN = {0xF6D2B0, 0xEBB98E, 0xD49A6A, 0xB07A4C, 0x8A5632, 0x5E3A22};
    static final String[] HAIR_STYLES = {"Short", "Spiky", "Long", "Mohawk", "Bun", "Bald", "Afro", "Messy"};
    static final int[] HAIR_STYLE_COST = {0, 0, 80, 150, 80, 0, 200, 0};
    static final String[] HAIR_COLOR_NAMES = {"Black", "Dark brown", "Brown", "Light brown", "Dirty blonde", "Blonde",
        "Red", "Grey", "White", "Blue", "Pink", "Green"};
    static final int[] HAIR_COLOR = {0x1E1A1C, 0x3E2616, 0x5A3820, 0x8A6038, 0xB8925A, 0xDDBC6A, 0xB5452A, 0xB8B8C4,
        0xE8E8EE, 0x3A6FE0, 0xE86AB4, 0x4CC46A};
    static final int[] HAIR_COLOR_COST = {0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 120, 120};
    static final String[] EYE_NAMES = {"Dark", "Blue", "Green", "Grey", "Hazel"};
    static final int[] EYES = {0x2A2230, 0x4A86C8, 0x3E9A5A, 0x7A8C9C, 0x8A6A2E};
    static final String[] SHIRTS = {"T-shirt", "Hoodie", "Suit", "Armor", "Robe"};
    static final int[] SHIRT_COST = {0, 0, 400, 600, 300};
    static final String[] SHIRT_COLOR_NAMES = {"Red", "Blue", "Green", "Yellow", "Purple", "Black", "White", "Orange", "Teal", "Gold"};
    static final int[] SHIRT_COLOR = {0xC83A3A, 0x3A6FD8, 0x3AA860, 0xE8C03A, 0x8A4AC8, 0x2A2A34, 0xECECEC, 0xE88A2A, 0x2AB0B0, 0xF0C040};
    static final int[] SHIRT_COLOR_COST = {0, 0, 0, 0, 0, 0, 0, 0, 0, 200};
    static final String[] PANTS_NAMES = {"Jeans", "Black", "Khaki", "Grey", "Green", "Shorts"};
    static final int[] PANTS = {0x3A5A9A, 0x2A2A34, 0xB89A62, 0x7A7A86, 0x3A6A48, 0x3A5A9A};
    static final String[] HATS = {"None", "Cap", "Beanie", "Crown", "Wizard hat", "Headband", "Top hat"};
    static final int[] HAT_COST = {0, 100, 100, 800, 500, 60, 400};
    static final String[] FACE = {"None", "Glasses", "Sunglasses", "Scarf", "Headphones", "Eyepatch"};
    static final int[] FACE_COST = {0, 80, 150, 120, 200, 60};
    static final String[] BACK = {"None", "Cape", "Backpack"};
    static final int[] BACK_COST = {0, 300, 80};
    static final String[] SHOES = {"Sneakers", "Boots", "Gold shoes"};
    static final int[] SHOES_COST = {0, 100, 500};

    private Avatar() {}

    /** One configuration. Order: skin, hairStyle, hairColor, shirt, shirtColor, pants, hat, face, back, shoes, eyes. */
    static int[] look() {
        return new int[] {Prefs.getInt("av_skin", 0), Prefs.getInt("av_hair", 7), Prefs.getInt("av_hairc", 5),
            Prefs.getInt("av_shirt", 1), Prefs.getInt("av_shirtc", 5), Prefs.getInt("av_pants", 1),
            Prefs.getInt("av_hat", 0), Prefs.getInt("av_face", 0), Prefs.getInt("av_back", 0), Prefs.getInt("av_shoes", 0),
            Prefs.getInt("av_eyes", 1)};
    }

    static final String[] KEYS = {"av_skin", "av_hair", "av_hairc", "av_shirt", "av_shirtc", "av_pants", "av_hat",
        "av_face", "av_back", "av_shoes", "av_eyes"};

    private static final int OUT = 0xFF1C1626;

    private static int opaque(int rgb) {
        return 0xFF000000 | rgb;
    }

    private static int mul(int rgb, float f) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 255) * f));
        int g = Math.min(255, Math.round(((rgb >> 8) & 255) * f));
        int b = Math.min(255, Math.round((rgb & 255) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void rc(int[] px, int x, int y, int w, int h, int col) {
        for (int j = y; j < y + h; j++) {
            for (int i = x; i < x + w; i++) {
                if (i >= 0 && j >= 0 && i < W && j < H) {
                    px[j * W + i] = col;
                }
            }
        }
    }

    private static void dot(int[] px, int x, int y, int col) {
        rc(px, x, y, 1, 1, col);
    }

    private static int[] outline(int[] px) {
        int[] o = px.clone();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (px[y * W + x] != 0) {
                    continue;
                }
                boolean near = false;
                int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                for (int[] q : d) {
                    int xx = x + q[0];
                    int yy = y + q[1];
                    if (xx >= 0 && yy >= 0 && xx < W && yy < H && px[yy * W + xx] != 0) {
                        near = true;
                        break;
                    }
                }
                if (near) {
                    o[y * W + x] = OUT;
                }
            }
        }
        return o;
    }

    static int[] render() {
        return render(look());
    }

    static int[] render(int[] lk) {
        int[] px = new int[W * H];
        final int skin = opaque(SKIN[Math.max(0, Math.min(SKIN.length - 1, lk[0]))]);
        final int skinD = mul(skin, 0.82f);
        final int hair = opaque(HAIR_COLOR[Math.max(0, Math.min(HAIR_COLOR.length - 1, lk[2]))]);
        final int hairD = mul(hair, 0.7f);
        final int hairL = mul(hair, 1.25f);
        final int shirtRgb = SHIRT_COLOR[Math.max(0, Math.min(SHIRT_COLOR.length - 1, lk[4]))];
        final int sc = opaque(shirtRgb);
        final int scD = mul(sc, 0.75f);
        final int scL = mul(sc, 1.2f);
        final int pc = opaque(PANTS[Math.max(0, Math.min(PANTS.length - 1, lk[5]))]);
        final int pcD = mul(pc, 0.75f);
        final int shirt = lk[3];
        final boolean shorts = lk[5] == 5;
        final int gold = 0xFFF0C040;
        final int goldD = 0xFFB07C1E;
        final int white = 0xFFF2F2F2;
        final int dark = 0xFF2A2A34;

        // behind the body: cape or backpack
        if (lk[8] == 1) {
            rc(px, 2, 13, 12, 15, 0xFFB02E3A);
            rc(px, 2, 13, 2, 15, 0xFF8A2030);
            rc(px, 12, 13, 2, 15, 0xFF8A2030);
            rc(px, 4, 26, 8, 2, 0xFF8A2030);
        } else if (lk[8] == 2) {
            rc(px, 1, 14, 3, 8, 0xFF7A5430);
            rc(px, 12, 14, 3, 8, 0xFF7A5430);
            rc(px, 1, 14, 1, 8, 0xFF9A7040);
            rc(px, 2, 13, 2, 1, 0xFF5A3C20);
        }
        // long hair and afro sit behind the head
        if (lk[1] == 2) {
            rc(px, 3, 5, 2, 9, hair);
            rc(px, 11, 5, 2, 9, hairD);
        } else if (lk[1] == 6) {
            rc(px, 2, 1, 12, 10, hair);
            rc(px, 3, 0, 10, 1, hair);
            rc(px, 12, 2, 2, 8, hairD);
            rc(px, 4, 1, 3, 1, hairL);
        }
        // legs and shoes
        if (shirt != 4) {
            rc(px, 4, 21, 8, 5, pc);
            rc(px, 4, 21, 1, 5, mul(pc, 1.15f));
            rc(px, 11, 21, 1, 5, pcD);
            rc(px, 7, 24, 2, 2, 0);
            rc(px, 7, 21, 2, 3, pcD);
            if (shorts) {
                rc(px, 4, 24, 8, 2, skin);
                rc(px, 7, 24, 2, 2, 0);
                rc(px, 11, 24, 1, 2, skinD);
            }
        } else {
            rc(px, 5, 24, 6, 3, skin);
            rc(px, 7, 24, 2, 3, 0);
        }
        int shoe = lk[9] == 1 ? 0xFF6A4426 : lk[9] == 2 ? gold : white;
        int shoeD = lk[9] == 1 ? 0xFF42291A : lk[9] == 2 ? goldD : 0xFF9A9AAA;
        if (lk[9] == 1) {
            rc(px, 4, 25, 4, 4, shoe);
            rc(px, 8, 25, 4, 4, shoe);
            rc(px, 4, 25, 4, 1, 0xFF8A5E38);
            rc(px, 8, 25, 4, 1, 0xFF8A5E38);
        } else {
            rc(px, 3, 26, 5, 2, shoe);
            rc(px, 8, 26, 5, 2, shoe);
        }
        rc(px, 3, 28, 5, 1, shoeD);
        rc(px, 8, 28, 5, 1, shoeD);
        // torso and arms
        switch (shirt) {
            case 0:
                rc(px, 4, 14, 8, 7, sc);
                rc(px, 11, 14, 1, 7, scD);
                rc(px, 4, 14, 1, 7, scL);
                rc(px, 2, 14, 2, 3, sc);
                rc(px, 12, 14, 2, 3, scD);
                rc(px, 2, 17, 2, 3, skin);
                rc(px, 12, 17, 2, 3, skinD);
                rc(px, 7, 14, 2, 1, skin);
                break;
            case 1:
                rc(px, 4, 14, 8, 7, sc);
                rc(px, 11, 14, 1, 7, scD);
                rc(px, 4, 14, 1, 7, scL);
                rc(px, 2, 14, 2, 6, sc);
                rc(px, 12, 14, 2, 6, scD);
                rc(px, 2, 19, 2, 1, scD);
                rc(px, 12, 19, 2, 1, mul(sc, 0.6f));
                rc(px, 2, 20, 2, 1, skin);
                rc(px, 12, 20, 2, 1, skinD);
                rc(px, 4, 13, 8, 2, scD);
                rc(px, 7, 15, 1, 3, white);
                rc(px, 9, 15, 1, 3, white);
                rc(px, 5, 18, 6, 2, scD);
                break;
            case 2:
                rc(px, 4, 14, 8, 7, 0xFF2E2E3E);
                rc(px, 11, 14, 1, 7, 0xFF1E1E2A);
                rc(px, 2, 14, 2, 6, 0xFF2E2E3E);
                rc(px, 12, 14, 2, 6, 0xFF1E1E2A);
                rc(px, 2, 20, 2, 1, skin);
                rc(px, 12, 20, 2, 1, skinD);
                rc(px, 7, 14, 2, 4, white);
                rc(px, 8, 15, 1, 5, 0xFFC83A3A);
                rc(px, 6, 14, 1, 3, 0xFF3E3E52);
                rc(px, 9, 14, 1, 3, 0xFF3E3E52);
                dot(px, 8, 19, 0xFFE8C03A);
                break;
            case 3:
                rc(px, 4, 14, 8, 7, 0xFFA0AAC0);
                rc(px, 4, 14, 2, 7, 0xFFE0E6F4);
                rc(px, 11, 14, 1, 7, 0xFF626C86);
                rc(px, 1, 13, 3, 3, 0xFFE0E6F4);
                rc(px, 12, 13, 3, 3, 0xFFA0AAC0);
                rc(px, 2, 16, 2, 4, 0xFFA0AAC0);
                rc(px, 12, 16, 2, 4, 0xFF626C86);
                rc(px, 2, 20, 2, 1, skin);
                rc(px, 12, 20, 2, 1, skinD);
                rc(px, 7, 14, 2, 6, gold);
                rc(px, 4, 19, 8, 1, goldD);
                rc(px, 7, 19, 2, 1, gold);
                break;
            default:
                rc(px, 4, 14, 8, 13, sc);
                rc(px, 3, 24, 10, 3, sc);
                rc(px, 11, 14, 1, 13, scD);
                rc(px, 12, 24, 1, 3, scD);
                rc(px, 4, 14, 1, 13, scL);
                rc(px, 2, 14, 2, 7, sc);
                rc(px, 12, 14, 2, 7, scD);
                rc(px, 2, 20, 2, 1, skin);
                rc(px, 12, 20, 2, 1, skinD);
                rc(px, 4, 19, 8, 1, gold);
                rc(px, 7, 19, 2, 1, goldD);
                dot(px, 6, 23, gold);
                dot(px, 10, 25, gold);
                dot(px, 5, 21, gold);
                rc(px, 7, 14, 2, 1, skin);
                break;
        }
        // scarf
        if (lk[7] == 3) {
            rc(px, 4, 13, 8, 2, 0xFFD2463E);
            rc(px, 4, 14, 8, 1, 0xFF9A2E2E);
            rc(px, 10, 15, 2, 4, 0xFFD2463E);
            rc(px, 10, 18, 2, 1, 0xFF9A2E2E);
        } else {
            rc(px, 7, 13, 2, 1, skin);
        }
        // head
        rc(px, 4, 5, 8, 8, skin);
        dot(px, 4, 5, 0);
        dot(px, 11, 5, 0);
        rc(px, 11, 6, 1, 6, skinD);
        rc(px, 3, 8, 1, 2, skinD);
        rc(px, 12, 8, 1, 2, skinD);
        final int eye = opaque(EYES[Math.max(0, Math.min(EYES.length - 1, lk.length > 10 ? lk[10] : 1))]);
        rc(px, 6, 8, 1, 2, eye);
        rc(px, 9, 8, 1, 2, eye);
        dot(px, 6, 8, mul(eye, 1.35f));
        dot(px, 9, 8, mul(eye, 1.35f));
        rc(px, 7, 11, 2, 1, mul(skin, 0.68f));
        dot(px, 5, 10, mul(skin, 1.05f) | 0xFF000000);
        // front hair
        switch (lk[1]) {
            case 0:
                rc(px, 4, 4, 8, 3, hair);
                dot(px, 4, 4, 0);
                dot(px, 11, 4, 0);
                rc(px, 4, 7, 1, 2, hair);
                rc(px, 11, 7, 1, 2, hairD);
                rc(px, 5, 4, 3, 1, hairL);
                break;
            case 1:
                rc(px, 4, 4, 8, 3, hair);
                dot(px, 4, 4, 0);
                dot(px, 11, 4, 0);
                rc(px, 5, 3, 6, 1, hair);
                rc(px, 6, 2, 4, 1, hair);
                rc(px, 7, 1, 2, 1, hair);
                rc(px, 4, 7, 1, 2, hair);
                rc(px, 11, 7, 1, 2, hairD);
                rc(px, 6, 3, 2, 1, hairL);
                break;
            case 2:
                rc(px, 4, 4, 8, 3, hair);
                dot(px, 4, 4, 0);
                dot(px, 11, 4, 0);
                rc(px, 5, 4, 3, 1, hairL);
                rc(px, 4, 7, 1, 6, hair);
                rc(px, 11, 7, 1, 6, hairD);
                break;
            case 3:
                rc(px, 7, 0, 2, 7, hair);
                rc(px, 8, 0, 1, 7, hairD);
                rc(px, 7, 0, 1, 3, hairL);
                break;
            case 4:
                rc(px, 4, 4, 8, 3, hair);
                dot(px, 4, 4, 0);
                dot(px, 11, 4, 0);
                rc(px, 4, 7, 1, 2, hair);
                rc(px, 11, 7, 1, 2, hairD);
                rc(px, 6, 1, 4, 3, hair);
                dot(px, 6, 1, 0);
                dot(px, 9, 1, 0);
                rc(px, 7, 1, 1, 1, hairL);
                dot(px, 7, 4, 0xFFD2463E);
                break;
            case 7:
                rc(px, 4, 4, 8, 3, hair);
                dot(px, 4, 4, 0);
                dot(px, 11, 4, 0);
                rc(px, 5, 3, 3, 1, hair);
                rc(px, 9, 3, 2, 1, hair);
                dot(px, 6, 2, hair);
                dot(px, 9, 2, hair);
                dot(px, 11, 3, hairD);
                rc(px, 4, 7, 3, 1, hair);
                rc(px, 4, 8, 1, 1, hair);
                rc(px, 11, 7, 1, 2, hairD);
                dot(px, 5, 4, hairL);
                dot(px, 6, 3, hairL);
                dot(px, 8, 4, hairL);
                dot(px, 10, 4, hairD);
                break;
            case 6:
                rc(px, 3, 3, 10, 4, hair);
                rc(px, 12, 3, 1, 4, hairD);
                rc(px, 4, 7, 1, 2, hair);
                rc(px, 11, 7, 1, 2, hairD);
                rc(px, 5, 3, 3, 1, hairL);
                break;
            default:
                dot(px, 5, 6, mul(skin, 1.12f));
                break;
        }
        // face things
        switch (lk[7]) {
            case 1:
                rc(px, 5, 7, 6, 1, dark);
                rc(px, 5, 8, 2, 2, 0xCCCFE8FF);
                rc(px, 9, 8, 2, 2, 0xCCCFE8FF);
                rc(px, 5, 8, 1, 3, dark);
                rc(px, 10, 8, 1, 3, dark);
                rc(px, 7, 8, 2, 1, dark);
                rc(px, 6, 8, 1, 2, eye);
                rc(px, 9, 8, 1, 2, eye);
                break;
            case 2:
                rc(px, 4, 8, 8, 2, 0xFF14141C);
                dot(px, 5, 8, 0xFF5A5A72);
                dot(px, 9, 8, 0xFF5A5A72);
                break;
            case 4:
                rc(px, 4, 3, 8, 1, dark);
                rc(px, 3, 4, 1, 5, dark);
                rc(px, 12, 4, 1, 5, dark);
                rc(px, 2, 8, 2, 4, 0xFF3A3A4A);
                rc(px, 12, 8, 2, 4, 0xFF3A3A4A);
                rc(px, 2, 9, 1, 2, 0xFF55A8FF);
                rc(px, 13, 9, 1, 2, 0xFF55A8FF);
                break;
            case 5:
                rc(px, 4, 7, 8, 1, dark);
                rc(px, 9, 8, 2, 2, dark);
                break;
            default:
                break;
        }
        // hats
        switch (lk[6]) {
            case 1:
                rc(px, 4, 2, 8, 4, 0xFFC83A3A);
                dot(px, 4, 2, 0);
                dot(px, 11, 2, 0);
                rc(px, 3, 5, 10, 1, 0xFF8A2428);
                rc(px, 5, 2, 3, 1, 0xFFE06A6A);
                dot(px, 8, 3, white);
                break;
            case 2:
                rc(px, 4, 2, 8, 4, 0xFF3A6FD8);
                dot(px, 4, 2, 0);
                dot(px, 11, 2, 0);
                rc(px, 4, 5, 8, 1, 0xFF2A4EA0);
                rc(px, 7, 0, 2, 2, white);
                rc(px, 5, 3, 3, 1, 0xFF6A9AF0);
                break;
            case 3:
                rc(px, 4, 3, 8, 3, gold);
                rc(px, 4, 2, 1, 1, gold);
                rc(px, 7, 1, 2, 2, gold);
                rc(px, 11, 2, 1, 1, gold);
                rc(px, 4, 5, 8, 1, goldD);
                dot(px, 5, 4, 0xFFD23A3A);
                dot(px, 10, 4, 0xFF3A8AE0);
                rc(px, 7, 3, 2, 2, 0xFF3AC878);
                rc(px, 5, 3, 1, 1, 0xFFFFE890);
                break;
            case 4:
                rc(px, 3, 5, 10, 1, 0xFF6A3AA8);
                rc(px, 5, 4, 6, 1, 0xFF7A48C0);
                rc(px, 5, 3, 5, 1, 0xFF7A48C0);
                rc(px, 6, 2, 4, 1, 0xFF7A48C0);
                rc(px, 7, 1, 3, 1, 0xFF7A48C0);
                rc(px, 9, 0, 2, 1, 0xFF7A48C0);
                rc(px, 5, 4, 6, 1, 0xFF4E2A82);
                dot(px, 7, 3, gold);
                dot(px, 9, 2, gold);
                break;
            case 5:
                rc(px, 4, 5, 8, 1, 0xFFD2463E);
                rc(px, 11, 5, 2, 2, 0xFFD2463E);
                dot(px, 12, 7, 0xFF9A2E2E);
                break;
            case 6:
                rc(px, 5, 0, 6, 5, 0xFF1E1E26);
                rc(px, 3, 5, 10, 1, 0xFF1E1E26);
                rc(px, 5, 3, 6, 1, 0xFFC83A3A);
                rc(px, 5, 0, 1, 3, 0xFF3C3C4C);
                break;
            default:
                break;
        }
        return outline(px);
    }
}
