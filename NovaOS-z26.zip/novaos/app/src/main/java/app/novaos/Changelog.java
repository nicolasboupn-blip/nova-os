package app.novaos;

import android.app.AlertDialog;

/** What changed in each version, and a one-time "what's new" popup after an update. */
final class Changelog {
    private Changelog() {}

    static final String TEXT =
            "3.7  The Coin Shop\n"
            + " - My character: a pixel art figure of you. Skin, hair, tops, hats, glasses, capes, shoes. Dress him with coins (Shop page or long-press the wizard)\n"
            + " - Double coins now comes in 1 hour (150), 1 day (3000) and 1 week (20000)\n"
            + " - Settings > Coin Shop, or long-press the wizard\n"
            + " - Double-coins potion, quest re-roll, streak shields, fireworks, dragon treats, mystery chest\n"
            + " - Titles from Squire to Emperor, pet hats, 6 premium colour themes\n"
            + " - The bank: save coins and earn 2% a day\n"
            + " - New SHOP page on the status panel with a free daily lucky spin\n"
            + " - Your name on the home screen under the date: elegant, graffiti or neon (Settings > Your name on home)\n"
            + " - New MAP page on the status panel: tap LOCATE to see where you are (OpenStreetMap, nothing saved)\n"
            + " - Castle visitors (from castle stage 2): a knight pays tribute, a merchant sells shop items at 40% off, a thief steals coins unless you tap him in time\n\n"
            + "3.6  New dragon, new pig\n"
            + " - Ember redrawn: bat wings that flap, sleeping and awake poses, fire, 8 colours\n"
            + " - He carries the roast pig to you in his claws, and the pig has a new look\n"
            + " - The extra towers and the sword are gone\n"
            + " - Admin only: Ember can coil around the main tower\n\n"
            + "3.5  The castle update\n"
            + " - Castle workshop: 10 upgrades (water wheel, lava, sword and banner of your country, towers, dragon, styles)\n"
            + " - Ember the dragon grows up, breathes fire, talks, travels for days, brings roast pigs\n"
            + " - Wizard wardrobe: robes and staff orbs. Second pet at stage 7.\n"
            + " - Long-press the wizard: jokes, riddles, fortune, 8-ball, spells, lesson of the day\n"
            + " - 4 new games: fishing, horse race, treasure map, word of the day\n"
            + " - To-do + habits and a focus timer on the home panel\n"
            + " - Daily login bonus with a streak, sound volume, night tint, reduce motion, left-handed mode\n"
            + " - Backup and restore, health check, safe mode, admin panel\n\n"
            + "3.3  Pets, surprises, quests, critters, pranks, wizard reactions\n"
            + "3.2  Wizard suggestions\n"
            + "3.1  Battery saver\n"
            + "3.0  Gallery and castle";

    static void show(NovaActivity host) {
        new AlertDialog.Builder(host).setTitle("What's new in NOVA " + Theme.OS_VERSION)
                .setMessage(TEXT).setPositiveButton("Nice", null).show();
    }

    static void showIfNew(NovaActivity host) {
        if (Prefs.getInt("setup_done", 0) == 0) {
            return;
        }
        String seen = Prefs.getString("whatsnew", "");
        if (!seen.equals(Theme.OS_VERSION)) {
            Prefs.putString("whatsnew", Theme.OS_VERSION);
            if (!seen.isEmpty()) {
                show(host);
            }
        }
    }
}
