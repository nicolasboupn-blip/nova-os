package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Surprises on the home screen. Now and then something happens: a shooting star crosses the sky, a treasure chest drops
 * in, or the wizard finds a golden coin. Tap it in time for coins. Touches pass straight through when nothing is there.
 */
final class EventLayer extends View {
    private static final int STAR = 0, CHEST = 1, COIN = 2, PIG = 3;

    private static final class Ev {
        int type;
        float x, y, vx, vy, age, life;
        boolean opened;
        float openedAt;
        int reward;
    }

    private static final class Bit {
        float x, y, vx, vy, age;
        int color;
    }

    private final NovaActivity host;
    private final Paint p = new Paint();
    private final Random rnd = new Random();
    private final List<Ev> events = new ArrayList<>();
    private final List<Bit> bits = new ArrayList<>();
    private final float d;
    private long last = System.nanoTime();
    private final Runnable spawn = new Runnable() {
        @Override
        public void run() {
            if (!isAttachedToWindow()) {
                return;
            }
            if (Prefs.eventsOn() && !Saver.on() && host.homeIdle() && events.isEmpty()) {
                spawnOne();
            }
            postDelayed(this, 80000 + rnd.nextInt(140000));
        }
    };

    EventLayer(NovaActivity host) {
        super(host);
        this.host = host;
        d = host.getResources().getDisplayMetrics().density;
        setClickable(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        host.eventLayer = this;
        postDelayed(spawn, 40000 + rnd.nextInt(60000));
    }

    /** Ember's delivery: a whole roast pig drops from the sky. Tap it for coins and happy pets. */
    void dropPig() {
        float w = getWidth();
        if (w <= 0) {
            return;
        }
        Ev e = new Ev();
        e.type = PIG;
        e.x = w * (0.3f + rnd.nextFloat() * 0.4f);
        e.y = -d * 40;
        e.life = 30f;
        e.reward = 60 + rnd.nextInt(60);
        events.add(e);
        Sfx.play(Sfx.BLIP);
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (host.eventLayer == this) {
            host.eventLayer = null;
        }
        removeCallbacks(spawn);
        super.onDetachedFromWindow();
    }

    private int forceType = -1;

    /** Admin: make an event appear now. 0 star, 1 chest, 2 coin. */
    void spawnNow(int type) {
        forceType = type;
        spawnOne();
    }

    private void spawnOne() {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0) {
            return;
        }
        int pick = forceType >= 0 ? forceType : rnd.nextInt(3);
        forceType = -1;
        WizardView wiz = host.wizardView();
        boolean wizOut = wiz != null && !host.wizInside;
        if (pick == COIN && !wizOut) {
            pick = rnd.nextBoolean() ? STAR : CHEST;
        }
        Ev e = new Ev();
        e.type = pick;
        e.reward = pick == STAR ? 15 + rnd.nextInt(35) : pick == CHEST ? 40 + rnd.nextInt(90) : 20 + rnd.nextInt(20);
        if (pick == STAR) {
            e.x = w * (0.55f + rnd.nextFloat() * 0.45f);
            e.y = h * 0.04f;
            e.vx = -w * 0.34f;
            e.vy = h * 0.13f;
            e.life = 3.2f;
        } else if (pick == CHEST) {
            e.x = w * (0.15f + rnd.nextFloat() * 0.7f);
            e.y = -d * 40;
            e.vy = 0;
            e.life = 14f;
        } else {
            e.x = wiz.getTranslationX() + wiz.getWidth() / 2f + (rnd.nextBoolean() ? -1 : 1) * d * 50;
            e.y = wiz.getTranslationY() + d * 30;
            e.life = 11f;
            wiz.say("Look! A golden coin!");
        }
        events.add(e);
        Sfx.play(Sfx.BLIP);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (events.isEmpty()) {
            return false;
        }
        if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
            return true;
        }
        if (ev.getActionMasked() != MotionEvent.ACTION_DOWN) {
            return true;
        }
        for (Ev e : events) {
            float r = (e.type == STAR ? 62 : 48) * d;
            float cy = e.type == CHEST ? e.y - d * 14 : e.y;
            if (e.type == PIG) {
                r = 70 * d;
            }
            if (!e.opened && Math.hypot(ev.getX() - e.x, ev.getY() - cy) < r) {
                catchIt(e);
                return true;
            }
        }
        return false;
    }

    private void catchIt(Ev e) {
        e.opened = true;
        e.openedAt = e.age;
        e.reward = Coins.earn(e.reward);
        Sfx.play(Sfx.COIN);
        host.buzz(20);
        Quests.event(host, "event");
        int[] cols = {0xFFFFD84D, 0xFFFFFFFF, Theme.ACCENT, 0xFFFF9A3D};
        for (int i = 0; i < 26; i++) {
            Bit b = new Bit();
            b.x = e.x;
            b.y = e.y;
            double a = rnd.nextDouble() * Math.PI * 2;
            float v = (60 + rnd.nextInt(220)) * d;
            b.vx = (float) Math.cos(a) * v;
            b.vy = (float) Math.sin(a) * v - 80 * d;
            b.color = cols[rnd.nextInt(cols.length)];
            bits.add(b);
        }
        if (e.type == PIG) {
            Prefs.putInt("pet_food", 100);
            Prefs.putInt("pet_joy", 100);
            host.wizardSay("Roast pig! +" + e.reward + " coins and the pets are stuffed.");
            return;
        }
        host.wizardSay("+" + e.reward + " coins!");
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        p.setStyle(Paint.Style.FILL);
        float floor = getHeight() * 0.52f;
        for (int i = events.size() - 1; i >= 0; i--) {
            Ev e = events.get(i);
            e.age += dt;
            if (e.age > e.life || (e.opened && e.age - e.openedAt > 0.6f)) {
                events.remove(i);
                continue;
            }
            if (e.type == STAR) {
                e.x += e.vx * dt;
                e.y += e.vy * dt;
                drawStar(c, e);
            } else if (e.type == PIG) {
                e.vy += 900 * d * dt;
                e.y += e.vy * dt;
                if (e.y > floor) {
                    e.y = floor;
                    e.vy = -e.vy * 0.3f;
                    if (Math.abs(e.vy) < 60 * d) {
                        e.vy = 0;
                    }
                }
                drawPig(c, e);
            } else if (e.type == CHEST) {
                e.vy += 900 * d * dt;
                e.y += e.vy * dt;
                if (e.y > floor) {
                    e.y = floor;
                    e.vy = -e.vy * 0.38f;
                    if (Math.abs(e.vy) < 60 * d) {
                        e.vy = 0;
                    }
                }
                drawChest(c, e);
            } else {
                drawCoin(c, e);
            }
        }
        for (int i = bits.size() - 1; i >= 0; i--) {
            Bit b = bits.get(i);
            b.age += dt;
            if (b.age > 1.0f) {
                bits.remove(i);
                continue;
            }
            b.vy += 500 * d * dt;
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            p.setColor((b.color & 0x00FFFFFF) | ((int) (255 * (1f - b.age)) << 24));
            c.drawRect(b.x, b.y, b.x + 4 * d, b.y + 4 * d, p);
        }
        if (!events.isEmpty() || !bits.isEmpty()) {
            postInvalidateOnAnimation();
        }
    }

    private void drawStar(Canvas c, Ev e) {
        // a tail of fading squares behind it
        for (int i = 14; i >= 1; i--) {
            float k = i / 14f;
            p.setColor(((int) (200 * (1f - k)) << 24) | 0xFFE6A0);
            float s = (1f - k * 0.7f) * 5 * d;
            float tx = e.x - e.vx * 0.045f * k * 6f / 1.2f;
            float ty = e.y - e.vy * 0.045f * k * 6f / 1.2f;
            c.drawRect(tx - s / 2, ty - s / 2, tx + s / 2, ty + s / 2, p);
        }
        p.setColor(0x44FFE6A0);
        c.drawCircle(e.x, e.y, 18 * d, p);
        p.setColor(0xFFFFF4C0);
        c.drawRect(e.x - 8 * d, e.y - 2 * d, e.x + 8 * d, e.y + 2 * d, p);
        c.drawRect(e.x - 2 * d, e.y - 8 * d, e.x + 2 * d, e.y + 8 * d, p);
        p.setColor(0xFFFFFFFF);
        c.drawRect(e.x - 3 * d, e.y - 3 * d, e.x + 3 * d, e.y + 3 * d, p);
    }

    private void drawChest(Canvas c, Ev e) {
        float s = 5 * d;
        float x = e.x - 6 * s / 2f;
        float y = e.y - 4 * s;
        float pulse = 0.5f + 0.5f * (float) Math.sin(e.age * 5f);
        if (!e.opened) {
            p.setColor(((int) (70 + 60 * pulse) << 24) | 0xFFD84D);
            c.drawCircle(e.x, e.y - 2 * s, 7 * s, p);
        }
        p.setColor(0xFF7A4A22);
        c.drawRect(x, y + 2 * s, x + 6 * s, y + 4 * s, p);                 // box
        p.setColor(e.opened ? 0xFFFFD84D : 0xFF9A5E2A);
        c.drawRect(x, y + (e.opened ? 0 : 0), x + 6 * s, y + 2 * s, p);    // lid (gold glow when open)
        p.setColor(0xFFE0B040);
        c.drawRect(x, y + 2 * s, x + 6 * s, y + 2.4f * s, p);              // band
        c.drawRect(x + 2.6f * s, y + 1.4f * s, x + 3.4f * s, y + 3 * s, p);// lock
        p.setColor(0xFF3A220E);
        c.drawRect(x, y + 3.6f * s, x + 6 * s, y + 4 * s, p);
    }

    private void drawCoin(Canvas c, Ev e) {
        float bob = (float) Math.sin(e.age * 4f) * 4 * d;
        float squash = Math.abs((float) Math.cos(e.age * 3f));
        p.setColor(0x55FFD84D);
        c.drawCircle(e.x, e.y + bob, 22 * d, p);
        p.setColor(0xFFFFC93C);
        float rx = Math.max(2 * d, 11 * d * squash);
        c.drawOval(e.x - rx, e.y + bob - 11 * d, e.x + rx, e.y + bob + 11 * d, p);
        p.setColor(0xFFFFEE9A);
        c.drawRect(e.x - rx * 0.4f, e.y + bob - 5 * d, e.x + rx * 0.4f, e.y + bob + 5 * d, p);
    }

    private static android.graphics.Bitmap pigBmp;
    private final android.graphics.Rect pigDst = new android.graphics.Rect();

    private void drawPig(Canvas c, Ev e) {
        if (pigBmp == null) {
            pigBmp = android.graphics.Bitmap.createBitmap(PigSprite.render(), PigSprite.W, PigSprite.H,
                    android.graphics.Bitmap.Config.ARGB_8888);
        }
        float s = Math.round(2.4f * d);
        float pw = PigSprite.W * s;
        float ph = PigSprite.H * s;
        float pulse = 0.5f + 0.5f * (float) Math.sin(e.age * 5f);
        if (!e.opened) {
            p.setColor(((int) (40 + 50 * pulse) << 24) | 0xFFB04D);
            c.drawCircle(e.x, e.y - ph / 2f, pw * 0.62f, p);
        }
        float wob = e.opened ? 0f : (float) Math.sin(e.age * 6f) * 1.5f * d;
        pigDst.set(Math.round(e.x - pw / 2f), Math.round(e.y - ph + wob), Math.round(e.x + pw / 2f), Math.round(e.y + wob));
        p.setAlpha(255);
        c.drawBitmap(pigBmp, null, pigDst, p);
        // steam rising from the roast
        for (int i = 0; i < 3; i++) {
            float k = (e.age * 0.8f + i * 0.33f) % 1f;
            p.setColor(((int) (130 * (1f - k)) << 24) | 0xFFFFFF);
            float sx = e.x - pw * 0.22f + i * pw * 0.2f + (float) Math.sin(e.age * 3 + i) * 2 * d;
            float sy = e.y - ph - k * 22 * d;
            c.drawRect(sx, sy, sx + 3 * d, sy + 6 * d, p);
        }
    }
}
