package app.novaos;

/** The play coins shared by the whole casino. Just for fun, no real money. */
final class Coins {
    private Coins() {}

    static int get() {
        return Prefs.getInt("slot_coins", 100);
    }

    /** Coins you earn (not casino winnings): doubled while a boost potion is active. */
    static int earn(int n) {
        if (n > 0 && Shop.boostMinutes() > 0) {
            n *= 2;
        }
        add(n);
        return n;
    }

    static void add(int n) {
        Prefs.putInt("slot_coins", Math.max(0, get() + n));
    }
}
