# NOVA Net server

The server behind NOVA Net (accounts, friends, chats and ranklists). One file, no dependencies: it needs only
**Python 3.8+** (standard library). Messages and accounts live in a single SQLite file next to it.

NOVA Net is off until someone types this server's address into the app (Settings > NOVA NET).
The address is never built into the app.

## 1. Run it

    python3 server.py                       # listens on 127.0.0.1:8080, database nova_net.db
    python3 server.py --port 9000 --db /data/nova.db

Check it: open `http://127.0.0.1:8080/` and you should see `{"name":"NOVA Net", ...}`.

## 2. Put HTTPS in front (required)

Android blocks plain `http://`, and passwords must never travel unencrypted. Use one of:

* **Cloudflare Tunnel** (no open ports, works from a home PC or Raspberry Pi):
  `cloudflared tunnel --url http://127.0.0.1:8080` gives a temporary `https://....trycloudflare.com` address.
  For a permanent address create a named tunnel on a domain you own.
* **Caddy** on a small VPS: a two line `Caddyfile`:
  `chat.example.com { reverse_proxy 127.0.0.1:8080 }` (certificates are automatic).

Start the server with **`--proxy`** behind a proxy, so rate limits see each visitor's real address
(`X-Forwarded-For` / `CF-Connecting-IP`). Do not use `--proxy` when the server is exposed directly.

## 3. Use it

* **Android:** NOVA > Settings > NOVA NET, type the address, create an account.
* **iPhone / any browser:** open `https://your-address/app`, create an account or log in. On iPhone tap Share >
  *Add to Home Screen* and it behaves like an app. The web version chats and shows ranklists; the numbers on the
  ranklists (coins, castle stage, streak, quests, cosmetics) come from the Android app.

## Email (optional)

Without email settings every account counts as verified immediately and password reset is off.
To send confirmation codes and reset codes, set these before starting:

    NOVA_SMTP_HOST=smtp.example.com NOVA_SMTP_PORT=587 NOVA_SMTP_USER=you NOVA_SMTP_PASS=secret \
    NOVA_SMTP_FROM="NOVA Net <no-reply@example.com>" python3 server.py

Keep passwords in the environment (or an `.env` file that stays out of git), never in the code.

## Owner tools

    python3 server.py --stats                 # users, chats, messages
    python3 server.py --reports               # latest reported messages
    python3 server.py --ban USER              # ban (they can no longer use the server)
    python3 server.py --unban USER
    python3 server.py --delete-message ID

Set `NOVA_LOG=1` to log requests.

## What it stores and rules

* Email, username, password (only a salted scrypt hash), messages, friend links, blocks, reports and the stats the app
  reports. Emails are never shown to other users. Deleting an account in the app removes it.
* Sessions last 90 days. Passwords need 8+ characters.
* Chats are **not end-to-end encrypted**: the server owner can read them in the database. Say so to your friends.
* Messages: 500 characters, 25 per minute. Friends and groups only (no strangers can message you). Groups hold 30
  people and a person can own 8. Blocking hides someone's messages and requests. Reports go to `--reports`.
* Ranklists: all-time numbers never go down. A phone that used admin mode, or a jump of more than 400000 coins at once,
  is left off the lists. Players can hide themselves.
* Back up the `.db` file (copy it while the server is stopped, or use `sqlite3 nova_net.db ".backup copy.db"`).
  The `.db` files are in `.gitignore`; never commit them.
