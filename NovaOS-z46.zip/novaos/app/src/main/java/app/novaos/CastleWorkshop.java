package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** The castle workshop: buy the ten upgrades, then style the castle, dress the wizard and look after the dragon. */
final class CastleWorkshop extends FrameLayout implements BackAware {
    private static final int[] PALETTE = {0xFFC0392B, 0xFFE67E22, 0xFFF1C40F, 0xFF27AE60, 0xFF16A085, 0xFF2980B9,
        0xFF8E44AD, 0xFFEC407A, 0xFFFFFFFF, 0xFF111111};

    private final NovaActivity host;
    private final LinearLayout body;

    CastleWorkshop(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 18);
        body.setPadding(pad, Theme.dp(host, 40), pad, Theme.dp(host, 60));
        sv.addView(body);
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        build();
    }

    static void open(NovaActivity host) {
        host.showOverlay(new CastleWorkshop(host));
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView head(String s) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, Theme.dp(host, 20), 0, Theme.dp(host, 6));
        return t;
    }

    private TextView chip(String s, boolean on, final Runnable r) {
        TextView t = text(s, 11f, on ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        t.setPadding(Theme.dp(host, 11), Theme.dp(host, 8), Theme.dp(host, 11), Theme.dp(host, 8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout wrap() {
        LinearLayout l = new LinearLayout(host);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void flow(LinearLayout into, java.util.List<View> chips) {
        LinearLayout row = null;
        int used = 0;
        int max = host.getResources().getDisplayMetrics().widthPixels - Theme.dp(host, 36);
        for (View c : chips) {
            c.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int w = c.getMeasuredWidth() + Theme.dp(host, 8);
            if (row == null || used + w > max) {
                row = new LinearLayout(host);
                row.setPadding(0, 0, 0, Theme.dp(host, 6));
                into.addView(row);
                used = 0;
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Theme.dp(host, 6);
            row.addView(c, lp);
            used += w;
        }
    }

    private void build() {
        body.removeAllViews();
        int stage = Castle.stage();
        boolean adm = Castle.admin();
        TextView title = text("CASTLE WORKSHOP", 16f, Theme.TEXT);
        title.setLetterSpacing(0.2f);
        body.addView(title);
        body.addView(text("Coins: " + Coins.get() + "    Stage " + stage + " / 10"
                + (adm ? "    ADMIN: all free, tap any stage" : ""), 11f, Theme.DIM));

        body.addView(head("UPGRADES"));
        for (int i = 0; i < 10; i++) {
            final int n = i + 1;
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
            LinearLayout info = wrap();
            boolean owned = stage >= n;
            info.addView(text(n + ". " + Castle.NAMES[i], 13f, owned ? Theme.TEXT : n == stage + 1 ? Theme.TEXT : Theme.DIM));
            TextView d = text(Castle.INFO[i], 10f, Theme.DIM);
            info.addView(d);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
            String state = owned ? "OWNED" : n == stage + 1 ? "BUY " + Castle.COST[i] : adm ? "SET" : "LOCKED";
            TextView b = chip(state, n == stage + 1 || (adm && !owned), () -> {
                if (adm) {
                    Castle.setStage(host, n);
                    Sfx.play(Sfx.WIN);
                } else if (n == Castle.stage() + 1) {
                    String err = Castle.buyNext(host);
                    if (err != null) {
                        host.toast(err);
                        return;
                    }
                    host.wizardSay(Castle.NAMES[n - 1] + " unlocked!");
                } else {
                    return;
                }
                build();
            });
            if (owned && adm) {
                b.setOnClickListener(v -> {
                    Castle.setStage(host, n - 1);
                    build();
                });
                b.setText("OWNED (tap: sell)");
            }
            row.addView(b);
            body.addView(row);
        }

        if (stage >= 2) {
            body.addView(head("WHEEL"));
            LinearLayout w = wrap();
            java.util.List<View> cs = new java.util.ArrayList<>();
            cs.add(chip("WATER", !Castle.lava(), () -> {
                Prefs.putInt("cs_lava", 0);
                Castle.changed();
                build();
            }));
            cs.add(chip("LAVA", Castle.lava(), () -> {
                Prefs.putInt("cs_lava", 1);
                Castle.changed();
                build();
            }));
            flow(w, cs);
            body.addView(w);
        }

        if (stage >= 3) {
            body.addView(head("BANNER OF YOUR COUNTRY"));
            LinearLayout w = wrap();
            java.util.List<View> cs = new java.util.ArrayList<>();
            for (int i = 0; i < Castle.FLAG_NAMES.length; i++) {
                final int fi = i;
                cs.add(chip(Castle.FLAG_NAMES[i], Castle.flag() == i, () -> {
                    Prefs.putInt("cs_flag", fi);
                    Castle.changed();
                    build();
                }));
            }
            flow(w, cs);
            body.addView(w);
            if (Castle.flag() == Castle.FLAG_NAMES.length - 1) {
                body.addView(text("Custom: tap a colour box to change it", 10f, Theme.DIM));
                LinearLayout r = new LinearLayout(host);
                r.setPadding(0, Theme.dp(host, 6), 0, 0);
                String[] keys = {"cs_fc1", "cs_fc2", "cs_fc3"};
                int[] defs = {0xFFC0392B, 0xFFF1C40F, 0xFF2980B9};
                for (int k = 0; k < 3; k++) {
                    final String key = keys[k];
                    final int def = defs[k];
                    View sw = new View(host);
                    sw.setBackground(Theme.rounded(Prefs.getInt(key, def), 8f, host));
                    sw.setOnClickListener(v -> {
                        int cur = Prefs.getInt(key, def);
                        int idx = 0;
                        for (int j = 0; j < PALETTE.length; j++) {
                            if (PALETTE[j] == cur) {
                                idx = j + 1;
                            }
                        }
                        Prefs.putInt(key, PALETTE[idx % PALETTE.length]);
                        Castle.changed();
                        build();
                    });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Theme.dp(host, 46), Theme.dp(host, 34));
                    lp.rightMargin = Theme.dp(host, 8);
                    r.addView(sw, lp);
                }
                body.addView(r);
            }
        }

        if (stage >= 4) {
            body.addView(head("WIZARD'S WARDROBE"));
            body.addView(text("Robe", 10f, Theme.DIM));
            body.addView(wardrobe("robe", Castle.ROBES, Castle.ROBE_COST, "wz_robe", Castle.robe()));
            body.addView(text("Staff orb", 10f, Theme.DIM));
            body.addView(wardrobe("orb", Castle.ORBS, Castle.ORB_COST, "wz_orb", Castle.orb()));
        }

        if (stage >= 7) {
            body.addView(head("SECOND PET"));
            LinearLayout pp = wrap();
            PetPicker.build(host, pp, 1, () -> {
                host.syncWizard();
                build();
            });
            body.addView(pp);
        }

        if (stage >= 8) {
            body.addView(head("CASTLE STYLE"));
            LinearLayout w = wrap();
            java.util.List<View> cs = new java.util.ArrayList<>();
            for (int i = 0; i < Castle.BASE_STYLES; i++) {
                final int si = i;
                cs.add(chip(Castle.STYLES[i], Castle.style() == i, () -> {
                    Prefs.putInt("cs_style", si);
                    Castle.changed();
                    build();
                }));
            }
            flow(w, cs);
            body.addView(w);
        }

        {
            java.util.List<View> zs = new java.util.ArrayList<>();
            for (int i = 0; i < Zigzag.NAMES.length; i++) {
                if (!Zigzag.ownsCastle(i)) {
                    continue;
                }
                final int si = Zigzag.FIRST_STYLE + i;
                zs.add(chip(Zigzag.NAMES[i], Castle.style() == si, () -> {
                    Prefs.putInt("cs_style", si);
                    Castle.changed();
                    build();
                }));
            }
            if (!zs.isEmpty()) {
                body.addView(head("ZIGZAG CASTLE SKINS"));
                zs.add(0, chip("Normal", Castle.style() == 0, () -> {
                    Prefs.putInt("cs_style", 0);
                    Castle.changed();
                    build();
                }));
                LinearLayout zw = wrap();
                flow(zw, zs);
                body.addView(zw);
            }
        }

        if (Upgrades.has("decor")) {
            body.addView(head("DECORATIONS"));
            java.util.List<View> ds = new java.util.ArrayList<>();
            for (int i = 0; i < Upgrades.DECOR.length; i++) {
                final int di = i;
                ds.add(chip(Upgrades.DECOR[i], Upgrades.decor() == i, () -> {
                    Prefs.putInt("cs_decor", di);
                    build();
                }));
            }
            LinearLayout dw = wrap();
            flow(dw, ds);
            body.addView(dw);
        }

        if (stage >= 5) {
            body.addView(head("EMBER THE DRAGON"));
            int away = Castle.awayMinutes();
            body.addView(text(away > 0 ? "Away exploring. Back in " + (away >= 1440 ? away / 1440 + "d " + (away % 1440) / 60
                    + "h" : away / 60 + "h " + away % 60 + "m") + "." : Castle.locked()
                    ? "Locked on his perch by an admin." : stage < 9 ? "Growing up." : "At home.", 11f, Theme.TEXT));
            if (stage >= 10) {
                body.addView(text("Colour", 10f, Theme.DIM));
                LinearLayout w = wrap();
                java.util.List<View> cs = new java.util.ArrayList<>();
                for (int i = 0; i < Castle.DRAGON_COLORS.length; i++) {
                    final int ci = i;
                    cs.add(chip(Castle.DRAGON_COLORS[i], Castle.dragonColor() == i, () -> {
                        Prefs.putInt("dr_color", ci);
                        build();
                    }));
                }
                flow(w, cs);
                body.addView(w);
                LinearLayout w2 = wrap();
                java.util.List<View> acts = new java.util.ArrayList<>();
                acts.add(chip(Castle.pigReady() ? "ASK FOR A ROAST PIG" : "PIG IN A BIT", Castle.pigReady(), () -> {
                    if (!Castle.orderPig(host)) {
                        host.toast("Ember is busy or already brought one lately");
                    } else {
                        host.hideOverlay();
                    }
                }));
                if (adm) {
                    acts.add(chip("RECALL NOW", false, () -> {
                        Castle.recall();
                        build();
                    }));
                    acts.add(chip(Castle.locked() ? "UNLOCK" : "LOCK ON PERCH", Castle.locked(), () -> {
                        Castle.setLocked(!Castle.locked());
                        build();
                    }));
                    acts.add(chip("SEND AWAY 1 DAY", false, () -> {
                        Castle.sendAway(24);
                        build();
                    }));
                }
                flow(w2, acts);
                body.addView(w2);
            }
        }
        body.addView(text("\nThe wizard lives here. Tap the castle to open the door.", 10f, Theme.DIM));
    }

    private View wardrobe(final String kind, String[] names, int[] costs, final String key, int current) {
        LinearLayout w = wrap();
        java.util.List<View> cs = new java.util.ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean owned = Castle.owns(kind, i) || Castle.admin();
            String label = names[i] + (owned ? "" : " " + costs[i]);
            cs.add(chip(label, current == i, () -> {
                if (!Castle.owns(kind, idx) && !Castle.admin()) {
                    if (Coins.get() < costs[idx]) {
                        host.toast("You need " + costs[idx] + " coins");
                        return;
                    }
                    Coins.add(-costs[idx]);
                    Prefs.putInt("own_" + kind + idx, 1);
                    Sfx.play(Sfx.COIN);
                }
                Prefs.putInt(key, idx);
                Castle.changed();
                build();
            }));
        }
        flow(w, cs);
        return w;
    }
}
