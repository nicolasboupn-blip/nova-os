package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The PET page of the panel: your companion, how hungry and happy it is, and a way to feed and play with it. */
final class PetPage extends LinearLayout {
    private final NovaActivity host;
    private final Paint p = new Paint();
    private final int s;
    private long born = System.nanoTime();

    PetPage(NovaActivity host) {
        super(host);
        this.host = host;
        s = Math.max(3, Math.round(host.getResources().getDisplayMetrics().density * 3f));
        setOrientation(VERTICAL);
        refresh();
    }

    void refresh() {
        removeAllViews();
        int kind = Pets.kind();
        if (kind == Pets.NONE) {
            addView(label("No companion yet. Pick a dog, a cat or a parrot.", 12f, Theme.DIM));
            addView(button("CHOOSE", () -> PetPicker.dialog(host, this::refresh)));
            return;
        }
        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        View pic = new View(host) {
            @Override
            protected void onDraw(Canvas c) {
                float t = (System.nanoTime() - born) / 1e9f;
                int frame = (int) (t * 2.5f) % 2;
                if (Pets.kind() == Pets.PARROT) {
                    Pets.drawParrot(c, p, (getWidth() - 6 * s) / 2f, (getHeight() - 9 * s) / 2f, s, frame);
                } else {
                    Pets.drawPet(c, p, Pets.kind(), Pets.color(), (getWidth() - Pets.PW * s) / 2f,
                            (getHeight() - Pets.PH * s) / 2f, s, frame, false, Pets.joy() > 60, false);
                }
                if (isShown() && !Saver.on()) {
                    postInvalidateDelayed(300);
                }
            }
        };
        top.addView(pic, new LayoutParams(Pets.PW * s + s * 3, 15 * s));
        LinearLayout info = new LinearLayout(host);
        info.setOrientation(VERTICAL);
        info.setPadding(Theme.dp(host, 8), 0, 0, 0);
        info.addView(label(Pets.label().toUpperCase(), 12f, Theme.ACCENT));
        info.addView(bar("HUNGER", Pets.food()));
        info.addView(bar("JOY", Pets.joy()));
        top.addView(info, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        addView(top);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, Theme.dp(host, 6), 0, 0);
        row.addView(button("FEED ·10", () -> {
            if (Pets.feed()) {
                Sfx.play(Sfx.COIN);
                host.wizardSay(Pets.kind() == Pets.DOG ? "Woof! Thank you." : Pets.kind() == Pets.CAT
                        ? "Purr..." : "Squawk! Tasty!");
            } else {
                host.toast("You need 10 coins");
            }
            refresh();
        }));
        row.addView(button("PLAY", () -> {
            Pets.bumpJoy(12);
            Sfx.play(Sfx.BLIP);
            Quests.event(host, "pet");
            refresh();
        }));
        addView(row);
    }

    private LinearLayout bar(String name, final int pct) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = label(name, 10f, Theme.DIM);
        r.addView(n, new LayoutParams(Theme.dp(host, 58), LayoutParams.WRAP_CONTENT));
        View b = new View(host) {
            @Override
            protected void onDraw(Canvas c) {
                p.setColor(0x33FFFFFF);
                c.drawRoundRect(0, 0, getWidth(), getHeight(), getHeight() / 2f, getHeight() / 2f, p);
                p.setColor(pct < 25 ? 0xFFFF5A5A : Theme.ACCENT);
                c.drawRoundRect(0, 0, getWidth() * pct / 100f, getHeight(), getHeight() / 2f, getHeight() / 2f, p);
            }
        };
        LayoutParams lp = new LayoutParams(0, Theme.dp(host, 7), 1f);
        lp.topMargin = Theme.dp(host, 4);
        lp.bottomMargin = Theme.dp(host, 4);
        r.addView(b, lp);
        return r;
    }

    private TextView label(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String s, final Runnable action) {
        TextView t = label(s, 12f, Theme.BG);
        t.setLetterSpacing(0.1f);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
        t.setPadding(Theme.dp(host, 20), Theme.dp(host, 9), Theme.dp(host, 20), Theme.dp(host, 9));
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(Theme.dp(host, 5), 0, Theme.dp(host, 5), 0);
        t.setLayoutParams(lp);
        return t;
    }
}
