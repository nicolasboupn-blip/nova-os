package app.novaos;

import android.view.Gravity;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** A treasure is buried on a 6x6 map. Dig and the map tells you hot or cold. Fewer digs, more coins. */
final class GameTreasure extends Game {
    private static final int N = 6;

    private final TextView[] cells = new TextView[N * N];
    private final TextView info;
    private final Random rnd = new Random();
    private int treasure;
    private int digs;
    private boolean over;

    GameTreasure(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(80), dp(20), dp(30));
        addView(col, new LayoutParams(-1, -1));
        info = label("", 13f, Theme.DIM);
        col.addView(info);
        GridLayout g = new GridLayout(host);
        g.setColumnCount(N);
        for (int i = 0; i < N * N; i++) {
            final int idx = i;
            TextView c = label("", 16f, Theme.TEXT);
            c.setBackground(Theme.rounded(0xFF3A2C1A, 8f, host));
            c.setClickable(true);
            c.setOnClickListener(v -> dig(idx));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = dp(50);
            lp.height = dp(50);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            g.addView(c, lp);
            cells[i] = c;
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2, -2);
        gp.topMargin = dp(20);
        col.addView(g, gp);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = dp(20);
        col.addView(button("NEW MAP", this::reset), bp);
        reset();
    }

    @Override
    String title() {
        return "TREASURE";
    }

    private void reset() {
        treasure = rnd.nextInt(N * N);
        digs = 0;
        over = false;
        for (TextView c : cells) {
            c.setText("");
            c.setBackground(Theme.rounded(0xFF3A2C1A, 8f, host));
        }
        info.setText("Find the treasure. BEST " + best("treasure", 0) + " coins");
    }

    private void dig(int i) {
        if (over || !cells[i].getText().toString().isEmpty()) {
            return;
        }
        digs++;
        if (i == treasure) {
            over = true;
            int prize = Math.max(5, 80 - digs * 8);
            Coins.earn(prize);
            cells[i].setText("💰");
            cells[i].setBackground(Theme.rounded(0xFF8A6A10, 8f, host));
            Sfx.play(Sfx.WIN);
            if (prize > best("treasure", 0)) {
                saveBest("treasure", prize);
            }
            info.setText("Found it in " + digs + " digs! +" + prize + " coins");
            return;
        }
        int dist = Math.abs(i / N - treasure / N) + Math.abs(i % N - treasure % N);
        String t = dist <= 1 ? "🔥" : dist <= 3 ? "♨" : dist <= 5 ? "❄" : "🧊";
        cells[i].setText(t);
        cells[i].setBackground(Theme.rounded(0xFF241A10, 8f, host));
        Sfx.play(Sfx.BLIP);
        info.setText("Digs: " + digs);
    }
}
