package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * Animated backgrounds that follow your accent colour: stars, rain, aurora, a retro grid and fireflies.
 * Draws only while it is on screen, at the screen's own pace, so it costs nothing when you are in another app.
 */
final class LiveWallpaper extends View {
    static final String[] NAMES = {"Off", "Stars", "Rain", "Aurora", "Grid", "Fireflies", "Now playing", "Nebula", "Ocean",
        "Petals"};
    /** Wallpapers from this number on come from the shop. */
    static final int BASE = 7;

    private final int mode;
    private final Context ctx;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Random rnd = new Random(7);
    private final float d;
    private final float[] px = new float[120];
    private final float[] py = new float[120];
    private final float[] ps = new float[120];
    private final float[] pz = new float[120];
    private long last;
    private float time;
    private float shoot = -1f;
    private float shootY;

    LiveWallpaper(Context c, int mode) {
        super(c);
        this.mode = mode;
        this.ctx = c;
        d = c.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        for (int i = 0; i < px.length; i++) {
            px[i] = rnd.nextFloat();
            py[i] = rnd.nextFloat();
            ps[i] = 0.3f + rnd.nextFloat();
            pz[i] = rnd.nextFloat() * 6.28f;
        }
    }

    private int accent(float alpha) {
        return (Theme.ACCENT & 0x00FFFFFF) | ((int) (Math.max(0f, Math.min(1f, alpha)) * 255) << 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        time += dt;
        float w = getWidth();
        float h = getHeight();
        switch (mode) {
            case 1:
                stars(c, w, h, dt);
                break;
            case 2:
                rain(c, w, h, dt);
                break;
            case 3:
                aurora(c, w, h);
                break;
            case 4:
                grid(c, w, h);
                break;
            case 6:
                nowPlaying(c, w, h, dt);
                break;
            case 7:
                nebula(c, w, h, dt);
                break;
            case 8:
                ocean(c, w, h);
                break;
            case 9:
                petals(c, w, h, dt);
                break;
            default:
                fireflies(c, w, h, dt);
                break;
        }
        if (isShown()) {
            postInvalidateOnAnimation();
        } else {
            last = 0;
        }
    }

    private void stars(Canvas c, float w, float h, float dt) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < px.length; i++) {
            py[i] += dt * 0.004f * ps[i];
            if (py[i] > 1f) {
                py[i] = 0f;
                px[i] = rnd.nextFloat();
            }
            float tw = 0.45f + 0.55f * (float) Math.sin(time * (0.8f + ps[i]) + pz[i]);
            float r = (0.6f + ps[i] * 1.1f) * d;
            p.setColor(i % 5 == 0 ? accent(0.25f * tw) : 0x00FFFFFF | ((int) (150 * tw) << 24));
            c.drawCircle(px[i] * w, py[i] * h, r * (i % 5 == 0 ? 2.6f : 1f), p);
            p.setColor(i % 5 == 0 ? accent(0.8f * tw) : 0x00FFFFFF | ((int) (230 * tw) << 24));
            c.drawCircle(px[i] * w, py[i] * h, r, p);
        }
        // a shooting star now and then
        if (shoot < 0f && rnd.nextFloat() < dt * 0.15f) {
            shoot = 0f;
            shootY = rnd.nextFloat() * 0.4f;
        }
        if (shoot >= 0f) {
            shoot += dt * 1.4f;
            float x = w * (1.1f - shoot * 1.3f);
            float y = h * (shootY + shoot * 0.35f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(2f * d);
            p.setColor(accent(0.9f * (1f - shoot)));
            c.drawLine(x, y, x + 70 * d, y - 22 * d, p);
            p.setColor(0x00FFFFFF | ((int) (255 * (1f - shoot)) << 24));
            c.drawLine(x, y, x + 24 * d, y - 8 * d, p);
            if (shoot > 1f) {
                shoot = -1f;
            }
        }
    }

    private void rain(Canvas c, float w, float h, float dt) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 90; i++) {
            int k = i % px.length;
            float speed = 0.5f + ps[k] * 0.9f;
            py[k] += dt * speed;
            px[k] -= dt * speed * 0.08f;
            if (py[k] > 1.05f) {
                py[k] = -0.05f;
                px[k] = rnd.nextFloat() * 1.1f;
            }
            if (px[k] < -0.05f) {
                px[k] += 1.1f;
            }
            float len = (14f + ps[k] * 22f) * d;
            float x = px[k] * w;
            float y = py[k] * h;
            p.setStrokeWidth((0.8f + ps[k] * 0.6f) * d);
            p.setColor(accent(0.15f + 0.35f * ps[k] / 1.3f));
            c.drawLine(x, y, x + len * 0.08f * 3f, y - len, p);
        }
    }

    private void aurora(Canvas c, float w, float h) {
        p.setStyle(Paint.Style.FILL);
        float[] hsv = new float[3];
        Color.colorToHSV(Theme.ACCENT, hsv);
        for (int band = 0; band < 4; band++) {
            float[] hh = {hsv[0] + band * 28f - 40f, hsv[1], Math.max(0.6f, hsv[2])};
            hh[0] = (hh[0] + 360f) % 360f;
            int col = Color.HSVToColor(hh);
            path.rewind();
            float baseY = h * (0.22f + 0.09f * band);
            float amp = h * 0.05f;
            path.moveTo(0, 0);
            for (int i = 0; i <= 24; i++) {
                float x = w * i / 24f;
                float y = baseY + amp * (float) Math.sin(i * 0.55 + time * (0.35 + band * 0.12) + band * 1.7)
                        + amp * 0.5f * (float) Math.sin(i * 1.3 - time * 0.5);
                path.lineTo(x, y);
            }
            path.lineTo(w, 0);
            path.close();
            // each ribbon fades out below its edge
            LinearGradient g = new LinearGradient(0, baseY - h * 0.25f, 0, baseY + h * 0.14f,
                    new int[] {0x00000000, (col & 0x00FFFFFF) | 0x00000000, (col & 0x00FFFFFF) | 0x66000000},
                    new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
            p.setShader(g);
            c.drawPath(path, p);
            p.setShader(null);
        }
    }

    /** Slow drifting clouds of colour with a few bright stars. */
    private final android.graphics.RadialGradient[] nebulaShaders = new android.graphics.RadialGradient[6];
    private int nebulaAccent;

    private void nebula(Canvas c, float w, float h, float dt) {
        p.setStyle(Paint.Style.FILL);
        if (nebulaShaders[0] == null || nebulaAccent != Theme.ACCENT) {
            // built once: unit-size gradients that are scaled when drawn, so no allocation per frame
            nebulaAccent = Theme.ACCENT;
            float[] hsv = new float[3];
            Color.colorToHSV(Theme.ACCENT, hsv);
            for (int i = 0; i < 6; i++) {
                float[] hh = {(hsv[0] + i * 38f) % 360f, 0.65f, 0.9f};
                int col = Color.HSVToColor(hh);
                nebulaShaders[i] = new android.graphics.RadialGradient(0f, 0f, 1f,
                        (col & 0x00FFFFFF) | 0x38000000, col & 0x00FFFFFF, Shader.TileMode.CLAMP);
            }
        }
        for (int i = 0; i < 6; i++) {
            float cx = w * (0.5f + 0.42f * (float) Math.sin(time * 0.07f * (1 + i * 0.3f) + i * 1.9f));
            float cy = h * (0.5f + 0.38f * (float) Math.cos(time * 0.05f * (1 + i * 0.2f) + i * 2.3f));
            float r = w * (0.55f + 0.12f * (float) Math.sin(time * 0.2f + i));
            c.save();
            c.translate(cx, cy);
            c.scale(r, r);
            p.setShader(nebulaShaders[i]);
            c.drawCircle(0f, 0f, 1f, p);
            p.setShader(null);
            c.restore();
        }
        for (int i = 0; i < 50; i++) {
            float tw = 0.4f + 0.6f * (float) Math.sin(time * (0.6f + ps[i]) + pz[i]);
            p.setColor(0x00FFFFFF | ((int) (200 * Math.max(0f, tw)) << 24));
            c.drawCircle(px[i] * w, py[i] * h, (0.5f + ps[i]) * d, p);
        }
    }

    /** Layers of slow waves in your accent colour. */
    private void ocean(Canvas c, float w, float h) {
        p.setStyle(Paint.Style.FILL);
        for (int layer = 0; layer < 5; layer++) {
            path.rewind();
            float base = h * (0.45f + 0.1f * layer);
            float amp = h * (0.012f + 0.004f * layer);
            path.moveTo(0, h);
            for (int i = 0; i <= 30; i++) {
                float x = w * i / 30f;
                float y = base + amp * (float) Math.sin(i * 0.4f + time * (0.5f + layer * 0.15f) + layer * 2f);
                path.lineTo(x, y);
            }
            path.lineTo(w, h);
            path.close();
            p.setColor(accent(0.07f + 0.04f * layer));
            c.drawPath(path, p);
        }
    }

    /** Petals drifting down and sideways. */
    private void petals(Canvas c, float w, float h, float dt) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 40; i++) {
            py[i] += dt * 0.035f * (0.5f + ps[i]);
            if (py[i] > 1.05f) {
                py[i] = -0.05f;
                px[i] = rnd.nextFloat();
            }
            float x = (px[i] + 0.04f * (float) Math.sin(time * 0.7f + pz[i])) * w;
            float y = py[i] * h;
            float s = (3f + 4f * ps[i]) * d;
            c.save();
            c.rotate((time * 40f * ps[i] + pz[i] * 57f) % 360f, x, y);
            p.setColor(accent(0.5f));
            c.drawOval(x - s, y - s * 0.55f, x + s, y + s * 0.55f, p);
            c.restore();
        }
    }

    private void grid(Canvas c, float w, float h) {
        float horizon = h * 0.52f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        // lines going to the vanishing point
        for (int i = -12; i <= 12; i++) {
            float xBottom = w / 2f + i * w * 0.2f;
            p.setColor(accent(0.30f));
            c.drawLine(w / 2f + i * w * 0.012f, horizon, xBottom, h, p);
        }
        // lines moving toward you
        float speed = (time * 0.35f) % 1f;
        for (int i = 0; i < 12; i++) {
            float t = (i + speed) / 12f;
            float y = horizon + (h - horizon) * t * t;
            p.setColor(accent(0.10f + 0.30f * t));
            c.drawLine(0, y, w, y, p);
        }
        // soft sun on the horizon
        p.setStyle(Paint.Style.FILL);
        LinearGradient sun = new LinearGradient(0, horizon - w * 0.22f, 0, horizon,
                accent(0.0f), accent(0.35f), Shader.TileMode.CLAMP);
        p.setShader(sun);
        c.drawCircle(w / 2f, horizon, w * 0.22f, p);
        p.setShader(null);
    }

    private void fireflies(Canvas c, float w, float h, float dt) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 40; i++) {
            float x = (px[i] + 0.06f * (float) Math.sin(time * 0.3f * ps[i] + pz[i])
                    + 0.04f * (float) Math.sin(time * 0.17f + i)) * w;
            float y = (py[i] + 0.05f * (float) Math.cos(time * 0.25f * ps[i] + pz[i] * 1.3f)
                    - ((time * 0.01f * ps[i]) % 1f)) * h;
            y = ((y % h) + h) % h;
            float glow = 0.5f + 0.5f * (float) Math.sin(time * (0.9f + ps[i]) + pz[i]);
            p.setColor(accent(0.12f * glow));
            c.drawCircle(x, y, 14 * d * ps[i], p);
            p.setColor(accent(0.35f * glow));
            c.drawCircle(x, y, 6 * d * ps[i], p);
            p.setColor(0x00FFFFFF | ((int) (230 * glow) << 24));
            c.drawCircle(x, y, 1.8f * d, p);
        }
    }

    // ---------------------------------------------------------------- now playing

    private static final int BARS = 28;
    private final float[] bars = new float[BARS];
    private final float[] level = new float[BARS];
    private volatile long realAt;
    private android.media.audiofx.Visualizer viz;
    private boolean playing;
    private String song = "";
    private long polled;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mode == 6) {
            startViz();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        stopViz();
        super.onDetachedFromWindow();
    }

    /** Tries the phone's real audio output. Needs the microphone permission; without it the beat is simulated. */
    private void startViz() {
        if (viz != null || ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            int[] range = android.media.audiofx.Visualizer.getCaptureSizeRange();
            android.media.audiofx.Visualizer v = new android.media.audiofx.Visualizer(0);
            v.setCaptureSize(Math.max(range[0], Math.min(range[1], 512)));
            v.setDataCaptureListener(new android.media.audiofx.Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(android.media.audiofx.Visualizer vz, byte[] wave, int rate) {
                }

                @Override
                public void onFftDataCapture(android.media.audiofx.Visualizer vz, byte[] fft, int rate) {
                    int n = fft.length / 2;
                    float total = 0f;
                    for (int i = 0; i < BARS; i++) {
                        int from = 1 + (int) ((n - 2) * Math.pow(i / (float) BARS, 2.0));
                        int to = Math.max(from + 1, 1 + (int) ((n - 2) * Math.pow((i + 1) / (float) BARS, 2.0)));
                        float m = 0f;
                        for (int k = from; k < Math.min(to, n); k++) {
                            float re = fft[2 * k];
                            float im = fft[2 * k + 1];
                            m = Math.max(m, (float) Math.sqrt(re * re + im * im));
                        }
                        level[i] = Math.min(1f, m / 90f);
                        total += level[i];
                    }
                    if (total > 0.05f) {
                        realAt = System.nanoTime();
                    }
                }
            }, android.media.audiofx.Visualizer.getMaxCaptureRate() / 2, false, true);
            v.setEnabled(true);
            viz = v;
        } catch (Throwable t) {
            viz = null;
        }
    }

    private void stopViz() {
        if (viz != null) {
            try {
                viz.setEnabled(false);
                viz.release();
            } catch (Throwable ignored) {
            }
            viz = null;
        }
    }

    private void nowPlaying(Canvas c, float w, float h, float dt) {
        long now = System.nanoTime();
        if (now - polled > 2_000_000_000L) {
            polled = now;
            android.media.session.MediaController mc = MusicHelper.controller(ctx);
            playing = MusicHelper.isPlaying(mc);
            song = mc != null && MusicHelper.active(mc)
                    ? (MusicHelper.artist(mc).isEmpty() ? "" : MusicHelper.artist(mc) + "  ·  ") + MusicHelper.title(mc)
                    : "";
            if (viz == null) {
                startViz();
            }
        }
        boolean real = playing && now - realAt < 1_500_000_000L;
        float phase = time * 112f / 60f;
        float pulse = (float) Math.pow(Math.max(0.0, Math.cos(phase * 6.2832)), 4.0);
        float sum = 0f;
        for (int i = 0; i < BARS; i++) {
            float target;
            if (real) {
                target = level[i];
            } else if (playing) {
                float n = 0.5f + 0.5f * (float) Math.sin(time * (1.7f + i * 0.13f) + i * 1.9f);
                target = (0.18f + 0.55f * n) * (0.55f + 0.45f * pulse) * (1f - 0.4f * i / BARS);
            } else {
                target = 0.05f + 0.03f * (float) Math.sin(time * 0.8f + i * 0.5f);
            }
            bars[i] += (target - bars[i]) * (target > bars[i] ? 0.55f : 0.14f);
            sum += bars[i];
        }
        float energy = sum / BARS;
        p.setStyle(Paint.Style.FILL);
        // a soft ring that breathes with the music
        p.setColor(accent(0.05f + 0.12f * energy));
        c.drawCircle(w / 2f, h * 0.42f, w * (0.26f + 0.22f * energy), p);
        p.setColor(accent(0.04f + 0.06f * energy));
        c.drawCircle(w / 2f, h * 0.42f, w * (0.40f + 0.30f * energy), p);
        // the bars, rising from the bottom with a glow under each one
        float slot = w / BARS;
        float maxH = h * 0.30f;
        for (int i = 0; i < BARS; i++) {
            float bh = Math.max(3f * d, bars[i] * maxH);
            float x = i * slot + slot * 0.5f;
            p.setColor(accent(0.10f));
            c.drawRoundRect(x - slot * 0.42f, h - bh - 4 * d, x + slot * 0.42f, h, 6 * d, 6 * d, p);
            p.setColor(accent(0.55f));
            c.drawRoundRect(x - slot * 0.22f, h - bh, x + slot * 0.22f, h, 4 * d, 4 * d, p);
        }
        if (!song.isEmpty()) {
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.MONOSPACE);
            p.setTextSize(12 * d);
            p.setColor(0x00FFFFFF | (110 << 24));
            String t = song.length() > 44 ? song.substring(0, 43) + "…" : song;
            c.drawText(t, w / 2f, h * 0.70f, p);
        }
    }
}
