package app.novaos;

/**
 * Ember, drawn in code: an original pixel-art dragon with a long neck, bat wings and a curling tail.
 * Pure Java (no Android classes) so the pictures can be checked on a desktop. Facing right.
 * The anchor (AX, AY) is the perch / the point under his belly.
 */
final class DragonSprite {
    static final int W = 76, H = 60, AX = 40, AY = 50;
    static final int ASLEEP = 0, AWAKE = 1, FLYING = 2;
    private static final int OX = 6, OY = 8;

    private final int[] px = new int[W * H];
    private final byte[] shadeV = new byte[W * H];      // body shading code per pixel: 0 none
    private int body, dark, light, belly, memb, memb2, bone, horn, line;
    private final int pose, frame;
    private final boolean open;
    private final float ws;                             // wing size 0.65 baby .. 1.15 adult
    private final boolean baby;

    private DragonSprite(int pose, int frame, boolean open, float ws, int bodyRgb) {
        this.pose = pose;
        this.frame = frame;
        this.open = open;
        this.ws = ws;
        this.baby = ws < 0.7f;
        body = 0xFF000000 | bodyRgb;
        dark = mul(body, 0.55f);
        light = add(mul(body, 1.22f), 26);
        belly = mix(body, 0xFFEBC878, 0.62f);
        memb = mix(mul(body, 0.50f), 0xFF4A4A9A, 0.50f);
        memb2 = add(memb, 22);
        bone = mul(body, 0.78f);
        horn = 0xFFE9E1C8;
        line = mul(body, 0.20f);
    }

    /** Renders one picture as ARGB pixels, W x H. */
    static int[] render(int pose, int frame, boolean openMouth, float wingScale, int bodyRgb) {
        DragonSprite d = new DragonSprite(pose, frame, openMouth, wingScale, bodyRgb & 0xFFFFFF);
        d.draw();
        return d.px;
    }

    // ------------------------------------------------------------------ colour helpers

    private static int ch(int c, int sh) {
        return (c >> sh) & 255;
    }

    private static int rgb(int r, int g, int b) {
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int mul(int c, float k) {
        return rgb((int) (ch(c, 16) * k), (int) (ch(c, 8) * k), (int) (ch(c, 0) * k));
    }

    private static int add(int c, int d) {
        return rgb(ch(c, 16) + d, ch(c, 8) + d, ch(c, 0) + d);
    }

    private static int mix(int a, int b, float t) {
        return rgb((int) (ch(a, 16) * (1 - t) + ch(b, 16) * t), (int) (ch(a, 8) * (1 - t) + ch(b, 8) * t),
                (int) (ch(a, 0) * (1 - t) + ch(b, 0) * t));
    }

    // ------------------------------------------------------------------ pixel primitives (design coordinates)

    private void dot(double x, double y, int col) {
        int ix = (int) Math.floor(x) + OX;
        int iy = (int) Math.floor(y) + OY;
        if (ix >= 0 && iy >= 0 && ix < W && iy < H) {
            px[iy * W + ix] = col;
        }
    }

    private void circle(double cx, double cy, double r, int col) {
        for (int y = (int) Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
            for (int x = (int) Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
                double dx = x + 0.5 - cx;
                double dy = y + 0.5 - cy;
                if (dx * dx + dy * dy <= r * r) {
                    dot(x, y, col);
                }
            }
        }
    }

    private void thickLine(double x0, double y0, double x1, double y1, double r, int col) {
        double len = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        int n = (int) Math.ceil(len * 2) + 1;
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            double x = x0 + (x1 - x0) * t;
            double y = y0 + (y1 - y0) * t;
            if (r <= 0.5) {
                dot(x, y, col);
            } else {
                circle(x, y, r, col);
            }
        }
    }

    private interface Shader {
        int at(int x, int y);
    }

    /** Fills a polygon. Returns the mask (design pixel grid) so edges can be outlined later. */
    private boolean[] polygon(double[][] p, Shader s) {
        boolean[] mask = new boolean[W * H];
        double minY = 1e9;
        double maxY = -1e9;
        for (double[] q : p) {
            minY = Math.min(minY, q[1]);
            maxY = Math.max(maxY, q[1]);
        }
        for (int y = (int) Math.floor(minY); y <= Math.ceil(maxY); y++) {
            double sy = y + 0.5;
            java.util.ArrayList<Double> xs = new java.util.ArrayList<>();
            for (int i = 0; i < p.length; i++) {
                double[] a = p[i];
                double[] b = p[(i + 1) % p.length];
                if ((a[1] <= sy && b[1] > sy) || (b[1] <= sy && a[1] > sy)) {
                    xs.add(a[0] + (sy - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
                }
            }
            java.util.Collections.sort(xs);
            for (int k = 0; k + 1 < xs.size(); k += 2) {
                for (int x = (int) Math.round(xs.get(k) - 0.5); x <= (int) Math.round(xs.get(k + 1) - 0.5); x++) {
                    int ix = x + OX;
                    int iy = y + OY;
                    if (ix >= 0 && iy >= 0 && ix < W && iy < H) {
                        px[iy * W + ix] = s.at(x, y);
                        mask[iy * W + ix] = true;
                    }
                }
            }
        }
        return mask;
    }

    private void edge(boolean[] mask, int col) {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (!mask[y * W + x]) {
                    continue;
                }
                boolean border = x == 0 || y == 0 || x == W - 1 || y == H - 1 || !mask[y * W + x - 1]
                        || !mask[y * W + x + 1] || !mask[(y - 1) * W + x] || !mask[(y + 1) * W + x];
                if (border) {
                    px[y * W + x] = col;
                }
            }
        }
    }

    // ------------------------------------------------------------------ the body

    /** spine point: x, y, radius, belly-lit (1) or dark underside (0) */
    private void spine(double[][] pts) {
        // paint circles along the polyline, remembering each pixel's vertical position inside its circle
        boolean[] filled = new boolean[W * H];
        double[] vv = new double[W * H];
        double[] bl = new double[W * H];
        for (int i = 0; i + 1 < pts.length; i++) {
            double[] a = pts[i];
            double[] b = pts[i + 1];
            double len = Math.hypot(b[0] - a[0], b[1] - a[1]);
            int n = (int) Math.ceil(len * 2) + 1;
            for (int s = 0; s <= n; s++) {
                double t = s / (double) n;
                double cx = a[0] + (b[0] - a[0]) * t;
                double cy = a[1] + (b[1] - a[1]) * t;
                double r = a[2] + (b[2] - a[2]) * t;
                double lit = a[3] + (b[3] - a[3]) * t;
                for (int y = (int) Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
                    for (int x = (int) Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
                        double dx = x + 0.5 - cx;
                        double dy = y + 0.5 - cy;
                        if (dx * dx + dy * dy <= r * r) {
                            int ix = x + OX;
                            int iy = y + OY;
                            if (ix >= 0 && iy >= 0 && ix < W && iy < H) {
                                filled[iy * W + ix] = true;
                                vv[iy * W + ix] = dy / r;
                                bl[iy * W + ix] = lit;
                            }
                        }
                    }
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (!filled[y * W + x]) {
                    continue;
                }
                double v = vv[y * W + x];
                boolean chk = ((x + y) & 1) == 0;
                int c;
                if (v < -0.62) {
                    c = light;
                } else if (v < -0.38) {
                    c = chk ? light : body;
                } else if (v < 0.22) {
                    c = body;
                } else if (v < 0.42) {
                    c = chk ? body : (bl[y * W + x] > 0.5 ? belly : dark);
                } else {
                    c = bl[y * W + x] > 0.5 ? belly : dark;
                }
                px[y * W + x] = c;
            }
        }
    }

    private void limb(double x0, double y0, double kx, double ky, double x1, double y1, int col, int claw) {
        thickLine(x0, y0, kx, ky, 1.5, col);
        thickLine(kx, ky, x1, y1, 1.1, col);
        dot(x1 + 1, y1, claw);
        dot(x1 + 2, y1, claw);
        dot(x1 + 1, y1 + 0.9, claw);
    }

    private void head(double hx, double hy, boolean asleep) {
        double hs = baby ? 1.25 : 1.0;
        // horns, swept back
        thickLine(hx - 1.5, hy - 2.6, hx - 5.5 * hs, hy - 5.5 * hs, 0.5, mul(horn, 0.7f));
        thickLine(hx - 5.5 * hs, hy - 5.5 * hs, hx - 8 * hs, hy - 5.8 * hs, 0.5, mul(horn, 0.9f));
        dot(hx - 0.5, hy - 3.2, mul(horn, 0.6f));
        dot(hx - 1.5, hy - 4.2, mul(horn, 0.6f));
        dot(hx - 2.5, hy - 5.2, mul(horn, 0.6f));
        // eye
        if (asleep) {
            dot(hx + 3, hy - 0.5, line);
            dot(hx + 4, hy - 0.5, line);
        } else {
            dot(hx + 3, hy - 1.2, 0xFFFFE066);
            dot(hx + 4, hy - 1.2, 0xFFFFC030);
            dot(hx + 2, hy - 2.2, line);
            dot(hx + 3, hy - 2.2, line);
        }
        // nostril
        dot(hx + 8, hy - 0.2, line);
        // mouth
        if (open && !asleep) {
            for (int i = 0; i < 8; i++) {
                dot(hx + 3 + i, hy + 1, 0xFFB02818);
                dot(hx + 3 + i, hy + 2, 0xFFE0502A);
            }
            thickLine(hx + 3, hy + 3, hx + 10, hy + 4.5, 0.7, belly);
            dot(hx + 9, hy + 1, 0xFFFFF4E0);
            dot(hx + 7, hy + 1, 0xFFFFF4E0);
        } else {
            thickLine(hx + 3, hy + 1.2, hx + 9, hy + 1.6, 0.5, line);
            if (!asleep) {
                dot(hx + 8, hy + 2.4, 0xFFFFF4E0);
            }
        }
    }

    private void spikes(double[][] along) {
        for (int i = 0; i < along.length; i++) {
            double[] a = along[i];
            dot(a[0], a[1], dark);
            dot(a[0] - 0.5, a[1] - 1, dark);
            dot(a[0] - 1, a[1] - 2, mul(body, 0.7f));
        }
    }

    // ------------------------------------------------------------------ wings

    private double[] rot(double lx, double ly, double ang, double sx, double sy, double k) {
        double c = Math.cos(ang);
        double s = Math.sin(ang);
        double x = lx * k;
        double y = ly * k;
        return new double[] {sx + x * c - y * s, sy + x * s + y * c};
    }

    /** One spread wing. ang 0 = straight up, negative swings it back and down. fold squeezes it. */
    private void wing(double sx, double sy, double ang, double k, double fs, double hipX, double hipY, boolean far) {
        double[][] loc = {{0, 0}, {-5, -17}, {-26, -27}, {-34, -13}, {-31, 1}, {-20, 8}};
        double[][] w = new double[loc.length][];
        for (int i = 0; i < loc.length; i++) {
            w[i] = rot(loc[i][0] * fs, loc[i][1], ang, sx, sy, k);
        }
        double[] wr = w[1];
        // membrane with scalloped trailing edge
        java.util.ArrayList<double[]> poly = new java.util.ArrayList<>();
        poly.add(w[0]);
        poly.add(wr);
        for (int i = 2; i < loc.length; i++) {
            if (i > 2) {
                double[] a = w[i - 1];
                double[] b = w[i];
                double mx = (a[0] + b[0]) / 2;
                double my = (a[1] + b[1]) / 2;
                poly.add(new double[] {mx + (wr[0] - mx) * 0.42, my + (wr[1] - my) * 0.42});
            }
            poly.add(w[i]);
        }
        poly.add(new double[] {hipX, hipY});
        final int m1 = far ? mul(memb, 0.78f) : memb;
        final int m2 = far ? mul(memb2, 0.78f) : memb2;
        final double fx = sx;
        final double fy = sy;
        boolean[] mask = polygon(poly.toArray(new double[0][]), (x, y) -> {
            double d = Math.hypot(x - fx, y - fy) / (30 * k);
            boolean chk = ((x + y) & 1) == 0;
            return d > 0.62 ? (chk ? m2 : m1) : (d > 0.5 && chk ? m2 : m1);
        });
        edge(mask, far ? mul(line, 1f) : line);
        // finger bones and the arm
        int bn = far ? mul(bone, 0.75f) : bone;
        for (int i = 2; i < loc.length; i++) {
            thickLine(wr[0], wr[1], w[i][0], w[i][1], 0.5, i == 2 ? mul(bn, 1.15f) : bn);
        }
        thickLine(w[0][0], w[0][1], wr[0], wr[1], 1.2, far ? mul(body, 0.7f) : mul(body, 0.88f));
        // claw on the wrist
        double[] cl = rot(-4 * fs, -19.5, ang, sx, sy, k);
        thickLine(wr[0], wr[1], cl[0], cl[1], 0.5, mul(horn, 0.75f));
    }

    private void foldedWing(double sx, double sy, boolean far, double lift) {
        double wy = sy - 13 * lift;
        double[][] p = {{sx, sy}, {sx - 6, wy}, {sx - 17, sy - 3 * lift}, {sx - 14, sy + 1}, {sx - 18, sy + 5},
            {sx - 11, sy + 6}, {sx - 6, sy + 7}};
        final int m1 = far ? mul(memb, 0.78f) : memb;
        final int m2 = far ? mul(memb2, 0.78f) : memb2;
        boolean[] mask = polygon(p, (x, y) -> ((x + y) & 1) == 0 ? m2 : m1);
        edge(mask, line);
        int bn = far ? mul(bone, 0.75f) : bone;
        thickLine(sx, sy, sx - 6, wy, 1.0, mul(body, far ? 0.7f : 0.88f));
        thickLine(sx - 6, wy, sx - 17, sy - 3 * lift, 0.5, bn);
        thickLine(sx - 6, wy, sx - 14, sy + 1, 0.5, bn);
        thickLine(sx - 6, wy, sx - 18, sy + 5, 0.5, bn);
        dot(sx - 6, wy - 1.5, mul(horn, 0.7f));
        dot(sx - 6.5, wy - 2.5, mul(horn, 0.7f));
    }

    // ------------------------------------------------------------------ the poses

    private void draw() {
        if (pose == FLYING) {
            flying();
        } else {
            perched(pose == ASLEEP);
        }
        // a dark outline all around the whole silhouette
        boolean[] mask = new boolean[W * H];
        for (int i = 0; i < px.length; i++) {
            mask[i] = px[i] >>> 24 != 0;
        }
        int ol = line;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (mask[y * W + x]) {
                    continue;
                }
                boolean near = (x > 0 && mask[y * W + x - 1]) || (x < W - 1 && mask[y * W + x + 1])
                        || (y > 0 && mask[(y - 1) * W + x]) || (y < H - 1 && mask[(y + 1) * W + x]);
                if (near) {
                    px[y * W + x] = ol;
                }
            }
        }
    }

    private void flying() {
        // wing cycle: up, mid-down, down, mid-up
        double[] angs = {-0.05, -0.55, -1.5, -0.55};
        double[] fss = {0.95, 0.62, 0.78, 0.62};
        double a = angs[frame & 3];
        double fs = fss[frame & 3];
        double k = ws * 0.9;
        double hx = 24;
        double hy = 29;
        // far wing first (a little out of step)
        wing(31, 22.5, a + 0.8, k * 0.85, fs * 0.8, hx + 2, hy - 1, true);
        // far legs
        limb(26, 31, 29, 36, 30, 38, mul(body, 0.7f), horn);
        limb(35, 31, 38, 35, 39, 37, mul(body, 0.7f), horn);
        // tail and body, head at the right
        double[][] sp = {
            {52, 22.8, 1.3, 1}, {49, 22.6, 2.1, 1}, {45, 21.5, 3.0, 1}, {41, 23, 2.5, 1}, {37.5, 25.5, 3.0, 1},
            {33, 27, 4.0, 1}, {27, 29, 3.7, 1}, {22, 30, 3.1, 1}, {17, 31.5, 2.4, 0}, {12, 34, 1.9, 0},
            {8, 36, 1.5, 0}, {4.5, 35, 1.2, 0}, {2.5, 32, 1.0, 0}, {3, 29, 0.9, 0}};
        spine(sp);
        // spade tail tip
        thickLine(3, 29, 5.5, 26, 0.6, dark);
        thickLine(3, 29, 0.5, 26.5, 0.6, dark);
        thickLine(3, 29, 3, 25, 0.6, dark);
        spikes(new double[][] {{41, 21}, {38, 23}, {34.5, 24}, {30.5, 25.5}, {26, 27}, {22, 28.3}, {18, 29.7}, {14.5, 31.5}});
        // near legs
        limb(29, 31, 31, 36.5, 32, 38.5, body, horn);
        limb(23, 32, 25, 37, 27, 38.5, body, horn);
        head(45, 21, false);
        // near wing on top
        wing(33, 23.5, a, k, fs, hx + 1, hy, false);
    }

    private void perched(boolean asleep) {
        double hs = baby ? 1.25 : 1.0;
        double[][] sp;
        double hx;
        double hy;
        if (asleep) {
            sp = new double[][] {
                {50, 38.5, 1.2 * hs, 1}, {47, 38.5, 2.0 * hs, 1}, {43, 38, 2.9 * hs, 1}, {38.5, 36.5, 2.8, 1},
                {34, 33.5, 3.9, 1}, {28, 34, 4.4, 1}, {22, 36.5, 4.2, 0}, {16, 39.5, 3.0, 0}, {11, 41.5, 2.2, 0},
                {7, 41, 1.7, 0}, {4, 38.5, 1.3, 0}, {3.5, 35.5, 1.0, 0}};
            hx = 43;
            hy = 38;
        } else {
            sp = new double[][] {
                {49, 17, 1.2 * hs, 1}, {46, 17, 2.0 * hs, 1}, {42, 16.5, 2.9 * hs, 1}, {39.5, 20, 2.5, 1},
                {37, 25, 3.2, 1}, {33.5, 30, 4.2, 1}, {27.5, 34, 4.6, 1}, {21.5, 37, 3.8, 0}, {15.5, 40, 2.8, 0},
                {10.5, 41.5, 2.1, 0}, {6.5, 41, 1.6, 0}, {4, 38.5, 1.2, 0}, {3.5, 35.5, 1.0, 0}};
            hx = 42;
            hy = 16.5;
        }
        // folded wings behind and on top
        foldedWing(asleep ? 31 : 33, asleep ? 31 : 27, true, baby ? 0.8 : 1.0);
        limb(30, 37, 33, 40, 34, 41, mul(body, 0.7f), horn);
        spine(sp);
        thickLine(3.5, 35.5, 6, 32.5, 0.6, dark);
        thickLine(3.5, 35.5, 1, 33, 0.6, dark);
        thickLine(3.5, 35.5, 3.5, 31.5, 0.6, dark);
        if (asleep) {
            spikes(new double[][] {{35, 31}, {31, 31.3}, {27, 31.5}, {23, 33}, {19, 36}});
            limb(26, 38, 29, 41, 31, 42, body, horn);
            limb(37, 38, 40, 41.5, 42, 42, body, horn);
        } else {
            spikes(new double[][] {{39, 17.5}, {37, 21}, {35, 26}, {31, 30}, {26.5, 31.5}, {22, 34}, {17.5, 37}});
            limb(26, 38, 29, 41, 31, 42, body, horn);
            limb(37, 32, 38.5, 38, 38.5, 42, body, horn);
        }
        head(hx, hy, asleep);
        foldedWing(asleep ? 33 : 35, asleep ? 31.5 : 27.5, false, baby ? 0.8 : 1.0);
    }
}
