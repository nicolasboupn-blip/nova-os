package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Saves the error when NOVA crashes, and shows it the next time NOVA opens, so a crash can be pinned down. */
final class CrashLog {
    private CrashLog() {
    }

    private static File file(Context c) {
        return new File(c.getFilesDir(), "nova.crash.txt");
    }

    static void install(final Context c) {
        final Context app = c.getApplicationContext();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                Prefs.putInt("crash_n", Prefs.getInt("crash_n", 0) + 1);
            } catch (Throwable ignored) {
                // never fail inside the handler
            }
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String text = "NOVA " + Theme.OS_VERSION + "  " + new java.util.Date() + "\nthread " + t.getName()
                        + "\n\n" + sw;
                try (FileOutputStream out = new FileOutputStream(file(app))) {
                    out.write(text.getBytes("UTF-8"));
                }
            } catch (Throwable ignored) {
                // nothing more we can do
            }
            if (old != null) {
                old.uncaughtException(t, e);
            }
        });
    }

    /** If NOVA crashed last time, shows what happened. */
    static void showPending(final NovaActivity host) {
        final File f = file(host);
        if (!f.exists()) {
            return;
        }
        String text;
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 6000)];
            int n = in.read(b);
            text = new String(b, 0, Math.max(0, n), "UTF-8");
        } catch (Exception e) {
            f.delete();
            return;
        }
        final String shown = text;
        // keep only the first lines on screen, the whole thing is copied
        String[] lines = shown.split("\n");
        StringBuilder brief = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 14); i++) {
            brief.append(lines[i]).append('\n');
        }
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("NOVA crashed last time")
                .setMessage(brief.toString())
                .setPositiveButton("Copy", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("nova crash", shown));
                    }
                    f.delete();
                    host.toast("Copied. Send it to Claude.");
                })
                .setNegativeButton("Dismiss", (d, w) -> f.delete())
                .show();
    }

    /** Two crashes in a row: switch the extras off so NOVA can start safely. */
    static void guard(NovaActivity host) {
        if (Prefs.getInt("crash_n", 0) >= 2) {
            safeMode(host);
            host.root.postDelayed(() -> host.toast("NOVA crashed twice, so Safe mode switched the extras off"), 2500);
        }
        host.root.postDelayed(() -> Prefs.putInt("crash_n", 0), 90000);
    }

    /** Turns the lively extras off. Everything can be switched on again in Settings. */
    static void safeMode(NovaActivity host) {
        Prefs.putInt("crash_n", 0);
        Prefs.putBool(Prefs.K_CLIFE, false);
        Prefs.putBool(Prefs.K_EVENTS, false);
        Prefs.putBool(Prefs.K_CRITTERS, false);
        Prefs.putBool(Prefs.K_PRANKS, false);
        Prefs.putBool(Prefs.K_REACT, false);
        Prefs.putInt("adm_fps", 0);
    }

    static String read(Context c) {
        File f = file(c);
        if (!f.exists()) {
            return "";
        }
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 20000)];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static void clear(Context c) {
        file(c).delete();
    }
}
