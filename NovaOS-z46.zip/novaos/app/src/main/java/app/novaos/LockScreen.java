package app.novaos;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.media.session.MediaController;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.Locale;

/**
 * Swipe-up lock screen. Without a NOVA PIN it is only a cover for looks and your phone's real PIN, pattern or
 * fingerprint still works the way you set it in Android. With a NOVA PIN (Settings) swiping up opens a PIN pad.
 * Swipe left for the camera. The music player shows up here when something is playing.
 */
final class LockScreen extends FrameLayout {
    private final NovaActivity host;
    private final ObjectAnimator pulse;
    private final ValueAnimator tagGlow;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int threshold;
    private final int slop;

    // music card
    private LinearLayout musicCard;
    private TextView musicTitle, musicArtist, playBtn;
    private boolean musicShown;

    // touch
    private float startX, startY;
    private int axis; // 0 undecided, 1 vertical, 2 horizontal

    // pin
    private PinPad pad;
    private CancellationSignal bioCancel;

    private final Runnable musicTick = new Runnable() {
        @Override
        public void run() {
            refreshMusic();
            handler.postDelayed(this, 2000);
        }
    };

    LockScreen(NovaActivity host) {
        super(host);
        this.host = host;
        threshold = Theme.dp(host, 120);
        slop = ViewConfiguration.get(host).getScaledTouchSlop();
        setClipChildren(false);

        // live wallpaper: NOVA's own source code typing itself, plus the edge light
        CodeWallpaper code = new CodeWallpaper(host);
        code.setAlpha(0.22f);
        code.setPadding(Theme.dp(host, 24), Theme.dp(host, 40), Theme.dp(host, 24), 0);
        addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        if (Prefs.liveWall() > 0 && !Saver.on()) {
            addView(new LiveWallpaper(host, Prefs.liveWall()),
                    new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setClipChildren(false);
        int side = Theme.dp(host, 24);
        col.setPadding(side, Theme.dp(host, 110), side, 0);
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        TextView tag = new TextView(host);
        tag.setText(Theme.OS_NAME + " " + Theme.OS_VERSION);
        tag.setTypeface(Theme.MONO);
        tag.setTextSize(12f);
        tag.setLetterSpacing(0.3f);
        tag.setTextColor(Theme.ACCENT);
        col.addView(tag, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        tagGlow = Theme.glow(tag);

        NovaClock time = new NovaClock(host, 1.375f);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 14) - time.pad;
        tlp.bottomMargin = -time.pad + Theme.dp(host, 2);
        tlp.gravity = Gravity.START;
        tlp.leftMargin = -time.pad;
        col.addView(time, tlp);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(16f);
        date.setTextColor(Theme.DIM);
        col.addView(date, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hello = new TextView(host);
        hello.setText(Prefs.greeting().toUpperCase(Locale.getDefault()));
        hello.setTypeface(Theme.MONO);
        hello.setTextSize(12f);
        hello.setLetterSpacing(0.3f);
        hello.setTextColor(Theme.ACCENT);
        LinearLayout.LayoutParams hlp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp2.topMargin = Theme.dp(host, 12);
        col.addView(hello, hlp2);

        // music card (only visible while a player is running)
        musicCard = new LinearLayout(host);
        musicCard.setOrientation(LinearLayout.VERTICAL);
        musicCard.setBackground(Theme.rounded(Theme.PANEL, 20f, host));
        musicCard.setPadding(Theme.dp(host, 18), Theme.dp(host, 14), Theme.dp(host, 18), Theme.dp(host, 6));
        musicTitle = mono("", 14f, Theme.TEXT);
        musicTitle.setSingleLine(true);
        musicTitle.setEllipsize(TextUtils.TruncateAt.END);
        musicCard.addView(musicTitle);
        musicArtist = mono("", 11f, Theme.DIM);
        musicArtist.setSingleLine(true);
        musicArtist.setEllipsize(TextUtils.TruncateAt.END);
        musicCard.addView(musicArtist);
        LinearLayout controls = new LinearLayout(host);
        controls.addView(control("<<", v -> {
            MusicHelper.previous(host);
            handler.postDelayed(this::refreshMusic, 350);
        }), cw());
        playBtn = control("PLAY", v -> {
            MusicHelper.toggle(host);
            handler.postDelayed(this::refreshMusic, 350);
        });
        controls.addView(playBtn, cw());
        controls.addView(control(">>", v -> {
            MusicHelper.next(host);
            handler.postDelayed(this::refreshMusic, 350);
        }), cw());
        LinearLayout.LayoutParams cwp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cwp.topMargin = Theme.dp(host, 6);
        musicCard.addView(controls, cwp);
        LayoutParams mlp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        mlp.setMargins(Theme.dp(host, 24), 0, Theme.dp(host, 24), Theme.dp(host, 124));
        musicCard.setAlpha(0f);
        musicCard.setVisibility(GONE);
        addView(musicCard, mlp);

        TextView hint = new TextView(host);
        hint.setText(Prefs.hasPin() ? "swipe up to enter PIN" : "swipe up to unlock");
        hint.setTypeface(Theme.MONO);
        hint.setTextSize(12f);
        hint.setLetterSpacing(0.15f);
        hint.setTextColor(Theme.DIM);
        LayoutParams hlp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hlp.bottomMargin = Theme.dp(host, 64);
        addView(hint, hlp);

        TextView cam = mono("CAMERA ‹", 10f, Theme.DIM);
        cam.setLetterSpacing(0.12f);
        LayoutParams clp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        clp.setMargins(0, 0, Theme.dp(host, 24), Theme.dp(host, 30));
        addView(cam, clp);

        pulse = ObjectAnimator.ofFloat(hint, View.ALPHA, 0.25f, 1f);
        pulse.setDuration(1300);
        pulse.setRepeatCount(Saver.on() ? 0 : ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams cw() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView control(String label, OnClickListener click) {
        TextView b = mono(label, 14f, Theme.ACCENT);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    // ------------------------------------------------------------------ music

    private void refreshMusic() {
        MediaController c = MusicHelper.controller(host);
        boolean show = MusicHelper.active(c);
        if (show) {
            musicTitle.setText(MusicHelper.title(c));
            musicArtist.setText(MusicHelper.artist(c));
            playBtn.setText(MusicHelper.isPlaying(c) ? "PAUSE" : "PLAY");
        }
        if (show == musicShown) {
            return;
        }
        musicShown = show;
        if (show) {
            musicCard.setVisibility(VISIBLE);
            musicCard.animate().alpha(1f).setDuration(300).start();
        } else {
            musicCard.animate().alpha(0f).setDuration(250)
                    .withEndAction(() -> musicCard.setVisibility(GONE)).start();
        }
    }

    // ------------------------------------------------------------------ touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (pad != null) {
            return true; // the PIN pad is open, it handles its own touches
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startX = e.getRawX();
                startY = e.getRawY();
                axis = 0;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - startX;
                float dy = e.getRawY() - startY;
                if (axis == 0 && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                    axis = Math.abs(dx) > Math.abs(dy) * 1.2f ? 2 : 1;
                }
                if (axis == 1) {
                    float up = Math.min(0f, dy);
                    setTranslationY(up * 0.8f);
                    setAlpha(Math.max(0.3f, 1f + up / (threshold * 4f)));
                } else if (axis == 2) {
                    setTranslationX(Math.min(0f, dx) * 0.4f);
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                float dx = e.getRawX() - startX;
                float dy = e.getRawY() - startY;
                boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                if (up && axis == 1 && dy < -threshold) {
                    if (Prefs.hasPin()) {
                        snapBack();
                        showPad();
                    } else {
                        finishUnlock();
                    }
                } else if (up && axis == 2 && dx < -Theme.dp(host, 110)) {
                    snapBack();
                    openCamera();
                } else {
                    snapBack();
                }
                axis = 0;
                return true;
            }
            default:
                return super.onTouchEvent(e);
        }
    }

    private void snapBack() {
        animate().translationY(0f).translationX(0f).alpha(1f).setDuration(480)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    /** The cover slides away and the home screen takes over. */
    private void finishUnlock() {
        animate().translationY(-getHeight()).alpha(0f).setDuration(420)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(() -> host.unlock()).start();
    }

    private void openCamera() {
        String action = Prefs.hasPin()
                ? MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE : MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA;
        try {
            host.startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                host.startActivity(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
                host.toast("No camera app found");
            }
        }
    }

    // ------------------------------------------------------------------ pin

    private void showPad() {
        if (pad != null) {
            return;
        }
        final boolean bio = Prefs.bio() && BioAuth.available(host);
        pad = new PinPad(host, Math.max(4, Prefs.pinLength()), bio, this::askFingerprint, new PinPad.Listener() {
            @Override
            public void onUnlocked() {
                cancelBio();
                finishUnlock();
            }

            @Override
            public void onCancel() {
                hidePad();
            }
        });
        addView(pad, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        pad.setAlpha(0f);
        pad.setTranslationY(Theme.dp(host, 90));
        pad.animate().alpha(1f).translationY(0f).setDuration(320)
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        if (bio) {
            askFingerprint();
        }
    }

    private void hidePad() {
        final PinPad p = pad;
        if (p == null) {
            return;
        }
        cancelBio();
        pad = null;
        p.animate().alpha(0f).translationY(Theme.dp(host, 90)).setDuration(240)
                .withEndAction(() -> removeView(p)).start();
    }

    private void askFingerprint() {
        cancelBio();
        bioCancel = BioAuth.prompt(host, () -> {
            if (pad != null) {
                pad.accept();
            }
        });
    }

    private void cancelBio() {
        if (bioCancel != null) {
            try {
                bioCancel.cancel();
            } catch (Exception ignored) {
                // already finished
            }
            bioCancel = null;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(musicTick);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        cancelBio();
        pulse.cancel();
        tagGlow.cancel();
        super.onDetachedFromWindow();
    }
}
