package app.novaos;

/**
 * Ember wrapped around the main tower of the castle, head resting up by the roof. Admin-only.
 * Pure Java so it can be previewed on a desktop. The picture is placed at (OX, OY) in castle pixels.
 */
final class DragonCoil {
    static final int W = 44, H = 76;
    static final int OX = 51, OY = 18;          // where the picture's corner sits on the castle sprite
    static final int HEAD_X = 36, HEAD_Y = 11;  // the mouth, in picture pixels

    private static final double AXIS = 22;      // the tower's centre line in the picture (castle x = 73)

    private final int[] px = new int[W * H];
    private final int body, dark, light, belly, line, horn, memb, memb2, bone;
    private final boolean blink;
    private final boolean open;

    private DragonCoil(int bodyRgb, boolean blink, boolean open) {
        body = 0xFF000000 | bodyRgb;
        dark = mul(body, 0.55f);
        light = add(mul(body, 1.22f), 26);
        belly = mix(body, 0xFFEBC878, 0.62f);
        line = mul(body, 0.20f);
        horn = 0xFFE9E1C8;
        memb = mix(mul(body, 0.50f), 0xFF4A4A9A, 0.50f);
        memb2 = add(memb, 22);
        bone = mul(body, 0.78f);
        this.blink = blink;
        this.open = open;
    }

    static int[] render(int bodyRgb, boolean blink, boolean openMouth) {
        DragonCoil d = new DragonCoil(bodyRgb & 0xFFFFFF, blink, openMouth);
        d.draw();
        return d.px;
    }

    // ------------------------------------------------------------------ helpers

    private static int ch(int c, int sh) {
        return (c >> sh) & 255;
    }

    private static int rgb(int r, int g, int b) {
        return 0xFF000000 | (Math.max(0, Math.min(255, r)) << 16) | (Math.max(0, Math.min(255, g)) << 8)
                | Math.max(0, Math.min(255, b));
    }

    private static int mul(int c, float k) {
        return rgb((int) (ch(c, 16) * k), (int) (ch(c, 8) * k), (int) (ch(c, 0) * k));
    }

    private static int add(int c, int d) {
        return rgb(ch(c, 16) + d, ch(c, 8) + d, ch(c, 0) + d);
    }

    private static int mix(int a, int b, float t) {
        return rgb((int) (ch(a, 16) * (1 - t) + ch(b, 16) * t), (int) (ch(a, 8) * (1 - t) + ch(b, 8) * t),
                (int) (ch(a, 0) * (1 - t) + ch(b, 0) * t));
    }

    private void dot(double x, double y, int col) {
        int ix = (int) Math.floor(x);
        int iy = (int) Math.floor(y);
        if (ix >= 0 && iy >= 0 && ix < W && iy < H) {
            px[iy * W + ix] = col;
        }
    }

    private void thickLine(double x0, double y0, double x1, double y1, double r, int col) {
        int n = (int) Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) * 2) + 1;
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            double x = x0 + (x1 - x0) * t;
            double y = y0 + (y1 - y0) * t;
            if (r <= 0.5) {
                dot(x, y, col);
            } else {
                disc(x, y, r, col);
            }
        }
    }

    private void disc(double cx, double cy, double r, int col) {
        for (int y = (int) Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
            for (int x = (int) Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
                double dx = x + 0.5 - cx;
                double dy = y + 0.5 - cy;
                if (dx * dx + dy * dy <= r * r) {
                    dot(x, y, col);
                }
            }
        }
    }

    /** Paints a stretch of body made of discs, shaded top to bottom, onto the picture. */
    private void stretch(double[][] pts, boolean back) {
        boolean[] filled = new boolean[W * H];
        double[] vv = new double[W * H];
        for (int i = 0; i + 1 < pts.length; i++) {
            double[] a = pts[i];
            double[] b = pts[i + 1];
            int n = (int) Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) * 2) + 1;
            for (int s = 0; s <= n; s++) {
                double t = s / (double) n;
                double cx = a[0] + (b[0] - a[0]) * t;
                double cy = a[1] + (b[1] - a[1]) * t;
                double r = a[2] + (b[2] - a[2]) * t;
                for (int y = (int) Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
                    for (int x = (int) Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
                        double dx = x + 0.5 - cx;
                        double dy = y + 0.5 - cy;
                        if (dx * dx + dy * dy <= r * r && x >= 0 && y >= 0 && x < W && y < H) {
                            filled[y * W + x] = true;
                            vv[y * W + x] = dy / r;
                        }
                    }
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (!filled[y * W + x]) {
                    continue;
                }
                double v = vv[y * W + x];
                boolean chk = ((x + y) & 1) == 0;
                int c;
                if (v < -0.55) {
                    c = light;
                } else if (v < -0.3) {
                    c = chk ? light : body;
                } else if (v < 0.25) {
                    c = body;
                } else if (v < 0.5) {
                    c = chk ? body : dark;
                } else {
                    c = dark;
                }
                // belly plates: faint cream flecks on the underside
                if (v > 0.1 && v < 0.5 && ((x * 3 + y) % 7 == 0)) {
                    c = belly;
                }
                px[y * W + x] = back ? mul(c, 0.62f) : c;
            }
        }
    }

    private boolean[] polygon(double[][] p, int m1, int m2) {
        boolean[] mask = new boolean[W * H];
        double minY = 1e9;
        double maxY = -1e9;
        for (double[] q : p) {
            minY = Math.min(minY, q[1]);
            maxY = Math.max(maxY, q[1]);
        }
        for (int y = (int) Math.floor(minY); y <= Math.ceil(maxY); y++) {
            double sy = y + 0.5;
            java.util.ArrayList<Double> xs = new java.util.ArrayList<>();
            for (int i = 0; i < p.length; i++) {
                double[] a = p[i];
                double[] b = p[(i + 1) % p.length];
                if ((a[1] <= sy && b[1] > sy) || (b[1] <= sy && a[1] > sy)) {
                    xs.add(a[0] + (sy - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
                }
            }
            java.util.Collections.sort(xs);
            for (int k = 0; k + 1 < xs.size(); k += 2) {
                for (int x = (int) Math.round(xs.get(k) - 0.5); x <= (int) Math.round(xs.get(k + 1) - 0.5); x++) {
                    if (x >= 0 && y >= 0 && x < W && y < H) {
                        px[y * W + x] = ((x + y) & 1) == 0 ? m2 : m1;
                        mask[y * W + x] = true;
                    }
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (mask[y * W + x] && (x == 0 || y == 0 || x == W - 1 || y == H - 1 || !mask[y * W + x - 1]
                        || !mask[y * W + x + 1] || !mask[(y - 1) * W + x] || !mask[(y + 1) * W + x])) {
                    px[y * W + x] = line;
                }
            }
        }
        return mask;
    }

    /** A bat wing: shoulder, wrist, three fingertips, and back to the body. */
    private void wing(double[] sh, double[] wr, double[][] tips, double[] hip, int m1, int m2, int bn) {
        java.util.ArrayList<double[]> poly = new java.util.ArrayList<>();
        poly.add(sh);
        poly.add(wr);
        for (int i = 0; i < tips.length; i++) {
            if (i > 0) {
                double mx = (tips[i - 1][0] + tips[i][0]) / 2;
                double my = (tips[i - 1][1] + tips[i][1]) / 2;
                poly.add(new double[] {mx + (wr[0] - mx) * 0.4, my + (wr[1] - my) * 0.4});
            }
            poly.add(tips[i]);
        }
        poly.add(hip);
        polygon(poly.toArray(new double[0][]), m1, m2);
        for (double[] t : tips) {
            thickLine(wr[0], wr[1], t[0], t[1], 0.5, bn);
        }
        thickLine(sh[0], sh[1], wr[0], wr[1], 1.1, mul(body, 0.8f));
        dot(wr[0], wr[1] - 1.5, mul(horn, 0.7f));
        dot(wr[0] - 0.5, wr[1] - 2.5, mul(horn, 0.7f));
    }

    // ------------------------------------------------------------------ the picture

    private void draw() {
        // wings spread against the sky, behind the coil
        wing(new double[] {24, 18}, new double[] {31, 6}, new double[][] {{39, 9}, {41, 17}, {37, 24}},
                new double[] {26, 26}, mul(memb, 0.78f), mul(memb2, 0.78f), mul(bone, 0.75f));
        wing(new double[] {19, 19}, new double[] {10, 7}, new double[][] {{1, 11}, {1, 20}, {5, 27}, {11, 30}},
                new double[] {19, 29}, memb, memb2, bone);
        final double turns = 3.0;
        final double top = 18;
        final double bottom = 72;
        final double radiusOfCoil = 8.8;
        int steps = 600;
        double phase0 = Math.PI * 0.9;
        // the body, from the tail (bottom) up to the neck; each stretch is either in front of the tower or behind it
        double[][] all = new double[steps + 1][];
        for (int i = 0; i <= steps; i++) {
            double s = i / (double) steps;
            double phi = phase0 + s * turns * 2 * Math.PI;
            double x = AXIS + radiusOfCoil * Math.sin(phi);
            double y = bottom - (bottom - top) * s;
            double depth = Math.cos(phi);
            double r = 0.9 + 2.5 * Math.min(1.0, s * 6) * (1.0 - 0.2 * s);
            all[i] = new double[] {x, y, r, depth};
        }
        // behind-the-tower parts: only the bits that stick out past the tower's edge
        java.util.ArrayList<double[]> run = new java.util.ArrayList<>();
        for (int i = 0; i <= steps; i++) {
            boolean show = all[i][3] <= 0 && Math.abs(all[i][0] - AXIS) > 5.6;
            if (show) {
                run.add(all[i]);
            }
            if ((!show || i == steps) && run.size() > 1) {
                stretch(run.toArray(new double[0][]), true);
                run.clear();
            } else if (!show) {
                run.clear();
            }
        }
        // in-front parts
        run.clear();
        for (int i = 0; i <= steps; i++) {
            boolean show = all[i][3] > 0;
            if (show) {
                run.add(all[i]);
            }
            if ((!show || i == steps) && run.size() > 1) {
                stretch(run.toArray(new double[0][]), false);
                run.clear();
            } else if (!show) {
                run.clear();
            }
        }
        // spines along the front of the body
        for (int i = 10; i < steps; i += 17) {
            if (all[i][3] > 0.2) {
                dot(all[i][0] + 0.5, all[i][1] - all[i][2] - 0.5, dark);
                dot(all[i][0], all[i][1] - all[i][2] - 1.5, dark);
            }
        }
        // the neck climbs the last bit and the head rests up by the roof, looking out to the right
        double[] end = all[steps];
        double[][] neck = {
            {end[0], end[1], end[2], 1}, {end[0] + 2.5, end[1] - 4, 2.7, 1}, {26, 10.5, 2.9, 1},
            {30, 10, 3.2, 1}, {34, 11, 2.4, 1}, {37.5, 12, 1.6, 1}};
        stretch(neck, false);
        // horns, eye, mouth
        thickLine(28.5, 7.5, 24.5, 4.8, 0.5, mul(horn, 0.7f));
        thickLine(24.5, 4.8, 21.5, 4.5, 0.5, mul(horn, 0.9f));
        dot(29.5, 7.2, mul(horn, 0.6f));
        dot(28.5, 6.2, mul(horn, 0.6f));
        if (blink) {
            dot(32, 9.6, line);
            dot(33, 9.6, line);
        } else {
            dot(32, 9.2, 0xFFFFE066);
            dot(33, 9.2, 0xFFFFC030);
            dot(31, 8.2, line);
            dot(32, 8.2, line);
        }
        dot(38, 11, line);
        if (open) {
            for (int i = 0; i < 6; i++) {
                dot(33 + i, 13, 0xFFB02818);
                dot(33 + i, 14, 0xFFE0502A);
            }
            thickLine(33, 15.5, 39, 16.5, 0.6, belly);
        } else {
            thickLine(33, 13, 38, 13.4, 0.5, line);
        }
        // front claws gripping the tower
        for (int k = 0; k < 2; k++) {
            double cx = 17 + k * 10;
            double cy = 30 + k * 2;
            thickLine(cx, cy, cx + 0.5, cy + 4, 0.9, body);
            dot(cx - 0.5, cy + 5, horn);
            dot(cx + 1, cy + 5, horn);
            dot(cx + 2.5, cy + 4.5, horn);
        }
        // the outline
        int[] out = px.clone();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (px[y * W + x] >>> 24 != 0) {
                    continue;
                }
                boolean near = (x > 0 && px[y * W + x - 1] >>> 24 != 0) || (x < W - 1 && px[y * W + x + 1] >>> 24 != 0)
                        || (y > 0 && px[(y - 1) * W + x] >>> 24 != 0) || (y < H - 1 && px[(y + 1) * W + x] >>> 24 != 0);
                if (near) {
                    out[y * W + x] = line;
                }
            }
        }
        System.arraycopy(out, 0, px, 0, px.length);
    }
}
