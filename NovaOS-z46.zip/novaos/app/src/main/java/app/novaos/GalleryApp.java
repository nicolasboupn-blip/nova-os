package app.novaos;

import android.Manifest;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * NOVA's gallery, laid out like the stock one but in NOVA's colours: Pictures grouped by day, Albums, videos with their
 * length, a full-screen viewer you swipe through, favourites, sharing and deleting.
 */
final class GalleryApp extends Game {
    private static final int COLS = 4;
    private static final int MAX = 700;
    private static final String FAVS = "gal_favs";

    private static final class Item {
        long id;
        boolean video;
        long date;
        String bucket;
        long durationMs;

        Uri uri() {
            return ContentUris.withAppendedId(video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
        }

        long key() {
            return id * 2 + (video ? 1 : 0);
        }
    }

    private final List<Item> all = new ArrayList<>();
    private List<Item> shown = new ArrayList<>(); // what the viewer swipes through
    private final LruCache<Long, Bitmap> cache = new LruCache<>(160);
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final FrameLayout holder;
    private final TextView status;
    private final TextView tabPics;
    private final TextView tabAlbums;
    private String openAlbum; // null = not inside an album
    private boolean onAlbums;
    private boolean needsReload;

    private FrameLayout viewer;
    private ImageView big;
    private VideoView video;
    private TextView info;
    private TextView heart;
    private int viewing = -1;

    GalleryApp(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(58), dp(8), dp(6));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout tabs = new LinearLayout(host);
        tabs.setGravity(Gravity.CENTER);
        tabPics = tab("PICTURES");
        tabAlbums = tab("ALBUMS");
        tabPics.setOnClickListener(v -> {
            openAlbum = null;
            onAlbums = false;
            render();
        });
        tabAlbums.setOnClickListener(v -> {
            openAlbum = null;
            onAlbums = true;
            render();
        });
        tabs.addView(tabPics, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        tabs.addView(tabAlbums, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView stock = label("STOCK", 10f, Theme.DIM);
        stock.setPadding(dp(12), dp(12), dp(8), dp(12));
        stock.setClickable(true);
        stock.setOnClickListener(v -> openStock());
        tabs.addView(stock);
        col.addView(tabs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        status = label("", 11f, Theme.DIM);
        status.setPadding(0, dp(4), 0, dp(6));
        col.addView(status);
        holder = new FrameLayout(host);
        col.addView(holder, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        final String[] perms = Build.VERSION.SDK_INT >= 33
                ? new String[] {Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO}
                : new String[] {Manifest.permission.READ_EXTERNAL_STORAGE};
        host.ask(perms, this::reload, () -> {
            status.setText("NOVA needs access to your photos");
            TextView again = button("ALLOW PHOTOS", () -> host.ask(perms, this::reload, null));
            holder.addView(again, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        });
    }

    @Override
    String title() {
        return "GALLERY";
    }

    private TextView tab(String s) {
        TextView t = label(s, 12f, Theme.DIM);
        t.setLetterSpacing(0.2f);
        t.setPadding(0, dp(12), 0, dp(12));
        t.setClickable(true);
        return t;
    }

    private void openStock() {
        String[] pkgs = {"com.sec.android.gallery3d", "com.android.gallery3d", "com.google.android.apps.photos"};
        for (String p : pkgs) {
            Intent i = host.getPackageManager().getLaunchIntentForPackage(p);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
                host.hideOverlay();
                return;
            }
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            host.startActivity(i);
        } catch (Exception e) {
            host.toast("No gallery app found");
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        pool.shutdownNow();
        if (video != null) {
            video.stopPlayback();
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && needsReload) {
            needsReload = false;
            closeViewer();
            reload();
        }
    }

    // ------------------------------------------------------------------ loading the library

    private void reload() {
        all.clear();
        queryInto(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false);
        queryInto(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true);
        Collections.sort(all, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                return Long.compare(b.date, a.date);
            }
        });
        while (all.size() > MAX) {
            all.remove(all.size() - 1);
        }
        render();
    }

    private void queryInto(Uri base, boolean isVideo) {
        String[] proj = isVideo
                ? new String[] {MediaStore.Video.Media._ID, MediaStore.Video.Media.DATE_TAKEN,
                    MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION}
                : new String[] {MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.BUCKET_DISPLAY_NAME};
        try (Cursor c = host.getContentResolver().query(base, proj, null, null,
                MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            int n = 0;
            while (c != null && c.moveToNext() && n++ < MAX) {
                Item it = new Item();
                it.id = c.getLong(0);
                it.video = isVideo;
                long taken = c.getLong(1);
                it.date = taken > 0 ? taken : c.getLong(2) * 1000L;
                String b = c.getString(3);
                it.bucket = b == null ? "Other" : b;
                it.durationMs = isVideo ? c.getLong(4) : 0;
                all.add(it);
            }
        } catch (Exception e) {
            status.setText("Could not read your photos");
        }
    }

    // ------------------------------------------------------------------ favourites

    private boolean isFav(Item it) {
        return (";" + Prefs.getString(FAVS, "") + ";").contains(";" + it.key() + ";");
    }

    private void toggleFav(Item it) {
        String cur = Prefs.getString(FAVS, "");
        String k = String.valueOf(it.key());
        StringBuilder out = new StringBuilder();
        boolean was = false;
        for (String p : cur.split(";")) {
            if (p.isEmpty()) {
                continue;
            }
            if (p.equals(k)) {
                was = true;
            } else {
                out.append(p).append(';');
            }
        }
        if (!was) {
            out.append(k).append(';');
        }
        Prefs.putString(FAVS, out.toString());
    }

    // ------------------------------------------------------------------ drawing the screens

    private void render() {
        tabPics.setTextColor(!onAlbums && openAlbum == null ? Theme.ACCENT : Theme.DIM);
        tabAlbums.setTextColor(onAlbums || openAlbum != null ? Theme.ACCENT : Theme.DIM);
        holder.removeAllViews();
        if (all.isEmpty()) {
            status.setText("NO PHOTOS OR VIDEOS YET");
            return;
        }
        if (openAlbum != null) {
            List<Item> list = new ArrayList<>();
            for (Item it : all) {
                if (openAlbum.equals("♥") ? isFav(it) : it.bucket.equals(openAlbum)) {
                    list.add(it);
                }
            }
            status.setText("‹ " + (openAlbum.equals("♥") ? "FAVOURITES" : openAlbum.toUpperCase())
                    + "   " + list.size());
            holder.addView(dayGrid(list), match());
        } else if (onAlbums) {
            status.setText("ALBUMS");
            holder.addView(albumGrid(), match());
        } else {
            int pics = 0;
            for (Item it : all) {
                if (!it.video) {
                    pics++;
                }
            }
            status.setText(pics + " PHOTOS  ·  " + (all.size() - pics) + " VIDEOS");
            holder.addView(dayGrid(all), match());
        }
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    private String dayLabel(long t) {
        Calendar now = Calendar.getInstance();
        Calendar d = Calendar.getInstance();
        d.setTimeInMillis(t);
        if (now.get(Calendar.YEAR) == d.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)) {
            return "TODAY";
        }
        now.add(Calendar.DAY_OF_YEAR, -1);
        if (now.get(Calendar.YEAR) == d.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)) {
            return "YESTERDAY";
        }
        return new SimpleDateFormat("EEE d MMM yyyy", Locale.getDefault()).format(new Date(t)).toUpperCase();
    }

    /** Thumbnails grouped under a heading for each day, four to a row. */
    private View dayGrid(List<Item> list) {
        shown = list;
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        int side = (host.getResources().getDisplayMetrics().widthPixels - dp(16) - dp(2) * (COLS - 1)) / COLS;
        String lastDay = null;
        LinearLayout row = null;
        int inRow = 0;
        for (int i = 0; i < list.size(); i++) {
            final Item it = list.get(i);
            String day = dayLabel(it.date);
            if (!day.equals(lastDay)) {
                lastDay = day;
                TextView hd = label(day, 11f, Theme.ACCENT);
                hd.setLetterSpacing(0.15f);
                hd.setGravity(Gravity.START);
                hd.setPadding(dp(2), dp(14), 0, dp(6));
                body.addView(hd);
                row = null;
            }
            if (row == null || inRow == COLS) {
                row = new LinearLayout(host);
                body.addView(row, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                inRow = 0;
            }
            inRow++;
            final int pos = i;
            row.addView(cell(it, side, pos), cellParams(side));
        }
        return sv;
    }

    private LinearLayout.LayoutParams cellParams(int side) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(side, side);
        lp.setMargins(0, 0, dp(2), dp(2));
        return lp;
    }

    private View cell(final Item it, int side, final int pos) {
        FrameLayout f = new FrameLayout(host);
        f.setBackgroundColor(0x22FFFFFF);
        ImageView iv = new ImageView(host);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        f.addView(iv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        load(it, iv);
        if (it.video) {
            TextView t = label("▶ " + fmt(it.durationMs), 9f, Theme.TEXT);
            t.setBackground(Theme.rounded(0x99000000, 8f, host));
            t.setPadding(dp(5), dp(2), dp(5), dp(2));
            f.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END));
        }
        if (isFav(it)) {
            TextView t = label("♥", 12f, Theme.ACCENT);
            f.addView(t, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START));
        }
        f.setOnClickListener(v -> open(pos));
        return f;
    }

    private String fmt(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    /** One card for each album (the folder the photos live in), plus Favourites on top. */
    private View albumGrid() {
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        Map<String, List<Item>> groups = new LinkedHashMap<>();
        List<Item> favs = new ArrayList<>();
        for (Item it : all) {
            List<Item> g = groups.get(it.bucket);
            if (g == null) {
                g = new ArrayList<>();
                groups.put(it.bucket, g);
            }
            g.add(it);
            if (isFav(it)) {
                favs.add(it);
            }
        }
        List<String> names = new ArrayList<>();
        List<List<Item>> lists = new ArrayList<>();
        if (!favs.isEmpty()) {
            names.add("♥");
            lists.add(favs);
        }
        for (Map.Entry<String, List<Item>> e : groups.entrySet()) {
            names.add(e.getKey());
            lists.add(e.getValue());
        }
        int side = (host.getResources().getDisplayMetrics().widthPixels - dp(16) - dp(10)) / 2;
        LinearLayout row = null;
        for (int i = 0; i < names.size(); i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(host);
                body.addView(row, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            final String name = names.get(i);
            List<Item> g = lists.get(i);
            LinearLayout card = new LinearLayout(host);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(0, 0, 0, dp(6));
            ImageView cover = new ImageView(host);
            cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cover.setBackground(Theme.rounded(0x22FFFFFF, 14f, host));
            cover.setClipToOutline(true);
            card.addView(cover, new LinearLayout.LayoutParams(side, side));
            load(g.get(0), cover);
            TextView n = label(name.equals("♥") ? "♥ Favourites" : name, 13f, Theme.TEXT);
            n.setGravity(Gravity.START);
            n.setPadding(dp(2), dp(6), 0, 0);
            n.setSingleLine(true);
            card.addView(n);
            TextView c = label(String.valueOf(g.size()), 10f, Theme.DIM);
            c.setGravity(Gravity.START);
            c.setPadding(dp(2), 0, 0, 0);
            card.addView(c);
            card.setOnClickListener(v -> {
                openAlbum = name;
                render();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(side, LinearLayout.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0, dp(6), dp(10), 0);
            row.addView(card, cp);
        }
        return sv;
    }

    // ------------------------------------------------------------------ thumbnails

    private void load(final Item it, final ImageView target) {
        final long key = it.key();
        target.setTag(key);
        Bitmap hit = cache.get(key);
        if (hit != null) {
            target.setImageBitmap(hit);
            return;
        }
        try {
            pool.execute(() -> {
                final Bitmap b = thumb(it);
                if (b != null) {
                    cache.put(key, b);
                    h.post(() -> {
                        if (target.getTag() instanceof Long && (Long) target.getTag() == key) {
                            target.setImageBitmap(b);
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            // the screen is closing
        }
    }

    @SuppressWarnings("deprecation")
    private Bitmap thumb(Item it) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                return host.getContentResolver().loadThumbnail(it.uri(), new Size(260, 260), null);
            }
            return it.video
                    ? MediaStore.Video.Thumbnails.getThumbnail(host.getContentResolver(), it.id,
                        MediaStore.Video.Thumbnails.MINI_KIND, null)
                    : MediaStore.Images.Thumbnails.getThumbnail(host.getContentResolver(), it.id,
                        MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ the viewer

    private void open(int pos) {
        viewing = pos;
        viewer = new FrameLayout(host);
        viewer.setBackgroundColor(0xFF000000);

        big = new ImageView(host);
        big.setScaleType(ImageView.ScaleType.FIT_CENTER);
        viewer.addView(big, match());
        video = new VideoView(host);
        video.setVisibility(View.GONE);
        viewer.addView(video, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        final GestureDetector gd = new GestureDetector(host, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 600) {
                    step(vx < 0 ? 1 : -1);
                    return true;
                }
                if (vy > 1200 && Math.abs(vy) > Math.abs(vx)) {
                    closeViewer();
                    return true;
                }
                return false;
            }
        });
        big.setClickable(true);
        big.setOnTouchListener((v, e) -> gd.onTouchEvent(e) || true);

        info = label("", 11f, Theme.DIM);
        info.setBackground(Theme.rounded(0x99000000, 12f, host));
        info.setPadding(dp(12), dp(8), dp(12), dp(8));
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        ip.setMargins(dp(14), dp(16), 0, 0);
        viewer.addView(info, ip);

        TextView back = label("✕", 22f, Theme.TEXT);
        back.setPadding(dp(18), dp(14), dp(18), dp(14));
        back.setClickable(true);
        back.setOnClickListener(v -> closeViewer());
        viewer.addView(back, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END));

        LinearLayout bar = new LinearLayout(host);
        bar.setGravity(Gravity.CENTER);
        bar.setBackground(Theme.rounded(0xCC0B0816, 22f, host));
        heart = barBtn("♡", () -> {
            Item it = shown.get(viewing);
            toggleFav(it);
            heart.setText(isFav(it) ? "♥" : "♡");
            heart.setTextColor(isFav(it) ? Theme.ACCENT : Theme.TEXT);
        });
        bar.addView(heart);
        bar.addView(barBtn("SHARE", this::share));
        bar.addView(barBtn("DELETE", this::delete));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bp.bottomMargin = dp(34);
        viewer.addView(bar, bp);

        addView(viewer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        viewer.bringToFront();
        showBig();
    }

    private TextView barBtn(String s, final Runnable action) {
        TextView t = label(s, s.length() == 1 ? 20f : 11f, Theme.TEXT);
        t.setLetterSpacing(s.length() == 1 ? 0f : 0.15f);
        t.setPadding(dp(18), dp(14), dp(18), dp(14));
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    private void step(int d) {
        int n = viewing + d;
        if (n >= 0 && n < shown.size()) {
            viewing = n;
            showBig();
        }
    }

    private void showBig() {
        if (viewing < 0 || viewing >= shown.size() || viewer == null) {
            return;
        }
        final Item it = shown.get(viewing);
        info.setText(new SimpleDateFormat("EEE d MMM yyyy  HH:mm", Locale.getDefault()).format(new Date(it.date))
                .toUpperCase() + "\n" + it.bucket + "   " + (viewing + 1) + "/" + shown.size());
        heart.setText(isFav(it) ? "♥" : "♡");
        heart.setTextColor(isFav(it) ? Theme.ACCENT : Theme.TEXT);
        video.stopPlayback();
        video.setVisibility(View.GONE);
        big.setVisibility(View.VISIBLE);
        big.setTag(it.key());
        Bitmap small = cache.get(it.key());
        big.setImageBitmap(small);
        if (it.video) {
            video.setVisibility(View.VISIBLE);
            MediaController mc = new MediaController(host);
            mc.setAnchorView(video);
            video.setMediaController(mc);
            video.setVideoURI(it.uri());
            video.setOnPreparedListener(m -> big.setVisibility(View.GONE));
            video.start();
            return;
        }
        final int target = Math.max(host.getResources().getDisplayMetrics().widthPixels, 1080);
        try {
            pool.execute(() -> {
                final Bitmap full = decode(it, target);
                if (full != null) {
                    h.post(() -> {
                        if (big != null && big.getTag() instanceof Long && (Long) big.getTag() == it.key()) {
                            big.setImageBitmap(full);
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            // closing
        }
    }

    private Bitmap decode(Item it, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = host.getContentResolver().openInputStream(it.uri())) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int s = 1;
            while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) {
                s *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            Bitmap b;
            try (InputStream in = host.getContentResolver().openInputStream(it.uri())) {
                b = BitmapFactory.decodeStream(in, null, o);
            }
            if (b == null) {
                return null;
            }
            int rot = 0;
            try (InputStream in = host.getContentResolver().openInputStream(it.uri())) {
                android.media.ExifInterface ex = new android.media.ExifInterface(in);
                int or = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Throwable ignored) {
                rot = 0;
            }
            if (rot != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private void share() {
        if (viewing < 0 || viewing >= shown.size()) {
            return;
        }
        Item it = shown.get(viewing);
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(it.video ? "video/*" : "image/*");
            i.putExtra(Intent.EXTRA_STREAM, it.uri());
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, "Share");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            host.startActivity(chooser);
        } catch (Exception e) {
            host.toast("Could not share");
        }
    }

    /** Android asks you to confirm. Needs Android 11 or newer. */
    private void delete() {
        if (viewing < 0 || viewing >= shown.size()) {
            return;
        }
        if (Build.VERSION.SDK_INT < 30) {
            host.toast("Deleting needs Android 11 or newer. Use STOCK.");
            return;
        }
        try {
            PendingIntent pi = MediaStore.createDeleteRequest(host.getContentResolver(),
                    Collections.singletonList(shown.get(viewing).uri()));
            needsReload = true;
            host.startIntentSenderForResult(pi.getIntentSender(), 91, null, 0, 0, 0);
        } catch (Exception e) {
            needsReload = false;
            host.toast("Could not delete");
        }
    }

    private void closeViewer() {
        if (viewer != null) {
            if (video != null) {
                video.stopPlayback();
            }
            removeView(viewer);
            viewer = null;
            big = null;
            video = null;
            viewing = -1;
            // hearts may have changed
            render();
        }
    }

    /** Back closes the viewer first, then leaves an album. */
    boolean onBackInside() {
        if (viewer != null) {
            closeViewer();
            return true;
        }
        if (openAlbum != null) {
            openAlbum = null;
            render();
            return true;
        }
        return false;
    }
}
