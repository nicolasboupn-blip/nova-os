package app.novaos;

import android.content.Context;
import android.content.SharedPreferences;

/** Every setting NOVA has. Read it anywhere, change it from the Settings screen. */
final class Prefs {
    static final String K_ACCENT = "s_accent";
    static final String K_GLOW_CLOCK = "s_glow_clock";
    static final String K_GLOW_EDGES = "s_glow_edges";
    static final String K_BATTERY = "s_battery";
    static final String K_CODE_WALL = "s_code_wall";
    static final String K_WALL_TEXT = "s_wall_text";
    static final String K_BOOT_UNLOCK = "s_boot_unlock";
    static final String K_BEEP = "s_beep";
    static final String K_GREETING = "s_greeting";
    static final String K_UNLOCKS = "s_unlocks";
    static final String K_HOME_CODE = "s_home_code";
    static final String K_HOME_STRENGTH = "s_home_strength";
    static final String K_SYSTEM_PANEL = "s_system_panel";
    static final String K_CLOCK_FONT = "s_clock_font";
    static final String K_GLOW_STRENGTH = "s_glow_strength";
    static final String K_ICON_STYLE = "s_icon_style";
    static final String K_HACKER = "s_hacker";
    static final String K_INTRO = "s_intro";
    static final String K_CLOCK_STYLE = "s_clock_style";
    static final String K_GREET_AUTO = "s_greet_auto";
    static final String K_TOUCH_GLOW = "s_touch_glow";
    static final String K_PIN = "s_pin";
    static final String K_BIO = "s_bio";
    static final String K_GREET_HOLD = "s_greet_hold";
    static final String K_DRAW = "s_draw_on";
    static final String K_LIVE = "s_live_wall";
    static final String K_PARALLAX = "s_parallax";
    static final String K_EDGE_FLASH = "s_edge_flash";
    static final String K_HAPTIC = "s_haptic";
    static final String K_QUIET = "s_quiet";
    static final String K_QSTART = "s_qstart";
    static final String K_QEND = "s_qend";
    static final String K_DIGEST = "s_digest";
    static final String K_HP_ASK = "s_hp_ask";
    static final String K_SHAKE = "s_shake_coin";
    static final String K_BOOT_STYLE = "s_boot_style";
    static final String K_HOLO = "s_holo";
    static final String K_CHEAT = "s_cheat";
    static final String K_WIZARD = "s_wizard";
    static final String K_SAVER = "s_saver";
    static final String K_NUDGE = "s_nudge";
    static final String K_EVENTS = "s_events";
    static final String K_CLIFE = "s_clife";
    static final String K_REACT = "s_react";
    static final String K_QUESTS = "s_quests";
    static final String K_CRITTERS = "s_critters";
    static final String K_PRANKS = "s_pranks";
    static final String K_CASTLE = "s_castle";
    static final String K_SFX = "s_sfx";
    static final String K_NIGHT = "s_night_clock";
    static final String K_NATIVE = "s_native_apps";
    static final String K_USER = "s_user_name";
    static final String K_VOICE = "s_voice";
    static final String K_VOICE_SPEAK = "s_voice_speak";

    private static SharedPreferences sp;

    private Prefs() {}

    private static Context app;

    static Context appContext() {
        return app;
    }

    /** How often the wizard may suggest something on the home screen: 0 off, 1 = 5 min, 2 = 1 hour, 3 = 12 hours. */
    static int nudgeMode() {
        return Math.max(0, Math.min(3, sp.getInt(K_NUDGE, 2)));
    }

    static boolean eventsOn() {
        return sp.getBoolean(K_EVENTS, true);
    }

    static boolean castleLife() {
        return sp.getBoolean(K_CLIFE, true);
    }

    static boolean reactions() {
        return sp.getBoolean(K_REACT, true);
    }

    static boolean questsOn() {
        return sp.getBoolean(K_QUESTS, true);
    }

    static boolean critters() {
        return sp.getBoolean(K_CRITTERS, true);
    }

    static boolean pranks() {
        return sp.getBoolean(K_PRANKS, true);
    }

    /** 0 off, 1 automatic when the battery is low, 2 always. */
    static int saverMode() {
        return Math.max(0, Math.min(2, sp.getInt(K_SAVER, 1)));
    }

    static void init(Context c) {
        app = c.getApplicationContext();
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("nova", Context.MODE_PRIVATE);
        }
    }

    static int accent() {
        return sp.getInt(K_ACCENT, 0);
    }

    static boolean glowClock() {
        return sp.getBoolean(K_GLOW_CLOCK, true);
    }

    static boolean glowEdges() {
        return sp.getBoolean(K_GLOW_EDGES, true);
    }

    static boolean battery() {
        return sp.getBoolean(K_BATTERY, true);
    }

    static boolean codeWall() {
        return sp.getBoolean(K_CODE_WALL, true);
    }

    static boolean bootOnUnlock() {
        return sp.getBoolean(K_BOOT_UNLOCK, false);
    }

    static boolean beep() {
        return sp.getBoolean(K_BEEP, false);
    }

    static String wallText() {
        return sp.getString(K_WALL_TEXT, "");
    }

    static String userName() {
        return sp.getString(K_USER, "").trim();
    }

    static String greeting() {
        if (greetAuto()) {
            int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
            String g;
            if (h >= 5 && h < 12) {
                g = "good morning";
            } else if (h >= 12 && h < 18) {
                g = "good afternoon";
            } else if (h >= 18 && h < 22) {
                g = "good evening";
            } else {
                g = "good night";
            }
            return userName().isEmpty() ? g : g + ", " + userName().toLowerCase();
        }
        String g = sp.getString(K_GREETING, "welcome");
        return g.trim().isEmpty() ? "welcome" : g.trim();
    }

    /** Code wallpaper behind the home screen. */
    static boolean homeCode() {
        return sp.getBoolean(K_HOME_CODE, true);
    }

    /** 0 = subtle, 1 = medium, 2 = strong. */
    static int homeStrength() {
        return sp.getInt(K_HOME_STRENGTH, 0);
    }

    static boolean systemPanel() {
        return sp.getBoolean(K_SYSTEM_PANEL, true);
    }

    /** 0 = digital, 1 = classic. */
    static int clockFont() {
        return sp.getInt(K_CLOCK_FONT, 0);
    }

    /** 0 = soft, 1 = normal, 2 = strong. */
    static int glowStrength() {
        return sp.getInt(K_GLOW_STRENGTH, 1);
    }

    /** 0 = black and white with a glowing edge, 1 = single-color tint, 2 = original icons. */
    static int iconStyle() {
        return sp.getInt(K_ICON_STYLE, 0);
    }

    /** Green terminal look; the glow pulses faster as the battery drops. */
    static boolean hacker() {
        return sp.getBoolean(K_HACKER, false);
    }

    /** The "welcome" animation that plays after you unlock. */
    static boolean intro() {
        return sp.getBoolean(K_INTRO, true);
    }

    /** 0 = digital, 1 = stacked, 2 = analog, 3 = binary. */
    static int clockStyle() {
        return sp.getInt(K_CLOCK_STYLE, 0);
    }

    /** How long the big greeting stays in the welcome animation, in half seconds. 0 means until you tap. */
    /** 0 off, 1 stars, 2 rain, 3 aurora, 4 grid, 5 fireflies */
    static int liveWall() {
        return Math.max(0, Math.min(9, sp.getInt(K_LIVE, 0)));
    }

    static boolean parallax() {
        return sp.getBoolean(K_PARALLAX, true);
    }

    static boolean edgeFlash() {
        return sp.getBoolean(K_EDGE_FLASH, true);
    }

    /** 0 off, 1 soft, 2 crisp, 3 strong */
    static int haptic() {
        return Math.max(0, Math.min(3, sp.getInt(K_HAPTIC, 2)));
    }

    static boolean quiet() {
        return sp.getBoolean(K_QUIET, false);
    }

    static int quietStart() {
        return Math.max(0, Math.min(1439, sp.getInt(K_QSTART, 22 * 60)));
    }

    static int quietEnd() {
        return Math.max(0, Math.min(1439, sp.getInt(K_QEND, 7 * 60)));
    }

    static boolean digest() {
        return sp.getBoolean(K_DIGEST, true);
    }

    static boolean voiceSpeak() {
        return sp.getBoolean(K_VOICE_SPEAK, true);
    }

    static boolean headphoneAsk() {
        return sp.getBoolean(K_HP_ASK, true);
    }

    static boolean shakeCoin() {
        return sp.getBoolean(K_SHAKE, true);
    }

    /** 0 = normal startup log, 1 = cinematic system check. */
    static int bootStyle() {
        return sp.getInt(K_BOOT_STYLE, 0);
    }

    static boolean holo() {
        return sp.getBoolean(K_HOLO, false);
    }

    static java.util.Map<String, ?> all() {
        return sp.getAll();
    }

    static void remove(String key) {
        sp.edit().remove(key).apply();
    }

    static void removePrefix(String prefix) {
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) {
            if (k.startsWith(prefix)) {
                e.remove(k);
            }
        }
        e.apply();
    }

    static boolean cheat() {
        return sp.getBoolean(K_CHEAT, false);
    }

    static boolean wizard() {
        return sp.getBoolean(K_WIZARD, false);
    }

    /** The castle on the home screen: needs the wizard, and can be switched off on its own. */
    static boolean castleSwitch() {
        return sp.getBoolean(K_CASTLE, true);
    }

    static boolean castle() {
        return wizard() && sp.getBoolean(K_CASTLE, true);
    }

    static boolean sfx() {
        return sp.getBoolean(K_SFX, true);
    }

    static boolean nightClock() {
        return sp.getBoolean(K_NIGHT, true);
    }

    /** Use NOVA's own Phone, Gallery and Camera instead of the stock apps. */
    static boolean nativeApps() {
        return sp.getBoolean(K_NATIVE, true);
    }

    static boolean voice() {
        return sp.getBoolean(K_VOICE, false);
    }

    static boolean drawOn() {
        return sp.getBoolean(K_DRAW, true);
    }

    static int greetHold() {
        return Math.max(0, Math.min(20, sp.getInt(K_GREET_HOLD, 2)));
    }

    /** Greeting that follows the time of day ("good morning"...), instead of your own text. */
    static boolean greetAuto() {
        return sp.getBoolean(K_GREET_AUTO, true);
    }

    /** App icons throw sparks when you touch them. */
    static boolean touchGlow() {
        return sp.getBoolean(K_TOUCH_GLOW, true);
    }

    /** Fingerprint unlock on the lock screen (only used together with a PIN). */
    static boolean bio() {
        return sp.getBoolean(K_BIO, false);
    }

    // ---- NOVA PIN (stored as a salted hash, never the digits)

    static boolean hasPin() {
        return !sp.getString(K_PIN, "").isEmpty();
    }

    static int pinLength() {
        String p = sp.getString(K_PIN, "");
        int i = p.indexOf(':');
        return i < 0 ? 0 : Integer.parseInt(p.substring(0, i));
    }

    static void setPin(String digits) {
        String salt = Long.toHexString(System.nanoTime());
        sp.edit().putString(K_PIN, digits.length() + ":" + salt + ":" + hash(salt + digits)).apply();
    }

    static void clearPin() {
        sp.edit().remove(K_PIN).apply();
    }

    static boolean checkPin(String digits) {
        String[] p = sp.getString(K_PIN, "").split(":");
        return p.length == 3 && p[2].equals(hash(p[1] + digits));
    }

    private static String hash(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    // ---- small bits of state that are not settings (kept through "reset all settings")

    static int getInt(String key, int def) {
        return sp.getInt(key, def);
    }

    static String getString(String key, String def) {
        return sp.getString(key, def);
    }

    static int unlocks() {
        return sp.getInt(K_UNLOCKS, 0);
    }

    static void incUnlocks() {
        sp.edit().putInt(K_UNLOCKS, unlocks() + 1).apply();
    }

    static boolean getBool(String key, boolean def) {
        return sp.getBoolean(key, def);
    }

    static void putBool(String key, boolean v) {
        sp.edit().putBoolean(key, v).apply();
    }

    static void putInt(String key, int v) {
        sp.edit().putInt(key, v).apply();
    }

    static void putString(String key, String v) {
        sp.edit().putString(key, v).apply();
    }

    /** Puts every setting back to its default. The unlock counter is kept. */
    static void reset() {
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) {
            if (k.startsWith("s_") && !k.equals(K_UNLOCKS) && !k.equals(K_PIN)) {
                e.remove(k);
            }
        }
        e.apply();
    }
}
