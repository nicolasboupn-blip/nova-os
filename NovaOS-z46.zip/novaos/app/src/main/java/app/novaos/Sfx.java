package app.novaos;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

/** NOVA's own sounds, made from simple tones so there are no audio files. Silent when the phone is on silent or vibrate. */
final class Sfx {
    private Sfx() {
    }

    static final int BLIP = 0, CLICK = 1, COIN = 2, WIN = 3, LOSE = 4, BOOT = 5, NOTIFY = 6;
    private static final int RATE = 22050;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Context ctx;
    private static final short[][] CACHE = new short[7][];

    static void init(Context c) {
        ctx = c.getApplicationContext();
    }

    /** A sine tone with a quick attack and a smooth fade. */
    private static short[] tone(double hz, int ms, double vol) {
        int n = RATE * ms / 1000;
        short[] s = new short[n];
        int pack = Upgrades.soundPack();
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double env = Math.min(1.0, i / (RATE * 0.004)) * Math.pow(1.0 - i / (double) n, 1.6);
            double v;
            switch (pack) {
                case 1:   // retro: a square wave
                    v = Math.sin(2 * Math.PI * hz * t) >= 0 ? 0.55 : -0.55;
                    break;
                case 2:   // bell: inharmonic partials that ring out
                    v = Math.sin(2 * Math.PI * hz * t) + 0.5 * Math.sin(2 * Math.PI * hz * 2.76 * t)
                            + 0.25 * Math.sin(2 * Math.PI * hz * 5.4 * t);
                    env = Math.min(1.0, i / (RATE * 0.002)) * Math.exp(-t * (7000.0 / Math.max(60, ms)));
                    break;
                case 3:   // wood: a short pluck
                    v = Math.sin(2 * Math.PI * hz * 0.5 * t) + 0.6 * Math.sin(2 * Math.PI * hz * t);
                    env = Math.min(1.0, i / (RATE * 0.001)) * Math.exp(-t * 22);
                    break;
                default:
                    v = Math.sin(2 * Math.PI * hz * t) + 0.25 * Math.sin(4 * Math.PI * hz * t);
                    break;
            }
            s[i] = (short) (v * env * vol * 12000);
        }
        return s;
    }

    private static short[] seq(short[]... parts) {
        int n = 0;
        for (short[] p : parts) {
            n += p.length;
        }
        short[] o = new short[n];
        int at = 0;
        for (short[] p : parts) {
            System.arraycopy(p, 0, o, at, p.length);
            at += p.length;
        }
        return o;
    }

    /** Mixes a tone into a buffer starting at a time offset. */
    private static void mix(short[] into, short[] part, int startMs) {
        int at = RATE * startMs / 1000;
        for (int i = 0; i < part.length && at + i < into.length; i++) {
            int v = into[at + i] + part[i];
            into[at + i] = (short) Math.max(-32000, Math.min(32000, v));
        }
    }

    private static short[] build(int id) {
        switch (id) {
            case BLIP:
                return tone(880, 70, 0.5);
            case CLICK:
                return tone(1500, 22, 0.35);
            case COIN:
                return seq(tone(1318, 70, 0.6), tone(1760, 220, 0.6));
            case WIN:
                return seq(tone(523, 90, 0.55), tone(659, 90, 0.55), tone(784, 90, 0.55), tone(1047, 300, 0.6));
            case LOSE:
                return seq(tone(330, 140, 0.5), tone(247, 260, 0.5));
            case NOTIFY:
                return seq(tone(988, 80, 0.5), tone(1319, 160, 0.5));
            default: {
                // boot chime: a rising chord that blooms and fades
                short[] o = new short[RATE * 1600 / 1000];
                mix(o, tone(262, 1300, 0.45), 0);
                mix(o, tone(392, 1200, 0.45), 160);
                mix(o, tone(523, 1100, 0.45), 320);
                mix(o, tone(784, 900, 0.45), 520);
                return o;
            }
        }
    }

    private static short[] click(double hz, double vol) {
        int n = RATE * 18 / 1000;
        short[] s = new short[n];
        java.util.Random r = new java.util.Random((long) hz);
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v = Math.sin(2 * Math.PI * hz * t) * Math.exp(-t * 380) + (r.nextDouble() - 0.5) * 0.7 * Math.exp(-t * 700);
            s[i] = (short) (v * vol * 14000);
        }
        return s;
    }

    private static short[] clunk(double vol) {
        int n = RATE * 130 / 1000;
        short[] s = new short[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v = Math.sin(2 * Math.PI * (170 - 420 * t) * t) * Math.exp(-t * 30)
                    + 0.5 * Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 400);
            s[i] = (short) (v * vol * 15000);
        }
        return s;
    }

    /**
     * The sound of three slot reels spinning: a ratchet tick for every symbol that passes, slowing down exactly like
     * the reels do, and a clunk as each one stops. start/target are in symbols, dur in milliseconds; the reels slow
     * down with 1 - (1 - x)^3.
     */
    static void playReels(float[] start, float[] target, long[] dur) {
        long max = 0;
        for (long d : dur) {
            max = Math.max(max, d);
        }
        short[] buf = new short[(int) (RATE * (max + 250) / 1000)];
        for (int i = 0; i < start.length; i++) {
            short[] tick = click(900 + 150 * i, 0.5);
            int steps = (int) Math.floor(target[i] - start[i]);
            for (int k = 1; k <= steps; k++) {
                double fr = k / (double) (target[i] - start[i]);
                double t = dur[i] * (1.0 - Math.pow(1.0 - fr, 1.0 / 3.0));
                mix(buf, tick, (int) t);
            }
            mix(buf, clunk(0.9), (int) dur[i]);
        }
        playPcm(buf);
    }

    /** Forget the sounds that were built, e.g. after you pick another sound pack. */
    static void reset() {
        java.util.Arrays.fill(CACHE, null);
    }

    static void play(int id) {
        if (ctx == null || !Prefs.sfx()) {
            return;
        }
        if (CACHE[id] == null) {
            CACHE[id] = build(id);
        }
        playPcm(CACHE[id]);
    }

    private static void playPcm(short[] pcm) {
        if (ctx == null || !Prefs.sfx()) {
            return;
        }
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am == null || am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) {
                return;
            }
            final AudioTrack t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            t.write(pcm, 0, pcm.length);
            t.setVolume(Math.max(0f, Math.min(1f, Prefs.getInt("s_vol", 100) / 100f)));
            t.play();
            H.postDelayed(() -> {
                try {
                    t.release();
                } catch (Throwable ignored) {
                    // already gone
                }
            }, pcm.length * 1000L / RATE + 300);
        } catch (Throwable ignored) {
            // no sound is better than a crash
        }
    }
}
