package app.novaos;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Invest with your NOVA coins in ten coins. Prices are live market quotes (CoinGecko), but every
 * trade uses game coins only. No real money is moved and this is not financial advice.
 */
final class InvestScreen extends FrameLayout implements BackAware {
    static final String[] IDS = {
        "bitcoin", "ethereum", "solana", "dogecoin", "ripple",
        "cardano", "avalanche-2", "chainlink", "litecoin", "tron"};
    static final String[] SYMBOLS = {"BTC", "ETH", "SOL", "DOGE", "XRP", "ADA", "AVAX", "LINK", "LTC", "TRX"};
    static final String[] NAMES = {
        "Bitcoin", "Ethereum", "Solana", "Dogecoin", "XRP", "Cardano", "Avalanche", "Chainlink", "Litecoin", "Tron"};
    private static final int[] BUYS = {100, 1000, 10000};

    private static final double[] price = new double[IDS.length];
    private static final double[] change = new double[IDS.length];
    private static long loadedAt;
    private static boolean loading;

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LinearLayout body;
    private final LinearLayout market;
    private final LinearLayout trade;
    private int sel;
    private String note = "";

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            load();
            ui.postDelayed(this, 60_000);
        }
    };

    private InvestScreen(NovaActivity host) {
        super(host);
        this.host = host;
        sel = Math.max(0, Math.min(IDS.length - 1, Prefs.getInt("inv_sel", 0)));
        setBackgroundColor(0xF2080614);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 18);
        body.setPadding(pad, Theme.dp(host, 40), pad, Theme.dp(host, 60));
        sv.addView(body);
        addView(sv, new LayoutParams(-1, -1));
        market = new LinearLayout(host);
        market.setOrientation(LinearLayout.VERTICAL);
        trade = new LinearLayout(host);
        trade.setOrientation(LinearLayout.VERTICAL);
        build();
    }

    static void open(NovaActivity host) {
        host.showOverlay(new InvestScreen(host));
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ data

    private void load() {
        long now = System.currentTimeMillis();
        if (loading || (loadedAt > 0 && now - loadedAt < 5 * 60_000L)) {
            return;
        }
        loading = true;
        new Thread(() -> {
            boolean ok = fetch();
            ui.post(() -> {
                loading = false;
                if (ok) {
                    build();
                } else {
                    note = "Prices offline. Trading is paused until they load.";
                    build();
                }
            });
        }).start();
    }

    private static boolean fetch() {
        StringBuilder ids = new StringBuilder();
        for (String id : IDS) {
            ids.append(ids.length() == 0 ? "" : ",").append(id);
        }
        String body = Http.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=" + ids
                + "&price_change_percentage=24h");
        if (body == null) {
            return false;
        }
        try {
            JSONArray arr = new JSONArray(body);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                for (int k = 0; k < IDS.length; k++) {
                    if (IDS[k].equals(o.optString("id"))) {
                        price[k] = o.optDouble("current_price", 0);
                        change[k] = o.optDouble("price_change_percentage_24h", 0);
                    }
                }
            }
            loadedAt = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static double units(int k) {
        return parse(Prefs.getString("inv_u_" + IDS[k], "0"));
    }

    private static double cost(int k) {
        return parse(Prefs.getString("inv_c_" + IDS[k], "0"));
    }

    private static double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static void save(int k, double units, double cost) {
        Prefs.putString("inv_u_" + IDS[k], Double.toString(Math.max(0, units)));
        Prefs.putString("inv_c_" + IDS[k], Double.toString(Math.max(0, cost)));
    }

    private boolean ready() {
        return loadedAt > 0 && price[sel] > 0;
    }

    private void buy(final int amount) {
        if (!ready()) {
            note = "No price yet";
        } else if (Coins.get() < amount) {
            note = "Not enough coins for " + amount;
        } else {
            Coins.add(-amount);
            save(sel, units(sel) + amount / price[sel], cost(sel) + amount);
            note = "Bought " + SYMBOLS[sel] + " for " + amount;
        }
        build();
    }

    private void sell(boolean all) {
        double u = units(sel);
        if (!ready()) {
            note = "No price yet";
        } else if (u <= 0) {
            note = "Nothing to sell";
        } else {
            double f = all ? 1.0 : 0.5;
            double sellUnits = u * f;
            double costPart = cost(sel) * f;
            int payout = (int) Math.floor(sellUnits * price[sel]);
            save(sel, u - sellUnits, cost(sel) - costPart);
            Coins.add(payout);
            long profit = Math.round(payout - costPart);
            note = "Sold for " + payout + " (" + (profit >= 0 ? "+" : "") + profit + ")";
        }
        build();
    }

    // ------------------------------------------------------------------ UI helpers

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private void head(LinearLayout into, String s) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, Theme.dp(host, 20), 0, Theme.dp(host, 6));
        into.addView(t);
    }

    private TextView chip(String s, boolean on, Runnable r) {
        TextView t = text(s, 11f, on ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        t.setPadding(Theme.dp(host, 11), Theme.dp(host, 8), Theme.dp(host, 11), Theme.dp(host, 8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout.LayoutParams gap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = Theme.dp(host, 6);
        lp.bottomMargin = Theme.dp(host, 6);
        return lp;
    }

    private static String fmt(double p) {
        return String.format(Locale.US, p >= 100 ? "$%,.0f" : p >= 1 ? "$%,.2f" : "$%.4f", p);
    }

    // ------------------------------------------------------------------ build

    private void build() {
        body.removeAllViews();
        market.removeAllViews();
        trade.removeAllViews();

        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("INVEST", 16f, Theme.TEXT);
        title.setLetterSpacing(0.2f);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(chip("< SHOP", false, () -> CoinShop.open(host)));
        body.addView(top);

        body.addView(text("Coins " + Coins.get() + "   Portfolio " + portfolioValue() + "   Net " + signed(netProfit()), 11f, Theme.DIM));
        if (!note.isEmpty()) {
            TextView n = text(note, 11f, Theme.ACCENT);
            n.setPadding(0, Theme.dp(host, 8), 0, 0);
            body.addView(n);
        }

        head(body, "MARKET");
        for (int k = 0; k < IDS.length; k++) {
            market.addView(row(k));
        }
        body.addView(market);

        head(body, "TRADE " + SYMBOLS[sel]);
        String status = ready() ? fmt(price[sel]) + "   " + changeText(change[sel]) : "price loading...";
        body.addView(text(status, 13f, Theme.TEXT));
        double u = units(sel);
        if (u > 0) {
            double value = u * price[sel];
            double c = cost(sel);
            body.addView(text("You hold " + String.format(Locale.US, "%.6f", u) + " " + SYMBOLS[sel]
                    + "   worth " + Math.round(value) + " (" + signed(Math.round(value - c)) + ")", 10f, Theme.DIM));
        } else {
            body.addView(text("You hold none", 10f, Theme.DIM));
        }

        LinearLayout buys = new LinearLayout(host);
        buys.setOrientation(LinearLayout.HORIZONTAL);
        for (final int b : BUYS) {
            buys.addView(chip("BUY " + (b >= 1000 ? (b / 1000) + "K" : String.valueOf(b)), false, () -> buy(b)), gap());
        }
        trade.addView(buys);
        LinearLayout sells = new LinearLayout(host);
        sells.setOrientation(LinearLayout.HORIZONTAL);
        sells.addView(chip("SELL HALF", false, () -> sell(false)), gap());
        sells.addView(chip("SELL ALL", false, () -> sell(true)), gap());
        trade.addView(sells);
        body.addView(trade);

        TextView fine = text("Prices are live market quotes. Trades use your NOVA coins only, no real money. "
                + "This is a game, not financial advice.", 10f, Theme.DIM);
        fine.setPadding(0, Theme.dp(host, 18), 0, 0);
        body.addView(fine);
    }

    private View row(final int k) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        boolean on = k == sel;
        r.setBackground(Theme.rounded(on ? 0x33B39DFF : 0x14FFFFFF, 10f, host));
        r.setPadding(Theme.dp(host, 10), Theme.dp(host, 8), Theme.dp(host, 10), Theme.dp(host, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Theme.dp(host, 6);
        r.setLayoutParams(lp);

        TextView name = text(SYMBOLS[k] + "  " + NAMES[k], 12f, on ? Theme.ACCENT : Theme.TEXT);
        r.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        double u = units(k);
        if (u > 0 && price[k] > 0) {
            r.addView(text("held " + Math.round(u * price[k]) + "  ", 10f, Theme.DIM));
        }
        r.addView(text(price[k] > 0 ? fmt(price[k]) : "--", 11f, Theme.TEXT));
        TextView ch = text(price[k] > 0 ? "  " + changeText(change[k]) : "", 10f,
                change[k] >= 0 ? 0xFF4DFF9A : 0xFFFF6B7F);
        r.addView(ch);
        r.setClickable(true);
        r.setOnClickListener(v -> {
            sel = k;
            Prefs.putInt("inv_sel", k);
            note = "";
            build();
        });
        return r;
    }

    private static String changeText(double c) {
        return String.format(Locale.US, "%s%.2f%%", c >= 0 ? "+" : "", c);
    }

    private static String signed(long v) {
        return (v >= 0 ? "+" : "") + v;
    }

    private static String signed(double v) {
        return signed(Math.round(v));
    }

    private long portfolioValue() {
        long total = 0;
        for (int k = 0; k < IDS.length; k++) {
            if (price[k] > 0) {
                total += Math.round(units(k) * price[k]);
            }
        }
        return total;
    }

    private long netProfit() {
        long total = 0;
        for (int k = 0; k < IDS.length; k++) {
            if (price[k] > 0) {
                total += Math.round(units(k) * price[k] - cost(k));
            }
        }
        return total;
    }
}
