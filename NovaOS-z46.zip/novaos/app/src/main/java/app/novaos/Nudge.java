package app.novaos;

import java.util.Random;

/**
 * The wizard's home-screen suggestions. After you unlock, once enough time has passed, there is a 50% chance he slides
 * the panel to Slots and asks if you want to gamble. If not: games without coins. If not: some music.
 */
final class Nudge {
    private static final Random RND = new Random();
    private static final int[] MINUTES = {0, 5, 60, 720};

    private Nudge() {}

    /** Called when the home screen appears after the lock screen or the startup. */
    static void maybe(final NovaActivity host) {
        int mode = Prefs.nudgeMode();
        if (mode == 0 || !Prefs.wizard() || Prefs.getInt("tip_home", 0) == 0) {
            return;
        }
        int now = (int) (System.currentTimeMillis() / 60000L);
        int last = Prefs.getInt("nudge_last", 0);
        if (last != 0 && now - last < MINUTES[mode]) {
            return;
        }
        Prefs.putInt("nudge_last", now); // the 50% roll counts as this period's turn
        if (RND.nextBoolean()) {
            return;
        }
        host.postHome(() -> slots(host), 4200);
    }

    /** Admin: run the whole suggestion chain right now. */
    static void force(NovaActivity host) {
        slots(host);
    }

    private static boolean ok(NovaActivity host) {
        return host.homeIdle() && host.wizardView() != null && host.home() != null;
    }

    private static void slots(final NovaActivity host) {
        if (!ok(host) || !host.home().panelTo(StatusPanel.SLOTS)) {
            return;
        }
        host.postHome(() -> {
            if (!ok(host)) {
                return;
            }
            host.wizardView().ask("Wanna gamble? 🎰",
                    () -> host.wizardSay("Good luck! Pull the lever."),
                    () -> games(host));
        }, 900);
    }

    private static void games(final NovaActivity host) {
        if (!ok(host) || !host.home().panelTo(StatusPanel.GAMES)) {
            return;
        }
        host.postHome(() -> {
            if (!ok(host)) {
                return;
            }
            host.wizardView().ask("Or without the coins? 🎮",
                    () -> host.wizardSay("Pick a game!"),
                    () -> music(host));
        }, 900);
    }

    private static void music(final NovaActivity host) {
        if (!ok(host) || !host.home().panelTo(StatusPanel.MUSIC)) {
            return;
        }
        host.postHome(() -> {
            if (!ok(host)) {
                return;
            }
            host.wizardView().ask("What about some music? 🎵",
                    () -> HeadphonePrompt.askMood(host),
                    () -> host.wizardSay("Alright, I'll be in my castle if you need me."));
        }, 900);
    }
}
