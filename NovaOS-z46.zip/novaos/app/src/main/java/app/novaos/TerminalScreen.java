package app.novaos;

import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A command line for your phone. Type an app name to open it, or try "help". */
final class TerminalScreen extends LinearLayout {
    private static final String HELP =
            "help        this list\n"
            + "neofetch    system info\n"
            + "apps        list installed apps\n"
            + "open <x>    open an app (or just type its name)\n"
            + "timer 10m   start a timer (90s, 1h30m, 25)\n"
            + "alarm 7:30  set an alarm (also 7pm, 19:45)\n"
            + "notes       open notes\n"
            + "lock        lock screen\n"
            + "home        back to home\n"
            + "time        current time\n"
            + "battery     battery level\n"
            + "calc 2+3*4  calculator (sqrt, sin, pi, 5%, !)\n"
            + "weather <x> weather for a city\n"
            + "history     commands you typed\n"
            + "clear       clear the screen\n"
            + "\nfun:\n"
            + "matrix      you know what this is\n"
            + "hack nasa   totally real hacking\n"
            + "8ball <q>   ask the magic 8 ball\n"
            + "roll d20    roll dice (2d6, d100...)\n"
            + "coin        flip a coin\n"
            + "fortune     a wise sentence\n"
            + "\nkeys: use the UP / DOWN / TAB buttons for\nhistory and completion.\n";

    private static final String[] COMMANDS = {
        "help", "neofetch", "apps", "open", "timer", "alarm", "notes", "lock", "home", "android",
        "time", "battery", "history", "clear", "matrix", "hack", "8ball", "roll", "coin", "fortune",
        "echo", "whoami", "calc", "weather"
    };

    private static final String[] EIGHT = {
        "It is certain.", "Without a doubt.", "Yes, definitely.", "You may rely on it.",
        "As I see it, yes.", "Most likely.", "Outlook good.", "Signs point to yes.",
        "Reply hazy, try again.", "Ask again later.", "Better not tell you now.", "Cannot predict now.",
        "Concentrate and ask again.", "Don't count on it.", "My reply is no.", "My sources say no.",
        "Outlook not so good.", "Very doubtful.", "Ask your phone. Oh wait, that's me.", "Yes, but touch grass first."
    };

    private static final String[] FORTUNES = {
        "The best time to close the 14th tab was an hour ago.",
        "A watched battery drains slower. This is a lie.",
        "You will soon find the thing you are holding.",
        "Today's lucky number is 7. Tomorrow's is also 7.",
        "It works on my phone.",
        "There is no cloud. It's just someone else's computer.",
        "Turn it off and on again. Then be kind to yourself.",
        "99 little bugs in the code, take one down, patch it around, 127 bugs in the code.",
        "Never trust a launcher that tells you it has no bugs.",
        "The user is always right, unless it's about the battery percentage.",
        "A smooth animation is worth a thousand log lines.",
        "He who sorts his apps alphabetically sleeps well.",
        "Your next idea is better than your current one. Write it down.",
        "Real programmers count from zero. Real phones count from 1% and panic.",
        "Weeks of coding can save you hours of planning.",
        "The best code is the code you don't have to write.",
        "May your builds be green and your merges fast-forward.",
        "Sudo make me a sandwich. No. Make it yourself.",
        "You are one swipe away from a great idea.",
        "Don't panic. Also don't tell the battery it's 1%."
    };

    private final NovaActivity host;
    private final ScrollView scroll;
    private final TextView out;
    private final EditText input;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final List<String> history = new ArrayList<>();
    private int histPos;
    private String lastCandidates = "";
    private boolean hacking;

    TerminalScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 16);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        String saved = Prefs.getString("term_hist", "");
        if (!saved.isEmpty()) {
            history.addAll(Arrays.asList(saved.split("\n")));
        }
        histPos = history.size();

        out = new TextView(host);
        out.setTypeface(Theme.MONO);
        out.setTextSize(12.5f);
        out.setTextColor(Theme.TEXT);
        out.setLineSpacing(0f, 1.15f);

        scroll = new ScrollView(host);
        scroll.addView(out);
        addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // history and completion keys, since a phone keyboard has no arrow or tab keys
        LinearLayout keys = new LinearLayout(host);
        keys.setGravity(Gravity.END);
        keys.addView(keyButton("UP", v -> historyStep(-1)));
        keys.addView(keyButton("DOWN", v -> historyStep(1)));
        keys.addView(keyButton("TAB", v -> complete()));
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        kp.topMargin = Theme.dp(host, 6);
        addView(keys, kp);

        LinearLayout row = new LinearLayout(host);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        row.setPadding(Theme.dp(host, 14), 0, Theme.dp(host, 8), 0);

        TextView prompt = new TextView(host);
        prompt.setText("$");
        prompt.setTypeface(Theme.MONO);
        prompt.setTextSize(15f);
        prompt.setTextColor(Theme.ACCENT);
        prompt.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.addView(prompt, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));

        input = new EditText(host);
        input.setTypeface(Theme.MONO);
        input.setTextSize(14f);
        input.setTextColor(Theme.TEXT);
        input.setHint("type a command");
        input.setHintTextColor(Theme.DIM);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setPadding(Theme.dp(host, 10), Theme.dp(host, 14), Theme.dp(host, 10), Theme.dp(host, 14));
        row.addView(input, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Theme.dp(host, 6);
        addView(row, rlp);

        print(Theme.OS_NAME + " terminal. type 'help' for commands.\n\n");

        input.setOnEditorActionListener((v, actionId, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_DONE || enter) {
                String line = input.getText().toString();
                input.setText("");
                run(line);
                return true;
            }
            return false;
        });
        // a real keyboard: arrows and tab work too
        input.setOnKeyListener((v, keyCode, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) {
                return false;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                historyStep(-1);
                return true;
            } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                historyStep(1);
                return true;
            } else if (keyCode == KeyEvent.KEYCODE_TAB) {
                complete();
                return true;
            }
            return false;
        });

        input.requestFocus();
        postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager)
                    host.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showSoftInput(input, 0);
            }
        }, 250);
    }

    private TextView keyButton(String label, OnClickListener click) {
        TextView b = new TextView(host);
        b.setText(label);
        b.setTypeface(Theme.MONO);
        b.setTextSize(11f);
        b.setLetterSpacing(0.12f);
        b.setTextColor(Theme.ACCENT);
        b.setGravity(Gravity.CENTER);
        b.setPadding(Theme.dp(host, 14), Theme.dp(host, 8), Theme.dp(host, 14), Theme.dp(host, 8));
        b.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
        b.setClickable(true);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = Theme.dp(host, 6);
        b.setLayoutParams(p);
        return b;
    }

    private void print(String s) {
        out.append(s);
        scroll.post(() -> scroll.fullScroll(FOCUS_DOWN));
    }

    // ------------------------------------------------------------------ history and completion

    private void historyStep(int dir) {
        if (history.isEmpty()) {
            return;
        }
        histPos = Math.max(0, Math.min(history.size(), histPos + dir));
        String text = histPos >= history.size() ? "" : history.get(histPos);
        input.setText(text);
        input.setSelection(text.length());
    }

    private void remember(String cmd) {
        if (history.isEmpty() || !history.get(history.size() - 1).equals(cmd)) {
            history.add(cmd);
        }
        while (history.size() > 50) {
            history.remove(0);
        }
        histPos = history.size();
        StringBuilder sb = new StringBuilder();
        for (String h : history) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(h);
        }
        Prefs.putString("term_hist", sb.toString());
    }

    /** Completes a command or app name. One match fills it in, several fill the shared start and list them. */
    private void complete() {
        String text = input.getText().toString();
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<>();
        boolean isCommand = false;
        if (lower.startsWith("open ")) {
            String q = lower.substring(5).trim();
            for (AppEntry e : host.repo.all) {
                if (e.label.toLowerCase(Locale.ROOT).startsWith(q)) {
                    matches.add("open " + e.label);
                }
            }
        } else if (!lower.contains(" ") && !lower.isEmpty()) {
            for (String c : COMMANDS) {
                if (c.startsWith(lower)) {
                    matches.add(c);
                    isCommand = true;
                }
            }
            for (AppEntry e : host.repo.all) {
                if (e.label.toLowerCase(Locale.ROOT).startsWith(lower)) {
                    matches.add(e.label);
                }
            }
        }
        if (matches.isEmpty()) {
            return;
        }
        String fill;
        if (matches.size() == 1) {
            fill = matches.get(0) + (isCommand ? " " : "");
        } else {
            fill = commonPrefix(matches);
            String list = String.join("   ", matches.subList(0, Math.min(14, matches.size())));
            if (!list.equals(lastCandidates)) {
                lastCandidates = list;
                print(list + "\n");
            }
            if (fill.length() <= text.length()) {
                fill = text;
            }
        }
        input.setText(fill);
        input.setSelection(fill.length());
    }

    private static String commonPrefix(List<String> l) {
        String p = l.get(0);
        for (String s : l) {
            int i = 0;
            while (i < p.length() && i < s.length()
                    && Character.toLowerCase(p.charAt(i)) == Character.toLowerCase(s.charAt(i))) {
                i++;
            }
            p = p.substring(0, i);
        }
        return p;
    }

    // ------------------------------------------------------------------ commands

    private void run(String line) {
        String cmd = line.trim();
        print((cmd.toLowerCase(Locale.ROOT).startsWith("admin ") ? "$ admin ******" : "$ " + cmd) + "\n");
        if (cmd.isEmpty()) {
            return;
        }
        String[] parts = cmd.split("\\s+", 2);
        String name = parts[0].toLowerCase(Locale.ROOT);
        String arg = parts.length > 1 ? parts[1].trim() : "";
        if (!name.equals("admin")) {
            remember(cmd);
        }
        String adminOut = Admin.command(host, name, arg);
        if (adminOut != null) {
            print(adminOut);
            return;
        }

        switch (name) {
            case "help":
                print(HELP + "\n");
                break;
            case "clear":
                out.setText("");
                break;
            case "neofetch":
            case "info":
                print(fetch() + "\n");
                break;
            case "apps": {
                StringBuilder sb = new StringBuilder();
                for (AppEntry e : host.repo.all) {
                    sb.append(e.label).append("\n");
                }
                print(sb.append("\n").toString());
                break;
            }
            case "open":
                openApp(arg);
                break;
            case "notes":
                host.showNotes();
                break;
            case "lock":
                host.showLock();
                break;
            case "home":
            case "exit":
                host.showHome();
                break;
            case "android":
                print("opening Android's home app setting...\n\n");
                host.openHomeSettings();
                break;
            case "time":
                print(new SimpleDateFormat("EEEE d MMMM yyyy, HH:mm:ss", Locale.getDefault())
                        .format(new Date()) + "\n\n");
                break;
            case "battery": {
                int l = host.batteryLevel();
                print((l < 0 ? "unknown" : l + "%" + (host.charging() ? " (charging)" : "")) + "\n\n");
                break;
            }
            case "history": {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < history.size(); i++) {
                    sb.append(String.format(Locale.US, "%3d  %s\n", i + 1, history.get(i)));
                }
                print(sb.append("\n").toString());
                break;
            }
            case "timer":
                timer(arg);
                break;
            case "alarm":
                alarm(arg);
                break;
            case "matrix":
                print("wake up...\n\n");
                host.showOverlay(new MatrixRain(host));
                break;
            case "hack":
                hack(arg.isEmpty() ? "the mainframe" : arg);
                break;
            case "8ball":
                if (arg.isEmpty()) {
                    print("ask a question first. usage: 8ball will it work?\n\n");
                } else {
                    print("🎱  " + EIGHT[rnd.nextInt(EIGHT.length)] + "\n\n");
                }
                break;
            case "roll":
                roll(arg);
                break;
            case "coin":
                print((rnd.nextBoolean() ? "heads" : "tails") + "\n\n");
                break;
            case "fortune":
                print(FORTUNES[rnd.nextInt(FORTUNES.length)] + "\n\n");
                break;
            case "whoami":
                print("you\n\n");
                break;
            case "calc":
                if (arg.isEmpty()) {
                    print("usage: calc 2+3*4   (also sqrt(16), sin(30), 5%, 4!, pi)\n\n");
                } else {
                    try {
                        print("= " + Expr.format(Expr.eval(arg)) + "\n\n");
                    } catch (IllegalArgumentException e) {
                        print("calc: " + e.getMessage() + "\n\n");
                    }
                }
                break;
            case "weather":
                weather(arg);
                break;
            case "sudo":
                print("nice try. you are not in the sudoers file. this incident will be reported (to nobody).\n\n");
                break;
            case "echo":
                print(arg + "\n\n");
                break;
            default:
                openApp(cmd);
                break;
        }
    }

    /** weather <city>, or just "weather" for the city set on the weather page. */
    private void weather(final String city) {
        if (city.isEmpty() && !WeatherData.hasCity()) {
            print("usage: weather zurich\n\n");
            return;
        }
        print("looking up the weather...\n");
        new Thread(() -> {
            final String text;
            if (city.isEmpty()) {
                WeatherData.Place p = new WeatherData.Place();
                p.name = WeatherData.city();
                try {
                    p.lat = Double.parseDouble(Prefs.getString("w_lat", "0"));
                    p.lon = Double.parseDouble(Prefs.getString("w_lon", "0"));
                } catch (NumberFormatException e) {
                    p.lat = 0;
                    p.lon = 0;
                }
                String r = WeatherData.report(p);
                text = r == null ? "no connection\n" : r;
            } else {
                WeatherData.Place p = WeatherData.geocode(city);
                if (p == null) {
                    text = "city not found (or no connection)\n";
                } else {
                    String r = WeatherData.report(p);
                    text = r == null ? "no connection\n" : r;
                }
            }
            post(() -> print(text + "\n"));
        }).start();
    }

    // ---- timer and alarm go through Android's own clock app, so they survive NOVA closing

    private static final Pattern PART = Pattern.compile("(\\d+)\\s*([hms]?)");

    private void timer(String arg) {
        if (arg.isEmpty()) {
            print("usage: timer 10m   (also 90s, 1h30m, or just 25 for minutes)\n\n");
            return;
        }
        Matcher m = PART.matcher(arg.toLowerCase(Locale.ROOT));
        long secs = 0;
        boolean any = false;
        while (m.find()) {
            long n = Long.parseLong(m.group(1));
            String u = m.group(2);
            secs += u.equals("h") ? n * 3600 : u.equals("s") ? n : n * 60;
            any = true;
        }
        if (!any || secs <= 0 || secs > 86400) {
            print("that does not look like a time. try: timer 10m\n\n");
            return;
        }
        String shown = (secs >= 3600 ? (secs / 3600) + "h " : "") + ((secs % 3600) / 60) + "m " + (secs % 60) + "s";
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, (int) secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA timer")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            host.startActivity(i);
            print("timer set: " + shown + "\n\n");
        } catch (Exception e) {
            // no clock app that takes timers: count down inside NOVA instead
            print("no clock app found, counting down here: " + shown + "\n\n");
            handler.postDelayed(() -> {
                print("\n*** TIMER DONE: " + shown + " ***\n\n");
                host.buzz(600);
            }, secs * 1000L);
        }
    }

    private void alarm(String arg) {
        Matcher m = Pattern.compile("^(\\d{1,2})(?::?(\\d{2}))?\\s*(am|pm)?$").matcher(arg.toLowerCase(Locale.ROOT));
        if (!m.matches()) {
            print("usage: alarm 7:30   (also 7pm, 19:45, 0630)\n\n");
            return;
        }
        int h = Integer.parseInt(m.group(1));
        int min = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
        String ap = m.group(3);
        if (ap != null) {
            if (h < 1 || h > 12) {
                print("12-hour times go from 1 to 12.\n\n");
                return;
            }
            h = h % 12 + (ap.equals("pm") ? 12 : 0);
        }
        if (h > 23 || min > 59) {
            print("that is not a real time.\n\n");
            return;
        }
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA alarm")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            host.startActivity(i);
            print(String.format(Locale.US, "alarm set for %02d:%02d\n\n", h, min));
        } catch (Exception e) {
            print("no clock app found that can set alarms.\n\n");
        }
    }

    // ---- the fun ones

    private void roll(String arg) {
        Matcher m = Pattern.compile("^(\\d*)d(\\d+)$").matcher(arg.toLowerCase(Locale.ROOT).replace(" ", ""));
        int count = 1;
        int sides = 6;
        if (!arg.isEmpty()) {
            if (!m.matches()) {
                print("usage: roll d20   (also 2d6, d100)\n\n");
                return;
            }
            count = m.group(1).isEmpty() ? 1 : Integer.parseInt(m.group(1));
            sides = Integer.parseInt(m.group(2));
        }
        if (count < 1 || count > 20 || sides < 2 || sides > 1000) {
            print("keep it between 1-20 dice and 2-1000 sides.\n\n");
            return;
        }
        StringBuilder sb = new StringBuilder();
        int total = 0;
        for (int i = 0; i < count; i++) {
            int r = 1 + rnd.nextInt(sides);
            total += r;
            sb.append(i > 0 ? " + " : "").append(r);
        }
        String extra = "";
        if (count == 1 && sides == 20) {
            extra = total == 20 ? "   NATURAL 20!" : total == 1 ? "   critical fail..." : "";
        }
        print("rolled " + (count > 1 ? count : "") + "d" + sides + ": "
                + (count > 1 ? sb + " = " + total : String.valueOf(total)) + extra + "\n\n");
    }

    /** A pretend hacking scene, line by line. It does nothing, of course. */
    private void hack(String target) {
        if (hacking) {
            print("already hacking. be patient.\n\n");
            return;
        }
        hacking = true;
        String t = target.toLowerCase(Locale.ROOT);
        String[] script = {
            "connecting to " + t + " ...",
            "resolving 3 proxies ... ok",
            "bypassing firewall  [##        ] 20%",
            "bypassing firewall  [#####     ] 50%",
            "bypassing firewall  [########  ] 80%",
            "bypassing firewall  [##########] 100%",
            "trying admin password: 'password123' ... nope",
            "trying admin password: 'hunter2' ... nope",
            "trying admin password: 'admin' ... ACCESS GRANTED",
            "downloading secrets [###       ] 30%",
            "downloading secrets [#######   ] 70%",
            "downloading secrets [##########] 100%",
            "found: 1 (one) sandwich recipe, 4 unread emails and a cat photo",
            "",
            "just kidding. i'm a phone launcher. i hack nothing. :)",
            ""
        };
        long delay = 0;
        for (int i = 0; i < script.length; i++) {
            final String line = script[i];
            final boolean last = i == script.length - 1;
            delay += i < 2 ? 450 : 330 + rnd.nextInt(260);
            handler.postDelayed(() -> {
                print(line + "\n");
                if (last) {
                    hacking = false;
                }
            }, delay);
        }
    }

    private void openApp(String query) {
        if (query.isEmpty()) {
            print("usage: open <app name>\n\n");
            return;
        }
        List<AppEntry> r = host.repo.search(query);
        if (r.isEmpty()) {
            print("not found: " + query + "  (type help)\n\n");
            return;
        }
        print("opening " + r.get(0).label + "\n\n");
        host.launch(r.get(0));
    }

    private String fetch() {
        long sec = SystemClock.elapsedRealtime() / 1000L;
        String up = (sec / 3600) + "h " + ((sec % 3600) / 60) + "m";
        int bat = host.batteryLevel();
        android.util.DisplayMetrics dm = host.getResources().getDisplayMetrics();
        String kernel = System.getProperty("os.version");

        String[] art = {
            "    *     ",
            "  . ' .   ",
            " - NOVA - ",
            "  ' . '   ",
            "    *     ",
            "          ",
            "          ",
            "          ",
            "          "
        };
        String[] info = {
            "nova@" + Build.MODEL.toLowerCase(Locale.ROOT).replace(' ', '-'),
            "----------------",
            "OS      " + Theme.OS_NAME + " " + Theme.OS_VERSION + " on Android " + Build.VERSION.RELEASE,
            "Host    " + Build.MANUFACTURER + " " + Build.MODEL,
            "Kernel  " + (kernel == null ? "linux" : kernel),
            "Uptime  " + up,
            "Apps    " + host.repo.all.size(),
            "Screen  " + dm.widthPixels + "x" + dm.heightPixels,
            "Battery " + (bat < 0 ? "unknown" : bat + "%")
        };
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < info.length; i++) {
            sb.append(art[i]).append("  ").append(info[i]).append("\n");
        }
        return sb.toString();
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
