package app.novaos;

/**
 * A whole roast pig in pixel art: golden crackling skin, an apple in the mouth, tied trotters and a sprig of parsley.
 * Pure Java so it can be previewed on a desktop. Faces right. W x H pixels.
 */
final class PigSprite {
    static final int W = 30, H = 18;

    private PigSprite() {}

    private static int rgb(int r, int g, int b) {
        return 0xFF000000 | (Math.max(0, Math.min(255, r)) << 16) | (Math.max(0, Math.min(255, g)) << 8)
                | Math.max(0, Math.min(255, b));
    }

    private static int hash(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= h >>> 13;
        return (h * 1274126177 >>> 8) & 0xFFFF;
    }

    static int[] render() {
        int[] px = new int[W * H];
        final int outline = rgb(58, 24, 10);
        final int deep = rgb(150, 70, 24);
        final int mid = rgb(204, 112, 40);
        final int gold = rgb(232, 150, 58);
        final int hi = rgb(250, 196, 104);
        final int shine = rgb(255, 232, 160);
        final int pink = rgb(236, 168, 140);
        final int pinkDk = rgb(190, 112, 96);
        // body: a long oval, lit from above
        double bcx = 12.5;
        double bcy = 8.8;
        double brx = 11.2;
        double bry = 5.6;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                double dx = (x + 0.5 - bcx) / brx;
                double dy = (y + 0.5 - bcy) / bry;
                double d = dx * dx + dy * dy;
                if (d <= 1.0) {
                    double v = dy;                       // -1 top .. 1 bottom
                    boolean chk = ((x + y) & 1) == 0;
                    int c;
                    if (v < -0.62 && dx < 0.5) {
                        c = chk ? shine : hi;
                    } else if (v < -0.25) {
                        c = chk ? hi : gold;
                    } else if (v < 0.25) {
                        c = chk ? gold : mid;
                    } else if (v < 0.55) {
                        c = chk ? mid : deep;
                    } else {
                        c = deep;
                    }
                    // crackling: little dark flecks
                    int h = hash(x, y) % 17;
                    if (h == 0 && v > -0.5) {
                        c = deep;
                    } else if (h == 1 && v < 0.2) {
                        c = hi;
                    }
                    px[y * W + x] = c;
                }
            }
        }
        // head: a little brighter than the body so it stands out, with a dark crease at the neck
        double hcx = 23.4;
        double hcy = 9.2;
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                double dx = (x + 0.5 - hcx) / 4.1;
                double dy = (y + 0.5 - hcy) / 3.9;
                double d = dx * dx + dy * dy;
                if (d <= 1.0) {
                    boolean chk = ((x + y) & 1) == 0;
                    int c = dy < -0.45 ? (chk ? shine : hi) : dy < 0.25 ? (chk ? hi : gold) : (chk ? gold : mid);
                    if (d > 0.62 && dx < -0.2) {
                        c = deep;                       // the crease between head and body
                    }
                    px[y * W + x] = c;
                }
            }
        }
        // snout and nostrils, ear, eye
        box(px, 26, 7, 4, 4, pink);
        box(px, 26, 10, 4, 1, pinkDk);
        px[8 * W + 28] = outline;
        px[9 * W + 28] = outline;
        box(px, 20, 2, 3, 3, mid);          // ear, pointing up and back
        box(px, 21, 3, 1, 2, pink);
        box(px, 19, 3, 1, 2, deep);
        box(px, 24, 6, 2, 2, outline);       // eye with a glint
        px[6 * W + 24] = rgb(255, 255, 255);
        // apple in the mouth
        box(px, 24, 12, 4, 4, rgb(200, 40, 40));
        px[12 * W + 25] = rgb(255, 130, 120);
        px[13 * W + 25] = rgb(255, 130, 120);
        box(px, 27, 14, 1, 2, rgb(140, 20, 24));
        px[11 * W + 26] = rgb(70, 140, 50);
        px[11 * W + 27] = rgb(90, 170, 60);
        // trotters, tied together with string
        box(px, 3, 13, 3, 3, deep);
        box(px, 3, 15, 3, 1, outline);
        box(px, 17, 13, 3, 3, deep);
        box(px, 17, 15, 3, 1, outline);
        box(px, 8, 14, 3, 2, mid);
        box(px, 13, 14, 3, 2, mid);
        box(px, 2, 12, 4, 1, rgb(214, 190, 120));
        box(px, 16, 12, 4, 1, rgb(214, 190, 120));
        // curly tail
        px[5 * W + 1] = gold;
        px[4 * W + 1] = gold;
        px[3 * W + 2] = gold;
        px[3 * W + 3] = mid;
        // parsley on the back
        int g1 = rgb(84, 170, 60);
        int g2 = rgb(52, 120, 40);
        box(px, 9, 2, 2, 2, g1);
        box(px, 11, 1, 2, 2, g2);
        box(px, 13, 2, 2, 2, g1);
        box(px, 11, 3, 2, 1, g2);
        // outline
        int[] out = px.clone();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (px[y * W + x] != 0) {
                    continue;
                }
                boolean near = (x > 0 && px[y * W + x - 1] != 0) || (x < W - 1 && px[y * W + x + 1] != 0)
                        || (y > 0 && px[(y - 1) * W + x] != 0) || (y < H - 1 && px[(y + 1) * W + x] != 0);
                if (near) {
                    out[y * W + x] = outline;
                }
            }
        }
        return out;
    }

    private static void box(int[] px, int x, int y, int w, int h, int c) {
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                if (x + i >= 0 && x + i < W && y + j >= 0 && y + j < H) {
                    px[(y + j) * W + x + i] = c;
                }
            }
        }
    }
}
