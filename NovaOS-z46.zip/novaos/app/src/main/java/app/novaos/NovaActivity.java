package app.novaos;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.projection.MediaProjectionManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The whole OS lives in this one activity. Because it declares the HOME category,
 * Android offers it as a home app, and when it is the default one Android starts it
 * at boot and whenever you press the home button.
 */
@SuppressWarnings("deprecation")
public class NovaActivity extends Activity {
    static final int BOOT = 0;
    static final int LOCK = 1;
    static final int HOME = 2;
    static final int DRAWER = 3;
    static final int TERMINAL = 4;
    static final int NOTES = 5;
    static final int SETTINGS = 6;

    private static final int REQ_HOME = 77;
    private static final int MAX_FAVS = 20;

    FrameLayout root;
    AppRepo repo;
    SharedPreferences prefs;
    int screen = -1;
    private boolean needLock = false;
    private Shade shade;
    private float shadeStartY;
    private boolean shadeArmed;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            needLock = true;
        }
    };

    /** Writes the battery level into the day log whenever Android reports a change. */
    private final BroadcastReceiver batteryRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (i == null) {
                return;
            }
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            if (scale > 0) {
                BatteryLog.record(prefs, level * 100 / scale, chg);
            }
        }
    };

    private final BroadcastReceiver pkgChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            repo.markDirty();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Prefs.init(this);
        CrashLog.install(this);
        Sfx.init(this);
        Theme.load();
        prefs = getSharedPreferences("nova", MODE_PRIVATE);
        repo = new AppRepo(this);

        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        root = new FrameLayout(this);
        root.setBackground(Theme.background());
        // Keeps the keyboard from covering the terminal and notes.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                bottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });
        setContentView(root);
        goImmersive();

        reg(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
        reg(batteryRx, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_CHANGED);
        pf.addDataScheme("package");
        reg(pkgChanged, pf);

        if (bootChanged()) {
            showBoot(false);
        } else {
            showLock();
        }
    }

    private void reg(BroadcastReceiver r, IntentFilter f) {
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(r, f);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(screenOff);
            unregisterReceiver(pkgChanged);
            unregisterReceiver(batteryRx);
        } catch (Exception ignored) {
            // already unregistered
        }
        super.onDestroy();
    }

    private View tintView;

    /** A warm filter over everything, for the evening. */
    void applyTint() {
        boolean want = Prefs.getBool("s_tint", false);
        if (want && tintView == null && root != null) {
            tintView = new View(this);
            tintView.setTag(KEEP);
            tintView.setBackgroundColor(0x2AFF8A1A);
            tintView.setClickable(false);
            tintView.setElevation(90f);
            root.addView(tintView, new FrameLayout.LayoutParams(-1, -1));
        } else if (!want && tintView != null) {
            root.removeView(tintView);
            tintView = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        NovaNotificationService.flashListener = () -> root.post(this::edgeFlash);
        syncWizard();
        root.removeCallbacks(idleCheck);
        root.postDelayed(idleCheck, 10000);
        if (!crashChecked) {
            crashChecked = true;
            root.postDelayed(() -> CrashLog.showPending(this), 1200);
            CrashLog.guard(this);
            root.postDelayed(() -> Changelog.showIfNew(this), 3500);
            if (Prefs.getInt("adm_fps", 0) == 1 && Admin.on()) {
                AdminPanel.fps(this, true);
            }
        }
        if (Theme.nightApplied != Upgrades.nightNow()) {
            Theme.load();
            recreate();
            return;
        }
        root.postDelayed(() -> {
            if (screen == HOME) {
                Upgrades.collectMine(this);
            }
        }, 2600);
        applyTint();
        Badges.check(this);
        QuietHours.apply(this);
        syncVoice();
        if (shake == null) {
            shake = new ShakeDetector(this, () -> root.post(this::shakeCoin));
        }
        if (Prefs.shakeCoin() && !Saver.on()) {
            shake.start();
        } else {
            shake.stop();
        }
        AudioManager hpAm = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (hpAm != null) {
            if (hpCallback == null) {
                hpCallback = HeadphonePrompt.callback(this);
            }
            hpAm.registerAudioDeviceCallback(hpCallback, null);
        }
        if (needLock) {
            needLock = false;
            if (screen != BOOT && screen != LOCK) {
                showLock();
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing the phone's home button lands here.
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME)
                && screen != LOCK && screen != BOOT) {
            showHome();
        }
    }

    @Override
    public void onBackPressed() {
        if (overlay instanceof BackAware && ((BackAware) overlay).onBack()) {
            return;
        }
        if (hideOverlay()) {
            return;
        }
        // A home screen never closes itself. Back goes up one level instead.
        if (screen == DRAWER || screen == TERMINAL || screen == NOTES || screen == SETTINGS) {
            showHome();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            goImmersive();
        }
    }

    /** Hides Android's status bar and navigation bar so only NOVA is visible. */
    private void goImmersive() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ---------------------------------------------------------------- screens

    private void show(View v, int which) {
        hideKeyboard();
        screen = which;
        shade = null;
        overlay = null;
        root.setBackground(Theme.background());
        // the screen we are leaving fades and drifts away while the new one settles in
        // one continuous move: the old screen fades out while the new one fades in, no pause in between
        android.view.animation.Interpolator ease = new android.view.animation.AccelerateDecelerateInterpolator();
        for (int i = root.getChildCount() - 1; i >= 0; i--) {
            final View old = root.getChildAt(i);
            if (KEEP.equals(old.getTag())) {
                continue; // the wizard, his bubble and the like stay across screens
            }
            old.setClickable(false);
            old.animate().cancel();
            old.animate().alpha(0f).scaleX(1.02f).scaleY(1.02f).setDuration(560)
                    .setInterpolator(ease)
                    .withEndAction(() -> root.removeView(old)).start();
        }
        v.setAlpha(0f);
        v.setScaleX(0.98f);
        v.setScaleY(0.98f);
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(560)
                .setInterpolator(ease).start();
        keepOnTop();
        syncWizard();
        final int shown = which;
        root.postDelayed(() -> {
            if (screen == shown) {
                Tips.screen(this, shown);
            }
        }, shown == HOME ? 3500 : 1200);
    }

    private long lastTouch = android.os.SystemClock.elapsedRealtime();
    private boolean nightOn;
    private boolean saverWas;
    private boolean cheered;
    private boolean lowSaid;
    private long hungrySaid;

    /** The wizard comments on what the phone is doing: late at night, a full battery, a hungry pet. */
    private void reactions() {
        if (!Prefs.reactions() || wizard == null || !homeIdle()) {
            return;
        }
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int hour = cal.get(java.util.Calendar.HOUR_OF_DAY);
        int dayKey = cal.get(java.util.Calendar.YEAR) * 1000 + cal.get(java.util.Calendar.DAY_OF_YEAR);
        if (hour >= 2 && hour < 5 && Prefs.getInt("wiz_yawn", 0) != dayKey) {
            Prefs.putInt("wiz_yawn", dayKey);
            wizardSay("*yawn* It is past " + hour + "am... Even wizards need sleep.");
            return;
        }
        int level = batteryLevel();
        if (charging() && level >= 100 && !cheered) {
            cheered = true;
            wizardSay("100%! Full power! \u26A1");
            return;
        }
        if (!charging() && level < 100) {
            cheered = false;
        }
        if (!charging() && level >= 0 && level <= 15 && !lowSaid) {
            lowSaid = true;
            wizardSay("Your battery is nearly empty. Find a charger, traveller!");
            return;
        }
        if (level > 30 || charging()) {
            lowSaid = false;
        }
        if (Pets.kind() != Pets.NONE && Pets.food() < 20
                && System.currentTimeMillis() - hungrySaid > 3_600_000L) {
            hungrySaid = System.currentTimeMillis();
            wizardSay("Your " + Pets.NAMES[Pets.kind()].toLowerCase() + " is hungry. Feed it on the PET page!");
        }
    }

    private final Runnable idleCheck = new Runnable() {
        @Override
        public void run() {
            reactions();
            boolean saving = Saver.on();
            if (saving != saverWas) {
                saverWas = saving;
                if (shake != null) {
                    if (saving || !Prefs.shakeCoin()) {
                        shake.stop();
                    } else {
                        shake.start();
                    }
                }
                syncVoice();
                toast(saving ? "Battery saver on: animations paused" : "Battery saver off");
            }
            if (Prefs.nightClock() && !nightOn && screen == HOME && overlay == null && shade == null && charging()
                    && android.os.SystemClock.elapsedRealtime() - lastTouch > 75000) {
                nightOn = true;
                if (wizard != null) {
                    wizard.setVisibility(View.GONE);
                }
                root.addView(new NightClock(NovaActivity.this), new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            root.postDelayed(this, 10000);
        }
    };

    /** The charging clock closed: back to normal. */
    void nightClockGone() {
        nightOn = false;
        lastTouch = android.os.SystemClock.elapsedRealtime();
        syncWizard();
    }

    private WizardView wizard;
    /** The castle on the home screen, while it is showing. */
    CastleView castle;
    EventLayer eventLayer;

    void dropPig() {
        if (eventLayer != null) {
            eventLayer.dropPig();
        }
    }
    /** True while the wizard is at home inside his castle. */
    boolean wizInside = true;

    /** The castle was tapped: the wizard comes out, or goes back in. */
    void castleTapped() {
        if (wizard == null) {
            return;
        }
        buzz(14);
        Sfx.play(Sfx.BLIP);
        Quests.event(this, "castle");
        if (eventLayer != null && Prefs.eventsOn() && !Saver.on() && new java.util.Random().nextInt(7) == 0) {
            eventLayer.spawnNow(new java.util.Random().nextBoolean() ? 0 : 1);
        }
        if (wizInside) {
            wizard.emerge();
            root.postDelayed(() -> Tips.discover(this, "castle"), 2600);
        } else {
            wizard.goHome();
        }
    }

    /** Shows or hides the wizard to match the setting and the current screen. */
    void syncWizard() {
        if (Prefs.wizard()) {
            if (wizard == null) {
                wizard = new WizardView(this);
                root.addView(wizard, wizard.params());
            }
            wizard.setVisibility(screen == LOCK || screen == BOOT ? View.GONE : View.VISIBLE);
            for (int sl = 0; sl < 2; sl++) {
                boolean want = Pets.hasBody(sl) && (sl == 0 || Castle.has(7));
                if (want) {
                    if (pets[sl] == null) {
                        pets[sl] = new PetView(this, sl);
                        root.addView(pets[sl], pets[sl].params());
                    }
                    pets[sl].setVisibility(screen == LOCK || screen == BOOT ? View.GONE : View.VISIBLE);
                } else if (pets[sl] != null) {
                    root.removeView(pets[sl]);
                    pets[sl] = null;
                }
            }
            keepOnTop();
        } else if (wizard != null) {
            wizard.remove();
            root.removeView(wizard);
            wizard = null;
            for (int sl = 0; sl < 2; sl++) {
                if (pets[sl] != null) {
                    root.removeView(pets[sl]);
                    pets[sl] = null;
                }
            }
        }
    }

    private final PetView[] pets = new PetView[2];

    void wizardSay(String text) {
        if (wizard != null && wizard.getVisibility() == View.VISIBLE) {
            wizard.say(text);
        }
    }

    /** The first time you discover something, the wizard explains it. */
    void tip(String id) {
        Tips.discover(this, id);
    }

    /** Views tagged KEEP survive screen changes and always sit above the screens. */
    static final String KEEP = "nova-keep";

    void keepOnTop() {
        List<View> keepers = new ArrayList<>();
        for (int i = 0; i < root.getChildCount(); i++) {
            View c = root.getChildAt(i);
            if (KEEP.equals(c.getTag())) {
                keepers.add(c);
            }
        }
        for (View c : keepers) {
            c.bringToFront();
        }
    }

    private static final int REQ_UPDATE = 78;
    private static final int REQ_CAPTURE = 79;

    // ------------------------------------------------------------- effects and overlays

    private View overlay;

    /** Puts a full-screen view (like the matrix rain) above everything. Back or showing another screen removes it. */
    void showOverlay(View v) {
        hideOverlay();
        overlay = v;
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        keepOnTop();
    }

    boolean hideOverlay() {
        if (overlay == null) {
            return false;
        }
        root.removeView(overlay);
        overlay = null;
        return true;
    }

    /** Confetti pops out of a point on the screen and falls away. */
    void confetti(float x, float y) {
        root.addView(new ConfettiView(this, x, y), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** A short buzz in the style chosen in Settings (off, soft, crisp or strong). Does nothing without a vibrator. */
    void buzz(long ms) {
        int style = Prefs.haptic();
        if (style == 0) {
            return;
        }
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib == null || !vib.hasVibrator()) {
                return;
            }
            VibrationEffect fx;
            switch (style) {
                case 1: // soft: gentle and short
                    fx = VibrationEffect.createOneShot(Math.max(8, ms * 6 / 10), 60);
                    break;
                case 3: // strong: long and at full power
                    if (ms <= 40 && android.os.Build.VERSION.SDK_INT >= 29) {
                        fx = VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK);
                    } else {
                        fx = VibrationEffect.createOneShot(Math.min(140, ms * 3 / 2), 255);
                    }
                    break;
                default: // crisp: a sharp tick, like a mechanical key
                    if (ms <= 40 && android.os.Build.VERSION.SDK_INT >= 29) {
                        fx = VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK);
                    } else {
                        fx = VibrationEffect.createOneShot(ms, 190);
                    }
                    break;
            }
            vib.vibrate(fx);
        } catch (RuntimeException ignored) {
            // no vibration available
        }
    }

    // ------------------------------------------------------------- edge light, quiet hours and voice

    private VoiceControl voice;

    /** Pulses a glowing light around the screen edge. Used for new notifications. */
    void edgeFlash() {
        Sfx.play(Sfx.NOTIFY);
        if (Prefs.critters() && !Saver.on() && root != null && (screen == HOME || screen == DRAWER)
                && root.getWidth() > 0) {
            new CritterView(this, NovaNotificationService.lastKey).start(root);
        }
        if (!Prefs.edgeFlash() || root == null) {
            return;
        }
        root.addView(new EdgeFlash(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private static final int REQ_AUDIO = 81;

    /** Starts or stops "Hey Nova" to match the setting. Asks for the microphone the first time. */
    void syncVoice() {
        if (Prefs.voice() && !Saver.on() && VoiceControl.available(this)) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[] {android.Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                return;
            }
            if (voice == null) {
                voice = new VoiceControl(this);
            }
            voice.start();
            tip("voice");
        } else {
            if (voice != null) {
                voice.stop();
            }
            if (Prefs.voice() && !VoiceControl.available(this)) {
                toast("Speech recognition is not available on this phone");
                Prefs.putBool(Prefs.K_VOICE, false);
            }
        }
    }

    private final android.util.SparseArray<Runnable[]> permCb = new android.util.SparseArray<>();
    private int permSeq;

    boolean has(String perm) {
        return checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /** Runs "granted" now if all the permissions are already there, else asks first. "denied" may be null. */
    void ask(String[] perms, Runnable granted, Runnable denied) {
        boolean all = true;
        for (String p : perms) {
            if (!has(p)) {
                all = false;
            }
        }
        if (all) {
            granted.run();
            return;
        }
        int code = 100 + (permSeq++ % 50);
        permCb.put(code, new Runnable[] {granted, denied});
        requestPermissions(perms, code);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Runnable[] cb = permCb.get(requestCode);
        if (cb != null) {
            permCb.remove(requestCode);
            boolean ok = grantResults.length > 0;
            for (int r : grantResults) {
                if (r != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    ok = false;
                }
            }
            if (ok) {
                cb[0].run();
            } else if (cb[1] != null) {
                cb[1].run();
            }
            return;
        }
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                syncVoice();
            } else {
                Prefs.putBool(Prefs.K_VOICE, false);
                toast("Hey Nova needs the microphone");
            }
        }
    }

    @Override
    protected void onPause() {
        NovaNotificationService.flashListener = null;
        root.removeCallbacks(idleCheck);
        if (shake != null) {
            shake.stop();
        }
        AudioManager hpAm = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (hpAm != null && hpCallback != null) {
            hpAm.unregisterAudioDeviceCallback(hpCallback);
        }
        if (voice != null) {
            voice.stop();
        }
        super.onPause();
    }

    /** Starts or stops recording the screen. Android shows its own "start recording" confirmation first. */
    void toggleRecording() {
        if (RecordService.running) {
            RecordService.stop(this);
            toast("Recording saved to Movies/NOVA");
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            toast("Screen recording is not available");
            return;
        }
        try {
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (Exception e) {
            toast("Screen recording is not available");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_UPDATE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            installApk(data.getData());
        } else if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                RecordService.start(this, resultCode, data);
                toast("Recording started");
            } else {
                toast("Recording cancelled");
            }
        }
    }

    /** Lets you pick a NOVA .apk from your phone and hands it to Android's installer. No GitHub needed. */
    void pickUpdate() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        try {
            startActivityForResult(i, REQ_UPDATE);
        } catch (Exception e) {
            toast("No file picker on this phone");
        }
    }

    void installApk(android.net.Uri uri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Could not start the installer");
        }
    }

    void showAccess(boolean test) {
        show(new AccessScreen(this, test), BOOT);
    }

    void showBoot(boolean quick) {
        show(new BootScreen(this, quick), BOOT);
    }

    /** Swiping the lock screen plays the quick startup (if on), then opens home. */
    void unlock() {
        armIntro();
        Prefs.incUnlocks();
        beep();
        boolean access = AccessScreen.shouldPlay();
        Prefs.putInt(AccessScreen.K_LAST, Castle.nowMin());
        if (access) {
            showAccess(false);
        } else if (Prefs.bootOnUnlock()) {
            showBoot(true);
        } else {
            showHome();
        }
    }

    private boolean introArmed;

    /** Marks the next home screen to play the welcome animation. Called on every unlock. */
    private void armIntro() {
        introArmed = Prefs.intro();
    }

    /** True once per unlock, for the home screen that is about to be built. */
    boolean takeIntro() {
        boolean b = introArmed;
        introArmed = false;
        return b;
    }

    private void beep() {
        if (!Prefs.beep()) {
            return;
        }
        try {
            final ToneGenerator t = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60);
            t.startTone(ToneGenerator.TONE_PROP_ACK, 120);
            root.postDelayed(t::release, 400);
        } catch (RuntimeException ignored) {
            // no tone on this phone
        }
    }

    void showLock() {
        show(new LockScreen(this), LOCK);
    }

    private android.media.AudioDeviceCallback hpCallback;
    private ShakeDetector shake;
    private boolean crashChecked;

    /** Shake the phone: a golden coin flips on the screen. Not on the lock screen or boot. */
    void shakeCoin() {
        if (screen == LOCK || screen == BOOT) {
            return;
        }
        Badges.bump("shakes");
        Badges.check(this);
        if (Prefs.reactions() && wizard != null && !wizInside && new java.util.Random().nextInt(2) == 0) {
            wizard.say("Whoa! Easy there!");
        }
        coinFlip(null);
    }

    /** Opens a mini-game full screen without a box to grow from. */
    void openGame(Game g) {
        Quests.event(this, "game");
        GameFrame frame = new GameFrame(this, g, null, null);
        showOverlay(frame);
        frame.grow();
    }

    /** Flips the golden coin. The callback gets true for heads once it lands. */
    void coinFlip(java.util.function.Consumer<Boolean> onLand) {
        if (coinOn) {
            return;
        }
        Quests.event(this, "coin");
        coinOn = true;
        tip("shake");
        CoinFlip coin = new CoinFlip(this);
        coin.setOnLand(onLand);
        coin.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                coinOn = false;
            }
        });
        root.addView(coin, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private boolean coinOn;

    /** Asks once for the microphone so the Now playing wallpaper can follow the real beat. */
    void askVizPermission() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED && Prefs.getInt("viz_asked", 0) == 0) {
            Prefs.putInt("viz_asked", 1);
            requestPermissions(new String[] {android.Manifest.permission.RECORD_AUDIO}, 82);
        }
    }

    boolean onHome() {
        return screen == HOME;
    }

    private boolean setupAsked;

    /** Opens the first-boot setup. */
    void showSetup() {
        showOverlay(new SetupFlow(this));
    }

    private HomeScreen home;

    /** Runs something on the UI thread after a delay. */
    void postHome(Runnable r, long delayMs) {
        root.postDelayed(r, delayMs);
    }

    /** The home screen, while it is the screen showing. */
    HomeScreen home() {
        return screen == HOME ? home : null;
    }

    /** True when nothing covers the home screen, so the wizard may speak up. */
    boolean homeIdle() {
        return screen == HOME && overlay == null && shade == null && !nightOn && !HeadphonePrompt.busy();
    }

    WizardView wizardView() {
        return wizard != null && wizard.getVisibility() == View.VISIBLE ? wizard : null;
    }

    /** The first unlock of each day pays a bonus that grows with your streak. */
    private void loginBonus() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        int day = c.get(java.util.Calendar.YEAR) * 1000 + c.get(java.util.Calendar.DAY_OF_YEAR);
        if (Prefs.getInt("login_day", 0) == day || Prefs.getInt("setup_done", 0) == 0) {
            return;
        }
        c.add(java.util.Calendar.DAY_OF_YEAR, -1);
        int yesterday = c.get(java.util.Calendar.YEAR) * 1000 + c.get(java.util.Calendar.DAY_OF_YEAR);
        int last = Prefs.getInt("login_day", 0);
        int streak;
        if (last == yesterday) {
            streak = Prefs.getInt("login_streak", 0) + 1;
        } else if (last != 0 && Prefs.getInt("login_streak", 0) > 0 && Shop.useShield()) {
            streak = Prefs.getInt("login_streak", 0) + 1;   // a streak shield covered the missed day
        } else {
            streak = 1;
        }
        Prefs.putInt("login_day", day);
        Prefs.putInt("login_streak", streak);
        final int bonus = Math.min(10 + 5 * streak, 60);
        final int got = Coins.earn(bonus);
        final int s = streak;
        postHome(() -> wizardSay("Welcome back! Day " + s + " in a row: +" + got + " coins."), 2500);
    }

    void showHome() {
        final int before = screen;
        home = new HomeScreen(this);
        show(home, HOME);
        if (before == LOCK || before == BOOT) {
            loginBonus();
            Nudge.maybe(this);
        }
        if (!setupAsked && Prefs.getInt("setup_done", 0) == 0) {
            setupAsked = true;
            root.postDelayed(() -> {
                if (screen == HOME && overlay == null) {
                    showSetup();
                }
            }, 1400);
            return;
        }
        maybeAskDefault();
        root.postDelayed(() -> HeadphonePrompt.check(this), 1500);
    }

    void showDrawer() {
        show(new DrawerScreen(this), DRAWER);
    }

    void showTerminal() {
        show(new TerminalScreen(this), TERMINAL);
    }

    void showSettings() {
        show(new SettingsScreen(this), SETTINGS);
    }

    /** Re-applies the palette and redraws Settings so the new colors show straight away. */
    void refreshTheme() {
        Theme.load();
        showSettings();
    }

    void showNotes() {
        show(new NotesScreen(this), NOTES);
    }

    /** Swipe down from the top edge to open the control panel, on any screen. */
    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        int a = ev.getActionMasked();
        lastTouch = android.os.SystemClock.elapsedRealtime();
        if (a == android.view.MotionEvent.ACTION_DOWN) {
            shadeStartY = ev.getRawY();
            shadeArmed = shade == null && overlay == null && screen != BOOT && shadeStartY < Theme.dp(this, 110);
        } else if (a == android.view.MotionEvent.ACTION_MOVE && shadeArmed) {
            if (ev.getRawY() - shadeStartY > Theme.dp(this, 90)) {
                shadeArmed = false;
                showShade();
            }
        } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
            shadeArmed = false;
        }
        return super.dispatchTouchEvent(ev);
    }

    void showShade() {
        if (shade != null) {
            return;
        }
        hideKeyboard();
        shade = new Shade(this);
        root.addView(shade, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        shade.open();
    }

    void hideShade() {
        if (shade != null) {
            root.removeView(shade);
            shade = null;
        }
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && root != null) {
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static final java.util.List<String> CAMERA_PKGS = java.util.Arrays.asList(
            "com.sec.android.app.camera", "com.android.camera", "com.android.camera2", "com.google.android.GoogleCamera");
    private static final java.util.List<String> GALLERY_PKGS = java.util.Arrays.asList(
            "com.sec.android.gallery3d", "com.android.gallery3d", "com.google.android.gallery3d");
    private static final java.util.List<String> DIALER_PKGS = java.util.Arrays.asList(
            "com.samsung.android.dialer", "com.google.android.dialer", "com.android.dialer", "com.android.contacts",
            "com.samsung.android.app.contacts");

    /** True if this app has a NOVA version that should open instead. */
    private boolean nativeFor(AppEntry e) {
        if (!Prefs.nativeApps()) {
            return false;
        }
        String p = e.pkg;
        boolean dialer = DIALER_PKGS.contains(p);
        if (!dialer && Build.VERSION.SDK_INT >= 23) {
            try {
                android.telecom.TelecomManager tm = (android.telecom.TelecomManager) getSystemService(TELECOM_SERVICE);
                dialer = tm != null && p.equals(tm.getDefaultDialerPackage());
            } catch (Exception ignored) {
                dialer = false;
            }
        }
        if (dialer) {
            openGame(new PhoneApp(this));
            return true;
        }
        if (CAMERA_PKGS.contains(p)) {
            openGame(new CameraApp(this));
            return true;
        }
        if (GALLERY_PKGS.contains(p)) {
            openGame(new GalleryApp(this));
            return true;
        }
        return false;
    }

    void launch(AppEntry e) {
        hideKeyboard();
        Quests.event(this, "app");
        if (nativeFor(e)) {
            return;
        }
        if (!repo.launch(e)) {
            toast("Could not open " + e.label);
        }
    }

    // ------------------------------------------------------------------ boot

    /** True on first run and after every phone reboot, so the boot animation plays then. */
    private boolean bootChanged() {
        int now = -1;
        try {
            now = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT);
        } catch (Exception ignored) {
            // setting not readable on this phone
        }
        int last = prefs.getInt("boot_count", -2);
        prefs.edit().putInt("boot_count", now).apply();
        return now != last;
    }

    // -------------------------------------------------------- default home app

    boolean isDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return rm.isRoleHeld(RoleManager.ROLE_HOME);
            }
        }
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && getPackageName().equals(ri.activityInfo.packageName);
    }

    private void maybeAskDefault() {
        if (prefs.getBoolean("asked_home", false) || isDefaultHome()) {
            return;
        }
        prefs.edit().putBoolean("asked_home", true).apply();
        root.postDelayed(this::requestHome, 600);
    }

    /** Asks Android to make NOVA the default home app (this is what enables start at boot). */
    void requestHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    toast(Theme.OS_NAME + " is already your home app");
                } else {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME);
                }
                return;
            }
        }
        openHomeSettings();
    }

    /** Opens Android's "Home app" setting, where you can pick the stock launcher again. */
    void openHomeSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                toast("Open Settings > Apps > Default apps > Home app");
            }
        }
    }

    // --------------------------------------------------------------- favorites

    List<String> favs() {
        String s = prefs.getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            out.addAll(repo.defaultPackages());
            saveFavs(out);
            return out;
        }
        if (!s.isEmpty()) {
            out.addAll(Arrays.asList(s.split(",")));
        }
        return out;
    }

    private void saveFavs(List<String> l) {
        prefs.edit().putString("favs", TextUtils.join(",", l)).apply();
    }

    void togglePin(AppEntry e) {
        List<String> l = favs();
        if (l.contains(e.pkg)) {
            l.remove(e.pkg);
            toast("Removed from home");
        } else if (l.size() >= MAX_FAVS) {
            toast("Home is full (" + MAX_FAVS + " apps)");
            return;
        } else {
            l.add(e.pkg);
            toast("Pinned to home");
        }
        saveFavs(l);
    }

    void confirmUnpin(final AppEntry e) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setMessage("Remove from home?")
                .setPositiveButton("Remove", (d, w) -> {
                    togglePin(e);
                    if (screen == HOME) {
                        showHome();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Long-press menu for an app in the drawer. */
    void appMenu(final AppEntry e) {
        boolean pinned = favs().contains(e.pkg);
        String[] items = {pinned ? "Remove from home" : "Pin to home", "App info", "Uninstall"};
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        togglePin(e);
                    } else if (which == 1) {
                        openPackageIntent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, e.pkg);
                    } else {
                        openPackageIntent(Intent.ACTION_DELETE, e.pkg);
                    }
                })
                .show();
    }

    private void openPackageIntent(String action, String pkg) {
        try {
            startActivity(new Intent(action, Uri.parse("package:" + pkg)));
        } catch (Exception ex) {
            toast("Not available for this app");
        }
    }

    // --------------------------------------------------------------- battery

    int batteryLevel() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return -1;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return scale > 0 ? level * 100 / scale : -1;
    }

    boolean charging() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return false;
        }
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
    }

    // ------------------------------------------------------------------ menu

    void showMenu() {
        String[] items = {
            "Switch back to Android",
            "Make " + Theme.OS_NAME + " my home app",
            "Replay boot animation",
            "Lock",
            "About"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(Theme.OS_NAME + " " + Theme.OS_VERSION)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            openHomeSettings();
                            break;
                        case 1:
                            requestHome();
                            break;
                        case 2:
                            showBoot(false);
                            break;
                        case 3:
                            showLock();
                            break;
                        default:
                            showAbout();
                            break;
                    }
                })
                .show();
    }

    private void showAbout() {
        String msg = Theme.OS_NAME + " " + Theme.OS_VERSION + "\n\n"
                + "A home screen that replaces the Android look and starts when your phone boots.\n\n"
                + "Default home app: " + (isDefaultHome() ? "yes" : "no") + "\n"
                + "Android " + Build.VERSION.RELEASE + ", " + Build.MANUFACTURER + " " + Build.MODEL;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("About")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }
}
