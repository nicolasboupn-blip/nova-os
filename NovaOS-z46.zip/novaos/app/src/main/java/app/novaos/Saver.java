package app.novaos;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

/**
 * Battery saver. When it is on, NOVA stops everything that animates all the time or listens in the background:
 * animated wallpapers, parallax, holographic icons, glowing edges, the pulsing glows, the castle's crumbling cubes,
 * the wizard's sparks, shake detection, "Hey Nova" and the cinematic startup. Everything still works, it just sits still.
 * Modes: 0 off, 1 automatic (20% or less and not charging), 2 always.
 */
final class Saver {
    static final int AUTO_BELOW = 20;
    private static long checked;
    private static boolean cached;

    private Saver() {}

    static boolean on() {
        if (Prefs.getInt("adm_saver", 0) == 1 || Prefs.getBool("s_reduce", false)) {
            return true;
        }
        int mode = Prefs.saverMode();
        if (mode == 0) {
            return false;
        }
        if (mode == 2) {
            return true;
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - checked > 15000 || checked == 0) {
            checked = now == 0 ? 1 : now;
            cached = compute();
        }
        return cached;
    }

    /** Forget the cached battery reading, so a change of mode or charger shows up at once. */
    static void refresh() {
        checked = 0;
    }

    private static boolean compute() {
        Context c = Prefs.appContext();
        if (c == null) {
            return false;
        }
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) {
                return false;
            }
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int fake = Prefs.getInt("adm_batt", -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL;
            if (level < 0 || scale <= 0) {
                return false;
            }
            if (fake >= 0) {
                return fake <= AUTO_BELOW;
            }
            return !charging && level * 100 / scale <= AUTO_BELOW;
        } catch (Exception e) {
            return false;
        }
    }
}
