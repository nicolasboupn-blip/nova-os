package app.novaos;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.List;

/** Reads the phone's notifications so NOVA can show them in its swipe-down panel. */
public class NovaNotificationService extends NotificationListenerService {

    static final class Item {
        final String key;
        final boolean low;
        final String app;
        final String title;
        final String text;
        final PendingIntent open;

        Item(String key, boolean low, String app, String title, String text, PendingIntent open) {
            this.key = key;
            this.low = low;
            this.app = app;
            this.title = title;
            this.text = text;
            this.open = open;
        }
    }

    private static final int MAX = 30;
    private static final List<Item> items = new ArrayList<>();

    /** Called on the main thread whenever the list changes while the panel is open. */
    static volatile Runnable listener;

    /** Called when a new, non-silent notification arrives and NOVA is on screen (edge lighting). */
    static volatile Runnable flashListener;
    /** The key of the newest notification and the running service, so a critter can dismiss it. */
    static volatile String lastKey;
    private static volatile NovaNotificationService instance;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
    }

    @Override
    public void onListenerDisconnected() {
        if (instance == this) {
            instance = null;
        }
        super.onListenerDisconnected();
    }

    static void dismiss(String key) {
        NovaNotificationService s = instance;
        if (s != null && key != null) {
            try {
                s.cancelNotification(key);
            } catch (RuntimeException ignored) {
                // the notification is already gone
            }
        }
    }
    private static long lastFlash;

    static synchronized List<Item> snapshot() {
        return new ArrayList<>(items);
    }

    static synchronized void clearAll() {
        items.clear();
    }

    static boolean hasAccess(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return flat != null
                && flat.contains(new ComponentName(c, NovaNotificationService.class).flattenToString());
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) {
            return;
        }
        Notification n = sbn.getNotification();
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
            return;
        }
        if (sbn.getPackageName().equals(getPackageName())) {
            return;
        }
        String title = text(n.extras, Notification.EXTRA_TITLE);
        String body = text(n.extras, Notification.EXTRA_TEXT);
        if (title.isEmpty() && body.isEmpty()) {
            return;
        }
        String app = sbn.getPackageName();
        try {
            app = getPackageManager()
                    .getApplicationLabel(getPackageManager().getApplicationInfo(app, 0)).toString();
        } catch (Exception ignored) {
            // keep the package name
        }
        boolean low = false;
        try {
            RankingMap rm = getCurrentRanking();
            Ranking rk = new Ranking();
            if (rm != null && rm.getRanking(sbn.getKey(), rk)) {
                low = rk.getImportance() <= NotificationManager.IMPORTANCE_LOW;
            }
        } catch (RuntimeException ignored) {
            // treat as normal
        }
        Item item = new Item(sbn.getKey(), low, app, title, body, n.contentIntent);
        synchronized (NovaNotificationService.class) {
            items.add(0, item);
            while (items.size() > MAX) {
                items.remove(items.size() - 1);
            }
        }
        Runnable r = listener;
        if (r != null) {
            r.run();
        }
        long now = System.currentTimeMillis();
        Runnable f = flashListener;
        if (f != null && !low && !sbn.isOngoing() && now - lastFlash > 2500
                && !Notification.CATEGORY_TRANSPORT.equals(n.category)
                && !Notification.CATEGORY_PROGRESS.equals(n.category)) {
            lastFlash = now;
            lastKey = sbn.getKey();
            f.run();
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn == null) {
            return;
        }
        synchronized (NovaNotificationService.class) {
            items.removeIf(i -> i.key != null && i.key.equals(sbn.getKey()));
        }
        Runnable r = listener;
        if (r != null) {
            r.run();
        }
    }

    private static String text(Bundle b, String key) {
        if (b == null) {
            return "";
        }
        CharSequence c = b.getCharSequence(key);
        return c == null ? "" : c.toString().trim();
    }
}
