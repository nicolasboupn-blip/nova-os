package app.novaos;

import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

/**
 * The client for NOVA Net, your own chat and ranklist server (see the server folder). Nothing here talks to anyone
 * until you type a server address in NOVA Net and sign in. Calls block, so use {@link #run} from the screen.
 */
final class NovaNet {
    private NovaNet() {}

    static final class Result {
        int code;
        JSONObject json = new JSONObject();
        String error;

        boolean ok() {
            return error == null && code >= 200 && code < 300;
        }
    }

    interface Done {
        void done(Result r);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static String server() {
        String u = Prefs.getString("net_url", "").trim();
        while (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        return u;
    }

    static void setServer(String url) {
        String u = url == null ? "" : url.trim();
        if (!u.isEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) {
            u = "https://" + u;
        }
        if (!u.equals(server())) {
            logoutLocal();
        }
        Prefs.putString("net_url", u);
    }

    static String token() {
        return Prefs.getString("net_token", "");
    }

    static String username() {
        return Prefs.getString("net_user", "");
    }

    static boolean signedIn() {
        return !token().isEmpty() && !server().isEmpty();
    }

    static void saveSession(String token, String user) {
        Prefs.putString("net_token", token);
        Prefs.putString("net_user", user);
    }

    static void logoutLocal() {
        Prefs.putString("net_token", "");
        Prefs.putString("net_user", "");
    }

    /** Runs a request on a background thread and hands the result back on the main thread. */
    static void run(final String method, final String path, final JSONObject body, final Done cb) {
        new Thread(() -> {
            final Result r = call(method, path, body);
            MAIN.post(() -> cb.done(r));
        }).start();
    }

    static Result call(String method, String path, JSONObject body) {
        Result r = new Result();
        String base = server();
        if (base.isEmpty()) {
            r.error = "No server address yet";
            return r;
        }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base + path).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            c.setRequestMethod(method);
            c.setRequestProperty("User-Agent", "NOVA/" + Theme.OS_VERSION);
            c.setRequestProperty("Accept", "application/json");
            String t = token();
            if (!t.isEmpty()) {
                c.setRequestProperty("Authorization", "Bearer " + t);
            }
            if (body != null) {
                byte[] data = body.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                OutputStream o = c.getOutputStream();
                o.write(data);
                o.close();
            }
            r.code = c.getResponseCode();
            InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = "";
            if (in != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                in.close();
                text = out.toString("UTF-8");
            }
            try {
                r.json = text.isEmpty() ? new JSONObject() : new JSONObject(text);
            } catch (Exception e) {
                r.json = new JSONObject();
                if (r.code < 400) {
                    r.error = "The server sent something odd. Is the address right?";
                }
            }
            if (r.code >= 400 && r.error == null) {
                r.error = r.json.optString("error", "Server said " + r.code);
            }
            if (r.code == 401 && !token().isEmpty()) {
                logoutLocal();   // the session ran out or was ended
            }
        } catch (Exception e) {
            r.error = "Can't reach the server. Check the address and your internet.";
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
        return r;
    }

    static JSONObject obj(String... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) {
                o.put(kv[i], kv[i + 1]);
            }
        } catch (Exception ignored) {
        }
        return o;
    }

    private static long lastSync;

    /** Sends your numbers to the server. Safe to call often: it only goes out every 3 minutes unless forced. */
    static void sync(boolean force) {
        if (!signedIn()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (!force && now - lastSync < 180000) {
            return;
        }
        lastSync = now;
        new Thread(() -> {
            try {
                call("POST", "/api/sync", NetStats.snapshot());
            } catch (Exception ignored) {
            }
        }).start();
    }
}
