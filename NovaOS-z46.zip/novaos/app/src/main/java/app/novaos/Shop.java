package app.novaos;

import java.util.Random;

/** The coin shop's rules: boosts, titles, pet hats, premium colours, the bank and the mystery chest. */
final class Shop {
    private Shop() {}

    static final String[] TITLES = {"Peasant", "Squire", "Baron", "Duke", "King", "Emperor"};
    static final int[] TITLE_COST = {0, 200, 600, 2000, 8000, 25000};

    static final String[] HATS = {"None", "Party hat", "Crown", "Sunglasses", "Bow tie"};
    static final int[] HAT_COST = {0, 120, 300, 150, 100};

    /** Premium colour themes are Theme presets 8 and up. */
    static final int FIRST_PREMIUM = 8;
    static final int ACCENT_COST = 250;

    static final int BOOST_COST = 150;
    static final int BOOST_DAY_COST = 3000;
    static final int BOOST_WEEK_COST = 20000;
    static final int REROLL_COST = 60;
    static final int SHIELD_COST = 120;
    static final int FIREWORKS_COST = 40;
    static final int TREAT_COST = 80;
    static final int MYSTERY_COST = 75;


    // ------------------------------------------------------------------ paying

    static boolean pay(NovaActivity host, int cost) {
        if (Castle.admin()) {
            return true;
        }
        if (Coins.get() < cost) {
            host.toast("You need " + cost + " coins");
            return false;
        }
        Coins.add(-cost);
        Prefs.putInt("stat_spent", Prefs.getInt("stat_spent", 0) + cost);
        Sfx.play(Sfx.COIN);
        return true;
    }

    // ------------------------------------------------------------------ titles

    static int title() {
        return Math.max(0, Math.min(TITLES.length - 1, Prefs.getInt("wz_title", 0)));
    }

    static String titleName() {
        return TITLES[title()];
    }

    // ------------------------------------------------------------------ boosts

    static int boostMinutes() {
        int until = Prefs.getInt("boost_until", 0);
        return Math.max(0, until - Castle.nowMin());
    }

    static void startBoost() {
        startBoost(60);
    }

    /** Adds minutes of double coins on top of whatever is left. */
    static void startBoost(int minutes) {
        int base = Math.max(Castle.nowMin(), Prefs.getInt("boost_until", 0));
        Prefs.putInt("boost_until", base + minutes);
    }

    /** "45 min", "5h 20m", "2d 3h": time left on the boost. */
    static String boostText() {
        int m = boostMinutes();
        if (m >= 1440) {
            return (m / 1440) + "d " + ((m % 1440) / 60) + "h";
        }
        return m >= 60 ? (m / 60) + "h " + (m % 60) + "m" : m + " min";
    }

    static int shields() {
        return Prefs.getInt("shield", 0);
    }

    /** Uses a streak shield if there is one. Returns true if it saved the streak. */
    static boolean useShield() {
        int n = shields();
        if (n > 0) {
            Prefs.putInt("shield", n - 1);
            return true;
        }
        return false;
    }

    static void addShield() {
        Prefs.putInt("shield", Math.min(3, shields() + 1));
    }

    // ------------------------------------------------------------------ the bank

    /** Pays 2% (3% with the upgrade) a day on what is saved, for each full day since the last time. */
    static void accrue() {
        int day = Castle.nowMin() / 1440;
        int last = Prefs.getInt("bank_day", 0);
        if (last == 0) {
            Prefs.putInt("bank_day", day);
            return;
        }
        int days = Math.min(30, day - last);
        if (days <= 0) {
            return;
        }
        long bal = Prefs.getInt("bank_bal", 0);
        for (int i = 0; i < days && bal < Upgrades.bankCap(); i++) {
            bal = Math.min(Upgrades.bankCap(), bal + Math.max(1, bal * Upgrades.interest() / 100));
        }
        Prefs.putInt("bank_bal", (int) bal);
        Prefs.putInt("bank_day", day);
    }

    static int bank() {
        return Prefs.getInt("bank_bal", 0);
    }

    static boolean deposit(int n) {
        n = Math.min(n, Math.min(Coins.get(), Upgrades.bankCap() - bank()));
        if (n <= 0) {
            return false;
        }
        accrue();
        Coins.add(-n);
        Prefs.putInt("bank_bal", bank() + n);
        if (Prefs.getInt("bank_day", 0) == 0) {
            Prefs.putInt("bank_day", Castle.nowMin() / 1440);
        }
        return true;
    }

    static boolean withdraw(int n) {
        n = Math.min(n, bank());
        if (n <= 0) {
            return false;
        }
        Prefs.putInt("bank_bal", bank() - n);
        Coins.add(n);
        return true;
    }

    // ------------------------------------------------------------------ mystery chest

    /** Opens the chest and returns what was inside, in words. */
    static String mystery(NovaActivity host) {
        Random r = new Random();
        int roll = r.nextInt(100);
        if (roll < 30) {
            return "Only dust and a spider. Better luck next time!";
        } else if (roll < 60) {
            Coins.add(40);
            return "40 coins!";
        } else if (roll < 75) {
            Coins.add(100);
            return "100 coins!";
        } else if (roll < 85) {
            startBoost();
            return "A double-coins potion! x2 for an hour.";
        } else if (roll < 93) {
            String got = cosmetic();
            return got == null ? "A tiny gold nugget: 60 coins!" : got;
        } else if (roll < 98) {
            addShield();
            return "A streak shield!";
        }
        Coins.add(1000);
        return "JACKPOT! 1000 coins!";
    }

    /** Gives one cosmetic you do not own yet. Returns what it was, or null if you own everything. */
    private static String cosmetic() {
        java.util.ArrayList<String> pool = new java.util.ArrayList<>();
        for (int i = 1; i < HATS.length; i++) {
            if (!Castle.owns("hat", i)) {
                pool.add("hat" + i);
            }
        }
        for (int i = 1; i < Castle.ROBES.length; i++) {
            if (!Castle.owns("robe", i)) {
                pool.add("robe" + i);
            }
        }
        for (int i = 1; i < Castle.ORBS.length; i++) {
            if (!Castle.owns("orb", i)) {
                pool.add("orb" + i);
            }
        }
        if (pool.isEmpty()) {
            Coins.add(60);
            return null;
        }
        String pick = pool.get(new Random().nextInt(pool.size()));
        Prefs.putInt("own_" + pick, 1);
        if (pick.startsWith("hat")) {
            return "A pet accessory: " + HATS[Integer.parseInt(pick.substring(3))] + "!";
        } else if (pick.startsWith("robe")) {
            return "A wizard robe: " + Castle.ROBES[Integer.parseInt(pick.substring(4))] + "!";
        }
        return "A staff orb: " + Castle.ORBS[Integer.parseInt(pick.substring(3))] + "!";
    }
}
