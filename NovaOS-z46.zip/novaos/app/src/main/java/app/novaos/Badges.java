package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.Calendar;

/** Small achievements. Unlocking one slides a glowing banner down from the top and pops confetti. */
final class Badges {
    static final int BRONZE = 0, SILVER = 1, GOLD = 2;
    static final int[] TIER_REWARD = {50, 150, 400};
    static final int[] TIER_COLOR = {0xFFCD7F32, 0xFFC4CCDC, 0xFFFFD35A};
    static final String[] TIER_NAME = {"bronze", "silver", "gold"};

    interface Progress {
        int get();
    }

    static final class Badge {
        final String id;
        final String icon;
        final String name;
        final String how;
        final int tier;
        final Progress progress;   // null: unlocked by an event somewhere in the app
        final int target;

        Badge(String id, String icon, String name, String how, int tier, Progress progress, int target) {
            this.id = id;
            this.icon = icon;
            this.name = name;
            this.how = how;
            this.tier = tier;
            this.progress = progress;
            this.target = target;
        }
    }

    private static Badge e(String id, String icon, String name, String how, int tier) {
        return new Badge(id, icon, name, how, tier, null, 0);
    }

    private static Badge p(String id, String icon, String name, String how, int tier, Progress pr, int target) {
        return new Badge(id, icon, name, how, tier, pr, target);
    }

    private static Progress stat(final String key) {
        return () -> Prefs.getInt("stat_" + key, 0);
    }

    private static int zigzagCastles() {
        int n = 0;
        for (int i = 0; i < Zigzag.NAMES.length; i++) {
            if (Prefs.getInt("own_zzcastle" + i, 0) == 1) {
                n++;
            }
        }
        return n;
    }

    private static int fullSets() {
        int n = 0;
        for (int i = 0; i < Zigzag.NAMES.length; i++) {
            if (Prefs.getInt("own_zzshield" + (i + 1), 0) == 1 && Prefs.getInt("own_zzwings" + (i + 1), 0) == 1
                    && Prefs.getInt("own_zzcape" + (i + 1), 0) == 1 && Prefs.getInt("own_zzcastle" + i, 0) == 1) {
                n++;
            }
        }
        return n;
    }

    private static int casinoBadges() {
        int n = 0;
        for (String id : new String[] {"spin1", "roulette", "blackjack", "dice", "scratch", "hilo"}) {
            if (has(id)) {
                n++;
            }
        }
        return n;
    }

    private static int bestStreak() {
        return Math.max(Prefs.getInt("best_streak", 0), Prefs.getInt("q_streak", 0));
    }

    static final Badge[] ALL = {
        // games and the casino
        e("spin1", "🎰", "First pull", "Pull the slot lever once", BRONZE),
        e("spin100", "🔁", "Regular", "Spin the slots 100 times", SILVER),
        e("jackpot", "7️⃣", "Jackpot", "Land three 7s", SILVER),
        e("broke", "💸", "Rock bottom", "Run out of slot coins", BRONZE),
        e("snake", "🐍", "Snake charmer", "Score 15 in Snake", BRONZE),
        e("g2048", "🔢", "Five twelve", "Make a 512 tile in 2048", SILVER),
        e("memory", "🧠", "Sharp mind", "Finish Memory in 10 moves or less", BRONZE),
        e("react", "⚡", "Quick draw", "React in under 250 ms", BRONZE),
        e("hilo", "🃏", "Hot streak", "Win 5 in a row in Higher or Lower", BRONZE),
        e("whack", "🎯", "Sharpshooter", "Score 20 in Whack", BRONZE),
        e("stopwatch", "⏱", "Timekeeper", "Start the stopwatch", BRONZE),
        e("timer", "⏰", "Time's up", "Let a timer run out", BRONZE),
        e("roulette", "🎡", "Called it", "Win a single number at roulette", SILVER),
        e("blackjack", "♠", "Twenty-one", "Get a natural blackjack", SILVER),
        e("dice", "🎲", "Lucky roll", "Win a dice duel with a double six", SILVER),
        e("scratch", "🎟", "Silver lining", "Win a scratch card", BRONZE),
        p("jackpot2", "🎊", "Double seven", "Hit the 777 jackpot twice", SILVER, stat("jackpots"), 2),
        p("slot10k", "🤑", "High roller", "Win 10000 coins on the slots in total", GOLD, stat("slotwon"), 10000),
        p("spins1000", "🍀", "Slot legend", "Spin the slots 1000 times", GOLD, stat("spins"), 1000),
        p("casinoall", "🎩", "Casino king", "Earn all 6 casino badges", SILVER, Badges::casinoBadges, 6),
        p("game25", "🎮", "Gamer", "Open 25 mini-games", BRONZE, stat("ev_game"), 25),
        // castle and dragon
        p("castle3", "🧱", "Mason", "Reach castle stage 3", BRONZE, Castle::stage, 3),
        p("castle5", "🥚", "Dragon egg", "Reach castle stage 5 and meet the baby dragon", BRONZE, Castle::stage, 5),
        p("castle8", "🏰", "Architect", "Reach castle stage 8", SILVER, Castle::stage, 8),
        p("castle10", "👑", "Dragon king", "Reach castle stage 10", GOLD, Castle::stage, 10),
        p("pig1", "🐷", "Pork chop", "Catch a roast pig", BRONZE, stat("pigs"), 1),
        p("pig10", "🐖", "Pig farmer", "Catch 10 roast pigs", SILVER, stat("pigs"), 10),
        p("thief1", "🥷", "Gotcha!", "Catch a thief at the castle", BRONZE, stat("thieves"), 1),
        p("thief10", "🛡", "Town guard", "Catch 10 thieves", SILVER, stat("thieves"), 10),
        p("deal1", "🤝", "Good deal", "Buy from the travelling merchant", BRONZE, stat("deals"), 1),
        p("deal10", "🧳", "Best customer", "Buy from the merchant 10 times", SILVER, stat("deals"), 10),
        p("zzcastle", "⚡", "Lightning lord", "Own all 7 Zigzag castle skins", GOLD, Badges::zigzagCastles, 7),
        p("castle50", "🏯", "Castle fan", "Tap the castle 50 times", BRONZE, stat("ev_castle"), 50),
        p("dragon10", "🐉", "Dragon whisperer", "Wake Ember 10 times", BRONZE, stat("ev_dragon"), 10),
        // daily life
        p("streak3", "🔥", "Warming up", "Finish all daily quests 3 days in a row", BRONZE, Badges::bestStreak, 3),
        p("streak7", "🌋", "On fire", "A 7 day quest streak", SILVER, Badges::bestStreak, 7),
        p("streak30", "🏆", "Unstoppable", "A 30 day quest streak", GOLD, Badges::bestStreak, 30),
        p("allq10", "📜", "Quest master", "Finish all 3 quests 10 times", SILVER, stat("allq"), 10),
        p("unlock100", "🔓", "Regular visitor", "Unlock your phone 100 times", BRONZE, Prefs::unlocks, 100),
        p("unlock1000", "📱", "Cannot stop", "Unlock your phone 1000 times", SILVER, Prefs::unlocks, 1000),
        p("apps100", "🧭", "Explorer", "Open 100 apps", BRONZE, stat("ev_app"), 100),
        p("apps1000", "📲", "App addict", "Open 1000 apps", SILVER, stat("ev_app"), 1000),
        p("pets25", "🐾", "Pet lover", "Pet your companion 25 times", BRONZE, stat("ev_pet"), 25),
        p("critter10", "🪲", "Exterminator", "Squash 10 notification critters", BRONZE, stat("ev_critter"), 10),
        p("event25", "⭐", "Treasure hunter", "Catch 25 surprises", SILVER, stat("ev_event"), 25),
        p("coin10", "🌕", "Flipper", "Flip the golden coin 10 times", BRONZE, stat("ev_coin"), 10),
        // coins and the shop
        p("earn1k", "🪙", "Pocket money", "Earn 1000 coins in total", BRONZE, () -> Prefs.getInt("ns_all", 0), 1000),
        p("earn10k", "💰", "Rich", "Earn 10000 coins in total", SILVER, () -> Prefs.getInt("ns_all", 0), 10000),
        p("earn100k", "🏦", "Tycoon", "Earn 100000 coins in total", GOLD, () -> Prefs.getInt("ns_all", 0), 100000),
        p("bank5k", "🏧", "Saver", "Have 5000 coins in the bank", SILVER, Shop::bank, 5000),
        p("spend10k", "🛍", "Big spender", "Spend 10000 coins in the shop", SILVER, stat("spent"), 10000),
        p("own5", "🎁", "Collector", "Own 5 cosmetics", BRONZE, NetStats::cosmetics, 5),
        p("own20", "🧺", "Hoarder", "Own 20 cosmetics", SILVER, NetStats::cosmetics, 20),
        p("own50", "🏛", "Museum", "Own 50 cosmetics", GOLD, NetStats::cosmetics, 50),
        p("fullset", "💎", "Full set", "Own a whole Zigzag edition: shield, wings, cape and castle", GOLD, Badges::fullSets, 1),
        // your character
        e("dress", "👕", "New look", "Change something in My character", BRONZE),
        e("scenes", "🎭", "Busy day", "See all 12 things your character does (tap him)", SILVER),
        p("wingcape", "🦸", "Superhero", "Wear wings and a Zigzag cape together", SILVER, () -> {
            int[] lk = Avatar.look();
            return lk.length > 13 && lk[12] > 0 && lk[13] > 0 ? 1 : 0;
        }, 1),
        // NOVA Net
        e("net_friend", "🙋", "New friend", "Make a friend on NOVA Net", BRONZE),
        e("net_msg", "💬", "Hello world", "Send a message on NOVA Net", BRONZE),
        e("net_group", "👥", "Group chat", "Join or start a group on NOVA Net", BRONZE),
        e("net_friends10", "🎉", "Popular", "Have 10 friends on NOVA Net", SILVER),
        e("net_top3", "🥇", "Top three", "Reach the top 3 of this week's ranklist", GOLD),
        // secrets
        p("night3", "🦉", "Night owl", "Use your phone at 3 in the morning", BRONZE, () -> Calendar.getInstance()
                .get(Calendar.HOUR_OF_DAY) == 3 ? 1 : 0, 1),
        p("shake20", "🤪", "Shaken up", "Shake the phone for a coin 20 times", BRONZE, stat("shakes"), 20)
    };

    private Badges() {
    }

    static boolean has(String id) {
        return Prefs.getInt("badge_" + id, 0) == 1;
    }

    static int count() {
        int n = 0;
        for (Badge b : ALL) {
            if (has(b.id)) {
                n++;
            }
        }
        return n;
    }

    static Badge find(String id) {
        for (Badge b : ALL) {
            if (b.id.equals(id)) {
                return b;
            }
        }
        return null;
    }

    /** How far along an automatic badge is, as text like "3 / 7". Empty for event badges. */
    static String progressText(Badge b) {
        if (b.progress == null) {
            return "";
        }
        return Math.min(b.target, b.progress.get()) + " / " + b.target;
    }

    private static boolean checking;
    private static long checkedAt;

    /** Looks at every automatic badge and gives the ones you have earned. Cheap, and safe to call often. */
    static void check(NovaActivity host) {
        long now = System.currentTimeMillis();
        if (checking || now - checkedAt < 2500 || host == null) {
            return;
        }
        checkedAt = now;
        checking = true;
        try {
            int streak = Prefs.getInt("q_streak", 0);
            if (streak > Prefs.getInt("best_streak", 0)) {
                Prefs.putInt("best_streak", streak);
            }
            for (Badge b : ALL) {
                if (b.progress != null && !has(b.id) && b.progress.get() >= b.target) {
                    unlock(host, b.id);
                }
            }
        } finally {
            checking = false;
        }
    }

    /** The icons of your three best badges, for your NOVA Net profile. */
    static String showcase() {
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (int tier = GOLD; tier >= BRONZE && shown < 3; tier--) {
            for (int i = ALL.length - 1; i >= 0 && shown < 3; i--) {
                if (ALL[i].tier == tier && has(ALL[i].id)) {
                    sb.append(ALL[i].icon);
                    shown++;
                }
            }
        }
        return sb.toString();
    }

    /** Adds one to a counter and returns the new value. */
    static int bump(String key) {
        int v = Prefs.getInt("stat_" + key, 0) + 1;
        Prefs.putInt("stat_" + key, v);
        return v;
    }

    /** Gives the badge once. Does nothing if you already have it. */
    static void unlock(final NovaActivity host, String id) {
        final Badge b = find(id);
        if (b == null || has(id)) {
            return;
        }
        Prefs.putInt("badge_" + id, 1);
        final int reward = Coins.earn(TIER_REWARD[b.tier]);
        Sfx.play(Sfx.WIN);
        host.tip("badge");
        host.buzz(40);

        final TextView banner = new TextView(host);
        banner.setText(b.icon + "  BADGE · " + b.name.toUpperCase() + "  +" + reward);
        banner.setTypeface(Theme.MONO);
        banner.setTextSize(13f);
        banner.setLetterSpacing(0.1f);
        banner.setTextColor(Theme.TEXT);
        banner.setGravity(Gravity.CENTER);
        banner.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        banner.setPadding(Theme.dp(host, 20), Theme.dp(host, 12), Theme.dp(host, 20), Theme.dp(host, 12));
        banner.setElevation(Theme.dp(host, 12));
        banner.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Theme.dp(host, 48);
        host.root.addView(banner, lp);
        banner.setAlpha(0f);
        banner.setTranslationY(-Theme.dp(host, 40));
        banner.animate().alpha(1f).translationY(0f).setDuration(380).start();
        host.confetti(host.root.getWidth() / 2f, Theme.dp(host, 90));
        banner.postDelayed(() -> banner.animate().alpha(0f).translationY(-Theme.dp(host, 30)).setDuration(400)
                .withEndAction(() -> {
                    if (banner.getParent() != null) {
                        host.root.removeView(banner);
                    }
                }).start(), 2800);
    }

    /** True if the view is still shown, so late callbacks do not touch dead screens. */
    static boolean alive(View v) {
        return v != null && v.isAttachedToWindow();
    }
}
