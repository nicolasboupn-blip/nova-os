package app.novaos;

import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;

import java.util.Calendar;
import java.util.Random;

/** Long-press the wizard: jokes, riddles, fortunes, spells and a lesson a day. */
final class WizardMenu {
    private static final Random RND = new Random();

    private static final String[] JOKES = {
        "Why do wizards love Wi-Fi? Because it has great spell-ing... I mean range.",
        "What do you call a sleepy dragon? A snore-cerer.",
        "Why did the phone go to the castle? To get its charge reinstated.",
        "I told my staff a joke. It just stood there. Typical wood.",
        "What's a wizard's favourite app? Hocus Focus.",
        "How does a dragon answer the phone? Burn-burn, who's there?",
        "Why was the coin nervous at the casino? It had too much at stake. Actually, no stake. Sorry.",
        "What do you call a wizard in a hurry? A quick-spell.",
        "Why don't knights use airplane mode? They prefer the drawbridge.",
        "What did the pig say to the dragon? Please. Not. The. Oven."};
    private static final String[][] RIDDLES = {
        {"I have keys but open no locks, space but no room. What am I?", "A keyboard."},
        {"The more you take, the more you leave behind. What am I?", "Footsteps."},
        {"I speak without a mouth and hear without ears. What am I?", "An echo."},
        {"What has hands but cannot clap?", "A clock."},
        {"What gets wetter the more it dries?", "A towel."},
        {"What can you catch but not throw?", "A cold."},
        {"I'm full of holes but still hold water. What am I?", "A sponge."},
        {"What has a head and a tail but no body?", "A coin."}};
    private static final String[] FORTUNES = {
        "A lucky star will cross your path soon.", "Someone is thinking of you right now.",
        "Today's small step is tomorrow's big leap.", "Beware of green on the roulette wheel.",
        "Gold finds those who keep going.", "You will find a chest where you least expect it.",
        "A dragon admires your persistence.", "Say yes to the next small adventure.",
        "Your phone will survive. Probably.", "An old friend will message you this week."};
    private static final String[] EIGHT = {"It is certain.", "Without a doubt.", "Yes, definitely.", "Most likely.",
        "Ask again later.", "Cannot predict now.", "Don't count on it.", "My sources say no.", "Very doubtful.",
        "Signs point to yes."};
    private static final String[] LESSONS = {
        "Honey never spoils. Jars found in old tombs were still edible.", "Octopuses have three hearts.",
        "A day on Venus is longer than its year.", "Bananas are berries, strawberries are not.",
        "Sharks are older than trees.", "Lightning is five times hotter than the surface of the sun.",
        "Your phone has more computing power than the computers that took us to the Moon.",
        "The Eiffel Tower grows about 15 cm taller in summer.", "Wombat droppings are cube shaped.",
        "Water can boil and freeze at the same time (the triple point).",
        "There are more possible chess games than atoms in the universe.",
        "A group of flamingos is called a flamboyance.", "Sound travels about four times faster in water than in air.",
        "Switzerland has four national languages.", "The first computer bug was a real moth in 1947.",
        "A cloud can weigh more than a million kilograms.", "Dolphins give each other names.",
        "Light from the Sun takes about 8 minutes to reach us.", "Cats spend about 70% of their life asleep.",
        "Mount Everest grows a few millimetres every year."};

    private WizardMenu() {}

    static void open(final NovaActivity host) {
        String name = Prefs.getString("wz_name", "Merlo");
        final String[] items = {"Tell me a joke", "A riddle", "Read my fortune", "Magic 8-ball", "Spell: confetti",
            "Spell: fireworks", "Spell: rain", "Spell: snow", "Lesson of the day", "Rename the wizard", "Coin Shop", "My character"};
        new AlertDialog.Builder(host).setTitle(Shop.title() > 0 ? Shop.titleName() + " " + name : name + " the wizard").setItems(items, (d, w) -> run(host, w)).show();
    }

    private static void run(final NovaActivity host, int which) {
        if (which == 10) {
            CoinShop.open(host);
            return;
        }
        if (which == 11) {
            AvatarEditor.open(host);
            return;
        }
        WizardView wiz = host.wizardView();
        float cx = host.root.getWidth() / 2f;
        switch (which) {
            case 0:
                host.wizardSay(JOKES[RND.nextInt(JOKES.length)]);
                break;
            case 1: {
                final String[] r = RIDDLES[RND.nextInt(RIDDLES.length)];
                if (wiz != null) {
                    wiz.ask(r[0], () -> host.wizardSay("The answer: " + r[1]), () -> host.wizardSay("The answer: " + r[1]));
                } else {
                    host.wizardSay(r[0] + "  (" + r[1] + ")");
                }
                break;
            }
            case 2:
                host.wizardSay("🔮 " + FORTUNES[RND.nextInt(FORTUNES.length)]);
                break;
            case 3:
                host.wizardSay("🎱 " + EIGHT[RND.nextInt(EIGHT.length)]);
                break;
            case 4:
                host.confetti(cx, host.root.getHeight() * 0.35f);
                host.wizardSay("Abracadabra!");
                break;
            case 5:
                for (int i = 0; i < 6; i++) {
                    final int k = i;
                    host.root.postDelayed(() -> host.confetti(host.root.getWidth() * (0.15f + 0.14f * k),
                            host.root.getHeight() * (0.2f + 0.1f * (k % 3))), i * 260L);
                }
                host.wizardSay("Fireworks!");
                break;
            case 6:
                weather(host, 1, "Rain, rain, come to my castle!");
                break;
            case 7:
                weather(host, 2, "Snow! Look at my castle!");
                break;
            case 8: {
                Calendar c = Calendar.getInstance();
                int day = c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
                String lesson = LESSONS[(day * 7) % LESSONS.length];
                if (Prefs.getInt("lesson_day", 0) != day) {
                    Prefs.putInt("lesson_day", day);
                    Coins.earn(3);
                    lesson += "  (+3 coins for learning!)";
                }
                host.wizardSay("📚 " + lesson);
                break;
            }
            default: {
                final EditText in = new EditText(host);
                in.setInputType(InputType.TYPE_CLASS_TEXT);
                in.setText(Prefs.getString("wz_name", "Merlo"));
                new AlertDialog.Builder(host).setTitle("Name your wizard").setView(in)
                        .setPositiveButton("OK", (d, w) -> {
                            String n = in.getText().toString().trim();
                            if (!n.isEmpty()) {
                                Prefs.putString("wz_name", n);
                                host.wizardSay("I like it. Call me " + n + "!");
                            }
                        }).setNegativeButton("Cancel", null).show();
                break;
            }
        }
        Quests.event(host, "castle");
    }

    private static void weather(final NovaActivity host, int kind, String say) {
        final int before = Prefs.getInt("adm_wx", -1);
        Prefs.putInt("adm_wx", kind);
        host.wizardSay(say);
        host.root.postDelayed(() -> {
            if (Prefs.getInt("adm_wx", -1) == kind) {
                Prefs.putInt("adm_wx", before);
            }
        }, 60000);
    }
}
