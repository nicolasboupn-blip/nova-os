package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Pick a horse, bet coins, watch the race. A win pays 3.6 times your bet. */
final class GameHorses extends Game {
    private static final String[] NAMES = {"Thunder", "Biscuit", "Nova", "Lucky"};
    private static final int[] BETS = {5, 10, 25, 50};

    private final TextView[] lanes = new TextView[4];
    private final TextView info;
    private final TextView go;
    private final Random rnd = new Random();
    private final float[] pos = new float[4];
    private int pick = -1;
    private int bet = 1;
    private boolean running;

    GameHorses(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(80), dp(20), dp(30));
        addView(col, new LayoutParams(-1, -1));
        info = label("", 13f, Theme.TEXT);
        col.addView(info);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            lanes[i] = label("", 13f, Theme.TEXT);
            lanes[i].setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            lanes[i].setTypeface(Theme.MONO);
            lanes[i].setPadding(dp(10), 0, dp(10), 0);
            lanes[i].setClickable(true);
            lanes[i].setOnClickListener(v -> {
                if (!running) {
                    pick = idx;
                    draw();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
            lp.topMargin = dp(8);
            col.addView(lanes[i], lp);
        }
        TextView betBtn = button("BET " + BETS[bet], null);
        betBtn.setOnClickListener(v -> {
            if (!running) {
                bet = (bet + 1) % BETS.length;
                betBtn.setText("BET " + BETS[bet]);
                draw();
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = dp(18);
        col.addView(betBtn, bp);
        go = button("START RACE", this::start);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2, -2);
        gp.topMargin = dp(10);
        col.addView(go, gp);
        draw();
    }

    @Override
    String title() {
        return "HORSE RACE";
    }

    private void draw() {
        info.setText("COINS " + Coins.get() + "   " + (pick < 0 ? "tap a horse" : NAMES[pick] + " for " + BETS[bet]));
        for (int i = 0; i < 4; i++) {
            int n = (int) (pos[i] * 22);
            StringBuilder sb = new StringBuilder(NAMES[i]).append(i == pick ? " ★" : "").append("\n");
            for (int k = 0; k < n; k++) {
                sb.append('·');
            }
            sb.append("🐎");
            lanes[i].setText(sb);
            lanes[i].setBackground(Theme.rounded(i == pick ? 0x44FFFFFF : 0x26FFFFFF, 12f, host));
        }
    }

    private void start() {
        if (running) {
            return;
        }
        if (pick < 0) {
            host.toast("Pick a horse first");
            return;
        }
        if (Coins.get() < BETS[bet]) {
            host.toast("Not enough coins");
            return;
        }
        Coins.add(-BETS[bet]);
        running = true;
        for (int i = 0; i < 4; i++) {
            pos[i] = 0f;
        }
        step();
    }

    private void step() {
        int win = -1;
        for (int i = 0; i < 4; i++) {
            pos[i] += 0.01f + rnd.nextFloat() * 0.035f;
            if (pos[i] >= 1f && win < 0) {
                win = i;
            }
        }
        draw();
        if (win < 0) {
            h.postDelayed(this::step, 90);
            return;
        }
        running = false;
        if (win == pick) {
            int prize = Math.round(BETS[bet] * 3.6f);
            Coins.add(prize);
            Sfx.play(Sfx.WIN);
            host.wizardSay(NAMES[win] + " wins! +" + prize + " coins");
        } else {
            Sfx.play(Sfx.LOSE);
            host.wizardSay(NAMES[win] + " won. Better luck next time.");
        }
        draw();
    }
}
