package app.novaos;

/** Shop upgrades that make the phone and the games nicer. Levels are stored as "up_<id>". */
final class Upgrades {
    private Upgrades() {}

    static int level(String id) {
        return Castle.admin() ? 99 : Prefs.getInt("up_" + id, 0);
    }

    static boolean has(String id) {
        return level(id) > 0;
    }

    static void set(String id, int lv) {
        Prefs.putInt("up_" + id, lv);
    }

    // ------------------------------------------------------------------ quests

    static final int QUEST_SLOT_COST = 1500;

    static int questSlots() {
        return has("quest4") ? 4 : 3;
    }

    // ------------------------------------------------------------------ slots

    static final int HIGH_ROLLER_COST = 2000;
    static final int AUTOSPIN_COST = 1500;
    static final int CHARM_COST = 300;

    static int[] bets() {
        return has("roller") ? new int[] {5, 10, 25, 50, 100, 250, 1000, 10000} : new int[] {5, 10, 25, 50, 1000, 10000};
    }

    static boolean charm() {
        return Prefs.getInt("luck_until", 0) > Castle.nowMin();
    }

    static int charmMinutes() {
        return Math.max(0, Prefs.getInt("luck_until", 0) - Castle.nowMin());
    }

    static void startCharm(int minutes) {
        Prefs.putInt("luck_until", Math.max(Castle.nowMin(), Prefs.getInt("luck_until", 0)) + minutes);
    }

    // ------------------------------------------------------------------ bank

    static final int[] CAP = {20000, 50000, 150000};
    static final int[] CAP_COST = {0, 2500, 10000};
    static final int INTEREST_COST = 4000;

    static int bankCap() {
        return CAP[Math.min(2, level("bankcap"))];
    }

    static int interest() {
        return has("bankint") ? 3 : 2;
    }

    // ------------------------------------------------------------------ daily spin ticket

    static final int TICKET_COST = 200;

    static int tickets() {
        return Prefs.getInt("spin_extra", 0);
    }

    // ------------------------------------------------------------------ golden coin magnet

    static final int MAGNET_COST = 3500;

    static float magnet() {
        return has("magnet") ? 1.7f : 1f;
    }

    // ------------------------------------------------------------------ castle gold mine

    static final int[] MINE_COST = {0, 3000, 8000, 20000};
    static final int[] MINE_RATE = {0, 12, 30, 70};      // coins per hour
    static final int MINE_CAP_HOURS = 8;

    static int mine() {
        return Math.min(3, level("mine"));
    }

    static void startMine() {
        Prefs.putInt("mine_last", Castle.nowMin());
    }

    static int mineReady() {
        int lv = mine();
        int last = Prefs.getInt("mine_last", 0);
        if (lv == 0 || last == 0) {
            return 0;
        }
        int mins = Math.min(MINE_CAP_HOURS * 60, Math.max(0, Castle.nowMin() - last));
        return MINE_RATE[lv] * mins / 60;
    }

    /** Pays out what the mine dug while you were away. Called when the home screen shows. */
    static void collectMine(NovaActivity host) {
        int lv = mine();
        if (lv == 0) {
            return;
        }
        if (Prefs.getInt("mine_last", 0) == 0) {
            startMine();
            return;
        }
        int ready = mineReady();
        if (ready < 5) {
            return;
        }
        startMine();
        int got = Coins.earn(ready);
        host.wizardSay("Your gold mine dug up " + got + " coins while you were away.");
        Sfx.play(Sfx.COIN);
    }

    // ------------------------------------------------------------------ phone

    static final int GRID5_COST = 1200;
    static final int DOCK5_COST = 1000;
    static final int PACK_COST = 600;

    static final String[] SHAPES = {"Normal", "Round", "Squircle", "Square"};
    static final String[] SOUND_PACKS = {"Classic", "Retro", "Bell", "Wood"};
    static final int NIGHT_COST = 800;
    static final int DANCER_COST = 900;

    static int shape() {
        return has("shapes") ? Math.max(0, Math.min(3, Prefs.getInt("s_icon_shape", 0))) : 0;
    }

    static int soundPack() {
        return has("sounds") ? Math.max(0, Math.min(3, Prefs.getInt("s_sound_pack", 0))) : 0;
    }

    static boolean wallpaperOwned(int mode) {
        return mode < LiveWallpaper.BASE || has("walls");
    }

    /** True from 21:00 to 06:00 when the night palette is switched on. */
    static boolean nightNow() {
        // only if you really bought it: admin mode must not switch the night palette on by itself
        if (Prefs.getInt("up_daynight", 0) == 0 || !Prefs.getBool("s_daynight", true)) {
            return false;
        }
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return h >= 21 || h < 6;
    }

    /** Rounds an icon's corners to the shape pack you picked. */
    static void shapeIcon(final android.view.View v) {
        final int s = shape();
        if (s == 0) {
            v.setClipToOutline(false);
            return;
        }
        v.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(android.view.View view, android.graphics.Outline o) {
                int w = view.getWidth();
                int h = view.getHeight();
                float r = s == 1 ? Math.min(w, h) / 2f : s == 2 ? Math.min(w, h) * 0.32f : Math.min(w, h) * 0.08f;
                o.setRoundRect(0, 0, w, h, r);
            }
        });
        v.setClipToOutline(true);
    }

    static final int CHATSTYLE_COST = 500;
    static final int STICKER_COST = 400;
    static final String[] BUBBLE_NAMES = {"Accent", "Mint", "Pink", "Gold", "Sky", "Lime"};
    static final int[] BUBBLE_COLORS = {0, 0xFF7AF0C0, 0xFFFF9AD5, 0xFFFFD35A, 0xFF8AC8FF, 0xFFC8FF5A};
    static final String[] FRAME_NAMES = {"None", "Gold", "Mint", "Pink", "Sky", "Fire"};
    static final int[] FRAME_COLORS = {0, 0xFFFFD35A, 0xFF7AF0C0, 0xFFFF9AD5, 0xFF8AC8FF, 0xFFFF7A3A};
    static final String[] STICKERS = {"(╯°□°)╯︵ ┻━┻", "¯\\_(ツ)_/¯", "ʕ•ᴥ•ʔ", "(づ｡◕‿‿◕｡)づ", "★彡 GG 彡★", "🔥🔥🔥",
        "👑 KING", "🐉 RAWR", "🍕🍕🍕", "💀💀", "✨ nice ✨", "o7"};

    static int bubble() {
        return has("chatstyle") ? Math.max(0, Math.min(BUBBLE_NAMES.length - 1, Prefs.getInt("net_bubble", 0))) : 0;
    }

    static int bubbleColor() {
        int b = bubble();
        return b == 0 ? Theme.ACCENT : BUBBLE_COLORS[b];
    }

    static int frame() {
        return has("chatstyle") ? Math.max(0, Math.min(FRAME_NAMES.length - 1, Prefs.getInt("net_frame", 0))) : 0;
    }

    /** Puts a coloured ring behind a picture of you. */
    static void frameIt(android.widget.ImageView v, int stroke) {
        int f = frame();
        if (f == 0) {
            return;
        }
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(stroke * 14f);
        g.setStroke(Math.max(2, stroke * 2), FRAME_COLORS[f]);
        g.setColor(0x22000000 | (FRAME_COLORS[f] & 0xFFFFFF));
        v.setBackground(g);
    }

    static final String[] DECOR = {"None", "Fireflies", "Lanterns", "Fountain"};
    static final int DECOR_COST = 700;

    static int decor() {
        return has("decor") ? Math.max(0, Math.min(3, Prefs.getInt("cs_decor", 0))) : 0;
    }

    static int gridCols() {
        return has("grid5") && Prefs.getBool("grid5_on", true) ? 5 : 4;
    }
}
