package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** The QUESTS page of the panel: today's three goals, progress bars and the streak. */
final class QuestPage extends LinearLayout {
    private final NovaActivity host;

    QuestPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        refresh();
    }

    void refresh() {
        removeAllViews();
        if (!Quests.on()) {
            addView(label("Quests are switched off in Settings.", 12f, Theme.DIM));
            return;
        }
        TextView head = label("STREAK " + Quests.streak() + " 🔥     COINS " + Coins.get(), 11f, Theme.ACCENT);
        head.setPadding(0, 0, 0, Theme.dp(host, 8));
        addView(head);
        List<Quests.Def> list = Quests.today3();
        for (Quests.Def d : list) {
            int p = Quests.progress(d);
            boolean done = Quests.done(d);
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = label((done ? "✓ " : "○ ") + d.text, 12f, done ? Theme.DIM : Theme.TEXT);
            t.setGravity(Gravity.START);
            row.addView(t, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            row.addView(label(p + "/" + d.target + "  +" + d.reward, 11f, done ? Theme.ACCENT : Theme.DIM));
            row.setPadding(0, Theme.dp(host, 5), 0, Theme.dp(host, 5));
            addView(row);
        }
        if (list.isEmpty()) {
            addView(label("No quests today.", 12f, Theme.DIM));
        }
    }

    private TextView label(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }
}
