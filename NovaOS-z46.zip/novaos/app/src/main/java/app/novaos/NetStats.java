package app.novaos;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.IsoFields;

/** The numbers NOVA Net shows on the ranklists. Counted on the phone and reported to your own server. */
final class NetStats {
    private NetStats() {}

    /** Same format as the server: ISO week in UTC, e.g. 2026-W41. */
    static String weekId() {
        ZonedDateTime d = ZonedDateTime.now(ZoneOffset.UTC);
        return String.format(java.util.Locale.US, "%04d-W%02d", d.get(IsoFields.WEEK_BASED_YEAR),
                d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR));
    }

    private static void init() {
        if (Prefs.getInt("ns_init", 0) == 0) {
            Prefs.putInt("ns_init", 1);
            Prefs.putInt("ns_all", Coins.get());
        }
    }

    /** Called for every coin you earn (not casino money, not admin gifts). */
    static void earned(int n) {
        if (n <= 0) {
            return;
        }
        init();
        String wk = weekId();
        if (!wk.equals(Prefs.getString("ns_week_id", ""))) {
            Prefs.putString("ns_week_id", wk);
            Prefs.putInt("ns_week", 0);
        }
        Prefs.putInt("ns_all", (int) Math.min(Integer.MAX_VALUE, (long) Prefs.getInt("ns_all", 0) + n));
        Prefs.putInt("ns_week", Prefs.getInt("ns_week", 0) + n);
    }

    static void questDone() {
        Prefs.putInt("ns_quests", Prefs.getInt("ns_quests", 0) + 1);
    }

    static int cosmetics() {
        int n = 0;
        for (java.util.Map.Entry<String, ?> e : Prefs.all().entrySet()) {
            if (e.getKey().startsWith("own_") && Integer.valueOf(1).equals(e.getValue())) {
                n++;
            }
        }
        return n;
    }

    /** The JSON body for POST /api/sync. */
    static org.json.JSONObject snapshot() throws org.json.JSONException {
        init();
        String wk = weekId();
        int week = wk.equals(Prefs.getString("ns_week_id", "")) ? Prefs.getInt("ns_week", 0) : 0;
        org.json.JSONObject o = new org.json.JSONObject();
        o.put("coins_all", Prefs.getInt("ns_all", 0));
        o.put("coins_week", week);
        o.put("week_id", wk);
        o.put("stage", Castle.stage());
        o.put("streak", Prefs.getInt("q_streak", 0));
        o.put("quests_total", Prefs.getInt("ns_quests", 0));
        o.put("cosmetics", cosmetics());
        o.put("title", Shop.title() > 0 ? Shop.titleName() : "");
        org.json.JSONArray look = new org.json.JSONArray();
        for (int v : Avatar.look()) {
            look.put(v);
        }
        o.put("look", look);
        o.put("cheat", Prefs.getInt("admin_ever", 0) == 1);
        return o;
    }
}
