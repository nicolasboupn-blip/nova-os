package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

/** Shows your character. If he wears wings they flap while the view is on screen. */
final class AvatarView extends ImageView {
    private final int zoom;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int frame;
    private int[] look = Avatar.look();
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!Avatar.hasWings(look) || !isShown()) {
                return;
            }
            frame = (frame + 1) & 3;
            draw();
            h.postDelayed(this, 170);
        }
    };

    AvatarView(NovaActivity host, int zoom) {
        super(host);
        this.zoom = zoom;
        setScaleType(ScaleType.CENTER_INSIDE);
        reload();
    }

    /** Re-reads the saved look and redraws. */
    void reload() {
        look = Avatar.look();
        draw();
        h.removeCallbacks(tick);
        if (Avatar.hasWings(look)) {
            h.postDelayed(tick, 170);
        }
    }

    private void draw() {
        android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(Avatar.render(look, frame), Avatar.W, Avatar.H,
                android.graphics.Bitmap.Config.ARGB_8888);
        setImageBitmap(android.graphics.Bitmap.createScaledBitmap(b, Avatar.W * zoom, Avatar.H * zoom, false));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        reload();
    }

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }
}
