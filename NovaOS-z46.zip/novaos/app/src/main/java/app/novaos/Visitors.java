package app.novaos;

/**
 * Castle visitors drawn in code: a knight, a travelling merchant and a thief. Pure Java so they can be previewed on a
 * desktop. All face right, W x H pixels, feet on the bottom row around x = AX.
 */
final class Visitors {
    static final int KNIGHT = 0, MERCHANT = 1, THIEF = 2;
    static final int W = 24, H = 30, AX = 12, AY = 29;
    private static final int OUT = 0xFF1C1626;

    private Visitors() {}

    private static int c(int r, int g, int b) {
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void rc(int[] px, int x, int y, int w, int h, int col) {
        for (int j = y; j < y + h; j++) {
            for (int i = x; i < x + w; i++) {
                if (i >= 0 && j >= 0 && i < W && j < H) {
                    px[j * W + i] = col;
                }
            }
        }
    }

    private static void dot(int[] px, int x, int y, int col) {
        rc(px, x, y, 1, 1, col);
    }

    /** A one pixel dark outline around everything that is drawn. */
    private static int[] outline(int[] px) {
        int[] o = px.clone();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (px[y * W + x] != 0) {
                    continue;
                }
                boolean near = false;
                for (int dy = -1; dy <= 1 && !near; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        if ((dx == 0) == (dy == 0)) {
                            continue;
                        }
                        int xx = x + dx;
                        int yy = y + dy;
                        if (xx >= 0 && yy >= 0 && xx < W && yy < H && px[yy * W + xx] != 0) {
                            near = true;
                            break;
                        }
                    }
                }
                if (near) {
                    o[y * W + x] = OUT;
                }
            }
        }
        return o;
    }

    static int[] render(int kind) {
        int[] px = new int[W * H];
        switch (kind) {
            case KNIGHT:
                knight(px);
                break;
            case MERCHANT:
                merchant(px);
                break;
            default:
                thief(px);
                break;
        }
        return outline(px);
    }

    // ------------------------------------------------------------------ the knight: bright steel, red tabard, cross shield

    private static void knight(int[] px) {
        final int sL = c(226, 232, 244), sM = c(160, 170, 192), sD = c(98, 108, 134), sX = c(62, 70, 96);
        final int red = c(200, 48, 44), redD = c(136, 28, 34), gold = c(240, 190, 58), goldD = c(176, 124, 30);
        final int white = c(240, 236, 226), brown = c(96, 62, 36);
        // plume streaming back
        rc(px, 9, 0, 3, 2, red);
        rc(px, 6, 1, 4, 2, redD);
        rc(px, 4, 2, 3, 2, redD);
        rc(px, 8, 2, 3, 1, red);
        // helm
        rc(px, 8, 3, 8, 8, sM);
        dot(px, 8, 3, 0);
        dot(px, 15, 3, 0);
        rc(px, 8, 4, 2, 6, sL);
        rc(px, 10, 3, 4, 1, sL);
        rc(px, 15, 4, 1, 7, sD);
        rc(px, 11, 6, 5, 1, sX);   // eye slit
        rc(px, 12, 8, 3, 1, sX);   // breaths
        rc(px, 12, 9, 3, 1, sX);
        rc(px, 8, 10, 8, 1, sD);
        // gorget
        rc(px, 9, 11, 6, 2, sD);
        // shoulders
        rc(px, 6, 12, 5, 4, sL);
        rc(px, 7, 13, 3, 3, sM);
        rc(px, 14, 12, 5, 4, sM);
        rc(px, 17, 13, 2, 3, sD);
        // tabard
        rc(px, 8, 13, 8, 10, red);
        rc(px, 8, 13, 1, 10, redD);
        rc(px, 15, 13, 1, 10, redD);
        rc(px, 11, 13, 2, 7, gold);
        rc(px, 10, 15, 4, 2, gold);
        rc(px, 8, 20, 8, 1, goldD);   // belt
        rc(px, 11, 20, 2, 1, gold);
        rc(px, 8, 22, 8, 1, redD);
        // legs and boots
        rc(px, 8, 23, 3, 4, sM);
        rc(px, 13, 23, 3, 4, sM);
        rc(px, 8, 23, 1, 4, sL);
        rc(px, 13, 23, 1, 4, sL);
        rc(px, 10, 23, 1, 4, sD);
        rc(px, 15, 23, 1, 4, sD);
        rc(px, 7, 27, 4, 3, sD);
        rc(px, 13, 27, 5, 3, sD);
        rc(px, 7, 27, 4, 1, sM);
        rc(px, 13, 27, 5, 1, sM);
        // kite shield on the near side
        int[] sw = {7, 7, 7, 7, 6, 6, 5, 4, 3, 1};
        for (int i = 0; i < sw.length; i++) {
            int w = sw[i];
            int x0 = 2 + (7 - w) / 2;
            rc(px, x0, 15 + i, w, 1, goldD);
            if (w > 2) {
                rc(px, x0 + 1, 15 + i, w - 2, 1, white);
            }
        }
        rc(px, 5, 16, 1, 7, red);
        rc(px, 3, 18, 5, 1, red);
        rc(px, 2, 15, 7, 1, gold);
        dot(px, 2, 15, goldD);
        dot(px, 8, 15, goldD);
        // sword arm lifted, blade up
        rc(px, 17, 16, 3, 3, sM);
        rc(px, 18, 15, 2, 1, sM);
        rc(px, 19, 4, 1, 11, sL);
        rc(px, 20, 6, 1, 9, sM);
        dot(px, 19, 3, sL);
        rc(px, 17, 14, 5, 1, gold);
        rc(px, 19, 15, 1, 1, brown);
    }

    // ------------------------------------------------------------------ the merchant: purple hood, huge pack, lantern

    private static void merchant(int[] px) {
        final int pur = c(128, 70, 168), purD = c(84, 44, 118), purL = c(166, 108, 204);
        final int skin = c(236, 184, 140), skinD = c(190, 130, 96), beard = c(226, 224, 218);
        final int brown = c(130, 84, 44), brownD = c(84, 52, 28), brownL = c(176, 122, 70);
        final int gold = c(244, 196, 64), goldD = c(176, 124, 30), pot = c(150, 156, 170), potD = c(96, 102, 120);
        final int green = c(96, 168, 92), cloth = c(210, 90, 70);
        // backpack, big and stuffed
        rc(px, 0, 8, 9, 14, brown);
        rc(px, 0, 8, 9, 2, brownL);
        rc(px, 8, 9, 1, 12, brownD);
        rc(px, 1, 11, 6, 1, brownD);
        rc(px, 1, 17, 7, 1, brownD);
        rc(px, 1, 5, 7, 4, cloth);       // bedroll on top
        rc(px, 1, 5, 7, 1, c(238, 130, 110));
        rc(px, 2, 3, 3, 3, pot);         // pot tied on
        rc(px, 2, 3, 3, 1, c(214, 220, 232));
        rc(px, 4, 5, 1, 1, potD);
        rc(px, 6, 3, 2, 3, green);       // a bottle
        dot(px, 6, 2, brownL);
        // robe
        rc(px, 9, 11, 10, 15, pur);
        rc(px, 9, 11, 2, 15, purL);
        rc(px, 17, 11, 2, 15, purD);
        rc(px, 9, 18, 10, 1, goldD);     // sash
        rc(px, 14, 18, 2, 3, gold);
        rc(px, 9, 25, 10, 1, purD);
        // hood and face
        rc(px, 9, 3, 9, 8, pur);
        dot(px, 9, 3, 0);
        dot(px, 17, 3, 0);
        rc(px, 9, 4, 2, 6, purL);
        rc(px, 17, 4, 1, 6, purD);
        rc(px, 12, 5, 6, 5, skin);
        rc(px, 12, 5, 1, 5, skinD);
        rc(px, 15, 6, 1, 1, c(40, 30, 40));   // eye
        rc(px, 17, 7, 2, 2, skin);            // nose
        rc(px, 12, 9, 6, 3, beard);           // beard
        rc(px, 13, 11, 4, 1, c(190, 188, 182));
        // arm with lantern
        rc(px, 17, 13, 3, 4, pur);
        rc(px, 19, 15, 2, 2, skin);
        rc(px, 20, 16, 1, 1, brownD);
        rc(px, 20, 17, 3, 1, goldD);
        rc(px, 20, 18, 3, 4, c(255, 224, 120));
        rc(px, 21, 19, 1, 2, c(255, 250, 200));
        rc(px, 20, 22, 3, 1, goldD);
        // boots
        rc(px, 10, 26, 4, 4, brownD);
        rc(px, 15, 26, 4, 4, brownD);
        rc(px, 10, 26, 4, 1, brown);
        rc(px, 15, 26, 4, 1, brown);
        rc(px, 14, 27, 1, 3, 0);
    }

    // ------------------------------------------------------------------ the thief: dark cloak, mask, dagger, loot sack

    private static void thief(int[] px) {
        final int cl = c(54, 62, 78), clD = c(34, 40, 54), clL = c(84, 96, 118);
        final int skin = c(226, 176, 136), mask = c(30, 30, 40), eye = c(250, 250, 240);
        final int scarf = c(214, 70, 62), scarfD = c(150, 44, 48);
        final int sack = c(176, 140, 84), sackD = c(120, 92, 54), sackL = c(210, 176, 118);
        final int gold = c(244, 196, 64), steel = c(220, 228, 240), steelD = c(150, 160, 180), brown = c(90, 58, 34);
        // sack of loot slung on the back
        rc(px, 1, 12, 8, 11, sack);
        rc(px, 1, 12, 2, 11, sackL);
        rc(px, 7, 13, 2, 10, sackD);
        rc(px, 3, 10, 4, 3, sack);
        rc(px, 2, 12, 6, 1, scarfD);       // tie
        dot(px, 4, 16, gold);
        dot(px, 6, 19, gold);
        dot(px, 3, 21, gold);
        // body, leaning forward a little
        rc(px, 9, 12, 9, 11, cl);
        rc(px, 9, 12, 2, 11, clL);
        rc(px, 16, 12, 2, 11, clD);
        rc(px, 9, 21, 9, 1, clD);
        rc(px, 9, 16, 9, 1, brown);        // belt
        rc(px, 12, 16, 2, 1, gold);
        // hood and head
        rc(px, 9, 3, 9, 9, cl);
        dot(px, 9, 3, 0);
        dot(px, 17, 3, 0);
        rc(px, 9, 4, 2, 7, clL);
        rc(px, 16, 4, 2, 7, clD);
        rc(px, 11, 6, 7, 3, skin);         // face opening
        rc(px, 11, 6, 7, 2, mask);         // bandit mask
        rc(px, 14, 6, 2, 1, eye);
        dot(px, 15, 6, c(30, 30, 40));
        rc(px, 11, 9, 7, 2, scarf);        // scarf over the mouth
        rc(px, 11, 10, 7, 1, scarfD);
        rc(px, 6, 10, 4, 2, scarf);        // flowing tail
        rc(px, 4, 11, 3, 2, scarfD);
        // arm and dagger
        rc(px, 16, 14, 3, 3, cl);
        rc(px, 18, 15, 2, 2, skin);
        rc(px, 20, 12, 1, 4, steel);
        rc(px, 21, 13, 1, 3, steelD);
        dot(px, 20, 11, steel);
        rc(px, 19, 16, 3, 1, gold);
        // legs
        rc(px, 10, 22, 3, 5, clD);
        rc(px, 14, 22, 3, 5, clD);
        rc(px, 10, 22, 1, 5, cl);
        rc(px, 14, 22, 1, 5, cl);
        rc(px, 9, 27, 4, 3, brown);
        rc(px, 14, 27, 5, 3, brown);
    }
}
