package app.novaos;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import java.util.Locale;
import java.util.Random;

/**
 * The "Access" startup: a fake system check with a roulette wheel, the castle, a slot machine and
 * the wizard, then a big open green padlock and "ACCESS ACCEPTED". Tap to skip.
 * Two looks: Hacker (code rain, smaller glitchy pictures, text bar) and Cinematic (full size).
 */
final class AccessScreen extends FrameLayout {
    static final String K_ON = "s_acc_on";
    static final String K_SECS = "s_acc_secs";
    static final String K_AWAY = "s_acc_away";
    static final String K_LAST = "s_acc_last";
    static final String K_STYLE = "s_acc_style";
    static final String[] STYLE_NAMES = {"Hacker", "Cinematic"};
    static final String[] AWAY_NAMES = {"Always", "5 min", "15 min", "30 min", "1 hour", "3 hours", "6 hours", "12 hours"};
    static final int[] AWAY_MIN = {0, 5, 15, 30, 60, 180, 360, 720};
    private static final int GREEN = 0xFF39FF88;
    private static final String GLYPHS = "01<>{}[]/\\|#$%&*+=";
    private static final int ROWS = 16;

    /** True if the sequence should play for this unlock. */
    static boolean shouldPlay() {
        if (!Prefs.getBool(K_ON, false) || Saver.on()) {
            return false;
        }
        int i = Math.max(0, Math.min(AWAY_MIN.length - 1, Prefs.getInt(K_AWAY, 4)));
        int last = Prefs.getInt(K_LAST, 0);
        return last == 0 || Castle.nowMin() - last >= AWAY_MIN[i];
    }

    static int seconds() {
        return Math.max(2, Math.min(20, Prefs.getInt(K_SECS, 8)));
    }

    static boolean hacker() {
        return Prefs.getInt(K_STYLE, 0) == 0;
    }

    private static final String[] STATUS = {
        "Greasing the roulette wheel", "Checking the castle gates", "Counting the slot reels",
        "Waking the wizard", "Verifying identity", "Almost there"};
    private static final String[] SYM = {"7", "$", "★", "♦", "BAR"};
    private static final int[] SYM_COL = {0xFFFF3B4E, 0xFF39FF88, 0xFFFFD34D, 0xFF5CC8FF, 0xFFFFFFFF};
    private static final float[][] CURVE = {
        {0f, 0f}, {0.12f, 0.08f}, {0.30f, 0.14f}, {0.42f, 0.55f}, {0.60f, 0.60f},
        {0.78f, 0.90f}, {0.90f, 0.93f}, {1f, 1f}};

    private final NovaActivity host;
    private final boolean hack;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Stage stage;
    private final RouletteWheel wheel;
    private final Bitmap castle;
    private final Bitmap wizard;
    private final float dens;
    private ValueAnimator run;
    private ValueAnimator open;
    private float prog;
    private float openT;
    private boolean accepted;
    private boolean left;
    private boolean attached = true;
    private final float[] pos = new float[3];
    private final boolean[] stopped = new boolean[3];
    private final float[] stopAt = {0.55f, 0.70f, 0.84f};
    private long lastNs;

    AccessScreen(NovaActivity host, boolean test) {
        super(host);
        this.host = host;
        dens = host.getResources().getDisplayMetrics().density;
        hack = hacker();
        setBackgroundColor(Color.BLACK);
        castle = load(host, "castle_night");
        wizard = WizardView.loadSprite(host);
        stage = new Stage(host);
        addView(stage, new LayoutParams(-1, -1));
        wheel = new RouletteWheel(host);
        addView(wheel, new LayoutParams(10, 10));
        spinWheel();

        run = ValueAnimator.ofFloat(0f, 1f);
        run.setDuration(seconds() * 1000L);
        run.setInterpolator(new LinearInterpolator());
        run.addUpdateListener(a -> {
            prog = curve((float) a.getAnimatedValue());
            stage.invalidate();
        });
        run.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator an) {
                accept();
            }
        });
        run.start();
        setOnClickListener(v -> {
            if (accepted) {
                leave();
            } else {
                run.cancel();
            }
        });
    }

    private static Bitmap load(Context c, String name) {
        int id = c.getResources().getIdentifier(name, "drawable", c.getPackageName());
        if (id == 0) {
            return null;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeResource(c.getResources(), id, o);
    }

    private static float curve(float t) {
        for (int i = 1; i < CURVE.length; i++) {
            if (t <= CURVE[i][0]) {
                float a = (t - CURVE[i - 1][0]) / (CURVE[i][0] - CURVE[i - 1][0]);
                return CURVE[i - 1][1] + (CURVE[i][1] - CURVE[i - 1][1]) * a;
            }
        }
        return 1f;
    }

    /** Layout factor: the Hacker look uses smaller pictures. */
    private float k() {
        return hack ? 0.6f : 1f;
    }

    private float cyTop(int h) {
        return h * 0.22f;
    }

    private float cyBot(int h) {
        return h * 0.78f;
    }

    private void spinWheel() {
        if (accepted || !attached) {
            return;
        }
        wheel.spin(rnd.nextInt(37), () -> handler.postDelayed(this::spinWheel, hack ? 90 : 150));
    }

    private void accept() {
        if (accepted) {
            return;
        }
        accepted = true;
        prog = 1f;
        for (int i = 0; i < 3; i++) {
            stopped[i] = true;
        }
        wheel.animate().alpha(0.12f).setDuration(500).start();
        Sfx.play(Sfx.WIN);
        host.buzz(80);
        open = ValueAnimator.ofFloat(0f, 1f);
        open.setDuration(900);
        open.setStartDelay(250);
        open.addUpdateListener(a -> {
            openT = (float) a.getAnimatedValue();
            stage.invalidate();
        });
        open.start();
        handler.postDelayed(this::leave, 2900);
    }

    private void leave() {
        if (left) {
            return;
        }
        left = true;
        host.showHome();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int s = (int) (Math.min(w * 0.42f, h * 0.30f) * k());
        LayoutParams lp = (LayoutParams) wheel.getLayoutParams();
        lp.width = s;
        lp.height = s;
        lp.leftMargin = (int) (w * 0.25f - s / 2f);
        lp.topMargin = (int) (cyTop(h) - s / 2f);
        wheel.setLayoutParams(lp);
    }

    @Override
    protected void onDetachedFromWindow() {
        attached = false;
        handler.removeCallbacksAndMessages(null);
        if (run != null) {
            run.removeAllListeners();
            run.cancel();
        }
        if (open != null) {
            open.cancel();
        }
        super.onDetachedFromWindow();
    }

    /** Everything except the wheel is drawn here. */
    private final class Stage extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint px = new Paint();
        private final Path path = new Path();
        private final RectF r = new RectF();
        private final RectF r2 = new RectF();
        private int rainW = -1;
        private int rainH = -1;
        private int cols;
        private float colW;
        private float rowH;
        private float[] rainY = new float[0];
        private float[] rainSpeed = new float[0];
        private char[][] rainChars = new char[0][];
        private Shader barShader;
        private float barW = -1f;
        private float hexAt = -1f;
        private String hex = "";

        Stage(Context c) {
            super(c);
            px.setFilterBitmap(false);
            p.setTypeface(Typeface.MONOSPACE);
        }

        private float d(float v) {
            return v * dens;
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            float tm = now / 1e9f;
            float dim = accepted ? 1f - 0.8f * Math.min(1f, openT * 2f) : 1f;
            // Hacker look: short glitch bursts every ~1.9 s
            float glitch = hack && (long) (tm * 1000) % 1900 < 140 ? 1f : 0f;

            if (hack) {
                drawRain(c, w, h, dt, dim);
            }
            drawCastle(c, w, h, tm, dim, glitch);
            drawSlot(c, w, h, dt, dim);
            drawWizard(c, w, h, tm, dim, glitch);
            drawHud(c, w, h, tm, glitch);
            if (accepted) {
                drawLock(c, w, h, tm);
            }
            postInvalidateOnAnimation();
        }

        private void drawRain(Canvas c, int w, int h, float dt, float dim) {
            if (rainW != w || rainH != h) {
                rainW = w;
                rainH = h;
                rowH = d(12);
                cols = Math.max(6, (int) (w / d(12)));
                colW = w / (float) cols;
                rainY = new float[cols];
                rainSpeed = new float[cols];
                rainChars = new char[cols][ROWS];
                for (int i = 0; i < cols; i++) {
                    rainY[i] = rnd.nextFloat() * h;
                    rainSpeed[i] = d(70) + rnd.nextFloat() * d(170);
                    for (int j = 0; j < ROWS; j++) {
                        rainChars[i][j] = GLYPHS.charAt(rnd.nextInt(GLYPHS.length()));
                    }
                }
            }
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextSize(d(10));
            p.setTextAlign(Paint.Align.LEFT);
            p.setFakeBoldText(false);
            for (int i = 0; i < cols; i++) {
                rainY[i] += rainSpeed[i] * dt;
                if (rainY[i] - ROWS * rowH > h) {
                    rainY[i] = -rnd.nextFloat() * h * 0.4f;
                    rainSpeed[i] = d(70) + rnd.nextFloat() * d(170);
                }
                rainChars[i][rnd.nextInt(ROWS)] = GLYPHS.charAt(rnd.nextInt(GLYPHS.length()));
                float x = i * colW + d(1);
                for (int j = 0; j < ROWS; j++) {
                    float y = rainY[i] - j * rowH;
                    if (y < 0 || y > h) {
                        continue;
                    }
                    if (j == 0) {
                        p.setColor(Color.argb((int) (255 * dim), 225, 255, 235));
                    } else {
                        float f = 1f - j / (float) ROWS;
                        p.setColor(Color.argb((int) (150 * f * f * dim), 57, 255, 136));
                    }
                    c.drawText(rainChars[i], j, 1, x, y, p);
                }
            }
        }

        /** Draws a picture; during a glitch it is cut into bands that jump sideways. */
        private void blit(Canvas c, Bitmap b, RectF box, int alpha, float glitch) {
            px.setAlpha(alpha);
            if (glitch <= 0f) {
                c.drawBitmap(b, null, box, px);
            } else {
                int bands = 6;
                float bh = box.height() / bands;
                for (int i = 0; i < bands; i++) {
                    float sh = rnd.nextFloat() < 0.5f ? (rnd.nextFloat() * 2f - 1f) * d(9) : 0f;
                    c.save();
                    c.clipRect(box.left, box.top + i * bh, box.right, box.top + (i + 1) * bh);
                    r2.set(box.left + sh, box.top, box.right + sh, box.bottom);
                    c.drawBitmap(b, null, r2, px);
                    c.restore();
                }
            }
            px.setAlpha(255);
        }

        private void drawCastle(Canvas c, int w, int h, float tm, float dim, float glitch) {
            float kk = k();
            float cx = w * 0.75f;
            float cy = cyTop(h);
            float ch = h * 0.30f * kk;
            float pulse = 0.75f + 0.25f * (float) Math.sin(tm * 3f);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, ch * 0.8f,
                    ((int) (90 * pulse * dim) << 24) | (Theme.ACCENT & 0xFFFFFF),
                    Theme.ACCENT & 0xFFFFFF, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, ch * 0.8f, p);
            p.setShader(null);
            if (castle != null) {
                float dw = castle.getWidth() * ch / castle.getHeight();
                r.set(cx - dw / 2f, cy - ch / 2f, cx + dw / 2f, cy + ch / 2f);
                blit(c, castle, r, (int) (255 * dim), glitch);
            }
        }

        private void drawSlot(Canvas c, int w, int h, float dt, float dim) {
            float kk = k();
            float cx = w * 0.25f;
            float cy = cyBot(h);
            float cellH = d(46) * kk;
            float cellW = d(42) * kk;
            float gap = d(6) * kk;
            float total = cellW * 3 + gap * 4;
            float top = cy - cellH / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(hack ? Color.argb((int) (255 * dim), 6, 20, 10) : Color.argb((int) (255 * dim), 40, 12, 24));
            r.set(cx - total / 2f, top - d(10) * kk, cx + total / 2f, top + cellH + d(10) * kk);
            c.drawRoundRect(r, d(10) * kk, d(10) * kk, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(d(2.5f) * kk);
            p.setColor(Color.argb((int) (255 * dim), hack ? 57 : 255, hack ? 255 : 211, hack ? 136 : 77));
            c.drawRoundRect(r, d(10) * kk, d(10) * kk, p);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                if (!stopped[i] && prog >= stopAt[i]) {
                    stopped[i] = true;
                    host.buzz(25);
                    Sfx.play(Sfx.CLICK);
                }
                if (!stopped[i]) {
                    pos[i] += dt * (14f + i * 2f);
                } else {
                    float target = (float) Math.ceil(pos[i] / SYM.length) * SYM.length;
                    pos[i] += (target - pos[i]) * Math.min(1f, dt * 10f);
                    if (target - pos[i] < 0.02f) {
                        pos[i] = target;
                    }
                }
                float x0 = cx - total / 2f + gap + i * (cellW + gap);
                r.set(x0, top, x0 + cellW, top + cellH);
                p.setColor(Color.argb((int) (255 * dim), 245, 240, 230));
                c.drawRect(r, p);
                c.save();
                c.clipRect(r);
                int base = (int) Math.floor(pos[i]);
                float frac = pos[i] - base;
                float ts = d(28) * kk;
                p.setTextAlign(Paint.Align.CENTER);
                p.setFakeBoldText(true);
                for (int j = -1; j <= 1; j++) {
                    int idx = Math.floorMod(base + j, SYM.length);
                    float yc = top + cellH / 2f + (j - frac) * cellH;
                    p.setTextSize(idx == 4 ? ts * 0.55f : ts);
                    p.setColor(SYM_COL[idx] == 0xFFFFFFFF ? 0xFF222222 : SYM_COL[idx]);
                    p.setAlpha((int) (255 * dim));
                    c.drawText(SYM[idx], x0 + cellW / 2f, yc + p.getTextSize() * 0.36f, p);
                }
                c.restore();
                p.setFakeBoldText(false);
                p.setAlpha(255);
            }
        }

        private void drawWizard(Canvas c, int w, int h, float tm, float dim, float glitch) {
            float kk = k();
            float cx = w * 0.75f;
            float cy = cyBot(h);
            float ch = h * 0.30f * kk;
            float bob = (float) Math.sin(tm * 2.4f) * d(4) * kk;
            if (wizard != null) {
                float dw = wizard.getWidth() * ch / wizard.getHeight();
                r.set(cx - dw / 2f, cy - ch / 2f + bob, cx + dw / 2f, cy + ch / 2f + bob);
                blit(c, wizard, r, (int) (255 * dim), glitch);
            }
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 6; i++) {
                float a = tm * 1.8f + i * 1.0472f;
                float sx = cx + (float) Math.cos(a) * d(48) * kk;
                float sy = cy + (float) Math.sin(a * 1.3f) * ch * 0.42f + bob;
                p.setColor(Color.argb((int) (200 * dim), 179, 157, 255));
                c.drawCircle(sx, sy, d(2.2f) * kk, p);
            }
        }

        private void drawHud(Canvas c, int w, int h, float tm, float glitch) {
            float bw = w * (hack ? 0.70f : 0.78f);
            float bx = (w - bw) / 2f;
            float by = h * 0.50f;
            float fade = accepted ? Math.max(0f, 1f - openT * 2f) : 1f;
            if (fade <= 0f) {
                return;
            }
            if (hack) {
                drawHackHud(c, h, tm, bx, by, bw, fade, glitch);
                return;
            }
            float bh = d(12);
            p.setTextAlign(Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(d(12));
            p.setColor(Theme.DIM);
            p.setAlpha((int) (255 * fade));
            int si = Math.min(STATUS.length - 1, (int) (prog * STATUS.length));
            c.drawText(STATUS[si] + dots(tm), w / 2f, by - d(14), p);
            p.setColor(Color.argb((int) (255 * fade), 30, 26, 50));
            r.set(bx, by, bx + bw, by + bh);
            c.drawRoundRect(r, bh / 2f, bh / 2f, p);
            if (barShader == null || barW != bw) {
                barW = bw;
                barShader = new LinearGradient(bx, 0, bx + bw, 0, Theme.ACCENT, GREEN, Shader.TileMode.CLAMP);
            }
            p.setShader(barShader);
            p.setAlpha((int) (255 * fade));
            r.set(bx, by, bx + Math.max(bh, bw * prog), by + bh);
            c.drawRoundRect(r, bh / 2f, bh / 2f, p);
            p.setShader(null);
            p.setColor(Theme.TEXT);
            p.setAlpha((int) (255 * fade));
            p.setTextSize(d(18));
            c.drawText((int) (prog * 100) + "%", w / 2f, by + bh + d(26), p);
            p.setAlpha(255);
        }

        /** Terminal style: typed status, a text progress bar and a hex stream. */
        private void drawHackHud(Canvas c, int h, float tm, float bx, float by, float bw, float fade, float glitch) {
            int a = (int) (255 * fade);
            float sx = glitch > 0f ? (rnd.nextFloat() * 2f - 1f) * d(6) : 0f;
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.MONOSPACE);
            p.setFakeBoldText(false);
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(d(12));
            int si = Math.min(STATUS.length - 1, (int) (prog * STATUS.length));
            String cursor = (int) (tm * 2.5f) % 2 == 0 ? "_" : " ";
            String line = "> " + STATUS[si].toLowerCase(Locale.US).replace(' ', '_') + dots(tm) + cursor;
            p.setColor(Color.argb(a, 57, 255, 136));
            c.drawText(line, bx + sx, by - d(16), p);

            int n = (int) (prog * 24);
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < 24; i++) {
                sb.append(i < n ? '#' : '.');
            }
            sb.append("] ").append((int) (prog * 100)).append('%');
            p.setColor(Color.argb(a, 57, 255, 136));
            c.drawText(sb.toString(), bx + sx, by + d(4), p);

            if (tm - hexAt > 0.09f) {
                hexAt = tm;
                StringBuilder hx = new StringBuilder("0x");
                for (int i = 0; i < 16; i++) {
                    hx.append(Character.forDigit(rnd.nextInt(16), 16));
                }
                hex = hx.toString().toUpperCase(Locale.US);
            }
            p.setTextSize(d(10));
            p.setColor(Color.argb((int) (110 * fade), 57, 255, 136));
            c.drawText(hex, bx, h * 0.92f, p);
        }

        private String dots(float tm) {
            int n = (int) (tm * 3) % 4;
            return "...".substring(0, n);
        }

        private void drawLock(Canvas c, int w, int h, float tm) {
            float o = openT;
            float bw = Math.min(w * 0.44f, h * 0.22f);
            float bh = bw * 0.80f;
            float cx = w / 2f;
            float cy = h * 0.42f;
            float bTop = cy - bh / 2f + bw * 0.25f;
            // glow
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, bw * 1.5f,
                    ((int) (140 * Math.min(1f, o + 0.3f)) << 24) | (GREEN & 0xFFFFFF),
                    GREEN & 0xFFFFFF, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, bw * 1.5f, p);
            p.setShader(null);
            // shackle: swings open around its left foot
            float sw = bw * 0.62f;
            float stroke = bw * 0.14f;
            float xl = cx - sw / 2f;
            float xr = cx + sw / 2f;
            float legTop = bTop - bw * 0.34f;
            c.save();
            c.translate(0f, -bw * 0.18f * o);
            c.rotate(-28f * o, xl, bTop);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(stroke);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0xFFD7FFE6);
            path.reset();
            path.moveTo(xl, bTop + stroke);
            path.lineTo(xl, legTop);
            r.set(xl, legTop - sw / 2f, xr, legTop + sw / 2f);
            path.arcTo(r, 180f, 180f, false);
            path.lineTo(xr, bTop + stroke);
            c.drawPath(path, p);
            c.restore();
            p.setStrokeCap(Paint.Cap.BUTT);
            // body
            p.setStyle(Paint.Style.FILL);
            r.set(cx - bw / 2f, bTop, cx + bw / 2f, bTop + bh);
            p.setColor(GREEN);
            c.drawRoundRect(r, bw * 0.12f, bw * 0.12f, p);
            p.setColor(0xFF0B7A3B);
            c.drawCircle(cx, bTop + bh * 0.42f, bw * 0.10f, p);
            r.set(cx - bw * 0.04f, bTop + bh * 0.42f, cx + bw * 0.04f, bTop + bh * 0.72f);
            c.drawRoundRect(r, bw * 0.03f, bw * 0.03f, p);
            // text
            float ta = Math.max(0f, Math.min(1f, (o - 0.3f) / 0.7f));
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setFakeBoldText(true);
            p.setTextSize(Math.min(w * 0.095f, d(40)));
            p.setColor(GREEN);
            p.setAlpha((int) (255 * ta));
            p.setShadowLayer(d(14), 0, 0, GREEN);
            float ty = bTop + bh + bw * 0.55f;
            c.drawText("ACCESS", cx, ty, p);
            c.drawText("ACCEPTED", cx, ty + p.getTextSize() * 1.15f, p);
            p.setShadowLayer(0, 0, 0, 0);
            p.setFakeBoldText(false);
            p.setAlpha(255);
        }
    }
}
