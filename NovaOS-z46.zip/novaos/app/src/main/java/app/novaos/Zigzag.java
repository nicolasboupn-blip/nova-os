package app.novaos;

/**
 * The Zigzag collection: seven editions, each with a shield, a pair of flapping wings, a cape and a castle skin. The
 * lightning-zigzag is the motif. Colours and prices live here; the drawing is in Avatar and CastleView.
 */
final class Zigzag {
    static final String[] NAMES = {"Zigzag I", "Zigzag II", "Zigzag III", "Zigzag IV", "Zigzag V", "Zigzag Black", "Zigzag Gold"};
    /** Main colour, shining accent, deep shade and a middle shade for each edition. */
    static final int[] PRI = {0x3CCB7A, 0x3A8FE8, 0x8A4AE8, 0xE8662A, 0xD02A4A, 0x2C2C3A, 0xF0C040};
    static final int[] ACC = {0xE8FFF0, 0x9AF0FF, 0xFF9AF0, 0xFFE08A, 0xFFC8A0, 0xC8D0FF, 0xFFFFFF};
    static final int[] DARK = {0x1E6A42, 0x1C4A8A, 0x4A2A8A, 0x8A2E14, 0x6A1428, 0x0A0A12, 0xA87A1E};
    static final int[] SHIELD_COST = {400, 700, 1100, 1700, 2600, 4500, 7000};
    static final int[] WINGS_COST = {900, 1500, 2300, 3500, 5500, 9000, 14000};
    static final int[] CAPE_COST = {700, 1200, 1800, 2800, 4300, 7000, 11000};
    static final int[] CASTLE_COST = {1500, 2500, 3800, 5800, 9000, 15000, 24000};

    /** Style number of the first Zigzag castle skin. */
    static final int FIRST_STYLE = 7;

    private Zigzag() {}

    /** The whole set costs 20% less than buying the three parts. */
    static int setCost(int i) {
        int sum = SHIELD_COST[i] + WINGS_COST[i] + CAPE_COST[i] + CASTLE_COST[i];
        return Math.round(sum * 0.8f / 50f) * 50;
    }

    static boolean ownsShield(int i) {
        return Castle.admin() || Prefs.getInt("own_zzshield" + (i + 1), 0) == 1;
    }

    static boolean ownsWings(int i) {
        return Castle.admin() || Prefs.getInt("own_zzwings" + (i + 1), 0) == 1;
    }

    static boolean ownsCape(int i) {
        return Castle.admin() || Prefs.getInt("own_zzcape" + (i + 1), 0) == 1;
    }

    static boolean ownsCastle(int i) {
        return Castle.admin() || Prefs.getInt("own_zzcastle" + i, 0) == 1;
    }
}
