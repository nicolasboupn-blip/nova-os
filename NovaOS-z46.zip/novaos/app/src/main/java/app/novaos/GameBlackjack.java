package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Blackjack against the dealer with the slot coins. Dealer stands on all 17s. A win pays 1 to 1, a natural
 * blackjack pays 3 to 2, a tie gives your bet back. You can hit, stand or double down on your first two cards.
 * (No splitting or insurance.)
 */
final class GameBlackjack extends Game {
    private static final String[] RANK = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
    private static final String[] SUIT = {"♠", "♥", "♦", "♣"};
    private static final int[] CHIPS = {5, 10, 25, 50, 100, 1000, 10000};

    private static final int BETTING = 0;
    private static final int PLAYING = 1;
    private static final int DEALER = 2;

    private final List<Integer> deck = new ArrayList<>();
    private final List<Integer> player = new ArrayList<>();
    private final List<Integer> dealer = new ArrayList<>();
    private final LinearLayout dealerRow;
    private final LinearLayout playerRow;
    private final TextView dealerTotal;
    private final TextView playerTotal;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView message;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final LinearLayout actions;
    private final LinearLayout betRow;
    private final TextView doubleBtn;
    private int phase = BETTING;
    private int chip = 1;
    private int stake;
    private boolean holeHidden;
    private boolean dealing;

    GameBlackjack(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(60), dp(16), dp(20));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(host);
        coinsText = label("", 13f, Theme.TEXT);
        coinsText.setGravity(Gravity.START);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (phase == BETTING && coins() < CHIPS[0]) {
                Prefs.putInt("slot_coins", 100);
                refresh();
            }
        });
        betText = label("", 13f, Theme.ACCENT);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dealerTotal = label("DEALER", 12f, Theme.DIM);
        LinearLayout.LayoutParams dt = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dt.topMargin = dp(24);
        col.addView(dealerTotal, dt);
        dealerRow = new LinearLayout(host);
        dealerRow.setGravity(Gravity.CENTER);
        col.addView(dealerRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(96)));

        message = label("PLACE YOUR BET", 16f, Theme.DIM);
        message.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 0, 1f);
        col.addView(message, mp);

        playerRow = new LinearLayout(host);
        playerRow.setGravity(Gravity.CENTER);
        col.addView(playerRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(96)));
        playerTotal = label("YOU", 12f, Theme.DIM);
        col.addView(playerTotal, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        betRow = new LinearLayout(host);
        betRow.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(CHIPS[i] >= 1000 ? (CHIPS[i] / 1000) + "K" : String.valueOf(CHIPS[i]), CHIPS[i] >= 1000 ? 11f : 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (phase == BETTING) {
                    chip = idx;
                    styleChips();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(40), dp(40));
            cp.setMargins(dp(3), 0, dp(3), 0);
            betRow.addView(c, cp);
        }
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        brp.topMargin = dp(20);
        col.addView(betRow, brp);

        actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER);
        TextView hit = button("HIT", this::hit);
        TextView stand = button("STAND", this::stand);
        doubleBtn = button("DOUBLE", this::doubleDown);
        actions.addView(hit, weight());
        actions.addView(stand, weight());
        actions.addView(doubleBtn, weight());
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(14);
        col.addView(actions, ap);

        TextView deal = button("DEAL", this::deal);
        deal.setTextColor(Theme.BG);
        deal.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        deal.setTag("deal");
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dp.topMargin = dp(14);
        col.addView(deal, dp);
        dealBtn = deal;

        styleChips();
        refresh();
    }

    private TextView dealBtn;

    @Override
    String title() {
        return "BLACKJACK";
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    private void refresh() {
        coinsText.setText(phase == BETTING && coins() < CHIPS[0] ? "TAP: FREE COINS" : "COINS " + coins());
        betText.setText(phase == BETTING ? "BET " + CHIPS[chip] : "BET " + stake);
        betRow.setVisibility(phase == BETTING ? VISIBLE : GONE);
        dealBtn.setVisibility(phase == BETTING ? VISIBLE : GONE);
        actions.setVisibility(phase == PLAYING ? VISIBLE : GONE);
        doubleBtn.setAlpha(canDouble() ? 1f : 0.35f);
    }

    private boolean canDouble() {
        return phase == PLAYING && player.size() == 2 && coins() >= stake;
    }

    // ------------------------------------------------------------------ cards

    private int draw() {
        if (deck.size() < 15) {
            deck.clear();
            for (int i = 0; i < 52; i++) {
                deck.add(i);
            }
            Collections.shuffle(deck);
        }
        return deck.remove(deck.size() - 1);
    }

    private static int total(List<Integer> hand) {
        int sum = 0;
        int aces = 0;
        for (int c : hand) {
            int r = c % 13;
            if (r == 0) {
                aces++;
                sum += 11;
            } else {
                sum += Math.min(10, r + 1);
            }
        }
        while (sum > 21 && aces > 0) {
            sum -= 10;
            aces--;
        }
        return sum;
    }

    private static boolean soft(List<Integer> hand) {
        int sum = 0;
        int aces = 0;
        for (int c : hand) {
            int r = c % 13;
            if (r == 0) {
                aces++;
                sum += 11;
            } else {
                sum += Math.min(10, r + 1);
            }
        }
        while (sum > 21 && aces > 0) {
            sum -= 10;
            aces--;
        }
        return aces > 0;
    }

    private TextView cardView(int card, boolean faceDown) {
        TextView t = new TextView(host);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Theme.MONO);
        t.setTextSize(20f);
        if (faceDown) {
            t.setText("?");
            t.setTextColor(Theme.ACCENT);
            t.setBackground(Theme.rounded(0xFF2A2145, 10f, host));
        } else {
            int suit = card / 13;
            t.setText(RANK[card % 13] + "\n" + SUIT[suit]);
            t.setTextColor(suit == 1 || suit == 2 ? 0xFFD62F4A : 0xFF14101F);
            t.setBackground(Theme.rounded(0xFFF2EEFF, 10f, host));
        }
        return t;
    }

    private void addCard(LinearLayout row, int card, boolean faceDown) {
        TextView t = cardView(card, faceDown);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(82));
        lp.setMargins(row.getChildCount() == 0 ? 0 : -dp(14), 0, 0, 0);
        row.addView(t, lp);
        t.setAlpha(0f);
        t.setTranslationY(-dp(50));
        t.animate().alpha(1f).translationY(0f).setDuration(260).start();
    }

    private void showTotals() {
        int pt = total(player);
        playerTotal.setText("YOU  " + pt + (soft(player) && pt <= 21 && pt != 21 ? " (soft)" : ""));
        if (holeHidden) {
            int up = total(dealer.subList(0, 1));
            dealerTotal.setText("DEALER  " + up);
        } else {
            dealerTotal.setText("DEALER  " + total(dealer));
        }
    }

    // ------------------------------------------------------------------ the game

    private void deal() {
        if (phase != BETTING) {
            return;
        }
        stake = CHIPS[chip];
        if (coins() < stake) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake);
        phase = PLAYING;
        dealing = true;
        player.clear();
        dealer.clear();
        playerRow.removeAllViews();
        dealerRow.removeAllViews();
        message.setText("");
        holeHidden = true;
        int p1 = draw();
        int d1 = draw();
        int p2 = draw();
        int d2 = draw();
        player.add(p1);
        dealer.add(d1);
        player.add(p2);
        dealer.add(d2);
        addCard(playerRow, p1, false);
        h.postDelayed(() -> addCard(dealerRow, d1, false), 180);
        h.postDelayed(() -> addCard(playerRow, p2, false), 360);
        h.postDelayed(() -> addCard(dealerRow, d2, true), 540);
        showTotals();
        refresh();
        h.postDelayed(() -> {
            dealing = false;
            boolean pb = total(player) == 21;
            boolean db = total(dealer) == 21;
            if (pb || db) {
                reveal();
                if (pb && db) {
                    finish(1.0f, "BOTH BLACKJACK · PUSH");
                } else if (pb) {
                    Badges.unlock(host, "blackjack");
                    finish(2.5f, "BLACKJACK!");
                } else {
                    finish(0f, "DEALER HAS BLACKJACK");
                }
            }
        }, 900);
    }

    private void hit() {
        if (phase != PLAYING || dealing) {
            return;
        }
        int c = draw();
        player.add(c);
        addCard(playerRow, c, false);
        showTotals();
        refresh();
        int t = total(player);
        if (t > 21) {
            reveal();
            finish(0f, "BUST");
        } else if (t == 21) {
            stand();
        }
    }

    private void doubleDown() {
        if (!canDouble() || dealing) {
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake);
        stake *= 2;
        int c = draw();
        player.add(c);
        addCard(playerRow, c, false);
        showTotals();
        if (total(player) > 21) {
            reveal();
            finish(0f, "BUST");
        } else {
            stand();
        }
    }

    private void stand() {
        if (phase != PLAYING || dealing) {
            return;
        }
        phase = DEALER;
        refresh();
        reveal();
        h.postDelayed(this::dealerStep, 600);
    }

    private void reveal() {
        if (!holeHidden) {
            return;
        }
        holeHidden = false;
        if (dealerRow.getChildCount() >= 2) {
            dealerRow.removeViewAt(1);
            TextView t = cardView(dealer.get(1), false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(82));
            lp.setMargins(-dp(14), 0, 0, 0);
            dealerRow.addView(t, 1, lp);
            t.setRotationY(90f);
            t.animate().rotationY(0f).setDuration(250).start();
        }
        showTotals();
    }

    private void dealerStep() {
        if (total(dealer) < 17) {
            int c = draw();
            dealer.add(c);
            addCard(dealerRow, c, false);
            showTotals();
            h.postDelayed(this::dealerStep, 700);
            return;
        }
        int d = total(dealer);
        int p = total(player);
        if (d > 21) {
            finish(2f, "DEALER BUSTS");
        } else if (p > d) {
            finish(2f, "YOU WIN");
        } else if (p == d) {
            finish(1f, "PUSH");
        } else {
            finish(0f, "DEALER WINS");
        }
    }

    private void finish(float multiplier, String text) {
        int back = Math.round(stake * multiplier);
        Prefs.putInt("slot_coins", coins() + back);
        int net = back - stake;
        if (net > 0) {
            message.setText(text + "  +" + net);
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
        } else if (net == 0) {
            message.setText(text);
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText(text + "  -" + (-net));
            message.setTextColor(0xFFFF6B7F);
            host.buzz(25);
        }
        phase = BETTING;
        refresh();
    }
}
