package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** The coin shop: potions, re-rolls, shields, fireworks, dragon treats, titles, pet hats, colours and a bank. */
final class CoinShop extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout body;
    private String note = "";

    private CoinShop(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 18);
        body.setPadding(pad, Theme.dp(host, 40), pad, Theme.dp(host, 60));
        sv.addView(body);
        addView(sv, new LayoutParams(-1, -1));
        Shop.accrue();
        build();
    }

    static void open(NovaActivity host) {
        host.showOverlay(new CoinShop(host));
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    // ------------------------------------------------------------------ helpers

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private void head(String s) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, Theme.dp(host, 20), 0, Theme.dp(host, 6));
        body.addView(t);
    }

    private TextView chip(String s, boolean on, final Runnable r) {
        TextView t = text(s, 11f, on ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        t.setPadding(Theme.dp(host, 11), Theme.dp(host, 8), Theme.dp(host, 11), Theme.dp(host, 8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private final List<View> pending = new ArrayList<>();

    private void add(String s, boolean on, Runnable r) {
        pending.add(chip(s, on, r));
    }

    private void flush() {
        LinearLayout row = null;
        int used = 0;
        int max = host.getResources().getDisplayMetrics().widthPixels - Theme.dp(host, 36);
        for (View c : pending) {
            c.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int w = c.getMeasuredWidth() + Theme.dp(host, 8);
            if (row == null || used + w > max) {
                row = new LinearLayout(host);
                row.setPadding(0, 0, 0, Theme.dp(host, 6));
                body.addView(row);
                used = 0;
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Theme.dp(host, 6);
            row.addView(c, lp);
            used += w;
        }
        pending.clear();
    }

    private void line(String name, String what) {
        TextView n = text(name, 13f, Theme.TEXT);
        n.setPadding(0, Theme.dp(host, 6), 0, 0);
        body.addView(n);
        body.addView(text(what, 10f, Theme.DIM));
    }

    private void say(String s) {
        note = s;
        build();
    }

    private String price(int cost) {
        return Castle.admin() ? "FREE" : String.valueOf(cost);
    }

    // ------------------------------------------------------------------ the shop

    private void build() {
        body.removeAllViews();
        TextView title = text("COIN SHOP", 16f, Theme.TEXT);
        title.setLetterSpacing(0.2f);
        body.addView(title);
        TextView invest = chip("INVEST", false, () -> InvestScreen.open(host));
        body.addView(invest);
        String status = "Coins " + Coins.get() + "   Title: " + Shop.titleName();
        if (Shop.boostMinutes() > 0) {
            status += "   x2 coins: " + Shop.boostText() + " left";
        }
        if (Shop.shields() > 0) {
            status += "   Shields " + Shop.shields();
        }
        if (Upgrades.charm()) {
            status += "   Lucky " + Upgrades.charmMinutes() + " min";
        }
        body.addView(text(status, 11f, Theme.DIM));
        if (Castle.admin()) {
            body.addView(text("ADMIN: everything is free", 10f, Theme.ACCENT));
        }
        if (!note.isEmpty()) {
            TextView n = text(note, 12f, Theme.TEXT);
            n.setBackground(Theme.rounded(0x33FFFFFF, 12f, host));
            n.setPadding(Theme.dp(host, 12), Theme.dp(host, 10), Theme.dp(host, 12), Theme.dp(host, 10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = Theme.dp(host, 12);
            body.addView(n, lp);
        }

        add("MY CHARACTER", false, () -> AvatarEditor.open(host));
        flush();

        head("POTIONS & HELPERS");
        line("Double coins", "Quests, surprises, to-dos, focus, daily bonus and small games pay twice. Stacks, so you can buy more time on top.");
        add("1 HOUR " + price(Shop.BOOST_COST), false, () -> {
            if (Shop.pay(host, Shop.BOOST_COST)) {
                Shop.startBoost(60);
                say("Glug glug. Everything you earn pays double for an hour.");
            }
        });
        add("1 DAY " + price(Shop.BOOST_DAY_COST), false, () -> {
            if (Shop.pay(host, Shop.BOOST_DAY_COST)) {
                Shop.startBoost(1440);
                say("Double coins for a whole day. Time left: " + Shop.boostText());
            }
        });
        add("1 WEEK " + price(Shop.BOOST_WEEK_COST), false, () -> {
            if (Shop.pay(host, Shop.BOOST_WEEK_COST)) {
                Shop.startBoost(10080);
                say("Double coins for a whole week! Time left: " + Shop.boostText());
            }
        });
        flush();
        line("Quest re-roll", "Don't like today's three quests? Get new ones.");
        add("BUY " + price(Shop.REROLL_COST), false, () -> {
            if (Shop.pay(host, Shop.REROLL_COST)) {
                Prefs.putInt("q_salt", Prefs.getInt("q_salt", 0) + 1);
                Prefs.putInt("q_day", 0);
                say("New quests are waiting on the QUESTS page.");
            }
        });
        flush();
        line("Streak shield (" + Shop.shields() + "/3)", "Covers one missed day for your quest or login streak.");
        add("BUY " + price(Shop.SHIELD_COST), false, () -> {
            if (Shop.shields() >= 3) {
                host.toast("You already hold 3 shields");
            } else if (Shop.pay(host, Shop.SHIELD_COST)) {
                Shop.addShield();
                say("A shield for your streak!");
            }
        });
        add("3-PACK " + price(Shop.SHIELD_COST * 5 / 2), false, () -> {
            if (Shop.shields() > 0) {
                host.toast("Use up your shield first. The pack fills all 3 slots.");
            } else if (Shop.pay(host, Shop.SHIELD_COST * 5 / 2)) {
                Shop.addShield();
                Shop.addShield();
                Shop.addShield();
                say("Three shields, and you saved " + (Shop.SHIELD_COST * 3 - Shop.SHIELD_COST * 5 / 2) + " coins.");
            }
        });
        flush();
        line("Fireworks over the castle", "A show for the home screen. Pure fun.");
        add("BUY " + price(Shop.FIREWORKS_COST), false, () -> {
            if (Shop.pay(host, Shop.FIREWORKS_COST)) {
                host.hideOverlay();
                fireworks();
            }
        });
        flush();
        line("Dragon treat", Castle.stage() >= 5 ? "Ember loves it and puts on a show." : "Needs the dragon (castle stage 5).");
        add("BUY " + price(Shop.TREAT_COST), false, () -> {
            if (Castle.stage() < 5) {
                host.toast("No dragon yet. Castle stage 5 hatches him.");
            } else if (Shop.pay(host, Shop.TREAT_COST)) {
                host.hideOverlay();
                treat();
            }
        });
        flush();
        line("Mystery chest", "Coins, a potion, a hat, a robe, a shield, or sometimes just dust. Rare jackpot of 1000.");
        add("OPEN " + price(Shop.MYSTERY_COST), false, () -> {
            if (Shop.pay(host, Shop.MYSTERY_COST)) {
                Sfx.play(Sfx.WIN);
                say("The chest holds: " + Shop.mystery(host));
            }
        });
        flush();

        upgrades();

        head("ZIGZAG EDITIONS");
        body.addView(text("Seven editions, each with a shield, flapping wings, a cape and a castle skin. "
                + "The full set is 20% cheaper. Wear them in My Character and the Castle Workshop.", 10f, Theme.DIM));
        for (int i = 0; i < Zigzag.NAMES.length; i++) {
            final int ed = i;
            TextView n = text(Zigzag.NAMES[i], 13f, 0xFF000000 | Zigzag.ACC[i]);
            n.setPadding(0, Theme.dp(host, 10), 0, 0);
            body.addView(n);
            boolean s1 = Zigzag.ownsShield(i);
            boolean w1 = Zigzag.ownsWings(i);
            boolean p1 = Zigzag.ownsCape(i);
            boolean c1 = Zigzag.ownsCastle(i);
            add(s1 ? "SHIELD OK" : "SHIELD " + price(Zigzag.SHIELD_COST[i]), s1, () -> buyZigzag(ed, true, false, false, false));
            add(w1 ? "WINGS OK" : "WINGS " + price(Zigzag.WINGS_COST[i]), w1, () -> buyZigzag(ed, false, true, false, false));
            add(p1 ? "CAPE OK" : "CAPE " + price(Zigzag.CAPE_COST[i]), p1, () -> buyZigzag(ed, false, false, true, false));
            add(c1 ? "CASTLE OK" : "CASTLE " + price(Zigzag.CASTLE_COST[i]), c1, () -> buyZigzag(ed, false, false, false, true));
            if (!(s1 && w1 && p1 && c1)) {
                add("FULL SET " + price(Zigzag.setCost(i)), false, () -> buyZigzag(ed, true, true, true, true));
            }
            flush();
        }

        head("TITLES");
        body.addView(text("Shown next to the wizard's name. Buy once, switch any time.", 10f, Theme.DIM));
        for (int i = 0; i < Shop.TITLES.length; i++) {
            final int idx = i;
            boolean owned = i == 0 || Castle.owns("title", i) || Castle.admin();
            add(Shop.TITLES[i] + (owned ? "" : " " + Shop.TITLE_COST[i]), Shop.title() == i, () -> {
                if (!(idx == 0 || Castle.owns("title", idx) || Castle.admin())) {
                    if (!Shop.pay(host, Shop.TITLE_COST[idx])) {
                        return;
                    }
                    Prefs.putInt("own_title" + idx, 1);
                }
                Prefs.putInt("wz_title", idx);
                build();
            });
        }
        flush();

        for (int slot = 0; slot < 2; slot++) {
            if (!Pets.hasBody(slot) || Pets.kind(slot) == Pets.PARROT || (slot == 1 && !Castle.has(7))) {
                continue;
            }
            final int sl = slot;
            final String key = slot == 0 ? "pet_hat" : "pet2_hat";
            head(slot == 0 ? "PET STYLE" : "SECOND PET STYLE");
            for (int i = 0; i < Shop.HATS.length; i++) {
                final int idx = i;
                boolean owned = i == 0 || Castle.owns("hat", i) || Castle.admin();
                add(Shop.HATS[i] + (owned ? "" : " " + Shop.HAT_COST[i]), Prefs.getInt(key, 0) == i, () -> {
                    if (!(idx == 0 || Castle.owns("hat", idx) || Castle.admin())) {
                        if (!Shop.pay(host, Shop.HAT_COST[idx])) {
                            return;
                        }
                        Prefs.putInt("own_hat" + idx, 1);
                    }
                    Prefs.putInt(key, idx);
                    build();
                });
            }
            flush();
        }

        head("PREMIUM COLOUR THEMES");
        body.addView(text(Shop.ACCENT_COST + " coins each. They change the whole phone's look.", 10f, Theme.DIM));
        for (int i = Shop.FIRST_PREMIUM; i < Theme.PRESET_NAMES.length; i++) {
            final int idx = i;
            boolean owned = Castle.owns("accent", i) || Castle.admin();
            add(Theme.PRESET_NAMES[i] + (owned ? "" : " " + Shop.ACCENT_COST), Prefs.accent() == i, () -> {
                if (!(Castle.owns("accent", idx) || Castle.admin())) {
                    if (!Shop.pay(host, Shop.ACCENT_COST)) {
                        return;
                    }
                    Prefs.putInt("own_accent" + idx, 1);
                }
                Prefs.putInt(Prefs.K_ACCENT, idx);
                host.refreshTheme();
                CoinShop.open(host);
            });
        }
        flush();

        head("THE BANK");
        body.addView(text("Saved: " + Shop.bank() + " / " + Upgrades.bankCap() + "   pays " + Upgrades.interest() + "% every day", 12f, Theme.TEXT));
        body.addView(text("Coins in the bank cannot be gambled away. Interest is added for each full day.", 10f, Theme.DIM));
        add("DEPOSIT 100", false, () -> bank(true, 100));
        add("DEPOSIT 1000", false, () -> bank(true, 1000));
        add("DEPOSIT ALL", false, () -> bank(true, Integer.MAX_VALUE));
        flush();
        add("TAKE 100", false, () -> bank(false, 100));
        add("TAKE 1000", false, () -> bank(false, 1000));
        add("TAKE ALL", false, () -> bank(false, Integer.MAX_VALUE));
        flush();
        body.addView(text("\nTip: coins also buy castle upgrades in the Castle Workshop.", 10f, Theme.DIM));
    }

    // ------------------------------------------------------------------ upgrades

    /** A one-time upgrade. Shows OWNED once you have it. */
    private void once(String id, String name, String what, int cost, final Runnable onBuy) {
        line(name, what);
        if (Upgrades.has(id)) {
            add("OWNED", true, () -> host.toast("You own this one"));
        } else {
            final int c = cost;
            final String uid = id;
            final String uname = name;
            add("BUY " + price(cost), false, () -> {
                if (Shop.pay(host, c)) {
                    Upgrades.set(uid, 1);
                    if (onBuy != null) {
                        onBuy.run();
                    }
                    Sfx.play(Sfx.WIN);
                    say(uname + " is yours!");
                }
            });
        }
        flush();
    }

    private void upgrades() {
        head("UPGRADES");
        body.addView(text("Permanent. Buy once, enjoy forever.", 10f, Theme.DIM));

        once("quest4", "Fourth daily quest", "One more quest every day, so one more reward. Added to today's list right away.",
                Upgrades.QUEST_SLOT_COST, null);

        line("Spin ticket (" + Upgrades.tickets() + ")", "One more spin of the daily wheel on the Shop page. They stack.");
        add("BUY " + price(Upgrades.TICKET_COST), false, () -> {
            if (Shop.pay(host, Upgrades.TICKET_COST)) {
                Prefs.putInt("spin_extra", Upgrades.tickets() + 1);
                say("A spin ticket! Use it on the Shop page.");
            }
        });
        flush();

        String luck = Upgrades.charm() ? " (" + Upgrades.charmMinutes() + " min left)" : "";
        line("Lucky charm" + luck, "One hour of better slot odds: more 777s and more pairs. Stacks.");
        add("1 HOUR " + price(Upgrades.CHARM_COST), false, () -> {
            if (Shop.pay(host, Upgrades.CHARM_COST)) {
                Upgrades.startCharm(60);
                say("The charm glows. Better luck at the slots for an hour.");
            }
        });
        flush();

        once("roller", "High roller bets", "Adds bets of 100 and 250 to the slot machine.", Upgrades.HIGH_ROLLER_COST, null);
        once("autospin", "Auto-spin x10", "Hold the slot lever to spin up to 10 times by itself. It stops on a big win.",
                Upgrades.AUTOSPIN_COST, null);
        once("magnet", "Golden magnet", "Surprises, golden coins and roast pigs stay 70% longer, so you can catch more.",
                Upgrades.MAGNET_COST, null);

        int mine = Upgrades.mine();
        String mineWhat = "Digs coins while you are away (up to " + Upgrades.MINE_CAP_HOURS + " hours) and pays when you open the home screen. "
                + (mine == 0 ? "Level 1 digs " + Upgrades.MINE_RATE[1] + " per hour."
                : "Now level " + mine + ": " + Upgrades.MINE_RATE[mine] + " per hour, " + Upgrades.mineReady() + " ready.");
        line("Castle gold mine", mineWhat);
        if (mine >= 3) {
            add("MAX LEVEL", true, () -> host.toast("Fully upgraded"));
        } else {
            final int next = mine + 1;
            add((mine == 0 ? "BUILD " : "UPGRADE ") + price(Upgrades.MINE_COST[next]), false, () -> {
                if (Shop.pay(host, Upgrades.MINE_COST[next])) {
                    if (Upgrades.mine() > 0) {
                        Upgrades.collectMine(host);
                    }
                    Upgrades.set("mine", next);
                    Upgrades.startMine();
                    Sfx.play(Sfx.WIN);
                    say("Gold mine level " + next + ": " + Upgrades.MINE_RATE[next] + " coins per hour.");
                }
            });
        }
        flush();

        int cap = Math.min(2, Upgrades.level("bankcap"));
        line("Bigger vault", "The bank holds " + Upgrades.bankCap() + " coins now.");
        if (cap >= 2) {
            add("MAX LEVEL", true, () -> host.toast("Fully upgraded"));
        } else {
            final int nc = cap + 1;
            add("HOLD " + Upgrades.CAP[nc] + "  " + price(Upgrades.CAP_COST[nc]), false, () -> {
                if (Shop.pay(host, Upgrades.CAP_COST[nc])) {
                    Upgrades.set("bankcap", nc);
                    say("The vault holds " + Upgrades.CAP[nc] + " coins now.");
                }
            });
        }
        flush();
        once("bankint", "Better interest", "The bank pays 3% a day instead of 2%.", Upgrades.INTEREST_COST, null);

        head("PHONE UPGRADES");
        once("grid5", "5 icons per row", "A tighter home screen and app list. Switch it on or off in Settings.",
                Upgrades.GRID5_COST, null);
        once("dock5", "Fifth dock button", "Adds a NET button to the dock for quick NOVA Net chats.", Upgrades.DOCK5_COST, null);
        once("shapes", "Icon shapes", "Round, squircle or square icons. Pick in Settings > App icons.", Upgrades.PACK_COST,
                () -> Prefs.putInt("s_icon_shape", 1));
        once("walls", "Wallpaper pack", "Three new animated wallpapers: Nebula, Ocean and Petals. Pick in Settings.",
                Upgrades.PACK_COST, null);
        once("sounds", "Sound packs", "Retro, Bell and Wood sounds for the whole phone. Pick in Settings.", Upgrades.PACK_COST,
                () -> {
                    Prefs.putInt("s_sound_pack", 2);
                    Sfx.reset();
                });
        once("dancerpack", "Dancer pack", "Three new things your character does on the home screen: DJ set, skateboarding and fishing.",
                Upgrades.DANCER_COST, null);
        once("chatstyle", "NOVA Net style", "Coloured chat bubbles and a frame around your picture on the ranklist. Pick in NOVA Net > ME.",
                Upgrades.CHATSTYLE_COST, null);
        once("stickers", "Sticker pack", "A sticker button in NOVA Net chats: table flip, shrug, bear, crown and more.",
                Upgrades.STICKER_COST, null);
        once("decor", "Castle decorations", "Fireflies, lanterns or a fountain for your castle. Pick in the Castle Workshop.",
                Upgrades.DECOR_COST, () -> Prefs.putInt("cs_decor", 1));
        once("daynight", "Auto night colours", "From 21:00 to 06:00 the phone switches to a calm moonlight palette.",
                Upgrades.NIGHT_COST, null);
    }

    /** Buys parts of an edition. A full set costs the discounted price and equips everything. */
    private void buyZigzag(int ed, boolean shield, boolean wings, boolean cape, boolean castle) {
        boolean full = shield && wings && cape && castle;
        int cost;
        if (full) {
            cost = Zigzag.setCost(ed);
        } else {
            cost = (shield && !Zigzag.ownsShield(ed) ? Zigzag.SHIELD_COST[ed] : 0)
                    + (wings && !Zigzag.ownsWings(ed) ? Zigzag.WINGS_COST[ed] : 0)
                    + (cape && !Zigzag.ownsCape(ed) ? Zigzag.CAPE_COST[ed] : 0)
                    + (castle && !Zigzag.ownsCastle(ed) ? Zigzag.CASTLE_COST[ed] : 0);
            if (cost == 0) {
                host.toast("You already own that. Wear it in My Character.");
                return;
            }
        }
        if (!Shop.pay(host, cost)) {
            return;
        }
        if (shield) {
            Prefs.putInt("own_zzshield" + (ed + 1), 1);
            Prefs.putInt("av_shield", ed + 1);
        }
        if (wings) {
            Prefs.putInt("own_zzwings" + (ed + 1), 1);
            Prefs.putInt("av_wings", ed + 1);
        }
        if (cape) {
            Prefs.putInt("own_zzcape" + (ed + 1), 1);
            Prefs.putInt("av_cape", ed + 1);
        }
        if (castle) {
            Prefs.putInt("own_zzcastle" + ed, 1);
            Prefs.putInt("cs_style", Zigzag.FIRST_STYLE + ed);
            Castle.changed();
        }
        Sfx.play(Sfx.WIN);
        say(Zigzag.NAMES[ed] + (full ? " full set" : "") + " is yours and equipped!");
    }

    private void bank(boolean in, int n) {
        boolean ok = in ? Shop.deposit(n) : Shop.withdraw(n);
        if (ok) {
            Sfx.play(Sfx.COIN);
        } else {
            host.toast(in ? "Nothing to deposit (or the bank is full)" : "Nothing in the bank");
        }
        build();
    }

    // ------------------------------------------------------------------ the fun things

    private void fireworks() {
        final int w = host.root.getWidth();
        final int h = host.root.getHeight();
        java.util.Random r = new java.util.Random();
        for (int i = 0; i < 9; i++) {
            final float x = w * (0.12f + 0.76f * r.nextFloat());
            final float y = h * (0.12f + 0.4f * r.nextFloat());
            host.root.postDelayed(() -> {
                host.confetti(x, y);
                Sfx.play(Sfx.WIN);
                host.buzz(15);
            }, 400L + i * 450L);
        }
        host.wizardSay("Ooooh! Fireworks!");
        Quests.event(host, "castle");
    }

    private void treat() {
        Pets.bumpJoy(20);
        if (host.castle != null) {
            if (Castle.stage() >= 9) {
                host.castle.dragonDo("fly");
            } else {
                host.castle.dragonDo("wake");
                host.castle.dragonDo("fire");
            }
        }
        Sfx.play(Sfx.WIN);
        host.wizardSay("Ember loves the treat! Look at him go!");
        Quests.event(host, "dragon");
    }
}
