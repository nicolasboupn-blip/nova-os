package app.novaos;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;

/** Your name on the home screen: elegant serif, graffiti tag or neon sign. */
final class NameTag extends View {
    static final String K_STYLE = "s_tag_style";
    static final String K_TEXT = "s_tag_text";
    static final String[] STYLES = {"Elegant", "Graffiti", "Neon", "Off"};

    private final int style;
    private final String text;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    static int style() {
        return Prefs.getInt(K_STYLE, 0);
    }

    static String text() {
        String t = Prefs.getString(K_TEXT, "").trim();
        if (t.isEmpty()) {
            t = Prefs.userName();
        }
        return t.isEmpty() ? "Nicolas" : t;
    }

    static boolean on() {
        return style() != 3;
    }

    NameTag(Context c) {
        super(c);
        style = style();
        text = text();
        d = c.getResources().getDisplayMetrics().density;
        if (style == 2) {
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }

    private float size() {
        return style == 1 ? sp(40) : style == 2 ? sp(30) : sp(32);
    }

    @Override
    protected void onMeasure(int w, int h) {
        int hh = Math.round(style == 1 ? size() * 1.9f : size() * 1.7f);
        setMeasuredDimension(MeasureSpec.getSize(w), hh);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        float sz = size();
        p.setTextSize(sz);
        p.setStyle(Paint.Style.FILL);
        float base = sz * 1.15f;
        switch (style) {
            case 0:
                elegant(c, w, sz, base);
                break;
            case 1:
                graffiti(c, sz, base);
                break;
            default:
                neon(c, sz, base);
                break;
        }
    }

    private void elegant(Canvas c, int w, float sz, float base) {
        p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        p.setLetterSpacing(0.14f);
        p.setColor(Theme.TEXT);
        p.setShadowLayer(8 * d, 0, 0, (Theme.ACCENT & 0x00FFFFFF) | 0x66000000);
        float tw = p.measureText(text);
        float x = 2 * d;
        c.drawText(text, x, base, p);
        p.clearShadowLayer();
        // a thin line that fades out, with a small diamond at its start
        float y = base + sz * 0.32f;
        float len = Math.max(tw, w * 0.5f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, d));
        p.setShader(new LinearGradient(x, 0, x + len, 0, Theme.ACCENT, Theme.ACCENT & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawLine(x + 10 * d, y, x + len, y, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.ACCENT);
        Path dia = new Path();
        dia.moveTo(x + 4 * d, y - 4 * d);
        dia.lineTo(x + 8 * d, y);
        dia.lineTo(x + 4 * d, y + 4 * d);
        dia.lineTo(x, y);
        dia.close();
        c.drawPath(dia, p);
    }

    private void graffiti(Canvas c, float sz, float base) {
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
        p.setLetterSpacing(0.04f);
        float x = 8 * d;
        c.save();
        c.rotate(-4f, x, base);
        // hard shadow
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        c.drawText(text, x + 4 * d, base + 4 * d, p);
        // thick dark outline, then the colour on top
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(7 * d);
        p.setColor(0xFF0A0A0F);
        c.drawText(text, x, base, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.ACCENT);
        c.drawText(text, x, base, p);
        // a glossy highlight on the upper half
        c.save();
        c.clipRect(0, base - sz, getWidth(), base - sz * 0.45f);
        p.setColor(0x55FFFFFF);
        c.drawText(text, x, base - 2 * d, p);
        c.restore();
        // paint drips under some of the letters
        p.setColor(Theme.ACCENT);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(3 * d);
        for (int i = 0; i < text.length(); i++) {
            if ((i * 7 + text.length()) % 3 != 0) {
                continue;
            }
            float cx = x + p.measureText(text, 0, i) + p.measureText(text, i, i + 1) * 0.5f;
            float len = (6 + ((i * 13) % 11)) * d;
            c.drawLine(cx, base + 2 * d, cx, base + 2 * d + len, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx, base + 2 * d + len + d, 2.4f * d, p);
            p.setStyle(Paint.Style.STROKE);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
        c.restore();
    }

    private void neon(Canvas c, float sz, float base) {
        p.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        p.setLetterSpacing(0.18f);
        float x = 4 * d;
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 3; i++) {
            p.setMaskFilter(new BlurMaskFilter((14 - i * 4) * d, BlurMaskFilter.Blur.NORMAL));
            p.setColor(Theme.ACCENT);
            c.drawText(text, x, base, p);
        }
        p.setMaskFilter(null);
        p.setColor(0xFFFFFFFF);
        c.drawText(text, x, base, p);
    }
}
