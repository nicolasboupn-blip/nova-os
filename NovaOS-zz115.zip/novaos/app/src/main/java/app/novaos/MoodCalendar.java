package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * MOOD CALENDAR: tap a smiley whenever your mood changes. Each day of the month gets a colour and a smiley worked out
 * by how long you spent in each mood (see MoodLog). Tap a day to see how it was made up.
 */
final class MoodCalendar extends NovaWidget {
    private final Calendar month = Calendar.getInstance();
    private final TextView title;
    private final TextView info;
    private final Grid grid;
    private final List<TextView> faces = new ArrayList<>();
    private String chosen = MoodLog.today();

    MoodCalendar(NovaActivity host) {
        super(host);
        setOrientation(VERTICAL);
        month.set(Calendar.DAY_OF_MONTH, 1);

        LinearLayout rate = row();
        rate.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 5; i++) {
            final int f = i;
            TextView c = chip(MoodLog.FACES[i], () -> {
                MoodLog.log(f);
                host.buzz(12);
                chosen = MoodLog.today();
                Calendar now = Calendar.getInstance();
                month.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 1);
                refresh();
            });
            c.setTextSize(20f);
            c.setPadding(0, dp(6), 0, dp(6));
            c.setGravity(Gravity.CENTER);
            faces.add(c);
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), 0, dp(2), 0);
            rate.addView(c, p);
        }
        addView(rate, wide());

        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, dp(8), 0, dp(4));
        TextView prev = text("‹", 20f, Theme.ACCENT);
        prev.setPadding(dp(10), 0, dp(10), 0);
        prev.setOnClickListener(v -> {
            month.add(Calendar.MONTH, -1);
            refresh();
        });
        head.addView(prev);
        title = text("", 12f, Theme.TEXT);
        title.setLetterSpacing(0.12f);
        title.setGravity(Gravity.CENTER);
        head.addView(title, weight(1f));
        TextView next = text("›", 20f, Theme.ACCENT);
        next.setPadding(dp(10), 0, dp(10), 0);
        next.setOnClickListener(v -> {
            month.add(Calendar.MONTH, 1);
            refresh();
        });
        head.addView(next);
        addView(head, wide());

        grid = new Grid(host);
        addView(grid, wide());
        info = text("", 10.5f, Theme.DIM);
        info.setGravity(Gravity.START);
        info.setPadding(dp(4), dp(6), dp(4), dp(2));
        addView(info, wide());
    }

    @Override
    long tickMs() {
        return 60000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        title.setText(new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(month.getTime())
                .toUpperCase(Locale.getDefault()));
        int cur = MoodLog.current();
        for (int i = 0; i < faces.size(); i++) {
            pick(faces.get(i), i == cur);
        }
        grid.invalidate();
        showInfo();
    }

    private void showInfo() {
        long[] m = MoodLog.minutes(chosen);
        long total = 0;
        for (long x : m) {
            total += x;
        }
        String day;
        try {
            java.util.Date d = new SimpleDateFormat("yyyyMMdd", Locale.ROOT).parse(chosen);
            day = new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(d);
        } catch (java.text.ParseException e) {
            day = chosen;
        }
        if (total == 0) {
            info.setText(day + ": no smileys yet. "
                    + (chosen.equals(MoodLog.today()) ? "Tap one above when your mood changes." : ""));
            return;
        }
        StringBuilder b = new StringBuilder(day).append(":  ");
        for (int i = 0; i < 5; i++) {
            if (m[i] > 0) {
                b.append(MoodLog.FACES[i]).append(' ').append(Math.round(m[i] * 100f / total)).append("%  ");
            }
        }
        float s = MoodLog.score(chosen);
        b.append("\n→ ").append(MoodLog.FACES[MoodLog.faceOf(s)]).append("  ")
                .append(MoodLog.NAMES[MoodLog.faceOf(s)]).append(" day (").append(Math.round(s * 100)).append("/100)");
        info.setText(b.toString());
    }

    /** The month: a coloured circle with the day's smiley for every rated day. */
    final class Grid extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        Grid(android.content.Context c) {
            super(c);
            d = getResources().getDisplayMetrics().density;
            p.setTypeface(Theme.MONO);
        }

        private int firstCol() {
            // weeks start on Monday
            return (month.get(Calendar.DAY_OF_WEEK) + 5) % 7;
        }

        private int rows() {
            int days = month.getActualMaximum(Calendar.DAY_OF_MONTH);
            return (firstCol() + days + 6) / 7;
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int w = MeasureSpec.getSize(ws);
            float cell = w / 7f;
            setMeasuredDimension(w, Math.round(16 * d + rows() * Math.min(cell, 38 * d)));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                return true;
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float cw = getWidth() / 7f;
                float ch = Math.min(cw, 38 * d);
                int col = (int) (e.getX() / cw);
                int row = (int) ((e.getY() - 16 * d) / ch);
                int day = row * 7 + col - firstCol() + 1;
                if (e.getY() > 16 * d && day >= 1 && day <= month.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                    Calendar c = (Calendar) month.clone();
                    c.set(Calendar.DAY_OF_MONTH, day);
                    chosen = MoodLog.stamp(c);
                    invalidate();
                    showInfo();
                }
                return true;
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            float cw = getWidth() / 7f;
            float ch = Math.min(cw, 38 * d);
            String[] wd = {"M", "T", "W", "T", "F", "S", "S"};
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(9 * d);
            p.setColor(Theme.DIM);
            for (int i = 0; i < 7; i++) {
                c.drawText(wd[i], cw * (i + 0.5f), 11 * d, p);
            }
            int days = month.getActualMaximum(Calendar.DAY_OF_MONTH);
            int fc = firstCol();
            String today = MoodLog.today();
            Calendar k = (Calendar) month.clone();
            for (int day = 1; day <= days; day++) {
                int pos = fc + day - 1;
                float cx = cw * (pos % 7 + 0.5f);
                float cy = 16 * d + ch * (pos / 7 + 0.5f);
                float r = Math.min(cw, ch) * 0.42f;
                k.set(Calendar.DAY_OF_MONTH, day);
                String st = MoodLog.stamp(k);
                float s = MoodLog.score(st);
                p.setStyle(Paint.Style.FILL);
                if (s >= 0) {
                    p.setColor(MoodLog.colorOf(s));
                    c.drawCircle(cx, cy, r, p);
                    p.setTextSize(r * 1.15f);
                    p.setColor(0xFF000000);
                    c.drawText(MoodLog.FACES[MoodLog.faceOf(s)], cx, cy + r * 0.4f, p);
                } else {
                    p.setColor(Theme.PANEL);
                    c.drawCircle(cx, cy, r, p);
                    p.setTextSize(10 * d);
                    p.setColor(Theme.DIM);
                    c.drawText(String.valueOf(day), cx, cy + 3.5f * d, p);
                }
                if (st.equals(today) || st.equals(chosen)) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth((st.equals(chosen) ? 2.5f : 1.5f) * d);
                    p.setColor(st.equals(chosen) ? Theme.TEXT : Theme.ACCENT);
                    c.drawCircle(cx, cy, r + 2.5f * d, p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
        }
    }
}
