package app.novaos;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;

/**
 * Ten "normal" phone home screens, the kind you know from real phones: GLANCE (date at the top, grid and dock at the
 * bottom), SPRING (square widgets, rounded icons, pages and a glass dock), ONE HAND (a big header, everything in thumb
 * reach), WAVE (a short list of favourites and an A to Z rail), FOLDERS (apps sorted into folders by themselves),
 * PAGES (swipe through pages of icons, all-apps button in the dock), SMART (apps suggested for this time of day),
 * GLASS (see-through cards over your wallpaper), CLEAN (only the time and four apps) and BOARD (widgets first).
 */
final class HomesD {
    private HomesD() {
    }

    // ------------------------------------------------------------------ shared pieces

    /** Swipe sideways between full-width pages; it always stops on a whole page. */
    static final class Pager extends HorizontalScrollView {
        final LinearLayout strip;
        private int page;
        private boolean flung;
        java.util.function.IntConsumer onPage;

        Pager(Context c) {
            super(c);
            setHorizontalScrollBarEnabled(false);
            setOverScrollMode(OVER_SCROLL_NEVER);
            strip = new LinearLayout(c);
            addView(strip, new FrameLayout.LayoutParams(-2, -1));
        }

        void addPage(View v) {
            strip.addView(v, new LinearLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels, -1));
        }

        int count() {
            return strip.getChildCount();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            if (w > 0 && w != ow) {
                for (int i = 0; i < strip.getChildCount(); i++) {
                    strip.getChildAt(i).getLayoutParams().width = w;
                }
                strip.requestLayout();
                post(() -> scrollTo(page * w, 0));
            }
        }

        void go(int p) {
            page = Math.max(0, Math.min(count() - 1, p));
            smoothScrollTo(page * Math.max(1, getWidth()), 0);
            if (onPage != null) {
                onPage.accept(page);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                flung = false;
            }
            boolean r = super.onTouchEvent(e);
            int a = e.getActionMasked();
            if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && !flung) {
                post(() -> go(Math.round(getScrollX() / (float) Math.max(1, getWidth()))));
            }
            return r;
        }

        @Override
        public void fling(int vx) {
            flung = true;
            float pos = getScrollX() / (float) Math.max(1, getWidth());
            go(vx > 0 ? (int) Math.ceil(pos) : (int) Math.floor(pos));
        }
    }

    /** Small page dots. */
    static final class Dots extends View {
        private int n;
        private int on;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Dots(Context c) {
            super(c);
        }

        void set(int n, int on) {
            this.n = n;
            this.on = on;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            if (n < 2) {
                return;
            }
            float d = getResources().getDisplayMetrics().density;
            float gap = 12 * d;
            float x0 = getWidth() / 2f - (n - 1) * gap / 2f;
            for (int i = 0; i < n; i++) {
                p.setColor(i == on ? Theme.TEXT : (Theme.TEXT & 0xFFFFFF) | 0x55000000);
                c.drawCircle(x0 + i * gap, getHeight() / 2f, 3.2f * d, p);
            }
        }
    }

    /** A grid of app icons with labels, cols wide. */
    static View grid(AltHome h, List<AppEntry> apps, int cols, int iconDp, boolean labels) {
        LinearLayout g = new LinearLayout(h.host);
        g.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < apps.size(); i++) {
            if (i % cols == 0) {
                row = new LinearLayout(h.host);
                g.addView(row, lp(-1, -2));
            }
            row.addView(h.appTile(apps.get(i), iconDp, labels), lp(0, -2, 1f));
        }
        if (row != null) {
            for (int k = apps.size() % cols; k != 0 && k < cols; k++) {
                row.addView(new View(h.host), lp(0, 1, 1f));
            }
        }
        return g;
    }

    static List<AppEntry> slice(List<AppEntry> l, int from, int to) {
        from = Math.max(0, Math.min(from, l.size()));
        to = Math.max(from, Math.min(to, l.size()));
        return new ArrayList<>(l.subList(from, to));
    }

    /** Pinned apps first, then every other app. */
    static List<AppEntry> everything(AltHome h) {
        List<AppEntry> out = h.pinned();
        for (AppEntry e : h.host.repo.all) {
            if (!out.contains(e)) {
                out.add(e);
            }
        }
        return out;
    }

    static TextView pill(AltHome h, String s, Runnable r) {
        TextView t = h.text(s, 13f, Theme.DIM);
        t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        t.setBackground(Theme.rounded(Theme.PANEL, 26f, h.host));
        t.setPadding(h.dp(20), h.dp(13), h.dp(20), h.dp(13));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    static Typeface sans(boolean light) {
        return light ? Theme.LIGHT : Typeface.create("sans-serif", Typeface.NORMAL);
    }

    // ================================================================== GLANCE

    /** The date and a line of info at the top left, then a grid of apps, a dock and a search bar at the bottom. */
    static final class Glance extends AltHome {
        private final TextView day;
        private final TextView line;

        Glance(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(18), dp(58), dp(18), dp(14));
            day = text("", 24f, Theme.TEXT);
            day.setTypeface(sans(false));
            day.setGravity(Gravity.START);
            col.addView(day);
            line = text("", 13f, Theme.DIM);
            line.setTypeface(sans(false));
            line.setGravity(Gravity.START);
            line.setPadding(0, dp(4), 0, 0);
            col.addView(line);
            day.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            line.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            col.addView(new View(host), lp(-1, 0, 1f));
            List<AppEntry> apps = appsFor(25);
            col.addView(grid(this, slice(apps, 5, 25), 5, 46, true), lp(-1, -2));
            LinearLayout dock = new LinearLayout(host);
            dock.setPadding(0, dp(12), 0, dp(10));
            for (AppEntry e : slice(apps, 0, 5)) {
                dock.addView(appTile(e, 50, false), lp(0, -2, 1f));
            }
            col.addView(dock, lp(-1, -2));
            col.addView(pill(this, "⌕   Search", () -> host.showDrawer()), lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        @Override
        void tick() {
            day.setText(new SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(new Date()));
            line.setText(clock() + "   ·   " + battery() + "% battery   ·   " + Profile.name());
        }
    }

    // ================================================================== SPRING

    /** Square widgets, rounded icons in rows of four, more pages to the right, and a see-through dock. */
    static final class Spring extends AltHome {
        private final TextView wTime;
        private final TextView wDay;
        private final TextView wBatt;
        private final View ring;

        Spring(NovaActivity host) {
            super(host);
            List<AppEntry> all = everything(this);
            List<AppEntry> dockApps = slice(all, 0, 4);
            List<AppEntry> rest = slice(all, 4, all.size());
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(0, dp(48), 0, dp(12));
            final Pager pager = new Pager(host);
            final Dots dots = new Dots(host);

            // page one: two square widgets and the first apps
            LinearLayout p1 = new LinearLayout(host);
            p1.setOrientation(LinearLayout.VERTICAL);
            p1.setPadding(dp(16), 0, dp(16), 0);
            LinearLayout widgets = new LinearLayout(host);
            int side = (getResources().getDisplayMetrics().widthPixels - dp(32) - dp(14)) / 2;
            LinearLayout clockW = new LinearLayout(host);
            clockW.setOrientation(LinearLayout.VERTICAL);
            clockW.setPadding(dp(16), dp(14), dp(16), dp(14));
            GradientDrawable cg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[] {Theme.ACCENT, HomeKit.darker(Theme.ACCENT, 0.5f)});
            cg.setCornerRadius(dp(24));
            clockW.setBackground(cg);
            int on = HomeKit.onColor(Theme.ACCENT);
            wDay = text("", 12f, on);
            wDay.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            wDay.setGravity(Gravity.START);
            clockW.addView(wDay);
            clockW.addView(new View(host), lp(-1, 0, 1f));
            wTime = text("", 40f, on);
            wTime.setTypeface(sans(true));
            wTime.setGravity(Gravity.START);
            clockW.addView(wTime);
            clockW.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            press(clockW);
            widgets.addView(clockW, lp(side, side));
            FrameLayout battW = new FrameLayout(host);
            battW.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
            ring = new View(host) {
                private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

                @Override
                protected void onDraw(Canvas c) {
                    float d = getResources().getDisplayMetrics().density;
                    float r = Math.min(getWidth(), getHeight()) / 2f - 8 * d;
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(9 * d);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setColor((Theme.TEXT & 0xFFFFFF) | 0x22000000);
                    c.drawCircle(getWidth() / 2f, getHeight() / 2f, r, p);
                    int b = battery();
                    p.setColor(b < 20 ? 0xFFFF5A4E : 0xFF4CD964);
                    c.drawArc(getWidth() / 2f - r, getHeight() / 2f - r, getWidth() / 2f + r, getHeight() / 2f + r,
                            -90, 360f * b / 100f, false, p);
                }
            };
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(Math.round(side * 0.62f), Math.round(side * 0.62f),
                    Gravity.CENTER);
            rp.bottomMargin = dp(14);
            battW.addView(ring, rp);
            wBatt = text("", 18f, Theme.TEXT);
            wBatt.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
            bp.bottomMargin = dp(14);
            battW.addView(wBatt, bp);
            TextView bl = text("Battery", 11f, Theme.DIM);
            bl.setTypeface(sans(false));
            battW.addView(bl, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));
            ((FrameLayout.LayoutParams) bl.getLayoutParams()).bottomMargin = dp(12);
            battW.setOnClickListener(v -> host.showShade());
            LinearLayout.LayoutParams bwp = lp(side, side);
            bwp.leftMargin = dp(14);
            widgets.addView(battW, bwp);
            p1.addView(widgets, lp(-1, -2));
            LinearLayout.LayoutParams gp = lp(-1, -2);
            gp.topMargin = dp(14);
            p1.addView(grid(this, slice(rest, 0, 12), 4, 56, true), gp);
            pager.addPage(p1);
            // the other pages: the rest of the apps, 24 per page
            for (int i = 12; i < rest.size() && pager.count() < 8; i += 24) {
                LinearLayout pg = new LinearLayout(host);
                pg.setOrientation(LinearLayout.VERTICAL);
                pg.setPadding(dp(16), 0, dp(16), 0);
                pg.addView(grid(this, slice(rest, i, i + 24), 4, 56, true), lp(-1, -2));
                pager.addPage(pg);
            }
            col.addView(pager, lp(-1, 0, 1f));
            pager.onPage = p -> dots.set(pager.count(), p);
            dots.set(pager.count(), 0);
            col.addView(dots, lp(-1, dp(18)));
            TextView search = text("⌕ Search", 12f, Theme.TEXT);
            search.setTypeface(sans(false));
            search.setBackground(Theme.rounded((Theme.PANEL & 0xFFFFFF) | 0xCC000000, 16f, host));
            search.setPadding(dp(14), dp(7), dp(14), dp(7));
            search.setOnClickListener(v -> host.showDrawer());
            LinearLayout.LayoutParams sp = lp(-2, -2);
            sp.gravity = Gravity.CENTER_HORIZONTAL;
            sp.setMargins(0, dp(6), 0, dp(10));
            col.addView(search, sp);
            LinearLayout dock = new LinearLayout(host);
            dock.setBackground(Theme.rounded(0x33FFFFFF, 32f, host));
            dock.setPadding(dp(8), dp(6), dp(8), dp(6));
            for (AppEntry e : dockApps) {
                dock.addView(appTile(e, 56, false), lp(0, -2, 1f));
            }
            LinearLayout.LayoutParams dp1 = lp(-1, -2);
            dp1.setMargins(dp(12), 0, dp(12), 0);
            col.addView(dock, dp1);
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        @Override
        void tick() {
            wTime.setText(clock());
            wDay.setText(new SimpleDateFormat("EEEE\nd MMMM", Locale.getDefault()).format(new Date())
                    .toUpperCase(Locale.getDefault()));
            wBatt.setText(battery() + "%");
            ring.invalidate();
        }
    }

    // ================================================================== ONE HAND

    /** The top part is just a big, calm header; your apps sit low on the screen where your thumb reaches. */
    static final class OneHand extends AltHome {
        private final TextView time;
        private final TextView sub;

        OneHand(NovaActivity host) {
            super(host);
            List<AppEntry> apps = appsFor(32);
            LinearLayout outer = new LinearLayout(host);
            outer.setOrientation(LinearLayout.VERTICAL);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout head = new LinearLayout(host);
            head.setOrientation(LinearLayout.VERTICAL);
            head.setGravity(Gravity.BOTTOM | Gravity.START);
            head.setPadding(dp(26), 0, dp(26), dp(26));
            time = text(clock(), 58f, Theme.TEXT);
            time.setTypeface(sans(true));
            time.setGravity(Gravity.START);
            head.addView(time);
            sub = text("", 15f, Theme.DIM);
            sub.setTypeface(sans(false));
            sub.setGravity(Gravity.START);
            head.addView(sub);
            col.addView(head, lp(-1, Math.round(getResources().getDisplayMetrics().heightPixels * 0.40f)));
            LinearLayout sheet = new LinearLayout(host);
            sheet.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable sg = new GradientDrawable();
            sg.setColor((Theme.PANEL & 0xFFFFFF) | 0xCC000000);
            float r = dp(28);
            sg.setCornerRadii(new float[] {r, r, r, r, 0, 0, 0, 0});
            sheet.setBackground(sg);
            sheet.setPadding(dp(10), dp(18), dp(10), dp(30));
            sheet.addView(grid(this, slice(apps, 4, 32), 4, 52, true), lp(-1, -2));
            col.addView(sheet, lp(-1, -2));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            outer.addView(sv, lp(-1, 0, 1f));
            LinearLayout dock = new LinearLayout(host);
            dock.setGravity(Gravity.CENTER_VERTICAL);
            dock.setBackgroundColor((Theme.PANEL & 0xFFFFFF) | 0xCC000000);
            dock.setPadding(dp(10), dp(6), dp(10), dp(14));
            for (AppEntry e : slice(apps, 0, 4)) {
                dock.addView(appTile(e, 50, false), lp(0, -2, 1f));
            }
            TextView all = text("☷", 24f, Theme.TEXT);
            all.setGravity(Gravity.CENTER);
            all.setOnClickListener(v -> host.showDrawer());
            all.setOnLongClickListener(v -> {
                host.showSettings();
                return true;
            });
            dock.addView(all, lp(0, dp(62), 1f));
            outer.addView(dock, lp(-1, -2));
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        @Override
        void tick() {
            time.setText(clock());
            sub.setText(new SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(new Date()) + "   " + battery() + "%");
        }
    }

    // ================================================================== WAVE

    /** A short list of your favourite apps in big type, and an A to Z rail on the right: slide along it and the
     *  letters make a wave while the apps of that letter show up. */
    static final class Wave extends AltHome {
        private final LinearLayout list;
        private final TextView time;
        private final TextView title;
        private String letter = null;

        Wave(NovaActivity host) {
            super(host);
            FrameLayout root = new FrameLayout(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(28), dp(56), dp(46), dp(24));
            time = text(clock(), 30f, Theme.TEXT);
            time.setTypeface(sans(true));
            time.setGravity(Gravity.START);
            col.addView(time);
            TextView d = text(date(), 12f, Theme.DIM);
            d.setGravity(Gravity.START);
            d.setTypeface(sans(false));
            col.addView(d);
            col.addView(new View(host), lp(-1, 0, 1f));
            title = text("", 11f, Theme.ACCENT);
            title.setGravity(Gravity.START);
            title.setPadding(0, 0, 0, dp(8));
            title.setOnClickListener(v -> showFavs());
            col.addView(title);
            list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(list);
            col.addView(sv, lp(-1, -2));
            col.addView(new View(host), lp(-1, 0, 1f));
            LinearLayout links = new LinearLayout(host);
            String[] n = {"settings", "widgets", "terminal"};
            Runnable[] r = {() -> host.showSettings(), () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showTerminal()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 12f, Theme.DIM);
                t.setPadding(0, dp(10), dp(16), dp(6));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                links.addView(t);
            }
            col.addView(links);
            root.addView(col, new FrameLayout.LayoutParams(-1, -1));
            FrameLayout.LayoutParams rl = new FrameLayout.LayoutParams(dp(40), -1, Gravity.END);
            rl.setMargins(0, dp(110), 0, dp(80));
            root.addView(new Rail(host), rl);
            addView(root, new FrameLayout.LayoutParams(-1, -1));
            showFavs();
        }

        private void showFavs() {
            letter = null;
            title.setText("FAVOURITES");
            fill(appsFor(8), 24f);
        }

        private void showLetter(String l) {
            if (l.equals(letter)) {
                return;
            }
            letter = l;
            title.setText(l + "   ·   tap here for favourites");
            List<AppEntry> out = new ArrayList<>();
            for (AppEntry e : host.repo.all) {
                char f = e.label.isEmpty() ? '#' : Character.toUpperCase(e.label.charAt(0));
                String key = Character.isLetter(f) ? String.valueOf(f) : "#";
                if (key.equals(l)) {
                    out.add(e);
                }
            }
            fill(out, 20f);
        }

        private void fill(List<AppEntry> apps, float sp) {
            list.removeAllViews();
            if (apps.isEmpty()) {
                TextView t = text("nothing here", 14f, Theme.DIM);
                t.setGravity(Gravity.START);
                list.addView(t);
            }
            for (final AppEntry e : apps) {
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, dp(7), 0, dp(7));
                ImageView iv = new ImageView(host);
                iv.setImageDrawable(Theme.tint(host, e.icon));
                r.addView(iv, lp(dp(30), dp(30)));
                TextView t = text(e.label, sp, Theme.TEXT);
                t.setTypeface(sans(false));
                t.setGravity(Gravity.START);
                t.setSingleLine(true);
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.setPadding(dp(14), 0, 0, 0);
                r.addView(t, lp(0, -2, 1f));
                r.setOnClickListener(v -> host.launch(e));
                r.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                list.addView(r, lp(-1, -2));
            }
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        final class Rail extends View {
            private final String[] letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#".split("");
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float touchY = -1;

            Rail(Context c) {
                super(c);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                p.setTextAlign(Paint.Align.CENTER);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                    touchY = e.getY();
                    int i = Math.max(0, Math.min(letters.length - 1, (int) (touchY / getHeight() * letters.length)));
                    if (!letters[i].equals(letter)) {
                        host.buzz(4);
                    }
                    showLetter(letters[i]);
                    invalidate();
                    return true;
                }
                touchY = -1;
                invalidate();
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float step = getHeight() / (float) letters.length;
                for (int i = 0; i < letters.length; i++) {
                    float y = step * (i + 0.5f);
                    float pull = 0;
                    float size = 10 * d;
                    if (touchY >= 0) {
                        float dist = Math.abs(y - touchY) / (step * 2.2f);
                        float g = (float) Math.exp(-dist * dist);
                        pull = g * 26 * d;
                        size = (10 + g * 10) * d;
                    }
                    p.setTextSize(size);
                    boolean on = letters[i].equals(letter);
                    p.setColor(on ? Theme.ACCENT : Theme.DIM);
                    c.drawText(letters[i], getWidth() / 2f - pull, y + size * 0.35f, p);
                }
            }
        }
    }

    // ================================================================== FOLDERS

    /** Your apps sort themselves into folders (social, music, games, photos ...). Tap a folder to open it. */
    static final class Folders extends AltHome {
        private final TextView time;
        private FrameLayout open;

        Folders(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(52), dp(16), dp(16));
            time = text(clock(), 48f, Theme.TEXT);
            time.setTypeface(sans(true));
            time.setGravity(Gravity.START);
            col.addView(time);
            TextView d = text(date(), 13f, Theme.DIM);
            d.setGravity(Gravity.START);
            d.setPadding(0, 0, 0, dp(18));
            col.addView(d);
            List<AppEntry> fav = slice(pinned(), 0, 5);
            if (!fav.isEmpty()) {
                col.addView(grid(this, fav, 5, 48, true), lp(-1, -2));
            }
            Map<String, List<AppEntry>> folders = sort(host);
            LinearLayout g = new LinearLayout(host);
            g.setOrientation(LinearLayout.VERTICAL);
            g.setPadding(0, dp(12), 0, 0);
            LinearLayout row = null;
            int i = 0;
            for (Map.Entry<String, List<AppEntry>> en : folders.entrySet()) {
                if (i % 3 == 0) {
                    row = new LinearLayout(host);
                    g.addView(row, lp(-1, -2));
                }
                LinearLayout.LayoutParams fp = lp(0, -2, 1f);
                fp.setMargins(dp(5), dp(5), dp(5), dp(5));
                row.addView(folder(en.getKey(), en.getValue()), fp);
                i++;
            }
            while (row != null && i % 3 != 0) {
                row.addView(new View(host), lp(0, 1, 1f));
                i++;
            }
            col.addView(g, lp(-1, -2));
            LinearLayout.LayoutParams sp = lp(-1, -2);
            sp.topMargin = dp(12);
            col.addView(pill(this, "⌕   Search all apps", () -> host.showDrawer()), sp);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
        }

        /** Puts every app in a folder, by name first and then by what Android says the app is. */
        static Map<String, List<AppEntry>> sort(NovaActivity host) {
            String[][] words = {
                {"Social", "whatsapp", "discord", "telegram", "instagram", "snapchat", "tiktok", "facebook", "messenger",
                    "signal", "threema", "twitter", "reddit", "bereal", "pinterest", "linkedin", "mms", "messaging", "message"},
                {"Music", "spotify", "music", "soundcloud", "shazam", "deezer", "tidal", "radio", "podcast"},
                {"Video", "youtube", "netflix", "disney", "twitch", "prime", "video", "vlc", "tv"},
                {"Photos", "camera", "photo", "gallery", "lens", "snapseed", "vsco", "capcut"},
                {"Travel", "maps", "sbb", "zvv", "uber", "bolt", "transit", "airbnb", "booking", "flight", "weather"},
                {"Money", "bank", "twint", "pay", "revolut", "ubs", "postfinance", "wallet", "crypto", "raiffeisen", "neon"},
                {"Web", "chrome", "browser", "firefox", "opera", "brave", "edge", "duckduckgo", "google.android.googlequicksearchbox"},
                {"Work", "docs", "sheets", "slides", "drive", "office", "word", "excel", "outlook", "gmail", "mail", "calendar",
                    "notion", "teams", "zoom", "keep", "claude", "chatgpt", "translate"},
                {"Tools", "settings", "clock", "calculator", "files", "contacts", "dialer", "phone", "recorder", "compass",
                    "flashlight", "store", "vending", "authenticator", "vpn"}};
            String[] cat = {"Games", "Music", "Video", "Photos", "Social", "News", "Travel", "Work"};
            Map<String, List<AppEntry>> out = new LinkedHashMap<>();
            for (String[] w : words) {
                out.put(w[0], new ArrayList<>());
            }
            out.put("Games", new ArrayList<>());
            out.put("News", new ArrayList<>());
            out.put("Other", new ArrayList<>());
            android.content.pm.PackageManager pm = host.getPackageManager();
            for (AppEntry e : host.repo.all) {
                String name = (e.pkg + " " + e.label).toLowerCase(Locale.ROOT);
                String put = null;
                for (String[] w : words) {
                    for (int k = 1; k < w.length && put == null; k++) {
                        if (name.contains(w[k])) {
                            put = w[0];
                        }
                    }
                    if (put != null) {
                        break;
                    }
                }
                if (put == null) {
                    try {
                        ApplicationInfo ai = pm.getApplicationInfo(e.pkg, 0);
                        int c = ai.category;
                        if ((ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0) {
                            c = ApplicationInfo.CATEGORY_GAME;
                        }
                        if (c >= 0 && c < cat.length) {
                            put = cat[c];
                        }
                    } catch (Exception ignored) {
                        // app gone
                    }
                }
                out.get(put == null ? "Other" : put).add(e);
            }
            Map<String, List<AppEntry>> clean = new LinkedHashMap<>();
            for (Map.Entry<String, List<AppEntry>> en : out.entrySet()) {
                if (!en.getValue().isEmpty()) {
                    clean.put(en.getKey(), en.getValue());
                }
            }
            return clean;
        }

        private View folder(final String name, final List<AppEntry> apps) {
            LinearLayout f = new LinearLayout(host);
            f.setOrientation(LinearLayout.VERTICAL);
            f.setGravity(Gravity.CENTER_HORIZONTAL);
            LinearLayout box = new LinearLayout(host);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
            box.setPadding(dp(10), dp(10), dp(10), dp(10));
            for (int r = 0; r < 2; r++) {
                LinearLayout row = new LinearLayout(host);
                for (int c = 0; c < 2; c++) {
                    int i = r * 2 + c;
                    if (i < apps.size()) {
                        ImageView iv = new ImageView(host);
                        iv.setImageDrawable(Theme.tint(host, apps.get(i).icon));
                        LinearLayout.LayoutParams ip = lp(0, dp(30), 1f);
                        ip.setMargins(dp(3), dp(3), dp(3), dp(3));
                        row.addView(iv, ip);
                    } else {
                        row.addView(new View(host), lp(0, dp(30), 1f));
                    }
                }
                box.addView(row, lp(-1, -2));
            }
            f.addView(box, lp(-1, -2));
            TextView t = text(name + "  " + apps.size(), 11f, Theme.TEXT);
            t.setTypeface(sans(false));
            t.setPadding(0, dp(6), 0, 0);
            f.addView(t);
            f.setOnClickListener(v -> openFolder(name, apps));
            press(f);
            return f;
        }

        private void openFolder(String name, List<AppEntry> apps) {
            closeFolder();
            open = new FrameLayout(host);
            open.setBackgroundColor(0xAA000000);
            open.setOnClickListener(v -> closeFolder());
            LinearLayout panel = new LinearLayout(host);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setBackground(Theme.rounded(Theme.PANEL | 0xFF000000, 28f, host));
            panel.setPadding(dp(14), dp(18), dp(14), dp(14));
            panel.setClickable(true);
            TextView t = text(name, 20f, Theme.TEXT);
            t.setTypeface(sans(false));
            t.setPadding(0, 0, 0, dp(10));
            panel.addView(t);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(grid(this, apps, 4, 50, true));
            panel.addView(sv, lp(-1, -2));
            FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            pp.setMargins(dp(20), dp(80), dp(20), dp(80));
            open.addView(panel, pp);
            open.setAlpha(0f);
            addView(open, new FrameLayout.LayoutParams(-1, -1));
            open.animate().alpha(1f).setDuration(160).start();
            panel.setScaleX(0.9f);
            panel.setScaleY(0.9f);
            panel.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
        }

        private void closeFolder() {
            if (open != null) {
                removeView(open);
                open = null;
            }
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== PAGES

    /** The classic phone: a big clock on the first page, pages of icons to swipe through, and a dock with the
     *  all-apps button in the middle. */
    static final class Pages extends AltHome {
        private final TextView time;
        private final TextView day;

        Pages(NovaActivity host) {
            super(host);
            List<AppEntry> all = everything(this);
            List<AppEntry> dockApps = slice(all, 0, 4);
            List<AppEntry> rest = slice(all, 4, all.size());
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(0, dp(48), 0, dp(10));
            final Pager pager = new Pager(host);
            final Dots dots = new Dots(host);
            LinearLayout p1 = new LinearLayout(host);
            p1.setOrientation(LinearLayout.VERTICAL);
            p1.setPadding(dp(12), dp(16), dp(12), 0);
            time = text(clock(), 72f, Theme.TEXT);
            time.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            time.setShadowLayer(8f, 0, 2f, 0x99000000);
            time.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            p1.addView(time);
            day = text("", 14f, Theme.TEXT);
            day.setTypeface(sans(false));
            day.setShadowLayer(6f, 0, 1f, 0x99000000);
            p1.addView(day);
            p1.addView(new View(host), lp(-1, 0, 1f));
            p1.addView(grid(this, slice(rest, 0, 8), 4, 50, true), lp(-1, -2));
            pager.addPage(p1);
            for (int i = 8; i < rest.size() && pager.count() < 8; i += 20) {
                LinearLayout pg = new LinearLayout(host);
                pg.setOrientation(LinearLayout.VERTICAL);
                pg.setPadding(dp(12), dp(16), dp(12), 0);
                pg.addView(grid(this, slice(rest, i, i + 20), 4, 50, true), lp(-1, -2));
                pager.addPage(pg);
            }
            col.addView(pager, lp(-1, 0, 1f));
            pager.onPage = p -> dots.set(pager.count(), p);
            dots.set(pager.count(), 0);
            col.addView(dots, lp(-1, dp(22)));
            View line = new View(host);
            line.setBackgroundColor(0x33FFFFFF);
            LinearLayout.LayoutParams ll = lp(-1, 1);
            ll.setMargins(dp(20), dp(2), dp(20), dp(6));
            col.addView(line, ll);
            LinearLayout dock = new LinearLayout(host);
            dock.setGravity(Gravity.CENTER_VERTICAL);
            dock.setPadding(dp(8), 0, dp(8), 0);
            for (int i = 0; i < 5; i++) {
                if (i == 2) {
                    dock.addView(new AllButton(host), lp(0, dp(58), 1f));
                    continue;
                }
                int k = i < 2 ? i : i - 1;
                if (k < dockApps.size()) {
                    dock.addView(appTile(dockApps.get(k), 50, false), lp(0, -2, 1f));
                } else {
                    dock.addView(new View(host), lp(0, 1, 1f));
                }
            }
            col.addView(dock, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        @Override
        void tick() {
            time.setText(clock());
            day.setText(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()) + "   " + battery() + "%");
        }

        /** The round all-apps button with six dots. */
        final class AllButton extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            AllButton(Context c) {
                super(c);
                setOnClickListener(v -> host.showDrawer());
                setOnLongClickListener(v -> {
                    host.showSettings();
                    return true;
                });
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                p.setColor(0xEEFFFFFF);
                c.drawCircle(cx, cy, 24 * d, p);
                p.setColor(0xFF555555);
                for (int r = 0; r < 2; r++) {
                    for (int k = 0; k < 3; k++) {
                        c.drawCircle(cx + (k - 1) * 8 * d, cy + (r - 0.5f) * 8 * d, 2.3f * d, p);
                    }
                }
            }
        }
    }

    // ================================================================== SMART

    /** Apps suggested for this time of day (from what you usually open around now), the last ones you used, and
     *  your favourites. */
    static final class Smart extends AltHome {
        private final TextView greet;
        private final TextView time;

        Smart(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(52), dp(16), dp(10));
            greet = text(greeting(), 24f, Theme.TEXT);
            greet.setTypeface(sans(false));
            greet.setGravity(Gravity.START);
            col.addView(greet);
            time = text("", 13f, Theme.DIM);
            time.setGravity(Gravity.START);
            time.setPadding(0, dp(2), 0, dp(14));
            col.addView(time);
            LinearLayout body = new LinearLayout(host);
            body.setOrientation(LinearLayout.VERTICAL);
            List<AppEntry> now = suggested(host, 5);
            body.addView(card("SUGGESTED FOR " + hourName().toUpperCase(Locale.getDefault()),
                    now.isEmpty() ? hint("Open apps for a few days and NOVA learns what you use when.")
                            : grid(this, now, 5, 46, true)));
            List<AppEntry> rec = HomeKit.recent(host, 5);
            if (!rec.isEmpty()) {
                body.addView(gap());
                body.addView(card("JUMP BACK IN", grid(this, rec, 5, 46, true)));
            }
            body.addView(gap());
            body.addView(card("FAVOURITES", grid(this, slice(pinned(), 0, 12), 4, 48, true)));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(body);
            col.addView(sv, lp(-1, 0, 1f));
            LinearLayout.LayoutParams sp = lp(-1, -2);
            sp.topMargin = dp(8);
            col.addView(pill(this, "⌕   Search apps", () -> host.showDrawer()), sp);
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private View gap() {
            View v = new View(host);
            v.setLayoutParams(lp(-1, dp(10)));
            return v;
        }

        private View hint(String s) {
            TextView t = text(s, 12f, Theme.DIM);
            t.setGravity(Gravity.START);
            t.setPadding(0, dp(8), 0, dp(4));
            return t;
        }

        private static String hourName() {
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            return h < 5 ? "tonight" : h < 11 ? "this morning" : h < 14 ? "lunchtime" : h < 18 ? "this afternoon" : "this evening";
        }

        /** The apps opened most within an hour of this time of day, over all the history. */
        static List<AppEntry> suggested(NovaActivity host, int n) {
            int nowH = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            Map<String, Integer> score = new HashMap<>();
            Calendar c = Calendar.getInstance();
            for (Object[] o : HomeKit.history()) {
                c.setTimeInMillis((long) o[1]);
                int h = c.get(Calendar.HOUR_OF_DAY);
                int dist = Math.min(Math.abs(h - nowH), 24 - Math.abs(h - nowH));
                if (dist <= 1) {
                    String p = (String) o[0];
                    score.put(p, (score.containsKey(p) ? score.get(p) : 0) + (dist == 0 ? 2 : 1));
                }
            }
            List<String> pk = new ArrayList<>(score.keySet());
            pk.sort((a, b) -> score.get(b) - score.get(a));
            List<AppEntry> out = new ArrayList<>();
            for (String p : pk) {
                AppEntry e = host.repo.find(p);
                if (e != null) {
                    out.add(e);
                    if (out.size() >= n) {
                        break;
                    }
                }
            }
            return out;
        }

        @Override
        void tick() {
            time.setText(clock() + "   ·   " + date() + "   ·   " + battery() + "%");
        }
    }

    // ================================================================== GLASS

    /** See-through cards over your wallpaper: a big clock, two small widgets, your apps and a dock. */
    static final class Glass extends AltHome {
        private final TextView time;
        private final TextView day;
        private final TextView batt;
        private final TextView week;

        Glass(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), dp(48), dp(14), dp(14));
            LinearLayout clockCard = glass();
            clockCard.setGravity(Gravity.CENTER);
            time = text(clock(), 64f, 0xFFFFFFFF);
            time.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            clockCard.addView(time);
            day = text("", 13f, 0xDDFFFFFF);
            day.setTypeface(sans(false));
            clockCard.addView(day);
            clockCard.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            col.addView(clockCard, lp(-1, -2));
            LinearLayout small = new LinearLayout(host);
            small.setPadding(0, dp(10), 0, 0);
            LinearLayout b = glass();
            batt = text("", 26f, 0xFFFFFFFF);
            batt.setTypeface(sans(true));
            b.addView(batt);
            b.addView(text("battery", 10f, 0xBBFFFFFF));
            b.setOnClickListener(v -> host.showShade());
            LinearLayout.LayoutParams bl = lp(0, -2, 1f);
            bl.rightMargin = dp(5);
            small.addView(b, bl);
            LinearLayout w = glass();
            week = text("", 26f, 0xFFFFFFFF);
            week.setTypeface(sans(true));
            w.addView(week);
            w.addView(text("week", 10f, 0xBBFFFFFF));
            w.setOnClickListener(v -> host.showOverlay(new ProfileScreen(host)));
            LinearLayout.LayoutParams wl = lp(0, -2, 1f);
            wl.leftMargin = dp(5);
            small.addView(w, wl);
            col.addView(small, lp(-1, -2));
            List<AppEntry> apps = appsFor(16);
            LinearLayout g = glass();
            g.setPadding(dp(6), dp(10), dp(6), dp(10));
            g.addView(grid(this, slice(apps, 4, 16), 4, 50, true), lp(-1, -2));
            LinearLayout.LayoutParams gp = lp(-1, -2);
            gp.topMargin = dp(10);
            col.addView(g, gp);
            col.addView(new View(host), lp(-1, 0, 1f));
            LinearLayout dock = glass();
            dock.setOrientation(LinearLayout.HORIZONTAL);
            dock.setPadding(dp(6), dp(6), dp(6), dp(6));
            for (AppEntry e : slice(apps, 0, 4)) {
                dock.addView(appTile(e, 52, false), lp(0, -2, 1f));
            }
            TextView all = text("⋯", 26f, 0xFFFFFFFF);
            all.setGravity(Gravity.CENTER);
            all.setOnClickListener(v -> host.showDrawer());
            dock.addView(all, lp(0, dp(64), 1f));
            col.addView(dock, lp(-1, -2));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.setFillViewport(true);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private LinearLayout glass() {
            LinearLayout l = new LinearLayout(host);
            l.setOrientation(LinearLayout.VERTICAL);
            l.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {0x30FFFFFF, 0x14FFFFFF});
            g.setCornerRadius(dp(26));
            g.setStroke(dp(1), 0x40FFFFFF);
            l.setBackground(g);
            l.setPadding(dp(14), dp(14), dp(14), dp(14));
            return l;
        }

        @Override
        void tick() {
            time.setText(clock());
            day.setText(date());
            batt.setText(battery() + "%");
            week.setText(String.valueOf(Calendar.getInstance().get(Calendar.WEEK_OF_YEAR)));
        }
    }

    // ================================================================== CLEAN

    /** Nothing but the time in the middle and four apps at the bottom. Tap the time for widgets, the arrow for all
     *  apps, hold anywhere for settings. */
    static final class Clean extends AltHome {
        private final TextView time;
        private final TextView day;

        Clean(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.setPadding(dp(20), dp(40), dp(20), dp(18));
            col.addView(new View(host), lp(-1, 0, 1f));
            time = text(clock(), 84f, Theme.TEXT);
            time.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            time.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            col.addView(time);
            day = text("", 14f, Theme.DIM);
            day.setTypeface(sans(false));
            col.addView(day);
            col.addView(new View(host), lp(-1, 0, 1.3f));
            TextView up = text("⌃", 22f, Theme.DIM);
            up.setPadding(dp(30), dp(4), dp(30), dp(6));
            up.setOnClickListener(v -> host.showDrawer());
            col.addView(up);
            LinearLayout dock = new LinearLayout(host);
            for (AppEntry e : appsFor(4)) {
                dock.addView(appTile(e, 52, false), lp(0, -2, 1f));
            }
            col.addView(dock, lp(-1, -2));
            col.setOnLongClickListener(v -> {
                host.showSettings();
                return true;
            });
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        @Override
        void tick() {
            time.setText(clock());
            day.setText(date() + "   ·   " + battery() + "%");
        }
    }

    // ================================================================== BOARD

    /** Widgets first: clock and info, the mixed card, your mood calendar and songs, then one row of apps. */
    static final class Board extends AltHome {
        Board(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout body = new LinearLayout(host);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(dp(12), dp(46), dp(12), dp(10));
            body.addView(card(null, HomeMix.hero(host)));
            body.addView(card("MOOD", new MoodCalendar(host)), top());
            body.addView(card(null, new HomeMix.Mix(host, 280)), top());
            body.addView(card("SONGS", new SongsWidget(host)), top());
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(body);
            col.addView(sv, lp(-1, 0, 1f));
            LinearLayout row = new LinearLayout(host);
            row.setPadding(dp(8), dp(6), dp(8), 0);
            for (AppEntry e : appsFor(5)) {
                row.addView(appTile(e, 46, false), lp(0, -2, 1f));
            }
            col.addView(row, lp(-1, -2));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        private LinearLayout.LayoutParams top() {
            LinearLayout.LayoutParams p = lp(-1, -2);
            p.topMargin = dp(10);
            return p;
        }
    }
}
