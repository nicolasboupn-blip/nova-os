package app.novaos;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Every smiley you tap is kept with its time. A day's mood is worked out by time: each smiley counts from when you
 * tapped it until the next one (or the end of the day, or now for today). Half a day good and half bad comes out in
 * the middle.
 */
final class MoodLog {
    static final String[] FACES = {"😄", "🙂", "😐", "🙁", "😢"};
    static final String[] NAMES = {"great", "good", "okay", "bad", "awful"};
    private static final String KEY = "mood_log";
    private static final int MAX = 3000;

    private MoodLog() {
    }

    static String stamp(Calendar c) {
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(c.getTime());
    }

    static String today() {
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date());
    }

    /** Saves a smiley (0 great ... 4 awful) at the current time. */
    static void log(int face) {
        Calendar c = Calendar.getInstance();
        int minute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        String entry = stamp(c) + "|" + minute + "|" + Math.max(0, Math.min(4, face));
        String old = Prefs.getString(KEY, "");
        String[] parts = old.isEmpty() ? new String[0] : old.split(";");
        StringBuilder b = new StringBuilder();
        int start = Math.max(0, parts.length - (MAX - 1));
        for (int i = start; i < parts.length; i++) {
            b.append(parts[i]).append(';');
        }
        b.append(entry);
        Prefs.putString(KEY, b.toString());
        // the old "mood today" keys, so older blocks still show the last smiley
        Prefs.putInt("mood_last_d", Integer.parseInt(stamp(c)));
        Prefs.putInt("mood_last_m", face);
    }

    /** {minute, face} pairs of one day, in time order. */
    static List<int[]> day(String stamp) {
        List<int[]> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String p : raw.split(";")) {
            if (!p.startsWith(stamp)) {
                continue;
            }
            String[] f = p.split("\\|");
            if (f.length < 3) {
                continue;
            }
            try {
                out.add(new int[] {Integer.parseInt(f[1]), Integer.parseInt(f[2])});
            } catch (NumberFormatException ignored) {
                // broken entry
            }
        }
        out.sort((a, b) -> a[0] - b[0]);
        return out;
    }

    /** The last smiley of today, or -1. */
    static int current() {
        List<int[]> d = day(today());
        return d.isEmpty() ? -1 : d.get(d.size() - 1)[1];
    }

    /** Minutes spent in each of the five moods on that day. */
    static long[] minutes(String stamp) {
        long[] m = new long[5];
        List<int[]> d = day(stamp);
        if (d.isEmpty()) {
            return m;
        }
        int end = 24 * 60;
        if (stamp.equals(today())) {
            Calendar c = Calendar.getInstance();
            end = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) + 1;
        }
        for (int i = 0; i < d.size(); i++) {
            int from = d.get(i)[0];
            int to = i + 1 < d.size() ? d.get(i + 1)[0] : end;
            // a smiley tapped in the last minute still counts a little
            m[d.get(i)[1]] += Math.max(1, to - from);
        }
        return m;
    }

    /** 1 = the whole day great, 0 = the whole day awful, -1 = nothing rated. */
    static float score(String stamp) {
        long[] m = minutes(stamp);
        long total = 0;
        double sum = 0;
        for (int i = 0; i < 5; i++) {
            total += m[i];
            sum += m[i] * (4 - i) / 4.0;
        }
        return total == 0 ? -1f : (float) (sum / total);
    }

    /** The smiley a score works out to. */
    static int faceOf(float score) {
        return Math.max(0, Math.min(4, Math.round((1f - score) * 4f)));
    }

    /** Red (awful) through yellow to green (great). */
    static int colorOf(float score) {
        float[] hsv = {Math.max(0f, Math.min(1f, score)) * 125f, 0.62f, 0.86f};
        return android.graphics.Color.HSVToColor(hsv);
    }
}
