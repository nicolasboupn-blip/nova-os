package app.novaos;

import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * The look picker: a panel that slides out from the right edge of the home screen. Every tap changes NOVA straight away,
 * so you see the result behind the panel. SKINS change everything at once (colours, home screen, app drawer); the rows
 * under them let you mix your own.
 */
final class UiSwitcher extends FrameLayout implements BackAware {
    // name, caption, colour look (UiStyle id), home layout (AltHome index), app drawer (DrawerScreen index)
    private static final Object[][] SKINS = {
        {"NOVA", "the original", 0, 0, 0},
        {"INK", "only type", 9, 9, 2},
        {"CANDY", "soft and round", 10, 10, 0},
        {"PAPER", "light tiles", 11, 1, 3},
        {"TOKYO", "neon rings", 12, 2, 4},
        {"SUNSET", "warm feed", 13, 3, 1},
        {"ARCADE", "game console", 14, 4, 3},
        {"PRESS", "newspaper", 15, 5, 2},
        {"WOODS", "forest fan", 16, 6, 0},
        {"GOLD", "black and gold", 17, 7, 1},
        {"POP", "bubblegum", 18, 8, 4},
        {"DESKTOP", "old computer", 6, 13, 1},
        {"HANDHELD", "game console", 16, 14, 3},
        {"TRAM", "line map", 11, 25, 1},
        {"STUDIO", "old radio", 13, 29, 0},
        {"GLYPH", "dots and red", 9, 12, 2},
        {"BLUE", "the familiar phone", 6, 10, 0},
        {"TILES", "live tiles", 3, 11, 1},
        {"KEYS", "old mobile phone", 6, 15, 1},
        {"WATCH", "honeycomb", 9, 16, 0},
        {"DECK", "card pile", 10, 17, 3},
        {"DAYLINE", "your day", 1, 18, 1},
        {"LIBRARY", "bookshelf", 17, 19, 2},
        {"TRIO", "three columns", 0, 20, 1},
        {"HACKER", "terminal dashboard", 2, 21, 4},
        {"FINDER", "one search box", 8, 22, 1},
        {"CAR", "dashboard", 7, 23, 0},
        {"CORK", "pin board", 13, 24, 3},
        {"COVERS", "3D carousel", 5, 26, 3},
        {"RAIL", "sidebar", 8, 27, 0},
        {"PLAYER", "click wheel", 11, 28, 1},
        {"PINS", "card wall", 18, 30, 3},
        {"GLANCE", "normal: date and grid", 0, 31, 0},
        {"SPRING", "normal: widgets and pages", 6, 32, 0},
        {"ONE HAND", "normal: thumb reach", 8, 33, 0},
        {"WAVE", "normal: A to Z rail", 9, 34, 1},
        {"FOLDERS", "normal: sorted folders", 1, 35, 3},
        {"PAGES", "normal: classic pages", 0, 36, 0},
        {"SMART", "normal: suggestions", 5, 37, 0},
        {"GLASS", "normal: see-through", 1, 38, 0},
        {"CLEAN", "normal: just the time", 9, 39, 2},
        {"BOARD", "normal: widgets first", 0, 40, 3}};

    private final NovaActivity host;
    private LinearLayout panel;
    private View sheet;
    private boolean first = true;

    private UiSwitcher(NovaActivity host) {
        super(host);
        this.host = host;
        build();
    }

    static void open(NovaActivity host) {
        if (host.switcher != null) {
            return;
        }
        host.switcher = new UiSwitcher(host);
        host.addKeep(host.switcher);
    }

    void close() {
        sheet.animate().translationX(sheet.getWidth()).setDuration(180).withEndAction(() -> host.removeSwitcher()).start();
    }

    @Override
    public boolean onBack() {
        close();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private void build() {
        removeAllViews();
        View scrim = new View(host);
        scrim.setBackgroundColor(0x55000000);
        scrim.setOnClickListener(v -> close());
        addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        int w = Math.min(dp(350), Math.round(host.getResources().getDisplayMetrics().widthPixels * 0.9f));
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(44), dp(16), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor((Theme.BG & 0xFFFFFF) | 0xF2000000);
        float r = dp(26);
        bg.setCornerRadii(new float[] {r, r, 0, 0, 0, 0, r, r});
        bg.setStroke(dp(1), (Theme.ACCENT & 0xFFFFFF) | 0x55000000);
        sv.setBackground(bg);
        sv.addView(panel);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, -1);
        lp.gravity = Gravity.END;
        addView(sv, lp);
        sheet = sv;

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("LOOK", 16f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = text("✕", 18f, Theme.TEXT);
        x.setPadding(dp(12), dp(6), dp(4), dp(6));
        x.setOnClickListener(v -> close());
        head.addView(x);
        panel.addView(head);
        TextView hint = text("Tap anything: it changes right away.", 11f, Theme.DIM);
        hint.setGravity(Gravity.START);
        hint.setPadding(0, dp(2), 0, dp(10));
        panel.addView(hint);

        section("SKINS  ·  change everything at once");
        int curStyle = Prefs.getInt(UiStyle.K_STYLE, 0);
        int curLay = Prefs.getInt(AltHome.K_LAYOUT, 0);
        int curDr = Prefs.getInt(DrawerScreen.K_DRAWER, 0);
        for (int i = 0; i < SKINS.length; i += 2) {
            LinearLayout row = new LinearLayout(host);
            for (int j = i; j < Math.min(i + 2, SKINS.length); j++) {
                Object[] k = SKINS[j];
                boolean on = (int) k[2] == curStyle && (int) k[3] == curLay && (int) k[4] == curDr;
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
                cp.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(skinCard(k, on), cp);
            }
            if (i + 1 >= SKINS.length) {
                row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
            }
            panel.addView(row);
        }

        section("COLOURS");
        String[] cn = new String[UiStyle.NAMES.length];
        int n = 0;
        int[] cid = new int[cn.length];
        for (int i = 0; i < UiStyle.NAMES.length; i++) {
            if (i == UiStyle.CUSTOM && !UiStyle.designerOn()) {
                continue;
            }
            cn[n] = UiStyle.NAMES[i];
            cid[n++] = i;
        }
        panel.addView(chips(cn, cid, n, UiStyle.chosen(), UiStyle.K_STYLE));

        section("HOME SCREEN");
        int[] lid = new int[AltHome.NAMES.length];
        for (int i = 0; i < lid.length; i++) {
            lid[i] = i;
        }
        // many layouts: three rows of chips you can each slide sideways
        int per = (lid.length + 2) / 3;
        for (int st = 0; st < lid.length; st += per) {
            int cnt = Math.min(per, lid.length - st);
            String[] nm = new String[cnt];
            int[] id = new int[cnt];
            for (int i = 0; i < cnt; i++) {
                nm[i] = AltHome.NAMES[st + i];
                id[i] = st + i;
            }
            View row = chips(nm, id, cnt, curLay, AltHome.K_LAYOUT);
            row.setPadding(0, 0, 0, dp(6));
            panel.addView(row);
        }

        section("APP DRAWER");
        int[] did = new int[DrawerScreen.NAMES.length];
        for (int i = 0; i < did.length; i++) {
            did[i] = i;
        }
        panel.addView(chips(DrawerScreen.NAMES, did, did.length, DrawerScreen.mode(), DrawerScreen.K_DRAWER));

        section("EXTRAS");
        LinearLayout ex = new LinearLayout(host);
        ex.addView(chip(UiStyle.forceDark() ? "FORCE DARK: ON" : "FORCE DARK: OFF", UiStyle.forceDark(), () -> {
            Prefs.putBool(UiStyle.K_DARK, !UiStyle.forceDark());
            apply();
        }));
        ex.addView(chip("SETTINGS ›", false, () -> {
            host.removeSwitcher();
            host.showSettings();
        }));
        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(ex);
        panel.addView(hs);

        if (first) {
            first = false;
            sv.setTranslationX(w);
            sv.animate().translationX(0).setDuration(220).start();
            scrim.setAlpha(0f);
            scrim.animate().alpha(1f).setDuration(220).start();
        }
    }

    private void section(String s) {
        TextView t = text(s, 10f, Theme.DIM);
        t.setLetterSpacing(0.15f);
        t.setGravity(Gravity.START);
        t.setPadding(dp(2), dp(16), 0, dp(6));
        panel.addView(t);
    }

    private void apply() {
        host.restyle();
        build();
    }

    private HorizontalScrollView chips(final String[] names, final int[] ids, int count, int current, final String key) {
        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(host);
        for (int i = 0; i < count; i++) {
            final int id = ids[i];
            row.addView(chip(names[i], id == current, () -> {
                Prefs.putInt(key, id);
                apply();
            }));
        }
        hs.addView(row);
        return hs;
    }

    private TextView chip(String s, boolean on, Runnable r) {
        TextView t = text(s, 11f, on ? Theme.BG : Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(9), dp(14), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? Theme.ACCENT : (Theme.PANEL | 0xFF000000));
        g.setCornerRadius(dp(18));
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, dp(6), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    /** A little preview painted in the skin's own colours, whatever look is on right now. */
    private View skinCard(final Object[] k, boolean on) {
        int style = (int) k[2];
        int[] p = palette(style);
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {p[1], p[0]});
        g.setCornerRadius(dp(style >= 9 ? Math.max(4, UiStyle.LOOK10[style - 9][0] / 8) : 14));
        g.setStroke(dp(on ? 3 : 1), on ? p[3] : (p[3] & 0xFFFFFF) | 0x55000000);
        c.setBackground(g);
        // a mock: accent bar, panel bar, two dots
        LinearLayout mock = new LinearLayout(host);
        mock.setGravity(Gravity.CENTER_VERTICAL);
        View bar = new View(host);
        GradientDrawable b1 = new GradientDrawable();
        b1.setColor(p[3]);
        b1.setCornerRadius(dp(3));
        bar.setBackground(b1);
        mock.addView(bar, new LinearLayout.LayoutParams(dp(26), dp(6)));
        View bar2 = new View(host);
        GradientDrawable b2 = new GradientDrawable();
        b2.setColor(p[2]);
        b2.setCornerRadius(dp(3));
        bar2.setBackground(b2);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(14), 1f);
        l2.leftMargin = dp(6);
        mock.addView(bar2, l2);
        View dot = new View(host);
        GradientDrawable b3 = new GradientDrawable();
        b3.setShape(GradientDrawable.OVAL);
        b3.setColor(p[4]);
        dot.setBackground(b3);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(dp(12), dp(12));
        l3.leftMargin = dp(6);
        mock.addView(dot, l3);
        c.addView(mock, new LinearLayout.LayoutParams(-1, -2));
        TextView name = new TextView(host);
        name.setText((String) k[0]);
        name.setTextColor(p[5]);
        name.setTextSize(15f);
        name.setTypeface(style >= 9 ? UiStyle.fontOf(UiStyle.LOOK10[style - 9][4]) : Typeface.MONOSPACE, Typeface.BOLD);
        name.setGravity(Gravity.START);
        name.setPadding(0, dp(10), 0, 0);
        c.addView(name);
        TextView cap = new TextView(host);
        cap.setText(k[1] + "\n" + AltHome.NAMES[(int) k[3]].toLowerCase() + " · " + DrawerScreen.NAMES[(int) k[4]].toLowerCase());
        cap.setTextColor(p[6]);
        cap.setTextSize(10f);
        cap.setGravity(Gravity.START);
        c.addView(cap);
        c.setOnClickListener(v -> {
            Prefs.putInt(UiStyle.K_STYLE, (int) k[2]);
            Prefs.putInt(AltHome.K_LAYOUT, (int) k[3]);
            Prefs.putInt(DrawerScreen.K_DRAWER, (int) k[4]);
            apply();
        });
        return c;
    }

    private static int[] palette(int style) {
        switch (style) {
            case UiStyle.AURORA:
                return UiStyle.P_AURORA;
            case UiStyle.TERMINAL:
                return UiStyle.P_TERMINAL;
            case UiStyle.BLOCK:
                return UiStyle.P_BLOCK;
            case UiStyle.SYNTH:
                return UiStyle.P_SYNTH;
            case UiStyle.OCEAN:
                return UiStyle.P_OCEAN;
            case UiStyle.INFERNO:
                return UiStyle.P_INFERNO;
            case UiStyle.GALAXY:
                return UiStyle.P_GALAXY;
            default:
                if (style >= 9 && style < 9 + UiStyle.PAL10.length) {
                    return UiStyle.PAL10[style - 9];
                }
                return new int[] {0xFF0B0A14, 0xFF1A1630, 0xFF221D3D, 0xFFB39DFF, 0xFFFF7BD5, 0xFFF2EEFF, 0xFF8E84B3};
        }
    }
}
