package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A normal street/terrain map (OpenStreetMap tiles) around you, about 40 km out in every direction, with every peak
 * marked by a triangle with its name and height. Drag to move, pinch or +/- to zoom, tap a peak for details.
 */
final class PeakTileMap extends View {
    private final float d;
    private final float scale;       // tile size multiplier so tiles are not tiny on sharp screens
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tileP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final LruCache<String, Bitmap> cache = new LruCache<>(90);
    private final Set<String> loading = new HashSet<>();
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final GestureDetector gestures;
    private final ScaleGestureDetector pinch;
    private final List<PeakData.Peak> hit = new ArrayList<>();
    private final List<float[]> hitPos = new ArrayList<>();
    private double cx;               // centre of the view, in world pixels at the current zoom
    private double cy;
    private int z = 10;
    private boolean placed;
    private float pinchAcc = 1f;
    boolean dark;
    PeakData.Peak selected;
    PeakMapView.Pick listener;

    PeakTileMap(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        scale = Math.max(1f, d / 1.5f);
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                cx += dx;
                cy += dy;
                invalidate();
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                tap(e.getX(), e.getY());
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                zoomBy(1, e.getX(), e.getY());
                return true;
            }
        });
        pinch = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector g) {
                pinchAcc *= g.getScaleFactor();
                if (pinchAcc > 1.6f) {
                    pinchAcc = 1f;
                    zoomBy(1, g.getFocusX(), g.getFocusY());
                } else if (pinchAcc < 0.62f) {
                    pinchAcc = 1f;
                    zoomBy(-1, g.getFocusX(), g.getFocusY());
                }
                return true;
            }
        });
    }

    // ------------------------------------------------------------------ coordinates

    private double world(int zoom) {
        return 256.0 * scale * Math.pow(2, zoom);
    }

    private double wx(double lon, int zoom) {
        return (lon + 180.0) / 360.0 * world(zoom);
    }

    private double wy(double lat, int zoom) {
        double r = Math.toRadians(lat);
        return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0 * world(zoom);
    }

    private double metresPerPixel(int zoom) {
        return 156543.03392 * Math.cos(Math.toRadians(PeakData.myLat)) / Math.pow(2, zoom) / scale;
    }

    /** The zoom at which the chosen range fits the short side of the view. */
    void fitRange() {
        int w = Math.min(getWidth(), getHeight());
        int best = 6;
        for (int zz = 6; zz <= 14; zz++) {
            if (metresPerPixel(zz) * w >= PeakData.km * 2000.0 * 0.92) {
                best = zz;
            }
        }
        z = best;
        centerOnMe();
    }

    void centerOnMe() {
        if (PeakData.have) {
            cx = wx(PeakData.myLon, z);
            cy = wy(PeakData.myLat, z);
            placed = true;
        }
        invalidate();
    }

    void zoomBy(int dz, float fx, float fy) {
        int nz = Math.max(5, Math.min(15, z + dz));
        if (nz == z) {
            return;
        }
        double k = Math.pow(2, nz - z);
        // keep the point under the fingers where it is
        double ox = fx - getWidth() / 2.0;
        double oy = fy - getHeight() / 2.0;
        cx = (cx + ox) * k - ox;
        cy = (cy + oy) * k - oy;
        z = nz;
        invalidate();
    }

    void zoomBy(int dz) {
        zoomBy(dz, getWidth() / 2f, getHeight() / 2f);
    }

    // ------------------------------------------------------------------ tiles

    private void tile(final int tz, final int tx, final int ty, Canvas cv, float left, float top, float size) {
        int max = 1 << tz;
        if (ty < 0 || ty >= max) {
            return;
        }
        final int txw = ((tx % max) + max) % max;
        final String key = tz + "/" + txw + "/" + ty;
        Bitmap b = cache.get(key);
        if (b != null) {
            cv.drawBitmap(b, null, new RectF(left, top, left + size, top + size), tileP);
            return;
        }
        // while the real tile loads, show the bigger one from one zoom level up (blurry but not empty)
        if (tz > 5) {
            Bitmap parent = cache.get((tz - 1) + "/" + (txw / 2) + "/" + (ty / 2));
            if (parent != null) {
                int hx = (txw % 2) * 128;
                int hy = (ty % 2) * 128;
                cv.drawBitmap(parent, new android.graphics.Rect(hx, hy, hx + 128, hy + 128),
                        new RectF(left, top, left + size, top + size), tileP);
            }
        }
        synchronized (loading) {
            if (!loading.add(key)) {
                return;
            }
        }
        pool.execute(() -> {
            byte[] data = Http.bytes("https://tile.openstreetmap.org/" + key + ".png");
            Bitmap bm = data == null ? null : BitmapFactory.decodeByteArray(data, 0, data.length);
            if (bm != null) {
                cache.put(key, bm);
            }
            synchronized (loading) {
                loading.remove(key);
            }
            postInvalidate();
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (!placed || ow == 0) {
            fitRange();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        pool.shutdownNow();
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ drawing

    private float sx(double lon) {
        return (float) (wx(lon, z) - cx + getWidth() / 2.0);
    }

    private float sy(double lat) {
        return (float) (wy(lat, z) - cy + getHeight() / 2.0);
    }

    @Override
    protected void onDraw(Canvas cv) {
        try {
            paint(cv);
        } catch (RuntimeException e) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(12 * d);
            cv.drawText("Could not draw: " + e.getClass().getSimpleName(), 12 * d, 40 * d, p);
        }
    }

    private void paint(Canvas cv) {
        int w = getWidth();
        int h = getHeight();
        if (!placed && PeakData.have) {
            fitRange();
        }
        cv.drawColor(dark ? 0xFF1B1D24 : 0xFFE8E4DA);
        tileP.setColorFilter(dark ? new ColorMatrixColorFilter(new ColorMatrix(new float[] {
            -0.9f, 0, 0, 0, 235, 0, -0.9f, 0, 0, 235, 0, 0, -0.9f, 0, 245, 0, 0, 0, 1, 0})) : null);
        float ts = 256f * scale;
        int x0 = (int) Math.floor((cx - w / 2.0) / ts);
        int x1 = (int) Math.floor((cx + w / 2.0) / ts);
        int y0 = (int) Math.floor((cy - h / 2.0) / ts);
        int y1 = (int) Math.floor((cy + h / 2.0) / ts);
        for (int ty = y0; ty <= y1; ty++) {
            for (int tx = x0; tx <= x1; tx++) {
                tile(z, tx, ty, cv, (float) (tx * ts - cx + w / 2.0), (float) (ty * ts - cy + h / 2.0), ts);
            }
        }
        if (!PeakData.have) {
            return;
        }
        float mx = sx(PeakData.myLon);
        float my = sy(PeakData.myLat);
        float ppm = (float) (1.0 / metresPerPixel(z));

        // rings: every 10 km, the chosen range in the accent colour
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * d);
        p.setTextSize(10 * d);
        for (int km = 10; km <= PeakData.km; km += 10) {
            boolean edge = km == PeakData.km;
            p.setStyle(Paint.Style.STROKE);
            p.setColor(edge ? Theme.ACCENT : 0x77333333);
            if (edge) {
                p.setStrokeWidth(2.5f * d);
            } else {
                p.setStrokeWidth(1.2f * d);
            }
            cv.drawCircle(mx, my, km * 1000f * ppm, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF222222);
            cv.drawText(km + " km", mx + 4 * d, my - km * 1000f * ppm - 3 * d, p);
        }

        // peaks: the high ones get a name first, names never overlap
        hit.clear();
        hitPos.clear();
        List<PeakData.Peak> list;
        synchronized (PeakData.peaks) {
            list = new ArrayList<>(PeakData.peaks);
        }
        list.sort((a, b) -> b.ele - a.ele);
        List<RectF> used = new ArrayList<>();
        int named = 0;
        p.setTextSize(10.5f * d);
        for (PeakData.Peak pk : list) {
            if (pk.dist > PeakData.km * 1000.0) {
                continue;
            }
            float x = sx(pk.lon);
            float y = sy(pk.lat);
            if (x < -20 || y < -20 || x > w + 20 || y > h + 20) {
                continue;
            }
            boolean sel = pk == selected;
            float size = (pk.ele > 3500 ? 8 : pk.ele > 2500 ? 7 : 5.5f) * d;
            Path tri = new Path();
            tri.moveTo(x, y - size);
            tri.lineTo(x - size, y + size * 0.75f);
            tri.lineTo(x + size, y + size * 0.75f);
            tri.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(sel ? 0xFFFFFFFF : pk.ele > 3000 ? 0xFFD32F2F : 0xFFB3541E);
            cv.drawPath(tri, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(sel ? 0xFF000000 : 0xFFFFFFFF);
            cv.drawPath(tri, p);
            hit.add(pk);
            hitPos.add(new float[] {x, y});
            if (named < 60 || sel) {
                String t = pk.name + " " + pk.ele + " m";
                float tw = p.measureText(t);
                RectF r = new RectF(x + size + 2 * d, y - 8 * d, x + size + 8 * d + tw, y + 6 * d);
                boolean free = true;
                for (RectF u : used) {
                    if (RectF.intersects(u, r)) {
                        free = false;
                        break;
                    }
                }
                if (free || sel) {
                    used.add(r);
                    named++;
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xCCFFFFFF);
                    cv.drawRoundRect(r, 4 * d, 4 * d, p);
                    p.setColor(sel ? 0xFF000000 : 0xFF222222);
                    cv.drawText(t, r.left + 3 * d, y + 4 * d, p);
                }
            }
        }

        // you
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x553DDC97);
        cv.drawCircle(mx, my, 13 * d, p);
        p.setColor(0xFF1E8E5A);
        cv.drawCircle(mx, my, 6 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(2 * d);
        cv.drawCircle(mx, my, 6 * d, p);

        p.setStyle(Paint.Style.FILL);
        p.setTextSize(9 * d);
        p.setColor(0xCC000000);
        cv.drawText("© OpenStreetMap contributors", 6 * d, h - 6 * d, p);
    }

    private void tap(float x, float y) {
        PeakData.Peak best = null;
        float bd = 32 * d;
        for (int i = 0; i < hit.size(); i++) {
            float[] q = hitPos.get(i);
            float dd = (float) Math.hypot(q[0] - x, q[1] - y);
            if (dd < bd) {
                bd = dd;
                best = hit.get(i);
            }
        }
        selected = best;
        if (listener != null) {
            listener.picked(best);
        }
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        pinch.onTouchEvent(e);
        if (!pinch.isInProgress()) {
            gestures.onTouchEvent(e);
        }
        return true;
    }
}
