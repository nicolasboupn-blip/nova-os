package app.novaos;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Mountain peaks near you, from OpenStreetMap (through the Overpass service). Peaks are kept on the phone for the area
 * you looked at, so the widget and the viewer work again without internet. There is no terrain data: a peak is only
 * marked "maybe hidden" when a nearer peak in the same direction looks higher.
 */
final class PeakData {
    private PeakData() {}

    static final class Peak {
        String name;
        int ele;
        double lat;
        double lon;
        double dist;      // metres
        double bearing;   // degrees from north, clockwise
        double up;        // angle above (or below) the horizon in degrees
        double east;      // metres
        double north;     // metres
        boolean hidden;

        String compass() {
            String[] n = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            return n[(int) Math.round(bearing / 45.0) % 8];
        }

        String distText() {
            return dist >= 10000 ? Math.round(dist / 1000.0) + " km"
                    : String.format(Locale.ROOT, "%.1f km", dist / 1000.0);
        }
    }

    static final List<Peak> peaks = new ArrayList<>();
    static double myLat;
    static double myLon;
    static double gpsAlt;
    static boolean have;
    static int km = 40;

    // the main server is often overloaded, so two more public ones (listed on the OpenStreetMap wiki) are tried
    private static final String[] SERVERS = {"https://overpass.private.coffee/api/interpreter",
        "https://overpass-api.de/api/interpreter", "https://maps.mail.ru/osm/tools/overpass/api/interpreter"};

    /** What went wrong the last time, shown on screen so a failure can be understood. */
    static volatile String lastError = "";

    /** Ground height at your spot from a height map (much better than GPS height). NaN when not known. */
    static volatile double demAlt = Double.NaN;

    private static void fetchDem(double lat, double lon) {
        try {
            String r = Http.get("https://api.open-meteo.com/v1/elevation?latitude=" + lat + "&longitude=" + lon);
            if (r != null) {
                JSONArray a = new JSONObject(r).getJSONArray("elevation");
                if (a.length() > 0) {
                    demAlt = a.getDouble(0);
                    return;
                }
            }
        } catch (Exception ignored) {
            // the GPS height is used instead
        }
        demAlt = Double.NaN;
    }

    /** My height in metres: the one you typed, then the height map, otherwise the GPS height. */
    static double myAlt() {
        String m = Prefs.getString("pk_alt_manual", "").trim();
        if (!m.isEmpty()) {
            try {
                return Double.parseDouble(m);
            } catch (NumberFormatException ignored) {
                // use the GPS height
            }
        }
        if (!Double.isNaN(demAlt)) {
            return demAlt;
        }
        return gpsAlt;
    }

    static void setPosition(double lat, double lon, double alt, boolean hasAlt) {
        myLat = lat;
        myLon = lon;
        gpsAlt = hasAlt ? alt : gpsAlt;
        have = true;
        Prefs.putString("pk_pos", lat + "," + lon + "," + gpsAlt);
    }

    /** The last position, so the widget can draw without asking for it again. */
    static void restore() {
        if (have) {
            return;
        }
        String s = Prefs.getString("pk_pos", "");
        String[] p = s.split(",");
        if (p.length == 3) {
            try {
                myLat = Double.parseDouble(p[0]);
                myLon = Double.parseDouble(p[1]);
                gpsAlt = Double.parseDouble(p[2]);
                have = true;
            } catch (NumberFormatException ignored) {
                // no position yet
            }
        }
        km = Math.max(10, Math.min(80, Prefs.getInt("pk_km", 40)));
    }

    static void setKm(int v) {
        km = v;
        Prefs.putInt("pk_km", v);
    }

    private static File cacheFile(Context c) {
        return new File(c.getFilesDir(), "peaks.cache");
    }

    static double distance(double la1, double lo1, double la2, double lo2) {
        double r = 6371000.0;
        double p1 = Math.toRadians(la1);
        double p2 = Math.toRadians(la2);
        double dp = p2 - p1;
        double dl = Math.toRadians(lo2 - lo1);
        double a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
        return 2 * r * Math.asin(Math.min(1.0, Math.sqrt(a)));
    }

    static double bearing(double la1, double lo1, double la2, double lo2) {
        double p1 = Math.toRadians(la1);
        double p2 = Math.toRadians(la2);
        double dl = Math.toRadians(lo2 - lo1);
        double y = Math.sin(dl) * Math.cos(p2);
        double x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    /** Fills distance, direction and the angle above the horizon for every peak, then marks the maybe-hidden ones. */
    static void compute(List<Peak> list) {
        double alt = myAlt();
        for (Peak p : list) {
            p.dist = distance(myLat, myLon, p.lat, p.lon);
            p.bearing = bearing(myLat, myLon, p.lat, p.lon);
            double rad = Math.toRadians(p.bearing);
            p.east = p.dist * Math.sin(rad);
            p.north = p.dist * Math.cos(rad);
            // the earth curves away below the line of sight, light bends a little back: 0.87 of the drop
            double drop = 0.87 * p.dist * p.dist / (2 * 6371000.0);
            p.up = Math.toDegrees(Math.atan2(p.ele - alt - drop, Math.max(1.0, p.dist)));
            p.hidden = false;
        }
        Collections.sort(list, (a, b) -> Double.compare(a.dist, b.dist));
        for (int i = 0; i < list.size(); i++) {
            Peak a = list.get(i);
            for (int j = 0; j < i; j++) {
                Peak b = list.get(j);
                double d = Math.abs(a.bearing - b.bearing);
                if (d > 180) {
                    d = 360 - d;
                }
                if (d < 1.0 && b.up > a.up + 0.15) {
                    a.hidden = true;
                    break;
                }
            }
        }
    }

    interface Done {
        void done(List<Peak> list, String error);
    }

    /** Gets the peaks around the position (from the phone's copy when it covers the area), then calls back on the main thread. */
    static void load(final Context c, final double lat, final double lon, final int radiusKm, final Done cb) {
        final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
        new Thread(() -> {
            if (Prefs.getString("pk_alt_manual", "").trim().isEmpty()) {
                fetchDem(lat, lon);
            }
            List<Peak> list = readCache(c, lat, lon, radiusKm);
            String err = null;
            if (list == null) {
                int used = radiusKm;
                list = fetch(lat, lon, used);
                if (list == null && radiusKm > 15) {
                    used = Math.max(10, radiusKm / 2); // a smaller area is a lighter question for a busy server
                    list = fetch(lat, lon, used);
                }
                if (list == null) {
                    String osmWhy = lastError;
                    list = fetchWikidata(lat, lon, Math.min(used, 50));
                    if (list == null) {
                        lastError = osmWhy + "  " + lastError;
                    }
                }
                if (list == null) {
                    err = "Could not load peaks. " + lastError;
                } else {
                    writeCache(c, lat, lon, used, list);
                }
            }
            final List<Peak> out = list;
            final String e = err;
            if (out != null) {
                compute(out);
            }
            ui.post(() -> {
                if (out != null) {
                    synchronized (peaks) {
                        peaks.clear();
                        peaks.addAll(out);
                    }
                }
                cb.done(out, e);
            });
        }, "nova-peaks").start();
    }

    /** Only reads what is already on the phone. */
    static void loadCached(final Context c, final Done cb) {
        final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
        new Thread(() -> {
            List<Peak> list = have ? readCache(c, myLat, myLon, 5) : null;
            if (list != null) {
                compute(list);
            }
            final List<Peak> out = list;
            ui.post(() -> {
                if (out != null) {
                    synchronized (peaks) {
                        peaks.clear();
                        peaks.addAll(out);
                    }
                }
                cb.done(out, out == null ? "no peaks saved yet" : null);
            });
        }, "nova-peaks-cache").start();
    }

    private static List<Peak> readCache(Context c, double lat, double lon, int radiusKm) {
        File f = cacheFile(c);
        if (!f.exists()) {
            return null;
        }
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String head = r.readLine();
            if (head == null) {
                return null;
            }
            String[] h = head.split(" ");
            double clat = Double.parseDouble(h[0]);
            double clon = Double.parseDouble(h[1]);
            double ckm = Double.parseDouble(h[2]);
            double off = distance(lat, lon, clat, clon) / 1000.0;
            if (off + radiusKm > ckm) {
                return null; // the saved area does not cover what you want to see
            }
            List<Peak> out = new ArrayList<>();
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t");
                if (p.length < 4) {
                    continue;
                }
                Peak k = new Peak();
                k.name = p[0];
                k.ele = Integer.parseInt(p[1]);
                k.lat = Double.parseDouble(p[2]);
                k.lon = Double.parseDouble(p[3]);
                out.add(k);
            }
            return out.isEmpty() ? null : out;
        } catch (Exception e) {
            return null;
        }
    }

    private static void writeCache(Context c, double lat, double lon, int radiusKm, List<Peak> list) {
        try (FileWriter w = new FileWriter(cacheFile(c))) {
            w.write(lat + " " + lon + " " + radiusKm + "\n");
            for (Peak p : list) {
                w.write(p.name.replace('\t', ' ').replace('\n', ' ') + "\t" + p.ele + "\t" + p.lat + "\t" + p.lon + "\n");
            }
        } catch (Exception ignored) {
            // the copy is only a speed-up
        }
    }

    private static List<Peak> fetch(double lat, double lon, int radiusKm) {
        StringBuilder why = new StringBuilder();
        String q = "[out:json][timeout:60];node[\"natural\"=\"peak\"][\"name\"][\"ele\"](around:" + (radiusKm * 1000) + ","
                + lat + "," + lon + ");out;";
        for (String server : SERVERS) {
            String host = server.replace("https://", "");
            host = host.substring(0, host.indexOf('/'));
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(server + "?data=" + URLEncoder.encode(q, "UTF-8")).openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(70000);
                c.setRequestProperty("User-Agent", "NOVA-launcher/" + Theme.OS_VERSION + " (peakfinder; Android)");
                c.setRequestProperty("Accept", "application/json");
                int code = c.getResponseCode();
                if (code != 200) {
                    why.append(host).append(": HTTP ").append(code).append("  ");
                    continue;
                }
                InputStream in = c.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                }
                JSONObject root = new JSONObject(bo.toString("UTF-8"));
                JSONArray els = root.getJSONArray("elements");
                List<Peak> out = new ArrayList<>();
                for (int i = 0; i < els.length(); i++) {
                    JSONObject e = els.getJSONObject(i);
                    JSONObject t = e.optJSONObject("tags");
                    if (t == null || !e.has("lat") || !e.has("lon")) {
                        continue;
                    }
                    int ele = parseEle(t.optString("ele", ""));
                    String name = t.optString("name", "").trim();
                    if (ele <= 0 || name.isEmpty()) {
                        continue;
                    }
                    Peak p = new Peak();
                    p.name = name;
                    p.ele = ele;
                    p.lat = e.getDouble("lat");
                    p.lon = e.getDouble("lon");
                    out.add(p);
                }
                String remark = root.optString("remark", "");
                if (out.isEmpty() || !remark.isEmpty() && out.size() < 3) {
                    // a busy server answers "ok" with an empty list and a remark: not a real answer
                    why.append(host).append(": ").append(remark.isEmpty() ? "no peaks in the answer" : remark).append("  ");
                    continue;
                }
                lastError = "";
                return out;
            } catch (java.net.UnknownHostException e) {
                why.append(host).append(": no internet  ");
            } catch (java.net.SocketTimeoutException e) {
                why.append(host).append(": too slow  ");
            } catch (Exception e) {
                why.append(host).append(": ").append(e.getClass().getSimpleName()).append("  ");
            } finally {
                if (c != null) {
                    c.disconnect();
                }
            }
        }
        lastError = why.toString().trim();
        return null;
    }

    /** Second source when the OpenStreetMap servers are busy: mountains with a height on Wikidata. */
    private static List<Peak> fetchWikidata(double lat, double lon, int radiusKm) {
        String q = "SELECT ?itemLabel ?coord ?ele WHERE { SERVICE wikibase:around { ?item wdt:P625 ?coord . "
                + "bd:serviceParam wikibase:center \"Point(" + lon + " " + lat + ")\"^^geo:wktLiteral . "
                + "bd:serviceParam wikibase:radius \"" + radiusKm + "\" . } "
                + "?item wdt:P2044 ?ele . ?item wdt:P31/wdt:P279* wd:Q8502 . "
                + "SERVICE wikibase:label { bd:serviceParam wikibase:language \"en,de,fr,it\". } }";
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://query.wikidata.org/sparql?format=json&query="
                    + URLEncoder.encode(q, "UTF-8")).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent", "NOVA-launcher/" + Theme.OS_VERSION + " (peakfinder; Android)");
            c.setRequestProperty("Accept", "application/sparql-results+json");
            int code = c.getResponseCode();
            if (code != 200) {
                lastError = "wikidata: HTTP " + code;
                return null;
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            JSONArray rows = new JSONObject(bo.toString("UTF-8")).getJSONObject("results").getJSONArray("bindings");
            List<Peak> out = new ArrayList<>();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject r = rows.getJSONObject(i);
                String name = r.getJSONObject("itemLabel").getString("value").trim();
                String wkt = r.getJSONObject("coord").getString("value"); // Point(lon lat)
                int ele = parseEle(r.getJSONObject("ele").getString("value"));
                int a = wkt.indexOf('(');
                String[] ll = wkt.substring(a + 1, wkt.indexOf(')')).trim().split(" ");
                if (ele <= 0 || name.isEmpty() || name.matches("Q\\d+") || ll.length < 2) {
                    continue;
                }
                Peak p = new Peak();
                p.name = name;
                p.ele = ele;
                p.lon = Double.parseDouble(ll[0]);
                p.lat = Double.parseDouble(ll[1]);
                out.add(p);
            }
            if (out.isEmpty()) {
                lastError = "wikidata: no peaks in the answer";
                return null;
            }
            return out;
        } catch (java.net.UnknownHostException e) {
            lastError = "wikidata: no internet";
        } catch (Exception e) {
            lastError = "wikidata: " + e.getClass().getSimpleName();
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
        return null;
    }

    private static int parseEle(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.replace(',', '.').toCharArray()) {
            if (Character.isDigit(ch) || ch == '.') {
                sb.append(ch);
            } else if (sb.length() > 0) {
                break;
            }
        }
        try {
            return (int) Math.round(Double.parseDouble(sb.toString()));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
