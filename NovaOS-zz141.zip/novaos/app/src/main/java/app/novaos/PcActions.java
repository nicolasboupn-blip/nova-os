package app.novaos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Every one-tap action of PC REMOTE, sorted into categories. A script is run by PcHid.run(): steps split by "|",
 * K: keys, T: type, W: wait ms, C: media key (hex), M: click, N: move dx,dy,times, S: scroll amount,times,
 * H: hold left ms. {date} and {time} in T: are filled in from the phone. A label starting with "!" asks first.
 */
final class PcActions {
    private PcActions() {
    }

    static final class Cat {
        final String icon;
        final String name;
        final List<String[]> items = new ArrayList<>();

        Cat(String icon, String name) {
            this.icon = icon;
            this.name = name;
        }

        void add(String label, String script) {
            items.add(new String[] {label, script});
        }
    }

    static final List<Cat> CATS = new ArrayList<>();

    static String run(String what) {
        return "K:WIN+R|W:550|T:" + what + "|W:150|K:ENTER";
    }

    static String app(String name) {
        return "K:WIN|W:700|T:" + name.toLowerCase(Locale.ROOT) + "|W:1100|K:ENTER";
    }

    static String power(String key) {
        return "K:WIN+X|W:600|K:U|W:500|K:" + key;
    }

    private static String times(String step, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) {
                b.append('|');
            }
            b.append(step);
        }
        return b.toString();
    }

    /** "Label=SCRIPT;Label=SCRIPT" where SCRIPT without a "X:" step prefix means keys. */
    private static void keys(Cat c, String list) {
        for (String e : list.split(";")) {
            int eq = e.lastIndexOf('=');
            if (eq <= 0) {
                continue;
            }
            String s = e.substring(eq + 1).trim();
            c.add(e.substring(0, eq).trim(), s.length() > 1 && s.charAt(1) == ':' ? s : "K:" + s);
        }
    }

    private static void apps(Cat c, String list) {
        for (String n : list.split(",")) {
            n = n.trim();
            if (!n.isEmpty()) {
                c.add(n, app(n));
            }
        }
    }

    /** "Label=command" through the Run box. */
    private static void runs(Cat c, String list) {
        for (String e : list.split(";")) {
            int eq = e.indexOf('=');
            if (eq > 0) {
                c.add(e.substring(0, eq).trim(), run(e.substring(eq + 1).trim()));
            }
        }
    }

    static {
        Cat apps = new Cat("📱", "Apps");
        apps(apps, "Chrome,Edge,Firefox,Opera GX,Brave,Spotify,Discord,Steam,Epic Games Launcher,EA app,Ubisoft Connect,"
                + "Battle.net,Riot Client,Xbox,NVIDIA app,NitroSense,Acer Care Center,OBS Studio,VLC media player,WhatsApp,"
                + "Telegram,Signal,Teams,Zoom,Outlook,Word,Excel,PowerPoint,OneNote,OneDrive,Notepad,Notepad++,"
                + "Visual Studio Code,Visual Studio,Android Studio,Git Bash,Python,Terminal,PowerShell,Command Prompt,"
                + "Calculator,Clock,Calendar,Maps,Weather,Photos,Camera,Paint,Snipping Tool,Sticky Notes,Sound Recorder,"
                + "Media Player,Microsoft Store,Settings,File Explorer,Control Panel,Task Manager,Registry Editor,"
                + "Device Manager,Disk Management,Character Map,Magnifier,Narrator,On-Screen Keyboard,Quick Assist,"
                + "Remote Desktop Connection,Phone Link,Copilot,Clipchamp,Solitaire,Minecraft,Roblox,War Thunder,"
                + "Arma Reforger,Arma 3,World of Tanks,Counter-Strike 2,Valorant,League of Legends,Rocket League,"
                + "Grand Theft Auto V,EA SPORTS FC,Call of Duty,Apex Legends,Rainbow Six Siege,Fortnite,Fall Guys,Among Us,"
                + "Terraria,Stardew Valley,Blender,GIMP,Photoshop,Premiere Pro,After Effects,DaVinci Resolve,Audacity,"
                + "CapCut,Canva,Figma,7-Zip,WinRAR,AnyDesk,TeamViewer,Malwarebytes,CCleaner,CPU-Z,HWMonitor,"
                + "MSI Afterburner,CrystalDiskInfo,Logitech G HUB,Razer Synapse,SteelSeries GG,iCUE,Wallpaper Engine,"
                + "Rainmeter,Everything,PowerToys,Windows Security,Windows Backup,Get Help,Tips,Feedback Hub,Game Bar,"
                + "NVIDIA Control Panel,Realtek Audio Console,Dolby Access,Prime Video,Netflix,Disney+,Twitch,TikTok,"
                + "Instagram,iTunes,Apple Music,WordPad,Mail");
        apps.add("Task Manager (fast)", "K:CTRL+SHIFT+ESC");
        CATS.add(apps);

        Cat win = new Cat("🪟", "Windows");
        keys(win, "Start=WIN;Search=WIN+S;Run box=WIN+R;Show desktop=WIN+D;Task view=WIN+TAB;Switch app=ALT+TAB;"
                + "Close app=ALT+F4;Minimize=WIN+DOWN;Maximize=WIN+UP;Snap left=WIN+LEFT;Snap right=WIN+RIGHT;"
                + "Snap layouts=WIN+Z;Next desktop=CTRL+WIN+RIGHT;Prev desktop=CTRL+WIN+LEFT;New desktop=CTRL+WIN+D;"
                + "Close desktop=CTRL+WIN+F4;Screenshot area=WIN+SHIFT+S;Screenshot all=WIN+PRTSC;Notifications=WIN+N;"
                + "Quick settings=WIN+A;Clipboard history=WIN+V;Emoji panel=WIN+DOT;Widgets=WIN+W;Project screen=WIN+P;"
                + "Zoom in=WIN+KPPLUS;Zoom out=WIN+KPMINUS;Zoom off=WIN+ESC;Quick link menu=WIN+X;Lock=WIN+L;"
                + "Taskbar app 1=WIN+1;Taskbar app 2=WIN+2;Taskbar app 3=WIN+3;Taskbar app 4=WIN+4;Taskbar app 5=WIN+5;"
                + "Taskbar app 6=WIN+6;Taskbar app 7=WIN+7;Taskbar app 8=WIN+8;Taskbar app 9=WIN+9;Focus taskbar=WIN+T;"
                + "Focus tray=WIN+B;Minimize all=WIN+M;Restore all=WIN+SHIFT+M;Minimize others=WIN+HOME;"
                + "Peek desktop=WIN+COMMA;Dictation=WIN+H;Cast=WIN+K;Accessibility=WIN+U;On-screen keyboard=CTRL+WIN+O;"
                + "Narrator=CTRL+WIN+ENTER;Color filter=CTRL+WIN+C;Mic mute in call=WIN+ALT+K;"
                + "Move to left screen=WIN+SHIFT+LEFT;Move to right screen=WIN+SHIFT+RIGHT;Stretch tall=WIN+SHIFT+UP;"
                + "Fix graphics=CTRL+SHIFT+WIN+B;Date & time flyout=WIN+ALT+D;Quick Assist=CTRL+WIN+Q;HDR on/off=WIN+ALT+B;"
                + "Feedback Hub=WIN+F;Copilot=WIN+C;Keyboard layout=WIN+SPACE;Lock rotation=WIN+O;Window menu=ALT+SPACE;"
                + "Cycle windows=ALT+ESC;About PC=WIN+PAUSE;File Explorer=WIN+E;Settings=WIN+I;Game Bar=WIN+G;"
                + "!Ctrl+Alt+Del=CTRL+ALT+DEL");
        CATS.add(win);

        Cat media = new Cat("🎵", "Media & volume");
        keys(media, "Vol +=C:E9;Vol −=C:EA;Mute=C:E2;Play / pause=C:CD;Next track=C:B5;Previous track=C:B6;"
                + "Stop=C:B7;Brightness +=C:6F;Brightness −=C:70;Sound output=WIN+CTRL+V");
        media.add("Vol +10%", times("C:E9", 5));
        media.add("Vol −10%", times("C:EA", 5));
        for (int v = 0; v <= 100; v += 20) {
            media.add("Volume " + v + "%", times("C:EA", 50) + (v > 0 ? "|" + times("C:E9", v / 2) : ""));
        }
        media.add("Volume mixer", run("sndvol"));
        media.add("Sound settings", run("ms-settings:sound"));
        media.add("App volumes", run("ms-settings:apps-volume"));
        media.add("Classic sound panel", run("mmsys.cpl"));
        CATS.add(media);

        Cat set = new Cat("⚙", "Settings pages");
        String[] pages = {"Home=", "About=about", "Activation=activation", "Apps=appsfeatures", "Default apps=defaultapps",
            "Startup apps=startupapps", "Optional features=optionalfeatures", "Apps for websites=appsforwebsites",
            "Bluetooth=bluetooth", "Devices=devices", "Printers=printers", "Mouse=mousetouchpad", "Pen=pen",
            "AutoPlay=autoplay", "USB=usb", "Phone=mobile-devices", "Display=display", "Advanced display=display-advanced",
            "Graphics=display-advancedgraphics", "Night light=nightlight", "Sound=sound", "Sound devices=sound-devices",
            "Notifications=notifications", "Focus=quiethours", "Power & battery=batterysaver", "Power & sleep=powersleep",
            "Storage=storagesense", "Multitasking=multitasking", "Clipboard=clipboard", "Remote desktop=remotedesktop",
            "Recovery=recovery", "Troubleshoot=troubleshoot", "Network=network-status", "Wi-Fi=network-wifi",
            "Wi-Fi networks=network-wifisettings", "Ethernet=network-ethernet", "VPN=network-vpn",
            "Hotspot=network-mobilehotspot", "Airplane mode=network-airplanemode", "Proxy=network-proxy",
            "Personalize=personalization", "Background=personalization-background", "Colors & dark mode=colors",
            "Themes=themes", "Lock screen=lockscreen", "Start menu=personalization-start",
            "Start folders=personalization-start-places", "Taskbar=taskbar", "Fonts=fonts",
            "Touch keyboard=personalization-touchkeyboard", "Dynamic lighting=personalization-lighting",
            "Your info=yourinfo", "Sign-in options=signinoptions", "Email & accounts=emailandaccounts",
            "Family=family-group", "Other users=otherusers", "Backup=backup", "Work or school=workplace",
            "Date & time=dateandtime", "Language & region=regionlanguage", "Region format=regionformatting",
            "Typing=typing", "Keyboard=keyboard", "Speech=speech", "Gaming=gaming-gamebar", "Captures=gaming-gamedvr",
            "Game mode=gaming-gamemode", "Accessibility text size=easeofaccess-display",
            "Visual effects=easeofaccess-visualeffects", "Mouse pointer=easeofaccess-mousepointer",
            "Text cursor=easeofaccess-cursor", "Magnifier=easeofaccess-magnifier", "Color filters=easeofaccess-colorfilter",
            "Contrast themes=easeofaccess-highcontrast", "Narrator=easeofaccess-narrator", "Audio=easeofaccess-audio",
            "Captions=easeofaccess-closedcaptioning", "Speech access=easeofaccess-speechrecognition",
            "Keyboard access=easeofaccess-keyboard", "Privacy=privacy", "Location=privacy-location",
            "Camera access=privacy-webcam", "Microphone access=privacy-microphone", "Activity history=privacy-activityhistory",
            "Diagnostics=privacy-feedback", "General privacy=privacy-general", "File system access=privacy-broadfilesystemaccess",
            "Find my device=findmydevice", "Windows Security=windowsdefender", "Windows Update=windowsupdate",
            "Update history=windowsupdate-history", "Update options=windowsupdate-options",
            "Delivery optimization=delivery-optimization", "Insider=windowsinsider", "For developers=developers",
            "Energy tips=energyrecommendations", "Mobile devices=crossdevice"};
        for (String e : pages) {
            int eq = e.indexOf('=');
            String page = e.substring(eq + 1);
            set.add(e.substring(0, eq), page.isEmpty() ? "K:WIN+I" : run("ms-settings:" + page));
        }
        CATS.add(set);

        Cat tools = new Cat("🧰", "System tools");
        runs(tools, "Device Manager=devmgmt.msc;Disk Management=diskmgmt.msc;Services=services.msc;"
                + "Task Scheduler=taskschd.msc;Event Viewer=eventvwr.msc;Computer Management=compmgmt.msc;"
                + "Group Policy (Pro)=gpedit.msc;Users & groups (Pro)=lusrmgr.msc;Certificates=certmgr.msc;"
                + "Performance Monitor=perfmon;Resource Monitor=resmon;Registry Editor=regedit;System Configuration=msconfig;"
                + "System Information=msinfo32;DirectX Diagnostic=dxdiag;Disk Cleanup=cleanmgr;Defragment=dfrgui;"
                + "Memory Diagnostic=mdsched;Malware removal tool=mrt;Windows version=winver;Remote Desktop=mstsc;"
                + "On-screen keyboard=osk;Magnifier=magnify;Narrator=narrator;Character Map=charmap;Volume Mixer=sndvol;"
                + "Sound (classic)=mmsys.cpl;Network adapters=ncpa.cpl;Programs & features=appwiz.cpl;"
                + "Power options=powercfg.cpl;System properties=sysdm.cpl;Advanced system=SystemPropertiesAdvanced;"
                + "Performance options=SystemPropertiesPerformance;Mouse (classic)=main.cpl;Firewall=firewall.cpl;"
                + "Firewall advanced=wf.msc;Internet options=inetcpl.cpl;Date & time (classic)=timedate.cpl;"
                + "Region (classic)=intl.cpl;Game controllers=joy.cpl;Printers (classic)=control printers;"
                + "Fonts (classic)=control fonts;Keyboard (classic)=control keyboard;Windows Tools=control admintools;"
                + "User accounts=netplwiz;System Restore=rstrui;Color management=colorcpl;Security & maintenance=wscui.cpl;"
                + "Bluetooth file transfer=fsquirt;Credential Manager=control /name Microsoft.CredentialManager;"
                + "Control Panel=control;Windows Terminal=wt;Command Prompt=cmd;PowerShell=powershell;Notepad=notepad;"
                + "Paint=mspaint;Calculator=calc;Task Manager=taskmgr;All apps=shell:AppsFolder;"
                + "God mode=explorer shell:::{ED7BA470-8E54-465E-825C-99712043E01C}");
        CATS.add(tools);

        Cat cmd = new Cat("💻", "Commands");
        runs(cmd, "My IP & network=cmd /k ipconfig /all;Ping Google=cmd /k ping google.com;Ping nonstop=cmd /k ping 8.8.8.8 -t;"
                + "Flush DNS=cmd /k ipconfig /flushdns;System info=cmd /k systeminfo;Running programs=cmd /k tasklist;"
                + "Open connections=cmd /k netstat -an;MAC address=cmd /k getmac;DNS lookup=cmd /k nslookup google.com;"
                + "Trace route=cmd /k tracert google.com;Saved Wi-Fi=cmd /k netsh wlan show profiles;"
                + "Wi-Fi info=cmd /k netsh wlan show interfaces;Battery report=cmd /k powercfg /batteryreport;"
                + "Sleep blockers=cmd /k powercfg /requests;App updates list=cmd /k winget upgrade;"
                + "!Update all apps=cmd /k winget upgrade --all;Weather Zurich=cmd /k curl wttr.in/Zurich;"
                + "Disk space=cmd /k wmic logicaldisk get name,freespace,size;Who am I=cmd /k whoami;"
                + "Windows build=cmd /k ver;Environment=cmd /k set;Drivers=cmd /k driverquery;"
                + "Startup items=cmd /k wmic startup get caption,command;!Empty recycle bin=powershell -c Clear-RecycleBin -Force");
        CATS.add(cmd);

        Cat power = new Cat("⚡", "Power");
        keys(power, "Lock=WIN+L;!Sleep=" + power("S") + ";!Sign out=" + power("I") + ";!Restart=" + power("R")
                + ";!Shut down=" + power("U"));
        runs(power, "!Shut down in 10 min=shutdown /s /t 600;!Shut down in 30 min=shutdown /s /t 1800;"
                + "!Shut down in 1 h=shutdown /s /t 3600;!Shut down in 2 h=shutdown /s /t 7200;Cancel shut down timer=shutdown /a;"
                + "!Restart now=shutdown /r /t 0;!Hibernate=shutdown /h;!Sign out now=shutdown /l;"
                + "Power options=powercfg.cpl;Battery settings=ms-settings:batterysaver;Battery report=cmd /k powercfg /batteryreport");
        CATS.add(power);

        Cat files = new Cat("📁", "Folders & files");
        runs(files, "Downloads=shell:downloads;Documents=shell:personal;Desktop=shell:desktop;Pictures=shell:my pictures;"
                + "Music=shell:my music;Videos=shell:my video;This PC=shell:mycomputerfolder;Recycle bin=shell:recyclebinfolder;"
                + "Screenshots=shell:screenshots;Camera roll=shell:camera roll;Saved games=shell:saved games;"
                + "OneDrive=shell:onedrive;User folder=shell:profile;Public=shell:public;Startup (me)=shell:startup;"
                + "Startup (all)=shell:common startup;AppData=%appdata%;Local AppData=%localappdata%;Temp files=%temp%;"
                + "Program Files=shell:programfiles;Program Files x86=shell:programfilesx86;Windows folder=shell:windows;"
                + "System32=shell:system;Fonts folder=shell:fonts;Send To=shell:sendto;Recent files=shell:recent;"
                + "Start menu=shell:start menu;Programs=shell:programs;Templates=shell:templates;Links=shell:links;"
                + "Searches=shell:searches;Control Panel items=shell:controlpanelfolder;Printers=shell:printersfolder;"
                + "Network connections=shell:connectionsfolder;All apps=shell:appsfolder");
        keys(files, "Explorer=WIN+E;New folder=CTRL+SHIFT+N;Rename=F2;Delete=DEL;!Delete forever=SHIFT+DEL;Copy=CTRL+C;"
                + "Cut=CTRL+X;Paste=CTRL+V;Select all=CTRL+A;Undo=CTRL+Z;Redo=CTRL+Y;Refresh=F5;Properties=ALT+ENTER;"
                + "Back=ALT+LEFT;Forward=ALT+RIGHT;Up a folder=ALT+UP;Address bar=ALT+D;Search here=CTRL+E;"
                + "New window=CTRL+N;New tab=CTRL+T;Close tab=CTRL+W;Preview pane=ALT+P;Details pane=ALT+SHIFT+P;"
                + "Extra large icons=CTRL+SHIFT+1;Large icons=CTRL+SHIFT+2;Medium icons=CTRL+SHIFT+3;Small icons=CTRL+SHIFT+4;"
                + "List view=CTRL+SHIFT+5;Details view=CTRL+SHIFT+6;Tiles view=CTRL+SHIFT+7;Content view=CTRL+SHIFT+8");
        CATS.add(files);

        Cat sites = new Cat("🌍", "Websites");
        String[] web = {"YouTube=youtube.com", "Twitch=twitch.tv", "Reddit=reddit.com", "GitHub=github.com",
            "NOVA on GitHub=github.com/nicolasboupn-blip/nova-os", "ChatGPT=chatgpt.com", "Claude=claude.ai",
            "Gemini=gemini.google.com", "Gmail=mail.google.com", "Google Drive=drive.google.com", "Google Docs=docs.google.com",
            "Google Calendar=calendar.google.com", "Google Maps=maps.google.com", "Google Translate=translate.google.com",
            "DeepL=deepl.com", "Wikipedia=wikipedia.org", "Netflix=netflix.com", "Prime Video=primevideo.com",
            "Disney+=disneyplus.com", "Spotify web=open.spotify.com", "YouTube Music=music.youtube.com",
            "SoundCloud=soundcloud.com", "Instagram=instagram.com", "TikTok=tiktok.com", "X=x.com", "Facebook=facebook.com",
            "LinkedIn=linkedin.com", "Pinterest=pinterest.com", "Discord web=discord.com/app", "WhatsApp web=web.whatsapp.com",
            "Telegram web=web.telegram.org", "Outlook web=outlook.live.com", "Office=office.com", "OneDrive web=onedrive.live.com",
            "Amazon=amazon.de", "Digitec=digitec.ch", "Galaxus=galaxus.ch", "Ricardo=ricardo.ch", "Tutti=tutti.ch",
            "AliExpress=aliexpress.com", "eBay=ebay.de", "SBB=sbb.ch", "ZVV=zvv.ch", "MeteoSwiss=meteoswiss.admin.ch",
            "SRF=srf.ch", "20 Minuten=20min.ch", "Blick=blick.ch", "NZZ=nzz.ch", "watson=watson.ch", "Google=google.com",
            "Bing=bing.com", "DuckDuckGo=duckduckgo.com", "Steam store=store.steampowered.com",
            "Epic store=store.epicgames.com", "War Thunder=warthunder.com", "War Thunder wiki=wiki.warthunder.com",
            "Thunderskill=thunderskill.com", "StatShark=statshark.net", "Arma Reforger=reforger.armaplatform.com",
            "NVIDIA drivers=nvidia.com/drivers", "Acer support=acer.com/support", "Speedtest=speedtest.net", "Fast.com=fast.com",
            "Downdetector=downdetector.ch", "Canva=canva.com", "Figma=figma.com", "Photopea=photopea.com",
            "Remove background=remove.bg", "Chess.com=chess.com", "Lichess=lichess.org", "GeoGuessr=geoguessr.com",
            "Monkeytype=monkeytype.com", "Poki=poki.com", "CrazyGames=crazygames.com", "Time and date=timeanddate.com",
            "Duolingo=duolingo.com", "Quizlet=quizlet.com", "Khan Academy=khanacademy.org", "WolframAlpha=wolframalpha.com",
            "Desmos=desmos.com/calculator", "Stack Overflow=stackoverflow.com", "W3Schools=w3schools.com",
            "Android developers=developer.android.com", "Imgur=imgur.com", "WeTransfer=wetransfer.com",
            "VirusTotal=virustotal.com", "Have I been pwned=haveibeenpwned.com", "Internet Archive=archive.org",
            "Kick=kick.com", "Twitch tracker=twitchtracker.com", "Google Photos=photos.google.com", "Google Keep=keep.google.com"};
        for (String e : web) {
            int eq = e.indexOf('=');
            sites.add(e.substring(0, eq), run("https://" + e.substring(eq + 1)));
        }
        CATS.add(sites);

        Cat br = new Cat("🌐", "Browser");
        keys(br, "New tab=CTRL+T;Close tab=CTRL+W;Reopen tab=CTRL+SHIFT+T;Next tab=CTRL+TAB;Prev tab=CTRL+SHIFT+TAB;"
                + "Tab 1=CTRL+1;Tab 2=CTRL+2;Tab 3=CTRL+3;Tab 4=CTRL+4;Tab 5=CTRL+5;Last tab=CTRL+9;Reload=F5;"
                + "Hard reload=CTRL+F5;Back=ALT+LEFT;Forward=ALT+RIGHT;Address bar=CTRL+L;New window=CTRL+N;"
                + "Incognito=CTRL+SHIFT+N;Find=CTRL+F;Zoom +=CTRL+KPPLUS;Zoom −=CTRL+KPMINUS;Zoom 100%=CTRL+0;"
                + "Fullscreen=F11;Downloads=CTRL+J;History=CTRL+H;Bookmark page=CTRL+D;Bookmarks bar=CTRL+SHIFT+B;"
                + "Bookmark manager=CTRL+SHIFT+O;!Clear browsing data=CTRL+SHIFT+DEL;Browser task manager=SHIFT+ESC;"
                + "Dev tools=F12;Console=CTRL+SHIFT+J;Page source=CTRL+U;Print page=CTRL+P;Save page=CTRL+S;"
                + "Scroll down=SPACE;Scroll up=SHIFT+SPACE;Top=HOME;Bottom=END;Home page=ALT+HOME");
        br.add("Search Google…", "?K:CTRL+L|W:200|T:{ask}|K:ENTER");
        CATS.add(br);

        Cat yt = new Cat("▶", "YouTube & video");
        keys(yt, "Pause / play=K;Back 10 s=J;Forward 10 s=L;Back 5 s=LEFT;Forward 5 s=RIGHT;Fullscreen=F;Theater=T;"
                + "Mini player=I;Mute=M;Captions=C;Next video=SHIFT+N;Previous video=SHIFT+P;Start=HOME;End=END;"
                + "Jump to 50%=5;Volume up=UP;Volume down=DOWN;Faster=T:>;Slower=T:<;Next frame=T:.;Prev frame=T:,");
        CATS.add(yt);

        Cat sp = new Cat("🎧", "Spotify");
        keys(sp, "Play / pause=SPACE;Next=CTRL+RIGHT;Previous=CTRL+LEFT;Volume up=CTRL+UP;Volume down=CTRL+DOWN;"
                + "Search=CTRL+K;Search (old)=CTRL+L;Like song=ALT+SHIFT+B;Shuffle=CTRL+S;Repeat=CTRL+R;Back=ALT+LEFT;"
                + "Forward=ALT+RIGHT;Seek back=SHIFT+LEFT;Seek forward=SHIFT+RIGHT;Now playing=ALT+SHIFT+J");
        CATS.add(sp);

        Cat dc = new Cat("💬", "Discord & calls");
        keys(dc, "Discord quick switch=CTRL+K;Discord mute=CTRL+SHIFT+M;Discord deafen=CTRL+SHIFT+D;Mark read=ESC;"
                + "Upload file=CTRL+SHIFT+U;Emoji picker=CTRL+E;Next server=CTRL+ALT+DOWN;Prev server=CTRL+ALT+UP;"
                + "Next channel=ALT+DOWN;Prev channel=ALT+UP;Next unread=ALT+SHIFT+DOWN;Answer call=CTRL+ENTER;"
                + "Decline call=ESC;Teams mute=CTRL+SHIFT+M;Teams camera=CTRL+SHIFT+O;Teams raise hand=CTRL+SHIFT+K;"
                + "Teams hang up=CTRL+SHIFT+H;Zoom mute=ALT+A;Zoom video=ALT+V;Zoom share=ALT+S;Zoom leave=ALT+Q;"
                + "Mic mute (Windows)=WIN+ALT+K");
        CATS.add(dc);

        Cat game = new Cat("🎮", "Gaming");
        keys(game, "Game Bar=WIN+G;Clip last 30 s=WIN+ALT+G;Record on/off=WIN+ALT+R;Game screenshot=WIN+ALT+PRTSC;"
                + "NVIDIA overlay=ALT+Z;NVIDIA clip=ALT+F10;NVIDIA record=ALT+F9;NVIDIA screenshot=ALT+F1;"
                + "Steam overlay=SHIFT+TAB;Steam screenshot=F12;Esc=ESC;Enter=ENTER;Space=SPACE;Tab (score)=TAB;"
                + "Map (M)=M;Inventory (I)=I;Reload (R)=R;Use (E)=E;Crouch (C)=C;Fullscreen toggle=ALT+ENTER;"
                + "Alt+Tab out=ALT+TAB;Discord mute=CTRL+SHIFT+M;Discord deafen=CTRL+SHIFT+D");
        apps(game, "Steam,War Thunder,Arma Reforger,NitroSense,Xbox,Epic Games Launcher,Discord");
        game.add("Game mode settings", run("ms-settings:gaming-gamemode"));
        game.add("Graphics settings", run("ms-settings:display-advancedgraphics"));
        game.add("GG in chat", "K:ENTER|W:150|T:gg|K:ENTER");
        game.add("GG WP in chat", "K:ENTER|W:150|T:gg wp|K:ENTER");
        CATS.add(game);

        Cat text = new Cat("✍", "Text & Office");
        keys(text, "Bold=CTRL+B;Italic=CTRL+I;Underline=CTRL+U;Select all=CTRL+A;Copy=CTRL+C;Cut=CTRL+X;Paste=CTRL+V;"
                + "Paste plain=CTRL+SHIFT+V;Undo=CTRL+Z;Redo=CTRL+Y;Word left=CTRL+LEFT;Word right=CTRL+RIGHT;"
                + "Select word left=CTRL+SHIFT+LEFT;Select word right=CTRL+SHIFT+RIGHT;Delete word=CTRL+BKSP;"
                + "Line start=HOME;Line end=END;Top of doc=CTRL+HOME;End of doc=CTRL+END;Select to start=SHIFT+HOME;"
                + "Select to end=SHIFT+END;Find=CTRL+F;Replace=CTRL+H;Save=CTRL+S;Save as=F12;Print=CTRL+P;New=CTRL+N;"
                + "Open=CTRL+O;Close document=CTRL+W;Align left=CTRL+L;Center=CTRL+E;Align right=CTRL+R;Justify=CTRL+J;"
                + "Bullet list=CTRL+SHIFT+L;Heading 1=CTRL+ALT+1;Heading 2=CTRL+ALT+2;Heading 3=CTRL+ALT+3;"
                + "Normal text=CTRL+SHIFT+N;Page break=CTRL+ENTER;Spell check=F7;Word count=CTRL+SHIFT+G;"
                + "Insert link=CTRL+K;Excel new sheet=SHIFT+F11;Excel next sheet=CTRL+PGDN;Excel prev sheet=CTRL+PGUP;"
                + "Excel edit cell=F2;Excel fill down=CTRL+D;Excel format cells=CTRL+1;Excel filter=CTRL+SHIFT+L;"
                + "Excel table=CTRL+T;Excel select column=CTRL+SPACE;Excel select row=SHIFT+SPACE;Excel chart=ALT+F1;"
                + "Excel insert row=CTRL+SHIFT+KPPLUS;Excel delete row=CTRL+KPMINUS;Slideshow from start=F5;"
                + "Slideshow from here=SHIFT+F5;Next slide=RIGHT;Previous slide=LEFT;Black screen=B;End slideshow=ESC;"
                + "New slide=CTRL+M");
        text.add("Type today's date", "T:{date}");
        text.add("Type the time", "T:{time}");
        text.add("Type date + time", "T:{date} {time}");
        CATS.add(text);

        Cat code = new Cat("🧑‍💻", "VS Code");
        keys(code, "Command palette=CTRL+SHIFT+P;Quick open=CTRL+P;Toggle sidebar=CTRL+B;New file=CTRL+N;Save=CTRL+S;"
                + "Save all=CTRL+K|K:S;Go to line=CTRL+G;Find in files=CTRL+SHIFT+F;Extensions=CTRL+SHIFT+X;"
                + "Source control=CTRL+SHIFT+G;Explorer=CTRL+SHIFT+E;Run / debug=F5;Stop=SHIFT+F5;Format=SHIFT+ALT+F;"
                + "Rename symbol=F2;Go to definition=F12;Cursor below=CTRL+ALT+DOWN;Cursor above=CTRL+ALT+UP;"
                + "Move line up=ALT+UP;Move line down=ALT+DOWN;Copy line down=SHIFT+ALT+DOWN;Delete line=CTRL+SHIFT+K;"
                + "Close editor=CTRL+W;Reopen editor=CTRL+SHIFT+T;Zen mode=CTRL+K|K:Z;Problems=CTRL+SHIFT+M;"
                + "Next editor=CTRL+PGDN;Prev editor=CTRL+PGUP;Select next match=CTRL+D;Fold=CTRL+SHIFT+KPMINUS");
        CATS.add(code);

        Cat mouse = new Cat("🖱", "Mouse tricks");
        mouse.add("Double click", "M:L|W:40|M:L");
        mouse.add("Triple click", "M:L|W:40|M:L|W:40|M:L");
        mouse.add("Right click", "M:R");
        mouse.add("Middle click", "M:M");
        mouse.add("Hold left 1 s", "H:1000");
        mouse.add("Hold left 3 s", "H:3000");
        for (int n : new int[] {3, 10, 25}) {
            mouse.add("Scroll down " + n, "S:-1," + n);
            mouse.add("Scroll up " + n, "S:1," + n);
        }
        mouse.add("To top-left corner", "N:-127,-127,40");
        mouse.add("To top-right corner", "N:127,-127,40");
        mouse.add("To bottom-left corner", "N:-127,127,40");
        mouse.add("To bottom-right corner", "N:127,127,40");
        mouse.add("10 fast clicks", times("M:L|W:40", 10));
        mouse.add("50 fast clicks", times("M:L|W:35", 50));
        mouse.add("100 fast clicks", times("M:L|W:30", 100));
        mouse.add("Anti-AFK 1 min", times("N:3,0,1|W:1500|N:-3,0,1|W:1500", 20));
        mouse.add("Anti-AFK 5 min", times("N:3,0,1|W:1500|N:-3,0,1|W:1500", 100));
        mouse.add("Wiggle", times("N:20,0,1|W:30|N:-20,0,1|W:30", 6));
        CATS.add(mouse);

        Cat quick = new Cat("💭", "Quick text");
        String[] q = {"gg", "gg wp", "brb", "afk", "ok", "lol", "thanks!", "on my way", "1 min", "good morning",
            "good night", "yes", "no", "wait", "nice", "let's go", "sorry", "what?", "/shrug", "hello"};
        for (String s : q) {
            quick.add(s, "T:" + s);
        }
        quick.add("Lorem ipsum", "T:Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        CATS.add(quick);
    }

    static int total() {
        int n = 0;
        for (Cat c : CATS) {
            n += c.items.size();
        }
        return n;
    }
}
