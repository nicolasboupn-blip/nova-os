package app.novaos;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * PC REMOTE: control a Windows PC from NOVA over Bluetooth. NOVA shows up on the PC as a keyboard and mouse
 * ("NOVA Remote"), so nothing needs installing there. A search box finds any of the 750+ actions; tiles open the
 * mouse, typing and each category; hold any action to make it a favourite. \u2922 opens it full screen.
 */
final class PcRemoteWidget extends NovaWidget {
    private static final String K_APPS = "pc_my_apps";
    private static final String K_FAVS = "pc_favs";

    private final boolean big;
    private final TextView status;
    private final TextView connect;
    private final TextView layoutChip;
    private final EditText search;
    private final FrameLayout body;
    /** -1 home, -2 mouse, -3 type, else a category. */
    private int page = -1;

    PcRemoteWidget(NovaActivity host) {
        this(host, false);
    }

    PcRemoteWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setSingleLine(true);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        connect = chip("CONNECT", this::connectTapped);
        connect.setOnLongClickListener(v -> {
            choosePc();
            return true;
        });
        top.addView(connect);
        layoutChip = chip("", () -> {
            Prefs.putInt(PcHid.K_LAYOUT, (Prefs.getInt(PcHid.K_LAYOUT, 0) + 1) % PcHid.LAYOUTS.length);
            refresh();
            host.toast("PC keyboard: " + PcHid.LAYOUTS[Prefs.getInt(PcHid.K_LAYOUT, 0)]);
        });
        top.addView(layoutChip, margin());
        if (!big) {
            top.addView(chip("\u2922", this::openBig), margin());
        }
        addView(top, wide());

        search = new EditText(host);
        search.setHint("\uD83D\uDD0D  Search " + PcActions.total() + " actions\u2026");
        search.setSingleLine(true);
        search.setTextSize(13f);
        search.setTextColor(Theme.TEXT);
        search.setHintTextColor(Theme.DIM);
        search.setBackground(Theme.rounded(0x18FFFFFF, 12f, host));
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void onTextChanged(CharSequence a, int b, int c, int d) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                draw();
            }
        });
        LinearLayout.LayoutParams sp = wide();
        sp.setMargins(0, dp(6), 0, dp(4));
        addView(search, sp);
        body = new FrameLayout(host);
        addView(body, wide());
        draw();
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        return lp;
    }

    @Override
    void refresh() {
        status.setText(PcHid.connected() ? "\u25CF " + PcHid.state : PcHid.state);
        status.setTextColor(PcHid.connected() ? 0xFF34C759 : Theme.DIM);
        connect.setText(PcHid.connected() ? "CONNECTED" : "CONNECT");
        pick(connect, PcHid.connected());
        layoutChip.setText(new String[] {"CH", "DE", "US"}[Math.max(0, Math.min(2, Prefs.getInt(PcHid.K_LAYOUT, 0)))]);
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            PcHid.listener = this::refresh;
        } else if (PcHid.listener != null && !big) {
            PcHid.listener = null;
        }
        if (on && PcHid.hid == null && btAllowed()) {
            PcHid.start(host);
        }
    }

    private boolean btAllowed() {
        return Build.VERSION.SDK_INT < 31
                || host.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(12), dp(40), dp(12), dp(16));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("PC REMOTE", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("\u2715 CLOSE", () -> {
            host.hideOverlay();
            PcHid.listener = this::refresh;
            refresh();
        }));
        v.addView(head, wide());
        ScrollView sv = new ScrollView(host);
        sv.addView(new PcRemoteWidget(host, true));
        v.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    // ------------------------------------------------------------------ connecting

    private void connectTapped() {
        PcConnect.connect(host);
    }

    private void choosePc() {
        PcConnect.choosePc(host);
    }

    // ------------------------------------------------------------------ pages

    private void open(int p) {
        page = p;
        if (search.getText().length() > 0) {
            search.setText("");
        } else {
            draw();
        }
    }

    private boolean ready() {
        if (!PcHid.connected()) {
            host.toast("Not connected: tap CONNECT");
            return false;
        }
        return true;
    }

    private void draw() {
        body.removeAllViews();
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        if (!q.isEmpty()) {
            List<String[]> hits = new ArrayList<>();
            for (PcActions.Cat c : PcActions.CATS) {
                for (String[] a : c.items) {
                    String label = a[0].startsWith("!") ? a[0].substring(1) : a[0];
                    if (label.toLowerCase(Locale.ROOT).contains(q) || c.name.toLowerCase(Locale.ROOT).contains(q)) {
                        hits.add(new String[] {a[0], a[1], c.name});
                    }
                }
            }
            if (hits.isEmpty()) {
                hits.add(new String[] {"Open \u201C" + search.getText().toString().trim() + "\u201D on the PC",
                    PcActions.app(search.getText().toString().trim()), ""});
            }
            TextView h = text(hits.size() + " found", 10f, Theme.DIM);
            h.setGravity(Gravity.START);
            col.addView(h, wide());
            buttons(col, hits.subList(0, Math.min(hits.size(), 120)));
        } else if (page == -1) {
            List<String[]> favs = favs();
            if (!favs.isEmpty()) {
                TextView h = text("\u2B50 FAVOURITES (hold to remove)", 10f, Theme.ACCENT);
                h.setGravity(Gravity.START);
                col.addView(h, wide());
                buttons(col, favs);
            }
            List<Object[]> tiles = new ArrayList<>();
            tiles.add(new Object[] {"\uD83D\uDDB1", "Mouse", "trackpad", -2});
            tiles.add(new Object[] {"\u2328", "Type", "write on the PC", -3});
            for (int i = 0; i < PcActions.CATS.size(); i++) {
                PcActions.Cat c = PcActions.CATS.get(i);
                tiles.add(new Object[] {c.icon, c.name, c.items.size() + (i == 0 ? appsMine().size() : 0) + " actions", i});
            }
            LinearLayout r = null;
            for (int i = 0; i < tiles.size(); i++) {
                if (i % 2 == 0) {
                    r = row();
                    col.addView(r, wide());
                }
                final Object[] tl = tiles.get(i);
                TextView b = text(tl[0] + "  " + tl[1] + "\n" + tl[2], big ? 13f : 11f, Theme.TEXT);
                b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                b.setBackground(Theme.rounded(0x1AFFFFFF, 14f, host));
                b.setPadding(dp(12), dp(big ? 14 : 10), dp(8), dp(big ? 14 : 10));
                b.setClickable(true);
                Theme.ripple(b);
                b.setOnClickListener(v -> open((int) tl[3]));
                LinearLayout.LayoutParams p = weight(1f);
                p.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(b, p);
            }
            if (r != null && r.getChildCount() < 2) {
                r.addView(new View(host), weight(1f));
            }
        } else {
            LinearLayout head = row();
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(chip("\u2039 BACK", () -> open(-1)));
            String title = page == -2 ? "\uD83D\uDDB1 Mouse" : page == -3 ? "\u2328 Type"
                    : PcActions.CATS.get(page).icon + " " + PcActions.CATS.get(page).name;
            TextView t = text(title, 13f, Theme.TEXT);
            t.setGravity(Gravity.START);
            t.setPadding(dp(10), 0, 0, 0);
            head.addView(t, weight(1f));
            col.addView(head, wide());
            if (page == -2) {
                col.addView(mousePanel());
            } else if (page == -3) {
                col.addView(typePanel());
            } else {
                List<String[]> list = new ArrayList<>(PcActions.CATS.get(page).items);
                if (page == 0) {
                    list.addAll(appsMine());
                    list.add(new String[] {"+ ANY APP", ""});
                }
                buttons(col, list);
            }
        }
        body.addView(col);
    }

    private List<String[]> appsMine() {
        List<String[]> out = new ArrayList<>();
        for (String n : Prefs.getString(K_APPS, "").split("\n")) {
            if (!n.trim().isEmpty()) {
                out.add(new String[] {n.trim(), PcActions.app(n.trim())});
            }
        }
        return out;
    }

    private List<String[]> favs() {
        List<String[]> out = new ArrayList<>();
        for (String line : Prefs.getString(K_FAVS, "").split("\n")) {
            int bar = line.indexOf('\t');
            if (bar > 0) {
                out.add(new String[] {line.substring(0, bar), line.substring(bar + 1)});
            }
        }
        return out;
    }

    private void toggleFav(String[] a) {
        List<String[]> f = favs();
        boolean removed = false;
        for (int i = f.size() - 1; i >= 0; i--) {
            if (f.get(i)[0].equals(a[0]) && f.get(i)[1].equals(a[1])) {
                f.remove(i);
                removed = true;
            }
        }
        if (!removed) {
            f.add(new String[] {a[0], a[1]});
        }
        StringBuilder b = new StringBuilder();
        for (String[] x : f) {
            b.append(x[0]).append('\t').append(x[1]).append('\n');
        }
        Prefs.putString(K_FAVS, b.toString());
        host.buzz(20);
        host.toast(removed ? "Removed from favourites" : "\u2B50 Added to favourites");
        draw();
    }

    /** Two buttons per row (three in the big view). */
    private void buttons(LinearLayout col, List<String[]> list) {
        int per = big ? 3 : 2;
        LinearLayout r = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % per == 0) {
                r = row();
                col.addView(r, wide());
            }
            final String[] a = list.get(i);
            final boolean danger = a[0].startsWith("!");
            final String label = danger ? a[0].substring(1) : a[0];
            TextView b = chip(label, () -> act(a, label, danger));
            b.setTextSize(big ? 12f : 10.5f);
            b.setPadding(dp(6), dp(big ? 12 : 9), dp(6), dp(big ? 12 : 9));
            b.setOnLongClickListener(v -> {
                if (!a[1].isEmpty()) {
                    toggleFav(a);
                }
                return true;
            });
            if (danger) {
                b.setTextColor(0xFFFF453A);
            }
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(b, p);
        }
        while (r != null && r.getChildCount() < per) {
            r.addView(new View(host), weight(1f));
        }
    }

    private void act(String[] a, String label, boolean danger) {
        if (a[1].isEmpty()) {
            addApp();
            return;
        }
        if (!ready()) {
            return;
        }
        if (a[1].startsWith("?")) {
            final EditText e = new EditText(host);
            e.setSingleLine(true);
            new AlertDialog.Builder(host).setTitle(label).setView(e)
                    .setPositiveButton("GO", (d, w) -> PcHid.run(a[1].substring(1).replace("{ask}", e.getText().toString())))
                    .setNegativeButton("CANCEL", null).show();
            return;
        }
        if (danger) {
            new AlertDialog.Builder(host).setTitle(label + "?")
                    .setMessage("This runs on the PC right away.")
                    .setPositiveButton("DO IT", (d, w) -> PcHid.run(a[1]))
                    .setNegativeButton("CANCEL", null).show();
            return;
        }
        host.buzz(8);
        PcHid.run(a[1]);
    }

    private void addApp() {
        final EditText e = new EditText(host);
        e.setHint("App name as in the Start menu");
        e.setSingleLine(true);
        new AlertDialog.Builder(host).setTitle("Add an app button")
                .setView(e)
                .setPositiveButton("ADD", (d, w) -> {
                    String n = e.getText().toString().trim();
                    if (!n.isEmpty()) {
                        String old = Prefs.getString(K_APPS, "");
                        Prefs.putString(K_APPS, old + n + "\n");
                        open(0);
                    }
                })
                .setNeutralButton("CLEAR MINE", (d, w) -> {
                    Prefs.putString(K_APPS, "");
                    open(0);
                })
                .setNegativeButton("CANCEL", null).show();
    }

    private View typePanel() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        final EditText e = new EditText(host);
        e.setHint("Type here, then SEND");
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(Theme.DIM);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setMaxLines(4);
        col.addView(e, wide());
        LinearLayout r = row();
        String[][] b = {{"SEND", ""}, {"SEND + ENTER", ""}, {"ENTER", "K:ENTER"}, {"⌫", "K:BKSP"}};
        for (final String[] x : b) {
            TextView c = chip(x[0], () -> {
                if (!ready()) {
                    return;
                }
                if (x[1].isEmpty()) {
                    String s = e.getText().toString();
                    PcHid.type(x[0].length() > 4 ? s + "\n" : s);
                    e.setText("");
                } else {
                    PcHid.run(x[1]);
                }
            });
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(c, p);
        }
        col.addView(r, wide());
        TextView hint = text("Set CH / DE / US (top right) to your PC's keyboard layout so symbols come out right.", 9f,
                Theme.DIM);
        hint.setPadding(0, dp(4), 0, 0);
        col.addView(hint, wide());
        return col;
    }

    private View mousePanel() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        Trackpad pad = new Trackpad();
        col.addView(pad, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, big ? (int) (getResources().getDisplayMetrics().heightPixels * 0.5f) : dp(170)));
        LinearLayout r = row();
        String[][] b = {{"LEFT", "1"}, {"MIDDLE", "4"}, {"RIGHT", "2"}};
        for (final String[] x : b) {
            TextView c = chip(x[0], () -> {
                if (ready()) {
                    PcHid.click(Integer.parseInt(x[1]));
                }
            });
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(c, p);
        }
        col.addView(r, wide());
        TextView hint = text("Drag = move · tap = click · 2-finger tap = right click · 2-finger drag = scroll "
                + "· double-tap + drag = hold and drag", 9f, Theme.DIM);
        col.addView(hint, wide());
        return col;
    }

    /** The trackpad: moves the mouse with acceleration, taps click, two fingers scroll or right-click. */
    private final class Trackpad extends View {
        private float lx;
        private float ly;
        private float sx;
        private float sy;
        private long downAt;
        private long lastTap;
        private boolean moved;
        private boolean two;
        private boolean holding;
        private float scrollAcc;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        Trackpad() {
            super(host);
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            p.setColor(0x18FFFFFF);
            c.drawRoundRect(new android.graphics.RectF(dp(2), dp(2), getWidth() - dp(2), getHeight() - dp(2)), dp(14), dp(14), p);
            p.setColor(Theme.DIM);
            p.setTextSize(dp(10));
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            c.drawText(PcHid.connected() ? "TRACKPAD" : "connect first", getWidth() / 2f, getHeight() / 2f, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lx = sx = e.getX();
                    ly = sy = e.getY();
                    downAt = SystemClock.uptimeMillis();
                    moved = false;
                    two = false;
                    // double-tap then drag: hold the left button
                    holding = downAt - lastTap < 250;
                    if (holding) {
                        PcHid.mouse(1, 0, 0, 0);
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    two = true;
                    ly = e.getY(0);
                    scrollAcc = 0;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    if (two && e.getPointerCount() >= 2) {
                        float dy = e.getY(0) - ly;
                        ly = e.getY(0);
                        scrollAcc += dy;
                        int steps = (int) (scrollAcc / dp(14));
                        if (steps != 0) {
                            scrollAcc -= steps * dp(14);
                            PcHid.mouse(holding ? 1 : 0, 0, 0, steps);
                            moved = true;
                        }
                        return true;
                    }
                    float dx = e.getX() - lx;
                    float dy = e.getY() - ly;
                    lx = e.getX();
                    ly = e.getY();
                    if (Math.hypot(e.getX() - sx, e.getY() - sy) > dp(6)) {
                        moved = true;
                    }
                    float speed = (float) Math.hypot(dx, dy);
                    float acc = 1.1f + Math.min(2.4f, speed / dp(9));
                    PcHid.mouse(holding ? 1 : 0, Math.round(dx * acc / getResources().getDisplayMetrics().density * 1.6f),
                            Math.round(dy * acc / getResources().getDisplayMetrics().density * 1.6f), 0);
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    long now = SystemClock.uptimeMillis();
                    if (holding) {
                        PcHid.mouse(0, 0, 0, 0);
                        holding = false;
                        lastTap = 0;
                        return true;
                    }
                    if (!moved && now - downAt < 220) {
                        if (!ready()) {
                            return true;
                        }
                        PcHid.click(two ? 2 : 1);
                        lastTap = two ? 0 : now;
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }
}
