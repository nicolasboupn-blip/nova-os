package app.novaos;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

/** Connecting NOVA's Bluetooth keyboard to a PC: shared by PC REMOTE and KEY DECK. */
final class PcConnect {
    private PcConnect() {
    }

    // ------------------------------------------------------------------ connecting

    static void connect(final NovaActivity host) {
        if (PcHid.connected()) {
            new AlertDialog.Builder(host).setTitle("PC REMOTE")
                    .setMessage(PcHid.state)
                    .setPositiveButton("DISCONNECT", (d, w) -> PcHid.disconnect())
                    .setNeutralButton("OTHER PC", (d, w) -> choosePc(host))
                    .setNegativeButton("OK", null).show();
            return;
        }
        String[] perms = Build.VERSION.SDK_INT >= 31
                ? new String[] {android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_ADVERTISE}
                : new String[0];
        Runnable go = () -> {
            BluetoothAdapter a = PcHid.adapter(host);
            if (a != null && !a.isEnabled()) {
                try {
                    host.startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                } catch (RuntimeException e) {
                    host.toast("Turn Bluetooth on");
                }
                return;
            }
            PcHid.start(host);
            if (Prefs.getString(PcHid.K_ADDR, "").isEmpty()) {
                choosePc(host);
            } else {
                PcHid.reconnect();
            }
        };
        if (perms.length == 0) {
            go.run();
        } else {
            host.ask(perms, go, () -> host.toast("PC REMOTE needs Nearby devices (Bluetooth)"));
        }
    }

    /** Pick a PC that is already paired, or pair a new one. */
    static void choosePc(final NovaActivity host) {
        final List<BluetoothDevice> pcs = new ArrayList<>();
        List<String> names = new ArrayList<>();
        try {
            BluetoothAdapter a = PcHid.adapter(host);
            if (a != null) {
                for (BluetoothDevice d : a.getBondedDevices()) {
                    BluetoothClass bc = d.getBluetoothClass();
                    boolean computer = bc != null && bc.getMajorDeviceClass() == BluetoothClass.Device.Major.COMPUTER;
                    pcs.add(computer ? 0 : pcs.size(), d);
                    names.add(computer ? 0 : names.size(), (computer ? "💻 " : "") + PcHid.name(d));
                }
            }
        } catch (SecurityException e) {
            host.toast("Allow Nearby devices first");
            return;
        }
        names.add("➕ PAIR A NEW PC");
        new AlertDialog.Builder(host).setTitle("Which PC?")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    if (which >= pcs.size()) {
                        pairNew(host);
                    } else {
                        String addr = pcs.get(which).getAddress();
                        Prefs.putString(PcHid.K_ADDR, addr);
                        if (PcHid.registered) {
                            PcHid.connectTo(addr);
                        } else {
                            PcHid.start(host);
                        }
                    }
                }).show();
    }

    static void pairNew(final NovaActivity host) {
        try {
            Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            host.startActivity(i);
        } catch (RuntimeException ignored) {
            // the phone will show it anyway from its Bluetooth screen
        }
        new AlertDialog.Builder(host).setTitle("Pair your PC")
                .setMessage("1. Your phone is now visible for 5 minutes.\n\n"
                        + "2. On the PC: Settings > Bluetooth & devices > Add device > Bluetooth, and pick this phone.\n\n"
                        + "3. Accept the code on both screens. Windows adds it as a keyboard and mouse.\n\n"
                        + "Tip: if the PC already knew this phone, remove it there first (Bluetooth & devices > ⋯ > "
                        + "Remove device) and pair again, so Windows sees the new keyboard and mouse.")
                .setPositiveButton("OK", null).show();
    }

}
