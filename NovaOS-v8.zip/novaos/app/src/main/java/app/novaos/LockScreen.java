package app.novaos;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

/**
 * Swipe-up lock screen. It is only a cover for looks: your phone's real PIN,
 * pattern or fingerprint lock still works the way you set it in Android.
 */
final class LockScreen extends FrameLayout {
    private final NovaActivity host;
    private final ObjectAnimator pulse;
    private final ValueAnimator glowAnim;
    private final ValueAnimator tagGlow;
    private float startY;
    private final int threshold;

    LockScreen(NovaActivity host) {
        super(host);
        this.host = host;
        threshold = Theme.dp(host, 120);

        // live wallpaper: NOVA's own source code typing itself, plus the purple edge light
        CodeWallpaper code = new CodeWallpaper(host);
        code.setAlpha(0.22f);
        code.setPadding(Theme.dp(host, 24), Theme.dp(host, 40), Theme.dp(host, 24), 0);
        addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        int side = Theme.dp(host, 24);
        col.setPadding(side, Theme.dp(host, 110), side, 0);
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        TextView tag = new TextView(host);
        tag.setText(Theme.OS_NAME + " " + Theme.OS_VERSION);
        tag.setTypeface(Theme.MONO);
        tag.setTextSize(12f);
        tag.setLetterSpacing(0.3f);
        tag.setTextColor(Theme.ACCENT);
        col.addView(tag);
        tagGlow = Theme.glow(tag);

        TextClock time = new TextClock(host);
        time.setFormat12Hour("HH:mm");
        time.setFormat24Hour("HH:mm");
        time.setTextSize(88f);
        time.setTypeface(Theme.clockFace());
        time.setTextColor(Theme.TEXT);
        time.setIncludeFontPadding(false);
        glowAnim = Theme.glow(time);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 14);
        col.addView(time, tlp);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(16f);
        date.setTextColor(Theme.DIM);
        col.addView(date);

        TextView hint = new TextView(host);
        hint.setText("swipe up to unlock");
        hint.setTypeface(Theme.MONO);
        hint.setTextSize(12f);
        hint.setLetterSpacing(0.15f);
        hint.setTextColor(Theme.DIM);
        LayoutParams hlp = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hlp.bottomMargin = Theme.dp(host, 64);
        addView(hint, hlp);

        pulse = ObjectAnimator.ofFloat(hint, View.ALPHA, 0.25f, 1f);
        pulse.setDuration(1300);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startY = e.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dy = Math.min(0f, e.getRawY() - startY);
                setTranslationY(dy * 0.8f);
                setAlpha(Math.max(0.3f, 1f + dy / (threshold * 4f)));
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                float dy = e.getRawY() - startY;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && dy < -threshold) {
                    animate().translationY(-getHeight()).alpha(0f).setDuration(420)
                            .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                            .withEndAction(() -> host.unlock()).start();
                } else {
                    animate().translationY(0f).alpha(1f).setDuration(480)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                }
                return true;
            }
            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        pulse.cancel();
        glowAnim.cancel();
        tagGlow.cancel();
        super.onDetachedFromWindow();
    }
}
