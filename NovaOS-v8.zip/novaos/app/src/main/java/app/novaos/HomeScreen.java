package app.novaos;

import android.animation.ValueAnimator;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Clock, a small tabbed panel (system, network, music), pinned apps and a dock.
 * Swipe up on an empty area to open the app drawer. After an unlock it plays a short
 * welcome animation: the greeting, then the time, then everything else rises in from below.
 */
final class HomeScreen extends FrameLayout {
    private static final int COLUMNS = 4;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Handler introHandler = new Handler(Looper.getMainLooper());
    private final TextView battery;
    private final android.view.GestureDetector swipe;
    private ValueAnimator glowAnim;
    private ValueAnimator nameGlow;

    // panel: tabs and pages
    private LinearLayout pageSystem, pageNet, pageMusic;
    private TextView tabSystem, tabNet, tabMusic;

    // system page
    private TextView batteryText, alarmText, storageText, ramText, tempText;
    private View barFill;

    // network page
    private TextView connText, wifiText, speedText, mobileText, mobileUsedText;
    private long lastRx, lastTx, lastMobRx, lastMobTx, lastAt;
    private boolean testing;

    // music page
    private TextView musicTitle, musicArtist, playBtn;

    // welcome animation
    private final List<View> early = new ArrayList<>();
    private final List<View> late = new ArrayList<>();
    private boolean introWanted;
    private boolean introStarted;
    private boolean introRunning;
    private TextView welcome;
    private ValueAnimator welcomeGlow;
    private ValueAnimator welcomeSpacing;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshBattery();
            refreshStatus();
            handler.postDelayed(this, 30000);
        }
    };

    private final Runnable musicTick = new Runnable() {
        @Override
        public void run() {
            refreshMusic();
            handler.postDelayed(this, 2000);
        }
    };

    private final Runnable netTick = new Runnable() {
        @Override
        public void run() {
            refreshNet();
            handler.postDelayed(this, 1000);
        }
    };

    HomeScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        introWanted = host.takeIntro();
        int side = Theme.dp(host, 24);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        // code wallpaper behind everything, typing itself at the chosen opacity
        if (Prefs.homeCode()) {
            CodeWallpaper code = new CodeWallpaper(host, true);
            code.setAlpha(Theme.wallAlpha());
            code.setPadding(side, Theme.dp(host, 44), side, 0);
            addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // top row: name on the left, battery on the right
        LinearLayout status = new LinearLayout(host);
        status.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = mono(Theme.OS_NAME, 12f, Theme.ACCENT);
        name.setLetterSpacing(0.3f);
        nameGlow = Theme.glow(name);
        battery = mono("", 12f, Theme.DIM);
        status.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        status.addView(battery);
        col.addView(status);
        late.add(status);

        TextClock clock = new TextClock(host);
        clock.setFormat12Hour("HH:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(64f);
        clock.setTypeface(Theme.clockFace());
        clock.setTextColor(Theme.TEXT);
        clock.setIncludeFontPadding(false);
        glowAnim = Theme.glow(clock);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 28);
        col.addView(clock, clp);
        early.add(clock);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(15f);
        date.setTextColor(Theme.DIM);
        col.addView(date);
        early.add(date);

        // live panel, then a flexible gap
        LinearLayout panel = statusPanel();
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.topMargin = Theme.dp(host, 28);
        if (Prefs.systemPanel()) {
            col.addView(panel, plp);
            late.add(panel);
        }
        col.addView(new View(host), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // pinned apps
        host.repo.ensureFresh();
        List<AppEntry> pinned = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                pinned.add(e);
            }
        }
        if (pinned.isEmpty()) {
            TextView empty = mono("Long-press an app in the drawer to pin it here.", 12f, Theme.DIM);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            elp.bottomMargin = Theme.dp(host, 20);
            col.addView(empty, elp);
            late.add(empty);
        } else {
            LinearLayout rows = new LinearLayout(host);
            rows.setOrientation(LinearLayout.VERTICAL);
            LinearLayout row = null;
            int n = 0;
            for (AppEntry e : pinned) {
                if (n % COLUMNS == 0) {
                    row = new LinearLayout(host);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    rows.addView(row, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                }
                row.addView(cell(e), new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                n++;
            }
            while (n % COLUMNS != 0) {
                row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
                n++;
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = Theme.dp(host, 20);
            col.addView(rows, rlp);
            late.add(rows);
        }

        // dock
        LinearLayout dock = new LinearLayout(host);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        dock.setPadding(Theme.dp(host, 6), Theme.dp(host, 4), Theme.dp(host, 6), Theme.dp(host, 4));
        dock.addView(dockButton("APPS", v -> host.showDrawer()), weight());
        dock.addView(dockButton("NOTES", v -> host.showNotes()), weight());
        dock.addView(dockButton("TERMINAL", v -> host.showTerminal()), weight());
        dock.addView(dockButton("SETUP", v -> host.showSettings()), weight());
        col.addView(dock, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        late.add(dock);

        swipe = new android.view.GestureDetector(host,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (e1 != null && e2 != null
                                && e1.getY() - e2.getY() > Theme.dp(host, 80) && Math.abs(vy) > 600) {
                            host.showDrawer();
                            return true;
                        }
                        return false;
                    }
                });

        refreshBattery();
        refreshStatus();
        refreshMusic();
        refreshNet();

        if (introWanted) {
            prepareIntro();
        }
    }

    // ---------------------------------------------------------------- welcome animation

    /** Hides everything and adds the big greeting in the middle. Plays once the screen is attached. */
    private void prepareIntro() {
        introRunning = true;
        for (View v : early) {
            v.setAlpha(0f);
        }
        float rise = Theme.dp(host, 70);
        for (View v : late) {
            v.setAlpha(0f);
            v.setTranslationY(rise);
        }
        welcome = new TextView(host);
        welcome.setText(Prefs.greeting().toUpperCase(Locale.getDefault()));
        welcome.setTypeface(Theme.clockFace());
        welcome.setTextSize(34f);
        welcome.setTextColor(Theme.TEXT);
        welcome.setLetterSpacing(0.9f);
        welcome.setAlpha(0f);
        welcomeGlow = Theme.glow(welcome);
        addView(welcome, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    /**
     * Greeting fades and settles in, then the time, then the rest rises from below,
     * one piece after another. About 2.3 seconds in total.
     */
    private void playIntro() {
        final DecelerateInterpolator out = new DecelerateInterpolator(1.6f);

        welcome.setScaleX(1.12f);
        welcome.setScaleY(1.12f);
        welcome.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
        welcomeSpacing = ValueAnimator.ofFloat(0.9f, 0.4f);
        welcomeSpacing.setDuration(1000);
        welcomeSpacing.setInterpolator(new DecelerateInterpolator());
        welcomeSpacing.addUpdateListener(a -> welcome.setLetterSpacing((float) a.getAnimatedValue()));
        welcomeSpacing.start();

        introHandler.postDelayed(() -> welcome.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f)
                .setDuration(350).start(), 900);

        introHandler.postDelayed(() -> {
            for (View v : early) {
                v.setPivotX(0f);
                v.setPivotY(v.getHeight() / 2f);
                v.setScaleX(0.9f);
                v.setScaleY(0.9f);
                v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
            }
        }, 950);

        for (int i = 0; i < late.size(); i++) {
            final View v = late.get(i);
            introHandler.postDelayed(() -> v.animate().alpha(1f).translationY(0f)
                    .setDuration(560).setInterpolator(out).start(), 1500L + 90L * i);
        }

        introHandler.postDelayed(() -> introRunning = false, 1500L + 90L * late.size() + 600L);
    }

    /** Tap anywhere during the animation to jump straight to the finished home screen. */
    private void finishIntro() {
        introRunning = false;
        introHandler.removeCallbacksAndMessages(null);
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        if (welcome != null) {
            welcome.animate().cancel();
            welcome.setAlpha(0f);
        }
        for (View v : early) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setScaleX(1f);
            v.setScaleY(1f);
        }
        for (View v : late) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setTranslationY(0f);
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (introRunning && e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            finishIntro();
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return swipe.onTouchEvent(e) || super.onTouchEvent(e);
    }

    // ---------------------------------------------------------------- panel

    /** One box with three tabs: SYSTEM, NETWORK and MUSIC. Tap a tab name to switch. */
    private LinearLayout statusPanel() {
        LinearLayout p = new LinearLayout(host);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        int pad = Theme.dp(host, 16);
        p.setPadding(pad, pad, pad, pad);

        LinearLayout tabs = new LinearLayout(host);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabSystem = tabLabel("SYSTEM", 0);
        tabNet = tabLabel("NETWORK", 1);
        tabMusic = tabLabel("MUSIC", 2);
        tabs.addView(tabSystem);
        tabs.addView(tabNet);
        tabs.addView(tabMusic);
        p.addView(tabs);

        pageSystem = page();
        pageNet = page();
        pageMusic = page();

        // SYSTEM
        batteryText = statValue(pageSystem, "BATTERY");
        LinearLayout bar = new LinearLayout(host);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setWeightSum(100f);
        bar.setBackground(Theme.rounded(0x33FFFFFF, 3f, host));
        barFill = new View(host);
        barFill.setBackground(Theme.rounded(Theme.ACCENT, 3f, host));
        bar.addView(barFill, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Theme.dp(host, 6));
        blp.topMargin = Theme.dp(host, 6);
        pageSystem.addView(bar, blp);
        alarmText = statValue(pageSystem, "NEXT ALARM");
        storageText = statValue(pageSystem, "STORAGE");
        ramText = statValue(pageSystem, "RAM");
        tempText = statValue(pageSystem, "BATTERY TEMP");

        // NETWORK
        connText = statValue(pageNet, "CONNECTION");
        wifiText = statValue(pageNet, "WI-FI");
        speedText = statValue(pageNet, "SPEED TEST");
        speedText.setText("tap to run");
        speedText.setTextColor(Theme.ACCENT);
        // the whole row is the button
        View speedRow = (View) speedText.getParent();
        speedRow.setClickable(true);
        speedRow.setOnClickListener(v -> runSpeedTest());
        mobileText = statValue(pageNet, "MOBILE");
        mobileUsedText = statValue(pageNet, "MOBILE USED");

        // MUSIC
        buildMusic(pageMusic);

        FrameLayout holder = new FrameLayout(host);
        holder.setMinimumHeight(Theme.dp(host, 150));
        holder.addView(pageSystem, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        holder.addView(pageNet, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        holder.addView(pageMusic, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = Theme.dp(host, 4);
        p.addView(holder, hlp);

        selectTab(0, false);
        return p;
    }

    private LinearLayout page() {
        LinearLayout l = new LinearLayout(host);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private TextView tabLabel(String label, final int index) {
        TextView t = mono(label, 11f, Theme.DIM);
        t.setLetterSpacing(0.2f);
        t.setPadding(0, Theme.dp(host, 2), Theme.dp(host, 20), Theme.dp(host, 6));
        t.setClickable(true);
        t.setOnClickListener(v -> selectTab(index, true));
        return t;
    }

    private void selectTab(int index, boolean animate) {
        View[] pages = {pageSystem, pageNet, pageMusic};
        TextView[] tabs = {tabSystem, tabNet, tabMusic};
        for (int k = 0; k < pages.length; k++) {
            boolean on = k == index;
            tabs[k].setTextColor(on ? Theme.ACCENT : Theme.DIM);
            pages[k].setVisibility(on ? View.VISIBLE : View.GONE);
            if (on && animate) {
                pages[k].setAlpha(0f);
                pages[k].animate().alpha(1f).setDuration(220).start();
            }
        }
    }

    private void buildMusic(LinearLayout music) {
        music.setPadding(0, Theme.dp(host, 8), 0, 0);

        musicTitle = mono("", 14f, Theme.TEXT);
        musicTitle.setSingleLine(true);
        musicTitle.setEllipsize(TextUtils.TruncateAt.END);
        music.addView(musicTitle, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        musicArtist = mono("", 11f, Theme.DIM);
        musicArtist.setSingleLine(true);
        musicArtist.setEllipsize(TextUtils.TruncateAt.END);
        music.addView(musicArtist);

        LinearLayout controls = new LinearLayout(host);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        playBtn = control("PLAY", v -> {
            MediaController c = controller();
            if (c != null) {
                PlaybackState s = c.getPlaybackState();
                boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
                if (playing) {
                    c.getTransportControls().pause();
                } else {
                    c.getTransportControls().play();
                }
            }
            handler.postDelayed(this::refreshMusic, 350);
        });
        controls.addView(control("<<", v -> {
            MediaController c = controller();
            if (c != null) {
                c.getTransportControls().skipToPrevious();
            }
            handler.postDelayed(this::refreshMusic, 350);
        }), weight());
        controls.addView(playBtn, weight());
        controls.addView(control(">>", v -> {
            MediaController c = controller();
            if (c != null) {
                c.getTransportControls().skipToNext();
            }
            handler.postDelayed(this::refreshMusic, 350);
        }), weight());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 10);
        music.addView(controls, clp);

        // without notification access NOVA can't see what is playing: tapping the page opens that setting
        music.setOnClickListener(v -> {
            if (!NovaNotificationService.hasAccess(host)) {
                try {
                    host.startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception ignored) {
                    // no such settings page on this phone
                }
            }
        });
    }

    private TextView control(String label, OnClickListener click) {
        TextView b = mono(label, 12f, Theme.ACCENT);
        b.setLetterSpacing(0.1f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 12), 0, Theme.dp(host, 4));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private TextView statValue(LinearLayout parent, String key) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, Theme.dp(host, 8), 0, 0);
        TextView k = mono(key, 11f, Theme.DIM);
        k.setLetterSpacing(0.12f);
        r.addView(k, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = mono("", 11f, Theme.TEXT);
        r.addView(v);
        parent.addView(r, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return v;
    }

    // ---------------------------------------------------------------- system page

    /** Battery, alarm, storage, RAM and battery temperature. Refreshes every 30 seconds. */
    private void refreshStatus() {
        int level = host.batteryLevel();
        if (level >= 0) {
            batteryText.setText(level + "%" + (host.charging() ? " · charging" : ""));
            ((LinearLayout.LayoutParams) barFill.getLayoutParams()).weight = level;
            barFill.getParent().requestLayout();
        } else {
            batteryText.setText("--");
        }
        alarmText.setText(nextAlarm());
        storageText.setText(storage());
        ramText.setText(ram());
        tempText.setText(batteryTemp());
    }

    /** "07:30 · in 7h 12m", or "none" if no alarm is set. Needs no permission. */
    private String nextAlarm() {
        try {
            AlarmManager am = (AlarmManager) host.getSystemService(Context.ALARM_SERVICE);
            AlarmManager.AlarmClockInfo info = am == null ? null : am.getNextAlarmClock();
            if (info == null) {
                return "none";
            }
            long at = info.getTriggerTime();
            long mins = Math.max(0L, (at - System.currentTimeMillis()) / 60000L);
            String when = new SimpleDateFormat(mins < 24 * 60 ? "HH:mm" : "EEE HH:mm",
                    Locale.getDefault()).format(new Date(at));
            String in = mins >= 60 ? (mins / 60) + "h " + (mins % 60) + "m" : mins + "m";
            return when + " · in " + in;
        } catch (Exception e) {
            return "none";
        }
    }

    private String storage() {
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            long total = fs.getTotalBytes();
            long used = total - fs.getAvailableBytes();
            return String.format(Locale.US, "%.0f / %.0f GB", used / 1e9, total / 1e9);
        } catch (Exception e) {
            return "--";
        }
    }

    private String ram() {
        try {
            ActivityManager am = (ActivityManager) host.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return String.format(Locale.US, "%.1f / %.1f GB", (mi.totalMem - mi.availMem) / 1e9, mi.totalMem / 1e9);
        } catch (Exception e) {
            return "--";
        }
    }

    private String batteryTemp() {
        try {
            Intent i = host.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = i == null ? -1 : i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            return t < 0 ? "--" : String.format(Locale.US, "%.1f °C", t / 10f);
        } catch (Exception e) {
            return "--";
        }
    }

    // ---------------------------------------------------------------- network page

    /** Connection type, Wi-Fi link speed with live rates, and mobile data rates and use. Every second. */
    private void refreshNet() {
        if (wifiText == null) {
            return;
        }
        long now = SystemClock.elapsedRealtime();
        long totalRx = TrafficStats.getTotalRxBytes();
        long totalTx = TrafficStats.getTotalTxBytes();
        long mobRx = Math.max(0L, TrafficStats.getMobileRxBytes());
        long mobTx = Math.max(0L, TrafficStats.getMobileTxBytes());
        long wifiRx = totalRx - mobRx;
        long wifiTx = totalTx - mobTx;

        String wifiRates = "";
        String mobRates = "";
        if (lastAt > 0 && now > lastAt && totalRx != TrafficStats.UNSUPPORTED
                && wifiRx >= lastRx && wifiTx >= lastTx && mobRx >= lastMobRx && mobTx >= lastMobTx) {
            double s = (now - lastAt) / 1000.0;
            wifiRates = "v " + rate((wifiRx - lastRx) / s) + "  ^ " + rate((wifiTx - lastTx) / s);
            mobRates = "v " + rate((mobRx - lastMobRx) / s) + "  ^ " + rate((mobTx - lastMobTx) / s);
        }
        lastRx = wifiRx;
        lastTx = wifiTx;
        lastMobRx = mobRx;
        lastMobTx = mobTx;
        lastAt = now;

        String link = linkSpeed();
        if (link.isEmpty()) {
            wifiText.setText(wifiRates);
        } else {
            wifiText.setText(wifiRates.isEmpty() ? link : link + "  " + wifiRates);
        }
        mobileText.setText(mobRates.isEmpty() ? "--" : mobRates);
        mobileUsedText.setText(bytes(mobRx + mobTx) + " since restart");
        connText.setText(connection());
    }

    private static String rate(double bytesPerSecond) {
        if (bytesPerSecond >= 1024 * 1024) {
            return String.format(Locale.US, "%.1f MB/s", bytesPerSecond / (1024 * 1024));
        }
        if (bytesPerSecond >= 1024) {
            return String.format(Locale.US, "%d KB/s", (long) (bytesPerSecond / 1024));
        }
        return String.format(Locale.US, "%d B/s", (long) bytesPerSecond);
    }

    private static String bytes(long b) {
        if (b >= 1_000_000_000L) {
            return String.format(Locale.US, "%.2f GB", b / 1e9);
        }
        if (b >= 1_000_000L) {
            return String.format(Locale.US, "%.0f MB", b / 1e6);
        }
        if (b >= 1_000L) {
            return String.format(Locale.US, "%.0f KB", b / 1e3);
        }
        return b + " B";
    }

    /** "Wi-Fi", "mobile data", "ethernet" or "offline". */
    private String connection() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null) {
                return "offline";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "Wi-Fi";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return "mobile data";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return "ethernet";
            }
            return "connected";
        } catch (Exception e) {
            return "--";
        }
    }

    /** The speed your phone and router agreed on, like "866 Mbps". Not the same as your internet speed. */
    @SuppressWarnings("deprecation")
    private String linkSpeed() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null || !nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "no Wi-Fi";
            }
            WifiManager wm = (WifiManager) host.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
            int mbps = wi == null ? -1 : wi.getLinkSpeed();
            return mbps > 0 ? mbps + " Mbps" : "connected";
        } catch (Exception e) {
            return "";
        }
    }

    /** Downloads up to 15 MB for at most 7 seconds and shows the real internet speed. Wi-Fi only. */
    private void runSpeedTest() {
        if (testing) {
            return;
        }
        String link = linkSpeed();
        if (link.isEmpty()) {
            speedText.setText("unavailable");
            return;
        }
        if (link.equals("no Wi-Fi")) {
            // keep it off mobile data: the test downloads up to 15 MB
            speedText.setText("connect to Wi-Fi first");
            return;
        }
        testing = true;
        speedText.setText("testing...");
        new Thread(() -> {
            String result;
            try {
                HttpURLConnection c = (HttpURLConnection)
                        new URL("https://speed.cloudflare.com/__down?bytes=15000000").openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                long start = System.nanoTime();
                long got = 0;
                byte[] buf = new byte[65536];
                int n;
                try (InputStream in = c.getInputStream()) {
                    while ((n = in.read(buf)) > 0) {
                        got += n;
                        if (System.nanoTime() - start > 7_000_000_000L) {
                            break;
                        }
                    }
                }
                double sec = (System.nanoTime() - start) / 1e9;
                result = String.format(Locale.US, "%.1f Mbps", got * 8 / sec / 1e6);
            } catch (Exception e) {
                result = "test failed";
            }
            final String shown = result;
            host.runOnUiThread(() -> {
                speedText.setText(shown);
                testing = false;
            });
        }).start();
    }

    // ---------------------------------------------------------------- music page

    /** The player that is playing right now, or the first one if none is. Needs notification access. */
    private MediaController controller() {
        if (!NovaNotificationService.hasAccess(host)) {
            return null;
        }
        try {
            MediaSessionManager m = (MediaSessionManager) host.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (m == null) {
                return null;
            }
            List<MediaController> list = m.getActiveSessions(
                    new ComponentName(host, NovaNotificationService.class));
            MediaController first = null;
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    return c;
                }
                if (first == null) {
                    first = c;
                }
            }
            return first;
        } catch (SecurityException e) {
            return null;
        }
    }

    private void refreshMusic() {
        if (musicTitle == null) {
            return;
        }
        if (!NovaNotificationService.hasAccess(host)) {
            musicTitle.setText("Tap to allow music info");
            musicArtist.setText("Turn on notification access for NOVA");
            playBtn.setText("PLAY");
            return;
        }
        MediaController c = controller();
        if (c == null) {
            musicTitle.setText("nothing playing");
            musicArtist.setText("");
            playBtn.setText("PLAY");
            return;
        }
        MediaMetadata md = c.getMetadata();
        String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        musicTitle.setText(title == null || title.isEmpty() ? c.getPackageName() : title);
        musicArtist.setText(artist == null ? "" : artist);
        PlaybackState s = c.getPlaybackState();
        boolean playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
        playBtn.setText(playing ? "PAUSE" : "PLAY");
    }

    // ---------------------------------------------------------------- bits

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView dockButton(String label, OnClickListener click) {
        TextView b = mono(label, 11f, Theme.TEXT);
        b.setLetterSpacing(0.12f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private View cell(final AppEntry e) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));

        ImageView icon = new ImageView(host);
        icon.setImageDrawable(Theme.tint(host, e.icon));
        c.addView(icon, new LinearLayout.LayoutParams(Theme.dp(host, 58), Theme.dp(host, 58)));

        TextView t = new TextView(host);
        t.setText(e.label);
        t.setTextSize(11f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 6);
        c.addView(t, tlp);

        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.confirmUnpin(e);
            return true;
        });
        return c;
    }

    private void refreshBattery() {
        if (!Prefs.battery()) {
            battery.setText("");
            return;
        }
        int level = host.batteryLevel();
        if (level < 0) {
            battery.setText("");
            return;
        }
        battery.setText(level + "%" + (host.charging() ? " · charging" : ""));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.postDelayed(tick, 30000);
        handler.postDelayed(musicTick, 2000);
        handler.postDelayed(netTick, 1000);
        if (introRunning && !introStarted) {
            introStarted = true;
            playIntro();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        introHandler.removeCallbacksAndMessages(null);
        glowAnim.cancel();
        nameGlow.cancel();
        if (welcomeGlow != null) {
            welcomeGlow.cancel();
        }
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        super.onDetachedFromWindow();
    }
}
