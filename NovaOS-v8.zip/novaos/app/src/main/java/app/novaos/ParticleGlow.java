package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * An app icon with a soft bloom behind it and tiny glowing particles drifting around it.
 * Each particle is born next to the icon, floats outward while slowly circling, and fades away.
 * Every icon gets its own pattern, so no two look the same.
 */
final class ParticleGlow extends Drawable {
    private static final int COUNT = 11;

    private final Drawable icon;
    private final int rgb;
    private final float density;
    private final float[] base = new float[COUNT];   // starting angle in radians
    private final float[] spin = new float[COUNT];   // radians per second, either direction
    private final float[] offset = new float[COUNT]; // where in its life each particle starts, 0..1
    private final float[] rate = new float[COUNT];   // lives per second
    private final float[] dot = new float[COUNT];    // size factor
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bloom = new Paint(Paint.ANTI_ALIAS_FLAG);

    ParticleGlow(Context c, Drawable icon, int color, long seed) {
        this.icon = icon;
        this.rgb = color & 0xFFFFFF;
        this.density = c.getResources().getDisplayMetrics().density;
        Random r = new Random(seed);
        for (int i = 0; i < COUNT; i++) {
            base[i] = r.nextFloat() * 6.2832f;
            spin[i] = (r.nextBoolean() ? 1f : -1f) * (0.15f + r.nextFloat() * 0.35f);
            offset[i] = r.nextFloat();
            rate[i] = 0.18f + r.nextFloat() * 0.22f; // each particle lives roughly 2.5 to 5.5 seconds
            dot[i] = 0.6f + r.nextFloat() * 0.9f;
        }
    }

    @Override
    protected void onBoundsChange(Rect b) {
        // the icon sits in the middle and leaves a margin for the particles
        float inset = b.width() * 0.13f;
        icon.setBounds(Math.round(b.left + inset), Math.round(b.top + inset),
                Math.round(b.right - inset), Math.round(b.bottom - inset));
        float radius = Math.max(1f, b.width() * 0.5f);
        // faint inside, brightest right at the icon's edge, fading to nothing outside
        bloom.setShader(new RadialGradient(b.exactCenterX(), b.exactCenterY(), radius,
                new int[] {(0x18 << 24) | rgb, (0x60 << 24) | rgb, rgb},
                new float[] {0.6f, 0.74f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        float w = b.width();
        if (w <= 0f) {
            return;
        }
        float cx = b.exactCenterX();
        float cy = b.exactCenterY();
        float t = (SystemClock.uptimeMillis() % 600000L) / 1000f;

        // slow breathing bloom
        float breathe = 0.5f + 0.5f * (float) Math.sin(t * 1.1f + base[0]);
        bloom.setAlpha((int) (150 + 105 * breathe));
        canvas.drawCircle(cx, cy, w * 0.5f, bloom);

        icon.draw(canvas);

        for (int i = 0; i < COUNT; i++) {
            float life = (t * rate[i] + offset[i]) % 1f;
            float ang = base[i] + t * spin[i];
            float rad = w * (0.40f + 0.09f * life);
            float px = cx + (float) Math.cos(ang) * rad;
            float py = cy + (float) Math.sin(ang) * rad;
            float fade = (float) Math.sin(Math.PI * life); // 0 at birth and death, 1 in the middle
            float twinkle = 0.65f + 0.35f * (float) Math.sin(t * 3f + i * 1.7f);
            float a = fade * twinkle;
            float size = density * 1.3f * dot[i] * (1.1f - 0.4f * life);

            paint.setColor((0xFF << 24) | rgb);
            paint.setAlpha((int) (50 * a));
            canvas.drawCircle(px, py, size * 3.2f, paint); // soft halo
            paint.setAlpha((int) (255 * a));
            canvas.drawCircle(px, py, size, paint);        // bright core
        }
    }

    @Override
    public boolean setVisible(boolean visible, boolean restart) {
        boolean changed = super.setVisible(visible, restart);
        if (visible) {
            Ticker.add(this);
        } else {
            Ticker.remove(this);
        }
        return changed;
    }

    @Override
    public void setAlpha(int alpha) {
        // the glow draws its own transparency
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        // the glow keeps its own colors
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    /** One shared timer redraws every visible icon about 30 times a second, and stops when none are on screen. */
    private static final class Ticker {
        private static final List<ParticleGlow> LIVE = new ArrayList<>();
        private static final Handler HANDLER = new Handler(Looper.getMainLooper());
        private static boolean running;

        private static final Runnable STEP = new Runnable() {
            @Override
            public void run() {
                for (int i = LIVE.size() - 1; i >= 0; i--) {
                    ParticleGlow d = LIVE.get(i);
                    if (d.getCallback() == null) {
                        LIVE.remove(i); // its view is gone
                    } else {
                        d.invalidateSelf();
                    }
                }
                if (LIVE.isEmpty()) {
                    running = false;
                } else {
                    HANDLER.postDelayed(this, 33);
                }
            }
        };

        static void add(ParticleGlow d) {
            if (!LIVE.contains(d)) {
                LIVE.add(d);
            }
            if (!running) {
                running = true;
                HANDLER.postDelayed(STEP, 33);
            }
        }

        static void remove(ParticleGlow d) {
            LIVE.remove(d);
        }
    }
}
