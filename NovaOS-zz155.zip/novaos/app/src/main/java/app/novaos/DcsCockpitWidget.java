package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * DCS COCKPIT: one widget with swipeable pages fed by live DCS data (see DcsLink and the PC script NovaExport.lua).
 * THROTTLE (thrust lever + main buttons), AIRCRAFT (your jet with moving parts coloured), CARRIER (side view and lineup),
 * RADAR (everything around you), TARGET (your lock) and FLIGHT (all the numbers). In AUTO it shows the page that fits
 * what you are doing; swipe to choose yourself. SIM flies a made-up mission so everything can be tried without DCS.
 */
final class DcsCockpitWidget extends NovaWidget {
    private static final String[] PAGES = {"THROTTLE", "AIRCRAFT", "CARRIER", "RADAR", "TARGET", "HUD", "MAP", "AUTOPILOT", "HSI",
        "NAV", "ADI", "ENGINE", "FUEL", "WARNINGS", "RWR", "STORES", "CMS", "GUN", "TIMER", "LSO", "CASE I", "G-METER", "TAPES",
        "TANKER", "LOG", "KNEEBOARD", "CLOCK"};
    private static final int P_MAP = 6;
    private static final int P_AP = 7;
    private static final int P_HSI = 8;
    private static final int P_NAV = 9;
    private static final int P_THROTTLE = 0;
    private static final int P_PLANE = 1;
    private static final int P_CARRIER = 2;
    private static final int P_RADAR = 3;
    private static final int P_TARGET = 4;
    private static final int P_FLIGHT = 5;
    private static final String K_AUTO = "dcs_auto";
    private static final String K_PAGE = "dcs_page";
    private static final String K_THR = "dcs_throttle";
    private static final String K_THR_MODE = "dcs_thr_mode";
    private static final String K_RANGE = "dcs_radar_nm";
    private static final String K_VOICE = "dcs_voice";
    private static final int GREEN = 0xFF30D158;
    private static final int AMBER = 0xFFFFB020;
    private static final int RED = 0xFFFF453A;
    private static final int BLUE = 0xFF0A84FF;

    private final boolean big;
    private int[] order;
    private final boolean full;
    private TextView title;
    private final TextView[] favs = new TextView[4];
    private final int[] favDef = new int[4];
    private final TextView status;
    private final TextView autoChip;
    private final TextView simChip;
    private final Pager pager;
    private final LinearLayout dots;
    private int page;
    private long manualUntil;
    private final java.util.Map<Integer, View> views = new java.util.HashMap<>();
    private LinearLayout freeRow;
    private TextView stickInfo;
    private android.hardware.SensorManager sensors;
    private float roll0 = Float.NaN;
    private float pitch0 = Float.NaN;
    private float rollNow;
    private float pitchNow;
    private boolean touchStick;
    private String lastEvent = "";
    private final android.hardware.SensorEventListener tilt = new android.hardware.SensorEventListener() {
        @Override
        public void onSensorChanged(android.hardware.SensorEvent e) {
            float x = e.values[0];
            float y = e.values[1];
            float z = e.values[2];
            rollNow = (float) Math.toDegrees(Math.atan2(x, z));
            pitchNow = (float) Math.toDegrees(Math.atan2(y, z));
            if (Float.isNaN(roll0)) {
                roll0 = rollNow;
                pitch0 = pitchNow;
            }
            if (touchStick) {
                return;
            }
            DcsLink.stickX = stick(-(rollNow - roll0) / 30f);
            DcsLink.stickY = stick((pitchNow - pitch0) / 25f);
        }

        @Override
        public void onAccuracyChanged(android.hardware.Sensor s, int a) {
        }
    };

    private static float stick(float v) {
        v = Math.max(-1, Math.min(1, v));
        return Math.abs(v) < 0.08f ? 0 : v;
    }

    private void center() {
        roll0 = rollNow;
        pitch0 = pitchNow;
        DcsLink.stickX = 0;
        DcsLink.stickY = 0;
    }

    private void simMenu() {
        String[] items = {"\u25B6 AUTO: watch a whole flight (start-up, fight, carrier landing)",
            "\u2708 FREE: fly it yourself (tilt the phone, thrust lever, buttons)", "\u25A0 SIM off"};
        new AlertDialog.Builder(host).setTitle("SIM").setItems(items, (d, w) -> {
            if (w == 0) {
                DcsLink.setSim(1);
                host.toast("AUTO SIM: try every page and button");
            } else if (w == 1) {
                DcsLink.setSim(2);
                roll0 = Float.NaN;
                show(P_CARRIER);
                manualUntil = 0;
                new AlertDialog.Builder(host).setTitle("FREE SIM")
                        .setMessage("You start 4 nm behind the carrier at 1500 ft.\n\n"
                                + "\u2022 Tilt the phone left / right to roll, back to pull up, forward to push down "
                                + "(or drag on the FLIGHT page).\n\u2022 Thrust lever on the THROTTLE page.\n"
                                + "\u2022 GEAR, FLAPS, HOOK, AIRBRAKE buttons work.\n\u2022 Land on the angled deck with gear and "
                                + "hook down to catch a wire. CENTER STICK sets your phone's neutral, RESET starts again.\n\n"
                                + "Hold the phone how you like it now, it becomes neutral.")
                        .setPositiveButton("GO", (dd, ww) -> center()).show();
            } else {
                DcsLink.setSim(0);
                host.toast("SIM off");
            }
            sensorsOn(DcsLink.simMode == 2);
            refresh();
        }).show();
    }

    private void sensorsOn(boolean on) {
        if (sensors == null) {
            sensors = (android.hardware.SensorManager) host.getSystemService(android.content.Context.SENSOR_SERVICE);
        }
        if (sensors == null) {
            return;
        }
        sensors.unregisterListener(tilt);
        if (on) {
            android.hardware.Sensor g = sensors.getDefaultSensor(android.hardware.Sensor.TYPE_GRAVITY);
            if (g == null) {
                g = sensors.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER);
            }
            if (g != null) {
                sensors.registerListener(tilt, g, android.hardware.SensorManager.SENSOR_DELAY_GAME);
            }
        }
    }
    private final List<Object[]> lit = new ArrayList<>();
    private final Runnable onData = this::data;
    private TextToSpeech tts;
    private long lastSay;
    private boolean ballCalled;
    private float lastFuel = -1;
    private long lastFuelAt;
    private float burn;

    DcsCockpitWidget(NovaActivity host) {
        this(host, false);
    }

    DcsCockpitWidget(NovaActivity host, boolean big) {
        this(host, big, null);
    }

    /** pages = which pages this widget shows (DCS AUTOPILOT uses a few), null = all of them. */
    DcsCockpitWidget(NovaActivity host, boolean big, int[] pages) {
        super(host);
        this.big = big;
        this.full = pages == null;
        if (pages == null) {
            pages = new int[PAGES.length];
            for (int i = 0; i < pages.length; i++) {
                pages[i] = i;
            }
        }
        this.order = pages;
        rebuildOrder();
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setSingleLine(true);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        autoChip = osb("AUTO", () -> {
            boolean on = !Prefs.getBool(K_AUTO, true);
            Prefs.putBool(K_AUTO, on);
            manualUntil = 0;
            refresh();
            data();
        });
        simChip = osb("SIM", this::simMenu);
        top.addView(chip("SETUP", this::setup), margin());
        if (!big) {
            top.addView(chip("⤢", this::openBig), margin());
        }
        addView(top, wide());
        freeRow = row();
        freeRow.setGravity(Gravity.CENTER_VERTICAL);
        stickInfo = text("", 9f, Theme.DIM);
        stickInfo.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        freeRow.addView(stickInfo, weight(1f));
        freeRow.addView(chip("\u25CE CENTER STICK", this::center), margin());
        freeRow.addView(chip("\u27F2 RESET", () -> {
            DcsLink.resetFree();
            center();
            host.toast("Back behind the carrier");
        }), margin());
        addView(freeRow, wide());
        dots = null;
        // the MFD: a metal bezel with push buttons on top and bottom around the screen
        Bezel bezel = new Bezel();
        bezel.setOrientation(VERTICAL);
        bezel.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout topRow = row();
        int[] defFav = order.length >= 4 ? new int[] {order[0], order[1], order[2], order[3]} : new int[] {order[0], order[0], order[0], order[0]};
        if (full) {
            defFav = new int[] {P_THROTTLE, P_CARRIER, P_RADAR, P_MAP};
        }
        for (int i = 0; i < 4; i++) {
            final int slot = i;
            final int def = defFav[i];
            favDef[i] = def;
            favs[i] = osb("", () -> manual(fav(slot, def)));
            favs[i].setOnLongClickListener(v -> {
                pickFav(slot);
                return true;
            });
            topRow.addView(favs[i], osbLp());
        }
        topRow.addView(osb("MENU", this::menu), osbLp());
        if (full) {
            topRow.addView(osb("\uFF0B", this::newPage), osbLp());
        }
        bezel.addView(topRow, wide());
        title = text("", 10f, HUD);
        title.setPadding(0, dp(3), 0, dp(3));
        bezel.addView(title, wide());
        pager = new Pager();
        int h = big ? (int) (getResources().getDisplayMetrics().heightPixels * 0.66f) : dp(330);
        bezel.addView(pager, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, h));
        LinearLayout botRow = row();
        botRow.addView(osb("\u25C0", () -> step(-1)), osbLp());
        botRow.addView(autoChip, osbLp());
        botRow.addView(simChip, osbLp());
        botRow.addView(osb("BRT", () -> {
            int b = (Prefs.getInt("dcs_brt", 0) + 1) % 3;
            Prefs.putInt("dcs_brt", b);
            pager.setAlpha(new float[] {1f, 0.7f, 0.45f}[b]);
        }), osbLp());
        botRow.addView(osb("\u25B6", () -> step(1)), osbLp());
        bezel.addView(botRow, wide());
        addView(bezel, wide());
        pager.setAlpha(new float[] {1f, 0.7f, 0.45f}[Math.max(0, Math.min(2, Prefs.getInt("dcs_brt", 0)))]);
        int want = Prefs.getInt(K_PAGE + (full ? "" : "_" + order[0]), order[0]);
        page = order[0];
        for (int id : order) {
            if (id == want) {
                page = want;
            }
        }
        show(page);
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        return lp;
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            DcsLink.start(host);
            DcsLink.listen(onData);
            if (PcHid.hid == null && android.os.Build.VERSION.SDK_INT >= 28
                    && (android.os.Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                    android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
                PcHid.start(host);
            }
            sensorsOn(DcsLink.simMode == 2);
            refresh();
        } else {
            DcsLink.unlisten(onData);
            DcsLink.stop();
            sensorsOn(false);
        }
    }

    @Override
    long tickMs() {
        return 1000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        DcsLink.State s = DcsLink.st;
        String src = DcsLink.simMode == 2 ? "\u25CF FREE SIM" : DcsLink.sim ? "\u25CF AUTO SIM" : DcsLink.live() ? "\u25CF DCS"
                : "\u25CB waiting for DCS";
        freeRow.setVisibility(DcsLink.simMode == 2 ? VISIBLE : GONE);
        status.setText(src + (DcsLink.live() && !s.name.isEmpty() ? "  " + nice(s.name) : "")
                + (PcHid.connected() ? "  · keys ✔" : "  · keys ✖"));
        status.setTextColor(DcsLink.live() ? GREEN : Theme.DIM);
        boolean auto = Prefs.getBool(K_AUTO, true);
        osbOn(autoChip, auto, auto ? (SystemClock.uptimeMillis() < manualUntil ? "AUTO \u23F8" : "AUTO") : "MANUAL");
        osbOn(simChip, DcsLink.sim, DcsLink.simMode == 2 ? "SIM FREE" : DcsLink.sim ? "SIM AUTO" : "SIM");
    }

    static String nice(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("FA-18") || u.contains("F/A-18")) {
            return "F/A-18C";
        }
        return n.replace("_", " ");
    }

    /** hornet, flanker, frogfoot or other. */
    static String family(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("18")) {
            return "hornet";
        }
        if (u.contains("SU-27") || u.contains("SU-33") || u.contains("J-11") || u.contains("SU-30")) {
            return "flanker";
        }
        if (u.contains("SU-25")) {
            return "frogfoot";
        }
        return u.isEmpty() ? "hornet" : "other";
    }

    // ------------------------------------------------------------------ pages and swiping

    private final class Pager extends FrameLayout {
        private float sx;
        private float sy;
        private boolean swiping;
        private final int slop = ViewConfiguration.get(host).getScaledTouchSlop();

        Pager() {
            super(host);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getX();
                    sy = e.getY();
                    swiping = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (editing) {
                        return false;
                    }
                    float dx = e.getX() - sx;
                    float dy = e.getY() - sy;
                    if (!swiping && Math.abs(dx) > slop * 3 && Math.abs(dx) > Math.abs(dy) * 1.6f
                            && !(page == P_THROTTLE && sx < getWidth() * 0.45f && sy < getHeight() * 0.5f)) {
                        swiping = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    }
                    return false;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP && swiping) {
                float dx = e.getX() - sx;
                step(dx < 0 ? 1 : -1);
                swiping = false;
            }
            return true;
        }
    }

    private void manual(int p) {
        manualUntil = SystemClock.uptimeMillis() + 30000;
        show(p);
        refresh();
    }

    private int idx(int id) {
        for (int i = 0; i < order.length; i++) {
            if (order[i] == id) {
                return i;
            }
        }
        return -1;
    }

    private void step(int d) {
        int i = Math.max(0, idx(page));
        manual(order[(i + d + order.length) % order.length]);
    }

    private void show(int p) {
        if (idx(p) < 0) {
            return;
        }
        if (p != page) {
            editing = false;
        }
        page = p;
        Prefs.putInt(K_PAGE + (full ? "" : "_" + order[0]), p);
        pager.removeAllViews();
        View v = views.get(p);
        if (v == null) {
            v = make(p);
            views.put(p, v);
        }
        if (v.getParent() != null) {
            ((android.view.ViewGroup) v.getParent()).removeView(v);
        }
        pager.addView(v, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        title.setText("\u25C0  " + name(p) + "  \u00B7  " + (idx(p) + 1) + "/" + order.length + "  \u25B6");
        for (int i = 0; i < 4; i++) {
            if (favs[i] != null) {
                favs[i].setText(name(fav(i, favDef[i])));
            }
        }
        v.invalidate();
    }

    // ------------------------------------------------------------------ bezel, push buttons, menu, favourites

    private final class Bezel extends LinearLayout {
        private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);

        Bezel() {
            super(host);
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            bp.setShader(new android.graphics.LinearGradient(0, 0, w, h, new int[] {0xFF3A3F47, 0xFF23272D, 0xFF2E3238}, null,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(0, 0, w, h), dp(14), dp(14), bp);
            bp.setShader(null);
            bp.setColor(0x22FFFFFF);
            c.drawRoundRect(new RectF(dp(1), dp(1), w - dp(1), dp(4)), dp(6), dp(6), bp);
            bp.setColor(0xFF15171B);
            for (float[] sc : new float[][] {{dp(7), dp(7)}, {w - dp(7), dp(7)}, {dp(7), h - dp(7)}, {w - dp(7), h - dp(7)}}) {
                c.drawCircle(sc[0], sc[1], dp(2.5f), bp);
            }
        }
    }

    private TextView osb(String label, Runnable r) {
        TextView b = text(label, 9.5f, HUD);
        b.setSingleLine(true);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(2), dp(8), dp(2), dp(8));
        b.setBackground(Theme.rounded(0xFF121519, 6f, host));
        b.setClickable(true);
        b.setOnClickListener(v -> {
            host.buzz(8);
            r.run();
        });
        return b;
    }

    private LinearLayout.LayoutParams osbLp() {
        LinearLayout.LayoutParams lp = weight(1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private void osbOn(TextView b, boolean on, String label) {
        b.setText(label);
        b.setTextColor(on ? 0xFF000000 : HUD);
        b.setBackground(Theme.rounded(on ? HUD : 0xFF121519, 6f, host));
    }

    private int fav(int slot, int def) {
        String k = "dcs_fav" + slot + (full ? "" : "_" + order[0]);
        int v = Prefs.getInt(k, def);
        return v >= 0 && idx(v) >= 0 ? v : def;
    }

    private void pickFav(final int slot) {
        String[] names = new String[order.length];
        for (int i = 0; i < order.length; i++) {
            names[i] = name(order[i]);
        }
        new AlertDialog.Builder(host).setTitle("Button " + (slot + 1) + " opens").setItems(names, (d, w) -> {
            Prefs.putInt("dcs_fav" + slot + (full ? "" : "_" + order[0]), order[w]);
            show(page);
        }).show();
    }

    private void menu() {
        String[] names = new String[order.length + 1];
        for (int i = 0; i < order.length; i++) {
            names[i] = (order[i] == page ? "\u25CF " : "   ") + (i + 1) + ".  " + name(order[i]);
        }
        names[order.length] = "\u2605 Set the 4 top buttons (hold one to change it)";
        new AlertDialog.Builder(host).setTitle("Pages").setItems(names, (d, w) -> {
            if (w < order.length) {
                manual(order[w]);
            } else {
                pickFav(0);
            }
        }).show();
    }

    private View make(int p) {
        if (p >= 100) {
            return new CustomPage(p);
        }
        switch (p) {
            case P_THROTTLE:
                return throttlePage();
            case P_PLANE:
                return new PlaneView();
            case P_CARRIER:
                return new CarrierView();
            case P_RADAR:
                return new RadarView();
            case P_TARGET:
                return new TargetView();
            case P_FLIGHT:
                return new FlightView();
            case P_MAP:
                return new MapView();
            case P_AP:
                return autopilotPage();
            case P_HSI:
                return new HsiView();
            case P_NAV:
                return new NavView();
            case 10:
                return new AdiView();
            case 11:
                return new EngineView();
            case 12:
                return new FuelView();
            case 13:
                return new WarnView();
            case 14:
                return new RwrView();
            case 15:
                return new StoresView();
            case 16:
                return cmsPage();
            case 17:
                return gunPage();
            case 18:
                return timerPage();
            case 19:
                return new LsoView();
            case 20:
                return new CaseView();
            case 21:
                return new GView();
            case 22:
                return new TapesView();
            case 23:
                return new TankerView();
            case 24:
                return new LogView();
            case 25:
                return kneePage();
            default:
                return new ClockView();
        }
    }

    /** New data: pick the page in AUTO, redraw, light the buttons, carrier calls. */
    private void data() {
        DcsLink.State s = DcsLink.st;
        if (DcsLink.live() && Prefs.getBool(K_AUTO, true) && SystemClock.uptimeMillis() > manualUntil) {
            int want = choose(s);
            if (want != page && idx(want) >= 0) {
                show(want);
            }
        }
        View cur = views.get(page);
        if (cur instanceof CustomPage) {
            invalidateAll(cur);
        } else if (cur != null) {
            cur.invalidate();
        }
        for (Object[] l : litCustom) {
            light((TextView) l[0], (int) l[1], (float) l[2]);
        }
        if (btnGrid != null && !fam().equals(builtFam)) {
            fillButtons(btnGrid);
        }
        for (Object[] l : lit) {
            light((TextView) l[0], (int) l[1], (float) l[2]);
        }
        // fuel burn per minute, for "minutes left"
        long now = SystemClock.elapsedRealtime();
        float fuel = s.fuel + s.fuelExt;
        if (lastFuel < 0 || now - lastFuelAt > 10000) {
            if (lastFuel >= 0 && now - lastFuelAt < 60000) {
                float perMin = (lastFuel - fuel) / ((now - lastFuelAt) / 60000f);
                burn = burn == 0 ? perMin : burn * 0.6f + perMin * 0.4f;
            }
            lastFuel = fuel;
            lastFuelAt = now;
        }
        calls(s);
        if (DcsLink.simMode == 2) {
            stickInfo.setText(String.format(Locale.ROOT, "STICK  roll %+.0f%%  pitch %+.0f%%%s", DcsLink.stickX * 100,
                    DcsLink.stickY * 100, touchStick ? "  (touch)" : "  (tilt)"));
            String ev = DcsLink.event;
            if (!ev.isEmpty() && !ev.equals(lastEvent)) {
                host.toast(ev);
                host.buzz(ev.startsWith("TRAP") ? 120 : 250);
                say(ev.replace("\u2605", "").replace(":", ","));
            }
            lastEvent = ev;
        }
    }

    private int choose(DcsLink.State s) {
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap != null && ap[0] > 0 && ap[0] < 9000 && Math.abs(ap[4]) < 25 && s.alt < 1200 && (s.gear > 0.5f || s.hook > 0.5f)) {
            return P_CARRIER;
        }
        if (s.lockDist > 0) {
            return P_TARGET;
        }
        for (DcsLink.Obj o : DcsLink.objs) {
            if (o.cat == 1 && o.coal != 0 && o.coal != s.coal && Math.hypot(o.x - s.x, o.z - s.z) < 37000) {
                return P_RADAR;
            }
        }
        if (s.agl < 5 && s.ias < 60) {
            return P_THROTTLE;
        }
        return P_FLIGHT;
    }

    private void calls(DcsLink.State s) {
        if (!Prefs.getBool(K_VOICE, true)) {
            return;
        }
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap == null || ap[0] <= 0 || ap[0] > 9000 || s.gear < 0.5f) {
            ballCalled = false;
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (!ballCalled && ap[0] < 1400) {
            ballCalled = true;
            say("three quarter mile, call the ball");
        } else if (ap[0] < 3000 && now - lastSay > 4000) {
            if (ap[4] > 1.5) {
                say("right of line up");
            } else if (ap[4] < -1.5) {
                say("left of line up");
            } else if (ap[3] > 0.7) {
                say("high");
            } else if (ap[3] < -0.7) {
                say("low, power");
            }
        }
    }

    private void say(String text) {
        lastSay = SystemClock.uptimeMillis();
        if (tts == null) {
            tts = new TextToSpeech(host.getApplicationContext(), st -> {
                if (st == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.US);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
                }
            });
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
    }

    // ------------------------------------------------------------------ THROTTLE page

    /** {label, key spec, part (0 gear 1 flaps 2 airbrake 3 hook 4 canopy, -1 none), sim value (-1 toggle), hold}. */
    static Object[][] buttons(String fam) {
        if (fam.equals("hornet")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS HALF", "LSHIFT+F", 1, 0.5f, false},
                {"FLAPS FULL", "LCTRL+F", 1, 1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"HOOK", "LCTRL+H", 3, -1f, false}, {"WHEEL BRAKE", "W", -1, -1f, true},
                {"GUN", "LSHIFT+X", -1, -1f, false}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
                {"AUTO START", "LWIN+HOME", -1, -1f, false}, {"EJECT", "x3:LCTRL+E", -1, -1f, false},
            };
        }
        if (fam.equals("frogfoot")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"GUN", "C", -1, -1f, false}, {"NEXT WEAPON", "D", -1, -1f, false}, {"FIRE", "SPACE", -1, -1f, true},
                {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"SHKVAL", "O", -1, -1f, false}, {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false},
                {"FLARE", "DEL", -1, -1f, false},
            };
        }
        return new Object[][] {
            {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
            {"GUN", "C", -1, -1f, false}, {"MISSILE", "D", -1, -1f, false}, {"FIRE GUN", "SPACE", -1, -1f, true},
            {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false}, {"RADAR", "I", -1, -1f, false},
            {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
        };
    }

    private String fam() {
        return family(DcsLink.st.name);
    }

    private View throttlePage() {
        final LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        LinearLayout topHalf = row();
        final Lever lever = new Lever();
        topHalf.addView(lever, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        final TextView info = text("", 11f, Theme.TEXT);
        info.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        topHalf.addView(info, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        lever.info = info;
        col.addView(topHalf, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        final LinearLayout grid = new LinearLayout(host);
        grid.setOrientation(VERTICAL);
        fillButtons(grid);
        col.addView(grid, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        col.setTag(grid);
        return col;
    }

    private String btnKey(String fam, int i, String def) {
        return Prefs.getString("dcsbtn_" + fam + "_" + i, def);
    }

    private String builtFam = "";
    private LinearLayout btnGrid;

    private void fillButtons(final LinearLayout grid) {
        btnGrid = grid;
        builtFam = fam();
        grid.removeAllViews();
        lit.clear();
        final String fam = fam();
        final Object[][] b = buttons(fam);
        LinearLayout r = null;
        for (int i = 0; i < b.length; i++) {
            if (i % 3 == 0) {
                r = row();
                grid.addView(r, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
            }
            final int idx = i;
            final Object[] d = b[i];
            String saved = btnKey(fam, i, d[0] + "|" + d[1]);
            final String label = saved.contains("|") ? saved.substring(0, saved.indexOf('|')) : (String) d[0];
            final String spec = saved.contains("|") ? saved.substring(saved.indexOf('|') + 1) : (String) d[1];
            final TextView t = text(label + "\n" + DcsKeysWidget.pretty(DcsLink.mine(spec)), big ? 12f : 10f, 0xFFFFFFFF);
            t.setGravity(Gravity.CENTER);
            t.setBackground(Theme.rounded(0x33FFFFFF, 12f, host));
            final int part = (int) d[2];
            final boolean hold = (boolean) d[4];
            t.setOnTouchListener((v, e) -> {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setTag(SystemClock.uptimeMillis());
                    v.setAlpha(0.6f);
                    host.buzz(10);
                    if (hold) {
                        press(spec, part, (float) d[3], true, true);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1f);
                    long held = SystemClock.uptimeMillis() - (long) v.getTag();
                    if (hold) {
                        press(spec, part, (float) d[3], false, true);
                    } else if (a == MotionEvent.ACTION_UP && held > 700) {
                        editButton(grid, fam, idx, label, spec);
                    } else if (a == MotionEvent.ACTION_UP) {
                        press(spec, part, (float) d[3], true, false);
                    }
                }
                return true;
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(t, p);
            if (part >= 0) {
                lit.add(new Object[] {t, part, (float) d[3]});
            }
        }
        TextView hint = text("Hold a button 1 s to change its key · keys are DCS names (US positions)", 8.5f, Theme.DIM);
        grid.addView(hint, wide());
    }

    private void press(String spec, int part, float simValue, boolean down, boolean holdMode) {
        if (DcsLink.sim) {
            if (part >= 0 && down) {
                DcsLink.simPress(part, simValue);
            }
            return;
        }
        if (!PcHid.connected()) {
            if (down) {
                host.toast("Not connected: tap CONNECT in KEY DECK or PC REMOTE (or try SIM)");
            }
            return;
        }
        if (down && DcsLink.unbound(spec)) {
            host.toast("You have no key for this in DCS (you removed " + DcsKeysWidget.pretty(spec) + "). Bind one in DCS");
        }
        Object[] k = DcsKeysWidget.parse(DcsLink.mine(spec));
        int code = PcHid.rawCode((String) k[1]);
        if (holdMode) {
            PcHid.hold((int) k[0], code, down);
        } else {
            PcHid.tap((int) k[0], code, (int) k[2], 40);
        }
    }

    private void editButton(final LinearLayout grid, final String fam, final int i, String label, String spec) {
        LinearLayout f = new LinearLayout(host);
        f.setOrientation(VERTICAL);
        f.setPadding(dp(18), dp(6), dp(18), 0);
        final EditText name = new EditText(host);
        name.setText(label);
        name.setHint("Name");
        name.setSingleLine(true);
        f.addView(name);
        final EditText key = new EditText(host);
        key.setText(spec);
        key.setHint("Key, e.g. G, LCTRL+H, RALT+SPACE, x3:LCTRL+E");
        key.setSingleLine(true);
        f.addView(key);
        new AlertDialog.Builder(host).setTitle("Button for " + fam)
                .setView(f)
                .setPositiveButton("SAVE", (d, w) -> {
                    String k = key.getText().toString().trim().toUpperCase(Locale.ROOT);
                    Object[] p = DcsKeysWidget.parse(k.isEmpty() ? "G" : k);
                    if (PcHid.rawCode((String) p[1]) == 0) {
                        host.toast("Unknown key: " + p[1]);
                        return;
                    }
                    Prefs.putString("dcsbtn_" + fam + "_" + i, name.getText().toString().trim().toUpperCase(Locale.ROOT) + "|" + k);
                    fillButtons(grid);
                })
                .setNeutralButton("DEFAULT", (d, w) -> {
                    Prefs.remove("dcsbtn_" + fam + "_" + i);
                    fillButtons(grid);
                })
                .setNegativeButton("CANCEL", null).show();
    }

    private void light(TextView t, int part, float simValue) {
        DcsLink.State s = DcsLink.st;
        float v = part == 0 ? s.gear : part == 1 ? s.flaps : part == 2 ? s.brake : part == 3 ? s.hook : s.canopy;
        int c;
        if (part == 1 && simValue > 0 && simValue < 1) {
            c = Math.abs(v - 0.5f) < 0.15f ? GREEN : 0x33FFFFFF;
        } else if (part == 1 && simValue >= 1) {
            c = v > 0.9f ? GREEN : 0x33FFFFFF;
        } else {
            c = v > 0.95f ? GREEN : v > 0.05f ? AMBER : 0x33FFFFFF;
        }
        if (!DcsLink.live()) {
            c = 0x33FFFFFF;
        }
        t.setBackground(Theme.rounded(c == 0x33FFFFFF ? c : (c & 0x00FFFFFF) | 0xAA000000, 12f, host));
    }

    /** The thrust lever: drag up and down. MIL at 80 %, afterburner above. */
    private final class Lever extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float value = Prefs.getInt(K_THR, 0) / 1000f;
        TextView info;
        private float sent = -1;
        private float est;
        private final Runnable keyLoop = new Runnable() {
            @Override
            public void run() {
                int plus = PcHid.rawCode("KPPLUS");
                int minus = PcHid.rawCode("KPMINUS");
                if (value > est + 0.02f) {
                    PcHid.hold(0, minus, false);
                    PcHid.hold(0, plus, true);
                    est += 0.012f;
                    postDelayed(this, 40);
                } else if (value < est - 0.02f) {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, true);
                    est -= 0.012f;
                    postDelayed(this, 40);
                } else {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, false);
                }
            }
        };

        Lever() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float top = dp(10);
            float bot = h - dp(10);
            float cx = w / 2f;
            float tw = Math.min(w * 0.36f, dp(64));
            // the throttle quadrant: a dark slot in a metal plate, a gate at MIL, an afterburner zone
            float plateL = cx - tw / 2 - dp(10);
            float plateR = cx + tw / 2 + dp(10);
            p.setShader(new android.graphics.LinearGradient(plateL, 0, plateR, 0,
                    new int[] {0xFF2A2D33, 0xFF41454D, 0xFF24272C}, null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(plateL, top - dp(6), plateR, bot + dp(6)), dp(8), dp(8), p);
            p.setShader(null);
            // screws
            p.setColor(0xFF15171A);
            for (float sy0 : new float[] {top, bot}) {
                c.drawCircle(plateL + dp(5), sy0, dp(2), p);
                c.drawCircle(plateR - dp(5), sy0, dp(2), p);
            }
            float slotW = dp(8);
            p.setColor(0xFF07080A);
            c.drawRoundRect(new RectF(cx - slotW / 2, top, cx + slotW / 2, bot), dp(4), dp(4), p);
            float mil = bot - (bot - top) * 0.8f;
            // afterburner zone in orange, the gate as a bright bar
            p.setColor(0x55FF7A00);
            c.drawRoundRect(new RectF(cx - slotW / 2, top, cx + slotW / 2, mil), dp(4), dp(4), p);
            p.setColor(0xFFB8BEC6);
            c.drawRect(plateL + dp(2), mil - dp(1.5f), plateR - dp(2), mil + dp(1.5f), p);
            // scale marks
            p.setColor(0x88FFFFFF);
            p.setStrokeWidth(dp(1));
            for (int i = 0; i <= 10; i++) {
                float my = bot - (bot - top) * i / 10f;
                c.drawLine(plateR - dp(8), my, plateR - dp(3), my, p);
            }
            p.setColor(Theme.DIM);
            p.setTextSize(dp(9));
            p.setTypeface(Theme.MONO);
            p.setColor(0xFFFF9F40);
            c.drawText("AB", plateR + dp(4), top + dp(10), p);
            p.setColor(0xFFDDE2E8);
            c.drawText("MIL", plateR + dp(4), mil + dp(3), p);
            c.drawText("IDLE", plateR + dp(4), bot, p);
            // the grip: a rounded metal handle with finger ridges and a red AB light when past the gate
            float y = bot - (bot - top) * value;
            float gw = tw + dp(14);
            float gh = dp(34);
            RectF grip = new RectF(cx - gw / 2, y - gh / 2, cx + gw / 2, y + gh / 2);
            p.setShadowLayer(dp(6), 0, dp(3), 0x99000000);
            p.setShader(new android.graphics.LinearGradient(0, grip.top, 0, grip.bottom,
                    new int[] {0xFF5B616B, 0xFF2F333A, 0xFF1C1F24}, null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(grip, dp(12), dp(12), p);
            p.setShader(null);
            p.clearShadowLayer();
            p.setColor(0x33FFFFFF);
            c.drawRoundRect(new RectF(grip.left + dp(3), grip.top + dp(2), grip.right - dp(3), grip.top + dp(8)), dp(6), dp(6), p);
            p.setColor(0x66000000);
            for (int i = 1; i <= 4; i++) {
                float rx = grip.left + gw * i / 5f;
                c.drawRect(rx - dp(1), grip.top + dp(10), rx + dp(1), grip.bottom - dp(6), p);
            }
            p.setColor(value > 0.8f ? 0xFFFF5A1F : 0xFF30D158);
            p.setShadowLayer(dp(5), 0, 0, value > 0.8f ? 0xFFFF5A1F : 0xFF30D158);
            c.drawCircle(grip.right - dp(9), grip.centerY(), dp(3.5f), p);
            p.clearShadowLayer();
            p.setColor(0xFFFFFFFF);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(11));
            c.drawText(Math.round(value * 100) + "%", cx - dp(4), y + dp(4), p);
            p.setTextAlign(Paint.Align.LEFT);
            if (info != null) {
                DcsLink.State s = DcsLink.st;
                boolean axis = Prefs.getInt(K_THR_MODE, 0) == 0;
                info.setText("THRUST " + Math.round(value * 100) + "%" + (value > 0.8f ? "  AB" : value > 0.78f ? "  MIL" : "")
                        + "\n" + (DcsLink.live() ? Math.round(s.ias * 1.94384f) + " kt  ·  RPM " + Math.round(Math.max(s.rpmL, s.rpmR))
                        + "%" : "no DCS data")
                        + "\n\nMode: " + (axis ? "AXIS (bind Thrust to NOVA Remote Z)" : "KEYS (Num+ / Num−)")
                        + "\ntap here to switch");
                info.setOnClickListener(v -> {
                    Prefs.putInt(K_THR_MODE, axis ? 1 : 0);
                    invalidate();
                });
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float top = dp(10);
                float bot = getHeight() - dp(10);
                float old = value;
                value = Math.max(0, Math.min(1, (bot - e.getY()) / (bot - top)));
                if ((old <= 0.8f) != (value <= 0.8f)) {
                    host.buzz(35);
                }
                apply();
                invalidate();
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                Prefs.putInt(K_THR, Math.round(value * 1000));
            }
            return true;
        }

        private void apply() {
            DcsLink.throttle = value;
            if (DcsLink.sim || !PcHid.connected()) {
                return;
            }
            if (Prefs.getInt(K_THR_MODE, 0) == 0) {
                if (Math.abs(value - sent) > 0.004f) {
                    sent = value;
                    PcHid.axis(value);
                }
            } else {
                removeCallbacks(keyLoop);
                post(keyLoop);
            }
        }
    }

    // ------------------------------------------------------------------ AIRCRAFT page

    private static final int HUD = 0xFF3CFF7A;
    private static final int PHOS = 0xFF35FF6A;

    private static float[] mirror(float[] pts) {
        float[] m = pts.clone();
        for (int i = 0; i < m.length; i += 2) {
            m[i] = -m[i];
        }
        return m;
    }

    /** Your aircraft from above, in its real paint: red = fully out, blue = partly out, normal = in. */
    private final class PlaneView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneView() {
            super(host);
        }

        private Path poly(float[] pts, float cx, float oy, float sc, boolean mirrorIt) {
            Path path = new Path();
            for (int i = 0; i < pts.length; i += 2) {
                float x = cx + pts[i] * sc;
                float y = oy + pts[i + 1] * sc;
                if (i == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            if (mirrorIt) {
                for (int i = pts.length - 2; i >= 0; i -= 2) {
                    path.lineTo(cx - pts[i] * sc, oy + pts[i + 1] * sc);
                }
            }
            path.close();
            return path;
        }

        /** A moving part: in its normal colour when in, tinted and glowing when out. */
        private void part(Canvas c, float[] pts, float cx, float oy, float sc, float v, boolean both, int skin) {
            for (int k = 0; k < (both ? 2 : 1); k++) {
                Path path = poly(k == 0 ? pts : mirror(pts), cx, oy, sc, false);
                p.setStyle(Paint.Style.FILL);
                if (v > 0.05f) {
                    int col = v > 0.95f ? RED : BLUE;
                    p.setShadowLayer(dp(7), 0, 0, col);
                    p.setColor((col & 0x00FFFFFF) | 0xE6000000);
                    c.drawPath(path, p);
                    p.clearShadowLayer();
                } else {
                    p.setColor(skin);
                    c.drawPath(path, p);
                }
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(0.9f));
                p.setColor(v > 0.05f ? 0xFFFFFFFF : 0x66000000);
                c.drawPath(path, p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        private void star(Canvas c, float x, float y, float r, int color) {
            Path s = new Path();
            for (int i = 0; i < 10; i++) {
                double a = Math.toRadians(-90 + i * 36);
                float rr = i % 2 == 0 ? r : r * 0.42f;
                float px = x + (float) Math.cos(a) * rr;
                float py = y + (float) Math.sin(a) * rr;
                if (i == 0) {
                    s.moveTo(px, py);
                } else {
                    s.lineTo(px, py);
                }
            }
            s.close();
            p.setColor(color);
            c.drawPath(s, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            String fam = family(s.name);
            float w = getWidth();
            float h = getHeight();
            // hangar floor background
            p.setShader(new android.graphics.RadialGradient(w * 0.35f, h / 2f, Math.max(w, h) * 0.7f,
                    0xFF1B1F26, 0xFF07080B, android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setColor(0x0DFFFFFF);
            for (float gx = 0; gx < w; gx += dp(24)) {
                c.drawRect(gx, 0, gx + 1, h, p);
            }
            for (float gy = 0; gy < h; gy += dp(24)) {
                c.drawRect(0, gy, w, gy + 1, p);
            }
            float listW = w * 0.31f;
            float sc = Math.min((w - listW) / 100f, (h - dp(10)) / 108f);
            float cx = (w - listW) / 2f;
            float oy = (h - 102 * sc) / 2f;
            float[] body;
            float[] tails;
            float[] stab;
            float[] flap;
            float[] brake;
            float[] gearN;
            float[] gearM;
            float[] canopy;
            float[] hookP = null;
            float[] nozzles;
            boolean brakeBoth;
            int base;
            int light;
            int dark;
            int[] camo;
            boolean redStar;
            if (fam.equals("flanker")) {
                body = new float[] {0, 0, 2.5f, 6, 4.5f, 16, 6, 26, 12, 36, 46, 58, 46, 63, 14, 66, 12, 80, 8, 98, 4, 101};
                tails = new float[] {9, 64, 11, 64, 12, 90, 10, 90};
                stab = new float[] {11, 82, 32, 93, 32, 97, 10, 96};
                flap = new float[] {14, 62.5f, 36, 58.5f, 37, 61.5f, 14, 66};
                brake = new float[] {-3.5f, 22, 3.5f, 22, 3.5f, 32, -3.5f, 32};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 20, 1.2f, 20, 1.2f, 25, -1.2f, 25};
                gearM = new float[] {7, 54, 10, 54, 10, 60, 7, 60};
                canopy = new float[] {-2.8f, 8, 2.8f, 8, 3, 18, -3, 18};
                nozzles = new float[] {5, 100};
                if (s.name.toUpperCase(Locale.ROOT).contains("33")) {
                    hookP = new float[] {-0.8f, 98, 0.8f, 98, 0.8f, 106, -0.8f, 106};
                }
                base = 0xFF8FA3B8;
                light = 0xFFB9C8D6;
                dark = 0xFF5D7186;
                camo = new int[] {0xFF6F86A0, 0xFFA9BCCB};
                redStar = true;
            } else if (fam.equals("frogfoot")) {
                body = new float[] {0, 0, 2.5f, 5, 4, 15, 5, 38, 48, 42, 48, 49, 8, 56, 6, 74, 4, 86, 22, 92, 22, 96, 2, 97};
                tails = new float[] {-0.8f, 72, 0.8f, 72, 0.8f, 96, -0.8f, 96};
                stab = new float[] {2, 86, 22, 92, 22, 96, 2, 97};
                flap = new float[] {7, 52, 30, 49.5f, 30, 53, 7, 56};
                brake = new float[] {46, 43, 49, 43, 49, 49, 46, 49};
                brakeBoth = true;
                gearN = new float[] {-1.2f, 14, 1.2f, 14, 1.2f, 19, -1.2f, 19};
                gearM = new float[] {9, 46, 12, 46, 12, 53, 9, 53};
                canopy = new float[] {-2.5f, 7, 2.5f, 7, 2.7f, 16, -2.7f, 16};
                nozzles = new float[] {6.5f, 73};
                base = 0xFF7A7F4E;
                light = 0xFF9EA06A;
                dark = 0xFF4F5232;
                camo = new int[] {0xFF6B5638, 0xFF8E9663, 0xFF4E5A35};
                redStar = true;
            } else {
                body = new float[] {0, 0, 1.9f, 1.2f, 3.6f, 4, 5.4f, 9, 6.8f, 15, 7.4f, 21, 8.2f, 26, 14, 40, 46, 55, 46, 60, 16, 64, 9.5f, 72,
                    9.5f, 78, 28, 90, 28, 94, 8.5f, 94, 6.5f, 100};
                tails = new float[] {9, 66, 11.5f, 66, 13, 86, 10.5f, 86};
                stab = new float[] {9, 78, 28, 90, 28, 94, 8, 94};
                flap = new float[] {16, 62, 33, 59.5f, 33.5f, 62.5f, 16, 65.5f};
                brake = new float[] {-3, 70, 3, 70, 3, 77, -3, 77};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 17, 1.2f, 17, 1.2f, 22, -1.2f, 22};
                gearM = new float[] {6.5f, 50, 9.5f, 50, 9.5f, 56, 6.5f, 56};
                canopy = new float[] {-2.6f, 6.5f, 2.6f, 6.5f, 3.8f, 12, 3.6f, 20, -3.6f, 20, -3.8f, 12};
                hookP = new float[] {-0.8f, 96, 0.8f, 96, 0.8f, 105, -0.8f, 105};
                nozzles = new float[] {3.2f, 100};
                base = 0xFFA7AEB7;
                light = 0xFFC9CFD6;
                dark = 0xFF767E88;
                camo = new int[0];
                redStar = false;
            }
            Path bodyPath = poly(body, cx, oy, sc, true);
            // shadow on the floor
            c.save();
            c.translate(dp(6), dp(8));
            p.setColor(0x66000000);
            c.drawPath(bodyPath, p);
            c.restore();
            // stabilisers and tails under the body
            p.setColor(dark);
            c.drawPath(poly(stab, cx, oy, sc, false), p);
            c.drawPath(poly(mirror(stab), cx, oy, sc, false), p);
            // body: metal with light from the top left
            p.setShader(new android.graphics.LinearGradient(cx - 46 * sc, oy, cx + 46 * sc, oy + 100 * sc,
                    new int[] {light, base, dark}, new float[] {0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            c.drawPath(bodyPath, p);
            p.setShader(null);
            // camouflage, kept inside the body outline
            if (camo.length > 0) {
                c.save();
                c.clipPath(bodyPath);
                java.util.Random rng = new java.util.Random(fam.hashCode());
                for (int i = 0; i < 26; i++) {
                    p.setColor((camo[i % camo.length] & 0x00FFFFFF) | 0xB0000000);
                    float bx = cx + (rng.nextFloat() * 92 - 46) * sc;
                    float by = oy + rng.nextFloat() * 100 * sc;
                    float bw = (6 + rng.nextFloat() * 14) * sc;
                    float bh = (3 + rng.nextFloat() * 8) * sc;
                    c.save();
                    c.rotate(rng.nextFloat() * 180, bx, by);
                    c.drawOval(new RectF(bx - bw, by - bh, bx + bw, by + bh), p);
                    c.restore();
                }
                c.restore();
            }
            // outline and panel lines
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.2f));
            p.setColor(0xCC0E1014);
            c.drawPath(bodyPath, p);
            p.setStrokeWidth(dp(0.6f));
            p.setColor(0x44000000);
            c.drawLine(cx, oy + 20 * sc, cx, oy + 96 * sc, p);
            for (float py : new float[] {28, 38, 48, 58, 70}) {
                c.drawLine(cx - 5 * sc, oy + py * sc, cx + 5 * sc, oy + py * sc, p);
            }
            c.drawLine(cx - 6 * sc, oy + 40 * sc, cx - 40 * sc, oy + 55.5f * sc, p);
            c.drawLine(cx + 6 * sc, oy + 40 * sc, cx + 40 * sc, oy + 55.5f * sc, p);
            p.setStyle(Paint.Style.FILL);
            // tails on top with their own shading
            p.setColor(dark);
            c.drawPath(poly(tails, cx, oy, sc, false), p);
            if (!fam.equals("frogfoot")) {
                c.drawPath(poly(mirror(tails), cx, oy, sc, false), p);
            }
            // engine nozzles
            p.setShader(new android.graphics.RadialGradient(0, 0, 1, 0xFF3A3A3A, 0xFF0A0A0A, android.graphics.Shader.TileMode.CLAMP));
            p.setShader(null);
            p.setColor(0xFF15161A);
            c.drawCircle(cx - nozzles[0] * sc, oy + nozzles[1] * sc, 2.2f * sc, p);
            c.drawCircle(cx + nozzles[0] * sc, oy + nozzles[1] * sc, 2.2f * sc, p);
            p.setColor(0xFF3A3D44);
            c.drawCircle(cx - nozzles[0] * sc, oy + nozzles[1] * sc, 1.2f * sc, p);
            c.drawCircle(cx + nozzles[0] * sc, oy + nozzles[1] * sc, 1.2f * sc, p);
            // insignia: US Navy star or red star on the wings
            if (redStar) {
                star(c, cx - 30 * sc, oy + 55 * sc, 3.6f * sc, 0xFFFFFFFF);
                star(c, cx - 30 * sc, oy + 55 * sc, 3f * sc, 0xFFD21F1F);
                star(c, cx + 30 * sc, oy + 55 * sc, 3.6f * sc, 0xFFFFFFFF);
                star(c, cx + 30 * sc, oy + 55 * sc, 3f * sc, 0xFFD21F1F);
            } else {
                p.setColor(0xFF59606A);
                c.drawCircle(cx - 32 * sc, oy + 56 * sc, 3.4f * sc, p);
                star(c, cx - 32 * sc, oy + 56 * sc, 3f * sc, 0xFFD6DAE0);
                p.setColor(0xFF33373E);
                c.drawRect(cx + 36 * sc, oy + 54.5f * sc, cx + 44 * sc, oy + 55.5f * sc, p);
                // wingtip missiles
                p.setColor(0xFFE8EBEF);
                c.drawRect(cx - 47 * sc, oy + 52 * sc, cx - 46 * sc, oy + 62 * sc, p);
                c.drawRect(cx + 46 * sc, oy + 52 * sc, cx + 47 * sc, oy + 62 * sc, p);
            }
            // moving parts
            part(c, flap, cx, oy, sc, s.flaps, true, (base & 0x00FFFFFF) | 0xFF000000);
            part(c, brake, cx, oy, sc, s.brake, brakeBoth, dark);
            part(c, gearN, cx, oy, sc, s.gear, false, dark);
            part(c, gearM, cx, oy, sc, s.gear, true, dark);
            if (hookP != null) {
                part(c, hookP, cx, oy, sc, s.hook, false, dark);
            }
            // canopy glass (tinted when open)
            Path glass = poly(canopy, cx, oy, sc, false);
            if (s.canopy > 0.05f) {
                part(c, canopy, cx, oy, sc, s.canopy, false, 0xFF1A2633);
            } else {
                p.setShader(new android.graphics.LinearGradient(cx - 3 * sc, oy + 8 * sc, cx + 3 * sc, oy + 19 * sc,
                        new int[] {0xFF5E7C99, 0xFF13202E, 0xFF0A121A}, null, android.graphics.Shader.TileMode.CLAMP));
                c.drawPath(glass, p);
                p.setShader(null);
                p.setColor(0x88FFFFFF);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                c.drawLine(cx - 1.2f * sc, oy + 10 * sc, cx - 1.8f * sc, oy + 15 * sc, p);
                p.setStyle(Paint.Style.FILL);
            }
            // the list on the right
            float lx = w - listW + dp(4);
            float ly = dp(20);
            p.setTypeface(Theme.MONO);
            p.setTextSize(dp(big ? 14 : 11));
            p.setColor(0xFFFFFFFF);
            c.drawText(DcsLink.live() ? nice(s.name.isEmpty() ? "F/A-18C" : s.name) : "no data", lx, ly, p);
            ly += dp(22);
            Object[][] rows = {{"GEAR", s.gear}, {"FLAPS", s.flaps}, {"AIRBRAKE", s.brake}, {"HOOK", s.hook},
                {"CANOPY", s.canopy}, {"WHEEL BRAKE", s.wheel}};
            p.setTextSize(dp(big ? 12 : 10));
            for (Object[] r : rows) {
                if (r[0].equals("HOOK") && hookP == null) {
                    continue;
                }
                float v = (float) r[1];
                int col = v > 0.95f ? RED : v > 0.05f ? BLUE : 0xFF5A5F68;
                p.setColor(col);
                if (v > 0.05f) {
                    p.setShadowLayer(dp(5), 0, 0, col);
                }
                c.drawCircle(lx + dp(5), ly - dp(4), dp(5), p);
                p.clearShadowLayer();
                p.setColor(0xFFE5E5EA);
                c.drawText((String) r[0], lx + dp(14), ly, p);
                p.setColor(col == 0xFF5A5F68 ? 0xFF8E8E93 : col);
                c.drawText(Math.round(v * 100) + "%", lx + dp(14), ly + dp(12), p);
                ly += dp(28);
            }
            p.setTextSize(dp(9));
            p.setColor(RED);
            c.drawText("■ fully out", lx, h - dp(30), p);
            p.setColor(BLUE);
            c.drawText("■ partly out", lx, h - dp(18), p);
            p.setColor(0xFF8E8E93);
            c.drawText("■ in", lx, h - dp(6), p);
        }
    }

    // ------------------------------------------------------------------ CARRIER page

    private final class CarrierView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        CarrierView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setColor(0xFF05070A);
            c.drawRect(0, 0, w, h, p);
            double[] ap = DcsLink.live() ? DcsLink.approach(s, DcsLink.objs) : null;
            if (ap == null) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(12));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(!DcsLink.live() ? "No DCS data (try SIM)" : DcsLink.objectsLive() ? "No carrier within 25 km"
                        : "No carrier data (server may block it)", w / 2, h / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            double along = ap[0];
            double height = ap[2];
            double gs = ap[3];
            double lu = ap[4];
            // ================= side view
            float sh = h * 0.5f;
            float l = 0;
            float r = w;
            float deckY = sh * 0.8f;
            double range = Math.max(1500, Math.min(9000, along * 1.3));
            float tdX = r - dp(70);
            float ppm = (float) ((tdX - dp(10)) / range);
            float vs = (float) Math.max(1, Math.min(6, (deckY * 0.75) / (Math.tan(Math.toRadians(5)) * range * ppm)));
            // sky and sea
            p.setShader(new android.graphics.LinearGradient(0, 0, 0, deckY, 0xFF0D2440, 0xFF5D82A8,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(l, 0, r, deckY, p);
            p.setShader(new android.graphics.LinearGradient(0, deckY, 0, sh, 0xFF0F3E5E, 0xFF04182A,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(l, deckY, r, sh, p);
            p.setShader(null);
            p.setColor(0x22FFFFFF);
            for (int i = 0; i < 6; i++) {
                float wy = deckY + dp(4) + i * (sh - deckY) / 6f;
                for (float wx = (i % 2) * dp(14); wx < w; wx += dp(28)) {
                    c.drawRect(wx, wy, wx + dp(10), wy + 1, p);
                }
            }
            // distance marks every quarter mile
            p.setTextSize(dp(8));
            for (int q = 1; q <= 8; q++) {
                double m = q * 463.0;
                if (m > range) {
                    break;
                }
                float mx = (float) (tdX - m * ppm);
                p.setColor(0x44FFFFFF);
                c.drawRect(mx, deckY - dp(3), mx + 1, deckY + dp(3), p);
                p.setColor(0x88FFFFFF);
                c.drawText(q % 4 == 0 ? q / 4 + "nm" : q == 3 ? "¾" : q == 2 ? "½" : q == 1 ? "¼" : "", mx - dp(4),
                        deckY + dp(12), p);
            }
            // glide slope band and line (3.5 deg)
            Path band = new Path();
            band.moveTo(tdX, deckY);
            band.lineTo(l, (float) (deckY - Math.tan(Math.toRadians(4.2)) * (tdX - l) * vs));
            band.lineTo(l, (float) (deckY - Math.tan(Math.toRadians(2.8)) * (tdX - l) * vs));
            band.close();
            p.setColor(0x2230D158);
            c.drawPath(band, p);
            p.setColor(0xFF30D158);
            p.setStrokeWidth(dp(1.5f));
            p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(8), dp(5)}, 0));
            c.drawLine(tdX, deckY, l, (float) (deckY - Math.tan(Math.toRadians(3.5)) * (tdX - l) * vs), p);
            p.setPathEffect(null);
            // the carrier in profile
            float L = Math.max(dp(110), (float) (333 * ppm));
            float sx = tdX - dp(8);
            Path hull = new Path();
            hull.moveTo(sx, deckY - dp(9));
            hull.lineTo(sx + L * 1.02f, deckY - dp(10));
            hull.lineTo(sx + L * 0.97f, deckY + dp(4));
            hull.lineTo(sx + dp(6), deckY + dp(4));
            hull.close();
            p.setShader(new android.graphics.LinearGradient(0, deckY - dp(10), 0, deckY + dp(4), 0xFF8C939C, 0xFF3D434B,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawPath(hull, p);
            p.setShader(null);
            p.setColor(0xFF2B2F35);
            c.drawRect(sx, deckY - dp(11), sx + L, deckY - dp(9), p);
            // island with mast and radar
            float ix = sx + L * 0.62f;
            p.setColor(0xFF7A818A);
            c.drawRect(ix, deckY - dp(26), ix + dp(16), deckY - dp(11), p);
            p.setColor(0xFF5E656E);
            c.drawRect(ix + dp(3), deckY - dp(34), ix + dp(13), deckY - dp(26), p);
            p.setColor(0xFF9AA1AA);
            c.drawRect(ix + dp(7), deckY - dp(46), ix + dp(8.5f), deckY - dp(34), p);
            c.drawRect(ix + dp(3), deckY - dp(42), ix + dp(13), deckY - dp(41), p);
            p.setColor(0xFFFFD23F);
            c.drawCircle(ix + dp(7.8f), deckY - dp(47), dp(1.5f), p);
            p.setColor(0x55FFFFFF);
            for (int i = 0; i < 4; i++) {
                c.drawRect(ix + dp(2), deckY - dp(23) + i * dp(3), ix + dp(14), deckY - dp(22.4f) + i * dp(3), p);
            }
            // your jet in profile, nose to the right, tilted by pitch
            float jx = (float) (tdX - along * ppm);
            float jy = (float) (deckY - height * ppm * vs);
            jy = Math.max(dp(8), Math.min(deckY - dp(2), jy));
            int gc = Math.abs(gs) < 0.35 ? GREEN : Math.abs(gs) < 0.8 ? AMBER : RED;
            c.save();
            c.translate(jx, jy);
            c.rotate(-s.pitch);
            Path jet = new Path();
            float k = dp(1.15f);
            jet.moveTo(14 * k, 0);
            jet.lineTo(6 * k, -1.6f * k);
            jet.lineTo(-6 * k, -2 * k);
            jet.lineTo(-9 * k, -8 * k);
            jet.lineTo(-12 * k, -8 * k);
            jet.lineTo(-12 * k, 1.5f * k);
            jet.lineTo(6 * k, 2 * k);
            jet.close();
            p.setShadowLayer(dp(6), 0, 0, gc);
            p.setColor(gc);
            c.drawPath(jet, p);
            p.clearShadowLayer();
            if (s.gear > 0.5f) {
                p.setColor(0xFFE5E5EA);
                c.drawRect(4 * k, 2 * k, 4.8f * k, 5 * k, p);
                c.drawRect(-3 * k, 2 * k, -2.2f * k, 5 * k, p);
            }
            if (s.hook > 0.5f) {
                p.setStrokeWidth(dp(1));
                p.setColor(0xFFE5E5EA);
                c.drawLine(-11 * k, 1.5f * k, -15 * k, 5 * k, p);
            }
            c.restore();
            // IFLOLS: green datum bars and the amber ball
            float bx = dp(8);
            float by = dp(8);
            float bw = dp(78);
            float bh = dp(62);
            p.setColor(0xEE000000);
            c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), dp(6), dp(6), p);
            float cyb = by + bh / 2;
            for (int i = 0; i < 4; i++) {
                p.setColor(0xFF2BFF5A);
                p.setShadowLayer(dp(3), 0, 0, 0xFF2BFF5A);
                c.drawCircle(bx + dp(7) + i * dp(5), cyb, dp(1.8f), p);
                c.drawCircle(bx + bw - dp(7) - i * dp(5), cyb, dp(1.8f), p);
            }
            p.clearShadowLayer();
            float lensX = bx + bw / 2;
            p.setColor(0xFF15171A);
            c.drawRect(lensX - dp(6), by + dp(5), lensX + dp(6), by + bh - dp(5), p);
            int cell = (int) Math.round(Math.max(-2.5, Math.min(2.5, -gs / 0.35)));
            float ballY = cyb + cell * (bh - dp(14)) / 6f;
            boolean veryLow = gs < -0.9;
            int ballC = veryLow ? 0xFFFF2D2D : 0xFFFFB020;
            p.setColor(ballC);
            p.setShadowLayer(dp(5), 0, 0, ballC);
            c.drawCircle(lensX, ballY, dp(4.2f), p);
            p.clearShadowLayer();
            p.setColor(0xFFDDDDDD);
            p.setTextSize(dp(7.5f));
            c.drawText("BALL", bx + dp(4), by + bh - dp(3), p);
            // AoA indexer: green V = slow, amber donut = on speed, red ^ = fast
            float ix0 = r - dp(30);
            float iy0 = dp(10);
            float aoa = s.aoa;
            boolean slow = aoa > 8.4f;
            boolean on = aoa >= 7.8f - 0.4f && aoa <= 8.8f;
            boolean fast = aoa < 7.8f;
            p.setColor(0xEE000000);
            c.drawRoundRect(new RectF(ix0 - dp(4), iy0 - dp(4), ix0 + dp(26), iy0 + dp(68)), dp(5), dp(5), p);
            indexer(c, 0, ix0, iy0, aoa > 8.8f || slow && aoa > 8.4f, 0xFF2BFF5A);
            indexer(c, 1, ix0, iy0 + dp(22), on && aoa >= 7.4f, 0xFFFFB020);
            indexer(c, 2, ix0, iy0 + dp(44), fast && aoa < 7.8f, 0xFFFF2D2D);
            // high / low word
            p.setTextSize(dp(big ? 15 : 12));
            p.setColor(gc);
            p.setShadowLayer(dp(4), 0, 0, gc);
            String word = gs > 0.35 ? "HIGH" : gs < -0.35 ? (veryLow ? "LOW  POWER!" : "LOW") : "ON GLIDE SLOPE";
            c.drawText(word, bx + bw + dp(8), dp(22), p);
            p.clearShadowLayer();
            // ================= deck from above, for lineup
            float ty = sh + dp(6);
            float th = h * 0.27f;
            p.setShader(new android.graphics.LinearGradient(0, ty, 0, ty + th, 0xFF06233A, 0xFF0B3654,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(dp(4), ty, w - dp(4), ty + th), dp(10), dp(10), p);
            p.setShader(null);
            float mid = w / 2f;
            // the hull, turned 9 degrees to the right (the ship sails that way)
            c.save();
            c.clipRect(dp(4), ty, w - dp(4), ty + th);
            c.rotate(9, mid, ty + th * 0.35f);
            p.setColor(0xFF4A5059);
            c.drawRoundRect(new RectF(mid - dp(18), ty - th, mid + dp(26), ty + th * 0.55f), dp(10), dp(10), p);
            c.restore();
            // the angled deck: dark grey with white edges and the dashed centreline
            c.save();
            c.clipRect(dp(4), ty, w - dp(4), ty + th);
            p.setColor(0xFF2C3036);
            c.drawRect(mid - dp(16), ty - dp(4), mid + dp(16), ty + th * 0.62f, p);
            p.setColor(0xFFEDEDED);
            c.drawRect(mid - dp(16), ty - dp(4), mid - dp(15), ty + th * 0.62f, p);
            c.drawRect(mid + dp(15), ty - dp(4), mid + dp(16), ty + th * 0.62f, p);
            p.setColor(0xFFFFD23F);
            for (float yy = ty; yy < ty + th * 0.62f; yy += dp(9)) {
                c.drawRect(mid - dp(0.8f), yy, mid + dp(0.8f), yy + dp(5), p);
            }
            // wires
            p.setColor(0xAAFFFFFF);
            for (int i = 0; i < 4; i++) {
                float wy = ty + th * 0.5f - i * dp(5);
                c.drawRect(mid - dp(14), wy, mid + dp(14), wy + 1, p);
            }
            // the extended centreline behind the ship
            p.setColor(0x66FFD23F);
            for (float yy = ty + th * 0.62f; yy < ty + th; yy += dp(9)) {
                c.drawRect(mid - dp(0.6f), yy, mid + dp(0.6f), yy + dp(4), p);
            }
            c.restore();
            float full = 4f;
            float off = (float) (Math.max(-full, Math.min(full, lu)) / full * (w / 2 - dp(24)));
            int lc = Math.abs(lu) < 0.6 ? GREEN : Math.abs(lu) < 1.5 ? AMBER : RED;
            float py = ty + th * 0.86f;
            p.setColor((lc & 0x00FFFFFF) | 0x55000000);
            p.setStrokeWidth(dp(2));
            c.drawLine(mid + off, py, mid, ty + th * 0.55f, p);
            Path top = new Path();
            float kk = dp(1);
            top.moveTo(mid + off, py - 9 * kk);
            top.lineTo(mid + off + 9 * kk, py + 4 * kk);
            top.lineTo(mid + off + 2 * kk, py + 3 * kk);
            top.lineTo(mid + off, py + 7 * kk);
            top.lineTo(mid + off - 2 * kk, py + 3 * kk);
            top.lineTo(mid + off - 9 * kk, py + 4 * kk);
            top.close();
            p.setColor(lc);
            p.setShadowLayer(dp(5), 0, 0, lc);
            c.drawPath(top, p);
            p.clearShadowLayer();
            p.setTextSize(dp(10));
            c.drawText(lu > 0.6 ? "RIGHT → fly left" : lu < -0.6 ? "LEFT ← fly right" : "LINED UP", dp(10), ty + dp(14), p);
            // ================= numbers and lights
            float ny = ty + th + dp(18);
            p.setColor(0xFFE5E5EA);
            p.setTextSize(dp(big ? 14 : 11));
            double nm = along / 1852.0;
            c.drawText(String.format(Locale.ROOT, "%.2f nm   %d ft   %d kt   AoA %.1f", nm, Math.round(height * 3.28084),
                    Math.round(s.ias * 1.94384), aoa), dp(8), ny, p);
            p.setTextSize(dp(9.5f));
            p.setColor(Theme.DIM);
            c.drawText(String.format(Locale.ROOT, "glide slope %+.1f°   lineup %+.1f°", gs, lu), dp(8), ny + dp(14), p);
            String[] ln = {"GEAR", "HOOK", "FLAPS"};
            float[] lv = {s.gear, s.hook, s.flaps};
            for (int i = 0; i < 3; i++) {
                int col = lv[i] > 0.9f ? GREEN : lv[i] > 0.05f ? AMBER : RED;
                float x = dp(8) + i * dp(64);
                RectF pill = new RectF(x, ny + dp(22), x + dp(58), ny + dp(40));
                p.setColor((col & 0x00FFFFFF) | 0x33000000);
                c.drawRoundRect(pill, dp(9), dp(9), p);
                p.setColor(col);
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(ln[i], pill.centerX(), pill.centerY() + dp(3.5f), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            if (nm < 0.8) {
                p.setColor(0xFFFFB020);
                p.setTextSize(dp(11));
                c.drawText("CALL THE BALL", w - dp(110), ny + dp(35), p);
            }
        }

        /** One AoA indexer light: 0 = V (slow), 1 = donut (on speed), 2 = ^ (fast). */
        private void indexer(Canvas c, int kind, float x, float y, boolean lit, int col) {
            p.setColor(lit ? col : (col & 0x00FFFFFF) | 0x26000000);
            if (lit) {
                p.setShadowLayer(dp(6), 0, 0, col);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(4));
            p.setStrokeCap(Paint.Cap.ROUND);
            float cx = x + dp(11);
            if (kind == 1) {
                c.drawCircle(cx, y + dp(9), dp(7), p);
            } else if (kind == 0) {
                c.drawLine(x + dp(2), y + dp(3), cx, y + dp(15), p);
                c.drawLine(cx, y + dp(15), x + dp(20), y + dp(3), p);
            } else {
                c.drawLine(x + dp(2), y + dp(15), cx, y + dp(3), p);
                c.drawLine(cx, y + dp(3), x + dp(20), y + dp(15), p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.clearShadowLayer();
        }
    }

    // ------------------------------------------------------------------ RADAR page

    /** A green phosphor scope: glowing rings, a turning sweep, blips that light up when the sweep passes and fade. */
    private final class RadarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String picked;
        private final long born = SystemClock.uptimeMillis();

        RadarView() {
            super(host);
        }

        private int nm() {
            int[] r = {10, 20, 40, 80};
            return r[Math.max(0, Math.min(3, Prefs.getInt(K_RANGE, 1)))];
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                if (e.getY() < dp(30) && e.getX() > getWidth() - dp(80)) {
                    Prefs.putInt(K_RANGE, (Prefs.getInt(K_RANGE, 1) + 1) % 4);
                } else {
                    picked = nearest(e.getX(), e.getY());
                }
                invalidate();
            }
            return true;
        }

        private float[] geo() {
            float w = getWidth();
            float h = getHeight();
            float R = Math.min(w, h - dp(46)) / 2f - dp(6);
            return new float[] {w / 2f, dp(30) + R + dp(4), R};
        }

        private float[] place(DcsLink.State s, DcsLink.Obj o, float cx, float cy, float R) {
            double dn = o.x - s.x;
            double de = o.z - s.z;
            double hd = Math.toRadians(s.hdg);
            double right = de * Math.cos(hd) - dn * Math.sin(hd);
            double fwd = dn * Math.cos(hd) + de * Math.sin(hd);
            double scale = R / (nm() * 1852.0);
            return new float[] {(float) (cx + right * scale), (float) (cy - fwd * scale), (float) Math.hypot(dn, de),
                (float) ((Math.toDegrees(Math.atan2(right, fwd)) + 360) % 360)};
        }

        private String nearest(float x, float y) {
            DcsLink.State s = DcsLink.st;
            float[] g = geo();
            String best = null;
            float bd = dp(30);
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, g[0], g[1], g[2]);
                float d = (float) Math.hypot(q[0] - x, q[1] - y);
                if (d < bd) {
                    bd = d;
                    best = o.id;
                }
            }
            return best;
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float[] g = geo();
            float cx = g[0];
            float cy = g[1];
            float R = g[2];
            p.setTypeface(Theme.MONO);
            // the tube
            p.setColor(0xFF010603);
            c.drawRect(0, 0, w, h, p);
            p.setShader(new android.graphics.RadialGradient(cx, cy, R * 1.1f, 0xFF06301A, 0xFF010A05,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            // rings, cross and bearing ticks, glowing
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setShadowLayer(dp(3), 0, 0, PHOS);
            for (int i = 1; i <= 4; i++) {
                p.setColor((PHOS & 0x00FFFFFF) | (i == 4 ? 0xAA000000 : 0x55000000));
                c.drawCircle(cx, cy, R * i / 4f, p);
            }
            p.setColor((PHOS & 0x00FFFFFF) | 0x33000000);
            c.drawLine(cx - R, cy, cx + R, cy, p);
            c.drawLine(cx, cy - R, cx, cy + R, p);
            p.setColor((PHOS & 0x00FFFFFF) | 0x99000000);
            for (int d = 0; d < 360; d += 10) {
                double a = Math.toRadians(d - s.hdg);
                float len = d % 30 == 0 ? dp(8) : dp(4);
                c.drawLine(cx + (float) Math.sin(a) * R, cy - (float) Math.cos(a) * R,
                        cx + (float) Math.sin(a) * (R - len), cy - (float) Math.cos(a) * (R - len), p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(9));
            p.setColor((PHOS & 0x00FFFFFF) | 0xCC000000);
            p.setTextAlign(Paint.Align.CENTER);
            for (int d = 0; d < 360; d += 90) {
                double a = Math.toRadians(d - s.hdg);
                String lab = d == 0 ? "N" : d == 90 ? "E" : d == 180 ? "S" : "W";
                c.drawText(lab, cx + (float) Math.sin(a) * (R - dp(16)), cy - (float) Math.cos(a) * (R - dp(16)) + dp(3), p);
            }
            p.setTextAlign(Paint.Align.LEFT);
            for (int i = 1; i <= 3; i++) {
                c.drawText(nm() * i / 4 + "", cx + dp(3), cy - R * i / 4f - dp(2), p);
            }
            // the sweep
            float sweep = ((SystemClock.uptimeMillis() - born) % 3000) / 3000f * 360f;
            c.save();
            c.rotate(sweep - 90, cx, cy);
            p.setShader(new android.graphics.SweepGradient(cx, cy, new int[] {0x0035FF6A, 0x0035FF6A, 0x6635FF6A, 0xCC35FF6A},
                    new float[] {0f, 0.75f, 0.985f, 1f}));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            c.restore();
            double sa = Math.toRadians(sweep);
            p.setColor(PHOS);
            p.setStrokeWidth(dp(1.5f));
            p.setShadowLayer(dp(4), 0, 0, PHOS);
            c.drawLine(cx, cy, cx + (float) Math.sin(sa) * R, cy - (float) Math.cos(sa) * R, p);
            p.clearShadowLayer();
            // scanlines
            p.setColor(0x10000000);
            for (float yy = 0; yy < h; yy += dp(3)) {
                c.drawRect(0, yy, w, yy + dp(1), p);
            }
            // you
            p.setColor(PHOS);
            p.setShadowLayer(dp(4), 0, 0, PHOS);
            Path me = new Path();
            me.moveTo(cx, cy - dp(8));
            me.lineTo(cx - dp(5), cy + dp(6));
            me.lineTo(cx, cy + dp(3));
            me.lineTo(cx + dp(5), cy + dp(6));
            me.close();
            c.drawPath(me, p);
            p.clearShadowLayer();
            // header
            p.setTextSize(dp(11));
            p.setColor(PHOS);
            c.drawText("HDG " + String.format(Locale.ROOT, "%03d", Math.round((s.hdg + 360) % 360)), dp(6), dp(16), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText(nm() + " NM ▾", w - dp(6), dp(16), p);
            p.setTextAlign(Paint.Align.LEFT);
            if (!DcsLink.objectsLive()) {
                p.setColor((PHOS & 0x00FFFFFF) | 0xAA000000);
                p.setTextSize(dp(11));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(DcsLink.live() ? "NO CONTACT DATA" : "NO DCS DATA · TRY SIM", cx, cy - R / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                postInvalidateDelayed(40);
                return;
            }
            DcsLink.Obj sel = null;
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, cx, cy, R);
                if (q[2] > nm() * 1852.0) {
                    continue;
                }
                // brightest right after the sweep passed, then fading for one turn
                float since = (sweep - q[3] + 360) % 360;
                float glow = 0.25f + 0.75f * (1f - since / 360f);
                boolean hostile = o.coal != 0 && o.coal != s.coal;
                boolean friend = o.coal == s.coal;
                int col = hostile ? 0xFFFF4A3D : friend ? PHOS : 0xFFFFD84A;
                int a = (int) (255 * glow);
                p.setColor((col & 0x00FFFFFF) | (a << 24));
                p.setShadowLayer(dp(6) * glow, 0, 0, col);
                float z = dp(5);
                if (o.cat == 3) {
                    Path d = new Path();
                    d.moveTo(q[0] - z * 1.6f, q[1]);
                    d.lineTo(q[0] - z, q[1] + z * 0.8f);
                    d.lineTo(q[0] + z, q[1] + z * 0.8f);
                    d.lineTo(q[0] + z * 1.6f, q[1]);
                    d.close();
                    c.drawPath(d, p);
                } else if (o.cat == 2) {
                    c.drawRect(q[0] - z * 0.7f, q[1] - z * 0.7f, q[0] + z * 0.7f, q[1] + z * 0.7f, p);
                } else if (hostile) {
                    Path d = new Path();
                    d.moveTo(q[0], q[1] - z);
                    d.lineTo(q[0] + z, q[1]);
                    d.lineTo(q[0], q[1] + z);
                    d.lineTo(q[0] - z, q[1]);
                    d.close();
                    c.drawPath(d, p);
                } else {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.8f));
                    c.drawArc(new RectF(q[0] - z, q[1] - z, q[0] + z, q[1] + z), 180, 180, false, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(q[0], q[1], dp(1.5f), p);
                }
                if (o.cat == 1) {
                    double rel = Math.toRadians(o.hdg - s.hdg);
                    p.setStrokeWidth(dp(1.4f));
                    c.drawLine(q[0], q[1], q[0] + (float) Math.sin(rel) * dp(12), q[1] - (float) Math.cos(rel) * dp(12), p);
                }
                p.clearShadowLayer();
                if (o.name != null && o.name.equals(s.lockName) && s.lockDist > 0) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.5f));
                    p.setColor(0xFFFFFFFF);
                    p.setShadowLayer(dp(4), 0, 0, 0xFFFFFFFF);
                    c.drawRect(q[0] - dp(9), q[1] - dp(9), q[0] + dp(9), q[1] + dp(9), p);
                    p.clearShadowLayer();
                    p.setStyle(Paint.Style.FILL);
                }
                if (o.id.equals(picked)) {
                    sel = o;
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1));
                    p.setColor(PHOS);
                    c.drawCircle(q[0], q[1], dp(12), p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
            p.setTextSize(dp(10));
            if (sel != null) {
                float[] q = place(s, sel, cx, cy, R);
                p.setColor(PHOS);
                c.drawText(sel.name + "  " + String.format(Locale.ROOT, "%.1f NM  %03d°  %d FT", q[2] / 1852.0,
                        Math.round((q[3] + s.hdg + 360) % 360), Math.round(sel.alt * 3.28084)), dp(6), h - dp(6), p);
            } else {
                p.setColor((PHOS & 0x00FFFFFF) | 0x99000000);
                c.drawText("◠ friend  ◆ hostile  ■ ground  ▬ ship  · tap a blip", dp(6), h - dp(6), p);
            }
            postInvalidateDelayed(40);
        }
    }

    // ------------------------------------------------------------------ TARGET and FLIGHT pages

    /** A green MFD page for your lock. */
    private final class TargetView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        TargetView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setColor(0xFF030805);
            c.drawRect(0, 0, w, h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor((HUD & 0x00FFFFFF) | 0x88000000);
            c.drawRoundRect(new RectF(dp(4), dp(4), w - dp(4), h - dp(4)), dp(10), dp(10), p);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setShadowLayer(dp(4), 0, 0, HUD);
            if (!DcsLink.live() || s.lockDist <= 0) {
                p.setColor((HUD & 0x00FFFFFF) | 0x99000000);
                p.setTextSize(dp(22));
                c.drawText("NO LOCK", w / 2, h / 2f, p);
                p.clearShadowLayer();
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            p.setColor(HUD);
            p.setTextSize(dp(11));
            c.drawText("TGT", w / 2, dp(22), p);
            p.setColor(0xFFFF5A4A);
            p.setShadowLayer(dp(5), 0, 0, 0xFFFF5A4A);
            p.setTextSize(dp(big ? 28 : 21));
            c.drawText(s.lockName.isEmpty() ? "UNKNOWN" : s.lockName, w / 2, dp(50), p);
            p.setColor(HUD);
            p.setShadowLayer(dp(5), 0, 0, HUD);
            p.setTextSize(dp(big ? 50 : 36));
            c.drawText(String.format(Locale.ROOT, "%.1f", s.lockDist / 1852.0), w / 2, dp(big ? 112 : 94), p);
            p.setTextSize(dp(11));
            c.drawText("NM", w / 2, dp(big ? 128 : 108), p);
            // range bar 0..40 nm with the target marker
            float bl = dp(30);
            float br = w - dp(30);
            float yb = dp(big ? 150 : 128);
            p.setStrokeWidth(dp(2));
            c.drawLine(bl, yb, br, yb, p);
            for (int i = 0; i <= 4; i++) {
                float x = bl + (br - bl) * i / 4f;
                c.drawLine(x, yb - dp(4), x, yb + dp(4), p);
            }
            float mx = bl + (br - bl) * Math.min(1f, (float) (s.lockDist / 1852.0 / 40.0));
            Path tri = new Path();
            tri.moveTo(mx, yb - dp(4));
            tri.lineTo(mx - dp(6), yb - dp(14));
            tri.lineTo(mx + dp(6), yb - dp(14));
            tri.close();
            c.drawPath(tri, p);
            p.setTextSize(dp(big ? 16 : 13));
            float y = yb + dp(30);
            c.drawText("VC " + Math.round(s.lockClose * 1.94384f) + " KT" + (s.lockClose > 0 ? "  CLOSING" : "  OPENING"), w / 2, y, p);
            if (s.lockAlt >= 0) {
                c.drawText("ALT " + Math.round(s.lockAlt * 3.28084) + " FT  " + (s.lockAlt > s.alt ? "↑ ABOVE" : "↓ BELOW"),
                        w / 2, y + dp(22), p);
            }
            if (s.lockClose > 1) {
                c.drawText("MERGE ~" + Math.round(s.lockDist / s.lockClose) + " S", w / 2, y + dp(44), p);
            }
            p.clearShadowLayer();
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    /** A green HUD: heading tape, speed and altitude boxes, a pitch ladder that banks with you, and the numbers. */
    private final class FlightView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        private float tx;
        private float ty;

        FlightView() {
            super(host);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (DcsLink.simMode != 2) {
                return false;
            }
            getParent().requestDisallowInterceptTouchEvent(true);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    tx = e.getX();
                    ty = e.getY();
                    touchStick = true;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    DcsLink.stickX = stick((e.getX() - tx) / dp(70));
                    DcsLink.stickY = stick((e.getY() - ty) / dp(70));
                    return true;
                default:
                    touchStick = false;
                    DcsLink.stickX = 0;
                    DcsLink.stickY = 0;
                    return true;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setShader(new android.graphics.LinearGradient(0, 0, 0, h, 0xFF0B1A2A, 0xFF16222C,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            boolean live = DcsLink.live();
            float cx = w / 2f;
            float cy = h * 0.46f;
            float ppd = h / 60f;
            p.setShadowLayer(dp(3), 0, 0, HUD);
            p.setColor(HUD);
            // pitch ladder, turning with the bank
            c.save();
            c.clipRect(dp(60), dp(36), w - dp(60), h - dp(56));
            c.rotate(-s.bank, cx, cy);
            p.setStrokeWidth(dp(1.4f));
            p.setTextSize(dp(9));
            for (int d = -30; d <= 30; d += 5) {
                if (d == 0) {
                    continue;
                }
                float y = cy - (d - s.pitch) * ppd;
                float half = dp(d % 10 == 0 ? 34 : 22);
                if (d < 0) {
                    p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(5), dp(4)}, 0));
                }
                c.drawLine(cx - half, y, cx - dp(10), y, p);
                c.drawLine(cx + dp(10), y, cx + half, y, p);
                p.setPathEffect(null);
                c.drawLine(cx - half, y, cx - half, y + (d > 0 ? dp(5) : -dp(5)), p);
                c.drawLine(cx + half, y, cx + half, y + (d > 0 ? dp(5) : -dp(5)), p);
                if (d % 10 == 0) {
                    c.drawText(String.valueOf(Math.abs(d)), cx + half + dp(3), y + dp(3), p);
                }
            }
            float hy = cy + s.pitch * ppd;
            p.setStrokeWidth(dp(1.8f));
            c.drawLine(dp(20), hy, w - dp(20), hy, p);
            c.restore();
            // boresight W and the flight path marker
            p.setStrokeWidth(dp(1.8f));
            c.drawLine(cx - dp(14), cy, cx - dp(7), cy + dp(6), p);
            c.drawLine(cx - dp(7), cy + dp(6), cx, cy, p);
            c.drawLine(cx, cy, cx + dp(7), cy + dp(6), p);
            c.drawLine(cx + dp(7), cy + dp(6), cx + dp(14), cy, p);
            float fy = cy + s.aoa * ppd;
            p.setStyle(Paint.Style.STROKE);
            c.drawCircle(cx, fy, dp(5), p);
            p.setStyle(Paint.Style.FILL);
            c.drawLine(cx - dp(13), fy, cx - dp(5), fy, p);
            c.drawLine(cx + dp(5), fy, cx + dp(13), fy, p);
            c.drawLine(cx, fy - dp(5), cx, fy - dp(10), p);
            // heading tape
            p.setTextSize(dp(10));
            p.setStrokeWidth(dp(1.2f));
            float tapeY = dp(26);
            float pxd = dp(4);
            for (int d = -30; d <= 30; d++) {
                int hd = (int) Math.floor(s.hdg) + d;
                float x = cx + (hd - s.hdg) * pxd;
                int hn = ((hd % 360) + 360) % 360;
                if (hn % 5 == 0) {
                    c.drawLine(x, tapeY, x, tapeY - (hn % 10 == 0 ? dp(7) : dp(4)), p);
                }
                if (hn % 10 == 0) {
                    p.setTextAlign(Paint.Align.CENTER);
                    c.drawText(String.format(Locale.ROOT, "%02d", hn / 10), x, tapeY - dp(10), p);
                    p.setTextAlign(Paint.Align.LEFT);
                }
            }
            Path caret = new Path();
            caret.moveTo(cx, tapeY + dp(2));
            caret.lineTo(cx - dp(5), tapeY + dp(9));
            caret.lineTo(cx + dp(5), tapeY + dp(9));
            caret.close();
            c.drawPath(caret, p);
            // speed and altitude boxes
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            RectF sp = new RectF(dp(6), cy - dp(13), dp(58), cy + dp(13));
            RectF al = new RectF(w - dp(72), cy - dp(13), w - dp(6), cy + dp(13));
            c.drawRect(sp, p);
            c.drawRect(al, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(big ? 15 : 13));
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(live ? String.valueOf(Math.round(s.ias * 1.94384f)) : "---", sp.centerX(), cy + dp(5), p);
            c.drawText(live ? String.format(Locale.ROOT, "%,d", Math.round(s.alt * 3.28084f)) : "-----", al.centerX(), cy + dp(5), p);
            p.setTextSize(dp(9));
            c.drawText("KT", sp.centerX(), sp.top - dp(4), p);
            c.drawText("FT", al.centerX(), al.top - dp(4), p);
            c.drawText(String.format(Locale.ROOT, "R %d", Math.round(s.agl * 3.28084f)), al.centerX(), al.bottom + dp(12), p);
            c.drawText(String.format(Locale.ROOT, "%+d FPM", Math.round(s.vs * 196.85f)), al.centerX(), al.bottom + dp(24), p);
            c.drawText(String.format(Locale.ROOT, "M %.2f", s.mach), sp.centerX(), sp.bottom + dp(12), p);
            c.drawText(String.format(Locale.ROOT, "α %.1f", s.aoa), sp.centerX(), sp.bottom + dp(24), p);
            p.setTextAlign(Paint.Align.LEFT);
            // bottom data block
            boolean lbs = family(s.name).equals("hornet");
            float fuel = s.fuel + s.fuelExt;
            String fuelS = lbs ? Math.round(fuel * 2.20462f) + " LB" : Math.round(fuel) + " KG";
            String mins = burn > 1 ? Math.round(fuel / burn) + " MIN" : "-- MIN";
            float by = h - dp(40);
            p.setTextSize(dp(big ? 12 : 10.5f));
            c.drawText(String.format(Locale.ROOT, "G %.1f  MAX %.1f", s.g, DcsLink.maxG), dp(8), by, p);
            c.drawText("FUEL " + fuelS + "  " + mins, dp(8), by + dp(14), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("CHAFF " + (s.chaff < 0 ? "--" : s.chaff) + "  FLARE " + (s.flare < 0 ? "--" : s.flare), w - dp(8), by, p);
            c.drawText("GUN " + (s.shells < 0 ? "--" : s.shells) + "  WPN " + (s.weapons < 0 ? "--" : s.weapons), w - dp(8), by + dp(14), p);
            p.setTextAlign(Paint.Align.LEFT);
            p.clearShadowLayer();
            String[] names = {"GEAR", "FLAPS", "BRAKE", "HOOK"};
            float[] vals = {s.gear, s.flaps, s.brake, s.hook};
            for (int i = 0; i < 4; i++) {
                int col = vals[i] > 0.95f ? GREEN : vals[i] > 0.05f ? AMBER : 0xFF4A5058;
                float x = dp(8) + i * ((w - dp(16)) / 4f);
                RectF pill = new RectF(x, h - dp(18), x + (w - dp(16)) / 4f - dp(6), h - dp(4));
                p.setColor((col & 0x00FFFFFF) | 0x40000000);
                c.drawRoundRect(pill, dp(7), dp(7), p);
                p.setColor(col);
                p.setTextSize(dp(9));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(names[i], pill.centerX(), pill.centerY() + dp(3), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            if (!live) {
                p.setColor(0xCC000000);
                c.drawRect(0, h * 0.4f, w, h * 0.55f, p);
                p.setColor(HUD);
                p.setTextSize(dp(12));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText("NO DCS DATA · TRY SIM", cx, h * 0.49f, p);
                p.setTextAlign(Paint.Align.LEFT);
            }
        }
    }

    // ================================================================== DCS COCKPIT 2 pages

    /** Base for the drawn pages: dark MFD glass, green text helpers. */
    private abstract class Mfd extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Mfd() {
            super(host);
        }

        void glass(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setShader(new android.graphics.RadialGradient(w / 2, h / 2, Math.max(w, h) * 0.75f, 0xFF071410, 0xFF020604,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setTypeface(Theme.MONO);
        }

        void t(Canvas c, String s, float x, float y, float sp, int col, Paint.Align a) {
            p.setTextSize(dp(sp));
            p.setColor(col);
            p.setTextAlign(a);
            p.setShadowLayer(dp(3), 0, 0, col);
            c.drawText(s, x, y, p);
            p.clearShadowLayer();
            p.setTextAlign(Paint.Align.LEFT);
        }

        void noData(Canvas c) {
            t(c, DcsLink.live() ? "NO DATA" : "NO DCS DATA · TRY SIM", getWidth() / 2f, getHeight() / 2f, 12, (HUD & 0x00FFFFFF) | 0x99000000,
                    Paint.Align.CENTER);
        }

        String nm(double m) {
            return String.format(Locale.ROOT, "%.1f NM", m / 1852.0);
        }

        int brg(DcsLink.State s, double x, double z) {
            return (int) Math.round((Math.toDegrees(Math.atan2(z - s.z, x - s.x)) + 360) % 360);
        }
    }

    private static boolean isTanker(DcsLink.Obj o) {
        String n = o.name == null ? "" : o.name.toUpperCase(Locale.ROOT);
        return o.cat == 1 && (n.contains("KC") || n.contains("S-3B") || n.contains("IL-78") || n.contains("TANKER"));
    }

    private static DcsLink.Obj nearest(DcsLink.State s, boolean carrier, boolean tanker, int coal) {
        DcsLink.Obj best = null;
        double bd = Double.MAX_VALUE;
        for (DcsLink.Obj o : DcsLink.objs) {
            if (carrier && !DcsLink.isCarrier(o) || tanker && !isTanker(o)) {
                continue;
            }
            if (coal == 1 && o.coal != s.coal || coal == -1 && (o.coal == s.coal || o.coal == 0)) {
                continue;
            }
            double d = Math.hypot(o.x - s.x, o.z - s.z);
            if (d < bd) {
                bd = d;
                best = o;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- MAP

    /** North-up moving map: your track, friends, enemies, ships, home and the autopilot target. Tap to fly there. */
    private final class MapView extends Mfd {
        private final int[] zooms = {5, 10, 20, 40, 80};

        private int zoom() {
            return zooms[Math.max(0, Math.min(4, Prefs.getInt("dcs_map_zoom", 2)))];
        }

        private float[] toScreen(DcsLink.State s, double x, double z) {
            float w = getWidth();
            float h = getHeight();
            float R = Math.min(w, h) / 2f;
            double sc = R / (zoom() * 1852.0);
            return new float[] {(float) (w / 2 + (z - s.z) * sc), (float) (h / 2 - (x - s.x) * sc)};
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_UP) {
                return true;
            }
            float w = getWidth();
            float h = getHeight();
            if (e.getX() > w - dp(44) && e.getY() > h - dp(90)) {
                int z = Prefs.getInt("dcs_map_zoom", 2) + (e.getY() > h - dp(45) ? 1 : -1);
                Prefs.putInt("dcs_map_zoom", Math.max(0, Math.min(4, z)));
                invalidate();
                return true;
            }
            if (!DcsLink.live()) {
                return true;
            }
            DcsLink.State s = DcsLink.st;
            float R = Math.min(w, h) / 2f;
            double sc = (zoom() * 1852.0) / R;
            final double tx = s.x - (e.getY() - h / 2) * sc;
            final double tz = s.z + (e.getX() - w / 2) * sc;
            double d = Math.hypot(tx - s.x, tz - s.z);
            int b = brg(s, tx, tz);
            new AlertDialog.Builder(host).setTitle("Fly here?")
                    .setMessage(String.format(Locale.ROOT, "%.1f nm, heading %03d°\nThe autopilot flies there at %d ft.", d / 1852.0, b,
                            Math.round(DcsLink.apAlt * 3.28084f)))
                    .setPositiveButton("✈ FLY HERE", (dd, ww) -> {
                        DcsLink.apTx = tx;
                        DcsLink.apTz = tz;
                        DcsLink.setAp(2);
                        host.toast("Autopilot: flying to the point");
                        invalidate();
                    })
                    .setNeutralButton("JUST MARK IT", (dd, ww) -> {
                        DcsLink.apTx = tx;
                        DcsLink.apTz = tz;
                        invalidate();
                    })
                    .setNegativeButton("CANCEL", null).show();
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            float w = getWidth();
            float h = getHeight();
            DcsLink.State s = DcsLink.st;
            float R = Math.min(w, h) / 2f;
            // grid every quarter of the range
            p.setColor(0x1A3CFF7A);
            p.setStrokeWidth(1);
            float step = R / 2f;
            for (float gx = w / 2 % step; gx < w; gx += step) {
                c.drawLine(gx, 0, gx, h, p);
            }
            for (float gy = h / 2 % step; gy < h; gy += step) {
                c.drawLine(0, gy, w, gy, p);
            }
            t(c, "N ▲", dp(6), dp(14), 10, HUD, Paint.Align.LEFT);
            t(c, zoom() + " NM", w - dp(6), dp(14), 10, HUD, Paint.Align.RIGHT);
            if (!DcsLink.live()) {
                noData(c);
                return;
            }
            // track
            p.setColor(0x993CFF7A);
            p.setStrokeWidth(dp(1.5f));
            float[] last = null;
            for (double[] pt : DcsLink.TRAIL) {
                float[] q = toScreen(s, pt[0], pt[1]);
                if (last != null) {
                    c.drawLine(last[0], last[1], q[0], q[1], p);
                }
                last = q;
            }
            // home
            if (!Double.isNaN(DcsLink.homeX)) {
                float[] q = toScreen(s, DcsLink.homeX, DcsLink.homeZ);
                t(c, "H", q[0], q[1] + dp(4), 12, 0xFFFFFFFF, Paint.Align.CENTER);
            }
            // everything around you, friends too
            p.setTextSize(dp(8.5f));
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = toScreen(s, o.x, o.z);
                if (q[0] < -dp(20) || q[0] > w + dp(20) || q[1] < -dp(20) || q[1] > h + dp(20)) {
                    continue;
                }
                boolean friend = o.coal == s.coal;
                boolean enemy = o.coal != 0 && !friend;
                int col = friend ? 0xFF4FA8FF : enemy ? 0xFFFF4A3D : 0xFFB0B0B0;
                p.setColor(col);
                p.setShadowLayer(dp(4), 0, 0, col);
                float z = dp(5);
                if (DcsLink.isCarrier(o) || o.cat == 3) {
                    c.save();
                    c.rotate(o.hdg, q[0], q[1]);
                    c.drawRoundRect(new RectF(q[0] - z * 0.7f, q[1] - z * 2, q[0] + z * 0.7f, q[1] + z * 2), z, z, p);
                    c.restore();
                } else if (o.cat == 2) {
                    c.drawRect(q[0] - z * 0.7f, q[1] - z * 0.7f, q[0] + z * 0.7f, q[1] + z * 0.7f, p);
                } else {
                    c.save();
                    c.rotate(o.hdg, q[0], q[1]);
                    Path a = new Path();
                    a.moveTo(q[0], q[1] - z * 1.4f);
                    a.lineTo(q[0] + z, q[1] + z);
                    a.lineTo(q[0], q[1] + z * 0.4f);
                    a.lineTo(q[0] - z, q[1] + z);
                    a.close();
                    c.drawPath(a, p);
                    c.restore();
                }
                p.clearShadowLayer();
                String name = o.name == null ? "" : o.name.replace("_", " ");
                if (name.length() > 12) {
                    name = name.substring(0, 12);
                }
                c.drawText(name, q[0] + dp(8), q[1] - dp(4), p);
            }
            // autopilot target
            if (DcsLink.apTx != 0 || DcsLink.apTz != 0) {
                float[] q = toScreen(s, DcsLink.apTx, DcsLink.apTz);
                float[] me = toScreen(s, s.x, s.z);
                p.setColor(0xFFFFD23F);
                p.setStrokeWidth(dp(1.5f));
                p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(6), dp(4)}, 0));
                c.drawLine(me[0], me[1], q[0], q[1], p);
                p.setPathEffect(null);
                c.drawLine(q[0] - dp(7), q[1] - dp(7), q[0] + dp(7), q[1] + dp(7), p);
                c.drawLine(q[0] - dp(7), q[1] + dp(7), q[0] + dp(7), q[1] - dp(7), p);
                t(c, nm(Math.hypot(DcsLink.apTx - s.x, DcsLink.apTz - s.z)) + " " + String.format(Locale.ROOT, "%03d",
                        brg(s, DcsLink.apTx, DcsLink.apTz)), q[0] + dp(10), q[1] + dp(12), 9, 0xFFFFD23F, Paint.Align.LEFT);
            }
            // you
            c.save();
            c.rotate(s.hdg, w / 2, h / 2);
            Path me = new Path();
            me.moveTo(w / 2, h / 2 - dp(10));
            me.lineTo(w / 2 + dp(7), h / 2 + dp(7));
            me.lineTo(w / 2, h / 2 + dp(3));
            me.lineTo(w / 2 - dp(7), h / 2 + dp(7));
            me.close();
            p.setColor(0xFFFFFFFF);
            p.setShadowLayer(dp(4), 0, 0, HUD);
            c.drawPath(me, p);
            p.clearShadowLayer();
            c.restore();
            // zoom buttons
            p.setColor(0xCC10161A);
            c.drawRoundRect(new RectF(w - dp(40), h - dp(88), w - dp(6), h - dp(50)), dp(6), dp(6), p);
            c.drawRoundRect(new RectF(w - dp(40), h - dp(44), w - dp(6), h - dp(6)), dp(6), dp(6), p);
            t(c, "+", w - dp(23), h - dp(62), 16, HUD, Paint.Align.CENTER);
            t(c, "−", w - dp(23), h - dp(18), 16, HUD, Paint.Align.CENTER);
            t(c, "tap the map to fly there", dp(6), h - dp(6), 8.5f, (HUD & 0x00FFFFFF) | 0x99000000, Paint.Align.LEFT);
            postInvalidateDelayed(500);
        }
    }

    // ---------------------------------------------------------------- AUTOPILOT

    /** Turn a dial to pick a heading, set the altitude, or fly to a point you tapped on the map. */
    private final class HeadingDial extends Mfd {
        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            float dx = e.getX() - getWidth() / 2f;
            float dy = e.getY() - getHeight() / 2f;
            if (Math.hypot(dx, dy) > dp(20)) {
                float h = (float) ((Math.toDegrees(Math.atan2(dx, -dy)) + DcsLink.st.hdg + 360) % 360);
                DcsLink.apHdg = Math.round(h / 5f) * 5 % 360;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && DcsLink.apMode == 0) {
                    host.toast("Heading set: tap HDG HOLD to fly it");
                }
                invalidate();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2;
            float cy = h / 2;
            float R = Math.min(w, h) / 2 - dp(14);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(HUD);
            p.setShadowLayer(dp(3), 0, 0, HUD);
            c.drawCircle(cx, cy, R, p);
            for (int d = 0; d < 360; d += 5) {
                double a = Math.toRadians(d - s.hdg);
                float len = d % 30 == 0 ? dp(10) : d % 10 == 0 ? dp(6) : dp(3);
                c.drawLine(cx + (float) Math.sin(a) * R, cy - (float) Math.cos(a) * R, cx + (float) Math.sin(a) * (R - len),
                        cy - (float) Math.cos(a) * (R - len), p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            for (int d = 0; d < 360; d += 30) {
                double a = Math.toRadians(d - s.hdg);
                String lab = d == 0 ? "N" : d == 90 ? "E" : d == 180 ? "S" : d == 270 ? "W" : String.valueOf(d / 10);
                t(c, lab, cx + (float) Math.sin(a) * (R - dp(20)), cy - (float) Math.cos(a) * (R - dp(20)) + dp(4), 10, HUD,
                        Paint.Align.CENTER);
            }
            // the bug: where the autopilot will turn
            double ba = Math.toRadians(DcsLink.apTarget() - s.hdg);
            p.setColor(DcsLink.apMode > 0 ? 0xFFFFD23F : 0x99FFD23F);
            Path bug = new Path();
            float bx = cx + (float) Math.sin(ba) * R;
            float by = cy - (float) Math.cos(ba) * R;
            bug.addCircle(bx, by, dp(7), Path.Direction.CW);
            c.drawPath(bug, p);
            p.setStrokeWidth(dp(2));
            c.drawLine(cx, cy, bx, by, p);
            // the nose up
            Path me = new Path();
            me.moveTo(cx, cy - dp(12));
            me.lineTo(cx + dp(8), cy + dp(8));
            me.lineTo(cx, cy + dp(4));
            me.lineTo(cx - dp(8), cy + dp(8));
            me.close();
            p.setColor(0xFFFFFFFF);
            c.drawPath(me, p);
            t(c, String.format(Locale.ROOT, "%03d", Math.round((s.hdg + 360) % 360)), cx, dp(14), 12, 0xFFFFFFFF, Paint.Align.CENTER);
        }
    }

    private View autopilotPage() {
        final LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        col.setBackgroundColor(0xFF030805);
        final TextView state = text("", big ? 14f : 12f, HUD);
        state.setPadding(0, dp(4), 0, dp(4));
        col.addView(state, wide());
        HeadingDial dial = new HeadingDial();
        col.addView(dial, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout modes = row();
        String[] m = {"OFF", "HDG HOLD", "FLY TO MAP"};
        final List<TextView> mb = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            TextView b = chip(m[i], () -> {
                if (mode == 2 && DcsLink.apTx == 0 && DcsLink.apTz == 0) {
                    host.toast("Tap a spot on the MAP first");
                    manual(P_MAP);
                    return;
                }
                if (mode == 1 && DcsLink.apMode == 0) {
                    // hold where you point now unless you set a heading
                    if (DcsLink.apHdg == 0) {
                        DcsLink.apHdg = Math.round(DcsLink.st.hdg);
                    }
                }
                DcsLink.setAp(mode);
                host.buzz(20);
            });
            b.setTextSize(11f);
            LinearLayout.LayoutParams lp = weight(1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            modes.addView(b, lp);
            mb.add(b);
        }
        col.addView(modes, wide());
        LinearLayout alt = row();
        alt.setGravity(Gravity.CENTER_VERTICAL);
        final TextView altT = text("", 12f, HUD);
        Object[][] steps = {{"−1000", -1000}, {"−100", -100}, {null, 0}, {"+100", 100}, {"+1000", 1000}};
        for (Object[] st : steps) {
            if (st[0] == null) {
                alt.addView(altT, weight(1.4f));
                continue;
            }
            final int ft = (int) st[1];
            TextView b = chip((String) st[0], () -> DcsLink.apAlt = Math.max(30, DcsLink.apAlt + ft / 3.28084f));
            LinearLayout.LayoutParams lp = weight(1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            alt.addView(b, lp);
        }
        col.addView(alt, wide());
        LinearLayout more = row();
        final TextView altOn = chip("", () -> DcsLink.apAltOn = !DcsLink.apAltOn);
        TextView here = chip("HOLD THIS ALT + HDG", () -> {
            DcsLink.apAlt = DcsLink.st.alt;
            DcsLink.apHdg = Math.round(DcsLink.st.hdg);
            DcsLink.apAltOn = true;
            DcsLink.setAp(1);
        });
        LinearLayout.LayoutParams l1 = weight(1f);
        l1.setMargins(dp(2), dp(2), dp(2), dp(2));
        more.addView(altOn, l1);
        LinearLayout.LayoutParams l2 = weight(1.4f);
        l2.setMargins(dp(2), dp(2), dp(2), dp(2));
        more.addView(here, l2);
        col.addView(more, wide());
        TextView hint = text("DCS: needs the new NovaExport.lua (SETUP). On first engage it nudges pitch and roll for 2 s to "
                + "learn the directions. Let go of your stick. It lets go by itself if the phone goes quiet.", 8.5f, Theme.DIM);
        col.addView(hint, wide());
        // live text
        Runnable upd = new Runnable() {
            @Override
            public void run() {
                DcsLink.State s = DcsLink.st;
                String mode = DcsLink.apMode == 0 ? "AUTOPILOT OFF" : DcsLink.apMode == 1
                        ? String.format(Locale.ROOT, "HDG HOLD %03d", Math.round(DcsLink.apHdg))
                        : String.format(Locale.ROOT, "FLY TO %03d · %.1f NM", Math.round(DcsLink.apTarget()), DcsLink.apDistance() / 1852.0);
                String link = DcsLink.sim ? "  (SIM)" : DcsLink.lastPc == null ? "  (no PC yet)" : "";
                state.setText(mode + link);
                state.setTextColor(DcsLink.apMode > 0 ? 0xFFFFD23F : HUD);
                altT.setText(String.format(Locale.ROOT, "ALT %,d FT", Math.round(DcsLink.apAlt * 3.28084f)));
                altOn.setText(DcsLink.apAltOn ? "ALT HOLD ON" : "ALT HOLD OFF");
                for (int i = 0; i < mb.size(); i++) {
                    pick(mb.get(i), DcsLink.apMode == i);
                }
                pick(altOn, DcsLink.apAltOn);
                dial.invalidate();
                if (col.isAttachedToWindow()) {
                    col.postDelayed(this, 300);
                }
            }
        };
        col.addOnAttachStateChangeListener(new OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                col.post(upd);
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                col.removeCallbacks(upd);
            }
        });
        return col;
    }

    // ---------------------------------------------------------------- HSI, NAV, ADI

    private final class HsiView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            if (!DcsLink.live()) {
                noData(c);
                return;
            }
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2;
            float cy = h / 2 + dp(6);
            float R = Math.min(w, h) / 2 - dp(18);
            // target: autopilot point, else carrier, else home
            double tx;
            double tz;
            String what;
            DcsLink.Obj cv = nearest(s, true, false, 0);
            if (DcsLink.apTx != 0 || DcsLink.apTz != 0) {
                tx = DcsLink.apTx;
                tz = DcsLink.apTz;
                what = "WPT";
            } else if (cv != null) {
                tx = cv.x;
                tz = cv.z;
                what = "CVN";
            } else {
                tx = DcsLink.homeX;
                tz = DcsLink.homeZ;
                what = "HOME";
            }
            c.save();
            c.rotate(-s.hdg, cx, cy);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            p.setColor(0xFFE5E5EA);
            for (int d = 0; d < 360; d += 5) {
                double a = Math.toRadians(d);
                float len = d % 10 == 0 ? dp(9) : dp(5);
                c.drawLine(cx + (float) Math.sin(a) * R, cy - (float) Math.cos(a) * R, cx + (float) Math.sin(a) * (R - len),
                        cy - (float) Math.cos(a) * (R - len), p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(11));
            p.setTextAlign(Paint.Align.CENTER);
            for (int d = 0; d < 360; d += 30) {
                c.save();
                c.rotate(d, cx, cy);
                c.drawText(d == 0 ? "N" : d == 90 ? "E" : d == 180 ? "S" : d == 270 ? "W" : String.valueOf(d / 10), cx, cy - R + dp(22), p);
                c.restore();
            }
            p.setTextAlign(Paint.Align.LEFT);
            // course needle to the target
            if (!Double.isNaN(tx)) {
                float b = brg(s, tx, tz);
                c.save();
                c.rotate(b, cx, cy);
                p.setColor(0xFFFF4FD8);
                p.setStrokeWidth(dp(3));
                c.drawLine(cx, cy - R + dp(28), cx, cy + R - dp(28), p);
                Path ar = new Path();
                ar.moveTo(cx, cy - R + dp(26));
                ar.lineTo(cx - dp(8), cy - R + dp(42));
                ar.lineTo(cx + dp(8), cy - R + dp(42));
                ar.close();
                c.drawPath(ar, p);
                c.restore();
            }
            // heading bug
            if (DcsLink.apMode > 0) {
                c.save();
                c.rotate(DcsLink.apTarget(), cx, cy);
                p.setColor(0xFFFFD23F);
                c.drawRect(cx - dp(7), cy - R - dp(2), cx + dp(7), cy - R + dp(6), p);
                c.restore();
            }
            c.restore();
            // lubber line and aircraft
            p.setColor(0xFFFFFFFF);
            Path lub = new Path();
            lub.moveTo(cx, cy - R - dp(4));
            lub.lineTo(cx - dp(6), cy - R - dp(14));
            lub.lineTo(cx + dp(6), cy - R - dp(14));
            lub.close();
            c.drawPath(lub, p);
            p.setStrokeWidth(dp(2.5f));
            c.drawLine(cx, cy - dp(14), cx, cy + dp(12), p);
            c.drawLine(cx - dp(14), cy - dp(2), cx + dp(14), cy - dp(2), p);
            c.drawLine(cx - dp(6), cy + dp(10), cx + dp(6), cy + dp(10), p);
            t(c, String.format(Locale.ROOT, "HDG %03d", Math.round((s.hdg + 360) % 360)), dp(6), dp(14), 11, HUD, Paint.Align.LEFT);
            if (!Double.isNaN(tx)) {
                double d = Math.hypot(tx - s.x, tz - s.z);
                t(c, what + " " + String.format(Locale.ROOT, "%03d", brg(s, tx, tz)), w - dp(6), dp(14), 11, 0xFFFF4FD8, Paint.Align.RIGHT);
                t(c, nm(d) + (s.tas > 20 ? String.format(Locale.ROOT, "  %d MIN", Math.round(d / s.tas / 60)) : ""), w - dp(6),
                        dp(28), 10, 0xFFFF4FD8, Paint.Align.RIGHT);
            }
        }
    }

    private final class NavView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            if (!DcsLink.live()) {
                noData(c);
                return;
            }
            DcsLink.State s = DcsLink.st;
            float y = dp(24);
            t(c, "NAVIGATION", dp(10), y, 12, HUD, Paint.Align.LEFT);
            y += dp(26);
            List<Object[]> rows = new ArrayList<>();
            DcsLink.Obj cv = nearest(s, true, false, 0);
            if (cv != null) {
                rows.add(new Object[] {"CARRIER", cv.x, cv.z, 0xFF4FA8FF});
            }
            if (!Double.isNaN(DcsLink.homeX)) {
                rows.add(new Object[] {"HOME (start)", DcsLink.homeX, DcsLink.homeZ, 0xFFFFFFFF});
            }
            if (DcsLink.apTx != 0 || DcsLink.apTz != 0) {
                rows.add(new Object[] {"MAP POINT", DcsLink.apTx, DcsLink.apTz, 0xFFFFD23F});
            }
            DcsLink.Obj tk = nearest(s, false, true, 1);
            if (tk != null) {
                rows.add(new Object[] {"TANKER " + tk.name, tk.x, tk.z, 0xFF4FA8FF});
            }
            DcsLink.Obj fr = nearest(s, false, false, 1);
            if (fr != null) {
                rows.add(new Object[] {"FRIEND " + fr.name, fr.x, fr.z, 0xFF4FA8FF});
            }
            DcsLink.Obj en = nearest(s, false, false, -1);
            if (en != null) {
                rows.add(new Object[] {"ENEMY " + en.name, en.x, en.z, 0xFFFF4A3D});
            }
            for (Object[] r : rows) {
                double x = (double) r[1];
                double z = (double) r[2];
                double d = Math.hypot(x - s.x, z - s.z);
                int col = (int) r[3];
                t(c, (String) r[0], dp(10), y, 11, col, Paint.Align.LEFT);
                t(c, String.format(Locale.ROOT, "%03d°  %s%s", brg(s, x, z), nm(d), s.tas > 20 ? String.format(Locale.ROOT,
                        "  %d MIN", Math.round(d / s.tas / 60)) : ""), dp(10), y + dp(16), 13, 0xFFE5E5EA, Paint.Align.LEFT);
                y += dp(42);
            }
            if (rows.isEmpty()) {
                t(c, "No points yet: tap the MAP", dp(10), y, 11, Theme.DIM, Paint.Align.LEFT);
            }
        }
    }

    private final class AdiView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2;
            float cy = h / 2;
            float R = Math.min(w, h) / 2 - dp(10);
            p.setColor(0xFF050505);
            c.drawRect(0, 0, w, h, p);
            c.save();
            Path ball = new Path();
            ball.addCircle(cx, cy, R, Path.Direction.CW);
            c.clipPath(ball);
            c.rotate(-s.bank, cx, cy);
            float ppd = R / 35f;
            float hy = cy + s.pitch * ppd;
            p.setShader(new android.graphics.LinearGradient(0, hy - R * 2, 0, hy, 0xFF0A3A7A, 0xFF3D8BD9,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(cx - R * 2, hy - R * 3, cx + R * 2, hy, p);
            p.setShader(new android.graphics.LinearGradient(0, hy, 0, hy + R * 2, 0xFF7A4B22, 0xFF3A2410,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(cx - R * 2, hy, cx + R * 2, hy + R * 3, p);
            p.setShader(null);
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(dp(2));
            c.drawLine(cx - R * 2, hy, cx + R * 2, hy, p);
            p.setStrokeWidth(dp(1.2f));
            p.setTextSize(dp(9));
            for (int d = -60; d <= 60; d += 10) {
                if (d == 0) {
                    continue;
                }
                float y = hy - d * ppd;
                float half = dp(d % 20 == 0 ? 30 : 18);
                c.drawLine(cx - half, y, cx + half, y, p);
                if (d % 20 == 0) {
                    c.drawText(String.valueOf(Math.abs(d)), cx + half + dp(4), y + dp(3), p);
                }
            }
            c.restore();
            // bank scale
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(dp(1.5f));
            c.drawCircle(cx, cy, R, p);
            for (int b : new int[] {-60, -45, -30, -20, -10, 0, 10, 20, 30, 45, 60}) {
                double a = Math.toRadians(b);
                float len = b % 30 == 0 ? dp(12) : dp(7);
                c.drawLine(cx + (float) Math.sin(a) * R, cy - (float) Math.cos(a) * R, cx + (float) Math.sin(a) * (R - len),
                        cy - (float) Math.cos(a) * (R - len), p);
            }
            p.setStyle(Paint.Style.FILL);
            c.save();
            c.rotate(-s.bank, cx, cy);
            Path ptr = new Path();
            ptr.moveTo(cx, cy - R + dp(12));
            ptr.lineTo(cx - dp(6), cy - R + dp(22));
            ptr.lineTo(cx + dp(6), cy - R + dp(22));
            ptr.close();
            p.setColor(0xFFFFD23F);
            c.drawPath(ptr, p);
            c.restore();
            // fixed aircraft symbol
            p.setColor(0xFFFFD23F);
            p.setStrokeWidth(dp(4));
            c.drawLine(cx - dp(50), cy, cx - dp(16), cy, p);
            c.drawLine(cx + dp(16), cy, cx + dp(50), cy, p);
            c.drawCircle(cx, cy, dp(4), p);
            p.setTypeface(Theme.MONO);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(dp(11));
            c.drawText(Math.round(s.ias * 1.94384f) + " KT", dp(6), dp(16), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText(String.format(Locale.ROOT, "%,d FT", Math.round(s.alt * 3.28084f)), w - dp(6), dp(16), p);
            c.drawText(String.format(Locale.ROOT, "P %+.0f  B %+.0f", s.pitch, s.bank), w - dp(6), h - dp(6), p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    // ---------------------------------------------------------------- ENGINE, FUEL, WARNINGS

    private void gauge(Mfd m, Canvas c, float cx, float cy, float R, float v, float min, float max, String label, String val,
            float warnFrom) {
        Paint p = m.p;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(3));
        p.setColor(0xFF2A2F35);
        RectF arc = new RectF(cx - R, cy - R, cx + R, cy + R);
        c.drawArc(arc, 135, 270, false, p);
        float warnA = (warnFrom - min) / (max - min) * 270;
        p.setColor(0x99FF453A);
        c.drawArc(arc, 135 + warnA, 270 - warnA, false, p);
        p.setStrokeWidth(dp(1));
        p.setColor(0xFFE5E5EA);
        for (int i = 0; i <= 10; i++) {
            double a = Math.toRadians(135 + 27 * i);
            c.drawLine(cx + (float) Math.cos(a) * (R - dp(6)), cy + (float) Math.sin(a) * (R - dp(6)), cx + (float) Math.cos(a) * R,
                    cy + (float) Math.sin(a) * R, p);
        }
        p.setStyle(Paint.Style.FILL);
        float f = Math.max(0, Math.min(1, (v - min) / (max - min)));
        double a = Math.toRadians(135 + 270 * f);
        int col = v >= warnFrom ? RED : HUD;
        p.setColor(col);
        p.setStrokeWidth(dp(3));
        p.setShadowLayer(dp(4), 0, 0, col);
        c.drawLine(cx, cy, cx + (float) Math.cos(a) * (R - dp(8)), cy + (float) Math.sin(a) * (R - dp(8)), p);
        p.clearShadowLayer();
        c.drawCircle(cx, cy, dp(4), p);
        m.t(c, val, cx, cy + R * 0.55f, 13, col, Paint.Align.CENTER);
        m.t(c, label, cx, cy + R * 0.85f, 9, Theme.DIM, Paint.Align.CENTER);
    }

    private final class EngineView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            t(c, "ENGINES", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            float R = Math.min(w / 4.4f, h / 3.4f);
            gauge(this, c, w * 0.27f, h * 0.38f, R, s.rpmL, 0, 110, "RPM LEFT", Math.round(s.rpmL) + "%", 102);
            gauge(this, c, w * 0.73f, h * 0.38f, R, s.rpmR, 0, 110, "RPM RIGHT", Math.round(s.rpmR) + "%", 102);
            float y = h * 0.74f;
            String ff = burn > 0 ? Math.round(burn) + " KG/MIN" : "--";
            t(c, "FUEL FLOW  " + ff, dp(10), y, 12, 0xFFE5E5EA, Paint.Align.LEFT);
            t(c, String.format(Locale.ROOT, "THRUST LEVER  %d%%  %s", Math.round(DcsLink.throttle * 100),
                    DcsLink.throttle > 0.8f ? "AFTERBURNER" : ""), dp(10), y + dp(18), 12, DcsLink.throttle > 0.8f ? 0xFFFF9F40
                    : 0xFFE5E5EA, Paint.Align.LEFT);
            t(c, String.format(Locale.ROOT, "SPEED %d KT  MACH %.2f", Math.round(s.ias * 1.94384f), s.mach), dp(10), y + dp(36), 12,
                    0xFFE5E5EA, Paint.Align.LEFT);
            if (!DcsLink.live()) {
                noData(c);
            }
        }
    }

    private float bingo() {
        return Prefs.getInt("dcs_bingo", 1500);
    }

    private final class FuelView extends Mfd {
        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP && e.getY() > getHeight() - dp(50)) {
                int b = Prefs.getInt("dcs_bingo", 1500) + (e.getX() > getWidth() / 2f ? 250 : -250);
                Prefs.putInt("dcs_bingo", Math.max(250, Math.min(8000, b)));
                invalidate();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            boolean lbs = family(s.name).equals("hornet");
            float k = lbs ? 2.20462f : 1f;
            String u = lbs ? " LB" : " KG";
            t(c, "FUEL", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            float tot = s.fuel + s.fuelExt;
            float maxInt = Math.max(4900, s.fuel);
            float bw = w * 0.22f;
            float top = dp(36);
            float bh = h * 0.5f;
            String[] names = {"INTERNAL", "EXTERNAL"};
            float[] vals = {s.fuel, s.fuelExt};
            float[] max = {maxInt, Math.max(1, Math.max(3000, s.fuelExt))};
            for (int i = 0; i < 2; i++) {
                float x = w * (0.2f + i * 0.3f);
                p.setColor(0xFF1E2328);
                c.drawRoundRect(new RectF(x, top, x + bw, top + bh), dp(6), dp(6), p);
                float f = Math.max(0, Math.min(1, vals[i] / max[i]));
                int col = tot < bingo() ? RED : HUD;
                p.setColor((col & 0x00FFFFFF) | 0xCC000000);
                p.setShadowLayer(dp(4), 0, 0, col);
                c.drawRoundRect(new RectF(x + dp(3), top + bh * (1 - f) + dp(3), x + bw - dp(3), top + bh - dp(3)), dp(4), dp(4), p);
                p.clearShadowLayer();
                t(c, names[i], x + bw / 2, top + bh + dp(14), 9, Theme.DIM, Paint.Align.CENTER);
                t(c, Math.round(vals[i] * k) + u, x + bw / 2, top + bh + dp(28), 11, 0xFFE5E5EA, Paint.Align.CENTER);
            }
            float rx = w * 0.82f;
            t(c, "TOTAL", rx, top + dp(20), 9, Theme.DIM, Paint.Align.CENTER);
            t(c, Math.round(tot * k) + "", rx, top + dp(38), 16, tot < bingo() ? RED : HUD, Paint.Align.CENTER);
            t(c, burn > 1 ? Math.round(tot / burn) + " MIN" : "-- MIN", rx, top + dp(58), 12, 0xFFE5E5EA, Paint.Align.CENTER);
            t(c, burn > 1 && tot > bingo() ? "BINGO IN " + Math.round((tot - bingo()) / burn) + " MIN" : tot < bingo() ? "BINGO! RTB"
                    : "", rx, top + dp(78), 10, tot < bingo() ? RED : AMBER, Paint.Align.CENTER);
            t(c, "−  BINGO " + Math.round(bingo() * k) + u + "  +", w / 2, h - dp(18), 12, AMBER, Paint.Align.CENTER);
        }
    }

    private final class WarnView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            boolean live = DcsLink.live();
            double[] ap = DcsLink.approach(s, DcsLink.objs);
            boolean onAppr = ap != null && ap[0] > 0 && ap[0] < 6000 && s.alt < 600;
            boolean enemy = false;
            for (DcsLink.Obj o : DcsLink.objs) {
                if (o.cat == 1 && o.coal != 0 && o.coal != s.coal && Math.hypot(o.x - s.x, o.z - s.z) < 37000) {
                    enemy = true;
                }
            }
            float tot = s.fuel + s.fuelExt;
            Object[][] lights = {
                {"LOW FUEL", live && tot < bingo() * 0.6f, RED}, {"BINGO", live && tot < bingo(), AMBER},
                {"GEAR", live && s.gear < 0.9f && s.agl < 300 && s.vs < -2 && s.ias < 110, RED},
                {"STALL", live && s.agl > 10 && (s.aoa > 22 || s.ias < 50), RED}, {"OVER-G", live && s.g > 7.5f, RED},
                {"PULL UP", live && s.agl > 5 && s.agl < 150 && s.vs < -15, RED}, {"HOOK", live && onAppr && s.hook < 0.9f, AMBER},
                {"FLAPS", live && onAppr && s.flaps < 0.9f, AMBER}, {"BRAKE", live && s.brake > 0.05f, AMBER},
                {"LOCKED", live && s.lockDist > 0, AMBER}, {"ENEMY < 20NM", live && enemy, RED},
                {"AUTOPILOT", DcsLink.apMode > 0, GREEN},
            };
            float cw = (w - dp(16)) / 3f;
            float ch = (h - dp(16)) / 4f;
            for (int i = 0; i < lights.length; i++) {
                float x = dp(8) + (i % 3) * cw;
                float y = dp(8) + (i / 3) * ch;
                boolean on = (boolean) lights[i][1];
                int col = (int) lights[i][2];
                RectF r = new RectF(x + dp(3), y + dp(3), x + cw - dp(3), y + ch - dp(3));
                p.setColor(on ? (col & 0x00FFFFFF) | 0xDD000000 : 0xFF14181C);
                if (on) {
                    p.setShadowLayer(dp(8), 0, 0, col);
                }
                c.drawRoundRect(r, dp(6), dp(6), p);
                p.clearShadowLayer();
                p.setTextSize(dp(big ? 12 : 10));
                p.setColor(on ? 0xFF000000 : 0xFF3A4047);
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText((String) lights[i][0], r.centerX(), r.centerY() + dp(4), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
        }
    }

    // ---------------------------------------------------------------- RWR, STORES

    private final class RwrView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2;
            float cy = h / 2;
            float R = Math.min(w, h) / 2 - dp(10);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.2f));
            p.setColor(0x993CFF7A);
            c.drawCircle(cx, cy, R, p);
            c.drawCircle(cx, cy, R * 0.5f, p);
            for (int d = 0; d < 360; d += 30) {
                double a = Math.toRadians(d);
                c.drawLine(cx + (float) Math.sin(a) * R * 0.94f, cy - (float) Math.cos(a) * R * 0.94f, cx + (float) Math.sin(a) * R,
                        cy - (float) Math.cos(a) * R, p);
            }
            p.setStyle(Paint.Style.FILL);
            t(c, "RWR", dp(6), dp(14), 11, HUD, Paint.Align.LEFT);
            t(c, "40 NM", w - dp(6), dp(14), 9, Theme.DIM, Paint.Align.RIGHT);
            p.setColor(HUD);
            c.drawCircle(cx, cy, dp(3), p);
            if (!DcsLink.objectsLive()) {
                noData(c);
                return;
            }
            int n = 0;
            for (DcsLink.Obj o : DcsLink.objs) {
                if (o.coal == 0 || o.coal == s.coal || o.cat == 3) {
                    continue;
                }
                double dn = o.x - s.x;
                double de = o.z - s.z;
                double d = Math.hypot(dn, de);
                if (d > 74000) {
                    continue;
                }
                n++;
                double hd = Math.toRadians(s.hdg);
                double right = de * Math.cos(hd) - dn * Math.sin(hd);
                double fwd = dn * Math.cos(hd) + de * Math.sin(hd);
                double a = Math.atan2(right, fwd);
                // closer threats sit nearer the middle, like a real RWR
                float rr = (float) (R * 0.25 + R * 0.7 * Math.min(1, d / 74000));
                float x = cx + (float) Math.sin(a) * rr;
                float y = cy - (float) Math.cos(a) * rr;
                String sym = threat(o);
                int col = d < 20000 ? 0xFFFF4A3D : 0xFFFFD84A;
                if (o.cat == 2) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(col);
                    c.drawRect(x - dp(11), y - dp(9), x + dp(11), y + dp(9), p);
                    p.setStyle(Paint.Style.FILL);
                } else {
                    Path hat = new Path();
                    hat.moveTo(x - dp(10), y - dp(8));
                    hat.lineTo(x, y - dp(15));
                    hat.lineTo(x + dp(10), y - dp(8));
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(col);
                    c.drawPath(hat, p);
                    p.setStyle(Paint.Style.FILL);
                }
                t(c, sym, x, y + dp(4), 11, col, Paint.Align.CENTER);
            }
            t(c, n == 0 ? "NO THREATS" : n + " THREATS", cx, h - dp(8), 10, n == 0 ? HUD : 0xFFFF4A3D, Paint.Align.CENTER);
        }

        private String threat(DcsLink.Obj o) {
            String n = o.name == null ? "" : o.name.toUpperCase(Locale.ROOT);
            String digits = n.replaceAll("[^0-9]", "");
            if (o.cat == 2) {
                return n.startsWith("SA") ? "SA" : digits.isEmpty() ? "AAA" : digits.length() > 2 ? digits.substring(0, 2) : digits;
            }
            if (!digits.isEmpty()) {
                return digits.length() > 2 ? digits.substring(0, 2) : digits;
            }
            return n.length() > 2 ? n.substring(0, 2) : "U";
        }
    }

    private int maxWeapons;

    private final class StoresView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            t(c, "STORES", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            if (!DcsLink.live()) {
                noData(c);
                return;
            }
            maxWeapons = Math.max(maxWeapons, Math.max(0, s.weapons));
            int slots = Math.max(2, Math.min(12, Math.max(maxWeapons, 2)));
            float cx = w / 2;
            float cy = h * 0.42f;
            float span = w * 0.8f;
            // a simple wing seen from above with the pylons
            p.setColor(0xFF2A3036);
            Path wing = new Path();
            wing.moveTo(cx, cy - dp(30));
            wing.lineTo(cx + span / 2, cy + dp(6));
            wing.lineTo(cx + span / 2, cy + dp(14));
            wing.lineTo(cx, cy + dp(4));
            wing.lineTo(cx - span / 2, cy + dp(14));
            wing.lineTo(cx - span / 2, cy + dp(6));
            wing.close();
            c.drawPath(wing, p);
            c.drawRoundRect(new RectF(cx - dp(8), cy - dp(60), cx + dp(8), cy + dp(50)), dp(8), dp(8), p);
            for (int i = 0; i < slots; i++) {
                float x = cx - span / 2 + span * (i + 0.5f) / slots;
                boolean full = i < s.weapons;
                int col = full ? HUD : 0xFF3A4047;
                p.setColor(col);
                if (full) {
                    p.setShadowLayer(dp(4), 0, 0, col);
                }
                c.drawRoundRect(new RectF(x - dp(4), cy + dp(14), x + dp(4), cy + dp(44)), dp(4), dp(4), p);
                p.clearShadowLayer();
            }
            float y = h * 0.72f;
            t(c, "WEAPONS  " + (s.weapons < 0 ? "--" : s.weapons), dp(12), y, 14, HUD, Paint.Align.LEFT);
            t(c, "GUN  " + (s.shells < 0 ? "--" : s.shells), dp(12), y + dp(22), 14, HUD, Paint.Align.LEFT);
            t(c, "CHAFF  " + (s.chaff < 0 ? "--" : s.chaff) + "   FLARE  " + (s.flare < 0 ? "--" : s.flare), dp(12), y + dp(44), 14, HUD,
                    Paint.Align.LEFT);
        }
    }

    // ---------------------------------------------------------------- CMS, GUN, TIMER (buttons)

    private TextView bigButton(String label, int col) {
        TextView b = text(label, big ? 18f : 15f, 0xFF000000);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Theme.rounded(col, 16f, host));
        return b;
    }

    /** Sends a key from a page button (or does it in SIM). */
    private void key(String spec, boolean down, boolean hold) {
        if (DcsLink.sim) {
            return;
        }
        if (!PcHid.connected()) {
            if (down) {
                host.toast("Not connected: tap CONNECT in KEY DECK (or try SIM)");
            }
            return;
        }
        if (down && DcsLink.unbound(spec)) {
            host.toast("You have no key for this in DCS (you removed " + DcsKeysWidget.pretty(spec) + "). Bind one in DCS");
        }
        Object[] k = DcsKeysWidget.parse(DcsLink.mine(spec));
        int code = PcHid.rawCode((String) k[1]);
        if (hold) {
            PcHid.hold((int) k[0], code, down);
        } else if (down) {
            PcHid.tap((int) k[0], code, (int) k[2], 40);
        }
    }

    private View cmsPage() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        col.setBackgroundColor(0xFF030805);
        final TextView counts = text("", 14f, HUD);
        counts.setPadding(0, dp(8), 0, dp(8));
        col.addView(counts, wide());
        String[][] b = {{"CHAFF", "INS", "#FF9F0A"}, {"FLARE", "DEL", "#FF453A"}, {"BOTH", "", "#FFD23F"}};
        for (final String[] x : b) {
            TextView t = bigButton(x[0], android.graphics.Color.parseColor(x[2]));
            t.setOnClickListener(v -> {
                host.buzz(40);
                if (x[1].isEmpty()) {
                    key("INS", true, false);
                    key("DEL", true, false);
                } else {
                    key(x[1], true, false);
                }
                if (DcsLink.sim) {
                    host.toast(x[0] + " (SIM)");
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
            lp.setMargins(dp(10), dp(6), dp(10), dp(6));
            col.addView(t, lp);
        }
        Runnable upd = new Runnable() {
            @Override
            public void run() {
                DcsLink.State s = DcsLink.st;
                counts.setText("CHAFF " + (s.chaff < 0 ? "--" : s.chaff) + "     FLARE " + (s.flare < 0 ? "--" : s.flare));
                if (col.isAttachedToWindow()) {
                    col.postDelayed(this, 500);
                }
            }
        };
        attachLoop(col, upd);
        return col;
    }

    private void attachLoop(final View v, final Runnable r) {
        v.addOnAttachStateChangeListener(new OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View x) {
                v.post(r);
            }

            @Override
            public void onViewDetachedFromWindow(View x) {
                v.removeCallbacks(r);
            }
        });
    }

    private View gunPage() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        col.setBackgroundColor(0xFF030805);
        final TextView rounds = text("", big ? 40f : 32f, HUD);
        rounds.setPadding(0, dp(10), 0, 0);
        col.addView(rounds, wide());
        final TextView burst = text("", 12f, Theme.DIM);
        col.addView(burst, wide());
        final int[] startRounds = {-1};
        TextView fire = bigButton("HOLD TO FIRE", 0xFFFF453A);
        fire.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                startRounds[0] = DcsLink.st.shells;
                host.buzz(30);
                key("SPACE", true, true);
                v.setAlpha(0.6f);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                key("SPACE", false, true);
                v.setAlpha(1f);
            }
            return true;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
        lp.setMargins(dp(10), dp(10), dp(10), dp(6));
        col.addView(fire, lp);
        TextView sel = chip("SELECT GUN (C)", () -> key("C", true, false));
        LinearLayout.LayoutParams sp = wide();
        sp.setMargins(dp(10), 0, dp(10), dp(8));
        col.addView(sel, sp);
        attachLoop(col, new Runnable() {
            @Override
            public void run() {
                int sh = DcsLink.st.shells;
                rounds.setText(sh < 0 ? "-- RDS" : sh + " RDS");
                burst.setText(startRounds[0] >= 0 && sh >= 0 ? "last burst: " + Math.max(0, startRounds[0] - sh) + " rounds" : "Space on the PC");
                if (col.isAttachedToWindow()) {
                    col.postDelayed(this, 200);
                }
            }
        });
        return col;
    }

    private long timerEnd;
    private String timerName = "";
    private long swStart;
    private long swAcc;

    private View timerPage() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        col.setBackgroundColor(0xFF030805);
        final TextView big1 = text("", big ? 44f : 34f, HUD);
        big1.setPadding(0, dp(10), 0, 0);
        col.addView(big1, wide());
        final TextView lab = text("", 12f, Theme.DIM);
        col.addView(lab, wide());
        LinearLayout r = row();
        Object[][] fox = {{"FOX 1", 45}, {"FOX 2", 15}, {"FOX 3", 60}, {"BOMB", 25}};
        for (Object[] f : fox) {
            TextView b = chip((String) f[0] + "\n" + f[1] + " s", () -> {
                timerEnd = SystemClock.uptimeMillis() + (int) f[1] * 1000L;
                timerName = (String) f[0];
                host.buzz(30);
            });
            LinearLayout.LayoutParams lp = weight(1f);
            lp.setMargins(dp(2), dp(6), dp(2), dp(6));
            r.addView(b, lp);
        }
        col.addView(r, wide());
        final TextView sw = text("", big ? 30f : 24f, 0xFFE5E5EA);
        sw.setPadding(0, dp(14), 0, dp(4));
        col.addView(sw, wide());
        LinearLayout r2 = row();
        TextView go = chip("START / STOP", () -> {
            if (swStart > 0) {
                swAcc += SystemClock.uptimeMillis() - swStart;
                swStart = 0;
            } else {
                swStart = SystemClock.uptimeMillis();
            }
        });
        TextView rs = chip("RESET", () -> {
            swStart = 0;
            swAcc = 0;
        });
        r2.addView(go, weight(1f));
        r2.addView(rs, weight(1f));
        col.addView(r2, wide());
        attachLoop(col, new Runnable() {
            @Override
            public void run() {
                long left = timerEnd - SystemClock.uptimeMillis();
                if (left > 0) {
                    big1.setText(String.format(Locale.ROOT, "%.1f", left / 1000f));
                    big1.setTextColor(left < 5000 ? AMBER : HUD);
                    lab.setText(timerName + " time to impact (rough)");
                } else {
                    big1.setText(timerEnd > 0 ? "IMPACT" : "--.-");
                    lab.setText("start a missile timer when you fire");
                }
                long t = swAcc + (swStart > 0 ? SystemClock.uptimeMillis() - swStart : 0);
                sw.setText(String.format(Locale.ROOT, "STOPWATCH  %02d:%02d.%d", t / 60000, (t / 1000) % 60, (t / 100) % 10));
                if (col.isAttachedToWindow()) {
                    col.postDelayed(this, 100);
                }
            }
        });
        return col;
    }

    // ---------------------------------------------------------------- LSO, CASE I

    private final class LsoView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            float w = getWidth();
            float h = getHeight();
            t(c, "GREENIE BOARD", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            List<String[]> g = new ArrayList<>();
            for (String l : Prefs.getString("dcs_greenie", "").split("\n")) {
                String[] f = l.split("\\|", -1);
                if (f.length >= 5) {
                    g.add(f);
                }
            }
            if (g.isEmpty()) {
                t(c, "No carrier landings yet", w / 2, h / 2, 12, Theme.DIM, Paint.Align.CENTER);
                t(c, "(FREE SIM or DCS traps are graded here)", w / 2, h / 2 + dp(16), 9, Theme.DIM, Paint.Align.CENTER);
                return;
            }
            // the board: one square per pass, newest on the left
            int n = Math.min(10, g.size());
            float sq = Math.min((w - dp(16)) / 10f, dp(30));
            double pts = 0;
            for (int i = 0; i < n; i++) {
                String gr = g.get(i)[1];
                int col = gr.equals("_OK_") ? 0xFF30D158 : gr.equals("OK") ? 0xFF30D158 : gr.equals("(OK)") ? 0xFFFFD23F
                        : gr.equals("B") ? 0xFF0A84FF : gr.equals("C") ? 0xFFFF453A : 0xFF8E6E3A;
                RectF r = new RectF(dp(8) + i * sq, dp(28), dp(8) + i * sq + sq - dp(3), dp(28) + sq - dp(3));
                p.setColor(col);
                c.drawRect(r, p);
                if (gr.equals("_OK_")) {
                    p.setColor(0xFF000000);
                    c.drawCircle(r.centerX(), r.centerY(), dp(4), p);
                }
            }
            for (String[] f : g) {
                pts += f[1].equals("_OK_") ? 5 : f[1].equals("OK") ? 4 : f[1].equals("(OK)") ? 3 : f[1].equals("B") ? 2.5 : f[1].equals("C") ? 0 : 2;
            }
            t(c, String.format(Locale.ROOT, "AVERAGE %.1f  ·  %d PASSES", pts / g.size(), g.size()), dp(8), dp(28) + sq + dp(16), 10,
                    0xFFE5E5EA, Paint.Align.LEFT);
            float y = dp(28) + sq + dp(36);
            for (int i = 0; i < g.size() && y < h - dp(6); i++) {
                String[] f = g.get(i);
                t(c, f[1], dp(8), y, 13, f[1].contains("OK") ? GREEN : f[1].equals("C") ? RED : AMBER, Paint.Align.LEFT);
                t(c, f[2] + "  " + f[3], dp(64), y, 10, 0xFFE5E5EA, Paint.Align.LEFT);
                t(c, f[0] + " " + f[4], w - dp(6), y, 8.5f, Theme.DIM, Paint.Align.RIGHT);
                y += dp(18);
            }
        }
    }

    /** The Case I pattern around the carrier (ship up), with you on it. */
    private final class CaseView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            t(c, "CASE I", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            DcsLink.Obj cv = DcsLink.live() ? nearest(s, true, false, 0) : null;
            float cx = w * 0.55f;
            float cy = h * 0.42f;
            float ppm = Math.min(w, h) / (5.5f * 1852);
            // pattern (ship-relative, metres): initial 3 nm behind, break over the ship, downwind 1.2 nm to the left
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(0x883CFF7A);
            p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(6), dp(4)}, 0));
            float dw = 1.2f * 1852 * ppm;
            c.drawLine(cx, cy + 3 * 1852 * ppm, cx, cy - 0.4f * 1852 * ppm, p);
            RectF brk = new RectF(cx - dw, cy - 0.4f * 1852 * ppm - dw / 2, cx, cy - 0.4f * 1852 * ppm + dw / 2);
            c.drawArc(brk, 270, -180, false, p);
            c.drawLine(cx - dw, cy - 0.4f * 1852 * ppm, cx - dw, cy + 1.0f * 1852 * ppm, p);
            RectF turn = new RectF(cx - dw, cy + 1.0f * 1852 * ppm - dw / 2, cx, cy + 1.0f * 1852 * ppm + dw / 2);
            c.drawArc(turn, 180, -180, false, p);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            // ship
            p.setColor(0xFF6E7380);
            c.drawRoundRect(new RectF(cx - dp(5), cy - dp(16), cx + dp(5), cy + dp(16)), dp(4), dp(4), p);
            t(c, "INITIAL 800 FT", cx + dp(6), cy + 2.6f * 1852 * ppm, 8.5f, Theme.DIM, Paint.Align.LEFT);
            t(c, "BREAK", cx + dp(6), cy - 0.5f * 1852 * ppm, 8.5f, Theme.DIM, Paint.Align.LEFT);
            t(c, "DOWNWIND 600 FT", cx - dw - dp(4), cy + 0.2f * 1852 * ppm, 8.5f, Theme.DIM, Paint.Align.RIGHT);
            t(c, "180", cx - dw - dp(4), cy + 1.0f * 1852 * ppm, 8.5f, Theme.DIM, Paint.Align.RIGHT);
            t(c, "90 · GROOVE", cx - dw / 2, cy + 1.0f * 1852 * ppm + dw / 2 + dp(12), 8.5f, Theme.DIM, Paint.Align.CENTER);
            if (cv == null) {
                t(c, DcsLink.live() ? "NO CARRIER NEAR" : "NO DCS DATA · TRY SIM", w / 2, h - dp(14), 11, Theme.DIM, Paint.Align.CENTER);
                return;
            }
            double hd = Math.toRadians(cv.hdg);
            double dn = s.x - cv.x;
            double de = s.z - cv.z;
            double fwd = dn * Math.cos(hd) + de * Math.sin(hd);
            double right = de * Math.cos(hd) - dn * Math.sin(hd);
            float x = cx + (float) (right * ppm);
            float y = cy - (float) (fwd * ppm);
            p.setColor(0xFFFFD23F);
            p.setShadowLayer(dp(5), 0, 0, 0xFFFFD23F);
            c.save();
            c.rotate(s.hdg - cv.hdg, x, y);
            Path me = new Path();
            me.moveTo(x, y - dp(8));
            me.lineTo(x + dp(6), y + dp(6));
            me.lineTo(x, y + dp(3));
            me.lineTo(x - dp(6), y + dp(6));
            me.close();
            c.drawPath(me, p);
            c.restore();
            p.clearShadowLayer();
            // where am I in the pattern
            String tip;
            double ft = s.alt * 3.28084;
            if (fwd < -1500 && Math.abs(right) < 900) {
                tip = String.format(Locale.ROOT, "INITIAL: %d ft (want 800), 350 kt", Math.round(ft));
            } else if (right < -1200 && Math.abs(fwd) < 2000) {
                tip = String.format(Locale.ROOT, "DOWNWIND: %d ft (want 600), %.1f nm abeam", Math.round(ft), -right / 1852);
            } else if (fwd < -400 && right < -200) {
                tip = String.format(Locale.ROOT, "180 / 90: %d ft, on speed, turn to the groove", Math.round(ft));
            } else {
                tip = String.format(Locale.ROOT, "%d ft · %.1f nm from the ship", Math.round(ft), Math.hypot(dn, de) / 1852);
            }
            t(c, tip, w / 2, h - dp(12), 10, 0xFFFFD23F, Paint.Align.CENTER);
        }
    }

    // ---------------------------------------------------------------- G, TAPES, TANKER

    private float lastHdg;
    private long lastHdgAt;
    private float turnRate;

    private final class GView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            long now = SystemClock.uptimeMillis();
            if (now - lastHdgAt > 500) {
                float d = s.hdg - lastHdg;
                if (d > 180) {
                    d -= 360;
                }
                if (d < -180) {
                    d += 360;
                }
                if (lastHdgAt > 0) {
                    turnRate = turnRate * 0.5f + 0.5f * d / ((now - lastHdgAt) / 1000f);
                }
                lastHdg = s.hdg;
                lastHdgAt = now;
            }
            float cx = w / 2;
            float cy = h * 0.42f;
            float R = Math.min(w, h) * 0.36f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(0xFFE5E5EA);
            c.drawCircle(cx, cy, R, p);
            p.setStyle(Paint.Style.FILL);
            for (int gv = -3; gv <= 10; gv++) {
                double a = Math.toRadians(-225 + (gv + 3) / 13.0 * 270);
                float len = dp(8);
                p.setColor(gv >= 7 ? RED : 0xFFE5E5EA);
                p.setStrokeWidth(dp(1.5f));
                c.drawLine(cx + (float) Math.cos(a) * (R - len), cy + (float) Math.sin(a) * (R - len), cx + (float) Math.cos(a) * R,
                        cy + (float) Math.sin(a) * R, p);
                p.setTextSize(dp(9));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(String.valueOf(gv), cx + (float) Math.cos(a) * (R - dp(18)), cy + (float) Math.sin(a) * (R - dp(18)) + dp(3), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            double am = Math.toRadians(-225 + (Math.max(-3, Math.min(10, DcsLink.maxG)) + 3) / 13.0 * 270);
            p.setColor(AMBER);
            p.setStrokeWidth(dp(2));
            c.drawLine(cx, cy, cx + (float) Math.cos(am) * (R - dp(12)), cy + (float) Math.sin(am) * (R - dp(12)), p);
            double a = Math.toRadians(-225 + (Math.max(-3, Math.min(10, s.g)) + 3) / 13.0 * 270);
            int col = s.g > 7 ? RED : HUD;
            p.setColor(col);
            p.setStrokeWidth(dp(4));
            p.setShadowLayer(dp(5), 0, 0, col);
            c.drawLine(cx, cy, cx + (float) Math.cos(a) * (R - dp(10)), cy + (float) Math.sin(a) * (R - dp(10)), p);
            p.clearShadowLayer();
            c.drawCircle(cx, cy, dp(5), p);
            t(c, String.format(Locale.ROOT, "%.1f G", s.g), cx, cy + R * 0.5f, 18, col, Paint.Align.CENTER);
            float y = h * 0.82f;
            t(c, String.format(Locale.ROOT, "MAX %.1f G   OVER 7 G: %d s", DcsLink.maxG, DcsLink.timeOver7 / 1000), w / 2, y, 11, AMBER,
                    Paint.Align.CENTER);
            t(c, String.format(Locale.ROOT, "TURN %.1f°/S   CLIMB %+d FPM", Math.abs(turnRate), Math.round(s.vs * 196.85f)), w / 2,
                    y + dp(18), 11, 0xFFE5E5EA, Paint.Align.CENTER);
        }
    }

    private final class TapesView extends Mfd {
        private void tape(Canvas c, float x, float tw, float h, float v, float step, int labelEvery, String unit, String label) {
            float cy = h / 2;
            float pxPer = dp(22) / step;
            p.setColor(0xFF0E1418);
            c.drawRect(x, dp(24), x + tw, h - dp(10), p);
            c.save();
            c.clipRect(x, dp(24), x + tw, h - dp(10));
            p.setColor(0xFFE5E5EA);
            p.setStrokeWidth(dp(1.2f));
            p.setTextSize(dp(10));
            float first = (float) Math.floor((v - (h / 2) / pxPer) / step) * step;
            for (float m = first; m < v + (h / 2) / pxPer; m += step) {
                float y = cy - (m - v) * pxPer;
                boolean lab = Math.round(m / step) % labelEvery == 0;
                c.drawLine(x + tw - (lab ? dp(14) : dp(7)), y, x + tw, y, p);
                if (lab) {
                    c.drawText(String.valueOf(Math.round(m)), x + dp(4), y + dp(4), p);
                }
            }
            c.restore();
            p.setColor(0xFF000000);
            RectF box = new RectF(x - dp(2), cy - dp(12), x + tw + dp(2), cy + dp(12));
            c.drawRect(box, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(HUD);
            c.drawRect(box, p);
            p.setStyle(Paint.Style.FILL);
            t(c, String.valueOf(Math.round(v)), box.centerX(), cy + dp(5), 13, HUD, Paint.Align.CENTER);
            t(c, label + " " + unit, x + tw / 2, dp(16), 9, Theme.DIM, Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float tw = (w - dp(32)) / 3f;
            tape(c, dp(8), tw, h, s.ias * 1.94384f, 10, 5, "KT", "SPEED");
            tape(c, dp(16) + tw, tw, h, s.alt * 3.28084f, 100, 5, "FT", "ALT");
            tape(c, dp(24) + tw * 2, tw, h, s.vs * 196.85f, 500, 2, "FPM", "VSI");
            if (!DcsLink.live()) {
                noData(c);
            }
        }
    }

    private float tankerLast = -1;
    private long tankerAt;
    private float tankerClose;

    private final class TankerView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            t(c, "TANKER", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            DcsLink.Obj tk = DcsLink.live() ? nearest(s, false, true, 1) : null;
            if (tk == null) {
                t(c, DcsLink.live() ? "NO FRIENDLY TANKER" : "NO DCS DATA · TRY SIM", w / 2, h / 2, 12, Theme.DIM, Paint.Align.CENTER);
                return;
            }
            double hd = Math.toRadians(tk.hdg);
            double dn = s.x - tk.x;
            double de = s.z - tk.z;
            double behind = -(dn * Math.cos(hd) + de * Math.sin(hd));
            double right = de * Math.cos(hd) - dn * Math.sin(hd);
            double up = s.alt - tk.alt;
            double d = Math.sqrt(dn * dn + de * de + up * up);
            long now = SystemClock.uptimeMillis();
            if (now - tankerAt > 1000) {
                if (tankerLast >= 0) {
                    tankerClose = (float) ((tankerLast - d) / ((now - tankerAt) / 1000.0));
                }
                tankerLast = (float) d;
                tankerAt = now;
            }
            t(c, tk.name, w - dp(8), dp(18), 10, 0xFF4FA8FF, Paint.Align.RIGHT);
            // rear view: the tanker seen from behind, you as a dot (1 square = 50 ft)
            float cx = w / 2;
            float cy = h * 0.42f;
            float sc = dp(1.6f);
            p.setColor(0xFF4A5059);
            c.drawRect(cx - dp(70), cy - dp(3), cx + dp(70), cy + dp(3), p);
            c.drawRoundRect(new RectF(cx - dp(9), cy - dp(10), cx + dp(9), cy + dp(10)), dp(8), dp(8), p);
            c.drawRect(cx - dp(2), cy - dp(28), cx + dp(2), cy - dp(8), p);
            p.setColor(0xFF2BFF5A);
            p.setStrokeWidth(dp(1.5f));
            c.drawLine(cx, cy + dp(10), cx, cy + dp(40), p);
            c.drawCircle(cx, cy + dp(44), dp(5), p);
            float px = cx + (float) Math.max(-w / 2 + dp(10), Math.min(w / 2 - dp(10), right * 3.28084 / 50 * dp(12)));
            float py = cy + dp(44) - (float) Math.max(-h / 3, Math.min(h / 3, (up + 15) * 3.28084 / 50 * dp(12)));
            boolean close = Math.abs(behind) < 300;
            int col = close ? 0xFFFFD23F : 0x88FFD23F;
            p.setColor(col);
            p.setShadowLayer(dp(5), 0, 0, col);
            c.drawCircle(px, py, dp(6), p);
            p.clearShadowLayer();
            float y = h * 0.72f;
            t(c, String.format(Locale.ROOT, "%s  %s", d > 1852 ? nm(d) : Math.round(d * 3.28084) + " FT",
                    behind > 0 ? "BEHIND" : "AHEAD"), w / 2, y, 14, HUD, Paint.Align.CENTER);
            t(c, String.format(Locale.ROOT, "%s %d FT   %s %d FT   CLOSURE %+d KT", right > 0 ? "RIGHT" : "LEFT", Math.abs(Math.round(right * 3.28084)),
                    up > 0 ? "HIGH" : "LOW", Math.abs(Math.round(up * 3.28084)), Math.round(tankerClose * 1.94384f)), w / 2, y + dp(20), 10,
                    0xFFE5E5EA, Paint.Align.CENTER);
            String tip = behind > 900 ? "close in, 20-30 kt faster" : behind > 60 ? "pre-contact: 50 ft behind, slightly low, match speed"
                    : "contact: small inputs, hold position";
            t(c, tip, w / 2, y + dp(38), 10, AMBER, Paint.Align.CENTER);
        }
    }

    // ---------------------------------------------------------------- LOG, KNEEBOARD, CLOCK

    private final class LogView extends Mfd {
        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP && e.getY() < dp(28) && e.getX() > getWidth() - dp(70)) {
                new AlertDialog.Builder(host).setTitle("Clear the flight log?")
                        .setPositiveButton("CLEAR", (d, w) -> {
                            Prefs.putString("dcs_log", "");
                            invalidate();
                        }).setNegativeButton("CANCEL", null).show();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            float w = getWidth();
            float h = getHeight();
            t(c, "FLIGHT LOG", dp(8), dp(18), 12, HUD, Paint.Align.LEFT);
            t(c, "CLEAR", w - dp(8), dp(18), 10, Theme.DIM, Paint.Align.RIGHT);
            float y = dp(40);
            String[] lines = Prefs.getString("dcs_log", "").split("\n");
            boolean any = false;
            for (String l : lines) {
                String[] f = l.split("\\|", -1);
                if (f.length < 3) {
                    continue;
                }
                any = true;
                t(c, f[0], dp(8), y, 8.5f, Theme.DIM, Paint.Align.LEFT);
                t(c, nice(f[1]) + "  " + f[2], dp(84), y, 10, f[2].startsWith("Carrier") ? AMBER : 0xFFE5E5EA, Paint.Align.LEFT);
                y += dp(16);
                if (y > h - dp(6)) {
                    break;
                }
            }
            if (!any) {
                t(c, "Take-offs, landings and traps show up here", w / 2, h / 2, 11, Theme.DIM, Paint.Align.CENTER);
            }
        }
    }

    private static String[] checklist(String fam) {
        if (fam.equals("hornet")) {
            return new String[] {"#COLD START", "Battery ON", "APU ON (wait for the green READY light)", "Right engine crank, IDLE at 25 %",
                "Left engine crank, IDLE at 25 %", "APU OFF", "Canopy close (LCtrl+C)", "INS align (CV on the carrier)",
                "Flaps HALF (LShift+F) for take-off", "Trim set for take-off", "Lights on", "Seat armed",
                "#CARRIER LANDING", "Initial: 800 ft, 350 kt, on the ship's course", "Break over the ship, turn left",
                "Gear DOWN, flaps FULL, hook DOWN", "Downwind: 600 ft, about 1.2 nm abeam", "On speed: amber donut (AoA 8.1)",
                "180 at the stern: start the turn, ~450 ft", "90: ~370 ft, keep turning", "Groove: call the ball",
                "Meatball, lineup, AoA", "Full power on touchdown"};
        }
        return new String[] {"#START (FC3)", "Canopy close (LCtrl+C)", "Engines start (RShift+Home or RAlt / RCtrl+Home)",
            "Lights (RCtrl+L)", "Flaps take-off (F)", "Wheel brakes off (W)", "Throttle up, take off", "Gear UP (G), flaps UP (F)",
            "#COMBAT", "Radar ON (I)", "Mode: 2 BVR, 3/4/5 dogfight", "Weapon (D) or gun (C)", "Chaff Insert, flare Delete",
            "#LANDING", "Speed back, airbrake (B)", "Gear DOWN (G), flaps (F)", "Navigation 1: LANDING", "Touch down, wheel brakes (W)"};
    }

    private View kneePage() {
        final LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        col.setBackgroundColor(0xFFF2EEDF);
        col.setPadding(dp(10), dp(6), dp(10), dp(6));
        ScrollView sv = new ScrollView(host);
        final LinearLayout list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        sv.addView(list);
        Runnable fill = () -> {
            list.removeAllViews();
            String fam = fam();
            for (String item : checklist(fam)) {
                if (item.startsWith("#")) {
                    TextView h = new TextView(host);
                    h.setText(item.substring(1) + "  ·  " + nice(DcsLink.st.name.isEmpty() ? "F/A-18C" : DcsLink.st.name));
                    h.setTextColor(0xFF1E2A3A);
                    h.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                    h.setPadding(0, dp(10), 0, dp(2));
                    list.addView(h);
                    continue;
                }
                android.widget.CheckBox cb = new android.widget.CheckBox(host);
                cb.setText(item);
                cb.setTextColor(0xFF1E1E1E);
                cb.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF1E2A3A));
                list.addView(cb);
            }
            TextView nh = new TextView(host);
            nh.setText("NOTES");
            nh.setTextColor(0xFF1E2A3A);
            nh.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            nh.setPadding(0, dp(12), 0, 0);
            list.addView(nh);
            final EditText notes = new EditText(host);
            notes.setText(Prefs.getString("dcs_notes", ""));
            notes.setTextColor(0xFF1E1E1E);
            notes.setHint("frequencies, TACAN, targets...");
            notes.setMinLines(3);
            notes.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence a, int b, int cc, int d) {
                }

                @Override
                public void onTextChanged(CharSequence a, int b, int cc, int d) {
                }

                @Override
                public void afterTextChanged(android.text.Editable e) {
                    Prefs.putString("dcs_notes", e.toString());
                }
            });
            list.addView(notes);
        };
        fill.run();
        TextView reset = chip("RESET CHECKS", fill);
        col.addView(reset, wide());
        col.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        return col;
    }

    private final class ClockView extends Mfd {
        @Override
        protected void onDraw(Canvas c) {
            glass(c);
            float w = getWidth();
            float h = getHeight();
            java.util.Calendar cal = java.util.Calendar.getInstance();
            t(c, String.format(Locale.ROOT, "%02d:%02d:%02d", cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE),
                    cal.get(java.util.Calendar.SECOND)), w / 2, h * 0.38f, big ? 52 : 40, HUD, Paint.Align.CENTER);
            t(c, "LOCAL TIME", w / 2, h * 0.38f + dp(18), 10, Theme.DIM, Paint.Align.CENTER);
            long z = System.currentTimeMillis();
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", Locale.ROOT);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            t(c, "ZULU " + f.format(new java.util.Date(z)) + "Z", w / 2, h * 0.62f, 18, 0xFFE5E5EA, Paint.Align.CENTER);
            String ft = "--";
            for (double[] ignored : DcsLink.TRAIL) {
                ft = DcsLink.TRAIL.size() / 60 + " MIN TRACKED";
                break;
            }
            t(c, DcsLink.live() ? "FLIGHT " + ft : "NO FLIGHT", w / 2, h * 0.75f, 12, AMBER, Paint.Align.CENTER);
            postInvalidateDelayed(1000);
        }
    }

    // ================================================================== MY PAGES: build your own page

    /** One piece on your page. type: page / lever / btn / read / light / label / dial. x, y, w, h are 0..1 of the page. */
    static final class Item {
        String type;
        String arg;
        float x;
        float y;
        float w;
        float h;

        Item(String type, String arg, float x, float y, float w, float h) {
            this.type = type;
            this.arg = arg;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    static final class MyPage {
        String name;
        final List<Item> items = new ArrayList<>();

        MyPage(String name) {
            this.name = name;
        }
    }

    private static final String K_MY = "dcs_mypages";
    private static List<MyPage> my;
    private final List<Object[]> litCustom = new ArrayList<>();
    private boolean editing;

    static List<MyPage> myPages() {
        if (my != null) {
            return my;
        }
        my = new ArrayList<>();
        try {
            org.json.JSONArray a = new org.json.JSONArray(Prefs.getString(K_MY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                org.json.JSONObject o = a.getJSONObject(i);
                MyPage p = new MyPage(o.optString("name", "MY PAGE"));
                org.json.JSONArray it = o.optJSONArray("items");
                for (int k = 0; it != null && k < it.length(); k++) {
                    org.json.JSONObject e = it.getJSONObject(k);
                    p.items.add(new Item(e.optString("t"), e.optString("a"), (float) e.optDouble("x"), (float) e.optDouble("y"),
                            (float) e.optDouble("w"), (float) e.optDouble("h")));
                }
                my.add(p);
            }
        } catch (Exception ignored) {
            // broken save: start empty
        }
        return my;
    }

    static void saveMy() {
        try {
            org.json.JSONArray a = new org.json.JSONArray();
            for (MyPage p : myPages()) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("name", p.name);
                org.json.JSONArray it = new org.json.JSONArray();
                for (Item e : p.items) {
                    org.json.JSONObject j = new org.json.JSONObject();
                    j.put("t", e.type);
                    j.put("a", e.arg);
                    j.put("x", e.x);
                    j.put("y", e.y);
                    j.put("w", e.w);
                    j.put("h", e.h);
                    it.put(j);
                }
                o.put("items", it);
                a.put(o);
            }
            Prefs.putString(K_MY, a.toString());
        } catch (Exception ignored) {
            // keep the old save
        }
    }

    private String name(int id) {
        if (id >= 100) {
            List<MyPage> m = myPages();
            return id - 100 < m.size() ? "★ " + m.get(id - 100).name : "?";
        }
        return PAGES[id];
    }

    /** All pages: the built-in ones, then yours. */
    private void rebuildOrder() {
        if (!full) {
            return;
        }
        int n = myPages().size();
        int[] o = new int[PAGES.length + n];
        for (int i = 0; i < PAGES.length; i++) {
            o[i] = i;
        }
        for (int i = 0; i < n; i++) {
            o[PAGES.length + i] = 100 + i;
        }
        order = o;
    }

    private static Item it(String t, String a, float x, float y, float w, float h) {
        return new Item(t, a, x, y, w, h);
    }

    /** Ready-made pages to start from. */
    private MyPage preset(int which) {
        if (which == 1) {
            MyPage p = new MyPage("CARRIER LANDING");
            p.items.add(it("page", "2", 0, 0, 1, 0.52f));
            p.items.add(it("lever", "", 0, 0.54f, 0.24f, 0.46f));
            p.items.add(it("btn", "GEAR|G|0|-1|0", 0.26f, 0.54f, 0.24f, 0.13f));
            p.items.add(it("btn", "HOOK|LCTRL+H|3|-1|0", 0.51f, 0.54f, 0.24f, 0.13f));
            p.items.add(it("btn", "FLAPS FULL|LCTRL+F|1|1|0", 0.76f, 0.54f, 0.24f, 0.13f));
            p.items.add(it("btn", "WHEEL BRAKE|W|-1|-1|1", 0.26f, 0.68f, 0.24f, 0.13f));
            p.items.add(it("btn", "AIRBRAKE|B|2|-1|0", 0.51f, 0.68f, 0.24f, 0.13f));
            p.items.add(it("light", "0", 0.76f, 0.68f, 0.24f, 0.06f));
            p.items.add(it("light", "3", 0.76f, 0.75f, 0.24f, 0.06f));
            p.items.add(it("read", "AOA", 0.26f, 0.83f, 0.24f, 0.17f));
            p.items.add(it("read", "IAS", 0.51f, 0.83f, 0.24f, 0.17f));
            p.items.add(it("read", "CVN", 0.76f, 0.83f, 0.24f, 0.17f));
            return p;
        }
        if (which == 2) {
            MyPage p = new MyPage("DOGFIGHT");
            p.items.add(it("page", "3", 0, 0, 0.62f, 0.55f));
            p.items.add(it("page", "4", 0.63f, 0, 0.37f, 0.55f));
            p.items.add(it("lever", "", 0, 0.57f, 0.22f, 0.43f));
            p.items.add(it("btn", "FIRE GUN|SPACE|-1|-1|1", 0.24f, 0.57f, 0.37f, 0.2f));
            p.items.add(it("btn", "LOCK|ENTER|-1|-1|0", 0.63f, 0.57f, 0.18f, 0.1f));
            p.items.add(it("btn", "GUN|C|-1|-1|0", 0.82f, 0.57f, 0.18f, 0.1f));
            p.items.add(it("btn", "CHAFF|INS|-1|-1|0", 0.63f, 0.68f, 0.18f, 0.1f));
            p.items.add(it("btn", "FLARE|DEL|-1|-1|0", 0.82f, 0.68f, 0.18f, 0.1f));
            p.items.add(it("read", "G", 0.24f, 0.79f, 0.18f, 0.21f));
            p.items.add(it("read", "IAS", 0.43f, 0.79f, 0.18f, 0.21f));
            p.items.add(it("read", "LOCK", 0.63f, 0.79f, 0.37f, 0.21f));
            return p;
        }
        MyPage p = new MyPage("MY PAGE " + (myPages().size() + 1));
        p.items.add(it("label", "Tap ✎ EDIT, then ＋ ADD", 0.05f, 0.4f, 0.9f, 0.08f));
        return p;
    }

    /** The ＋ on the bezel: make a new page. */
    private void newPage() {
        if (!full) {
            host.toast("Your own pages live in the DCS COCKPIT widget");
            return;
        }
        String[] items = {"Empty page", "Start from CARRIER LANDING", "Start from DOGFIGHT"};
        new AlertDialog.Builder(host).setTitle("＋ New page").setItems(items, (d, w) -> {
            myPages().add(preset(w));
            saveMy();
            rebuildOrder();
            int id = 100 + myPages().size() - 1;
            manual(id);
            if (w == 0) {
                editing = true;
                View v = views.get(id);
                if (v instanceof CustomPage) {
                    ((CustomPage) v).fillBar();
                    invalidateAll(v);
                }
            }
            host.toast(w == 0 ? "Tap ＋ ADD to put things on it" : "Tap ✎ EDIT to change it");
        }).show();
    }

    /** Your page: pieces placed by fractions, draggable and resizable in edit mode. */
    private final class CustomPage extends FrameLayout {
        final int id;
        final MyPage pg;
        private final LinearLayout bar;
        private final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);

        CustomPage(int id) {
            super(host);
            this.id = id;
            this.pg = myPages().get(id - 100);
            setWillNotDraw(false);
            setBackgroundColor(0xFF030805);
            for (Item e : pg.items) {
                addView(new Holder(e));
            }
            bar = new LinearLayout(host);
            bar.setGravity(Gravity.END);
            addView(bar);
            fillBar();
        }

        void fillBar() {
            bar.removeAllViews();
            if (editing) {
                bar.setBackgroundColor(0xCC000000);
                String[] l = {"＋ ADD", Prefs.getBool("dcs_grid", true) ? "GRID ON" : "GRID OFF", "NAME", "✕ PAGE", "✔ DONE"};
                for (int i = 0; i < l.length; i++) {
                    final int k = i;
                    TextView b = chip(l[i], () -> barTap(k));
                    b.setTextSize(9.5f);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
                    lp.setMargins(dp(1), dp(1), dp(1), dp(1));
                    bar.addView(b, lp);
                }
            } else {
                bar.setBackgroundColor(0);
                TextView b = chip("✎ EDIT", () -> {
                    editing = true;
                    fillBar();
                    invalidateAll(this);
                });
                b.setTextSize(9f);
                bar.addView(b);
            }
        }

        private void barTap(int k) {
            if (k == 0) {
                addMenu(this);
            } else if (k == 1) {
                Prefs.putBool("dcs_grid", !Prefs.getBool("dcs_grid", true));
                fillBar();
                invalidate();
            } else if (k == 2) {
                final EditText e = new EditText(host);
                e.setText(pg.name);
                e.setSingleLine(true);
                new AlertDialog.Builder(host).setTitle("Page name").setView(e)
                        .setPositiveButton("OK", (d, w) -> {
                            pg.name = e.getText().toString().trim().isEmpty() ? pg.name : e.getText().toString().trim().toUpperCase(Locale.ROOT);
                            saveMy();
                            show(id);
                        }).setNegativeButton("CANCEL", null).show();
            } else if (k == 3) {
                new AlertDialog.Builder(host).setTitle("Delete “" + pg.name + "”?")
                        .setPositiveButton("DELETE", (d, w) -> {
                            myPages().remove(pg);
                            saveMy();
                            views.clear();
                            litCustom.clear();
                            rebuildOrder();
                            editing = false;
                            show(order[0]);
                        }).setNegativeButton("CANCEL", null).show();
            } else {
                editing = false;
                saveMy();
                fillBar();
                invalidateAll(this);
                host.toast("Saved ✔");
            }
        }

        void add(Item e) {
            pg.items.add(e);
            saveMy();
            addView(new Holder(e), getChildCount() - 1);
            bar.bringToFront();
        }

        @Override
        protected void onMeasure(int wm, int hm) {
            int w = MeasureSpec.getSize(wm);
            int h = MeasureSpec.getSize(hm);
            setMeasuredDimension(w, h);
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Holder) {
                    Item e = ((Holder) c).e;
                    c.measure(MeasureSpec.makeMeasureSpec(Math.max(dp(20), Math.round(e.w * w)), MeasureSpec.EXACTLY),
                            MeasureSpec.makeMeasureSpec(Math.max(dp(16), Math.round(e.h * h)), MeasureSpec.EXACTLY));
                } else {
                    c.measure(MeasureSpec.makeMeasureSpec(editing ? w : w / 3, MeasureSpec.EXACTLY),
                            MeasureSpec.makeMeasureSpec(h, MeasureSpec.AT_MOST));
                }
            }
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int w = r - l;
            int h = b - t;
            for (int i = 0; i < getChildCount(); i++) {
                View c = getChildAt(i);
                if (c instanceof Holder) {
                    Item e = ((Holder) c).e;
                    int x = Math.round(e.x * w);
                    int y = Math.round(e.y * h);
                    c.layout(x, y, x + c.getMeasuredWidth(), y + c.getMeasuredHeight());
                } else {
                    c.layout(w - c.getMeasuredWidth(), 0, w, c.getMeasuredHeight());
                }
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            if (!editing || !Prefs.getBool("dcs_grid", true)) {
                return;
            }
            gp.setColor(0x223CFF7A);
            float w = getWidth();
            float h = getHeight();
            for (int i = 1; i < 24; i++) {
                for (int k = 1; k < 24; k++) {
                    c.drawCircle(w * i / 24f, h * k / 24f, dp(0.8f), gp);
                }
            }
        }
    }

    private static void invalidateAll(View v) {
        v.invalidate();
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                invalidateAll(g.getChildAt(i));
            }
        }
    }

    private float snap(float v) {
        return Prefs.getBool("dcs_grid", true) ? Math.round(v * 24) / 24f : v;
    }

    /** Wraps one piece: shows it, and in edit mode lets you drag it (anywhere) and resize it (bottom-right corner). */
    private final class Holder extends FrameLayout {
        final Item e;
        private final Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float sx;
        private float sy;
        private float ox;
        private float oy;
        private float ow;
        private float oh;
        private boolean resize;
        private boolean moved;
        private long downAt;

        Holder(Item e) {
            super(host);
            this.e = e;
            setWillNotDraw(false);
            View v = makeItem(e);
            addView(v, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            return editing;
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            if (!editing) {
                return false;
            }
            View page = (View) getParent();
            float pw = page.getWidth();
            float ph = page.getHeight();
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    pager.requestDisallowInterceptTouchEvent(true);
                    sx = ev.getRawX();
                    sy = ev.getRawY();
                    ox = e.x;
                    oy = e.y;
                    ow = e.w;
                    oh = e.h;
                    resize = ev.getX() > getWidth() - dp(28) && ev.getY() > getHeight() - dp(28);
                    moved = false;
                    downAt = SystemClock.uptimeMillis();
                    bringToFront();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = (ev.getRawX() - sx) / pw;
                    float dy = (ev.getRawY() - sy) / ph;
                    if (Math.abs(ev.getRawX() - sx) + Math.abs(ev.getRawY() - sy) > dp(6)) {
                        moved = true;
                    }
                    if (resize) {
                        e.w = Math.max(0.06f, Math.min(1 - e.x, snap(ow + dx)));
                        e.h = Math.max(0.04f, Math.min(1 - e.y, snap(oh + dy)));
                    } else {
                        e.x = Math.max(0, Math.min(1 - e.w, snap(ox + dx)));
                        e.y = Math.max(0, Math.min(1 - e.h, snap(oy + dy)));
                    }
                    page.requestLayout();
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved && SystemClock.uptimeMillis() - downAt > 450) {
                        itemMenu(this);
                    }
                    saveMy();
                    return true;
                default:
                    return true;
            }
        }

        @Override
        protected void dispatchDraw(Canvas c) {
            super.dispatchDraw(c);
            if (!editing) {
                return;
            }
            float w = getWidth();
            float h = getHeight();
            hp.setStyle(Paint.Style.STROKE);
            hp.setStrokeWidth(dp(1.5f));
            hp.setColor(0xFFFFD23F);
            hp.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(5), dp(4)}, 0));
            c.drawRect(dp(1), dp(1), w - dp(1), h - dp(1), hp);
            hp.setPathEffect(null);
            hp.setStyle(Paint.Style.FILL);
            Path tri = new Path();
            tri.moveTo(w, h - dp(22));
            tri.lineTo(w, h);
            tri.lineTo(w - dp(22), h);
            tri.close();
            c.drawPath(tri, hp);
        }
    }

    private void itemMenu(final Holder hd) {
        final Item e = hd.e;
        List<String> opts = new ArrayList<>();
        opts.add("🗑 Delete");
        opts.add("⧉ Duplicate");
        opts.add("⬆ Bring to front");
        opts.add("⤢ Fill the width");
        if (e.type.equals("btn") || e.type.equals("label")) {
            opts.add("✎ Change text / key");
        }
        new AlertDialog.Builder(host).setItems(opts.toArray(new String[0]), (d, w) -> {
            CustomPage page = (CustomPage) hd.getParent();
            if (w == 0) {
                page.pg.items.remove(e);
                page.removeView(hd);
            } else if (w == 1) {
                Item c = new Item(e.type, e.arg, Math.min(1 - e.w, e.x + 0.04f), Math.min(1 - e.h, e.y + 0.04f), e.w, e.h);
                page.add(c);
            } else if (w == 2) {
                page.pg.items.remove(e);
                page.pg.items.add(e);
                hd.bringToFront();
            } else if (w == 3) {
                e.x = 0;
                e.w = 1;
                page.requestLayout();
            } else if (e.type.equals("label")) {
                final EditText t = new EditText(host);
                t.setText(e.arg);
                new AlertDialog.Builder(host).setTitle("Text").setView(t).setPositiveButton("OK", (dd, ww) -> {
                    e.arg = t.getText().toString();
                    saveMy();
                    show(page.id);
                }).show();
            } else {
                String[] f = e.arg.split("\\|", -1);
                LinearLayout fl = new LinearLayout(host);
                fl.setOrientation(VERTICAL);
                fl.setPadding(dp(18), dp(6), dp(18), 0);
                final EditText nm = new EditText(host);
                nm.setText(f[0]);
                final EditText ky = new EditText(host);
                ky.setText(f.length > 1 ? f[1] : "G");
                ky.setHint("Key, e.g. G, LCTRL+H, x3:LCTRL+E");
                final android.widget.CheckBox hold = new android.widget.CheckBox(host);
                hold.setText("Hold (key stays down while pressed)");
                hold.setChecked(f.length > 4 && f[4].equals("1"));
                fl.addView(nm);
                fl.addView(ky);
                fl.addView(hold);
                new AlertDialog.Builder(host).setTitle("Button").setView(fl).setPositiveButton("SAVE", (dd, ww) -> {
                    String k = ky.getText().toString().trim().toUpperCase(Locale.ROOT);
                    Object[] pk = DcsKeysWidget.parse(k.isEmpty() ? "G" : k);
                    if (PcHid.rawCode((String) pk[1]) == 0) {
                        host.toast("Unknown key: " + pk[1]);
                        return;
                    }
                    e.arg = nm.getText().toString().trim().toUpperCase(Locale.ROOT) + "|" + k + "|" + (f.length > 2 ? f[2] : "-1") + "|"
                            + (f.length > 3 ? f[3] : "-1") + "|" + (hold.isChecked() ? "1" : "0");
                    saveMy();
                    show(page.id);
                }).setNegativeButton("CANCEL", null).show();
            }
            saveMy();
        }).show();
    }

    private static final String[][] READS = {{"IAS", "SPEED"}, {"MACH", "MACH"}, {"ALT", "ALTITUDE"}, {"AGL", "RADAR ALT"},
        {"VS", "VERTICAL SPEED"}, {"HDG", "HEADING"}, {"AOA", "AoA"}, {"G", "G"}, {"FUEL", "FUEL"}, {"MIN", "MINUTES LEFT"},
        {"CVN", "CARRIER DISTANCE"}, {"GS", "GLIDE SLOPE"}, {"LU", "LINEUP"}, {"LOCK", "LOCK RANGE"}, {"AP", "AUTOPILOT"},
        {"THR", "THRUST"}};

    private static final String[] PAGE_ICONS = {"\uD83C\uDF9A", "\u2708", "\uD83D\uDEEC", "\uD83D\uDCE1", "\uD83C\uDFAF", "\uD83D\uDFE9",
        "\uD83D\uDDFA", "\uD83E\uDDED", "\uD83E\uDDED", "\uD83D\uDCCD", "\uD83C\uDF10", "\u2699", "\u26FD", "\u26A0", "\uD83D\uDCE1",
        "\uD83D\uDCA3", "\u2728", "\uD83D\uDD2B", "\u23F1", "\uD83D\uDFE2", "\uD83D\uDEA2", "\uD83D\uDCAA", "\uD83D\uDCCF",
        "\u26FD", "\uD83D\uDCD3", "\uD83D\uDCCB", "\uD83D\uDD52"};

    /** Everything you can put on your page, in one list: every page first (radar, map...), then the rest. */
    private void addMenu(final CustomPage page) {
        final float px = 0.05f + (page.pg.items.size() % 5) * 0.04f;
        final float py = 0.1f + (page.pg.items.size() % 5) * 0.04f;
        final List<String> names = new ArrayList<>();
        final List<Runnable> acts = new ArrayList<>();
        for (int k = 0; k < PAGES.length; k++) {
            final int kk = k;
            names.add(PAGE_ICONS[k] + "  " + PAGES[k]);
            boolean wide = k == 3 || k == 6 || k == 2 || k == 5 || k == 10 || k == 14;
            acts.add(() -> page.add(new Item("page", String.valueOf(kk), px, py, wide ? 0.7f : 0.55f, wide ? 0.5f : 0.4f)));
        }
        names.add("\uD83C\uDF9A  THRUST LEVER (on its own)");
        acts.add(() -> page.add(new Item("lever", "", px, py, 0.24f, 0.45f)));
        names.add("\u25A2  A BUTTON\u2026");
        acts.add(() -> addButton(page, px, py));
        names.add("\uD83D\uDD22  A NUMBER (speed, alt, AoA, G, fuel\u2026)");
        acts.add(() -> {
            String[] n = new String[READS.length];
            for (int i = 0; i < READS.length; i++) {
                n[i] = READS[i][1];
            }
            new AlertDialog.Builder(host).setTitle("Which number?").setItems(n, (dd, k) ->
                    page.add(new Item("read", READS[k][0], px, py, 0.26f, 0.13f))).show();
        });
        names.add("\uD83D\uDCA1  A STATUS LIGHT (gear, flaps, hook\u2026)");
        acts.add(() -> {
            String[] n = {"GEAR", "FLAPS", "AIRBRAKE", "HOOK", "CANOPY"};
            new AlertDialog.Builder(host).setTitle("Which light?").setItems(n, (dd, k) ->
                    page.add(new Item("light", String.valueOf(k), px, py, 0.24f, 0.07f))).show();
        });
        names.add("\u2B55  AUTOPILOT DIAL");
        acts.add(() -> page.add(new Item("dial", "", px, py, 0.5f, 0.35f)));
        names.add("\uD83C\uDFAF  WEAPONS (pick weapon, target, fire)");
        acts.add(() -> page.add(new Item("weapons", "", px, py, 0.9f, 0.75f)));
        names.add("\uD83D\uDDA5  PC SCREEN (live, tap to click)");
        acts.add(() -> page.add(new Item("screen", "", px, py, 0.7f, 0.4f)));
        names.add("T  TEXT LABEL");
        acts.add(() -> page.add(new Item("label", "TEXT", px, py, 0.4f, 0.07f)));
        new AlertDialog.Builder(host).setTitle("\uFF0B Add anything").setItems(names.toArray(new String[0]), (d, w) -> {
            acts.get(w).run();
            host.toast("Added: drag it, resize it with the yellow corner");
        }).show();
    }

    private void addButton(final CustomPage page, final float px, final float py) {
        final Object[][] b = buttons(fam());
        List<String> names = new ArrayList<>();
        for (Object[] x : b) {
            names.add(x[0] + "  (" + DcsKeysWidget.pretty((String) x[1]) + ")");
        }
        final String[][] extra = {{"MAP", "F10"}, {"COCKPIT", "F1"}, {"OUTSIDE", "F2"}, {"LABELS", "LSHIFT+F10"}, {"COMMS", "BACKSLASH"},
            {"PAUSE", "PAUSE"}, {"EJECT", "x3:LCTRL+E"}, {"AUTO START", "LWIN+HOME"}};
        for (String[] x : extra) {
            names.add(x[0] + "  (" + DcsKeysWidget.pretty(x[1]) + ")");
        }
        names.add("\u270E Your own button\u2026");
        new AlertDialog.Builder(host).setTitle("Which button?").setItems(names.toArray(new String[0]), (dd, k) -> {
            String arg;
            if (k < b.length) {
                Object[] x = b[k];
                arg = x[0] + "|" + x[1] + "|" + x[2] + "|" + x[3] + "|" + ((boolean) x[4] ? "1" : "0");
            } else if (k < b.length + extra.length) {
                String[] x = extra[k - b.length];
                arg = x[0] + "|" + x[1] + "|-1|-1|0";
            } else {
                arg = "MY KEY|G|-1|-1|0";
            }
            page.add(new Item("btn", arg, px, py, 0.24f, 0.12f));
            if (k >= b.length + extra.length) {
                host.toast("Hold it in EDIT to set the key");
            }
        }).show();
    }

    /** Builds the live view for one piece. */
    private View makeItem(Item e) {
        switch (e.type) {
            case "page": {
                int k = 0;
                try {
                    k = Integer.parseInt(e.arg);
                } catch (NumberFormatException ignored) {
                    // first page
                }
                return make(Math.max(0, Math.min(PAGES.length - 1, k)));
            }
            case "lever":
                return new Lever();
            case "dial":
                return new HeadingDial();
            case "weapons":
                return new DcsWeaponsWidget(host);
            case "screen":
                return new PcScreenWidget(host, false, true);
            case "read":
                return new Readout(e.arg);
            case "light":
                return new Lamp(Integer.parseInt(e.arg.isEmpty() ? "0" : e.arg));
            case "label": {
                TextView t = text(e.arg, 11f, HUD);
                t.setGravity(Gravity.CENTER);
                return t;
            }
            default: {
                String[] f = e.arg.split("\\|", -1);
                final String label = f[0];
                final String spec = f.length > 1 ? f[1] : "G";
                final int part = f.length > 2 ? parseInt(f[2], -1) : -1;
                final float simV = f.length > 3 ? (float) parseInt(f[3], -1) : -1f;
                final boolean hold = f.length > 4 && f[4].equals("1");
                final TextView t = text(label + "\n" + DcsKeysWidget.pretty(DcsLink.mine(spec)), big ? 12f : 10f, 0xFFFFFFFF);
                t.setGravity(Gravity.CENTER);
                t.setBackground(Theme.rounded(0x33FFFFFF, 12f, host));
                t.setOnTouchListener((v, ev) -> {
                    int a = ev.getActionMasked();
                    if (a == MotionEvent.ACTION_DOWN) {
                        v.setAlpha(0.6f);
                        host.buzz(10);
                        press(spec, part, simV, true, hold);
                        return true;
                    }
                    if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                        v.setAlpha(1f);
                        if (hold) {
                            press(spec, part, simV, false, true);
                        }
                    }
                    return true;
                });
                if (part >= 0) {
                    litCustom.add(new Object[] {t, part, simV});
                }
                return t;
            }
        }
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** One number in a box; the text grows with the box. */
    private final class Readout extends Mfd {
        private final String key;

        Readout(String key) {
            this.key = key;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setColor(0xFF071410);
            c.drawRoundRect(new RectF(0, 0, w, h), dp(8), dp(8), p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x553CFF7A);
            p.setStrokeWidth(dp(1));
            c.drawRoundRect(new RectF(dp(0.5f), dp(0.5f), w - dp(0.5f), h - dp(0.5f)), dp(8), dp(8), p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Theme.MONO);
            DcsLink.State s = DcsLink.st;
            String lab = key;
            for (String[] r : READS) {
                if (r[0].equals(key)) {
                    lab = r[1];
                }
            }
            String v;
            int col = HUD;
            double[] ap = DcsLink.approach(s, DcsLink.objs);
            switch (key) {
                case "IAS":
                    v = Math.round(s.ias * 1.94384f) + " KT";
                    break;
                case "MACH":
                    v = String.format(Locale.ROOT, "%.2f", s.mach);
                    break;
                case "ALT":
                    v = String.format(Locale.ROOT, "%,d FT", Math.round(s.alt * 3.28084f));
                    break;
                case "AGL":
                    v = Math.round(s.agl * 3.28084f) + " FT";
                    break;
                case "VS":
                    v = String.format(Locale.ROOT, "%+d", Math.round(s.vs * 196.85f));
                    break;
                case "HDG":
                    v = String.format(Locale.ROOT, "%03d°", Math.round((s.hdg + 360) % 360));
                    break;
                case "AOA":
                    v = String.format(Locale.ROOT, "%.1f", s.aoa);
                    col = s.aoa > 8.8f ? GREEN : s.aoa < 7.4f ? RED : AMBER;
                    break;
                case "G":
                    v = String.format(Locale.ROOT, "%.1f", s.g);
                    col = s.g > 7 ? RED : HUD;
                    break;
                case "FUEL":
                    v = Math.round((s.fuel + s.fuelExt) * (family(s.name).equals("hornet") ? 2.20462f : 1f)) + "";
                    col = s.fuel + s.fuelExt < bingo() ? RED : HUD;
                    break;
                case "MIN":
                    v = burn > 1 ? Math.round((s.fuel + s.fuelExt) / burn) + " MIN" : "--";
                    break;
                case "CVN":
                    v = ap == null ? "--" : String.format(Locale.ROOT, "%.2f NM", ap[0] / 1852.0);
                    break;
                case "GS":
                    v = ap == null ? "--" : String.format(Locale.ROOT, "%+.1f°", ap[3]);
                    col = ap == null ? HUD : Math.abs(ap[3]) < 0.35 ? GREEN : Math.abs(ap[3]) < 0.8 ? AMBER : RED;
                    break;
                case "LU":
                    v = ap == null ? "--" : String.format(Locale.ROOT, "%+.1f°", ap[4]);
                    col = ap == null ? HUD : Math.abs(ap[4]) < 0.6 ? GREEN : Math.abs(ap[4]) < 1.5 ? AMBER : RED;
                    break;
                case "LOCK":
                    v = s.lockDist > 0 ? String.format(Locale.ROOT, "%.1f NM", s.lockDist / 1852.0) : "NO LOCK";
                    col = s.lockDist > 0 ? 0xFFFF5A4A : HUD;
                    break;
                case "AP":
                    v = DcsLink.apMode == 0 ? "OFF" : String.format(Locale.ROOT, "%03d", Math.round(DcsLink.apTarget()));
                    col = DcsLink.apMode > 0 ? 0xFFFFD23F : HUD;
                    break;
                default:
                    v = Math.round(DcsLink.throttle * 100) + "%";
                    break;
            }
            if (!DcsLink.live() && !key.equals("THR") && !key.equals("AP")) {
                v = "--";
            }
            float big0 = Math.min(h * 0.45f, w / Math.max(3, v.length()) * 1.6f);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(Math.max(dp(7), Math.min(h * 0.22f, dp(11))));
            p.setColor(Theme.DIM);
            c.drawText(lab, w / 2, h * 0.3f, p);
            p.setTextSize(big0);
            p.setColor(col);
            p.setShadowLayer(dp(4), 0, 0, col);
            c.drawText(v, w / 2, h * 0.3f + big0 + dp(2), p);
            p.clearShadowLayer();
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    /** A status lamp: green = down / out, amber = moving, dark = up / in. */
    private final class Lamp extends Mfd {
        private final int part;

        Lamp(int part) {
            this.part = part;
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float v = part == 0 ? s.gear : part == 1 ? s.flaps : part == 2 ? s.brake : part == 3 ? s.hook : s.canopy;
            String[] n = {"GEAR", "FLAPS", "AIRBRAKE", "HOOK", "CANOPY"};
            float w = getWidth();
            float h = getHeight();
            int col = !DcsLink.live() ? 0xFF2A2F35 : v > 0.95f ? GREEN : v > 0.05f ? AMBER : 0xFF2A2F35;
            p.setColor((col & 0x00FFFFFF) | 0xDD000000);
            if (col != 0xFF2A2F35) {
                p.setShadowLayer(dp(6), 0, 0, col);
            }
            c.drawRoundRect(new RectF(dp(2), dp(2), w - dp(2), h - dp(2)), dp(8), dp(8), p);
            p.clearShadowLayer();
            p.setTypeface(Theme.MONO);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(Math.min(h * 0.5f, dp(13)));
            p.setColor(col == 0xFF2A2F35 ? 0xFF6A7078 : 0xFF000000);
            c.drawText(n[Math.max(0, Math.min(4, part))], w / 2, h / 2 + p.getTextSize() / 3, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    // ------------------------------------------------------------------ setup and full screen

    static String script(android.content.Context c) {
        try (InputStream in = c.getAssets().open("NovaExport.lua")) {
            byte[] b = new byte[in.available()];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void setup() {
        String ip = "?";
        try {
            for (java.net.NetworkInterface ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress a : java.util.Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address && ni.getName().startsWith("wlan")) {
                        ip = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
            // no Wi-Fi
        }
        String msg = "DATA (radar, carrier, panels)\n"
                + "1. On the PC open:  Saved Games\\DCS\\Scripts  (make the Scripts folder if it is missing; on the beta it is "
                + "DCS.openbeta).\n"
                + "2. No Export.lua there? Save the NOVA script as  Export.lua.\n"
                + "   Already have one (Tacview, SRS...)? Save it as  NovaExport.lua  and add this line at the end of Export.lua:\n"
                + "   dofile(lfs.writedir()..[[Scripts\\NovaExport.lua]])\n"
                + "3. Phone and PC on the same Wi-Fi / router. If Windows asks, allow DCS through the firewall.\n"
                + "4. Start a mission: the dot here turns green.\n"
                + "   Nothing arrives? Open the script and change 255.255.255.255 to this phone's IP: " + ip + "\n\n"
                + "THRUST LEVER\n"
                + "AXIS mode: in DCS Options > Controls > your aircraft > Axis Commands > Thrust, click the cell under "
                + "NOVA Remote and move the lever. If NOVA Remote has no axis column, remove the phone in Windows Bluetooth "
                + "and pair again once.\nKEYS mode needs no setup (uses Num+ / Num−).\n\n"
                + "BUTTONS use the KEY DECK / PC REMOTE Bluetooth connection.";
        new AlertDialog.Builder(host).setTitle("DCS COCKPIT setup")
                .setMessage(msg)
                .setPositiveButton("SHARE SCRIPT", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "NovaExport.lua");
                    i.putExtra(Intent.EXTRA_TEXT, script(host));
                    host.startActivity(Intent.createChooser(i, "Send the DCS script to your PC"));
                })
                .setNeutralButton("INSTALL ON THE PC", (d, w) -> {
                    if (!PcHid.connected()) {
                        host.toast("Connect the phone to the PC first (KEY DECK > CONNECT)");
                        return;
                    }
                    boolean ok = NovaInstall.install(host, "dcs", r -> {
                        if (r.startsWith("NODCS")) {
                            host.toast("No Saved Games\\DCS folder on this PC: start DCS once, then INSTALL again");
                        } else if (r.contains("FAILED")) {
                            host.toast("Install problem: " + r);
                        } else {
                            host.toast("\u2714 Installed in " + r + ". Start (or restart) a mission");
                        }
                    });
                    if (ok) {
                        host.toast("Installing over Wi-Fi: NOVA types one short line (a few seconds), the PC downloads the rest");
                        return;
                    }
                    final String code = PcHid.compact(script(host), "--");
                    int sec = PcHid.typeSeconds(code) + 4;
                    new AlertDialog.Builder(host).setTitle("No Wi-Fi: type the script instead?")
                            .setMessage("Without Wi-Fi NOVA has to type the whole script into Notepad: about " + (sec / 60)
                                    + " min " + (sec % 60) + " s.\n\nDon't touch the PC or click anything until the "
                                    + "notification \"NOVA is typing\" is gone: every key goes to the window in front.\n\n"
                                    + "If something goes wrong, tap \u25A0 STOP in that notification. Safer: SHARE SCRIPT.")
                            .setPositiveButton("TYPE IT", (dd, ww) -> {
                                PcHid.run("K:WIN+R|W:900|T:notepad|K:ENTER|W:2500");
                                PcHid.type(code);
                            }).setNegativeButton("CANCEL", null).show();
                })
                .setNegativeButton("VOICE " + (Prefs.getBool(K_VOICE, true) ? "ON" : "OFF"), (d, w) -> {
                    Prefs.putBool(K_VOICE, !Prefs.getBool(K_VOICE, true));
                    host.toast("Carrier calls " + (Prefs.getBool(K_VOICE, true) ? "on" : "off"));
                }).show();
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(10), dp(40), dp(10), dp(12));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(full ? "DCS COCKPIT" : "DCS AUTOPILOT", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", () -> {
            host.hideOverlay();
            PcHid.releaseAll();
            refresh();
        }));
        v.addView(head, wide());
        ScrollView sv = new ScrollView(host);
        sv.addView(new DcsCockpitWidget(host, true, full ? null : order));
        v.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    static int dim(int c) {
        return Color.argb(80, Color.red(c), Color.green(c), Color.blue(c));
    }
}
