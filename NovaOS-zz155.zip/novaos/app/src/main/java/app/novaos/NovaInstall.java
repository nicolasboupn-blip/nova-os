package app.novaos;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

/**
 * Puts NOVA's PC scripts onto the PC over Wi-Fi instead of typing them blind for minutes. The phone serves the files
 * for 3 minutes; NOVA only types one short line into Win+R (a few seconds) that makes PowerShell download and install
 * them. Nothing on the PC has to accept a connection (the PC downloads), so no firewall prompt.
 */
final class NovaInstall {
    static final int PORT = 41920;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile ServerSocket server;
    private static volatile long until;

    interface Done {
        void done(String result);
    }

    private NovaInstall() {
    }

    /** This phone's Wi-Fi address, or null. */
    static String phoneIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                String n = ni.getName();
                if (!n.startsWith("wlan") && !n.startsWith("ap") && !n.startsWith("swlan")) {
                    continue;
                }
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
            // no Wi-Fi
        }
        return null;
    }

    /**
     * Installs on the PC. what = "dcs" (NovaExport.lua into Saved Games\DCS\Scripts + Export.lua line) or
     * "screens" (NovaScreens.ps1 into the user folder, then starts it). Returns false when it can't start.
     */
    static boolean install(Context c, String what, Done done) {
        final String ip = phoneIp();
        if (ip == null) {
            return false;
        }
        final Context app = c.getApplicationContext();
        final String installer = what.equals("dcs") ? dcsInstaller(ip) : screensInstaller(ip);
        final String payload = what.equals("dcs") ? DcsCockpitWidget.script(app) : PcScreenWidget.script(app);
        stopServer();
        try {
            final ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new java.net.InetSocketAddress(PORT));
            ss.setSoTimeout(1000);
            server = ss;
            until = System.currentTimeMillis() + 180000;
            new Thread(() -> {
                while (server == ss && System.currentTimeMillis() < until) {
                    try (Socket s = ss.accept()) {
                        s.setSoTimeout(4000);
                        String path = request(s.getInputStream());
                        String body;
                        if (path.startsWith("/i")) {
                            body = installer;
                        } else if (path.startsWith("/f")) {
                            body = payload;
                        } else if (path.startsWith("/ok")) {
                            final String r = java.net.URLDecoder.decode(path.substring(path.indexOf('?') + 1), "UTF-8");
                            body = "ok";
                            answer(s.getOutputStream(), body);
                            MAIN.post(() -> done.done(r));
                            until = System.currentTimeMillis() + 3000;
                            continue;
                        } else {
                            body = "NOVA";
                        }
                        answer(s.getOutputStream(), body);
                    } catch (java.net.SocketTimeoutException t) {
                        // keep waiting
                    } catch (Exception e) {
                        // one bad request
                    }
                }
                try {
                    ss.close();
                } catch (Exception ignored) {
                    // closed
                }
                if (server == ss) {
                    server = null;
                }
            }, "nova-install").start();
        } catch (Exception e) {
            return false;
        }
        // the only thing typed: one short line into Win+R
        String cmd = "powershell -NoProfile -ExecutionPolicy Bypass -Command \"iex ((New-Object Net.WebClient)"
                + ".DownloadString('http://" + ip + ":" + PORT + "/i'))\"";
        // DEL drops anything Windows auto-completes from the Run history
        PcHid.run("K:WIN+R|W:900|T:" + cmd + "|W:300|K:DEL|K:ENTER");
        return true;
    }

    static void stopServer() {
        ServerSocket s = server;
        server = null;
        if (s != null) {
            try {
                s.close();
            } catch (Exception ignored) {
                // closed
            }
        }
    }

    private static String request(InputStream in) throws java.io.IOException {
        StringBuilder b = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0 && c != '\n' && b.length() < 2000) {
            if (c != '\r') {
                b.append((char) c);
            }
        }
        // read the rest of the headers so the PC isn't cut off
        int blank = 0;
        while (blank < 2 && (c = in.read()) >= 0) {
            if (c == '\n') {
                blank++;
            } else if (c != '\r') {
                blank = 0;
            }
        }
        String[] p = b.toString().split(" ");
        return p.length > 1 ? p[1] : "/";
    }

    private static void answer(OutputStream o, String body) throws java.io.IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        o.write(("HTTP/1.0 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: " + b.length
                + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        o.write(b);
        o.flush();
    }

    private static String dcsInstaller(String ip) {
        String u = "http://" + ip + ":" + PORT;
        return "$ErrorActionPreference = 'Stop'\r\n"
                + "$wc = New-Object Net.WebClient\r\n"
                + "$wc.Encoding = [Text.Encoding]::UTF8\r\n"
                + "$lua = $wc.DownloadString('" + u + "/f')\r\n"
                + "$utf8 = New-Object Text.UTF8Encoding($false)\r\n"
                + "$line = 'dofile(lfs.writedir()..[[Scripts\\NovaExport.lua]])'\r\n"
                + "$done = @()\r\n"
                + "foreach ($n in @('DCS', 'DCS.openbeta')) {\r\n"
                + "  $d = Join-Path $env:USERPROFILE ('Saved Games\\' + $n)\r\n"
                + "  if (-not (Test-Path $d)) { continue }\r\n"
                + "  try {\r\n"
                + "    $s = Join-Path $d 'Scripts'\r\n"
                + "    New-Item -ItemType Directory -Force -Path $s | Out-Null\r\n"
                + "    [IO.File]::WriteAllText((Join-Path $s 'NovaExport.lua'), $lua, $utf8)\r\n"
                + "    $e = Join-Path $s 'Export.lua'\r\n"
                + "    $old = ''\r\n"
                + "    if (Test-Path $e) { $old = [IO.File]::ReadAllText($e) }\r\n"
                + "    if ($old.Contains('novaUdp') -and -not $old.Contains('NovaExport.lua')) {\r\n"
                + "      Copy-Item $e ($e + '.nova-backup') -Force\r\n"
                + "      [IO.File]::WriteAllText($e, $line + [Environment]::NewLine, $utf8)\r\n"
                + "    } elseif (-not $old.Contains('NovaExport.lua')) {\r\n"
                + "      [IO.File]::AppendAllText($e, [Environment]::NewLine + $line + [Environment]::NewLine, $utf8)\r\n"
                + "    }\r\n"
                + "    $done += ('Saved Games\\' + $n + '\\Scripts')\r\n"
                + "  } catch { $done += ('FAILED ' + $n + ': ' + $_.Exception.Message) }\r\n"
                + "}\r\n"
                + "if ($done.Count -eq 0) { $done = @('NODCS') }\r\n"
                + "$wc.DownloadString('" + u + "/ok?' + [Uri]::EscapeDataString(($done -join ' + '))) | Out-Null\r\n";
    }

    private static String screensInstaller(String ip) {
        String u = "http://" + ip + ":" + PORT;
        return "$ErrorActionPreference = 'Stop'\r\n"
                + "$wc = New-Object Net.WebClient\r\n"
                + "$wc.Encoding = [Text.Encoding]::UTF8\r\n"
                + "$f = Join-Path $env:USERPROFILE 'NovaScreens.ps1'\r\n"
                + "[IO.File]::WriteAllText($f, $wc.DownloadString('" + u + "/f'), (New-Object Text.UTF8Encoding($false)))\r\n"
                + "$wc.DownloadString('" + u + "/ok?' + [Uri]::EscapeDataString($f)) | Out-Null\r\n"
                + "Start-Process powershell -ArgumentList ('-NoExit -ExecutionPolicy Bypass -File \"' + $f + '\"')\r\n";
    }
}
