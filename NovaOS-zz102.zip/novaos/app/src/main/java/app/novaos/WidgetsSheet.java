package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/**
 * Your home widgets on every home screen layout. The Classic home shows them on its pages; the other layouts open this
 * sheet from the WIDGETS button. You can add any widget, build your own, or remove one from here.
 */
final class WidgetsSheet extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout list;

    WidgetsSheet(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("WIDGETS", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));
        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout acts = new LinearLayout(host);
        acts.setPadding(0, dp(10), 0, dp(6));
        acts.addView(chip("+ ADD", this::add));
        acts.addView(chip("BUILD YOUR OWN", () -> host.showOverlay(new WidgetBuilder(host))));
        hs.addView(acts);
        col.addView(hs);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(6), 0, dp(30));
        sv.addView(list);
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        addView(col, new FrameLayout.LayoutParams(-1, -1));
        build();
    }

    private void build() {
        list.removeAllViews();
        final List<Widgets.Placed> placed = Widgets.load();
        if (placed.isEmpty()) {
            TextView t = text("No widgets yet. Tap + ADD to pick one, or BUILD YOUR OWN.", 11f, Theme.DIM);
            t.setGravity(Gravity.START);
            t.setPadding(0, dp(10), 0, 0);
            list.addView(t);
            return;
        }
        for (int i = 0; i < placed.size(); i++) {
            final int idx = i;
            final Widgets.Placed p = placed.get(i);
            LinearLayout card = new LinearLayout(host);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(12));
            card.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(Widgets.title(p.id), 9f, Theme.DIM);
            name.setGravity(Gravity.START);
            top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
            top.addView(chip("REMOVE", () -> {
                List<Widgets.Placed> all = Widgets.load();
                if (idx < all.size()) {
                    all.remove(idx);
                    Widgets.save(all);
                }
                build();
            }));
            card.addView(top, new LinearLayout.LayoutParams(-1, -2));
            try {
                card.addView(Widgets.create(host, p.id), new LinearLayout.LayoutParams(-1, -2));
            } catch (RuntimeException e) {
                card.addView(text("This widget could not start: " + e.getClass().getSimpleName(), 10f, Theme.DIM));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            list.addView(card, lp);
        }
    }

    private void add() {
        final String[] ids = Widgets.placeIds();
        new AlertDialog.Builder(host).setTitle("Add a widget").setItems(Widgets.placeTitles(), (d, which) -> {
            List<Widgets.Placed> all = Widgets.load();
            all.add(new Widgets.Placed(0, ids[which], Widgets.WIDE));
            Widgets.save(all);
            build();
        }).show();
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setClickable(true);
        t.setOnClickListener((View v) -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }
}
