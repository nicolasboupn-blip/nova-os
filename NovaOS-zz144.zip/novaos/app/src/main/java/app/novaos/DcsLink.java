package app.novaos;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Live DCS data for DCS COCKPIT. The PC script NovaExport.lua broadcasts the aircraft state 20 times a second and the
 * objects around it twice a second over Wi-Fi (UDP 41900). SIM mode makes up a whole flight instead (take-off, a
 * fight, a carrier approach) so every page and button can be tried without DCS.
 */
final class DcsLink {
    static final int PORT = 41900;

    /** Everything about your own aircraft. Distances in metres, speeds in m/s, angles in degrees. */
    static final class State {
        String name = "";
        float ias;
        float tas;
        float mach;
        float alt;
        float agl;
        float vs;
        float aoa;
        float g = 1;
        float hdg;
        float pitch;
        float bank;
        float fuel;
        float fuelExt;
        float rpmL;
        float rpmR;
        float gear;
        float flaps;
        float brake;
        float hook;
        float canopy;
        float wheel;
        int chaff = -1;
        int flare = -1;
        int shells = -1;
        int weapons = -1;
        int coal;
        double x;
        double y;
        double z;
        float lockDist = -1;
        float lockClose;
        String lockName = "";
        float lockAlt = -1;
    }

    /** Something around you: cat 1 air, 2 ground, 3 ship. hdg in degrees. */
    static final class Obj {
        String id;
        int cat;
        int coal;
        double x;
        double z;
        float alt;
        float hdg;
        String name;
    }

    static volatile State st = new State();
    static volatile List<Obj> objs = new ArrayList<>();
    static volatile long lastAt;
    static volatile long objAt;
    static volatile boolean sim;
    static volatile float maxG = 1;
    static volatile float throttle;
    private static final CopyOnWriteArrayList<Runnable> LISTENERS = new CopyOnWriteArrayList<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static int users;
    private static Thread rx;
    private static volatile boolean running;
    private static DatagramSocket socket;
    private static WifiManager.MulticastLock lock;
    private static boolean posted;

    private DcsLink() {
    }

    static boolean live() {
        return sim || SystemClock.elapsedRealtime() - lastAt < 2500;
    }

    static boolean objectsLive() {
        return sim || SystemClock.elapsedRealtime() - objAt < 4000;
    }

    static void listen(Runnable r) {
        LISTENERS.addIfAbsent(r);
    }

    static void unlisten(Runnable r) {
        LISTENERS.remove(r);
    }

    private static void changed() {
        if (posted) {
            return;
        }
        posted = true;
        MAIN.post(() -> {
            posted = false;
            for (Runnable r : LISTENERS) {
                r.run();
            }
        });
    }

    /** Starts listening for the PC (called when a DCS COCKPIT page is on screen). */
    static synchronized void start(Context c) {
        users++;
        if (running) {
            return;
        }
        running = true;
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("nova-dcs");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (RuntimeException ignored) {
            // broadcasts may still arrive
        }
        rx = new Thread(DcsLink::receive, "nova-dcs");
        rx.start();
    }

    static synchronized void stop() {
        users = Math.max(0, users - 1);
        if (users > 0) {
            return;
        }
        running = false;
        DatagramSocket s = socket;
        if (s != null) {
            s.close();
        }
        try {
            if (lock != null) {
                lock.release();
            }
        } catch (RuntimeException ignored) {
            // gone
        }
    }

    private static void receive() {
        byte[] buf = new byte[65507];
        while (running) {
            try {
                DatagramSocket s = new DatagramSocket(null);
                s.setReuseAddress(true);
                s.setBroadcast(true);
                s.bind(new InetSocketAddress(PORT));
                s.setSoTimeout(1000);
                socket = s;
                while (running) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        s.receive(p);
                    } catch (java.net.SocketTimeoutException t) {
                        continue;
                    }
                    if (sim) {
                        continue;
                    }
                    parse(new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8));
                }
                s.close();
            } catch (Exception e) {
                if (running) {
                    SystemClock.sleep(1500);
                }
            }
        }
    }

    private static float f(String[] a, int i, float def) {
        if (i >= a.length || a[i].isEmpty()) {
            return def;
        }
        try {
            return Float.parseFloat(a[i]);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static void parse(String msg) {
        String[] a = msg.split(";", -1);
        if (a.length == 0) {
            return;
        }
        if (a[0].equals("N1") && a.length >= 35) {
            State s = new State();
            s.name = a[1];
            s.ias = f(a, 2, 0);
            s.tas = f(a, 3, 0);
            s.mach = f(a, 4, 0);
            s.alt = f(a, 5, 0);
            s.agl = f(a, 6, 0);
            s.vs = f(a, 7, 0);
            s.aoa = f(a, 8, 0);
            s.g = f(a, 9, 1);
            s.hdg = (float) Math.toDegrees(f(a, 10, 0));
            s.pitch = (float) Math.toDegrees(f(a, 11, 0));
            s.bank = (float) Math.toDegrees(f(a, 12, 0));
            s.fuel = f(a, 13, 0);
            s.fuelExt = f(a, 14, 0);
            s.rpmL = f(a, 15, 0);
            s.rpmR = f(a, 16, 0);
            s.gear = f(a, 17, 0);
            s.flaps = f(a, 18, 0);
            s.brake = f(a, 19, 0);
            s.hook = f(a, 20, 0);
            s.canopy = f(a, 21, 0);
            s.wheel = f(a, 22, 0);
            s.chaff = (int) f(a, 23, -1);
            s.flare = (int) f(a, 24, -1);
            s.shells = (int) f(a, 25, -1);
            s.x = f(a, 26, 0);
            s.y = f(a, 27, 0);
            s.z = f(a, 28, 0);
            s.lockDist = f(a, 29, -1);
            s.lockClose = f(a, 30, 0);
            s.lockName = a[31];
            s.lockAlt = f(a, 32, -1);
            s.weapons = (int) f(a, 33, -1);
            s.coal = (int) f(a, 34, 0);
            st = s;
            maxG = s.agl < 5 && s.ias < 20 ? 1 : Math.max(maxG, s.g);
            lastAt = SystemClock.elapsedRealtime();
            changed();
        } else if (a[0].equals("N2")) {
            List<Obj> out = new ArrayList<>();
            for (int i = 1; i < a.length; i++) {
                String[] o = a[i].split(",", -1);
                if (o.length < 8) {
                    continue;
                }
                Obj b = new Obj();
                b.id = o[0];
                b.cat = (int) f(o, 1, 0);
                b.coal = (int) f(o, 2, 0);
                b.x = f(o, 3, 0);
                b.z = f(o, 4, 0);
                b.alt = f(o, 5, 0);
                b.hdg = (float) Math.toDegrees(f(o, 6, 0));
                b.name = o[7];
                out.add(b);
            }
            objs = out;
            objAt = SystemClock.elapsedRealtime();
            changed();
        }
    }

    // ================================================================== carriers

    static boolean isCarrier(Obj o) {
        if (o.cat != 3 || o.name == null) {
            return false;
        }
        String n = o.name.toUpperCase(Locale.ROOT);
        return n.contains("CVN") || n.contains("STENNIS") || n.contains("KUZNE") || n.contains("CV_1143")
                || n.contains("FORRESTAL") || n.contains("LHA") || n.contains("TARAWA") || n.contains("VINSON");
    }

    /**
     * Where you are compared to the landing area of the nearest carrier: {distance along the approach (m, positive =
     * behind the deck), lineup offset (m, + = right of the centreline), height above the deck (m), glide slope error
     * (degrees, + = high), lineup error (degrees, + = right), carrier index in objs}. Null when there is no carrier.
     */
    static double[] approach(State s, List<Obj> list) {
        Obj best = null;
        double bd = Double.MAX_VALUE;
        for (Obj o : list) {
            if (isCarrier(o)) {
                double d = Math.hypot(o.x - s.x, o.z - s.z);
                if (d < bd) {
                    bd = d;
                    best = o;
                }
            }
        }
        if (best == null || bd > 25000) {
            return null;
        }
        // the landing area: about 70 m behind the middle of the ship, the angled deck points 9 degrees to the left
        double h = Math.toRadians(best.hdg);
        double tdx = best.x - Math.cos(h) * 70;
        double tdz = best.z - Math.sin(h) * 70;
        double deck = h - Math.toRadians(9);
        double ux = Math.cos(deck);
        double uz = Math.sin(deck);
        double dx = s.x - tdx;
        double dz = s.z - tdz;
        double along = -(dx * ux + dz * uz);
        // right of the landing direction is (-uz, ux) turned: for north = x, east = z, right of heading is +90 degrees
        double rx = Math.cos(deck + Math.PI / 2);
        double rz = Math.sin(deck + Math.PI / 2);
        double lateral = dx * rx + dz * rz;
        double height = s.alt - 19;
        double gs = along > 1 ? Math.toDegrees(Math.atan2(height, along)) - 3.5 : 0;
        double lu = along > 1 ? Math.toDegrees(Math.atan2(lateral, along)) : 0;
        return new double[] {along, lateral, height, gs, lu, list.indexOf(best)};
    }

    // ================================================================== SIM mode

    private static long simStart;
    private static final float[] TARGET = new float[5];
    private static final long[] TOUCHED = new long[5];
    private static final Runnable SIM_TICK = new Runnable() {
        @Override
        public void run() {
            if (!sim) {
                return;
            }
            simStep();
            MAIN.postDelayed(this, 50);
        }
    };

    static void setSim(boolean on) {
        sim = on;
        if (on) {
            simStart = SystemClock.elapsedRealtime();
            st = new State();
            maxG = 1;
            MAIN.removeCallbacks(SIM_TICK);
            MAIN.post(SIM_TICK);
        } else {
            st = new State();
            objs = new ArrayList<>();
            lastAt = 0;
            objAt = 0;
            changed();
        }
    }

    /** A button pressed in SIM: 0 gear, 1 flaps, 2 airbrake, 3 hook, 4 canopy. value -1 = toggle. */
    static void simPress(int part, float value) {
        State s = st;
        float now = new float[] {s.gear, s.flaps, s.brake, s.hook, s.canopy}[part];
        TARGET[part] = value >= 0 ? value : (now > 0.5f ? 0 : 1);
        TOUCHED[part] = SystemClock.elapsedRealtime();
    }

    private static float toward(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    private static void simStep() {
        float t = ((SystemClock.elapsedRealtime() - simStart) % 120000) / 1000f;
        long now = SystemClock.elapsedRealtime();
        State p = st;
        State s = new State();
        s.name = "FA-18C_hornet";
        s.coal = 2;
        // the carrier sails north at 15 m/s
        double total = (SystemClock.elapsedRealtime() - simStart) / 1000.0;
        double cx = (total % 120) * 15;
        float[] script = new float[5];
        List<Obj> list = new ArrayList<>();
        Obj cvn = new Obj();
        cvn.id = "cvn";
        cvn.cat = 3;
        cvn.coal = 2;
        cvn.x = cx;
        cvn.z = 0;
        cvn.hdg = 0;
        cvn.name = "CVN_71";
        list.add(cvn);
        if (t < 15) {
            // parked, canopy closes
            s.x = -20000;
            s.z = 3000;
            s.alt = 20;
            s.agl = 0;
            s.ias = 0;
            s.hdg = 0;
            script[0] = 1;
            script[1] = 0.5f;
            script[4] = t < 5 ? 1 : 0;
            s.rpmL = s.rpmR = 65;
        } else if (t < 35) {
            float k = (t - 15) / 20f;
            s.x = -20000 + k * k * 2600;
            s.z = 3000;
            s.ias = Math.min(170, k * 220) * (0.7f + 0.3f * throttle);
            s.alt = t < 24 ? 20 : 20 + (t - 24) * 90;
            s.agl = s.alt - 20;
            s.vs = t < 24 ? 0 : 60;
            s.pitch = t < 24 ? 0 : 12;
            s.aoa = t < 24 ? 0 : 7;
            s.hdg = 0;
            script[0] = t < 27 ? 1 : 0;
            script[1] = t < 30 ? 0.5f : 0;
            s.rpmL = s.rpmR = 99;
            s.g = t < 24 ? 1 : 1.4f;
        } else if (t < 70) {
            float k = t - 35;
            s.x = -17000 + k * 220;
            s.z = 3000 + 4000 * (float) Math.sin(k / 12);
            s.alt = 3000 + 300 * (float) Math.sin(k / 6);
            s.agl = s.alt;
            s.ias = 150 + 120 * throttle;
            s.mach = s.ias / 300;
            s.hdg = (float) (Math.toDegrees(Math.atan2(4000 * Math.cos(k / 12) / 12, 220)) + 360) % 360;
            s.bank = (float) (-30 * Math.sin(k / 12));
            s.aoa = 4;
            s.g = 1 + 3.5f * Math.abs((float) Math.sin(k / 3));
            s.rpmL = s.rpmR = 85 + 14 * throttle;
            String[] names = {"F-16C", "F-18C", "E-2C", "MiG-29S", "Su-27", "SA-11 Buk"};
            for (int i = 0; i < names.length; i++) {
                Obj o = new Obj();
                o.id = "c" + i;
                o.cat = i == 5 ? 2 : 1;
                o.coal = i < 3 ? 2 : 1;
                double ang = i * 1.05 + k / 20;
                double r = 8000 + i * 6000 - (i >= 3 ? k * 250 : 0);
                o.x = s.x + Math.cos(ang) * r;
                o.z = s.z + Math.sin(ang) * r;
                o.alt = i == 5 ? 0 : 2500 + i * 900;
                o.hdg = (float) Math.toDegrees(ang + Math.PI);
                o.name = names[i];
                list.add(o);
            }
            if (k > 15 && k < 32) {
                Obj tg = list.get(4);
                s.lockDist = (float) Math.hypot(tg.x - s.x, tg.z - s.z);
                s.lockClose = 320;
                s.lockName = tg.name;
                s.lockAlt = tg.alt;
            }
        } else if (t < 110) {
            // carrier approach from 9 km, a little high and drifting right, then corrected
            float k = (t - 70) / 40f;
            double along = 9000 * (1 - k);
            double lateral = 120 * Math.sin(k * 5.5) * (1 - k) + 6 * (1 - k);
            double deck = Math.toRadians(-9);
            double tdx = cx - 70;
            s.x = tdx - Math.cos(deck) * along + Math.cos(deck + Math.PI / 2) * lateral;
            s.z = -Math.sin(deck) * along + Math.sin(deck + Math.PI / 2) * lateral;
            double gsErr = 0.6 * Math.sin(k * 7) * (1 - k * 0.8);
            s.alt = (float) (19 + Math.tan(Math.toRadians(3.5 + gsErr)) * along);
            s.agl = s.alt;
            s.ias = 72;
            s.hdg = (float) ((Math.toDegrees(deck) + 360 - lateral / 40) % 360);
            s.aoa = 8.1f + 0.9f * (float) Math.sin(k * 9);
            s.vs = -4;
            s.g = 1;
            script[0] = t > 72 ? 1 : 0;
            script[3] = t > 74 ? 1 : 0;
            script[1] = t > 76 ? 1 : 0;
            s.rpmL = s.rpmR = 78;
        } else {
            // trapped
            s.x = cx - 40;
            s.z = 0;
            s.alt = 19;
            s.agl = 0;
            s.ias = Math.max(0, 72 - (t - 110) * 30);
            s.hdg = 351;
            script[0] = 1;
            script[3] = 1;
            script[1] = 1;
            s.rpmL = s.rpmR = 70;
        }
        float[] cur = {p.gear, p.flaps, p.brake, p.hook, p.canopy};
        float[] rate = {0.017f, 0.025f, 0.08f, 0.06f, 0.015f};
        for (int i = 0; i < 5; i++) {
            float want = now - TOUCHED[i] < 15000 ? TARGET[i] : script[i];
            cur[i] = toward(cur[i], want, rate[i]);
        }
        s.gear = cur[0];
        s.flaps = cur[1];
        s.brake = cur[2];
        s.hook = cur[3];
        s.canopy = cur[4];
        s.tas = s.ias * 1.05f;
        s.fuel = 4900 - t * 15;
        s.fuelExt = t < 70 ? 1200 : 0;
        s.chaff = 60 - (int) (t / 10);
        s.flare = 60 - (int) (t / 12);
        s.shells = 578;
        s.weapons = t < 60 ? 8 : 6;
        st = s;
        maxG = Math.max(maxG, s.g);
        objs = list;
        lastAt = now;
        objAt = now;
        changed();
    }
}
