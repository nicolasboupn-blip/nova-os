package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * DCS COCKPIT: one widget with swipeable pages fed by live DCS data (see DcsLink and the PC script NovaExport.lua).
 * THROTTLE (thrust lever + main buttons), AIRCRAFT (your jet with moving parts coloured), CARRIER (side view and lineup),
 * RADAR (everything around you), TARGET (your lock) and FLIGHT (all the numbers). In AUTO it shows the page that fits
 * what you are doing; swipe to choose yourself. SIM flies a made-up mission so everything can be tried without DCS.
 */
final class DcsCockpitWidget extends NovaWidget {
    private static final String[] PAGES = {"THROTTLE", "AIRCRAFT", "CARRIER", "RADAR", "TARGET", "FLIGHT"};
    private static final int P_THROTTLE = 0;
    private static final int P_PLANE = 1;
    private static final int P_CARRIER = 2;
    private static final int P_RADAR = 3;
    private static final int P_TARGET = 4;
    private static final int P_FLIGHT = 5;
    private static final String K_AUTO = "dcs_auto";
    private static final String K_PAGE = "dcs_page";
    private static final String K_THR = "dcs_throttle";
    private static final String K_THR_MODE = "dcs_thr_mode";
    private static final String K_RANGE = "dcs_radar_nm";
    private static final String K_VOICE = "dcs_voice";
    private static final int GREEN = 0xFF30D158;
    private static final int AMBER = 0xFFFFB020;
    private static final int RED = 0xFFFF453A;
    private static final int BLUE = 0xFF0A84FF;

    private final boolean big;
    private final TextView status;
    private final TextView autoChip;
    private final TextView simChip;
    private final Pager pager;
    private final LinearLayout dots;
    private int page;
    private long manualUntil;
    private final View[] views = new View[PAGES.length];
    private final List<Object[]> lit = new ArrayList<>();
    private final Runnable onData = this::data;
    private TextToSpeech tts;
    private long lastSay;
    private boolean ballCalled;
    private float lastFuel = -1;
    private long lastFuelAt;
    private float burn;

    DcsCockpitWidget(NovaActivity host) {
        this(host, false);
    }

    DcsCockpitWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setSingleLine(true);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        autoChip = chip("AUTO", () -> {
            boolean on = !Prefs.getBool(K_AUTO, true);
            Prefs.putBool(K_AUTO, on);
            manualUntil = 0;
            refresh();
            data();
        });
        top.addView(autoChip, margin());
        simChip = chip("SIM", () -> {
            DcsLink.setSim(!DcsLink.sim);
            host.toast(DcsLink.sim ? "SIM flight started: try every page and button" : "SIM off");
            refresh();
        });
        top.addView(simChip, margin());
        top.addView(chip("SETUP", this::setup), margin());
        if (!big) {
            top.addView(chip("⤢", this::openBig), margin());
        }
        addView(top, wide());
        dots = row();
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < PAGES.length; i++) {
            final int p = i;
            TextView d = text(PAGES[i], 8f, Theme.DIM);
            d.setPadding(dp(4), dp(4), dp(4), dp(4));
            d.setOnClickListener(v -> manual(p));
            dots.addView(d);
        }
        addView(dots, wide());
        pager = new Pager();
        int h = big ? (int) (getResources().getDisplayMetrics().heightPixels * 0.72f) : dp(330);
        addView(pager, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, h));
        page = Math.max(0, Math.min(PAGES.length - 1, Prefs.getInt(K_PAGE, 0)));
        show(page);
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        return lp;
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            DcsLink.start(host);
            DcsLink.listen(onData);
            if (PcHid.hid == null && android.os.Build.VERSION.SDK_INT >= 28
                    && (android.os.Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                    android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
                PcHid.start(host);
            }
            refresh();
        } else {
            DcsLink.unlisten(onData);
            DcsLink.stop();
        }
    }

    @Override
    long tickMs() {
        return 1000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        DcsLink.State s = DcsLink.st;
        String src = DcsLink.sim ? "● SIM" : DcsLink.live() ? "● DCS" : "○ waiting for DCS";
        status.setText(src + (DcsLink.live() && !s.name.isEmpty() ? "  " + nice(s.name) : "")
                + (PcHid.connected() ? "  · keys ✔" : "  · keys ✖"));
        status.setTextColor(DcsLink.live() ? GREEN : Theme.DIM);
        boolean auto = Prefs.getBool(K_AUTO, true);
        autoChip.setText(auto ? (SystemClock.uptimeMillis() < manualUntil ? "AUTO ⏸" : "AUTO") : "MANUAL");
        pick(autoChip, auto);
        pick(simChip, DcsLink.sim);
    }

    static String nice(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("FA-18") || u.contains("F/A-18")) {
            return "F/A-18C";
        }
        return n.replace("_", " ");
    }

    /** hornet, flanker, frogfoot or other. */
    static String family(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("18")) {
            return "hornet";
        }
        if (u.contains("SU-27") || u.contains("SU-33") || u.contains("J-11") || u.contains("SU-30")) {
            return "flanker";
        }
        if (u.contains("SU-25")) {
            return "frogfoot";
        }
        return u.isEmpty() ? "hornet" : "other";
    }

    // ------------------------------------------------------------------ pages and swiping

    private final class Pager extends FrameLayout {
        private float sx;
        private float sy;
        private boolean swiping;
        private final int slop = ViewConfiguration.get(host).getScaledTouchSlop();

        Pager() {
            super(host);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getX();
                    sy = e.getY();
                    swiping = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getX() - sx;
                    float dy = e.getY() - sy;
                    if (!swiping && Math.abs(dx) > slop * 3 && Math.abs(dx) > Math.abs(dy) * 1.6f
                            && !(page == P_THROTTLE && sx < getWidth() * 0.45f && sy < getHeight() * 0.5f)) {
                        swiping = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    }
                    return false;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP && swiping) {
                float dx = e.getX() - sx;
                manual((page + (dx < 0 ? 1 : -1) + PAGES.length) % PAGES.length);
                swiping = false;
            }
            return true;
        }
    }

    private void manual(int p) {
        manualUntil = SystemClock.uptimeMillis() + 30000;
        show(p);
        refresh();
    }

    private void show(int p) {
        page = p;
        Prefs.putInt(K_PAGE, p);
        pager.removeAllViews();
        if (views[p] == null) {
            views[p] = make(p);
        }
        pager.addView(views[p], new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        for (int i = 0; i < dots.getChildCount(); i++) {
            TextView d = (TextView) dots.getChildAt(i);
            d.setTextColor(i == p ? Theme.ACCENT : Theme.DIM);
            d.setText(i == p ? "● " + PAGES[i] : PAGES[i]);
        }
        views[p].invalidate();
    }

    private View make(int p) {
        switch (p) {
            case P_THROTTLE:
                return throttlePage();
            case P_PLANE:
                return new PlaneView();
            case P_CARRIER:
                return new CarrierView();
            case P_RADAR:
                return new RadarView();
            case P_TARGET:
                return new TargetView();
            default:
                return new FlightView();
        }
    }

    /** New data: pick the page in AUTO, redraw, light the buttons, carrier calls. */
    private void data() {
        DcsLink.State s = DcsLink.st;
        if (DcsLink.live() && Prefs.getBool(K_AUTO, true) && SystemClock.uptimeMillis() > manualUntil) {
            int want = choose(s);
            if (want != page) {
                show(want);
            }
        }
        if (views[page] != null) {
            views[page].invalidate();
        }
        if (btnGrid != null && !fam().equals(builtFam)) {
            fillButtons(btnGrid);
        }
        for (Object[] l : lit) {
            light((TextView) l[0], (int) l[1], (float) l[2]);
        }
        // fuel burn per minute, for "minutes left"
        long now = SystemClock.elapsedRealtime();
        float fuel = s.fuel + s.fuelExt;
        if (lastFuel < 0 || now - lastFuelAt > 10000) {
            if (lastFuel >= 0 && now - lastFuelAt < 60000) {
                float perMin = (lastFuel - fuel) / ((now - lastFuelAt) / 60000f);
                burn = burn == 0 ? perMin : burn * 0.6f + perMin * 0.4f;
            }
            lastFuel = fuel;
            lastFuelAt = now;
        }
        calls(s);
    }

    private int choose(DcsLink.State s) {
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap != null && ap[0] > 0 && ap[0] < 9000 && Math.abs(ap[4]) < 25 && s.alt < 1200 && (s.gear > 0.5f || s.hook > 0.5f)) {
            return P_CARRIER;
        }
        if (s.lockDist > 0) {
            return P_TARGET;
        }
        for (DcsLink.Obj o : DcsLink.objs) {
            if (o.cat == 1 && o.coal != 0 && o.coal != s.coal && Math.hypot(o.x - s.x, o.z - s.z) < 37000) {
                return P_RADAR;
            }
        }
        if (s.agl < 5 && s.ias < 60) {
            return P_THROTTLE;
        }
        return P_FLIGHT;
    }

    private void calls(DcsLink.State s) {
        if (!Prefs.getBool(K_VOICE, true)) {
            return;
        }
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap == null || ap[0] <= 0 || ap[0] > 9000 || s.gear < 0.5f) {
            ballCalled = false;
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (!ballCalled && ap[0] < 1400) {
            ballCalled = true;
            say("three quarter mile, call the ball");
        } else if (ap[0] < 3000 && now - lastSay > 4000) {
            if (ap[4] > 1.5) {
                say("right of line up");
            } else if (ap[4] < -1.5) {
                say("left of line up");
            } else if (ap[3] > 0.7) {
                say("high");
            } else if (ap[3] < -0.7) {
                say("low, power");
            }
        }
    }

    private void say(String text) {
        lastSay = SystemClock.uptimeMillis();
        if (tts == null) {
            tts = new TextToSpeech(host.getApplicationContext(), st -> {
                if (st == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.US);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
                }
            });
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
    }

    // ------------------------------------------------------------------ THROTTLE page

    /** {label, key spec, part (0 gear 1 flaps 2 airbrake 3 hook 4 canopy, -1 none), sim value (-1 toggle), hold}. */
    private static Object[][] buttons(String fam) {
        if (fam.equals("hornet")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS HALF", "LSHIFT+F", 1, 0.5f, false},
                {"FLAPS FULL", "LCTRL+F", 1, 1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"HOOK", "LCTRL+H", 3, -1f, false}, {"WHEEL BRAKE", "W", -1, -1f, true},
                {"GUN", "C", -1, -1f, false}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
                {"AUTO START", "LWIN+HOME", -1, -1f, false}, {"EJECT", "x3:LCTRL+E", -1, -1f, false},
            };
        }
        if (fam.equals("frogfoot")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"GUN", "C", -1, -1f, false}, {"NEXT WEAPON", "D", -1, -1f, false}, {"FIRE", "SPACE", -1, -1f, true},
                {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"SHKVAL", "O", -1, -1f, false}, {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false},
                {"FLARE", "DEL", -1, -1f, false},
            };
        }
        return new Object[][] {
            {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
            {"GUN", "C", -1, -1f, false}, {"MISSILE", "D", -1, -1f, false}, {"FIRE GUN", "SPACE", -1, -1f, true},
            {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false}, {"RADAR", "I", -1, -1f, false},
            {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
        };
    }

    private String fam() {
        return family(DcsLink.st.name);
    }

    private View throttlePage() {
        final LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        LinearLayout topHalf = row();
        final Lever lever = new Lever();
        topHalf.addView(lever, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        final TextView info = text("", 11f, Theme.TEXT);
        info.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        topHalf.addView(info, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        lever.info = info;
        col.addView(topHalf, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        final LinearLayout grid = new LinearLayout(host);
        grid.setOrientation(VERTICAL);
        fillButtons(grid);
        col.addView(grid, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        col.setTag(grid);
        return col;
    }

    private String btnKey(String fam, int i, String def) {
        return Prefs.getString("dcsbtn_" + fam + "_" + i, def);
    }

    private String builtFam = "";
    private LinearLayout btnGrid;

    private void fillButtons(final LinearLayout grid) {
        btnGrid = grid;
        builtFam = fam();
        grid.removeAllViews();
        lit.clear();
        final String fam = fam();
        final Object[][] b = buttons(fam);
        LinearLayout r = null;
        for (int i = 0; i < b.length; i++) {
            if (i % 3 == 0) {
                r = row();
                grid.addView(r, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
            }
            final int idx = i;
            final Object[] d = b[i];
            String saved = btnKey(fam, i, d[0] + "|" + d[1]);
            final String label = saved.contains("|") ? saved.substring(0, saved.indexOf('|')) : (String) d[0];
            final String spec = saved.contains("|") ? saved.substring(saved.indexOf('|') + 1) : (String) d[1];
            final TextView t = text(label + "\n" + DcsKeysWidget.pretty(spec), big ? 12f : 10f, 0xFFFFFFFF);
            t.setGravity(Gravity.CENTER);
            t.setBackground(Theme.rounded(0x33FFFFFF, 12f, host));
            final int part = (int) d[2];
            final boolean hold = (boolean) d[4];
            t.setOnTouchListener((v, e) -> {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setTag(SystemClock.uptimeMillis());
                    v.setAlpha(0.6f);
                    host.buzz(10);
                    if (hold) {
                        press(spec, part, (float) d[3], true, true);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1f);
                    long held = SystemClock.uptimeMillis() - (long) v.getTag();
                    if (hold) {
                        press(spec, part, (float) d[3], false, true);
                    } else if (a == MotionEvent.ACTION_UP && held > 700) {
                        editButton(grid, fam, idx, label, spec);
                    } else if (a == MotionEvent.ACTION_UP) {
                        press(spec, part, (float) d[3], true, false);
                    }
                }
                return true;
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(t, p);
            if (part >= 0) {
                lit.add(new Object[] {t, part, (float) d[3]});
            }
        }
        TextView hint = text("Hold a button 1 s to change its key · keys are DCS names (US positions)", 8.5f, Theme.DIM);
        grid.addView(hint, wide());
    }

    private void press(String spec, int part, float simValue, boolean down, boolean holdMode) {
        if (DcsLink.sim) {
            if (part >= 0 && down) {
                DcsLink.simPress(part, simValue);
            }
            return;
        }
        if (!PcHid.connected()) {
            if (down) {
                host.toast("Not connected: tap CONNECT in KEY DECK or PC REMOTE (or try SIM)");
            }
            return;
        }
        Object[] k = DcsKeysWidget.parse(spec);
        int code = PcHid.rawCode((String) k[1]);
        if (holdMode) {
            PcHid.hold((int) k[0], code, down);
        } else {
            PcHid.tap((int) k[0], code, (int) k[2], 40);
        }
    }

    private void editButton(final LinearLayout grid, final String fam, final int i, String label, String spec) {
        LinearLayout f = new LinearLayout(host);
        f.setOrientation(VERTICAL);
        f.setPadding(dp(18), dp(6), dp(18), 0);
        final EditText name = new EditText(host);
        name.setText(label);
        name.setHint("Name");
        name.setSingleLine(true);
        f.addView(name);
        final EditText key = new EditText(host);
        key.setText(spec);
        key.setHint("Key, e.g. G, LCTRL+H, RALT+SPACE, x3:LCTRL+E");
        key.setSingleLine(true);
        f.addView(key);
        new AlertDialog.Builder(host).setTitle("Button for " + fam)
                .setView(f)
                .setPositiveButton("SAVE", (d, w) -> {
                    String k = key.getText().toString().trim().toUpperCase(Locale.ROOT);
                    Object[] p = DcsKeysWidget.parse(k.isEmpty() ? "G" : k);
                    if (PcHid.rawCode((String) p[1]) == 0) {
                        host.toast("Unknown key: " + p[1]);
                        return;
                    }
                    Prefs.putString("dcsbtn_" + fam + "_" + i, name.getText().toString().trim().toUpperCase(Locale.ROOT) + "|" + k);
                    fillButtons(grid);
                })
                .setNeutralButton("DEFAULT", (d, w) -> {
                    Prefs.remove("dcsbtn_" + fam + "_" + i);
                    fillButtons(grid);
                })
                .setNegativeButton("CANCEL", null).show();
    }

    private void light(TextView t, int part, float simValue) {
        DcsLink.State s = DcsLink.st;
        float v = part == 0 ? s.gear : part == 1 ? s.flaps : part == 2 ? s.brake : part == 3 ? s.hook : s.canopy;
        int c;
        if (part == 1 && simValue > 0 && simValue < 1) {
            c = Math.abs(v - 0.5f) < 0.15f ? GREEN : 0x33FFFFFF;
        } else if (part == 1 && simValue >= 1) {
            c = v > 0.9f ? GREEN : 0x33FFFFFF;
        } else {
            c = v > 0.95f ? GREEN : v > 0.05f ? AMBER : 0x33FFFFFF;
        }
        if (!DcsLink.live()) {
            c = 0x33FFFFFF;
        }
        t.setBackground(Theme.rounded(c == 0x33FFFFFF ? c : (c & 0x00FFFFFF) | 0xAA000000, 12f, host));
    }

    /** The thrust lever: drag up and down. MIL at 80 %, afterburner above. */
    private final class Lever extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float value = Prefs.getInt(K_THR, 0) / 1000f;
        TextView info;
        private float sent = -1;
        private float est;
        private final Runnable keyLoop = new Runnable() {
            @Override
            public void run() {
                int plus = PcHid.rawCode("KPPLUS");
                int minus = PcHid.rawCode("KPMINUS");
                if (value > est + 0.02f) {
                    PcHid.hold(0, minus, false);
                    PcHid.hold(0, plus, true);
                    est += 0.012f;
                    postDelayed(this, 40);
                } else if (value < est - 0.02f) {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, true);
                    est -= 0.012f;
                    postDelayed(this, 40);
                } else {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, false);
                }
            }
        };

        Lever() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float top = dp(10);
            float bot = h - dp(10);
            float cx = w / 2f;
            float tw = Math.min(w * 0.36f, dp(64));
            // the throttle quadrant: a dark slot in a metal plate, a gate at MIL, an afterburner zone
            float plateL = cx - tw / 2 - dp(10);
            float plateR = cx + tw / 2 + dp(10);
            p.setShader(new android.graphics.LinearGradient(plateL, 0, plateR, 0,
                    new int[] {0xFF2A2D33, 0xFF41454D, 0xFF24272C}, null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(plateL, top - dp(6), plateR, bot + dp(6)), dp(8), dp(8), p);
            p.setShader(null);
            // screws
            p.setColor(0xFF15171A);
            for (float sy0 : new float[] {top, bot}) {
                c.drawCircle(plateL + dp(5), sy0, dp(2), p);
                c.drawCircle(plateR - dp(5), sy0, dp(2), p);
            }
            float slotW = dp(8);
            p.setColor(0xFF07080A);
            c.drawRoundRect(new RectF(cx - slotW / 2, top, cx + slotW / 2, bot), dp(4), dp(4), p);
            float mil = bot - (bot - top) * 0.8f;
            // afterburner zone in orange, the gate as a bright bar
            p.setColor(0x55FF7A00);
            c.drawRoundRect(new RectF(cx - slotW / 2, top, cx + slotW / 2, mil), dp(4), dp(4), p);
            p.setColor(0xFFB8BEC6);
            c.drawRect(plateL + dp(2), mil - dp(1.5f), plateR - dp(2), mil + dp(1.5f), p);
            // scale marks
            p.setColor(0x88FFFFFF);
            p.setStrokeWidth(dp(1));
            for (int i = 0; i <= 10; i++) {
                float my = bot - (bot - top) * i / 10f;
                c.drawLine(plateR - dp(8), my, plateR - dp(3), my, p);
            }
            p.setColor(Theme.DIM);
            p.setTextSize(dp(9));
            p.setTypeface(Theme.MONO);
            p.setColor(0xFFFF9F40);
            c.drawText("AB", plateR + dp(4), top + dp(10), p);
            p.setColor(0xFFDDE2E8);
            c.drawText("MIL", plateR + dp(4), mil + dp(3), p);
            c.drawText("IDLE", plateR + dp(4), bot, p);
            // the grip: a rounded metal handle with finger ridges and a red AB light when past the gate
            float y = bot - (bot - top) * value;
            float gw = tw + dp(14);
            float gh = dp(34);
            RectF grip = new RectF(cx - gw / 2, y - gh / 2, cx + gw / 2, y + gh / 2);
            p.setShadowLayer(dp(6), 0, dp(3), 0x99000000);
            p.setShader(new android.graphics.LinearGradient(0, grip.top, 0, grip.bottom,
                    new int[] {0xFF5B616B, 0xFF2F333A, 0xFF1C1F24}, null, android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(grip, dp(12), dp(12), p);
            p.setShader(null);
            p.clearShadowLayer();
            p.setColor(0x33FFFFFF);
            c.drawRoundRect(new RectF(grip.left + dp(3), grip.top + dp(2), grip.right - dp(3), grip.top + dp(8)), dp(6), dp(6), p);
            p.setColor(0x66000000);
            for (int i = 1; i <= 4; i++) {
                float rx = grip.left + gw * i / 5f;
                c.drawRect(rx - dp(1), grip.top + dp(10), rx + dp(1), grip.bottom - dp(6), p);
            }
            p.setColor(value > 0.8f ? 0xFFFF5A1F : 0xFF30D158);
            p.setShadowLayer(dp(5), 0, 0, value > 0.8f ? 0xFFFF5A1F : 0xFF30D158);
            c.drawCircle(grip.right - dp(9), grip.centerY(), dp(3.5f), p);
            p.clearShadowLayer();
            p.setColor(0xFFFFFFFF);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(11));
            c.drawText(Math.round(value * 100) + "%", cx - dp(4), y + dp(4), p);
            p.setTextAlign(Paint.Align.LEFT);
            if (info != null) {
                DcsLink.State s = DcsLink.st;
                boolean axis = Prefs.getInt(K_THR_MODE, 0) == 0;
                info.setText("THRUST " + Math.round(value * 100) + "%" + (value > 0.8f ? "  AB" : value > 0.78f ? "  MIL" : "")
                        + "\n" + (DcsLink.live() ? Math.round(s.ias * 1.94384f) + " kt  ·  RPM " + Math.round(Math.max(s.rpmL, s.rpmR))
                        + "%" : "no DCS data")
                        + "\n\nMode: " + (axis ? "AXIS (bind Thrust to NOVA Remote Z)" : "KEYS (Num+ / Num−)")
                        + "\ntap here to switch");
                info.setOnClickListener(v -> {
                    Prefs.putInt(K_THR_MODE, axis ? 1 : 0);
                    invalidate();
                });
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float top = dp(10);
                float bot = getHeight() - dp(10);
                float old = value;
                value = Math.max(0, Math.min(1, (bot - e.getY()) / (bot - top)));
                if ((old <= 0.8f) != (value <= 0.8f)) {
                    host.buzz(35);
                }
                apply();
                invalidate();
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                Prefs.putInt(K_THR, Math.round(value * 1000));
            }
            return true;
        }

        private void apply() {
            DcsLink.throttle = value;
            if (DcsLink.sim || !PcHid.connected()) {
                return;
            }
            if (Prefs.getInt(K_THR_MODE, 0) == 0) {
                if (Math.abs(value - sent) > 0.004f) {
                    sent = value;
                    PcHid.axis(value);
                }
            } else {
                removeCallbacks(keyLoop);
                post(keyLoop);
            }
        }
    }

    // ------------------------------------------------------------------ AIRCRAFT page

    private static final int HUD = 0xFF3CFF7A;
    private static final int PHOS = 0xFF35FF6A;

    private static float[] mirror(float[] pts) {
        float[] m = pts.clone();
        for (int i = 0; i < m.length; i += 2) {
            m[i] = -m[i];
        }
        return m;
    }

    /** Your aircraft from above, in its real paint: red = fully out, blue = partly out, normal = in. */
    private final class PlaneView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneView() {
            super(host);
        }

        private Path poly(float[] pts, float cx, float oy, float sc, boolean mirrorIt) {
            Path path = new Path();
            for (int i = 0; i < pts.length; i += 2) {
                float x = cx + pts[i] * sc;
                float y = oy + pts[i + 1] * sc;
                if (i == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            if (mirrorIt) {
                for (int i = pts.length - 2; i >= 0; i -= 2) {
                    path.lineTo(cx - pts[i] * sc, oy + pts[i + 1] * sc);
                }
            }
            path.close();
            return path;
        }

        /** A moving part: in its normal colour when in, tinted and glowing when out. */
        private void part(Canvas c, float[] pts, float cx, float oy, float sc, float v, boolean both, int skin) {
            for (int k = 0; k < (both ? 2 : 1); k++) {
                Path path = poly(k == 0 ? pts : mirror(pts), cx, oy, sc, false);
                p.setStyle(Paint.Style.FILL);
                if (v > 0.05f) {
                    int col = v > 0.95f ? RED : BLUE;
                    p.setShadowLayer(dp(7), 0, 0, col);
                    p.setColor((col & 0x00FFFFFF) | 0xE6000000);
                    c.drawPath(path, p);
                    p.clearShadowLayer();
                } else {
                    p.setColor(skin);
                    c.drawPath(path, p);
                }
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(0.9f));
                p.setColor(v > 0.05f ? 0xFFFFFFFF : 0x66000000);
                c.drawPath(path, p);
                p.setStyle(Paint.Style.FILL);
            }
        }

        private void star(Canvas c, float x, float y, float r, int color) {
            Path s = new Path();
            for (int i = 0; i < 10; i++) {
                double a = Math.toRadians(-90 + i * 36);
                float rr = i % 2 == 0 ? r : r * 0.42f;
                float px = x + (float) Math.cos(a) * rr;
                float py = y + (float) Math.sin(a) * rr;
                if (i == 0) {
                    s.moveTo(px, py);
                } else {
                    s.lineTo(px, py);
                }
            }
            s.close();
            p.setColor(color);
            c.drawPath(s, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            String fam = family(s.name);
            float w = getWidth();
            float h = getHeight();
            // hangar floor background
            p.setShader(new android.graphics.RadialGradient(w * 0.35f, h / 2f, Math.max(w, h) * 0.7f,
                    0xFF1B1F26, 0xFF07080B, android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setColor(0x0DFFFFFF);
            for (float gx = 0; gx < w; gx += dp(24)) {
                c.drawRect(gx, 0, gx + 1, h, p);
            }
            for (float gy = 0; gy < h; gy += dp(24)) {
                c.drawRect(0, gy, w, gy + 1, p);
            }
            float listW = w * 0.31f;
            float sc = Math.min((w - listW) / 100f, (h - dp(10)) / 108f);
            float cx = (w - listW) / 2f;
            float oy = (h - 102 * sc) / 2f;
            float[] body;
            float[] tails;
            float[] stab;
            float[] flap;
            float[] brake;
            float[] gearN;
            float[] gearM;
            float[] canopy;
            float[] hookP = null;
            float[] nozzles;
            boolean brakeBoth;
            int base;
            int light;
            int dark;
            int[] camo;
            boolean redStar;
            if (fam.equals("flanker")) {
                body = new float[] {0, 0, 2.5f, 6, 4.5f, 16, 6, 26, 12, 36, 46, 58, 46, 63, 14, 66, 12, 80, 8, 98, 4, 101};
                tails = new float[] {9, 64, 11, 64, 12, 90, 10, 90};
                stab = new float[] {11, 82, 32, 93, 32, 97, 10, 96};
                flap = new float[] {14, 62.5f, 36, 58.5f, 37, 61.5f, 14, 66};
                brake = new float[] {-3.5f, 22, 3.5f, 22, 3.5f, 32, -3.5f, 32};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 20, 1.2f, 20, 1.2f, 25, -1.2f, 25};
                gearM = new float[] {7, 54, 10, 54, 10, 60, 7, 60};
                canopy = new float[] {-2.8f, 8, 2.8f, 8, 3, 18, -3, 18};
                nozzles = new float[] {5, 100};
                if (s.name.toUpperCase(Locale.ROOT).contains("33")) {
                    hookP = new float[] {-0.8f, 98, 0.8f, 98, 0.8f, 106, -0.8f, 106};
                }
                base = 0xFF8FA3B8;
                light = 0xFFB9C8D6;
                dark = 0xFF5D7186;
                camo = new int[] {0xFF6F86A0, 0xFFA9BCCB};
                redStar = true;
            } else if (fam.equals("frogfoot")) {
                body = new float[] {0, 0, 2.5f, 5, 4, 15, 5, 38, 48, 42, 48, 49, 8, 56, 6, 74, 4, 86, 22, 92, 22, 96, 2, 97};
                tails = new float[] {-0.8f, 72, 0.8f, 72, 0.8f, 96, -0.8f, 96};
                stab = new float[] {2, 86, 22, 92, 22, 96, 2, 97};
                flap = new float[] {7, 52, 30, 49.5f, 30, 53, 7, 56};
                brake = new float[] {46, 43, 49, 43, 49, 49, 46, 49};
                brakeBoth = true;
                gearN = new float[] {-1.2f, 14, 1.2f, 14, 1.2f, 19, -1.2f, 19};
                gearM = new float[] {9, 46, 12, 46, 12, 53, 9, 53};
                canopy = new float[] {-2.5f, 7, 2.5f, 7, 2.7f, 16, -2.7f, 16};
                nozzles = new float[] {6.5f, 73};
                base = 0xFF7A7F4E;
                light = 0xFF9EA06A;
                dark = 0xFF4F5232;
                camo = new int[] {0xFF6B5638, 0xFF8E9663, 0xFF4E5A35};
                redStar = true;
            } else {
                body = new float[] {0, 0, 2.5f, 6, 4, 14, 5, 22, 14, 40, 46, 55, 46, 60, 16, 64, 9, 72, 9, 78, 28, 90, 28, 94, 8, 94, 6, 100};
                tails = new float[] {9, 66, 11.5f, 66, 13, 86, 10.5f, 86};
                stab = new float[] {9, 78, 28, 90, 28, 94, 8, 94};
                flap = new float[] {16, 62, 33, 59.5f, 33.5f, 62.5f, 16, 65.5f};
                brake = new float[] {-3, 70, 3, 70, 3, 77, -3, 77};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 17, 1.2f, 17, 1.2f, 22, -1.2f, 22};
                gearM = new float[] {6.5f, 50, 9.5f, 50, 9.5f, 56, 6.5f, 56};
                canopy = new float[] {-2.6f, 8, 2.6f, 8, 2.8f, 19, -2.8f, 19};
                hookP = new float[] {-0.8f, 96, 0.8f, 96, 0.8f, 105, -0.8f, 105};
                nozzles = new float[] {3.2f, 100};
                base = 0xFFA7AEB7;
                light = 0xFFC9CFD6;
                dark = 0xFF767E88;
                camo = new int[0];
                redStar = false;
            }
            Path bodyPath = poly(body, cx, oy, sc, true);
            // shadow on the floor
            c.save();
            c.translate(dp(6), dp(8));
            p.setColor(0x66000000);
            c.drawPath(bodyPath, p);
            c.restore();
            // stabilisers and tails under the body
            p.setColor(dark);
            c.drawPath(poly(stab, cx, oy, sc, false), p);
            c.drawPath(poly(mirror(stab), cx, oy, sc, false), p);
            // body: metal with light from the top left
            p.setShader(new android.graphics.LinearGradient(cx - 46 * sc, oy, cx + 46 * sc, oy + 100 * sc,
                    new int[] {light, base, dark}, new float[] {0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            c.drawPath(bodyPath, p);
            p.setShader(null);
            // camouflage, kept inside the body outline
            if (camo.length > 0) {
                c.save();
                c.clipPath(bodyPath);
                java.util.Random rng = new java.util.Random(fam.hashCode());
                for (int i = 0; i < 26; i++) {
                    p.setColor((camo[i % camo.length] & 0x00FFFFFF) | 0xB0000000);
                    float bx = cx + (rng.nextFloat() * 92 - 46) * sc;
                    float by = oy + rng.nextFloat() * 100 * sc;
                    float bw = (6 + rng.nextFloat() * 14) * sc;
                    float bh = (3 + rng.nextFloat() * 8) * sc;
                    c.save();
                    c.rotate(rng.nextFloat() * 180, bx, by);
                    c.drawOval(new RectF(bx - bw, by - bh, bx + bw, by + bh), p);
                    c.restore();
                }
                c.restore();
            }
            // outline and panel lines
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.2f));
            p.setColor(0xCC0E1014);
            c.drawPath(bodyPath, p);
            p.setStrokeWidth(dp(0.6f));
            p.setColor(0x44000000);
            c.drawLine(cx, oy + 20 * sc, cx, oy + 96 * sc, p);
            for (float py : new float[] {28, 38, 48, 58, 70}) {
                c.drawLine(cx - 5 * sc, oy + py * sc, cx + 5 * sc, oy + py * sc, p);
            }
            c.drawLine(cx - 6 * sc, oy + 40 * sc, cx - 40 * sc, oy + 55.5f * sc, p);
            c.drawLine(cx + 6 * sc, oy + 40 * sc, cx + 40 * sc, oy + 55.5f * sc, p);
            p.setStyle(Paint.Style.FILL);
            // tails on top with their own shading
            p.setColor(dark);
            c.drawPath(poly(tails, cx, oy, sc, false), p);
            if (!fam.equals("frogfoot")) {
                c.drawPath(poly(mirror(tails), cx, oy, sc, false), p);
            }
            // engine nozzles
            p.setShader(new android.graphics.RadialGradient(0, 0, 1, 0xFF3A3A3A, 0xFF0A0A0A, android.graphics.Shader.TileMode.CLAMP));
            p.setShader(null);
            p.setColor(0xFF15161A);
            c.drawCircle(cx - nozzles[0] * sc, oy + nozzles[1] * sc, 2.2f * sc, p);
            c.drawCircle(cx + nozzles[0] * sc, oy + nozzles[1] * sc, 2.2f * sc, p);
            p.setColor(0xFF3A3D44);
            c.drawCircle(cx - nozzles[0] * sc, oy + nozzles[1] * sc, 1.2f * sc, p);
            c.drawCircle(cx + nozzles[0] * sc, oy + nozzles[1] * sc, 1.2f * sc, p);
            // insignia: US Navy star or red star on the wings
            if (redStar) {
                star(c, cx - 30 * sc, oy + 55 * sc, 3.6f * sc, 0xFFFFFFFF);
                star(c, cx - 30 * sc, oy + 55 * sc, 3f * sc, 0xFFD21F1F);
                star(c, cx + 30 * sc, oy + 55 * sc, 3.6f * sc, 0xFFFFFFFF);
                star(c, cx + 30 * sc, oy + 55 * sc, 3f * sc, 0xFFD21F1F);
            } else {
                p.setColor(0xFF59606A);
                c.drawCircle(cx - 32 * sc, oy + 56 * sc, 3.4f * sc, p);
                star(c, cx - 32 * sc, oy + 56 * sc, 3f * sc, 0xFFD6DAE0);
                p.setColor(0xFF33373E);
                c.drawRect(cx + 36 * sc, oy + 54.5f * sc, cx + 44 * sc, oy + 55.5f * sc, p);
                // wingtip missiles
                p.setColor(0xFFE8EBEF);
                c.drawRect(cx - 47 * sc, oy + 52 * sc, cx - 46 * sc, oy + 62 * sc, p);
                c.drawRect(cx + 46 * sc, oy + 52 * sc, cx + 47 * sc, oy + 62 * sc, p);
            }
            // moving parts
            part(c, flap, cx, oy, sc, s.flaps, true, (base & 0x00FFFFFF) | 0xFF000000);
            part(c, brake, cx, oy, sc, s.brake, brakeBoth, dark);
            part(c, gearN, cx, oy, sc, s.gear, false, dark);
            part(c, gearM, cx, oy, sc, s.gear, true, dark);
            if (hookP != null) {
                part(c, hookP, cx, oy, sc, s.hook, false, dark);
            }
            // canopy glass (tinted when open)
            Path glass = poly(canopy, cx, oy, sc, false);
            if (s.canopy > 0.05f) {
                part(c, canopy, cx, oy, sc, s.canopy, false, 0xFF1A2633);
            } else {
                p.setShader(new android.graphics.LinearGradient(cx - 3 * sc, oy + 8 * sc, cx + 3 * sc, oy + 19 * sc,
                        new int[] {0xFF5E7C99, 0xFF13202E, 0xFF0A121A}, null, android.graphics.Shader.TileMode.CLAMP));
                c.drawPath(glass, p);
                p.setShader(null);
                p.setColor(0x88FFFFFF);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                c.drawLine(cx - 1.2f * sc, oy + 10 * sc, cx - 1.8f * sc, oy + 15 * sc, p);
                p.setStyle(Paint.Style.FILL);
            }
            // the list on the right
            float lx = w - listW + dp(4);
            float ly = dp(20);
            p.setTypeface(Theme.MONO);
            p.setTextSize(dp(big ? 14 : 11));
            p.setColor(0xFFFFFFFF);
            c.drawText(DcsLink.live() ? nice(s.name.isEmpty() ? "F/A-18C" : s.name) : "no data", lx, ly, p);
            ly += dp(22);
            Object[][] rows = {{"GEAR", s.gear}, {"FLAPS", s.flaps}, {"AIRBRAKE", s.brake}, {"HOOK", s.hook},
                {"CANOPY", s.canopy}, {"WHEEL BRAKE", s.wheel}};
            p.setTextSize(dp(big ? 12 : 10));
            for (Object[] r : rows) {
                if (r[0].equals("HOOK") && hookP == null) {
                    continue;
                }
                float v = (float) r[1];
                int col = v > 0.95f ? RED : v > 0.05f ? BLUE : 0xFF5A5F68;
                p.setColor(col);
                if (v > 0.05f) {
                    p.setShadowLayer(dp(5), 0, 0, col);
                }
                c.drawCircle(lx + dp(5), ly - dp(4), dp(5), p);
                p.clearShadowLayer();
                p.setColor(0xFFE5E5EA);
                c.drawText((String) r[0], lx + dp(14), ly, p);
                p.setColor(col == 0xFF5A5F68 ? 0xFF8E8E93 : col);
                c.drawText(Math.round(v * 100) + "%", lx + dp(14), ly + dp(12), p);
                ly += dp(28);
            }
            p.setTextSize(dp(9));
            p.setColor(RED);
            c.drawText("■ fully out", lx, h - dp(30), p);
            p.setColor(BLUE);
            c.drawText("■ partly out", lx, h - dp(18), p);
            p.setColor(0xFF8E8E93);
            c.drawText("■ in", lx, h - dp(6), p);
        }
    }

    // ------------------------------------------------------------------ CARRIER page

    private final class CarrierView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        CarrierView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setColor(0xFF05070A);
            c.drawRect(0, 0, w, h, p);
            double[] ap = DcsLink.live() ? DcsLink.approach(s, DcsLink.objs) : null;
            if (ap == null) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(12));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(!DcsLink.live() ? "No DCS data (try SIM)" : DcsLink.objectsLive() ? "No carrier within 25 km"
                        : "No carrier data (server may block it)", w / 2, h / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            double along = ap[0];
            double height = ap[2];
            double gs = ap[3];
            double lu = ap[4];
            // ================= side view
            float sh = h * 0.5f;
            float l = 0;
            float r = w;
            float deckY = sh * 0.8f;
            double range = Math.max(1500, Math.min(9000, along * 1.3));
            float tdX = r - dp(70);
            float ppm = (float) ((tdX - dp(10)) / range);
            float vs = (float) Math.max(1, Math.min(6, (deckY * 0.75) / (Math.tan(Math.toRadians(5)) * range * ppm)));
            // sky and sea
            p.setShader(new android.graphics.LinearGradient(0, 0, 0, deckY, 0xFF0D2440, 0xFF5D82A8,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(l, 0, r, deckY, p);
            p.setShader(new android.graphics.LinearGradient(0, deckY, 0, sh, 0xFF0F3E5E, 0xFF04182A,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(l, deckY, r, sh, p);
            p.setShader(null);
            p.setColor(0x22FFFFFF);
            for (int i = 0; i < 6; i++) {
                float wy = deckY + dp(4) + i * (sh - deckY) / 6f;
                for (float wx = (i % 2) * dp(14); wx < w; wx += dp(28)) {
                    c.drawRect(wx, wy, wx + dp(10), wy + 1, p);
                }
            }
            // distance marks every quarter mile
            p.setTextSize(dp(8));
            for (int q = 1; q <= 8; q++) {
                double m = q * 463.0;
                if (m > range) {
                    break;
                }
                float mx = (float) (tdX - m * ppm);
                p.setColor(0x44FFFFFF);
                c.drawRect(mx, deckY - dp(3), mx + 1, deckY + dp(3), p);
                p.setColor(0x88FFFFFF);
                c.drawText(q % 4 == 0 ? q / 4 + "nm" : q == 3 ? "¾" : q == 2 ? "½" : q == 1 ? "¼" : "", mx - dp(4),
                        deckY + dp(12), p);
            }
            // glide slope band and line (3.5 deg)
            Path band = new Path();
            band.moveTo(tdX, deckY);
            band.lineTo(l, (float) (deckY - Math.tan(Math.toRadians(4.2)) * (tdX - l) * vs));
            band.lineTo(l, (float) (deckY - Math.tan(Math.toRadians(2.8)) * (tdX - l) * vs));
            band.close();
            p.setColor(0x2230D158);
            c.drawPath(band, p);
            p.setColor(0xFF30D158);
            p.setStrokeWidth(dp(1.5f));
            p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(8), dp(5)}, 0));
            c.drawLine(tdX, deckY, l, (float) (deckY - Math.tan(Math.toRadians(3.5)) * (tdX - l) * vs), p);
            p.setPathEffect(null);
            // the carrier in profile
            float L = Math.max(dp(110), (float) (333 * ppm));
            float sx = tdX - dp(8);
            Path hull = new Path();
            hull.moveTo(sx, deckY - dp(9));
            hull.lineTo(sx + L * 1.02f, deckY - dp(10));
            hull.lineTo(sx + L * 0.97f, deckY + dp(4));
            hull.lineTo(sx + dp(6), deckY + dp(4));
            hull.close();
            p.setShader(new android.graphics.LinearGradient(0, deckY - dp(10), 0, deckY + dp(4), 0xFF8C939C, 0xFF3D434B,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawPath(hull, p);
            p.setShader(null);
            p.setColor(0xFF2B2F35);
            c.drawRect(sx, deckY - dp(11), sx + L, deckY - dp(9), p);
            // island with mast and radar
            float ix = sx + L * 0.62f;
            p.setColor(0xFF7A818A);
            c.drawRect(ix, deckY - dp(26), ix + dp(16), deckY - dp(11), p);
            p.setColor(0xFF5E656E);
            c.drawRect(ix + dp(3), deckY - dp(34), ix + dp(13), deckY - dp(26), p);
            p.setColor(0xFF9AA1AA);
            c.drawRect(ix + dp(7), deckY - dp(46), ix + dp(8.5f), deckY - dp(34), p);
            c.drawRect(ix + dp(3), deckY - dp(42), ix + dp(13), deckY - dp(41), p);
            p.setColor(0xFFFFD23F);
            c.drawCircle(ix + dp(7.8f), deckY - dp(47), dp(1.5f), p);
            p.setColor(0x55FFFFFF);
            for (int i = 0; i < 4; i++) {
                c.drawRect(ix + dp(2), deckY - dp(23) + i * dp(3), ix + dp(14), deckY - dp(22.4f) + i * dp(3), p);
            }
            // your jet in profile, nose to the right, tilted by pitch
            float jx = (float) (tdX - along * ppm);
            float jy = (float) (deckY - height * ppm * vs);
            jy = Math.max(dp(8), Math.min(deckY - dp(2), jy));
            int gc = Math.abs(gs) < 0.35 ? GREEN : Math.abs(gs) < 0.8 ? AMBER : RED;
            c.save();
            c.translate(jx, jy);
            c.rotate(-s.pitch);
            Path jet = new Path();
            float k = dp(1.15f);
            jet.moveTo(14 * k, 0);
            jet.lineTo(6 * k, -1.6f * k);
            jet.lineTo(-6 * k, -2 * k);
            jet.lineTo(-9 * k, -8 * k);
            jet.lineTo(-12 * k, -8 * k);
            jet.lineTo(-12 * k, 1.5f * k);
            jet.lineTo(6 * k, 2 * k);
            jet.close();
            p.setShadowLayer(dp(6), 0, 0, gc);
            p.setColor(gc);
            c.drawPath(jet, p);
            p.clearShadowLayer();
            if (s.gear > 0.5f) {
                p.setColor(0xFFE5E5EA);
                c.drawRect(4 * k, 2 * k, 4.8f * k, 5 * k, p);
                c.drawRect(-3 * k, 2 * k, -2.2f * k, 5 * k, p);
            }
            if (s.hook > 0.5f) {
                p.setStrokeWidth(dp(1));
                p.setColor(0xFFE5E5EA);
                c.drawLine(-11 * k, 1.5f * k, -15 * k, 5 * k, p);
            }
            c.restore();
            // IFLOLS: green datum bars and the amber ball
            float bx = dp(8);
            float by = dp(8);
            float bw = dp(78);
            float bh = dp(62);
            p.setColor(0xEE000000);
            c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), dp(6), dp(6), p);
            float cyb = by + bh / 2;
            for (int i = 0; i < 4; i++) {
                p.setColor(0xFF2BFF5A);
                p.setShadowLayer(dp(3), 0, 0, 0xFF2BFF5A);
                c.drawCircle(bx + dp(7) + i * dp(5), cyb, dp(1.8f), p);
                c.drawCircle(bx + bw - dp(7) - i * dp(5), cyb, dp(1.8f), p);
            }
            p.clearShadowLayer();
            float lensX = bx + bw / 2;
            p.setColor(0xFF15171A);
            c.drawRect(lensX - dp(6), by + dp(5), lensX + dp(6), by + bh - dp(5), p);
            int cell = (int) Math.round(Math.max(-2.5, Math.min(2.5, -gs / 0.35)));
            float ballY = cyb + cell * (bh - dp(14)) / 6f;
            boolean veryLow = gs < -0.9;
            int ballC = veryLow ? 0xFFFF2D2D : 0xFFFFB020;
            p.setColor(ballC);
            p.setShadowLayer(dp(5), 0, 0, ballC);
            c.drawCircle(lensX, ballY, dp(4.2f), p);
            p.clearShadowLayer();
            p.setColor(0xFFDDDDDD);
            p.setTextSize(dp(7.5f));
            c.drawText("BALL", bx + dp(4), by + bh - dp(3), p);
            // AoA indexer: green V = slow, amber donut = on speed, red ^ = fast
            float ix0 = r - dp(30);
            float iy0 = dp(10);
            float aoa = s.aoa;
            boolean slow = aoa > 8.4f;
            boolean on = aoa >= 7.8f - 0.4f && aoa <= 8.8f;
            boolean fast = aoa < 7.8f;
            p.setColor(0xEE000000);
            c.drawRoundRect(new RectF(ix0 - dp(4), iy0 - dp(4), ix0 + dp(26), iy0 + dp(68)), dp(5), dp(5), p);
            indexer(c, 0, ix0, iy0, aoa > 8.8f || slow && aoa > 8.4f, 0xFF2BFF5A);
            indexer(c, 1, ix0, iy0 + dp(22), on && aoa >= 7.4f, 0xFFFFB020);
            indexer(c, 2, ix0, iy0 + dp(44), fast && aoa < 7.8f, 0xFFFF2D2D);
            // high / low word
            p.setTextSize(dp(big ? 15 : 12));
            p.setColor(gc);
            p.setShadowLayer(dp(4), 0, 0, gc);
            String word = gs > 0.35 ? "HIGH" : gs < -0.35 ? (veryLow ? "LOW  POWER!" : "LOW") : "ON GLIDE SLOPE";
            c.drawText(word, bx + bw + dp(8), dp(22), p);
            p.clearShadowLayer();
            // ================= deck from above, for lineup
            float ty = sh + dp(6);
            float th = h * 0.27f;
            p.setShader(new android.graphics.LinearGradient(0, ty, 0, ty + th, 0xFF06233A, 0xFF0B3654,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(dp(4), ty, w - dp(4), ty + th), dp(10), dp(10), p);
            p.setShader(null);
            float mid = w / 2f;
            // the hull, turned 9 degrees to the right (the ship sails that way)
            c.save();
            c.clipRect(dp(4), ty, w - dp(4), ty + th);
            c.rotate(9, mid, ty + th * 0.35f);
            p.setColor(0xFF4A5059);
            c.drawRoundRect(new RectF(mid - dp(18), ty - th, mid + dp(26), ty + th * 0.55f), dp(10), dp(10), p);
            c.restore();
            // the angled deck: dark grey with white edges and the dashed centreline
            c.save();
            c.clipRect(dp(4), ty, w - dp(4), ty + th);
            p.setColor(0xFF2C3036);
            c.drawRect(mid - dp(16), ty - dp(4), mid + dp(16), ty + th * 0.62f, p);
            p.setColor(0xFFEDEDED);
            c.drawRect(mid - dp(16), ty - dp(4), mid - dp(15), ty + th * 0.62f, p);
            c.drawRect(mid + dp(15), ty - dp(4), mid + dp(16), ty + th * 0.62f, p);
            p.setColor(0xFFFFD23F);
            for (float yy = ty; yy < ty + th * 0.62f; yy += dp(9)) {
                c.drawRect(mid - dp(0.8f), yy, mid + dp(0.8f), yy + dp(5), p);
            }
            // wires
            p.setColor(0xAAFFFFFF);
            for (int i = 0; i < 4; i++) {
                float wy = ty + th * 0.5f - i * dp(5);
                c.drawRect(mid - dp(14), wy, mid + dp(14), wy + 1, p);
            }
            // the extended centreline behind the ship
            p.setColor(0x66FFD23F);
            for (float yy = ty + th * 0.62f; yy < ty + th; yy += dp(9)) {
                c.drawRect(mid - dp(0.6f), yy, mid + dp(0.6f), yy + dp(4), p);
            }
            c.restore();
            float full = 4f;
            float off = (float) (Math.max(-full, Math.min(full, lu)) / full * (w / 2 - dp(24)));
            int lc = Math.abs(lu) < 0.6 ? GREEN : Math.abs(lu) < 1.5 ? AMBER : RED;
            float py = ty + th * 0.86f;
            p.setColor((lc & 0x00FFFFFF) | 0x55000000);
            p.setStrokeWidth(dp(2));
            c.drawLine(mid + off, py, mid, ty + th * 0.55f, p);
            Path top = new Path();
            float kk = dp(1);
            top.moveTo(mid + off, py - 9 * kk);
            top.lineTo(mid + off + 9 * kk, py + 4 * kk);
            top.lineTo(mid + off + 2 * kk, py + 3 * kk);
            top.lineTo(mid + off, py + 7 * kk);
            top.lineTo(mid + off - 2 * kk, py + 3 * kk);
            top.lineTo(mid + off - 9 * kk, py + 4 * kk);
            top.close();
            p.setColor(lc);
            p.setShadowLayer(dp(5), 0, 0, lc);
            c.drawPath(top, p);
            p.clearShadowLayer();
            p.setTextSize(dp(10));
            c.drawText(lu > 0.6 ? "RIGHT → fly left" : lu < -0.6 ? "LEFT ← fly right" : "LINED UP", dp(10), ty + dp(14), p);
            // ================= numbers and lights
            float ny = ty + th + dp(18);
            p.setColor(0xFFE5E5EA);
            p.setTextSize(dp(big ? 14 : 11));
            double nm = along / 1852.0;
            c.drawText(String.format(Locale.ROOT, "%.2f nm   %d ft   %d kt   AoA %.1f", nm, Math.round(height * 3.28084),
                    Math.round(s.ias * 1.94384), aoa), dp(8), ny, p);
            p.setTextSize(dp(9.5f));
            p.setColor(Theme.DIM);
            c.drawText(String.format(Locale.ROOT, "glide slope %+.1f°   lineup %+.1f°", gs, lu), dp(8), ny + dp(14), p);
            String[] ln = {"GEAR", "HOOK", "FLAPS"};
            float[] lv = {s.gear, s.hook, s.flaps};
            for (int i = 0; i < 3; i++) {
                int col = lv[i] > 0.9f ? GREEN : lv[i] > 0.05f ? AMBER : RED;
                float x = dp(8) + i * dp(64);
                RectF pill = new RectF(x, ny + dp(22), x + dp(58), ny + dp(40));
                p.setColor((col & 0x00FFFFFF) | 0x33000000);
                c.drawRoundRect(pill, dp(9), dp(9), p);
                p.setColor(col);
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(ln[i], pill.centerX(), pill.centerY() + dp(3.5f), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            if (nm < 0.8) {
                p.setColor(0xFFFFB020);
                p.setTextSize(dp(11));
                c.drawText("CALL THE BALL", w - dp(110), ny + dp(35), p);
            }
        }

        /** One AoA indexer light: 0 = V (slow), 1 = donut (on speed), 2 = ^ (fast). */
        private void indexer(Canvas c, int kind, float x, float y, boolean lit, int col) {
            p.setColor(lit ? col : (col & 0x00FFFFFF) | 0x26000000);
            if (lit) {
                p.setShadowLayer(dp(6), 0, 0, col);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(4));
            p.setStrokeCap(Paint.Cap.ROUND);
            float cx = x + dp(11);
            if (kind == 1) {
                c.drawCircle(cx, y + dp(9), dp(7), p);
            } else if (kind == 0) {
                c.drawLine(x + dp(2), y + dp(3), cx, y + dp(15), p);
                c.drawLine(cx, y + dp(15), x + dp(20), y + dp(3), p);
            } else {
                c.drawLine(x + dp(2), y + dp(15), cx, y + dp(3), p);
                c.drawLine(cx, y + dp(3), x + dp(20), y + dp(15), p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.clearShadowLayer();
        }
    }

    // ------------------------------------------------------------------ RADAR page

    /** A green phosphor scope: glowing rings, a turning sweep, blips that light up when the sweep passes and fade. */
    private final class RadarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String picked;
        private final long born = SystemClock.uptimeMillis();

        RadarView() {
            super(host);
        }

        private int nm() {
            int[] r = {10, 20, 40, 80};
            return r[Math.max(0, Math.min(3, Prefs.getInt(K_RANGE, 1)))];
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                if (e.getY() < dp(30) && e.getX() > getWidth() - dp(80)) {
                    Prefs.putInt(K_RANGE, (Prefs.getInt(K_RANGE, 1) + 1) % 4);
                } else {
                    picked = nearest(e.getX(), e.getY());
                }
                invalidate();
            }
            return true;
        }

        private float[] geo() {
            float w = getWidth();
            float h = getHeight();
            float R = Math.min(w, h - dp(46)) / 2f - dp(6);
            return new float[] {w / 2f, dp(30) + R + dp(4), R};
        }

        private float[] place(DcsLink.State s, DcsLink.Obj o, float cx, float cy, float R) {
            double dn = o.x - s.x;
            double de = o.z - s.z;
            double hd = Math.toRadians(s.hdg);
            double right = de * Math.cos(hd) - dn * Math.sin(hd);
            double fwd = dn * Math.cos(hd) + de * Math.sin(hd);
            double scale = R / (nm() * 1852.0);
            return new float[] {(float) (cx + right * scale), (float) (cy - fwd * scale), (float) Math.hypot(dn, de),
                (float) ((Math.toDegrees(Math.atan2(right, fwd)) + 360) % 360)};
        }

        private String nearest(float x, float y) {
            DcsLink.State s = DcsLink.st;
            float[] g = geo();
            String best = null;
            float bd = dp(30);
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, g[0], g[1], g[2]);
                float d = (float) Math.hypot(q[0] - x, q[1] - y);
                if (d < bd) {
                    bd = d;
                    best = o.id;
                }
            }
            return best;
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            float[] g = geo();
            float cx = g[0];
            float cy = g[1];
            float R = g[2];
            p.setTypeface(Theme.MONO);
            // the tube
            p.setColor(0xFF010603);
            c.drawRect(0, 0, w, h, p);
            p.setShader(new android.graphics.RadialGradient(cx, cy, R * 1.1f, 0xFF06301A, 0xFF010A05,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            // rings, cross and bearing ticks, glowing
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setShadowLayer(dp(3), 0, 0, PHOS);
            for (int i = 1; i <= 4; i++) {
                p.setColor((PHOS & 0x00FFFFFF) | (i == 4 ? 0xAA000000 : 0x55000000));
                c.drawCircle(cx, cy, R * i / 4f, p);
            }
            p.setColor((PHOS & 0x00FFFFFF) | 0x33000000);
            c.drawLine(cx - R, cy, cx + R, cy, p);
            c.drawLine(cx, cy - R, cx, cy + R, p);
            p.setColor((PHOS & 0x00FFFFFF) | 0x99000000);
            for (int d = 0; d < 360; d += 10) {
                double a = Math.toRadians(d - s.hdg);
                float len = d % 30 == 0 ? dp(8) : dp(4);
                c.drawLine(cx + (float) Math.sin(a) * R, cy - (float) Math.cos(a) * R,
                        cx + (float) Math.sin(a) * (R - len), cy - (float) Math.cos(a) * (R - len), p);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(9));
            p.setColor((PHOS & 0x00FFFFFF) | 0xCC000000);
            p.setTextAlign(Paint.Align.CENTER);
            for (int d = 0; d < 360; d += 90) {
                double a = Math.toRadians(d - s.hdg);
                String lab = d == 0 ? "N" : d == 90 ? "E" : d == 180 ? "S" : "W";
                c.drawText(lab, cx + (float) Math.sin(a) * (R - dp(16)), cy - (float) Math.cos(a) * (R - dp(16)) + dp(3), p);
            }
            p.setTextAlign(Paint.Align.LEFT);
            for (int i = 1; i <= 3; i++) {
                c.drawText(nm() * i / 4 + "", cx + dp(3), cy - R * i / 4f - dp(2), p);
            }
            // the sweep
            float sweep = ((SystemClock.uptimeMillis() - born) % 3000) / 3000f * 360f;
            c.save();
            c.rotate(sweep - 90, cx, cy);
            p.setShader(new android.graphics.SweepGradient(cx, cy, new int[] {0x0035FF6A, 0x0035FF6A, 0x6635FF6A, 0xCC35FF6A},
                    new float[] {0f, 0.75f, 0.985f, 1f}));
            c.drawCircle(cx, cy, R, p);
            p.setShader(null);
            c.restore();
            double sa = Math.toRadians(sweep);
            p.setColor(PHOS);
            p.setStrokeWidth(dp(1.5f));
            p.setShadowLayer(dp(4), 0, 0, PHOS);
            c.drawLine(cx, cy, cx + (float) Math.sin(sa) * R, cy - (float) Math.cos(sa) * R, p);
            p.clearShadowLayer();
            // scanlines
            p.setColor(0x10000000);
            for (float yy = 0; yy < h; yy += dp(3)) {
                c.drawRect(0, yy, w, yy + dp(1), p);
            }
            // you
            p.setColor(PHOS);
            p.setShadowLayer(dp(4), 0, 0, PHOS);
            Path me = new Path();
            me.moveTo(cx, cy - dp(8));
            me.lineTo(cx - dp(5), cy + dp(6));
            me.lineTo(cx, cy + dp(3));
            me.lineTo(cx + dp(5), cy + dp(6));
            me.close();
            c.drawPath(me, p);
            p.clearShadowLayer();
            // header
            p.setTextSize(dp(11));
            p.setColor(PHOS);
            c.drawText("HDG " + String.format(Locale.ROOT, "%03d", Math.round((s.hdg + 360) % 360)), dp(6), dp(16), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText(nm() + " NM ▾", w - dp(6), dp(16), p);
            p.setTextAlign(Paint.Align.LEFT);
            if (!DcsLink.objectsLive()) {
                p.setColor((PHOS & 0x00FFFFFF) | 0xAA000000);
                p.setTextSize(dp(11));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(DcsLink.live() ? "NO CONTACT DATA" : "NO DCS DATA · TRY SIM", cx, cy - R / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                postInvalidateDelayed(40);
                return;
            }
            DcsLink.Obj sel = null;
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, cx, cy, R);
                if (q[2] > nm() * 1852.0) {
                    continue;
                }
                // brightest right after the sweep passed, then fading for one turn
                float since = (sweep - q[3] + 360) % 360;
                float glow = 0.25f + 0.75f * (1f - since / 360f);
                boolean hostile = o.coal != 0 && o.coal != s.coal;
                boolean friend = o.coal == s.coal;
                int col = hostile ? 0xFFFF4A3D : friend ? PHOS : 0xFFFFD84A;
                int a = (int) (255 * glow);
                p.setColor((col & 0x00FFFFFF) | (a << 24));
                p.setShadowLayer(dp(6) * glow, 0, 0, col);
                float z = dp(5);
                if (o.cat == 3) {
                    Path d = new Path();
                    d.moveTo(q[0] - z * 1.6f, q[1]);
                    d.lineTo(q[0] - z, q[1] + z * 0.8f);
                    d.lineTo(q[0] + z, q[1] + z * 0.8f);
                    d.lineTo(q[0] + z * 1.6f, q[1]);
                    d.close();
                    c.drawPath(d, p);
                } else if (o.cat == 2) {
                    c.drawRect(q[0] - z * 0.7f, q[1] - z * 0.7f, q[0] + z * 0.7f, q[1] + z * 0.7f, p);
                } else if (hostile) {
                    Path d = new Path();
                    d.moveTo(q[0], q[1] - z);
                    d.lineTo(q[0] + z, q[1]);
                    d.lineTo(q[0], q[1] + z);
                    d.lineTo(q[0] - z, q[1]);
                    d.close();
                    c.drawPath(d, p);
                } else {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.8f));
                    c.drawArc(new RectF(q[0] - z, q[1] - z, q[0] + z, q[1] + z), 180, 180, false, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(q[0], q[1], dp(1.5f), p);
                }
                if (o.cat == 1) {
                    double rel = Math.toRadians(o.hdg - s.hdg);
                    p.setStrokeWidth(dp(1.4f));
                    c.drawLine(q[0], q[1], q[0] + (float) Math.sin(rel) * dp(12), q[1] - (float) Math.cos(rel) * dp(12), p);
                }
                p.clearShadowLayer();
                if (o.name != null && o.name.equals(s.lockName) && s.lockDist > 0) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.5f));
                    p.setColor(0xFFFFFFFF);
                    p.setShadowLayer(dp(4), 0, 0, 0xFFFFFFFF);
                    c.drawRect(q[0] - dp(9), q[1] - dp(9), q[0] + dp(9), q[1] + dp(9), p);
                    p.clearShadowLayer();
                    p.setStyle(Paint.Style.FILL);
                }
                if (o.id.equals(picked)) {
                    sel = o;
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1));
                    p.setColor(PHOS);
                    c.drawCircle(q[0], q[1], dp(12), p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
            p.setTextSize(dp(10));
            if (sel != null) {
                float[] q = place(s, sel, cx, cy, R);
                p.setColor(PHOS);
                c.drawText(sel.name + "  " + String.format(Locale.ROOT, "%.1f NM  %03d°  %d FT", q[2] / 1852.0,
                        Math.round((q[3] + s.hdg + 360) % 360), Math.round(sel.alt * 3.28084)), dp(6), h - dp(6), p);
            } else {
                p.setColor((PHOS & 0x00FFFFFF) | 0x99000000);
                c.drawText("◠ friend  ◆ hostile  ■ ground  ▬ ship  · tap a blip", dp(6), h - dp(6), p);
            }
            postInvalidateDelayed(40);
        }
    }

    // ------------------------------------------------------------------ TARGET and FLIGHT pages

    /** A green MFD page for your lock. */
    private final class TargetView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        TargetView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setColor(0xFF030805);
            c.drawRect(0, 0, w, h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor((HUD & 0x00FFFFFF) | 0x88000000);
            c.drawRoundRect(new RectF(dp(4), dp(4), w - dp(4), h - dp(4)), dp(10), dp(10), p);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setShadowLayer(dp(4), 0, 0, HUD);
            if (!DcsLink.live() || s.lockDist <= 0) {
                p.setColor((HUD & 0x00FFFFFF) | 0x99000000);
                p.setTextSize(dp(22));
                c.drawText("NO LOCK", w / 2, h / 2f, p);
                p.clearShadowLayer();
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            p.setColor(HUD);
            p.setTextSize(dp(11));
            c.drawText("TGT", w / 2, dp(22), p);
            p.setColor(0xFFFF5A4A);
            p.setShadowLayer(dp(5), 0, 0, 0xFFFF5A4A);
            p.setTextSize(dp(big ? 28 : 21));
            c.drawText(s.lockName.isEmpty() ? "UNKNOWN" : s.lockName, w / 2, dp(50), p);
            p.setColor(HUD);
            p.setShadowLayer(dp(5), 0, 0, HUD);
            p.setTextSize(dp(big ? 50 : 36));
            c.drawText(String.format(Locale.ROOT, "%.1f", s.lockDist / 1852.0), w / 2, dp(big ? 112 : 94), p);
            p.setTextSize(dp(11));
            c.drawText("NM", w / 2, dp(big ? 128 : 108), p);
            // range bar 0..40 nm with the target marker
            float bl = dp(30);
            float br = w - dp(30);
            float yb = dp(big ? 150 : 128);
            p.setStrokeWidth(dp(2));
            c.drawLine(bl, yb, br, yb, p);
            for (int i = 0; i <= 4; i++) {
                float x = bl + (br - bl) * i / 4f;
                c.drawLine(x, yb - dp(4), x, yb + dp(4), p);
            }
            float mx = bl + (br - bl) * Math.min(1f, (float) (s.lockDist / 1852.0 / 40.0));
            Path tri = new Path();
            tri.moveTo(mx, yb - dp(4));
            tri.lineTo(mx - dp(6), yb - dp(14));
            tri.lineTo(mx + dp(6), yb - dp(14));
            tri.close();
            c.drawPath(tri, p);
            p.setTextSize(dp(big ? 16 : 13));
            float y = yb + dp(30);
            c.drawText("VC " + Math.round(s.lockClose * 1.94384f) + " KT" + (s.lockClose > 0 ? "  CLOSING" : "  OPENING"), w / 2, y, p);
            if (s.lockAlt >= 0) {
                c.drawText("ALT " + Math.round(s.lockAlt * 3.28084) + " FT  " + (s.lockAlt > s.alt ? "↑ ABOVE" : "↓ BELOW"),
                        w / 2, y + dp(22), p);
            }
            if (s.lockClose > 1) {
                c.drawText("MERGE ~" + Math.round(s.lockDist / s.lockClose) + " S", w / 2, y + dp(44), p);
            }
            p.clearShadowLayer();
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    /** A green HUD: heading tape, speed and altitude boxes, a pitch ladder that banks with you, and the numbers. */
    private final class FlightView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        FlightView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            p.setShader(new android.graphics.LinearGradient(0, 0, 0, h, 0xFF0B1A2A, 0xFF16222C,
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            boolean live = DcsLink.live();
            float cx = w / 2f;
            float cy = h * 0.46f;
            float ppd = h / 60f;
            p.setShadowLayer(dp(3), 0, 0, HUD);
            p.setColor(HUD);
            // pitch ladder, turning with the bank
            c.save();
            c.clipRect(dp(60), dp(36), w - dp(60), h - dp(56));
            c.rotate(-s.bank, cx, cy);
            p.setStrokeWidth(dp(1.4f));
            p.setTextSize(dp(9));
            for (int d = -30; d <= 30; d += 5) {
                if (d == 0) {
                    continue;
                }
                float y = cy - (d - s.pitch) * ppd;
                float half = dp(d % 10 == 0 ? 34 : 22);
                if (d < 0) {
                    p.setPathEffect(new android.graphics.DashPathEffect(new float[] {dp(5), dp(4)}, 0));
                }
                c.drawLine(cx - half, y, cx - dp(10), y, p);
                c.drawLine(cx + dp(10), y, cx + half, y, p);
                p.setPathEffect(null);
                c.drawLine(cx - half, y, cx - half, y + (d > 0 ? dp(5) : -dp(5)), p);
                c.drawLine(cx + half, y, cx + half, y + (d > 0 ? dp(5) : -dp(5)), p);
                if (d % 10 == 0) {
                    c.drawText(String.valueOf(Math.abs(d)), cx + half + dp(3), y + dp(3), p);
                }
            }
            float hy = cy + s.pitch * ppd;
            p.setStrokeWidth(dp(1.8f));
            c.drawLine(dp(20), hy, w - dp(20), hy, p);
            c.restore();
            // boresight W and the flight path marker
            p.setStrokeWidth(dp(1.8f));
            c.drawLine(cx - dp(14), cy, cx - dp(7), cy + dp(6), p);
            c.drawLine(cx - dp(7), cy + dp(6), cx, cy, p);
            c.drawLine(cx, cy, cx + dp(7), cy + dp(6), p);
            c.drawLine(cx + dp(7), cy + dp(6), cx + dp(14), cy, p);
            float fy = cy + s.aoa * ppd;
            p.setStyle(Paint.Style.STROKE);
            c.drawCircle(cx, fy, dp(5), p);
            p.setStyle(Paint.Style.FILL);
            c.drawLine(cx - dp(13), fy, cx - dp(5), fy, p);
            c.drawLine(cx + dp(5), fy, cx + dp(13), fy, p);
            c.drawLine(cx, fy - dp(5), cx, fy - dp(10), p);
            // heading tape
            p.setTextSize(dp(10));
            p.setStrokeWidth(dp(1.2f));
            float tapeY = dp(26);
            float pxd = dp(4);
            for (int d = -30; d <= 30; d++) {
                int hd = (int) Math.floor(s.hdg) + d;
                float x = cx + (hd - s.hdg) * pxd;
                int hn = ((hd % 360) + 360) % 360;
                if (hn % 5 == 0) {
                    c.drawLine(x, tapeY, x, tapeY - (hn % 10 == 0 ? dp(7) : dp(4)), p);
                }
                if (hn % 10 == 0) {
                    p.setTextAlign(Paint.Align.CENTER);
                    c.drawText(String.format(Locale.ROOT, "%02d", hn / 10), x, tapeY - dp(10), p);
                    p.setTextAlign(Paint.Align.LEFT);
                }
            }
            Path caret = new Path();
            caret.moveTo(cx, tapeY + dp(2));
            caret.lineTo(cx - dp(5), tapeY + dp(9));
            caret.lineTo(cx + dp(5), tapeY + dp(9));
            caret.close();
            c.drawPath(caret, p);
            // speed and altitude boxes
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            RectF sp = new RectF(dp(6), cy - dp(13), dp(58), cy + dp(13));
            RectF al = new RectF(w - dp(72), cy - dp(13), w - dp(6), cy + dp(13));
            c.drawRect(sp, p);
            c.drawRect(al, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(big ? 15 : 13));
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(live ? String.valueOf(Math.round(s.ias * 1.94384f)) : "---", sp.centerX(), cy + dp(5), p);
            c.drawText(live ? String.format(Locale.ROOT, "%,d", Math.round(s.alt * 3.28084f)) : "-----", al.centerX(), cy + dp(5), p);
            p.setTextSize(dp(9));
            c.drawText("KT", sp.centerX(), sp.top - dp(4), p);
            c.drawText("FT", al.centerX(), al.top - dp(4), p);
            c.drawText(String.format(Locale.ROOT, "R %d", Math.round(s.agl * 3.28084f)), al.centerX(), al.bottom + dp(12), p);
            c.drawText(String.format(Locale.ROOT, "%+d FPM", Math.round(s.vs * 196.85f)), al.centerX(), al.bottom + dp(24), p);
            c.drawText(String.format(Locale.ROOT, "M %.2f", s.mach), sp.centerX(), sp.bottom + dp(12), p);
            c.drawText(String.format(Locale.ROOT, "α %.1f", s.aoa), sp.centerX(), sp.bottom + dp(24), p);
            p.setTextAlign(Paint.Align.LEFT);
            // bottom data block
            boolean lbs = family(s.name).equals("hornet");
            float fuel = s.fuel + s.fuelExt;
            String fuelS = lbs ? Math.round(fuel * 2.20462f) + " LB" : Math.round(fuel) + " KG";
            String mins = burn > 1 ? Math.round(fuel / burn) + " MIN" : "-- MIN";
            float by = h - dp(40);
            p.setTextSize(dp(big ? 12 : 10.5f));
            c.drawText(String.format(Locale.ROOT, "G %.1f  MAX %.1f", s.g, DcsLink.maxG), dp(8), by, p);
            c.drawText("FUEL " + fuelS + "  " + mins, dp(8), by + dp(14), p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("CHAFF " + (s.chaff < 0 ? "--" : s.chaff) + "  FLARE " + (s.flare < 0 ? "--" : s.flare), w - dp(8), by, p);
            c.drawText("GUN " + (s.shells < 0 ? "--" : s.shells) + "  WPN " + (s.weapons < 0 ? "--" : s.weapons), w - dp(8), by + dp(14), p);
            p.setTextAlign(Paint.Align.LEFT);
            p.clearShadowLayer();
            String[] names = {"GEAR", "FLAPS", "BRAKE", "HOOK"};
            float[] vals = {s.gear, s.flaps, s.brake, s.hook};
            for (int i = 0; i < 4; i++) {
                int col = vals[i] > 0.95f ? GREEN : vals[i] > 0.05f ? AMBER : 0xFF4A5058;
                float x = dp(8) + i * ((w - dp(16)) / 4f);
                RectF pill = new RectF(x, h - dp(18), x + (w - dp(16)) / 4f - dp(6), h - dp(4));
                p.setColor((col & 0x00FFFFFF) | 0x40000000);
                c.drawRoundRect(pill, dp(7), dp(7), p);
                p.setColor(col);
                p.setTextSize(dp(9));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(names[i], pill.centerX(), pill.centerY() + dp(3), p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            if (!live) {
                p.setColor(0xCC000000);
                c.drawRect(0, h * 0.4f, w, h * 0.55f, p);
                p.setColor(HUD);
                p.setTextSize(dp(12));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText("NO DCS DATA · TRY SIM", cx, h * 0.49f, p);
                p.setTextAlign(Paint.Align.LEFT);
            }
        }
    }

    // ------------------------------------------------------------------ setup and full screen

    static String script(android.content.Context c) {
        try (InputStream in = c.getAssets().open("NovaExport.lua")) {
            byte[] b = new byte[in.available()];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void setup() {
        String ip = "?";
        try {
            for (java.net.NetworkInterface ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress a : java.util.Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address && ni.getName().startsWith("wlan")) {
                        ip = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
            // no Wi-Fi
        }
        String msg = "DATA (radar, carrier, panels)\n"
                + "1. On the PC open:  Saved Games\\DCS\\Scripts  (make the Scripts folder if it is missing; on the beta it is "
                + "DCS.openbeta).\n"
                + "2. No Export.lua there? Save the NOVA script as  Export.lua.\n"
                + "   Already have one (Tacview, SRS...)? Save it as  NovaExport.lua  and add this line at the end of Export.lua:\n"
                + "   dofile(lfs.writedir()..[[Scripts\\NovaExport.lua]])\n"
                + "3. Phone and PC on the same Wi-Fi / router. If Windows asks, allow DCS through the firewall.\n"
                + "4. Start a mission: the dot here turns green.\n"
                + "   Nothing arrives? Open the script and change 255.255.255.255 to this phone's IP: " + ip + "\n\n"
                + "THRUST LEVER\n"
                + "AXIS mode: in DCS Options > Controls > your aircraft > Axis Commands > Thrust, click the cell under "
                + "NOVA Remote and move the lever. If NOVA Remote has no axis column, remove the phone in Windows Bluetooth "
                + "and pair again once.\nKEYS mode needs no setup (uses Num+ / Num−).\n\n"
                + "BUTTONS use the KEY DECK / PC REMOTE Bluetooth connection.";
        new AlertDialog.Builder(host).setTitle("DCS COCKPIT setup")
                .setMessage(msg)
                .setPositiveButton("SHARE SCRIPT", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "NovaExport.lua");
                    i.putExtra(Intent.EXTRA_TEXT, script(host));
                    host.startActivity(Intent.createChooser(i, "Send the DCS script to your PC"));
                })
                .setNeutralButton("TYPE IT ON THE PC", (d, w) -> {
                    if (!PcHid.connected()) {
                        host.toast("Connect the phone to the PC first (KEY DECK > CONNECT)");
                        return;
                    }
                    host.toast("Opening Notepad and typing the script (about 3 minutes, don't touch the PC)");
                    PcHid.run("K:WIN+R|W:600|T:notepad|K:ENTER|W:2000");
                    PcHid.type(script(host));
                })
                .setNegativeButton("VOICE " + (Prefs.getBool(K_VOICE, true) ? "ON" : "OFF"), (d, w) -> {
                    Prefs.putBool(K_VOICE, !Prefs.getBool(K_VOICE, true));
                    host.toast("Carrier calls " + (Prefs.getBool(K_VOICE, true) ? "on" : "off"));
                }).show();
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(10), dp(40), dp(10), dp(12));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("DCS COCKPIT", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", () -> {
            host.hideOverlay();
            PcHid.releaseAll();
            refresh();
        }));
        v.addView(head, wide());
        ScrollView sv = new ScrollView(host);
        sv.addView(new DcsCockpitWidget(host, true));
        v.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    static int dim(int c) {
        return Color.argb(80, Color.red(c), Color.green(c), Color.blue(c));
    }
}
