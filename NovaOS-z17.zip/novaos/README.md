# NOVA OS

Your own phone "OS", built as an Android home-screen app. It replaces the Android look with its own
boot animation, lock screen, home, app drawer, terminal and notes. Once it is your default home app,
Android starts it every time the phone boots, and you can switch back any time.

## What it really is

NOVA is a launcher: Android still runs underneath it (calls, notifications, security, updates).
That is what makes it safe to try and easy to remove. Two honest limits:

- The NOVA lock screen is only a cover for looks. Your real PIN, pattern or fingerprint lock is
  still Android's, so keep it turned on.
- Swiping in from the screen edge shows Android's bars for a moment. That is Android, not NOVA.

## 1. Get the APK

**Option A, on a PC (Android Studio)**
1. Install Android Studio, choose *Open*, and select this folder.
2. Wait for the Gradle sync to finish.
3. Plug in your phone (USB debugging on) and press Run, or use *Build > Build APK(s)*.
   The file lands in `app/build/outputs/apk/debug/app-debug.apk`.

**Option B, no PC needed, using GitHub's free builder**
1. Make a free GitHub account and a new empty repository.
2. Upload all files from this folder, including the hidden `.github` folder.
3. Open the *Actions* tab, run *Build NOVA APK* (it also runs on every upload), wait about 3 minutes.
4. Open the finished run, download the `nova-os-apk` file, unzip it, and open `app-debug.apk` on your phone.

## 2. Install and switch it on

1. Open the APK on your phone and allow "install unknown apps" for the app you opened it from.
2. Open NOVA. Swipe up to unlock. Android asks to make NOVA your default home app. Choose NOVA.
3. Restart the phone. You see the NOVA boot sequence, then the lock screen. From now on it starts at every boot.

## 3. Switch back to Android

- In NOVA: **MENU > Switch back to Android**, then pick your old launcher, or
- Android Settings > Apps > Default apps > **Home app**, then pick your old launcher.

If you ever get stuck, restart in Safe mode (hold the power button, then long-press "Power off").
Safe mode ignores third-party launchers, so the stock one comes back and you can uninstall NOVA.

## Make it yours

- `app/src/main/java/app/novaos/Theme.java`: OS name, version and all colors.
- `app/src/main/res/values/strings.xml`: the name under the app icon.
- `app/src/main/res/drawable/ic_nova_fg.xml`: the icon shape.

## What is inside

| Screen | What it does |
| --- | --- |
| Boot | Kernel-style log after every phone restart, tap to skip |
| Lock | Big clock, swipe up to unlock, returns after the screen turns off |
| Home | Clock, battery, 8 pinned apps (long-press to remove), dock, swipe up for apps |
| Apps | Every installed app, search, long-press to pin, see info or uninstall |
| Terminal | Type an app name to open it, `neofetch`, `apps`, `help` |
| Notes | One page that saves while you type |
