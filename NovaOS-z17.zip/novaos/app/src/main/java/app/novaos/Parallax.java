package app.novaos;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/**
 * Reads how the phone is tilted and reports a smooth offset between -1 and 1 on both axes. The offset is relative
 * to how you usually hold the phone, so the screen sits still when you do. Only listens while started.
 */
final class Parallax implements SensorEventListener {
    interface Target {
        void apply(float nx, float ny);
    }

    private final SensorManager sm;
    private final Sensor accel;
    private final Target target;
    private boolean on;
    private boolean primed;
    private float fastX, fastY;
    private float slowX, slowY;
    private float outX, outY;

    Parallax(Context c, Target target) {
        this.target = target;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        accel = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    void start() {
        if (on || accel == null) {
            return;
        }
        on = true;
        primed = false;
        sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_UI);
    }

    void stop() {
        if (!on) {
            return;
        }
        on = false;
        sm.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0];
        float y = e.values[1];
        if (!primed) {
            fastX = slowX = x;
            fastY = slowY = y;
            primed = true;
        }
        fastX += (x - fastX) * 0.15f;
        fastY += (y - fastY) * 0.15f;
        slowX += (x - slowX) * 0.01f; // the "resting" way you hold the phone
        slowY += (y - slowY) * 0.01f;
        float tx = clamp((fastX - slowX) / 3.5f);
        float ty = clamp((fastY - slowY) / 3.5f);
        outX += (tx - outX) * 0.35f;
        outY += (ty - outY) * 0.35f;
        target.apply(outX, outY);
    }

    private static float clamp(float v) {
        return Math.max(-1f, Math.min(1f, v));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
