package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Base for the mini-games. Each game fills the full-screen frame it is shown in. */
abstract class Game extends FrameLayout {
    final NovaActivity host;
    final Handler h = new Handler(Looper.getMainLooper());
    final float d;

    Game(NovaActivity host) {
        super(host);
        this.host = host;
        this.d = host.getResources().getDisplayMetrics().density;
    }

    abstract String title();

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    TextView label(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    TextView button(String s, final Runnable action) {
        TextView t = label(s, 13f, Theme.ACCENT);
        t.setLetterSpacing(0.12f);
        t.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
        t.setPadding(Theme.dp(host, 18), Theme.dp(host, 12), Theme.dp(host, 18), Theme.dp(host, 12));
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    int dp(float v) {
        return Theme.dp(host, v);
    }

    static int best(String key, int def) {
        return Prefs.getInt("best_" + key, def);
    }

    static void saveBest(String key, int v) {
        Prefs.putInt("best_" + key, v);
    }
}
