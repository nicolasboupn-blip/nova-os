package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The casino page: roulette, blackjack, dice duel and scratch cards. They all play with the slot coins. */
final class CasinoPage extends LinearLayout {
    private static final String[] NAMES = {"ROULETTE", "BLACKJACK", "DICE DUEL", "SCRATCH", "PARTY WHEEL"};
    private static final String[] ICONS = {"🎡", "♠️", "🎲", "🎟", "🥳"};
    private static final String[] SUBS = {"pays 35 to 1", "pays 3 to 2", "win x1.9", "win up to x25", "just tap it · for friends"};

    private final NovaActivity host;
    private final TextView coins;

    CasinoPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        coins = new TextView(host);
        coins.setTypeface(Theme.MONO);
        coins.setTextSize(10f);
        coins.setTextColor(Theme.DIM);
        coins.setGravity(Gravity.CENTER);
        addView(coins, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        for (int row = 0; row < 3; row++) {
            LinearLayout line = new LinearLayout(host);
            for (int col = 0; col < (row == 2 ? 1 : 2); col++) {
                final int idx = row * 2 + col;
                LinearLayout box = new LinearLayout(host);
                box.setOrientation(VERTICAL);
                box.setGravity(Gravity.CENTER);
                box.setBackground(Theme.rounded(0x26FFFFFF, 14f, host));
                box.setClickable(true);
                Theme.ripple(box);
                TextView icon = new TextView(host);
                icon.setText(ICONS[idx]);
                icon.setTextSize(22f);
                icon.setGravity(Gravity.CENTER);
                box.addView(icon);
                TextView name = new TextView(host);
                name.setText(NAMES[idx]);
                name.setTypeface(Theme.MONO);
                name.setTextSize(10f);
                name.setLetterSpacing(0.1f);
                name.setTextColor(Theme.TEXT);
                name.setGravity(Gravity.CENTER);
                box.addView(name);
                TextView sub = new TextView(host);
                sub.setText(SUBS[idx]);
                sub.setTypeface(Theme.MONO);
                sub.setTextSize(8f);
                sub.setTextColor(Theme.DIM);
                sub.setGravity(Gravity.CENTER);
                box.addView(sub);
                box.setOnClickListener(v -> open(idx, v));
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Theme.dp(host, 68), row == 2 ? 2f : 1f);
                bp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                line.addView(box, bp);
            }
            addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        refresh();
    }

    void refresh() {
        coins.setText("COINS " + Prefs.getInt("slot_coins", 100));
    }

    private void open(int idx, View box) {
        Game g;
        switch (idx) {
            case 0:
                g = new GameRoulette(host);
                break;
            case 1:
                g = new GameBlackjack(host);
                break;
            case 2:
                g = new GameDice(host);
                break;
            case 4:
                g = new GamePartyWheel(host);
                break;
            default:
                g = new GameScratch(host);
                break;
        }
        GameFrame frame = new GameFrame(host, g, box, this::refresh);
        host.showOverlay(frame);
        frame.grow();
    }
}
