package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Sunrise, sunset and an arc that shows where the sun is right now. Uses the city from the weather page. */
final class SunPage extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final float d;
    private boolean loading;
    private long lastTry;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                maybeLoad();
                invalidate();
            }
            ui.postDelayed(this, 20_000);
        }
    };

    SunPage(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.MONOSPACE);
        p.setTextAlign(Paint.Align.CENTER);
    }

    private void maybeLoad() {
        if (loading || !WeatherData.hasCity()) {
            return;
        }
        long now = System.currentTimeMillis();
        if ((WeatherData.valid && now - WeatherData.loadedAt < 20 * 60_000L) || now - lastTry < 60_000L) {
            return;
        }
        lastTry = now;
        loading = true;
        new Thread(() -> {
            WeatherData.load(false);
            ui.post(() -> {
                loading = false;
                invalidate();
            });
        }).start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        p.setStyle(Paint.Style.FILL);
        if (!WeatherData.hasCity()) {
            p.setColor(Theme.DIM);
            p.setTextSize(11 * d);
            c.drawText("Set your city on the WEATHER page first", w / 2f, h / 2f, p);
            return;
        }
        WeatherData.Day today = WeatherData.valid ? WeatherData.days[0] : null;
        if (today == null || today.sunrise == null || today.sunrise.isEmpty()) {
            p.setColor(Theme.DIM);
            p.setTextSize(11 * d);
            c.drawText(loading ? "loading..." : "no data", w / 2f, h / 2f, p);
            return;
        }
        LocalDateTime rise;
        LocalDateTime set;
        try {
            rise = LocalDateTime.parse(today.sunrise, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            set = LocalDateTime.parse(today.sunset, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        } catch (RuntimeException e) {
            p.setColor(Theme.DIM);
            c.drawText("no data", w / 2f, h / 2f, p);
            return;
        }
        // "now" on the city's own clock
        LocalDateTime now = LocalDateTime.now(java.time.ZoneOffset.ofTotalSeconds(WeatherData.utcOffset));
        long total = Duration.between(rise, set).getSeconds();
        long into = Duration.between(rise, now).getSeconds();
        float f = total > 0 ? Math.max(0f, Math.min(1f, into / (float) total)) : 0f;
        boolean daytime = into >= 0 && into <= total;

        float cx = w / 2f;
        float baseY = h * 0.70f;
        float radius = Math.min(w * 0.36f, h * 0.55f);
        oval.set(cx - radius, baseY - radius, cx + radius, baseY + radius);

        // horizon
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.5f * d);
        p.setColor(0x55FFFFFF);
        c.drawLine(cx - radius * 1.25f, baseY, cx + radius * 1.25f, baseY, p);
        // arc
        p.setStrokeWidth(2f * d);
        p.setColor(Theme.DIM);
        Path arc = new Path();
        arc.addArc(oval, 180f, 180f);
        c.drawPath(arc, p);
        // travelled part, glowing
        p.setColor(Theme.ACCENT);
        p.setStrokeWidth(3f * d);
        c.drawArc(oval, 180f, 180f * f, false, p);
        // the sun
        double ang = Math.PI * (1.0 - f);
        float sx = cx + (float) Math.cos(ang) * radius;
        float sy = baseY - (float) Math.sin(ang) * radius;
        p.setStyle(Paint.Style.FILL);
        if (daytime) {
            p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x44000000);
            c.drawCircle(sx, sy, 13 * d, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(sx, sy, 6 * d, p);
        } else {
            p.setColor(0x55FFFFFF);
            c.drawCircle(f < 0.5f ? cx - radius : cx + radius, baseY, 5 * d, p);
        }

        p.setTextSize(11 * d);
        p.setColor(Theme.TEXT);
        c.drawText(today.sunrise.substring(11), cx - radius, baseY + 16 * d, p);
        c.drawText(today.sunset.substring(11), cx + radius, baseY + 16 * d, p);
        p.setTextSize(9 * d);
        p.setColor(Theme.DIM);
        c.drawText("SUNRISE", cx - radius, baseY + 28 * d, p);
        c.drawText("SUNSET", cx + radius, baseY + 28 * d, p);
        long mins = total / 60;
        p.setTextSize(11 * d);
        p.setColor(Theme.TEXT);
        c.drawText((mins / 60) + "h " + (mins % 60) + "m of daylight", cx, baseY - radius * 0.35f, p);
        p.setTextSize(9 * d);
        p.setColor(Theme.DIM);
        String next;
        if (into < 0) {
            next = "sunrise in " + fmt(-into);
        } else if (into <= total) {
            next = "sunset in " + fmt(total - into);
        } else {
            next = "sun is down";
        }
        c.drawText(next, cx, baseY - radius * 0.35f + 14 * d, p);
    }

    private static String fmt(long seconds) {
        long m = seconds / 60;
        return (m / 60) + "h " + (m % 60) + "m";
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
