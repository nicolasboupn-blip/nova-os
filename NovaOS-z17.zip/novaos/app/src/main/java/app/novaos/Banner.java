package app.novaos;

import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** A small glowing message that drops in from the top and fades away. */
final class Banner {
    private Banner() {
    }

    static void show(final NovaActivity host, String text, long stayMs) {
        final TextView banner = new TextView(host);
        banner.setText(text);
        banner.setTypeface(Theme.MONO);
        banner.setTextSize(13f);
        banner.setLetterSpacing(0.06f);
        banner.setTextColor(Theme.TEXT);
        banner.setGravity(Gravity.CENTER);
        banner.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        banner.setPadding(Theme.dp(host, 20), Theme.dp(host, 12), Theme.dp(host, 20), Theme.dp(host, 12));
        banner.setElevation(Theme.dp(host, 12));
        banner.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Theme.dp(host, 48);
        lp.leftMargin = Theme.dp(host, 16);
        lp.rightMargin = Theme.dp(host, 16);
        host.root.addView(banner, lp);
        banner.setAlpha(0f);
        banner.setTranslationY(-Theme.dp(host, 30));
        banner.animate().alpha(1f).translationY(0f).setDuration(260).start();
        banner.postDelayed(() -> banner.animate().alpha(0f).translationY(-Theme.dp(host, 20)).setDuration(300)
                .withEndAction(() -> {
                    if (banner.getParent() != null) {
                        host.root.removeView(banner);
                    }
                }).start(), stayMs);
    }
}
