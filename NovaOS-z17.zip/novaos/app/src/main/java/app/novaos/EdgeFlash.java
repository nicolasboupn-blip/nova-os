package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;

/** A glowing light that pulses around the screen edge when a notification arrives. Removes itself when done. */
final class EdgeFlash extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float d;
    private float t;
    private ValueAnimator anim;

    EdgeFlash(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        p.setStyle(Paint.Style.STROKE);
        setClickable(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(1700);
        anim.addUpdateListener(a -> {
            t = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                if (getParent() instanceof ViewGroup) {
                    ((ViewGroup) getParent()).removeView(EdgeFlash.this);
                }
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected boolean dispatchHoverEvent(android.view.MotionEvent event) {
        return false;
    }

    @Override
    public boolean onTouchEvent(android.view.MotionEvent event) {
        return false;
    }

    @Override
    protected void onDraw(Canvas c) {
        // two soft pulses
        float pulse = (float) Math.pow(Math.sin(t * Math.PI * 2.0 - 0.0) * 0.5 + 0.5, 1.5);
        float env = (float) Math.sin(t * Math.PI);
        float a = Math.max(0f, pulse * env);
        float w = getWidth();
        float h = getHeight();
        int glow = Theme.ACCENT & 0x00FFFFFF;
        float[] widths = {40f, 24f, 12f, 4f};
        int[] alphas = {0x14, 0x26, 0x55, 0xFF};
        for (int i = 0; i < widths.length; i++) {
            p.setStrokeWidth(widths[i] * d);
            p.setColor((((int) (alphas[i] * a)) << 24) | (i == 3 ? 0x00FFFFFF : glow));
            float inset = widths[i] * d / 2f - 2 * d;
            r.set(inset, inset, w - inset, h - inset);
            c.drawRoundRect(r, 36 * d, 36 * d, p);
        }
    }
}
