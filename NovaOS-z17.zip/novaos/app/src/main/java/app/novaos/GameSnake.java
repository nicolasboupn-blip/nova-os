package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Swipe to steer, eat the glowing dots, do not hit the walls or yourself. */
final class GameSnake extends Game {
    private static final int COLS = 14;

    GameSnake(NovaActivity host) {
        super(host);
        addView(new Board(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    @Override
    String title() {
        return "SNAKE";
    }

    private final class Board extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Random rnd = new Random();
        private final List<int[]> snake = new ArrayList<>();
        private int rows;
        private float cell;
        private float ox, oy;
        private int dx = 1, dy = 0, nextDx = 1, nextDy = 0;
        private int[] food = {0, 0};
        private int score;
        private boolean over, started;
        private float downX, downY;
        private boolean swiped;
        private long born = System.currentTimeMillis();

        private final Runnable step = new Runnable() {
            @Override
            public void run() {
                advance();
            }
        };

        Board(Context c) {
            super(c);
            p.setTypeface(Typeface.MONOSPACE);
        }

        @Override
        protected void onSizeChanged(int w, int hh, int ow, int oh) {
            cell = w / (float) COLS;
            rows = Math.max(8, (int) ((hh - dp(110)) / cell));
            ox = 0;
            oy = dp(70);
            reset();
        }

        private void reset() {
            h.removeCallbacks(step);
            snake.clear();
            int cx = COLS / 2;
            int cy = rows / 2;
            for (int i = 0; i < 3; i++) {
                snake.add(new int[] {cx - i, cy});
            }
            dx = 1;
            dy = 0;
            nextDx = 1;
            nextDy = 0;
            score = 0;
            over = false;
            started = false;
            placeFood();
            invalidate();
        }

        private void placeFood() {
            while (true) {
                int fx = rnd.nextInt(COLS);
                int fy = rnd.nextInt(rows);
                boolean free = true;
                for (int[] s : snake) {
                    if (s[0] == fx && s[1] == fy) {
                        free = false;
                        break;
                    }
                }
                if (free) {
                    food[0] = fx;
                    food[1] = fy;
                    return;
                }
            }
        }

        private void advance() {
            dx = nextDx;
            dy = nextDy;
            int[] head = snake.get(0);
            int nx = head[0] + dx;
            int ny = head[1] + dy;
            boolean eat = nx == food[0] && ny == food[1];
            boolean dead = nx < 0 || ny < 0 || nx >= COLS || ny >= rows;
            if (!dead) {
                int limit = eat ? snake.size() : snake.size() - 1;
                for (int i = 0; i < limit; i++) {
                    int[] s = snake.get(i);
                    if (s[0] == nx && s[1] == ny) {
                        dead = true;
                        break;
                    }
                }
            }
            if (dead) {
                over = true;
                host.buzz(80);
                if (score > best("snake", 0)) {
                    saveBest("snake", score);
                }
                invalidate();
                return;
            }
            snake.add(0, new int[] {nx, ny});
            if (eat) {
                score++;
                host.buzz(12);
                placeFood();
                if (score >= 15) {
                    Badges.unlock(host, "snake");
                }
            } else {
                snake.remove(snake.size() - 1);
            }
            invalidate();
            h.postDelayed(step, Math.max(70, 150 - score * 3));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    swiped = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float mx = e.getX() - downX;
                    float my = e.getY() - downY;
                    float t = dp(22);
                    if (!over && (Math.abs(mx) > t || Math.abs(my) > t)) {
                        int ndx = 0, ndy = 0;
                        if (Math.abs(mx) > Math.abs(my)) {
                            ndx = mx > 0 ? 1 : -1;
                        } else {
                            ndy = my > 0 ? 1 : -1;
                        }
                        if (ndx != -dx || ndy != -dy) {
                            nextDx = ndx;
                            nextDy = ndy;
                        }
                        swiped = true;
                        downX = e.getX();
                        downY = e.getY();
                        if (!started) {
                            started = true;
                            h.postDelayed(step, 150);
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!swiped) {
                        if (over) {
                            reset();
                        } else if (!started) {
                            started = true;
                            h.postDelayed(step, 150);
                        }
                    }
                    return true;
                default:
                    return true;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Theme.TEXT);
            p.setTextSize(22 * d);
            c.drawText("SCORE " + score, w / 2f, dp(46), p);
            p.setColor(Theme.DIM);
            p.setTextSize(11 * d);
            c.drawText("BEST " + Math.max(best("snake", 0), score), w / 2f, dp(62), p);

            // board
            r.set(ox, oy, ox + cell * COLS, oy + cell * rows);
            p.setColor(0xFF140E26);
            c.drawRoundRect(r, dp(10), dp(10), p);
            // food, pulsing
            float pulse = 0.55f + 0.2f * (float) Math.sin((System.currentTimeMillis() - born) / 160.0);
            float fx = ox + (food[0] + 0.5f) * cell;
            float fy = oy + (food[1] + 0.5f) * cell;
            p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x44000000);
            c.drawCircle(fx, fy, cell * (pulse + 0.35f), p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(fx, fy, cell * 0.28f, p);
            // snake
            for (int i = snake.size() - 1; i >= 0; i--) {
                int[] s = snake.get(i);
                float l = ox + s[0] * cell + 1.5f * d;
                float t = oy + s[1] * cell + 1.5f * d;
                r.set(l, t, l + cell - 3 * d, t + cell - 3 * d);
                p.setColor(i == 0 ? 0xFFFFFFFF : Theme.ACCENT);
                p.setAlpha(i == 0 ? 255 : Math.max(110, 255 - i * 10));
                c.drawRoundRect(r, cell * 0.3f, cell * 0.3f, p);
            }
            p.setAlpha(255);
            if (!started && !over) {
                p.setColor(Theme.TEXT);
                p.setTextSize(13 * d);
                c.drawText("SWIPE TO START", w / 2f, oy + cell * rows + dp(30), p);
            }
            if (over) {
                p.setColor(0xCC0C0917);
                c.drawRoundRect(ox, oy, ox + cell * COLS, oy + cell * rows, dp(10), dp(10), p);
                p.setColor(Theme.TEXT);
                p.setTextSize(24 * d);
                c.drawText("GAME OVER", w / 2f, oy + cell * rows / 2f, p);
                p.setColor(Theme.ACCENT);
                p.setTextSize(12 * d);
                c.drawText("tap to play again", w / 2f, oy + cell * rows / 2f + dp(28), p);
            }
            if (started && !over) {
                postInvalidateOnAnimation();
            }
        }
    }
}
