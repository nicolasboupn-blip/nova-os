package app.novaos;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One scratch note that saves itself as you type. */
final class NotePage extends LinearLayout {
    private final NovaActivity host;
    private final EditText edit;

    NotePage(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);

        TextView hint = new TextView(host);
        hint.setText("saves as you type");
        hint.setTypeface(Theme.MONO);
        hint.setTextSize(10f);
        hint.setTextColor(Theme.DIM);
        hint.setGravity(Gravity.END);
        addView(hint, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        edit = new EditText(host);
        edit.setText(Prefs.getString("quick_note", ""));
        edit.setHint("write something...");
        edit.setHintTextColor(Theme.DIM);
        edit.setTextColor(Theme.TEXT);
        edit.setTextSize(14f);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        edit.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        edit.setPadding(Theme.dp(host, 12), Theme.dp(host, 8), Theme.dp(host, 12), Theme.dp(host, 8));
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Prefs.putString("quick_note", s.toString());
            }
        });
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = Theme.dp(host, 4);
        addView(edit, lp);
    }

    /** Called when the page is left, so the keyboard does not stay open over another page. */
    void leave() {
        edit.clearFocus();
        InputMethodManager imm = (InputMethodManager) host.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(edit.getWindowToken(), 0);
        }
    }
}
