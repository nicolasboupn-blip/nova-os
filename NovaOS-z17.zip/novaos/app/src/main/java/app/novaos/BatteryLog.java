package app.novaos;

import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Remembers the battery level through the day, so the BATTERY page can draw a graph and say
 * how much was used. Android does not hand a normal app its battery history, so NOVA keeps its own:
 * one sample whenever the level changes. Home screens stay running all day, which makes this accurate.
 */
final class BatteryLog {
    static final class Sample {
        final long t;
        final int level;
        final boolean charging;

        Sample(long t, int level, boolean charging) {
            this.t = t;
            this.level = level;
            this.charging = charging;
        }
    }

    /** What happened today, worked out from the samples. */
    static final class Day {
        List<Sample> samples = new ArrayList<>();
        int used;          // percent drained while on battery
        int charged;       // percent gained while charging
        float perHour;     // average drain per hour on battery, 0 if unknown
        long dayStart;
    }

    private static final String KEY = "bat_log";
    private static final int MAX = 500;
    private static final long GAP = 30 * 60 * 1000L;

    private BatteryLog() {}

    static long midnight() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static List<Sample> load() {
        List<Sample> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String part : raw.split(";")) {
            String[] f = part.split(",");
            if (f.length == 3) {
                try {
                    out.add(new Sample(Long.parseLong(f[0]), Integer.parseInt(f[1]), f[2].equals("1")));
                } catch (NumberFormatException ignored) {
                    // skip a damaged entry
                }
            }
        }
        return out;
    }

    /** Called whenever Android reports a battery change. Stores a sample if something changed. */
    static void record(SharedPreferences sp, int level, boolean charging) {
        if (level < 0) {
            return;
        }
        List<Sample> l = load();
        long now = System.currentTimeMillis();
        if (!l.isEmpty()) {
            Sample last = l.get(l.size() - 1);
            if (last.level == level && last.charging == charging && now - last.t < GAP) {
                return;
            }
        }
        l.add(new Sample(now, level, charging));
        while (l.size() > MAX) {
            l.remove(0);
        }
        StringBuilder sb = new StringBuilder();
        for (Sample s : l) {
            if (sb.length() > 0) {
                sb.append(';');
            }
            sb.append(s.t).append(',').append(s.level).append(',').append(s.charging ? 1 : 0);
        }
        sp.edit().putString(KEY, sb.toString()).apply();
    }

    static Day today() {
        Day d = new Day();
        d.dayStart = midnight();
        List<Sample> all = load();
        Sample before = null; // the last sample from yesterday, so the line starts at midnight
        for (Sample s : all) {
            if (s.t >= d.dayStart) {
                d.samples.add(s);
            } else {
                before = s;
            }
        }
        if (before != null) {
            d.samples.add(0, new Sample(d.dayStart, before.level, before.charging));
        }
        long drainMs = 0;
        float drainPct = 0;
        for (int i = 1; i < d.samples.size(); i++) {
            Sample a = d.samples.get(i - 1);
            Sample b = d.samples.get(i);
            int diff = b.level - a.level;
            if (diff < 0 && !a.charging && !b.charging) {
                d.used += -diff;
                drainPct += -diff;
            }
            if (diff > 0 && b.charging) {
                d.charged += diff;
            }
            if (!a.charging && b.t - a.t <= GAP) {
                drainMs += b.t - a.t;
            }
        }
        if (drainMs > 20 * 60 * 1000L) {
            d.perHour = drainPct / (drainMs / 3600000f);
        }
        return d;
    }
}
