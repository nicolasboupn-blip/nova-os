package app.novaos;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** NOVA's own gallery: a grid of your latest photos, a full-screen viewer you swipe through, and sharing. */
final class GalleryApp extends Game {
    private static final int COLS = 3;
    private static final int MAX = 400;

    private final List<Long> ids = new ArrayList<>();
    private final LruCache<Long, Bitmap> cache = new LruCache<>(120);
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final FrameLayout holder;
    private GridView grid;
    private final TextView status;
    private ImageView big;
    private FrameLayout viewer;
    private int viewing = -1;

    GalleryApp(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(58), dp(6), dp(6));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        status = label("", 12f, Theme.DIM);
        status.setPadding(0, 0, 0, dp(8));
        col.addView(status);
        holder = new FrameLayout(host);
        col.addView(holder, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        final String perm = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        host.ask(new String[] {perm}, this::load, () -> {
            status.setText("NOVA needs access to your photos");
            TextView again = button("ALLOW PHOTOS", () -> host.ask(new String[] {perm}, this::load, null));
            holder.addView(again, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        });
    }

    @Override
    String title() {
        return "GALLERY";
    }

    @Override
    protected void onDetachedFromWindow() {
        pool.shutdownNow();
        super.onDetachedFromWindow();
    }

    private void load() {
        ids.clear();
        try (Cursor c = host.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[] {MediaStore.Images.Media._ID},
                null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            while (c != null && c.moveToNext() && ids.size() < MAX) {
                ids.add(c.getLong(0));
            }
        } catch (Exception e) {
            status.setText("Could not read photos");
            return;
        }
        status.setText(ids.isEmpty() ? "NO PHOTOS YET" : ids.size() + " LATEST PHOTOS");
        holder.removeAllViews();
        grid = new GridView(host);
        grid.setNumColumns(COLS);
        grid.setHorizontalSpacing(dp(3));
        grid.setVerticalSpacing(dp(3));
        grid.setVerticalScrollBarEnabled(false);
        grid.setAdapter(new Adapter());
        holder.addView(grid, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private Uri uri(long id) {
        return ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
    }

    // ------------------------------------------------------------------ the grid

    private final class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return ids.size();
        }

        @Override
        public Object getItem(int i) {
            return ids.get(i);
        }

        @Override
        public long getItemId(int i) {
            return ids.get(i);
        }

        @Override
        public View getView(final int pos, View convert, ViewGroup parent) {
            ImageView v = convert instanceof ImageView ? (ImageView) convert : new ImageView(host);
            int pw = parent.getWidth() > 0 ? parent.getWidth()
                    : host.getResources().getDisplayMetrics().widthPixels - dp(12);
            int side = (pw - dp(3) * (COLS - 1)) / COLS;
            v.setLayoutParams(new GridView.LayoutParams(side, side));
            v.setScaleType(ImageView.ScaleType.CENTER_CROP);
            v.setBackgroundColor(0x22FFFFFF);
            final long id = ids.get(pos);
            v.setTag(id);
            Bitmap hit = cache.get(id);
            if (hit != null) {
                v.setImageBitmap(hit);
            } else {
                v.setImageDrawable(null);
                final ImageView target = v;
                pool.execute(() -> {
                    final Bitmap b = thumb(id);
                    if (b != null) {
                        cache.put(id, b);
                        h.post(() -> {
                            if (target.getTag() instanceof Long && (Long) target.getTag() == id) {
                                target.setImageBitmap(b);
                            }
                        });
                    }
                });
            }
            v.setOnClickListener(x -> open(pos));
            return v;
        }
    }

    @SuppressWarnings("deprecation")
    private Bitmap thumb(long id) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                return host.getContentResolver().loadThumbnail(uri(id), new Size(300, 300), null);
            }
            return MediaStore.Images.Thumbnails.getThumbnail(host.getContentResolver(), id,
                    MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ the viewer

    private void open(int pos) {
        viewing = pos;
        viewer = new FrameLayout(host);
        viewer.setBackgroundColor(0xFF000000);
        big = new ImageView(host);
        big.setScaleType(ImageView.ScaleType.FIT_CENTER);
        viewer.addView(big, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        final GestureDetector gd = new GestureDetector(host, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (Math.abs(vx) > Math.abs(vy) && Math.abs(vx) > 600) {
                    step(vx < 0 ? 1 : -1);
                    return true;
                }
                if (vy > 1200 && Math.abs(vy) > Math.abs(vx)) {
                    close();
                    return true;
                }
                return false;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return false;
            }
        });
        viewer.setOnTouchListener((v, e) -> gd.onTouchEvent(e) || true);

        TextView share = label("SHARE", 12f, Theme.TEXT);
        share.setLetterSpacing(0.2f);
        share.setPadding(dp(18), dp(14), dp(18), dp(14));
        share.setBackground(Theme.rounded(0x99000000, 16f, host));
        share.setClickable(true);
        share.setOnClickListener(v -> share());
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = dp(40);
        viewer.addView(share, sp);

        TextView back = label("✕", 22f, Theme.TEXT);
        back.setPadding(dp(18), dp(16), dp(18), dp(16));
        back.setClickable(true);
        back.setOnClickListener(v -> close());
        viewer.addView(back, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END));

        addView(viewer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        viewer.bringToFront();
        showBig();
    }

    private void step(int d) {
        int n = viewing + d;
        if (n >= 0 && n < ids.size()) {
            viewing = n;
            showBig();
        }
    }

    private void showBig() {
        final long id = ids.get(viewing);
        big.setTag(id);
        Bitmap small = cache.get(id);
        if (small != null) {
            big.setImageBitmap(small);
        }
        final int target = Math.max(host.getResources().getDisplayMetrics().widthPixels, 1080);
        pool.execute(() -> {
            final Bitmap full = decode(id, target);
            if (full != null) {
                h.post(() -> {
                    if (big != null && big.getTag() instanceof Long && (Long) big.getTag() == id) {
                        big.setImageBitmap(full);
                    }
                });
            }
        });
    }

    private Bitmap decode(long id, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = host.getContentResolver().openInputStream(uri(id))) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int s = 1;
            while (o.outWidth / (s * 2) >= maxSide && o.outHeight / (s * 2) >= maxSide) {
                s *= 2;
            }
            o.inJustDecodeBounds = false;
            o.inSampleSize = s;
            Bitmap b;
            try (InputStream in = host.getContentResolver().openInputStream(uri(id))) {
                b = BitmapFactory.decodeStream(in, null, o);
            }
            if (b == null) {
                return null;
            }
            // honour the photo's rotation
            int rot = 0;
            try (InputStream in = host.getContentResolver().openInputStream(uri(id))) {
                android.media.ExifInterface ex = new android.media.ExifInterface(in);
                int or = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Throwable ignored) {
                rot = 0;
            }
            if (rot != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private void share() {
        if (viewing < 0 || viewing >= ids.size()) {
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_STREAM, uri(ids.get(viewing)));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, "Share photo");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            host.startActivity(chooser);
        } catch (Exception e) {
            host.toast("Could not share");
        }
    }

    private void close() {
        if (viewer != null) {
            removeView(viewer);
            viewer = null;
            big = null;
            viewing = -1;
        }
    }

    /** Back closes the viewer first. */
    boolean onBackInside() {
        if (viewer != null) {
            close();
            return true;
        }
        return false;
    }
}
