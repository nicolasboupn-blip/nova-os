package app.novaos;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Turns Do Not Disturb on at the start time and off at the end time. It only switches off what it switched on,
 * so a Do Not Disturb you turned on yourself is left alone. Needs Do Not Disturb access once (in Settings).
 */
final class QuietHours {
    private QuietHours() {
    }

    static boolean hasAccess(Context c) {
        try {
            return ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE))
                    .isNotificationPolicyAccessGranted();
        } catch (RuntimeException e) {
            return false;
        }
    }

    static boolean inWindow(int nowMinutes, int start, int end) {
        if (start == end) {
            return false;
        }
        return start < end ? nowMinutes >= start && nowMinutes < end : nowMinutes >= start || nowMinutes < end;
    }

    /** Applies the schedule right now and sets the alarm for the next change. Safe to call any time. */
    static void apply(Context c) {
        if (!Prefs.quiet()) {
            cancel(c);
            // switch off a window we started earlier if the feature was turned off meanwhile
            if (Prefs.getInt("q_active", 0) == 1 && hasAccess(c)) {
                setFilter(c, NotificationManager.INTERRUPTION_FILTER_ALL);
                Prefs.putInt("q_active", 0);
            }
            return;
        }
        Calendar now = Calendar.getInstance();
        int minutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
        boolean inside = inWindow(minutes, Prefs.quietStart(), Prefs.quietEnd());
        if (hasAccess(c)) {
            boolean mine = Prefs.getInt("q_active", 0) == 1;
            if (inside && !mine) {
                setFilter(c, NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                Prefs.putInt("q_active", 1);
            } else if (!inside && mine) {
                setFilter(c, NotificationManager.INTERRUPTION_FILTER_ALL);
                Prefs.putInt("q_active", 0);
            }
        }
        schedule(c, inside ? Prefs.quietEnd() : Prefs.quietStart());
    }

    private static void setFilter(Context c, int filter) {
        try {
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).setInterruptionFilter(filter);
        } catch (RuntimeException ignored) {
            // access was taken away
        }
    }

    private static PendingIntent pending(Context c) {
        return PendingIntent.getBroadcast(c, 4720, new Intent(c, QuietReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void schedule(Context c, int targetMinutes) {
        try {
            Calendar t = Calendar.getInstance();
            t.set(Calendar.HOUR_OF_DAY, targetMinutes / 60);
            t.set(Calendar.MINUTE, targetMinutes % 60);
            t.set(Calendar.SECOND, 5);
            t.set(Calendar.MILLISECOND, 0);
            if (t.getTimeInMillis() <= System.currentTimeMillis()) {
                t.add(Calendar.DAY_OF_YEAR, 1);
            }
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            // inexact on purpose: needs no special permission, may run a few minutes late
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), pending(c));
        } catch (RuntimeException ignored) {
            // the schedule is also checked every time NOVA opens
        }
    }

    static void cancel(Context c) {
        try {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c));
        } catch (RuntimeException ignored) {
            // nothing scheduled
        }
    }

    static String format(int minutes) {
        return String.format(java.util.Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }
}
