package app.novaos;

import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;

/** Fingerprint (or face) unlock through Android's own prompt. Needs Android 9 or newer. */
final class BioAuth {
    private BioAuth() {}

    static boolean available(NovaActivity host) {
        return Build.VERSION.SDK_INT >= 28
                && host.getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
    }

    /** Shows the fingerprint prompt. onOk runs on success. Returns a handle to cancel it, or null if it could not start. */
    static CancellationSignal prompt(NovaActivity host, Runnable onOk) {
        if (Build.VERSION.SDK_INT < 28) {
            return null;
        }
        return start(host, onOk);
    }

    @TargetApi(28)
    private static CancellationSignal start(final NovaActivity host, final Runnable onOk) {
        final CancellationSignal cs = new CancellationSignal();
        try {
            BiometricPrompt p = new BiometricPrompt.Builder(host)
                    .setTitle("NOVA")
                    .setSubtitle("Unlock with your fingerprint")
                    .setNegativeButton("USE PIN", host.getMainExecutor(), (d, w) -> { })
                    .build();
            p.authenticate(cs, host.getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    onOk.run();
                }
            });
        } catch (Exception e) {
            return null;
        }
        return cs;
    }
}
