package app.novaos;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/** Notices a firm double shake of the phone. Listens only while started. */
final class ShakeDetector implements SensorEventListener {
    private final SensorManager sm;
    private final Sensor accel;
    private final Runnable onShake;
    private boolean on;
    private long firstJolt;
    private long lastFire;

    ShakeDetector(Context c, Runnable onShake) {
        this.onShake = onShake;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        accel = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    void start() {
        if (on || accel == null) {
            return;
        }
        on = true;
        sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
    }

    void stop() {
        if (!on) {
            return;
        }
        on = false;
        sm.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float gx = e.values[0] / SensorManager.GRAVITY_EARTH;
        float gy = e.values[1] / SensorManager.GRAVITY_EARTH;
        float gz = e.values[2] / SensorManager.GRAVITY_EARTH;
        float g = (float) Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (g < 2.6f) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastFire < 2500) {
            return;
        }
        if (firstJolt != 0 && now - firstJolt > 120 && now - firstJolt < 900) {
            firstJolt = 0;
            lastFire = now;
            onShake.run();
        } else if (firstJolt == 0 || now - firstJolt >= 900) {
            firstJolt = now;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}
