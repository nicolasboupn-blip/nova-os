package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

import java.util.List;

/** Today's battery level as a line from midnight to midnight, with charging stretches in green. */
final class BatteryGraph extends View {
    private BatteryLog.Day day;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint area = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    BatteryGraph(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2f * d);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(1f);
        label.setTypeface(Theme.MONO);
        label.setTextSize(9f * d);
        label.setColor(Theme.DIM);
        label.setTextAlign(Paint.Align.CENTER);
    }

    void setDay(BatteryLog.Day day) {
        this.day = day;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float bottom = h - 14 * d;
        float top = 4 * d;
        for (int i = 0; i <= 4; i++) {
            float y = top + (bottom - top) * i / 4f;
            c.drawLine(0, y, w, y, grid);
        }
        String[] marks = {"00", "06", "12", "18", "24"};
        for (int i = 0; i < marks.length; i++) {
            float x = i == 0 ? 8 * d : i == 4 ? w - 8 * d : w * i / 4f;
            c.drawText(marks[i], x, h - 2 * d, label);
        }
        if (day == null || day.samples.isEmpty()) {
            label.setColor(Theme.DIM);
            c.drawText("collecting data...", w / 2f, (top + bottom) / 2f, label);
            return;
        }
        List<BatteryLog.Sample> s = day.samples;
        long span = 24L * 3600 * 1000;
        long now = System.currentTimeMillis();

        Path fillPath = new Path();
        float firstX = x(s.get(0).t, day.dayStart, span, w);
        fillPath.moveTo(firstX, bottom);
        for (BatteryLog.Sample p : s) {
            fillPath.lineTo(x(p.t, day.dayStart, span, w), y(p.level, top, bottom));
        }
        BatteryLog.Sample last = s.get(s.size() - 1);
        float nowX = x(now, day.dayStart, span, w);
        fillPath.lineTo(nowX, y(last.level, top, bottom));
        fillPath.lineTo(nowX, bottom);
        fillPath.close();
        area.setShader(new LinearGradient(0, top, 0, bottom,
                (0x55 << 24) | (Theme.ACCENT & 0xFFFFFF), 0x00000000, Shader.TileMode.CLAMP));
        c.drawPath(fillPath, area);

        for (int i = 1; i < s.size(); i++) {
            BatteryLog.Sample a = s.get(i - 1);
            BatteryLog.Sample b = s.get(i);
            line.setColor(b.charging ? 0xFF7CFFB2 : Theme.ACCENT);
            c.drawLine(x(a.t, day.dayStart, span, w), y(a.level, top, bottom),
                    x(b.t, day.dayStart, span, w), y(b.level, top, bottom), line);
        }
        line.setColor(last.charging ? 0xFF7CFFB2 : Theme.ACCENT);
        c.drawLine(x(last.t, day.dayStart, span, w), y(last.level, top, bottom),
                nowX, y(last.level, top, bottom), line);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(Theme.TEXT);
        c.drawCircle(nowX, y(last.level, top, bottom), 3.5f * d, dot);
    }

    private static float x(long t, long start, long span, float w) {
        return Math.max(0f, Math.min(w, (t - start) * w / span));
    }

    private static float y(int level, float top, float bottom) {
        return bottom - (bottom - top) * Math.max(0, Math.min(100, level)) / 100f;
    }
}
