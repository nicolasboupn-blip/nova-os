package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/** This month as a small grid with today circled. */
final class CalendarView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    CalendarView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        paint.setTypeface(Typeface.MONOSPACE);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        Calendar now = Calendar.getInstance();
        Calendar first = (Calendar) now.clone();
        first.set(Calendar.DAY_OF_MONTH, 1);
        int firstDow = Calendar.getInstance().getFirstDayOfWeek();
        int offset = (first.get(Calendar.DAY_OF_WEEK) - firstDow + 7) % 7;
        int days = now.getActualMaximum(Calendar.DAY_OF_MONTH);
        int today = now.get(Calendar.DAY_OF_MONTH);

        float headH = h * 0.14f;
        paint.setColor(Theme.TEXT);
        paint.setTextSize(11 * d);
        paint.setLetterSpacing(0.15f);
        String month = new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(now.getTime()).toUpperCase();
        c.drawText(month, w / 2f, headH * 0.8f, paint);
        paint.setLetterSpacing(0f);

        float cell = w / 7f;
        float rowH = (h - headH) / 7f;
        String[] names = weekdayLetters(firstDow);
        paint.setTextSize(9 * d);
        paint.setColor(Theme.DIM);
        for (int i = 0; i < 7; i++) {
            c.drawText(names[i], cell * (i + 0.5f), headH + rowH * 0.75f, paint);
        }
        for (int day = 1; day <= days; day++) {
            int idx = offset + day - 1;
            int col = idx % 7;
            int row = idx / 7 + 1;
            float cx = cell * (col + 0.5f);
            float cy = headH + rowH * (row + 0.5f);
            if (day == today) {
                paint.setColor(Theme.ACCENT);
                c.drawCircle(cx, cy, Math.min(rowH, cell) * 0.46f, paint);
                paint.setColor(Theme.BG);
            } else {
                paint.setColor(Theme.TEXT);
            }
            paint.setTextSize(10 * d);
            c.drawText(String.valueOf(day), cx, cy + 3.5f * d, paint);
        }
    }

    private static String[] weekdayLetters(int firstDow) {
        String[] out = new String[7];
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_WEEK, firstDow);
        SimpleDateFormat f = new SimpleDateFormat("EEEEE", Locale.getDefault());
        for (int i = 0; i < 7; i++) {
            out[i] = f.format(c.getTime()).toUpperCase();
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return out;
    }
}
