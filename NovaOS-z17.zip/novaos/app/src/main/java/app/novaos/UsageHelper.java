package app.novaos;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Build;
import android.os.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** How long each app was on screen today. Needs "usage access", which you allow once in Android settings. */
final class UsageHelper {
    static final class Row {
        final String pkg;
        final long ms;

        Row(String pkg, long ms) {
            this.pkg = pkg;
            this.ms = ms;
        }
    }

    static final class Result {
        List<Row> apps = new ArrayList<>();
        long totalMs;
        long screenOnMs;
    }

    private UsageHelper() {}

    @SuppressWarnings("deprecation")
    static boolean hasAccess(Context c) {
        try {
            AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = Build.VERSION.SDK_INT >= 29
                    ? ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName())
                    : ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    /** Adds up the time each app was in front, from midnight until now. Do not call on the main thread. */
    static Result today(Context c) {
        Result r = new Result();
        UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) {
            return r;
        }
        long start = BatteryLog.midnight();
        long now = System.currentTimeMillis();
        UsageEvents events = usm.queryEvents(start, now);
        UsageEvents.Event e = new UsageEvents.Event();
        Map<String, Long> total = new HashMap<>();
        Map<String, Long> opened = new HashMap<>();
        long screenOn = -1;
        while (events.hasNextEvent()) {
            events.getNextEvent(e);
            String p = e.getPackageName();
            int type = e.getEventType();
            long ts = e.getTimeStamp();
            if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
                opened.put(p, ts);
            } else if (type == UsageEvents.Event.ACTIVITY_PAUSED) {
                Long from = opened.remove(p);
                if (from != null && ts > from) {
                    Long old = total.get(p);
                    total.put(p, (old == null ? 0L : old) + (ts - from));
                }
            } else if (type == UsageEvents.Event.SCREEN_INTERACTIVE) {
                screenOn = ts;
            } else if (type == UsageEvents.Event.SCREEN_NON_INTERACTIVE) {
                if (screenOn >= 0 && ts > screenOn) {
                    r.screenOnMs += ts - screenOn;
                }
                screenOn = -1;
            }
        }
        // whatever is still open right now counts up to this moment
        for (Map.Entry<String, Long> en : opened.entrySet()) {
            if (now > en.getValue()) {
                Long old = total.get(en.getKey());
                total.put(en.getKey(), (old == null ? 0L : old) + (now - en.getValue()));
            }
        }
        if (screenOn >= 0) {
            r.screenOnMs += now - screenOn;
        }
        for (Map.Entry<String, Long> en : total.entrySet()) {
            if (en.getKey().equals(c.getPackageName()) || en.getValue() < 30_000L) {
                continue; // NOVA itself and blips under half a minute
            }
            r.apps.add(new Row(en.getKey(), en.getValue()));
            r.totalMs += en.getValue();
        }
        Collections.sort(r.apps, (a, b) -> Long.compare(b.ms, a.ms));
        return r;
    }

    static String duration(long ms) {
        long min = ms / 60000L;
        if (min >= 60) {
            return (min / 60) + "h " + (min % 60) + "m";
        }
        return Math.max(1, min) + "m";
    }
}
