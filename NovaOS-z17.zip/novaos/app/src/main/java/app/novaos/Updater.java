package app.novaos;

import android.net.Uri;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * One-tap updates. Looks at the newest NOVA release on GitHub, downloads its APK
 * and hands it to Android's installer. Android still asks you to confirm the install.
 */
final class Updater {
    static final String REPO = "nicolasboupn-blip/nova-os";
    private static final String API = "https://api.github.com/repos/" + REPO + "/releases/latest";

    private Updater() {}

    /** Checks for a newer build. Shows the result in status. Runs off the main thread. */
    static void check(final NovaActivity host, final TextView status) {
        status.setText("checking...");
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(15000);
                c.setReadTimeout(15000);
                int code = c.getResponseCode();
                if (code != 200) {
                    throw new Exception("GitHub answered " + code);
                }
                JSONObject rel = new JSONObject(readAll(c.getInputStream()));
                String tag = rel.optString("tag_name", "");
                final long latest = buildOf(tag);
                final int current = currentBuild(host);
                if (latest <= current) {
                    post(host, status, "up to date (build " + current + ")");
                    return;
                }

                String url = null;
                JSONArray assets = rel.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length() && url == null; i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.optString("name").endsWith(".apk")) {
                            url = a.getString("browser_download_url");
                        }
                    }
                }
                if (url == null) {
                    throw new Exception("no APK in " + tag);
                }

                post(host, status, "downloading build " + latest + "...");
                File dir = new File(host.getCacheDir(), "updates");
                dir.mkdirs();
                File apk = new File(dir, "nova-update.apk");
                download(url, apk);

                final Uri uri = FileProvider.getUriForFile(
                        host, host.getPackageName() + ".fileprovider", apk);
                host.runOnUiThread(() -> {
                    status.setText("installing build " + latest + "...");
                    host.installApk(uri);
                });
            } catch (Exception e) {
                post(host, status, "update failed: " + e.getMessage());
            }
        }).start();
    }

    private static void post(NovaActivity host, TextView status, String text) {
        host.runOnUiThread(() -> status.setText(text));
    }

    /** "nova-12" -> 12. Returns 0 if the tag has no number. */
    static long buildOf(String tag) {
        String digits = tag.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) {
            return 0L;
        }
        try {
            return Long.parseLong(digits);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    private static int currentBuild(NovaActivity host) {
        try {
            return host.getPackageManager().getPackageInfo(host.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream src = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = src.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        }
    }

    private static void download(String url, File target) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
    }
}
