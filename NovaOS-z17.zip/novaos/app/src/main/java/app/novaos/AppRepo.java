package app.novaos;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Finds, searches and launches the apps installed on the phone. */
final class AppRepo {
    private final Context ctx;
    private final PackageManager pm;
    private boolean dirty = false;
    List<AppEntry> all = new ArrayList<>();

    AppRepo(Context ctx) {
        this.ctx = ctx;
        this.pm = ctx.getPackageManager();
        reload();
    }

    void markDirty() {
        dirty = true;
    }

    void ensureFresh() {
        if (dirty) {
            reload();
        }
    }

    void reload() {
        dirty = false;
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        List<AppEntry> out = new ArrayList<>();
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) {
                continue;
            }
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(ctx.getPackageName())) {
                continue; // NOVA itself is not listed
            }
            out.add(new AppEntry(r.loadLabel(pm).toString(), pkg, r.activityInfo.name, r.loadIcon(pm)));
        }
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        all = out;
    }

    AppEntry find(String pkg) {
        for (AppEntry e : all) {
            if (e.pkg.equals(pkg)) {
                return e;
            }
        }
        return null;
    }

    /** Apps whose name contains the query, names that start with it first. */
    List<AppEntry> search(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            return new ArrayList<>(all);
        }
        List<AppEntry> starts = new ArrayList<>();
        List<AppEntry> contains = new ArrayList<>();
        for (AppEntry e : all) {
            String l = e.label.toLowerCase(Locale.ROOT);
            if (l.startsWith(q)) {
                starts.add(e);
            } else if (l.contains(q)) {
                contains.add(e);
            }
        }
        starts.addAll(contains);
        return starts;
    }

    boolean launch(AppEntry e) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setClassName(e.pkg, e.cls);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            ctx.startActivity(i);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    /** First-run favorites: the phone's own dialer, messages, camera, browser and settings. */
    List<String> defaultPackages() {
        List<Intent> probes = new ArrayList<>();
        probes.add(new Intent(Intent.ACTION_DIAL));
        probes.add(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")));
        probes.add(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
        probes.add(new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")));
        probes.add(new Intent(Settings.ACTION_SETTINGS));
        List<String> out = new ArrayList<>();
        for (Intent i : probes) {
            ResolveInfo ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri != null && ri.activityInfo != null) {
                String p = ri.activityInfo.packageName;
                if (find(p) != null && !out.contains(p)) {
                    out.add(p);
                }
            }
        }
        return out;
    }
}
