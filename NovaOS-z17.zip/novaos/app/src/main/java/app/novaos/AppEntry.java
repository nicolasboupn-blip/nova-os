package app.novaos;

import android.graphics.drawable.Drawable;

/** One launchable app on the phone. */
final class AppEntry {
    final String label;
    final String pkg;
    final String cls;
    final Drawable icon;

    AppEntry(String label, String pkg, String cls, Drawable icon) {
        this.label = label;
        this.pkg = pkg;
        this.cls = cls;
        this.icon = icon;
    }
}
