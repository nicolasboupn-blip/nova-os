package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pick a time with the + buttons, press START. Rings in the background through TimerReceiver. */
final class TimerPage extends LinearLayout {
    private static long setMs;
    private static long leftMs;
    private static long endAt;
    private static boolean running;
    private static boolean done;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView time;
    private final TextView startBtn;
    private final TextView[] presets = new TextView[4];

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown() || running) {
                refresh();
            }
            handler.postDelayed(this, isShown() ? 200 : 600);
        }
    };

    TimerPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);

        time = new TextView(host);
        time.setTypeface(Theme.MONO);
        time.setTextSize(34f);
        time.setTextColor(Theme.TEXT);
        time.setGravity(Gravity.CENTER);
        time.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        addView(time, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout add = new LinearLayout(host);
        add.setGravity(Gravity.CENTER);
        final long[] steps = {60_000L, 5 * 60_000L, 10 * 60_000L, 0L};
        String[] names = {"+1m", "+5m", "+10m", "CLEAR"};
        for (int i = 0; i < 4; i++) {
            final long step = steps[i];
            presets[i] = pill(names[i]);
            presets[i].setOnClickListener(v -> add(step));
            LayoutParams lp = new LayoutParams(0, Theme.dp(host, 36), 1f);
            lp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
            add.addView(presets[i], lp);
        }
        LayoutParams ap = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        ap.topMargin = Theme.dp(host, 6);
        addView(add, ap);

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        startBtn = pill("START");
        startBtn.setOnClickListener(v -> toggle());
        TextView reset = pill("RESET");
        reset.setOnClickListener(v -> reset());
        for (TextView b : new TextView[] {startBtn, reset}) {
            LayoutParams lp = new LayoutParams(0, Theme.dp(host, 38), 1f);
            lp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
            row.addView(b, lp);
        }
        LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        rp.topMargin = Theme.dp(host, 8);
        addView(row, rp);
        refresh();
    }

    private TextView pill(String s) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(11f);
        t.setLetterSpacing(0.1f);
        t.setTextColor(Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private void add(long step) {
        if (running) {
            return;
        }
        if (done) {
            done = false;
            setMs = 0;
            leftMs = 0;
        }
        if (step == 0) {
            setMs = 0;
            leftMs = 0;
        } else {
            setMs += step;
            leftMs += step;
        }
        refresh();
    }

    private void toggle() {
        if (running) {
            leftMs = Math.max(0, endAt - SystemClock.elapsedRealtime());
            running = false;
            TimerReceiver.cancel(host);
        } else {
            if (done) {
                done = false;
                leftMs = setMs;
            }
            if (leftMs <= 0) {
                return;
            }
            endAt = SystemClock.elapsedRealtime() + leftMs;
            running = true;
            TimerReceiver.schedule(host, leftMs);
        }
        refresh();
    }

    private void reset() {
        TimerReceiver.cancel(host);
        running = false;
        done = false;
        leftMs = setMs;
        refresh();
    }

    private void refresh() {
        if (running && SystemClock.elapsedRealtime() >= endAt) {
            running = false;
            done = true;
            leftMs = 0;
            Badges.unlock(host, "timer");
            if (isShown()) {
                host.buzz(250);
                host.confetti(host.root.getWidth() / 2f, host.root.getHeight() * 0.45f);
            }
        }
        long left = running ? Math.max(0, endAt - SystemClock.elapsedRealtime()) : leftMs;
        if (done) {
            time.setText(System.currentTimeMillis() / 500 % 2 == 0 ? "TIME'S UP" : "         ");
            time.setTextSize(26f);
        } else {
            time.setText(TimeFormat.clock(left + (running ? 999 : 0)));
            time.setTextSize(34f);
        }
        startBtn.setText(running ? "PAUSE" : (leftMs > 0 && leftMs < setMs) ? "RESUME" : "START");
        for (TextView p : presets) {
            p.setAlpha(running ? 0.3f : 1f);
        }
        startBtn.setAlpha(done || running || leftMs > 0 ? 1f : 0.35f);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
