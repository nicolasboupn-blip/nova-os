package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The games page: six boxes. Press one and it grows from where it sits until it fills the whole screen
 * as that game. The X (or the back button) shrinks it back into its box.
 */
final class MiniGames extends LinearLayout {
    private static final String[] NAMES = {"SNAKE", "2048", "MEMORY", "REACTION", "HI / LO", "WHACK"};
    private static final String[] ICONS = {"🐍", "🔢", "🧠", "⚡", "🃏", "🎯"};
    private static final String[] KEYS = {"snake", "2048", "memory", "react", "", "whack"};
    private static final String[] UNITS = {"", "", " moves", " ms", "", ""};

    private final NovaActivity host;
    private final TextView[] bests = new TextView[6];

    MiniGames(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        for (int row = 0; row < 2; row++) {
            LinearLayout line = new LinearLayout(host);
            for (int col = 0; col < 3; col++) {
                final int idx = row * 3 + col;
                LinearLayout box = new LinearLayout(host);
                box.setOrientation(VERTICAL);
                box.setGravity(Gravity.CENTER);
                box.setBackground(Theme.rounded(0x26FFFFFF, 14f, host));
                box.setClickable(true);
                Theme.ripple(box);
                TextView icon = new TextView(host);
                icon.setText(ICONS[idx]);
                icon.setTextSize(24f);
                icon.setGravity(Gravity.CENTER);
                box.addView(icon);
                TextView name = new TextView(host);
                name.setText(NAMES[idx]);
                name.setTypeface(Theme.MONO);
                name.setTextSize(9f);
                name.setLetterSpacing(0.1f);
                name.setTextColor(Theme.TEXT);
                name.setGravity(Gravity.CENTER);
                box.addView(name);
                bests[idx] = new TextView(host);
                bests[idx].setTypeface(Theme.MONO);
                bests[idx].setTextSize(8f);
                bests[idx].setTextColor(Theme.DIM);
                bests[idx].setGravity(Gravity.CENTER);
                box.addView(bests[idx]);
                box.setOnClickListener(v -> open(idx, v));
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Theme.dp(host, 74), 1f);
                bp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                line.addView(box, bp);
            }
            addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        refreshBests();
    }

    void refreshBests() {
        for (int i = 0; i < 6; i++) {
            if (KEYS[i].isEmpty()) {
                bests[i].setText("coins " + Prefs.getInt("slot_coins", 100));
                continue;
            }
            int b = Game.best(KEYS[i], 0);
            bests[i].setText(b > 0 ? "best " + b + UNITS[i] : "play");
        }
    }

    private Game create(int idx) {
        switch (idx) {
            case 0:
                return new GameSnake(host);
            case 1:
                return new Game2048(host);
            case 2:
                return new GameMemory(host);
            case 3:
                return new GameReaction(host);
            case 4:
                return new GameHiLo(host);
            default:
                return new GameWhack(host);
        }
    }

    private void open(int idx, final View box) {
        final GameFrame frame = new GameFrame(host, create(idx), box, this::refreshBests);
        host.showOverlay(frame);
        frame.grow();
    }
}
