package app.novaos;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lock screen wallpaper that types text forever: NOVA's own source, or your own words from Settings. */
final class CodeWallpaper extends TextView {
    private static final int MAX_LINES = 60;
    private static final int STR = Color.parseColor("#A6E3A1");
    private static final int COM = Color.parseColor("#5C5478");

    private static final Pattern TOKEN = Pattern.compile(
            "(//[^\\n]*)|(\"[^\"\\n]*\")|\\b(public|private|static|final|class|void|return|new|if|else|for"
            + "|int|boolean|String|import|package|null|true|false|extends|List)\\b");

    private static final String[] SOURCE = {
        "package app.novaos;",
        "",
        "final class Theme {",
        "    static final String OS_NAME = \"NOVA\";",
        "    static int ACCENT = 0xFFB39DFF;",
        "",
        "    static int dp(Context c, float v) {",
        "        return Math.round(v * c.getResources().getDisplayMetrics().density);",
        "    }",
        "}",
        "",
        "// every screen is a plain View, so the whole OS stays small",
        "public class NovaActivity extends Activity {",
        "    void unlock() {",
        "        showBoot(true);  // quick startup, then home",
        "    }",
        "",
        "    List<AppEntry> search(String query) {",
        "        String q = query.trim().toLowerCase();",
        "        return new ArrayList<>(all);",
        "    }",
        "}",
        "",
    };

    private final String[] src;
    private final List<CharSequence> done = new ArrayList<>();
    private final StringBuilder partial = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int line = 0;
    private int col = 0;
    private int blink = 0;
    private final boolean typing;

    private final Runnable typer = new Runnable() {
        @Override
        public void run() {
            typeOne();
            handler.postDelayed(this, 40);
        }
    };

    CodeWallpaper(Context c) {
        this(c, Prefs.codeWall());
    }

    /** typing = whether the text types itself; the lock screen and home screen each set their own. */
    CodeWallpaper(Context c, boolean typing) {
        super(c);
        this.typing = typing;
        String custom = Prefs.wallText().trim();
        if (custom.isEmpty()) {
            src = SOURCE;
        } else {
            String[] own = custom.split("\n");
            src = new String[own.length + 1];
            System.arraycopy(own, 0, src, 0, own.length);
            src[own.length] = "";
        }
        setTypeface(Theme.MONO);
        setTextSize(11f);
        setTextColor(Theme.DIM);
        setLineSpacing(0f, 1.35f);
        setGravity(Gravity.TOP | Gravity.START);
        setIncludeFontPadding(false);
        setClickable(false);
        setFocusable(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (typing) {
            handler.post(typer);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(typer);
        super.onDetachedFromWindow();
    }

    private void typeOne() {
        String s = src[line % src.length];
        if (col < s.length()) {
            partial.append(s.charAt(col++));
        } else {
            done.add(highlight(partial.toString()));
            if (done.size() > MAX_LINES) {
                done.remove(0);
            }
            partial.setLength(0);
            col = 0;
            line++;
        }
        redraw();
    }

    private void redraw() {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        for (CharSequence l : done) {
            sb.append(l);
            sb.append('\n');
        }
        sb.append(highlight(partial.toString()));
        blink++;
        if ((blink / 18) % 2 == 0) {
            int at = sb.length();
            sb.append('\u2588');
            sb.setSpan(new ForegroundColorSpan(Theme.ACCENT), at, at + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        setText(sb);
        // keep the newest line at the bottom: push the text up by its overflow
        post(() -> {
            Layout l = getLayout();
            if (l != null) {
                int over = l.getHeight() - getHeight();
                setTranslationY(over > 0 ? -over : 0);
            }
        });
    }

    private static CharSequence highlight(String s) {
        SpannableStringBuilder sb = new SpannableStringBuilder(s);
        Matcher m = TOKEN.matcher(s);
        while (m.find()) {
            int color = m.group(1) != null ? COM : m.group(2) != null ? STR : Theme.ACCENT;
            sb.setSpan(new ForegroundColorSpan(color), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sb;
    }
}
