package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;

import java.util.Random;

/** A burst of confetti that pops out of a point, falls with gravity and removes itself. */
final class ConfettiView extends View {
    private static final int COUNT = 110;
    private static final long LIFE = 3400L;
    private static final int[] COLORS = {
        0xFFFF5C8A, 0xFFFFD166, 0xFF7CFFB2, 0xFF6EC8FF, 0xFFB39DFF, 0xFFFFFFFF, 0xFFFF9F43
    };

    private final float[] x = new float[COUNT];
    private final float[] y = new float[COUNT];
    private final float[] vx = new float[COUNT];
    private final float[] vy = new float[COUNT];
    private final float[] rot = new float[COUNT];
    private final float[] spin = new float[COUNT];
    private final float[] w = new float[COUNT];
    private final int[] color = new int[COUNT];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private long last;
    private final long born = SystemClock.uptimeMillis();

    ConfettiView(Context c, float originX, float originY) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        setClickable(false);
        Random r = new Random();
        for (int i = 0; i < COUNT; i++) {
            x[i] = originX + (r.nextFloat() - 0.5f) * 40 * density;
            y[i] = originY;
            // mostly upward, fanned out wide
            double ang = Math.toRadians(-90 + (r.nextFloat() - 0.5f) * 150);
            float speed = (380 + r.nextFloat() * 900) * density;
            vx[i] = (float) Math.cos(ang) * speed;
            vy[i] = (float) Math.sin(ang) * speed;
            rot[i] = r.nextFloat() * 360f;
            spin[i] = (r.nextFloat() - 0.5f) * 720f;
            w[i] = (4 + r.nextFloat() * 6) * density;
            color[i] = COLORS[r.nextInt(COLORS.length)];
        }
        last = born;
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = Math.min(0.05f, (now - last) / 1000f);
        last = now;
        long age = now - born;
        float fade = age > LIFE - 700 ? Math.max(0f, (LIFE - age) / 700f) : 1f;
        for (int i = 0; i < COUNT; i++) {
            vy[i] += 1900f * density * dt;       // gravity
            vx[i] *= 1f - 1.4f * dt;            // air drag
            vy[i] *= 1f - 0.5f * dt;
            x[i] += vx[i] * dt;
            y[i] += vy[i] * dt;
            rot[i] += spin[i] * dt;
            paint.setColor(color[i]);
            paint.setAlpha((int) (255 * fade));
            c.save();
            c.translate(x[i], y[i]);
            c.rotate(rot[i]);
            c.drawRect(-w[i] / 2f, -w[i] * 0.3f, w[i] / 2f, w[i] * 0.3f, paint);
            c.restore();
        }
        if (age < LIFE) {
            postInvalidateOnAnimation();
        } else if (getParent() instanceof ViewGroup) {
            ((ViewGroup) getParent()).removeView(this);
        }
    }
}
