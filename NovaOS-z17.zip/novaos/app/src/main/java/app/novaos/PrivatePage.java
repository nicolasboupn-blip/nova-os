package app.novaos;

import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Private search with DuckDuckGo. Nothing is saved: no history, no recent searches, and the window wipes
 * cookies and site data when it closes. For real Tor there is a shortcut to Tor Browser or Orbot if installed.
 */
final class PrivatePage extends LinearLayout {
    private static final String[] TOR_APPS = {
        "org.torproject.torbrowser", "org.torproject.torbrowser_alpha", "org.torproject.android"
    };

    private final NovaActivity host;
    private final EditText input;

    PrivatePage(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(host);
        input.setHint("search DuckDuckGo or type a site");
        input.setHintTextColor(Theme.DIM);
        input.setTextColor(Theme.TEXT);
        input.setTextSize(14f);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        input.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        input.setPadding(Theme.dp(host, 12), Theme.dp(host, 8), Theme.dp(host, 12), Theme.dp(host, 8));
        input.setOnEditorActionListener((v, id, e) -> {
            go(input.getText().toString());
            return true;
        });
        row.addView(input, new LayoutParams(0, Theme.dp(host, 42), 1f));
        TextView play = pill("→");
        play.setTextSize(18f);
        play.setOnClickListener(v -> go(input.getText().toString()));
        LayoutParams pp = new LayoutParams(Theme.dp(host, 52), Theme.dp(host, 42));
        pp.leftMargin = Theme.dp(host, 6);
        row.addView(play, pp);
        addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout buttons = new LinearLayout(host);
        TextView ddg = pill("DUCKDUCKGO");
        ddg.setOnClickListener(v -> go(""));
        TextView tor = pill("TOR BROWSER");
        tor.setOnClickListener(v -> openTor());
        LayoutParams bl = new LayoutParams(0, Theme.dp(host, 38), 1f);
        bl.setMargins(0, 0, Theme.dp(host, 3), 0);
        LayoutParams br = new LayoutParams(0, Theme.dp(host, 38), 1f);
        br.setMargins(Theme.dp(host, 3), 0, 0, 0);
        buttons.addView(ddg, bl);
        buttons.addView(tor, br);
        LayoutParams bp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        bp.topMargin = Theme.dp(host, 8);
        addView(buttons, bp);

        TextView note = new TextView(host);
        note.setText("No history. Cookies and site data are wiped\nwhen you close it. This is not Tor.");
        note.setTypeface(Theme.MONO);
        note.setTextSize(10f);
        note.setTextColor(Theme.DIM);
        note.setGravity(Gravity.CENTER);
        LayoutParams np = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        np.topMargin = Theme.dp(host, 10);
        addView(note, np);
    }

    private TextView pill(String s) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(11f);
        t.setLetterSpacing(0.1f);
        t.setTextColor(Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private void go(String q) {
        leave();
        host.showOverlay(new PrivateBrowserView(host, q));
    }

    private void openTor() {
        host.repo.ensureFresh();
        for (String pkg : TOR_APPS) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                host.launch(e);
                return;
            }
        }
        host.toast("Tor Browser is not installed. Get it from torproject.org");
    }

    /** Hides the keyboard, also when the page is left. */
    void leave() {
        input.clearFocus();
        InputMethodManager imm = (InputMethodManager) host.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        }
    }
}
