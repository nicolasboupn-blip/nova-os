package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.util.Random;

/** Falling green code, full screen. Tap anywhere (or press back) to leave. */
final class MatrixRain extends View {
    private static final String GLYPHS =
            "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃ"
            + "ﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖ"
            + "ﾗﾘﾙﾚﾛﾜﾝ0123456789:.=*+-<>";
    private static final int TRAIL = 20;
    private static final long LIFETIME = 25_000L;

    private final NovaActivity host;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final float cell;
    private float[] head;
    private float[] speed;
    private int cols;
    private int rows;
    private long last;
    private long born;
    private int frame;

    MatrixRain(NovaActivity host) {
        super(host);
        this.host = host;
        float d = host.getResources().getDisplayMetrics().density;
        cell = 15 * d;
        paint.setTypeface(Typeface.MONOSPACE);
        paint.setTextSize(cell * 0.95f);
        paint.setTextAlign(Paint.Align.CENTER);
        setBackgroundColor(0xFF000000);
        setClickable(true);
        setOnClickListener(v -> host.hideOverlay());
        born = System.currentTimeMillis();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cols = Math.max(1, (int) (w / cell));
        rows = Math.max(1, (int) (h / cell));
        head = new float[cols];
        speed = new float[cols];
        for (int i = 0; i < cols; i++) {
            head[i] = -rnd.nextFloat() * rows;
            speed[i] = 7f + rnd.nextFloat() * 14f;
        }
        last = System.nanoTime();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (head == null) {
            return;
        }
        long now = System.nanoTime();
        float dt = Math.min(0.06f, (now - last) / 1e9f);
        last = now;
        frame++;
        float x0 = (getWidth() - cols * cell) / 2f + cell / 2f;
        for (int col = 0; col < cols; col++) {
            head[col] += speed[col] * dt;
            if (head[col] - TRAIL > rows) {
                head[col] = -rnd.nextFloat() * 10f;
                speed[col] = 7f + rnd.nextFloat() * 14f;
            }
            int h = (int) head[col];
            for (int t = 0; t < TRAIL; t++) {
                int row = h - t;
                if (row < 0 || row >= rows) {
                    continue;
                }
                // each cell keeps its glyph for a few frames, then flickers to another
                int seed = col * 7919 + row * 104729 + (frame / (t == 0 ? 2 : 9)) * 31;
                char ch = GLYPHS.charAt(Math.abs(seed % GLYPHS.length()));
                float k = 1f - t / (float) TRAIL;
                if (t == 0) {
                    paint.setColor(0xFFD8FFE4);
                } else {
                    paint.setColor(((int) (255 * k * k) << 24) | 0x0039FF88);
                }
                c.drawText(String.valueOf(ch), x0 + col * cell, (row + 1) * cell - cell * 0.2f, paint);
            }
        }
        if (System.currentTimeMillis() - born > LIFETIME) {
            host.hideOverlay();
            return;
        }
        postInvalidateDelayed(33);
    }
}
