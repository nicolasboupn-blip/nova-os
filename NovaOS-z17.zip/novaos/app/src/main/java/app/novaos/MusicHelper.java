package app.novaos;

import android.content.ComponentName;
import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;

import java.util.List;

/** Finds the music player that is running and controls it. Needs notification access (Settings). */
final class MusicHelper {
    private MusicHelper() {}

    /** The player that is playing right now, or the first one if none is. Null without access. */
    static MediaController controller(Context c) {
        if (!NovaNotificationService.hasAccess(c)) {
            return null;
        }
        try {
            MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (m == null) {
                return null;
            }
            List<MediaController> list = m.getActiveSessions(new ComponentName(c, NovaNotificationService.class));
            MediaController first = null;
            for (MediaController mc : list) {
                if (isPlaying(mc)) {
                    return mc;
                }
                if (first == null) {
                    first = mc;
                }
            }
            return first;
        } catch (SecurityException e) {
            return null;
        }
    }

    static boolean isPlaying(MediaController c) {
        PlaybackState s = c == null ? null : c.getPlaybackState();
        return s != null && s.getState() == PlaybackState.STATE_PLAYING;
    }

    /** True while a player is playing or paused (not stopped), so a finished app does not linger on the lock screen. */
    static boolean active(MediaController c) {
        PlaybackState s = c == null ? null : c.getPlaybackState();
        if (s == null) {
            return false;
        }
        int st = s.getState();
        return st != PlaybackState.STATE_NONE && st != PlaybackState.STATE_STOPPED;
    }

    static String title(MediaController c) {
        MediaMetadata md = c.getMetadata();
        String t = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        return t == null || t.isEmpty() ? c.getPackageName() : t;
    }

    static String artist(MediaController c) {
        MediaMetadata md = c.getMetadata();
        String a = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        return a == null ? "" : a;
    }

    static void toggle(Context c) {
        MediaController mc = controller(c);
        if (mc != null) {
            if (isPlaying(mc)) {
                mc.getTransportControls().pause();
            } else {
                mc.getTransportControls().play();
            }
        }
    }

    static void next(Context c) {
        MediaController mc = controller(c);
        if (mc != null) {
            mc.getTransportControls().skipToNext();
        }
    }

    static void previous(Context c) {
        MediaController mc = controller(c);
        if (mc != null) {
            mc.getTransportControls().skipToPrevious();
        }
    }
}
