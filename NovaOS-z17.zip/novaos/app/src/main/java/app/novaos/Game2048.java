package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

/** Swipe to slide the tiles, equal tiles merge. Make a 2048 (or at least a 512). */
final class Game2048 extends Game {
    Game2048(NovaActivity host) {
        super(host);
        addView(new Board(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    @Override
    String title() {
        return "2048";
    }

    private final class Board extends View {
        private final int[][] g = new int[4][4];
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Random rnd = new Random();
        private int score;
        private boolean over;
        private float downX, downY;

        Board(Context c) {
            super(c);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextAlign(Paint.Align.CENTER);
            reset();
        }

        private void reset() {
            for (int[] row : g) {
                java.util.Arrays.fill(row, 0);
            }
            score = 0;
            over = false;
            spawn();
            spawn();
            invalidate();
        }

        private void spawn() {
            int empty = 0;
            for (int[] row : g) {
                for (int v : row) {
                    if (v == 0) {
                        empty++;
                    }
                }
            }
            if (empty == 0) {
                return;
            }
            int pick = rnd.nextInt(empty);
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 4; x++) {
                    if (g[y][x] == 0 && pick-- == 0) {
                        g[y][x] = rnd.nextInt(10) == 0 ? 4 : 2;
                        return;
                    }
                }
            }
        }

        /** dir: 0 left, 1 right, 2 up, 3 down. Returns true if anything moved. */
        private boolean slide(int dir) {
            boolean moved = false;
            for (int i = 0; i < 4; i++) {
                int[] line = new int[4];
                for (int j = 0; j < 4; j++) {
                    line[j] = get(dir, i, j);
                }
                int[] out = new int[4];
                int n = 0;
                for (int j = 0; j < 4; j++) {
                    if (line[j] != 0) {
                        if (n > 0 && out[n - 1] == line[j] && out[n - 1] > 0) {
                            out[n - 1] *= -2; // negative marks "already merged"
                            score += -out[n - 1];
                        } else {
                            out[n++] = line[j];
                        }
                    }
                }
                for (int j = 0; j < 4; j++) {
                    out[j] = Math.abs(out[j]);
                    if (out[j] != line[j]) {
                        moved = true;
                    }
                    put(dir, i, j, out[j]);
                }
            }
            return moved;
        }

        private int get(int dir, int i, int j) {
            switch (dir) {
                case 0:
                    return g[i][j];
                case 1:
                    return g[i][3 - j];
                case 2:
                    return g[j][i];
                default:
                    return g[3 - j][i];
            }
        }

        private void put(int dir, int i, int j, int v) {
            switch (dir) {
                case 0:
                    g[i][j] = v;
                    break;
                case 1:
                    g[i][3 - j] = v;
                    break;
                case 2:
                    g[j][i] = v;
                    break;
                default:
                    g[3 - j][i] = v;
                    break;
            }
        }

        private boolean canMove() {
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 4; x++) {
                    if (g[y][x] == 0) {
                        return true;
                    }
                    if (x < 3 && g[y][x] == g[y][x + 1]) {
                        return true;
                    }
                    if (y < 3 && g[y][x] == g[y + 1][x]) {
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    return true;
                case MotionEvent.ACTION_UP: {
                    float mx = e.getX() - downX;
                    float my = e.getY() - downY;
                    if (over) {
                        reset();
                        return true;
                    }
                    if (Math.max(Math.abs(mx), Math.abs(my)) < dp(30)) {
                        return true;
                    }
                    int dir = Math.abs(mx) > Math.abs(my) ? (mx < 0 ? 0 : 1) : (my < 0 ? 2 : 3);
                    if (slide(dir)) {
                        spawn();
                        host.buzz(8);
                        int top = 0;
                        for (int[] row : g) {
                            for (int v : row) {
                                top = Math.max(top, v);
                            }
                        }
                        if (top >= 512) {
                            Badges.unlock(host, "g2048");
                        }
                        if (score > best("2048", 0)) {
                            saveBest("2048", score);
                        }
                        if (!canMove()) {
                            over = true;
                        }
                        invalidate();
                    }
                    return true;
                }
                default:
                    return true;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.TEXT);
            p.setTextSize(22 * d);
            c.drawText("SCORE " + score, w / 2f, dp(46), p);
            p.setColor(Theme.DIM);
            p.setTextSize(11 * d);
            c.drawText("BEST " + Math.max(best("2048", 0), score), w / 2f, dp(62), p);

            float size = Math.min(w - dp(32), getHeight() - dp(200));
            float left = (w - size) / 2f;
            float top = dp(84);
            r.set(left, top, left + size, top + size);
            p.setColor(0xFF140E26);
            c.drawRoundRect(r, dp(14), dp(14), p);
            float gap = dp(8);
            float cell = (size - gap * 5) / 4f;
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 4; x++) {
                    float l = left + gap + x * (cell + gap);
                    float t = top + gap + y * (cell + gap);
                    r.set(l, t, l + cell, t + cell);
                    int v = g[y][x];
                    if (v == 0) {
                        p.setColor(0xFF1E1638);
                        c.drawRoundRect(r, dp(10), dp(10), p);
                        continue;
                    }
                    int level = 31 - Integer.numberOfLeadingZeros(v);
                    float k = Math.min(1f, (level - 1) / 10f);
                    p.setColor(blend(0xFF2E2352, Theme.ACCENT, k));
                    c.drawRoundRect(r, dp(10), dp(10), p);
                    p.setColor(level >= 5 ? Theme.BG : Theme.TEXT);
                    String s = String.valueOf(v);
                    p.setTextSize((s.length() <= 2 ? 26 : s.length() == 3 ? 21 : 16) * d);
                    c.drawText(s, r.centerX(), r.centerY() + 9 * d, p);
                }
            }
            if (over) {
                p.setColor(0xCC0C0917);
                r.set(left, top, left + size, top + size);
                c.drawRoundRect(r, dp(14), dp(14), p);
                p.setColor(Theme.TEXT);
                p.setTextSize(24 * d);
                c.drawText("NO MOVES", w / 2f, top + size / 2f, p);
                p.setColor(Theme.ACCENT);
                p.setTextSize(12 * d);
                c.drawText("tap to play again", w / 2f, top + size / 2f + dp(28), p);
            }
        }

        private int blend(int a, int b, float k) {
            return Color.rgb(
                    (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * k),
                    (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * k),
                    (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k));
        }
    }
}
