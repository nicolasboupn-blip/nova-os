package app.novaos;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Rings when the NOVA timer runs out, even if NOVA is not on screen. */
public class TimerReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "nova_timer";

    private static PendingIntent pending(Context c) {
        Intent i = new Intent(c, TimerReceiver.class);
        return PendingIntent.getBroadcast(c, 4711, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent show = PendingIntent.getActivity(c, 4712, new Intent(c, NovaActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            // setAlarmClock needs no special permission and fires on time, even in battery saving
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis() + delayMs, show), pending(c));
        } catch (RuntimeException ignored) {
            // the in-app timer still works, only the background ring is lost
        }
    }

    static void cancel(Context c) {
        try {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c));
        } catch (RuntimeException ignored) {
            // nothing scheduled
        }
    }

    @Override
    public void onReceive(final Context c, Intent intent) {
        final PendingResult result = goAsync();
        Ringtone ring = null;
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) {
                uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }
            ring = RingtoneManager.getRingtone(c, uri);
            if (ring != null) {
                ring.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                ring.play();
            }
            Vibrator vib = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(VibrationEffect.createWaveform(new long[] {0, 400, 250, 400, 250, 400}, -1));
            }
            notifyDone(c);
        } catch (RuntimeException ignored) {
            // best effort
        }
        final Ringtone toStop = ring;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                if (toStop != null) {
                    toStop.stop();
                }
            } catch (RuntimeException ignored) {
                // already stopped
            }
            result.finish();
        }, 8000);
    }

    private void notifyDone(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "NOVA timer", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent open = PendingIntent.getActivity(c, 4713, new Intent(c, NovaActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification n = new android.app.Notification.Builder(c, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("Timer finished")
                    .setContentText("Your NOVA timer ran out")
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build();
            nm.notify(4711, n);
        } catch (RuntimeException ignored) {
            // notifications may be blocked, the sound still played
        }
    }
}
