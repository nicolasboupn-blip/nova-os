package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Scratch card: buy a card, scratch the silver with your finger, match three of the same symbol to win.
 * Prizes: 💎 x25, ⭐ x10, 🔔 x5, 🍒 x3, 🍋 x2. About one card in seven wins something.
 */
final class GameScratch extends Game {
    private static final String[] SYM = {"🍒", "🍋", "🔔", "⭐", "💎", "🍀"};
    private static final int[] MULT = {3, 2, 5, 10, 25, 0};
    // chance of each symbol being the winning one: cherry, lemon, bell, star, gem
    private static final double[] CHANCE = {0.040, 0.070, 0.025, 0.012, 0.004};
    private static final int[] PRICES = {10, 20, 50};

    private final Random rnd = new Random();
    private final Card card;
    private final TextView message;
    private final TextView coinsText;
    private final TextView buyBtn;
    private final TextView revealBtn;
    private final TextView[] priceViews = new TextView[PRICES.length];
    private int price = 1;
    private int paid;
    private boolean live;

    GameScratch(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(60), dp(20), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        coinsText = label("", 13f, Theme.TEXT);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (!live && coins() < PRICES[0]) {
                Prefs.putInt("slot_coins", 100);
                refresh();
            }
        });
        col.addView(coinsText);

        card = new Card(host);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(250));
        cp.topMargin = dp(20);
        col.addView(card, cp);

        message = label("BUY A CARD AND SCRATCH IT", 15f, Theme.DIM);
        message.setLetterSpacing(0.08f);
        col.addView(message, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 0, 1f));

        LinearLayout prices = new LinearLayout(host);
        prices.setGravity(Gravity.CENTER);
        for (int i = 0; i < PRICES.length; i++) {
            final int idx = i;
            TextView t = label("" + PRICES[i], 14f, Theme.TEXT);
            t.setClickable(true);
            t.setOnClickListener(v -> {
                if (!live) {
                    price = idx;
                    stylePrices();
                }
            });
            priceViews[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(64), dp(46));
            lp.setMargins(dp(6), 0, dp(6), 0);
            prices.addView(t, lp);
        }
        col.addView(prices, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        buyBtn = button("BUY CARD", this::buy);
        buyBtn.setTextColor(Theme.BG);
        buyBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(16);
        col.addView(buyBtn, bp);
        revealBtn = button("REVEAL ALL", () -> card.revealAll());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(10);
        col.addView(revealBtn, rp);
        stylePrices();
        refresh();
    }

    @Override
    String title() {
        return "SCRATCH CARD";
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void stylePrices() {
        for (int i = 0; i < priceViews.length; i++) {
            boolean on = i == price;
            priceViews[i].setBackground(Theme.rounded(on ? Theme.ACCENT : 0x33FFFFFF, 14f, host));
            priceViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
        }
    }

    private void refresh() {
        coinsText.setText(!live && coins() < PRICES[0] ? "TAP: FREE COINS" : "COINS " + coins());
        buyBtn.setVisibility(live ? GONE : VISIBLE);
        revealBtn.setVisibility(live ? VISIBLE : GONE);
    }

    private void buy() {
        if (live) {
            return;
        }
        paid = PRICES[price];
        if (coins() < paid) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - paid);
        int[] cells = makeCard();
        live = true;
        message.setText("SCRATCH!");
        message.setTextColor(Theme.TEXT);
        card.start(cells);
        host.buzz(15);
        refresh();
    }

    /** Six symbols. Exactly three of one prize symbol on a winning card, never three of a kind otherwise. */
    private int[] makeCard() {
        double roll = rnd.nextDouble();
        double acc = 0;
        int winner = -1;
        for (int i = 0; i < CHANCE.length; i++) {
            acc += CHANCE[i];
            if (roll < acc) {
                winner = i;
                break;
            }
        }
        List<Integer> cells = new ArrayList<>();
        int[] count = new int[SYM.length];
        if (winner >= 0) {
            for (int i = 0; i < 3; i++) {
                cells.add(winner);
            }
            count[winner] = 3;
        }
        while (cells.size() < 6) {
            int s = rnd.nextInt(SYM.length);
            if (count[s] >= 2) {
                continue;
            }
            count[s]++;
            cells.add(s);
        }
        Collections.shuffle(cells, rnd);
        int[] out = new int[6];
        for (int i = 0; i < 6; i++) {
            out[i] = cells.get(i);
        }
        return out;
    }

    private void settle(int[] cells) {
        int[] count = new int[SYM.length];
        for (int c : cells) {
            count[c]++;
        }
        int prize = 0;
        for (int s = 0; s < SYM.length; s++) {
            if (count[s] >= 3 && MULT[s] > 0) {
                prize = paid * MULT[s];
            }
        }
        live = false;
        if (prize > 0) {
            Prefs.putInt("slot_coins", coins() + prize);
            message.setText("WINNER!  +" + (prize - paid > 0 ? prize - paid : prize));
            message.setTextColor(Theme.ACCENT);
            host.buzz(60);
            host.confetti(getWidth() / 2f, getHeight() * 0.35f);
            Badges.unlock(host, "scratch");
        } else {
            message.setText("NO LUCK · TRY ANOTHER");
            message.setTextColor(Theme.DIM);
        }
        refresh();
    }

    // ------------------------------------------------------------------ the card

    private final class Card extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path stroke = new Path();
        private final boolean[] touched = new boolean[16 * 10];
        private Bitmap coat;
        private Canvas coatCanvas;
        private int[] cells = {5, 5, 5, 5, 5, 5};
        private boolean scratching;
        private boolean revealed = true;
        private float lastX, lastY;
        private float fade = 1f;

        Card(Context c) {
            super(c);
            p.setTextAlign(Paint.Align.CENTER);
            clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            clear.setStyle(Paint.Style.STROKE);
            clear.setStrokeCap(Paint.Cap.ROUND);
            clear.setStrokeJoin(Paint.Join.ROUND);
            clear.setStrokeWidth(dp(40));
        }

        void start(int[] newCells) {
            cells = newCells;
            java.util.Arrays.fill(touched, false);
            revealed = false;
            scratching = true;
            fade = 1f;
            makeCoat();
            invalidate();
        }

        private void makeCoat() {
            if (getWidth() == 0) {
                return;
            }
            if (coat == null || coat.getWidth() != getWidth() || coat.getHeight() != getHeight()) {
                coat = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
                coatCanvas = new Canvas(coat);
            }
            coat.eraseColor(0);
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setShader(new LinearGradient(0, 0, getWidth(), getHeight(),
                    new int[] {0xFFB8B8C4, 0xFFE9E9F2, 0xFF9A9AAA, 0xFFD7D7E2},
                    null, Shader.TileMode.CLAMP));
            coatCanvas.drawRoundRect(0, 0, getWidth(), getHeight(), dp(18), dp(18), g);
            Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
            t.setColor(0x33000000);
            t.setTextSize(dp(26));
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextAlign(Paint.Align.CENTER);
            coatCanvas.drawText("SCRATCH HERE", getWidth() / 2f, getHeight() / 2f + dp(9), t);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (!revealed) {
                makeCoat();
            }
        }

        void revealAll() {
            if (revealed || !scratching) {
                return;
            }
            scratching = false;
            revealed = true;
            animate().cancel();
            android.animation.ValueAnimator a = android.animation.ValueAnimator.ofFloat(1f, 0f);
            a.setDuration(450);
            a.addUpdateListener(an -> {
                fade = (float) an.getAnimatedValue();
                invalidate();
            });
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    settle(cells);
                }
            });
            a.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!scratching || coatCanvas == null) {
                return true;
            }
            float x = e.getX();
            float y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    lastX = x;
                    lastY = y;
                    stroke.rewind();
                    stroke.moveTo(x, y);
                    stroke.lineTo(x + 0.1f, y);
                    coatCanvas.drawPath(stroke, clear);
                    mark(x, y);
                    break;
                case MotionEvent.ACTION_MOVE:
                    stroke.rewind();
                    stroke.moveTo(lastX, lastY);
                    stroke.lineTo(x, y);
                    coatCanvas.drawPath(stroke, clear);
                    float steps = Math.max(1f, (float) Math.hypot(x - lastX, y - lastY) / dp(10));
                    for (int i = 1; i <= steps; i++) {
                        mark(lastX + (x - lastX) * i / steps, lastY + (y - lastY) * i / steps);
                    }
                    lastX = x;
                    lastY = y;
                    break;
                default:
                    break;
            }
            invalidate();
            if (covered() >= 0.55f) {
                revealAll();
            }
            return true;
        }

        private void mark(float x, float y) {
            int cx = (int) (x / getWidth() * 16);
            int cy = (int) (y / getHeight() * 10);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    int ix = cx + dx;
                    int iy = cy + dy;
                    if (ix >= 0 && ix < 16 && iy >= 0 && iy < 10) {
                        touched[iy * 16 + ix] = true;
                    }
                }
            }
        }

        private float covered() {
            int n = 0;
            for (boolean b : touched) {
                if (b) {
                    n++;
                }
            }
            return n / (float) touched.length;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x33000000);
            c.drawRoundRect(-dp(3), -dp(3), w + dp(3), h + dp(3), dp(20), dp(20), p);
            p.setColor(0xFF1B1430);
            c.drawRoundRect(0, 0, w, h, dp(18), dp(18), p);
            // the six symbols in two rows of three
            p.setTextSize(Math.min(w / 3.6f, h / 2.6f));
            for (int i = 0; i < 6; i++) {
                float cx = w * (0.19f + 0.31f * (i % 3));
                float cy = h * (0.30f + 0.42f * (i / 3));
                p.setColor(0x22FFFFFF);
                c.drawCircle(cx, cy, Math.min(w, h) * 0.17f, p);
                p.setColor(0xFFFFFFFF);
                c.drawText(SYM[cells[i]], cx, cy + p.getTextSize() * 0.35f, p);
            }
            if (coat != null && (!revealed || fade > 0f)) {
                p.setAlpha((int) (255 * fade));
                c.drawBitmap(coat, 0, 0, p);
                p.setAlpha(255);
            }
        }
    }
}
