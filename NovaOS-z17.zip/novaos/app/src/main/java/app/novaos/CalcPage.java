package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A calculator on the panel. Uses the same maths engine as the terminal "calc" command. */
final class CalcPage extends LinearLayout {
    private final NovaActivity host;
    private final TextView expr;
    private final TextView preview;
    private final StringBuilder text = new StringBuilder();
    private boolean justEvaluated;

    CalcPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);

        expr = new TextView(host);
        expr.setTypeface(Theme.MONO);
        expr.setTextSize(16f);
        expr.setTextColor(Theme.TEXT);
        expr.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        expr.setSingleLine(true);
        expr.setEllipsize(android.text.TextUtils.TruncateAt.START);
        addView(expr, new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 24)));
        preview = new TextView(host);
        preview.setTypeface(Theme.MONO);
        preview.setTextSize(11f);
        preview.setTextColor(Theme.DIM);
        preview.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        preview.setSingleLine(true);
        addView(preview, new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 16)));

        String[][] keys = {
            {"C", "( )", "%", "÷"},
            {"7", "8", "9", "×"},
            {"4", "5", "6", "−"},
            {"1", "2", "3", "+"},
            {"0", ".", "⌫", "="}
        };
        for (String[] row : keys) {
            LinearLayout line = new LinearLayout(host);
            for (final String k : row) {
                TextView b = new TextView(host);
                b.setText(k);
                b.setTypeface(Theme.MONO);
                b.setTextSize(14f);
                boolean op = "÷×−+=".contains(k) || k.equals("C");
                b.setTextColor(op ? Theme.BG : Theme.TEXT);
                b.setGravity(Gravity.CENTER);
                b.setBackground(Theme.rounded(k.equals("=") || "÷×−+".contains(k) ? Theme.ACCENT
                        : k.equals("C") ? 0xFFFF6B7F : 0x26FFFFFF, 8f, host));
                b.setClickable(true);
                b.setOnClickListener(v -> press(k));
                LayoutParams lp = new LayoutParams(0, Theme.dp(host, 24), 1f);
                lp.setMargins(Theme.dp(host, 2), Theme.dp(host, 1), Theme.dp(host, 2), Theme.dp(host, 1));
                line.addView(b, lp);
            }
            addView(line, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        }
        show();
    }

    private void press(String k) {
        host.buzz(6);
        switch (k) {
            case "C":
                text.setLength(0);
                justEvaluated = false;
                break;
            case "⌫":
                if (text.length() > 0) {
                    text.setLength(text.length() - 1);
                }
                break;
            case "( )": {
                int open = 0;
                int close = 0;
                for (int i = 0; i < text.length(); i++) {
                    if (text.charAt(i) == '(') {
                        open++;
                    } else if (text.charAt(i) == ')') {
                        close++;
                    }
                }
                char last = text.length() > 0 ? text.charAt(text.length() - 1) : ' ';
                boolean afterValue = Character.isDigit(last) || last == ')' || last == '%';
                text.append(open > close && afterValue ? ")" : "(");
                break;
            }
            case "=":
                try {
                    String r = Expr.format(Expr.eval(text.toString()));
                    text.setLength(0);
                    text.append(r);
                    justEvaluated = true;
                } catch (IllegalArgumentException e) {
                    preview.setText(e.getMessage());
                    return;
                }
                break;
            default: {
                boolean isOp = "÷×−+%".contains(k);
                if (justEvaluated && !isOp) {
                    text.setLength(0);
                }
                justEvaluated = false;
                text.append(k);
                break;
            }
        }
        show();
    }

    private void show() {
        expr.setText(text.length() == 0 ? "0" : text.toString());
        if (text.length() == 0) {
            preview.setText("");
            return;
        }
        try {
            preview.setText("= " + Expr.format(Expr.eval(text.toString())));
        } catch (IllegalArgumentException e) {
            preview.setText("");
        }
    }
}
