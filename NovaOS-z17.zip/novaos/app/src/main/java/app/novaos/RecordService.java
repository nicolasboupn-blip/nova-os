package app.novaos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Records the screen to a video in Movies/NOVA. Android asks you to confirm before it starts, and shows
 * a notification while it runs. Tap STOP in the notification or the REC tile in the swipe-down panel to finish.
 */
public class RecordService extends Service {
    static volatile boolean running = false;

    private static final String ACTION_STOP = "app.novaos.STOP_RECORD";
    private static final String CHANNEL = "nova_record";

    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay display;
    private Uri savedUri;
    private ParcelFileDescriptor pfd;

    static void start(Context c, int resultCode, Intent data) {
        Intent i = new Intent(c, RecordService.class);
        i.putExtra("code", resultCode);
        i.putExtra("data", data);
        c.startForegroundService(i);
    }

    static void stop(Context c) {
        c.startService(new Intent(c, RecordService.class).setAction(ACTION_STOP));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            finish();
            return START_NOT_STICKY;
        }
        if (intent == null || running) {
            return START_NOT_STICKY;
        }
        startForegroundNow();
        try {
            begin(intent.getIntExtra("code", 0), intent.getParcelableExtra("data"));
            running = true;
        } catch (Exception e) {
            cleanup(false);
            stopForeground(true);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startForegroundNow() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Screen recording",
                NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, RecordService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("NOVA is recording the screen")
                .setContentText("Tap STOP to finish")
                .addAction(new Notification.Action.Builder(null, "STOP", stop).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(41, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(41, n);
        }
    }

    private void begin(int code, Intent data) throws Exception {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        // Android 14 wants a callback registered before the screen is captured
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                new Handler(Looper.getMainLooper()).post(RecordService.this::finish);
            }
        }, new Handler(Looper.getMainLooper()));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels & ~1;
        int h = dm.heightPixels & ~1;
        // keep the video a sensible size
        while (w * h > 1920 * 1080 * 1.2) {
            w = (w / 2) & ~1;
            h = (h / 2) & ~1;
        }

        recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(w, h);
        recorder.setVideoFrameRate(30);
        recorder.setVideoEncodingBitRate(8_000_000);

        String name = "NOVA_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NOVA");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
            savedUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            pfd = getContentResolver().openFileDescriptor(savedUri, "w");
            recorder.setOutputFile(pfd.getFileDescriptor());
        } else {
            File dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            recorder.setOutputFile(new File(dir, name).getAbsolutePath());
        }
        recorder.prepare();
        display = projection.createVirtualDisplay("nova-rec", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, null);
        recorder.start();
    }

    private void finish() {
        boolean wasRunning = running;
        running = false;
        cleanup(wasRunning);
        stopForeground(true);
        stopSelf();
    }

    private void cleanup(boolean save) {
        try {
            if (recorder != null && save) {
                recorder.stop();
            }
        } catch (RuntimeException ignored) {
            // stopped too quickly, nothing recorded
        }
        try {
            if (recorder != null) {
                recorder.release();
            }
        } catch (RuntimeException ignored) {
            // already released
        }
        recorder = null;
        if (display != null) {
            display.release();
            display = null;
        }
        if (projection != null) {
            projection.stop();
            projection = null;
        }
        try {
            if (pfd != null) {
                pfd.close();
            }
        } catch (Exception ignored) {
            // closed already
        }
        pfd = null;
        if (savedUri != null && Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.IS_PENDING, 0);
            try {
                getContentResolver().update(savedUri, cv, null, null);
            } catch (Exception ignored) {
                // file vanished
            }
        }
        savedUri = null;
    }

    @Override
    public void onDestroy() {
        running = false;
        cleanup(false);
        super.onDestroy();
    }
}
