package app.novaos;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Six quick switches. The flashlight and sound switch directly, the others open the Android panel for it. */
final class TogglesPage extends LinearLayout {
    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView[] tiles = new TextView[6];
    private CameraManager camera;
    private String torchId;
    private boolean torchOn;
    private CameraManager.TorchCallback torchCallback;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                refresh();
            }
            ui.postDelayed(this, 2000);
        }
    };

    TogglesPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        String[] names = {"FLASHLIGHT", "WI-FI", "BLUETOOTH", "LOCATION", "AIRPLANE", "SOUND"};
        String[] icons = {"🔦", "📶", "🔵", "📍", "✈️", "🔔"};
        for (int r = 0; r < 2; r++) {
            LinearLayout line = new LinearLayout(host);
            for (int c = 0; c < 3; c++) {
                final int idx = r * 3 + c;
                TextView t = new TextView(host);
                t.setGravity(Gravity.CENTER);
                t.setTypeface(Theme.MONO);
                t.setTextSize(9f);
                t.setLetterSpacing(0.05f);
                t.setTextColor(Theme.TEXT);
                t.setTag(new String[] {icons[idx], names[idx]});
                t.setClickable(true);
                Theme.ripple(t);
                t.setOnClickListener(v -> press(idx));
                tiles[idx] = t;
                LayoutParams lp = new LayoutParams(0, Theme.dp(host, 70), 1f);
                lp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                line.addView(t, lp);
            }
            addView(line, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        }
        setupTorch();
        refresh();
    }

    private void setupTorch() {
        try {
            camera = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
            for (String id : camera.getCameraIdList()) {
                CameraCharacteristics ch = camera.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    torchId = id;
                    break;
                }
            }
            torchCallback = new CameraManager.TorchCallback() {
                @Override
                public void onTorchModeChanged(String id, boolean enabled) {
                    if (id.equals(torchId)) {
                        torchOn = enabled;
                        refresh();
                    }
                }
            };
        } catch (CameraAccessException | RuntimeException e) {
            torchId = null;
        }
    }

    private void press(int idx) {
        host.buzz(10);
        switch (idx) {
            case 0:
                if (torchId == null) {
                    host.toast("No flashlight on this phone");
                    return;
                }
                try {
                    camera.setTorchMode(torchId, !torchOn);
                } catch (CameraAccessException | RuntimeException e) {
                    host.toast("Flashlight is busy");
                }
                break;
            case 1:
                open(android.os.Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_INTERNET_CONNECTIVITY
                        : Settings.ACTION_WIFI_SETTINGS);
                break;
            case 2:
                open(Settings.ACTION_BLUETOOTH_SETTINGS);
                break;
            case 3:
                open(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                break;
            case 4:
                open(Settings.ACTION_AIRPLANE_MODE_SETTINGS);
                break;
            default:
                cycleSound();
                break;
        }
        refresh();
    }

    private void open(String action) {
        try {
            host.startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            host.toast("Not available on this phone");
        }
    }

    private void cycleSound() {
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            int mode = am.getRingerMode();
            am.setRingerMode(mode == AudioManager.RINGER_MODE_NORMAL
                    ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_NORMAL);
        } catch (SecurityException e) {
            host.toast("Allow Do Not Disturb access in NOVA settings first");
        }
    }

    private void refresh() {
        boolean wifi = false;
        try {
            WifiManager wm = (WifiManager) host.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            wifi = wm != null && wm.isWifiEnabled();
        } catch (RuntimeException ignored) {
            // leave off
        }
        boolean bt = false;
        try {
            android.bluetooth.BluetoothAdapter a = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
            bt = a != null && a.isEnabled();
        } catch (RuntimeException ignored) {
            // leave off
        }
        boolean air = Settings.Global.getInt(host.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
        boolean loc = false;
        try {
            android.location.LocationManager lm = (android.location.LocationManager) host.getSystemService(Context.LOCATION_SERVICE);
            loc = lm != null && lm.isLocationEnabled();
        } catch (RuntimeException ignored) {
            // leave off
        }
        boolean loud = true;
        try {
            loud = ((AudioManager) host.getSystemService(Context.AUDIO_SERVICE)).getRingerMode()
                    == AudioManager.RINGER_MODE_NORMAL;
        } catch (RuntimeException ignored) {
            // leave on
        }
        boolean[] on = {torchOn, wifi, bt, loc, air, loud};
        String[] extra = {"", "", "", "", "", loud ? "" : "\nvibrate"};
        for (int i = 0; i < tiles.length; i++) {
            String[] tag = (String[]) tiles[i].getTag();
            tiles[i].setText(tag[0] + "\n" + tag[1] + extra[i]);
            tiles[i].setBackground(Theme.rounded(on[i] ? (Theme.ACCENT & 0x00FFFFFF) | 0x55000000 : 0x1AFFFFFF, 14f, host));
            tiles[i].setAlpha(on[i] ? 1f : 0.75f);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (camera != null && torchCallback != null) {
            try {
                camera.registerTorchCallback(torchCallback, ui);
            } catch (RuntimeException ignored) {
                // no live torch state
            }
        }
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (camera != null && torchCallback != null) {
            try {
                camera.unregisterTorchCallback(torchCallback);
            } catch (RuntimeException ignored) {
                // already gone
            }
        }
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
