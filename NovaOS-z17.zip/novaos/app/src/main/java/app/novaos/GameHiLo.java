package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * Higher or Lower with the slot coins. The payout follows the odds, so safe guesses pay little and
 * brave ones pay a lot. A tie loses. About 95% comes back on average.
 */
final class GameHiLo extends Game {
    private static final String[] RANK = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
    private static final String[] SUIT = {"♠", "♥", "♦", "♣"};
    private static final int[] BETS = {5, 10, 25, 50};

    private final Random rnd = new Random();
    private final TextView coinsText;
    private final TextView betText;
    private final TextView streakText;
    private final TextView card;
    private final TextView hiBtn;
    private final TextView loBtn;
    private final TextView message;
    private int rank;
    private int suit;
    private int betIndex = 1;
    private int streak;
    private boolean busy;

    GameHiLo(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(80), dp(24), dp(30));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(host);
        coinsText = label("", 13f, Theme.TEXT);
        betText = label("", 13f, Theme.ACCENT);
        betText.setClickable(true);
        betText.setOnClickListener(v -> {
            if (!busy) {
                betIndex = (betIndex + 1) % BETS.length;
                refresh();
            }
        });
        streakText = label("", 13f, Theme.DIM);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(streakText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        card = label("", 64f, Theme.TEXT);
        card.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(170), dp(240));
        cp.topMargin = dp(36);
        col.addView(card, cp);

        message = label("", 14f, Theme.DIM);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mp.topMargin = dp(22);
        col.addView(message, mp);

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        loBtn = button("", () -> guess(false));
        hiBtn = button("", () -> guess(true));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        bl.setMargins(dp(6), 0, dp(6), 0);
        row.addView(loBtn, bl);
        row.addView(hiBtn, bl);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(26);
        col.addView(row, rp);

        draw();
        refresh();
    }

    @Override
    String title() {
        return "HIGHER OR LOWER";
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void draw() {
        rank = rnd.nextInt(13);
        suit = rnd.nextInt(4);
        showCard();
    }

    private void showCard() {
        card.setText(RANK[rank] + "\n" + SUIT[suit]);
        card.setTextColor(suit == 1 || suit == 2 ? 0xFFFF6B7F : Theme.TEXT);
    }

    /** Payout multiplier for a guess, from the number of cards that would win. */
    private float multiplier(boolean higher) {
        int wins = higher ? 12 - rank : rank;
        return wins <= 0 ? 0f : 0.95f * 13f / wins;
    }

    private void refresh() {
        int bet = BETS[betIndex];
        coinsText.setText("COINS " + coins());
        betText.setText("BET " + bet);
        streakText.setText("STREAK " + streak);
        float up = multiplier(true);
        float down = multiplier(false);
        hiBtn.setText("HIGHER\n" + (up > 0 ? String.format(java.util.Locale.US, "×%.2f", up) : "-"));
        loBtn.setText("LOWER\n" + (down > 0 ? String.format(java.util.Locale.US, "×%.2f", down) : "-"));
        hiBtn.setAlpha(up > 0 ? 1f : 0.35f);
        loBtn.setAlpha(down > 0 ? 1f : 0.35f);
        if (coins() < bet) {
            message.setText("not enough coins - tap COINS for +100");
        }
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (coins() < BETS[0]) {
                Prefs.putInt("slot_coins", 100);
                message.setText("+100 free coins");
                refresh();
            }
        });
    }

    private void guess(final boolean higher) {
        if (busy) {
            return;
        }
        final int bet = BETS[betIndex];
        final float mult = multiplier(higher);
        if (mult <= 0f) {
            return;
        }
        if (coins() < bet) {
            message.setText("not enough coins - lower the bet");
            return;
        }
        busy = true;
        Prefs.putInt("slot_coins", coins() - bet);
        refresh();
        final int nextRank = rnd.nextInt(13);
        final int nextSuit = rnd.nextInt(4);
        final boolean win = higher ? nextRank > rank : nextRank < rank;
        card.animate().rotationY(90f).setDuration(140).withEndAction(() -> {
            rank = nextRank;
            suit = nextSuit;
            showCard();
            card.setRotationY(-90f);
            card.animate().rotationY(0f).setDuration(140).start();
        }).start();
        h.postDelayed(() -> {
            if (win) {
                int pay = Math.round(bet * mult);
                Prefs.putInt("slot_coins", coins() + pay);
                streak++;
                message.setText("YES  +" + pay);
                message.setTextColor(Theme.ACCENT);
                host.buzz(25);
                if (streak >= 5) {
                    Badges.unlock(host, "hilo");
                }
                if (streak % 3 == 0) {
                    host.confetti(getWidth() / 2f, getHeight() * 0.4f);
                }
            } else {
                streak = 0;
                message.setText("NOPE");
                message.setTextColor(Theme.DIM);
            }
            busy = false;
            refresh();
        }, 330);
    }
}
