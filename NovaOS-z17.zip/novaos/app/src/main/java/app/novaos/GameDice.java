package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * Dice duel: you and the house each roll two dice. The higher total wins 1.9 times your bet, a tie gives your
 * bet back. About 96% comes back over time.
 */
final class GameDice extends Game {
    private static final int[] CHIPS = {5, 10, 25, 50, 100};

    private final Random rnd = new Random();
    private final DiceView[] mine = new DiceView[2];
    private final DiceView[] house = new DiceView[2];
    private final TextView myTotal;
    private final TextView houseTotal;
    private final TextView message;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView rollBtn;
    private int chip = 1;
    private boolean rolling;

    GameDice(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(60), dp(20), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(host);
        coinsText = label("", 13f, Theme.TEXT);
        coinsText.setGravity(Gravity.START);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (!rolling && coins() < CHIPS[0]) {
                Prefs.putInt("slot_coins", 100);
                refresh();
            }
        });
        betText = label("", 13f, Theme.ACCENT);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        houseTotal = label("HOUSE", 13f, Theme.DIM);
        LinearLayout.LayoutParams ht = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ht.topMargin = dp(36);
        col.addView(houseTotal, ht);
        col.addView(diceRow(house));

        message = label("PICK A BET AND ROLL", 16f, Theme.DIM);
        message.setLetterSpacing(0.1f);
        col.addView(message, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 0, 1f));

        col.addView(diceRow(mine));
        myTotal = label("YOU", 13f, Theme.DIM);
        col.addView(myTotal);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(String.valueOf(CHIPS[i]), 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (!rolling) {
                    chip = idx;
                    styleChips();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(46), dp(46));
            cp.setMargins(dp(5), 0, dp(5), 0);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chp.topMargin = dp(22);
        col.addView(chips, chp);

        rollBtn = button("ROLL", this::roll);
        rollBtn.setTextColor(Theme.BG);
        rollBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(16);
        col.addView(rollBtn, rp);

        styleChips();
        refresh();
    }

    @Override
    String title() {
        return "DICE DUEL";
    }

    private LinearLayout diceRow(DiceView[] into) {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 2; i++) {
            into[i] = new DiceView(host);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(92), dp(92));
            lp.setMargins(dp(10), dp(8), dp(10), dp(8));
            row.addView(into[i], lp);
        }
        return row;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    private void refresh() {
        coinsText.setText(!rolling && coins() < CHIPS[0] ? "TAP: FREE COINS" : "COINS " + coins());
        betText.setText("BET " + CHIPS[chip]);
        rollBtn.setAlpha(rolling ? 0.4f : 1f);
    }

    private void roll() {
        if (rolling) {
            return;
        }
        final int bet = CHIPS[chip];
        if (coins() < bet) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - bet);
        rolling = true;
        message.setText("");
        refresh();
        final int[] m = {1 + rnd.nextInt(6), 1 + rnd.nextInt(6)};
        final int[] hs = {1 + rnd.nextInt(6), 1 + rnd.nextInt(6)};
        final int frames = 14;
        for (int f = 0; f < frames; f++) {
            final boolean last = f == frames - 1;
            h.postDelayed(() -> {
                for (int i = 0; i < 2; i++) {
                    mine[i].set(last ? m[i] : 1 + rnd.nextInt(6));
                    house[i].set(last ? hs[i] : 1 + rnd.nextInt(6));
                    mine[i].setRotation(last ? 0f : rnd.nextInt(30) - 15);
                    house[i].setRotation(last ? 0f : rnd.nextInt(30) - 15);
                }
                if (last) {
                    done(bet, m[0] + m[1], hs[0] + hs[1], m[0] == 6 && m[1] == 6);
                }
            }, 70L * f + (f > 9 ? (f - 9) * 60L : 0));
        }
    }

    private void done(int bet, int me, int them, boolean doubleSix) {
        myTotal.setText("YOU  " + me);
        houseTotal.setText("HOUSE  " + them);
        rolling = false;
        if (me > them) {
            int back = Math.round(bet * 1.9f);
            Prefs.putInt("slot_coins", coins() + back);
            message.setText("YOU WIN  +" + (back - bet));
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
            if (doubleSix) {
                Badges.unlock(host, "dice");
            }
        } else if (me == them) {
            Prefs.putInt("slot_coins", coins() + bet);
            message.setText("TIE · BET BACK");
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText("HOUSE WINS  -" + bet);
            message.setTextColor(0xFFFF6B7F);
            host.buzz(25);
        }
        refresh();
    }

    /** One die with the usual dots, glowing in the accent colour. */
    private static final class DiceView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private int value = 1;

        DiceView(Context c) {
            super(c);
        }

        void set(int v) {
            value = v;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float inset = w * 0.06f;
            r.set(inset, inset, w - inset, w - inset);
            p.setStyle(Paint.Style.FILL);
            p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x40000000);
            c.drawRoundRect(0, 0, w, w, w * 0.24f, w * 0.24f, p);
            p.setColor(0xFFF2EEFF);
            c.drawRoundRect(r, w * 0.2f, w * 0.2f, p);
            p.setColor(0xFF14101F);
            float[] pos = {0.27f, 0.5f, 0.73f};
            int[][] pips = {
                {}, {4}, {0, 8}, {0, 4, 8}, {0, 2, 6, 8}, {0, 2, 4, 6, 8}, {0, 2, 3, 5, 6, 8}
            };
            for (int idx : pips[value]) {
                float x = pos[idx % 3] * w;
                float y = pos[idx / 3] * w;
                c.drawCircle(x, y, w * 0.075f, p);
            }
        }
    }
}
