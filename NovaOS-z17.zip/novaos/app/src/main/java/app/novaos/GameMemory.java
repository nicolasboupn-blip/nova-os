package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Twelve cards, six pairs. Find them all in as few tries as you can. */
final class GameMemory extends Game {
    private static final String[] EMOJI = {"🐙", "🚀", "🍕", "🎸", "🌵", "👾"};
    private final TextView[] cards = new TextView[12];
    private final int[] face = new int[12];
    private final boolean[] up = new boolean[12];
    private final boolean[] done = new boolean[12];
    private final TextView info;
    private int first = -1;
    private boolean lock;
    private int moves;
    private int found;

    GameMemory(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(70), dp(16), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        info = label("", 14f, Theme.TEXT);
        col.addView(info, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        for (int row = 0; row < 3; row++) {
            LinearLayout line = new LinearLayout(host);
            for (int cI = 0; cI < 4; cI++) {
                final int idx = row * 4 + cI;
                TextView t = label("?", 30f, Theme.ACCENT);
                t.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
                t.setClickable(true);
                t.setOnClickListener(v -> tap(idx));
                cards[idx] = t;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(104), 1f);
                lp.setMargins(dp(5), dp(5), dp(5), dp(5));
                line.addView(t, lp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.topMargin = row == 0 ? dp(18) : 0;
            col.addView(line, rp);
        }
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(24);
        col.addView(button("NEW GAME", this::deal), bp);
        deal();
    }

    @Override
    String title() {
        return "MEMORY";
    }

    private void deal() {
        h.removeCallbacksAndMessages(null);
        Random rnd = new Random();
        int[] deck = new int[12];
        for (int i = 0; i < 12; i++) {
            deck[i] = i / 2;
        }
        for (int i = 11; i > 0; i--) {
            int j = rnd.nextInt(i + 1);
            int tmp = deck[i];
            deck[i] = deck[j];
            deck[j] = tmp;
        }
        for (int i = 0; i < 12; i++) {
            face[i] = deck[i];
            up[i] = false;
            done[i] = false;
            cards[i].setRotationY(0f);
            cards[i].setText("?");
            cards[i].setTextColor(Theme.ACCENT);
            cards[i].setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        }
        first = -1;
        lock = false;
        moves = 0;
        found = 0;
        updateInfo();
    }

    private void updateInfo() {
        int b = best("memory", 0);
        info.setText("MOVES " + moves + (b > 0 ? "   BEST " + b : ""));
    }

    private void flip(final int i, final boolean show) {
        final TextView c = cards[i];
        c.animate().cancel();
        c.animate().rotationY(90f).setDuration(110).withEndAction(() -> {
            c.setText(show ? EMOJI[face[i]] : "?");
            c.setTextColor(show ? Theme.TEXT : Theme.ACCENT);
            c.setRotationY(-90f);
            c.animate().rotationY(0f).setDuration(110).start();
        }).start();
    }

    private void tap(int i) {
        if (lock || up[i] || done[i]) {
            return;
        }
        up[i] = true;
        flip(i, true);
        if (first < 0) {
            first = i;
            return;
        }
        final int a = first;
        final int b = i;
        first = -1;
        moves++;
        updateInfo();
        if (face[a] == face[b]) {
            done[a] = true;
            done[b] = true;
            found++;
            host.buzz(20);
            h.postDelayed(() -> {
                cards[a].setBackground(Theme.rounded(0x55FFFFFF & (Theme.ACCENT | 0xFF000000), 14f, host));
                cards[b].setBackground(Theme.rounded(0x55FFFFFF & (Theme.ACCENT | 0xFF000000), 14f, host));
            }, 240);
            if (found == 6) {
                int bestNow = best("memory", 0);
                if (bestNow == 0 || moves < bestNow) {
                    saveBest("memory", moves);
                }
                if (moves <= 10) {
                    Badges.unlock(host, "memory");
                }
                h.postDelayed(() -> {
                    if (isAttachedToWindow()) {
                        host.confetti(getWidth() / 2f, getHeight() * 0.4f);
                        updateInfo();
                    }
                }, 400);
            }
        } else {
            lock = true;
            h.postDelayed(() -> {
                up[a] = false;
                up[b] = false;
                flip(a, false);
                flip(b, false);
                lock = false;
            }, 750);
        }
    }
}
