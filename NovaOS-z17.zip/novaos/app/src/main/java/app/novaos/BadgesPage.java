package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** All achievements. Locked ones are dim; press one to see how to get it. */
final class BadgesPage extends LinearLayout {
    private final NovaActivity host;
    private final TextView head;
    private final TextView[] cells = new TextView[Badges.ALL.length];

    BadgesPage(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        head = new TextView(host);
        head.setTypeface(Theme.MONO);
        head.setTextSize(11f);
        head.setTextColor(Theme.TEXT);
        head.setGravity(Gravity.CENTER);
        addView(head, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        int cols = 6;
        for (int r = 0; r * cols < cells.length; r++) {
            LinearLayout row = new LinearLayout(host);
            for (int c = 0; c < cols; c++) {
                final int i = r * cols + c;
                if (i >= cells.length) {
                    break;
                }
                TextView t = new TextView(host);
                t.setTextSize(20f);
                t.setGravity(Gravity.CENTER);
                t.setClickable(true);
                t.setBackground(Theme.rounded(0x1AFFFFFF, 12f, host));
                t.setOnClickListener(v -> {
                    Badges.Badge b = Badges.ALL[i];
                    host.toast(Badges.has(b.id) ? b.name + " ✓  " + b.how : "🔒 " + b.name + ": " + b.how);
                });
                cells[i] = t;
                LayoutParams lp = new LayoutParams(0, Theme.dp(host, 36), 1f);
                lp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                row.addView(t, lp);
            }
            LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            rp.topMargin = r == 0 ? Theme.dp(host, 6) : 0;
            addView(row, rp);
        }
        refresh();
    }

    void refresh() {
        head.setText(Badges.count() + " / " + Badges.ALL.length + " UNLOCKED");
        for (int i = 0; i < cells.length; i++) {
            Badges.Badge b = Badges.ALL[i];
            boolean has = Badges.has(b.id);
            cells[i].setText(b.icon);
            cells[i].setAlpha(has ? 1f : 0.25f);
        }
    }
}
