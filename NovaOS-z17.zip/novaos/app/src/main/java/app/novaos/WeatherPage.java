package app.novaos;

import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

/** Weather now and the next 5 days for your city. Tap the city name to change it. */
final class WeatherPage extends LinearLayout {
    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView city;
    private final TextView now;
    private final TextView detail;
    private final LinearLayout forecast;
    private boolean loading;
    private long lastTry;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                maybeLoad();
                render();
            }
            ui.postDelayed(this, 30_000);
        }
    };

    WeatherPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);

        city = new TextView(host);
        city.setTypeface(Theme.MONO);
        city.setTextSize(11f);
        city.setLetterSpacing(0.12f);
        city.setTextColor(Theme.ACCENT);
        city.setGravity(Gravity.CENTER);
        city.setClickable(true);
        city.setPadding(0, Theme.dp(host, 4), 0, Theme.dp(host, 4));
        city.setOnClickListener(v -> askCity());
        addView(city, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        now = new TextView(host);
        now.setTypeface(Theme.MONO);
        now.setTextSize(30f);
        now.setTextColor(Theme.TEXT);
        now.setGravity(Gravity.CENTER);
        now.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        addView(now, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        detail = new TextView(host);
        detail.setTypeface(Theme.MONO);
        detail.setTextSize(10.5f);
        detail.setTextColor(Theme.DIM);
        detail.setGravity(Gravity.CENTER);
        addView(detail, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        forecast = new LinearLayout(host);
        LayoutParams fp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        fp.topMargin = Theme.dp(host, 8);
        addView(forecast, fp);
        render();
    }

    private void maybeLoad() {
        if (loading || !WeatherData.hasCity()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (WeatherData.valid && now - WeatherData.loadedAt < 20 * 60_000L) {
            return;
        }
        if (now - lastTry < 60_000L) {
            return;
        }
        lastTry = now;
        loading = true;
        new Thread(() -> {
            WeatherData.load(false);
            ui.post(() -> {
                loading = false;
                render();
            });
        }).start();
    }

    private void render() {
        forecast.removeAllViews();
        if (!WeatherData.hasCity()) {
            city.setText("TAP HERE TO SET YOUR CITY");
            now.setText("--");
            detail.setText("");
            return;
        }
        city.setText(WeatherData.city().toUpperCase(Locale.ROOT) + "  ✎");
        if (!WeatherData.valid) {
            now.setText(loading ? "..." : "--");
            detail.setText(loading ? "loading" : "no connection");
            return;
        }
        now.setText(WeatherData.emoji(WeatherData.code, WeatherData.day) + " " + Math.round(WeatherData.temp) + "°");
        detail.setText(WeatherData.describe(WeatherData.code) + " · feels " + Math.round(WeatherData.feels)
                + "° · wind " + Math.round(WeatherData.wind) + " km/h");
        for (WeatherData.Day d : WeatherData.days) {
            if (d == null || d.date == null) {
                continue;
            }
            LinearLayout cell = new LinearLayout(host);
            cell.setOrientation(VERTICAL);
            cell.setGravity(Gravity.CENTER);
            String label;
            try {
                label = LocalDate.parse(d.date).getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.getDefault())
                        .toUpperCase(Locale.ROOT);
            } catch (RuntimeException e) {
                label = "";
            }
            cell.addView(small(label, Theme.DIM, 9f));
            cell.addView(small(WeatherData.emoji(d.code, true), Theme.TEXT, 16f));
            cell.addView(small(Math.round(d.max) + "°", Theme.TEXT, 10f));
            cell.addView(small(Math.round(d.min) + "°", Theme.DIM, 9f));
            forecast.addView(cell, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        }
    }

    private TextView small(String s, int color, float size) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void askCity() {
        final EditText input = new EditText(host);
        input.setHint("city, for example Zurich");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        new AlertDialog.Builder(host)
                .setTitle("Weather city")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Set", (d, w) -> {
                    final String q = input.getText().toString().trim();
                    if (q.isEmpty()) {
                        return;
                    }
                    loading = true;
                    detail.setText("looking up " + q + "...");
                    new Thread(() -> {
                        final WeatherData.Place p = WeatherData.geocode(q);
                        if (p != null) {
                            WeatherData.saveCity(p);
                            WeatherData.load(true);
                        }
                        ui.post(() -> {
                            loading = false;
                            if (p == null) {
                                host.toast("City not found (or no connection)");
                            }
                            render();
                        });
                    }).start();
                })
                .show();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
