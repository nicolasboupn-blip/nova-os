package app.novaos;

import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * When the Sennheiser Momentum 4 headphones are connected, a small card drops in from the top:
 * "Want some music?" (gone after 6 seconds if you ignore it). Yes leads to "How are you feelin today?"
 * with three genres, and the choice is handed to your music app as a search to play.
 */
final class HeadphonePrompt {
    private HeadphonePrompt() {
    }

    private static final String[] GENRES = {"Chill", "Hip-Hop", "Electronic"};
    private static final String[] ICONS = {"😌", "🔥", "⚡"};
    private static final String[] QUERIES = {"chill music", "hip hop music", "electronic music"};

    private static boolean asked;      // asked since the headphones last connected
    private static android.view.View card;

    static boolean connected(NovaActivity host) {
        AudioManager am = (AudioManager) host.getSystemService(android.content.Context.AUDIO_SERVICE);
        if (am == null) {
            return false;
        }
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int t = d.getType();
            boolean bt = t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                    || (android.os.Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET);
            CharSequence name = d.getProductName();
            if (bt && name != null && name.toString().toLowerCase(java.util.Locale.ROOT).contains("momentum")) {
                return true;
            }
        }
        return false;
    }

    /** Watches for the headphones connecting or leaving while NOVA is on screen. */
    static AudioDeviceCallback callback(final NovaActivity host) {
        return new AudioDeviceCallback() {
            @Override
            public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
                host.root.postDelayed(() -> check(host), 1200);
            }

            @Override
            public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
                if (!connected(host)) {
                    asked = false;
                }
            }
        };
    }

    /** Called when the home screen shows and when a device connects. Asks at most once per connection. */
    static void check(NovaActivity host) {
        if (asked || card != null || !Prefs.headphoneAsk() || !host.onHome()) {
            return;
        }
        if (!connected(host)) {
            return;
        }
        if (MusicHelper.isPlaying(MusicHelper.controller(host))) {
            asked = true;
            return;
        }
        asked = true;
        question(host);
    }

    private static TextView text(NovaActivity host, String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private static TextView pill(final NovaActivity host, String s, boolean strong, final Runnable action) {
        TextView t = text(host, s, 13f, strong ? Theme.TEXT : Theme.DIM);
        t.setLetterSpacing(0.1f);
        t.setBackground(Theme.rounded(strong ? ((Theme.ACCENT & 0x00FFFFFF) | 0x55000000) : 0x26FFFFFF, 14f, host));
        t.setPadding(Theme.dp(host, 16), Theme.dp(host, 10), Theme.dp(host, 16), Theme.dp(host, 10));
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    private static LinearLayout shell(NovaActivity host) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        box.setPadding(Theme.dp(host, 20), Theme.dp(host, 14), Theme.dp(host, 20), Theme.dp(host, 14));
        box.setElevation(Theme.dp(host, 12));
        return box;
    }

    private static void put(final NovaActivity host, LinearLayout box) {
        dismiss(host, false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Theme.dp(host, 40);
        lp.leftMargin = Theme.dp(host, 16);
        lp.rightMargin = Theme.dp(host, 16);
        host.root.addView(box, lp);
        card = box;
        box.setAlpha(0f);
        box.setTranslationY(-Theme.dp(host, 30));
        box.animate().alpha(1f).translationY(0f).setDuration(260).start();
    }

    static void dismiss(final NovaActivity host, boolean animate) {
        final android.view.View c = card;
        card = null;
        if (c == null) {
            return;
        }
        if (!animate) {
            host.root.removeView(c);
            return;
        }
        c.animate().alpha(0f).translationY(-Theme.dp(host, 20)).setDuration(260)
                .withEndAction(() -> {
                    if (c.getParent() != null) {
                        host.root.removeView(c);
                    }
                }).start();
    }

    private static void question(final NovaActivity host) {
        LinearLayout box = shell(host);
        box.addView(text(host, "🎧  MOMENTUM 4 CONNECTED", 11f, Theme.ACCENT));
        TextView ask = text(host, "Want to hear some music?", 16f, Theme.TEXT);
        ask.setPadding(0, Theme.dp(host, 8), 0, Theme.dp(host, 12));
        box.addView(ask);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        pp.setMargins(Theme.dp(host, 6), 0, Theme.dp(host, 6), 0);
        row.addView(pill(host, "YES", true, () -> mood(host)), pp);
        row.addView(pill(host, "NO", false, () -> dismiss(host, true)), pp);
        box.addView(row);
        put(host, box);
        final android.view.View mine = box;
        box.postDelayed(() -> {
            if (card == mine) {
                dismiss(host, true);
            }
        }, 6000);
    }

    private static void mood(final NovaActivity host) {
        LinearLayout box = shell(host);
        box.addView(text(host, "How are you feelin today?", 16f, Theme.TEXT));
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, Theme.dp(host, 12), 0, 0);
        // the genre you pick most comes first
        Integer[] order = {0, 1, 2};
        java.util.Arrays.sort(order, (a, b) -> Prefs.getInt("mood_" + b, 0) - Prefs.getInt("mood_" + a, 0));
        for (int pos = 0; pos < order.length; pos++) {
            final int idx = order[pos];
            final int i = idx;
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            pp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
            TextView p = pill(host, ICONS[i] + "\n" + GENRES[i].toUpperCase(), true, () -> play(host, idx));
            p.setTextSize(11f);
            if (pos == 0 && Prefs.getInt("mood_" + idx, 0) >= 2) {
                p.setText(ICONS[i] + "\n" + GENRES[i].toUpperCase() + "\n★ your usual");
            }
            row.addView(p, pp);
        }
        box.addView(row);
        put(host, box);
        final android.view.View mine = box;
        box.postDelayed(() -> {
            if (card == mine) {
                dismiss(host, true);
            }
        }, 20000);
    }

    private static void play(NovaActivity host, int idx) {
        dismiss(host, true);
        Prefs.putInt("mood_" + idx, Prefs.getInt("mood_" + idx, 0) + 1);
        Intent i = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
        i.putExtra(SearchManager.QUERY, QUERIES[idx]);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            host.startActivity(i);
            Banner.show(host, ICONS[idx] + "  " + GENRES[idx].toUpperCase() + " COMING UP", 2500);
        } catch (ActivityNotFoundException e) {
            Banner.show(host, "NO MUSIC APP CAN PLAY THIS", 3000);
        }
    }
}
