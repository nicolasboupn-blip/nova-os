package app.novaos;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One note page that saves itself while you type. */
final class NotesScreen extends LinearLayout {

    NotesScreen(final NovaActivity host) {
        super(host);
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 24);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        LinearLayout head = new LinearLayout(host);
        head.setOrientation(LinearLayout.HORIZONTAL);

        TextView title = new TextView(host);
        title.setText("NOTES");
        title.setTypeface(Theme.MONO);
        title.setTextSize(12f);
        title.setLetterSpacing(0.3f);
        title.setTextColor(Theme.ACCENT);
        head.addView(title, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final TextView status = new TextView(host);
        status.setText("saved");
        status.setTypeface(Theme.MONO);
        status.setTextSize(12f);
        status.setTextColor(Theme.DIM);
        head.addView(status);
        addView(head);

        EditText et = new EditText(host);
        et.setBackground(null);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        et.setTextSize(17f);
        et.setLineSpacing(0f, 1.2f);
        et.setTextColor(Theme.TEXT);
        et.setHint("write something");
        et.setHintTextColor(Theme.DIM);
        et.setPadding(0, Theme.dp(host, 16), 0, 0);
        et.setText(host.prefs.getString("note", ""));
        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                host.prefs.edit().putString("note", s.toString()).apply();
                status.setText("saved");
            }
        });
        addView(et, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    }
}
