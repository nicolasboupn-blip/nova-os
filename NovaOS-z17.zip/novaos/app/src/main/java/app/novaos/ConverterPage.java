package app.novaos;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/** Converts units and currencies. Tap the blue labels to change category, from and to. Rates update daily online. */
final class ConverterPage extends LinearLayout {
    private static final String[] CATS = {"CURRENCY", "LENGTH", "MASS", "TEMP", "SPEED", "VOLUME"};
    // factor = how many base units one of this unit is (base: metre, kilogram, m/s, litre)
    private static final String[][] UNITS = {
        {"USD", "EUR", "CHF", "GBP", "JPY", "CAD", "AUD", "CNY", "SEK", "NOK", "PLN", "TRY", "INR", "BRL", "MXN", "UAH", "AED"},
        {"m", "km", "cm", "mm", "mi", "yd", "ft", "in"},
        {"kg", "g", "mg", "lb", "oz", "t"},
        {"°C", "°F", "K"},
        {"km/h", "m/s", "mph", "kn"},
        {"l", "ml", "gal (US)", "fl oz", "cup"}
    };
    private static final double[][] FACTORS = {
        {},
        {1, 1000, 0.01, 0.001, 1609.344, 0.9144, 0.3048, 0.0254},
        {1, 0.001, 0.000001, 0.45359237, 0.028349523, 1000},
        {},
        {1 / 3.6, 1, 0.44704, 0.514444},
        {1, 0.001, 3.785411784, 0.0295735296, 0.2365882365}
    };

    private final NovaActivity host;
    private final TextView catBtn;
    private final TextView fromBtn;
    private final TextView toBtn;
    private final EditText amount;
    private final TextView result;
    private int cat;
    private int from;
    private int to = 1;
    private JSONObject rates;

    ConverterPage(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        cat = Prefs.getInt("conv_cat", 0);
        from = Prefs.getInt("conv_from", 0);
        to = Prefs.getInt("conv_to", 1);
        clamp();

        LinearLayout r1 = new LinearLayout(host);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        catBtn = pill("");
        catBtn.setOnClickListener(v -> {
            cat = (cat + 1) % CATS.length;
            from = 0;
            to = 1;
            changed();
        });
        r1.addView(catBtn, new LayoutParams(0, Theme.dp(host, 40), 1f));
        amount = new EditText(host);
        amount.setText(Prefs.getString("conv_amount", "1"));
        amount.setTextColor(Theme.TEXT);
        amount.setHintTextColor(Theme.DIM);
        amount.setTextSize(15f);
        amount.setSingleLine(true);
        amount.setGravity(Gravity.CENTER);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        amount.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                Prefs.putString("conv_amount", s.toString());
                compute();
            }
        });
        LayoutParams ap = new LayoutParams(0, Theme.dp(host, 40), 1.3f);
        ap.leftMargin = Theme.dp(host, 6);
        r1.addView(amount, ap);
        addView(r1, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout r2 = new LinearLayout(host);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        fromBtn = pill("");
        fromBtn.setOnClickListener(v -> {
            from = (from + 1) % unitCount();
            changed();
        });
        TextView swap = pill("⇄");
        swap.setTextSize(16f);
        swap.setOnClickListener(v -> {
            int t = from;
            from = to;
            to = t;
            changed();
        });
        toBtn = pill("");
        toBtn.setOnClickListener(v -> {
            to = (to + 1) % unitCount();
            changed();
        });
        r2.addView(fromBtn, new LayoutParams(0, Theme.dp(host, 40), 1f));
        LayoutParams sp = new LayoutParams(Theme.dp(host, 44), Theme.dp(host, 40));
        sp.setMargins(Theme.dp(host, 6), 0, Theme.dp(host, 6), 0);
        r2.addView(swap, sp);
        r2.addView(toBtn, new LayoutParams(0, Theme.dp(host, 40), 1f));
        LayoutParams r2p = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        r2p.topMargin = Theme.dp(host, 8);
        addView(r2, r2p);

        result = new TextView(host);
        result.setTypeface(Theme.MONO);
        result.setTextSize(22f);
        result.setTextColor(Theme.TEXT);
        result.setGravity(Gravity.CENTER);
        result.setSingleLine(true);
        result.setShadowLayer(Theme.dp(host, 6), 0f, 0f, Theme.ACCENT);
        LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
        addView(result, rp);
        loadRates();
        changed();
    }

    private TextView pill(String s) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(12f);
        t.setTextColor(Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private int unitCount() {
        return UNITS[cat].length;
    }

    private void clamp() {
        cat = Math.max(0, Math.min(CATS.length - 1, cat));
        from = Math.max(0, Math.min(unitCount() - 1, from));
        to = Math.max(0, Math.min(unitCount() - 1, to));
    }

    private void changed() {
        clamp();
        Prefs.putInt("conv_cat", cat);
        Prefs.putInt("conv_from", from);
        Prefs.putInt("conv_to", to);
        catBtn.setText(CATS[cat]);
        fromBtn.setText(UNITS[cat][from]);
        toBtn.setText(UNITS[cat][to]);
        compute();
    }

    private void compute() {
        double v;
        try {
            String t = amount.getText().toString().trim();
            if (t.isEmpty() || t.equals("-") || t.equals(".")) {
                result.setText("");
                return;
            }
            v = Double.parseDouble(t);
        } catch (NumberFormatException e) {
            result.setText("");
            return;
        }
        double out;
        if (cat == 0) {
            if (rates == null) {
                result.setText("loading rates...");
                result.setTextSize(14f);
                return;
            }
            double a = rates.optDouble(UNITS[0][from], Double.NaN);
            double b = rates.optDouble(UNITS[0][to], Double.NaN);
            if (Double.isNaN(a) || Double.isNaN(b)) {
                result.setText("rate unavailable");
                return;
            }
            out = v / a * b;
        } else if (cat == 3) {
            double c;
            switch (from) {
                case 1:
                    c = (v - 32) * 5 / 9;
                    break;
                case 2:
                    c = v - 273.15;
                    break;
                default:
                    c = v;
                    break;
            }
            switch (to) {
                case 1:
                    out = c * 9 / 5 + 32;
                    break;
                case 2:
                    out = c + 273.15;
                    break;
                default:
                    out = c;
                    break;
            }
        } else {
            out = v * FACTORS[cat][from] / FACTORS[cat][to];
        }
        result.setTextSize(22f);
        result.setText(pretty(out) + " " + UNITS[cat][to]);
    }

    private static String pretty(double v) {
        double a = Math.abs(v);
        if (a >= 1e9 || (a != 0 && a < 1e-4)) {
            return String.format(Locale.US, "%.4g", v);
        }
        if (a >= 100) {
            return String.format(Locale.US, "%,.2f", v);
        }
        return String.format(Locale.US, "%.4f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    /** Exchange rates once a day, kept on the phone so it also works offline after the first time. */
    private void loadRates() {
        try {
            String saved = Prefs.getString("fx_rates", "");
            if (!saved.isEmpty()) {
                rates = new JSONObject(saved);
            }
        } catch (Exception ignored) {
            rates = null;
        }
        long age = System.currentTimeMillis() - Long.parseLong(Prefs.getString("fx_time", "0"));
        if (rates != null && age < 24L * 3600_000L) {
            return;
        }
        new Thread(() -> {
            String body = Http.get("https://open.er-api.com/v6/latest/USD");
            if (body == null) {
                return;
            }
            try {
                final JSONObject r = new JSONObject(body).getJSONObject("rates");
                Prefs.putString("fx_rates", r.toString());
                Prefs.putString("fx_time", String.valueOf(System.currentTimeMillis()));
                host.runOnUiThread(() -> {
                    rates = r;
                    compute();
                });
            } catch (Exception ignored) {
                // keep the old rates
            }
        }).start();
    }
}
