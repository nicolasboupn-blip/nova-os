package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * The drawing on the home background: white lines with a soft glow in the accent colour. It sits behind the
 * clock, panel and icons and does not take touches itself. The home screen feeds it touches while draw mode is on.
 * Drawings are saved and come back after a restart.
 */
final class DrawLayer extends View {
    private static final String KEY = "home_draw";
    private static final int MAX_CHARS = 60_000;

    private static final class Stroke {
        final List<float[]> pts = new ArrayList<>(); // normalised 0..1
        final Path path = new Path();
    }

    private final List<Stroke> strokes = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private Stroke active;

    DrawLayer(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        load();
    }

    boolean isEmpty() {
        return strokes.isEmpty();
    }

    // ------------------------------------------------------------------ input

    void down(float x, float y) {
        if (getWidth() == 0) {
            return;
        }
        active = new Stroke();
        add(active, x, y);
        add(active, x + 0.1f, y); // so a single tap still leaves a dot
        strokes.add(active);
        rebuild(active);
        invalidate();
    }

    void move(float x, float y) {
        if (active == null) {
            return;
        }
        float[] last = active.pts.get(active.pts.size() - 1);
        float dx = x - last[0] * getWidth();
        float dy = y - last[1] * getHeight();
        if (dx * dx + dy * dy < d * d * 2.25f) {
            return; // ignore tiny jitter
        }
        add(active, x, y);
        rebuild(active);
        invalidate();
    }

    void up() {
        if (active != null) {
            active = null;
            save();
        }
    }

    void undo() {
        if (!strokes.isEmpty()) {
            strokes.remove(strokes.size() - 1);
            save();
            invalidate();
        }
    }

    void clear() {
        strokes.clear();
        active = null;
        save();
        invalidate();
    }

    private void add(Stroke s, float x, float y) {
        s.pts.add(new float[] {x / getWidth(), y / getHeight()});
    }

    // ------------------------------------------------------------------ drawing

    private void rebuild(Stroke s) {
        Path p = s.path;
        p.rewind();
        int n = s.pts.size();
        if (n == 0) {
            return;
        }
        float w = getWidth();
        float h = getHeight();
        float[] first = s.pts.get(0);
        p.moveTo(first[0] * w, first[1] * h);
        if (n == 1) {
            p.lineTo(first[0] * w + 0.1f, first[1] * h);
            return;
        }
        for (int i = 1; i < n - 1; i++) {
            float[] a = s.pts.get(i);
            float[] b = s.pts.get(i + 1);
            p.quadTo(a[0] * w, a[1] * h, (a[0] + b[0]) * w / 2f, (a[1] + b[1]) * h / 2f);
        }
        float[] last = s.pts.get(n - 1);
        p.lineTo(last[0] * w, last[1] * h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        for (Stroke s : strokes) {
            rebuild(s);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int glow = Theme.ACCENT & 0x00FFFFFF;
        float[] widths = {22f, 14f, 8f};
        int[] alphas = {0x1E, 0x3C, 0x80};
        for (Stroke s : strokes) {
            for (int i = 0; i < widths.length; i++) {
                paint.setStrokeWidth(widths[i] * d);
                paint.setColor((alphas[i] << 24) | glow);
                c.drawPath(s.path, paint);
            }
            paint.setStrokeWidth(2.8f * d);
            paint.setColor(0xFFFFFFFF);
            c.drawPath(s.path, paint);
        }
    }

    // ------------------------------------------------------------------ saving

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (Stroke s : strokes) {
            if (sb.length() > 0) {
                sb.append('|');
            }
            for (int i = 0; i < s.pts.size(); i++) {
                float[] p = s.pts.get(i);
                if (i > 0) {
                    sb.append(' ');
                }
                sb.append(Math.round(p[0] * 1000)).append(',').append(Math.round(p[1] * 1000));
            }
        }
        String out = sb.toString();
        // too big: drop the oldest strokes until it fits
        while (out.length() > MAX_CHARS && strokes.size() > 1) {
            strokes.remove(0);
            out = out.substring(out.indexOf('|') + 1);
        }
        Prefs.putString(KEY, out);
    }

    private void load() {
        String raw = Prefs.getString(KEY, "");
        if (raw.isEmpty()) {
            return;
        }
        try {
            for (String part : raw.split("\\|")) {
                Stroke s = new Stroke();
                for (String pt : part.split(" ")) {
                    String[] xy = pt.split(",");
                    if (xy.length == 2) {
                        s.pts.add(new float[] {Integer.parseInt(xy[0]) / 1000f, Integer.parseInt(xy[1]) / 1000f});
                    }
                }
                if (!s.pts.isEmpty()) {
                    strokes.add(s);
                }
            }
        } catch (NumberFormatException e) {
            strokes.clear();
        }
    }

    /** Routes a touch to the drawing. Returns true. */
    boolean handle(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                down(e.getX(), e.getY());
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getHistorySize(); i++) {
                    move(e.getHistoricalX(i), e.getHistoricalY(i));
                }
                move(e.getX(), e.getY());
                break;
            default:
                up();
                break;
        }
        return true;
    }
}
