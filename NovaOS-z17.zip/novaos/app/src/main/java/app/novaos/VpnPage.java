package app.novaos;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Shows whether a VPN is running (any VPN app, CyberGhost included) and opens CyberGhost or the Android VPN
 * settings in one tap. NOVA cannot connect the VPN itself, that stays with the CyberGhost app.
 */
final class VpnPage extends LinearLayout {
    private static final String[] CYBERGHOST = {"de.mobileconcepts.cyberghost"};

    private static long connectedSince;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView state;
    private final TextView detail;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                refresh();
            }
            handler.postDelayed(this, 1500);
        }
    };

    VpnPage(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);

        state = new TextView(host);
        state.setTypeface(Theme.MONO);
        state.setTextSize(22f);
        state.setLetterSpacing(0.1f);
        state.setGravity(Gravity.CENTER);
        addView(state, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        ((LayoutParams) state.getLayoutParams()).topMargin = Theme.dp(host, 12);

        detail = new TextView(host);
        detail.setTypeface(Theme.MONO);
        detail.setTextSize(11f);
        detail.setTextColor(Theme.DIM);
        detail.setGravity(Gravity.CENTER);
        addView(detail, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(host);
        TextView open = pill("OPEN CYBERGHOST");
        open.setOnClickListener(v -> openCyberGhost());
        TextView settings = pill("VPN SETTINGS");
        settings.setOnClickListener(v -> openVpnSettings());
        LayoutParams l = new LayoutParams(0, Theme.dp(host, 40), 1.25f);
        l.setMargins(0, 0, Theme.dp(host, 3), 0);
        LayoutParams r = new LayoutParams(0, Theme.dp(host, 40), 1f);
        r.setMargins(Theme.dp(host, 3), 0, 0, 0);
        row.addView(open, l);
        row.addView(settings, r);
        LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        rp.topMargin = Theme.dp(host, 14);
        addView(row, rp);

        TextView tip = new TextView(host);
        tip.setText("Tip: in VPN SETTINGS tap the gear next to CyberGhost\nand switch on Always-on VPN + Block without VPN.");
        tip.setTypeface(Theme.MONO);
        tip.setTextSize(9f);
        tip.setTextColor(Theme.DIM);
        tip.setGravity(Gravity.CENTER);
        LayoutParams tp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        tp.topMargin = Theme.dp(host, 10);
        addView(tip, tp);
        refresh();
    }

    private TextView pill(String s) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(10.5f);
        t.setLetterSpacing(0.08f);
        t.setTextColor(Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private boolean vpnOn() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    return true;
                }
            }
        } catch (RuntimeException ignored) {
            // treat as off
        }
        return false;
    }

    private void refresh() {
        boolean on = vpnOn();
        if (on && connectedSince == 0) {
            connectedSince = SystemClock.elapsedRealtime();
        } else if (!on) {
            connectedSince = 0;
        }
        if (on) {
            state.setText("● VPN ON");
            state.setTextColor(0xFF4DFF9A);
            state.setShadowLayer(Theme.dp(host, 10), 0f, 0f, 0xFF4DFF9A);
            detail.setText("protected for " + TimeFormat.clock(SystemClock.elapsedRealtime() - connectedSince));
        } else {
            state.setText("○ VPN OFF");
            state.setTextColor(0xFFFF6B7F);
            state.setShadowLayer(Theme.dp(host, 10), 0f, 0f, 0xFFFF6B7F);
            detail.setText("your traffic is not protected");
        }
    }

    private void openCyberGhost() {
        host.repo.ensureFresh();
        for (String pkg : CYBERGHOST) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                host.launch(e);
                return;
            }
        }
        host.toast("CyberGhost is not installed on this phone");
    }

    private void openVpnSettings() {
        try {
            host.startActivity(new Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            host.toast("Not available on this phone");
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
