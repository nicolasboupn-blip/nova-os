package app.novaos;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.URLEncoder;

/**
 * A private browser window with DuckDuckGo as the search engine. Nothing is kept: cookies, cache, history and
 * site data are wiped when the window closes, and third-party cookies are refused. This is NOT Tor, your
 * connection looks the same as any other app on the phone.
 */
final class PrivateBrowserView extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final WebView web;
    private final LinearLayout bar;
    private final View progress;
    private final TextView title;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;

    /** A web address stays one (https added if missing), anything else becomes a DuckDuckGo search. */
    static String addressFor(String input) {
        String t = input == null ? "" : input.trim();
        if (t.isEmpty()) {
            return "https://duckduckgo.com/";
        }
        boolean spaces = t.contains(" ");
        if (!spaces && (t.startsWith("https://") || t.startsWith("http://"))) {
            return t;
        }
        if (!spaces && t.contains(".") && !t.endsWith(".") && t.indexOf('.') > 0) {
            return "https://" + t;
        }
        try {
            return "https://duckduckgo.com/?q=" + URLEncoder.encode(t, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return "https://duckduckgo.com/";
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    PrivateBrowserView(final NovaActivity host, String start) {
        super(host);
        this.host = host;
        setBackgroundColor(0xFF000000);
        setClickable(true);

        web = new WebView(host);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(true);
        ws.setSaveFormData(false);
        ws.setGeolocationEnabled(false);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setBackgroundColor(0xFF000000);

        int barH = Theme.dp(host, 48);
        addView(web, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        ((LayoutParams) web.getLayoutParams()).topMargin = barH;

        bar = new LinearLayout(host);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Theme.BG);
        TextView back = barButton("‹", 24f);
        back.setOnClickListener(v -> {
            if (web.canGoBack()) {
                web.goBack();
            } else {
                host.hideOverlay();
            }
        });
        bar.addView(back, new LinearLayout.LayoutParams(Theme.dp(host, 52), ViewGroup.LayoutParams.MATCH_PARENT));
        title = new TextView(host);
        title.setText("PRIVATE");
        title.setTypeface(Theme.MONO);
        title.setTextSize(12f);
        title.setLetterSpacing(0.3f);
        title.setTextColor(Theme.ACCENT);
        title.setSingleLine(true);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = barButton("✕", 20f);
        close.setOnClickListener(v -> host.hideOverlay());
        bar.addView(close, new LinearLayout.LayoutParams(Theme.dp(host, 52), ViewGroup.LayoutParams.MATCH_PARENT));
        addView(bar, new LayoutParams(LayoutParams.MATCH_PARENT, barH, Gravity.TOP));

        progress = new View(host);
        progress.setBackgroundColor(Theme.ACCENT);
        addView(progress, new LayoutParams(0, Theme.dp(host, 3), Gravity.TOP | Gravity.START));
        ((LayoutParams) progress.getLayoutParams()).topMargin = barH;

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                if (!"https".equals(scheme) && !"http".equals(scheme)) {
                    return true; // app links like intent:// stay out
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                progress.setVisibility(VISIBLE);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                progress.setVisibility(GONE);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                ViewGroup.LayoutParams lp = progress.getLayoutParams();
                lp.width = getWidth() * p / 100;
                progress.setLayoutParams(lp);
            }

            @Override
            public void onReceivedTitle(WebView v, String t) {
                if (t != null && !t.isEmpty()) {
                    title.setText(t);
                    title.setLetterSpacing(0.05f);
                }
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = callback;
                addView(view, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                bar.setVisibility(GONE);
            }

            @Override
            public void onHideCustomView() {
                leaveFullscreen();
            }
        });
        web.loadUrl(addressFor(start));
    }

    private TextView barButton(String s, float size) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private void leaveFullscreen() {
        if (customView == null) {
            return;
        }
        removeView(customView);
        customView = null;
        bar.setVisibility(VISIBLE);
        if (customCallback != null) {
            customCallback.onCustomViewHidden();
            customCallback = null;
        }
    }

    @Override
    public boolean onBack() {
        if (customView != null) {
            leaveFullscreen();
            return true;
        }
        if (web.canGoBack()) {
            web.goBack();
            return true;
        }
        return false;
    }

    @Override
    protected void onDetachedFromWindow() {
        // closing the window ends the session: nothing is kept
        leaveFullscreen();
        web.loadUrl("about:blank");
        web.stopLoading();
        web.clearHistory();
        web.clearCache(true);
        web.clearFormData();
        WebStorage.getInstance().deleteAllData();
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        web.destroy();
        super.onDetachedFromWindow();
    }
}
