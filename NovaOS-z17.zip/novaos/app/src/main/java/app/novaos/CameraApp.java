package app.novaos;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

/**
 * NOVA's own camera: a live preview, a shutter, front and back cameras and flash. Photos are saved to Pictures/NOVA.
 * If anything about the camera goes wrong, NOVA opens the stock camera instead. STOCK does that on purpose.
 */
final class CameraApp extends Game {
    private final FrameLayout holder;
    private final TextureView tv;
    private final TextView status;
    private final TextView flashBtn;
    private HandlerThread thread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private CaptureRequest.Builder previewReq;
    private Size previewSize;
    private int sensorOrientation;
    private boolean front;
    private boolean flashAuto;
    private boolean wanted;
    private boolean opening;
    private boolean failed;

    CameraApp(NovaActivity host) {
        super(host);
        setBackgroundColor(0xFF000000);
        holder = new FrameLayout(host);
        addView(holder, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        tv = new TextureView(host);
        holder.addView(tv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        status = label("", 12f, Theme.DIM);
        addView(status, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        // shutter
        View shutter = new View(host);
        android.graphics.drawable.GradientDrawable ring = new android.graphics.drawable.GradientDrawable();
        ring.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        ring.setColor(0xFFFFFFFF);
        ring.setStroke(dp(5), 0x99FFFFFF);
        shutter.setBackground(ring);
        shutter.setClickable(true);
        shutter.setOnClickListener(v -> capture());
        LayoutParams sp = new LayoutParams(dp(74), dp(74), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = dp(46);
        addView(shutter, sp);

        TextView flip = side("⟲", () -> {
            front = !front;
            closeCamera();
            openCamera();
        });
        LayoutParams fp = new LayoutParams(dp(56), dp(56), Gravity.BOTTOM | Gravity.END);
        fp.setMargins(0, 0, dp(30), dp(55));
        addView(flip, fp);

        flashBtn = side("⚡ OFF", () -> {
            flashAuto = !flashAuto;
            flashBtn_set();
        });
        flashBtn.setTextSize(11f);
        LayoutParams lp = new LayoutParams(dp(70), dp(56), Gravity.BOTTOM | Gravity.START);
        lp.setMargins(dp(20), 0, 0, dp(55));
        addView(flashBtn, lp);

        TextView stock = label("STOCK", 10f, Theme.TEXT);
        stock.setPadding(dp(14), dp(10), dp(14), dp(10));
        stock.setBackground(Theme.rounded(0x66000000, 12f, host));
        stock.setClickable(true);
        stock.setOnClickListener(v -> openStock());
        LayoutParams stp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        stp.topMargin = dp(18);
        addView(stock, stp);

        host.ask(new String[] {Manifest.permission.CAMERA}, () -> {
            wanted = true;
            startWhenReady();
        }, () -> status.setText("NOVA needs the camera permission"));
    }

    private TextView side(String s, final Runnable action) {
        TextView t = label(s, 22f, Theme.TEXT);
        t.setBackground(Theme.rounded(0x66000000, 28f, host));
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    private void flashBtn_set() {
        flashBtn.setText(flashAuto ? "⚡ AUTO" : "⚡ OFF");
    }

    @Override
    String title() {
        return "CAMERA";
    }

    // ------------------------------------------------------------------ opening

    private void startWhenReady() {
        if (tv.isAvailable()) {
            openCamera();
        } else {
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override
                public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                    if (wanted) {
                        openCamera();
                    }
                }

                @Override
                public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
                }

                @Override
                public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                    return true;
                }

                @Override
                public void onSurfaceTextureUpdated(SurfaceTexture st) {
                }
            });
        }
    }

    private void giveUp(String why) {
        if (failed) {
            return;
        }
        failed = true;
        h.post(() -> {
            host.toast(why + ". Opening the stock camera.");
            openStock();
        });
    }

    private void openStock() {
        closeCamera();
        try {
            Intent i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            host.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
            } catch (Exception e2) {
                host.toast("No camera app found");
            }
        }
        host.hideOverlay();
    }

    private void openCamera() {
        if (opening || device != null || !wanted) {
            return;
        }
        opening = true;
        status.setText("");
        try {
            CameraManager cm = (CameraManager) host.getSystemService(android.content.Context.CAMERA_SERVICE);
            String id = null;
            CameraCharacteristics chars = null;
            for (String cid : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(cid);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == (front ? CameraCharacteristics.LENS_FACING_FRONT
                        : CameraCharacteristics.LENS_FACING_BACK)) {
                    id = cid;
                    chars = c;
                    break;
                }
            }
            if (id == null) {
                opening = false;
                if (front) {
                    front = false;
                    host.toast("No front camera");
                    openCamera();
                } else {
                    giveUp("No camera found");
                }
                return;
            }
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = so == null ? 90 : so;
            previewSize = choose(map.getOutputSizes(SurfaceTexture.class), 1920 * 1440, null);
            Size jpeg = choose(map.getOutputSizes(ImageFormat.JPEG), 12_000_000, previewSize);
            fit();
            if (reader != null) {
                reader.close();
            }
            reader = ImageReader.newInstance(jpeg.getWidth(), jpeg.getHeight(), ImageFormat.JPEG, 2);
            if (thread == null) {
                thread = new HandlerThread("nova-camera");
                thread.start();
                bg = new Handler(thread.getLooper());
            }
            reader.setOnImageAvailableListener(r -> {
                Image img = r.acquireLatestImage();
                if (img == null) {
                    return;
                }
                try {
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    save(bytes);
                } finally {
                    img.close();
                }
            }, bg);
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    device = camera;
                    opening = false;
                    startPreview();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    device = null;
                    opening = false;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    device = null;
                    opening = false;
                    giveUp("Camera error " + error);
                }
            }, bg);
        } catch (SecurityException e) {
            opening = false;
            status.setText("NOVA needs the camera permission");
        } catch (Throwable t) {
            opening = false;
            giveUp("Camera problem");
        }
    }

    /** The biggest size close to the target shape that is not bigger than the area limit. */
    private static Size choose(Size[] sizes, int maxArea, Size like) {
        Size best = null;
        double wantRatio = like == null ? 4.0 / 3.0 : like.getWidth() / (double) like.getHeight();
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            double ratio = s.getWidth() / (double) s.getHeight();
            if (area <= maxArea && Math.abs(ratio - wantRatio) < 0.03) {
                if (best == null || area > (long) best.getWidth() * best.getHeight()) {
                    best = s;
                }
            }
        }
        if (best == null) {
            for (Size s : sizes) {
                long area = (long) s.getWidth() * s.getHeight();
                if (area <= maxArea && (best == null || area > (long) best.getWidth() * best.getHeight())) {
                    best = s;
                }
            }
        }
        return best == null ? sizes[sizes.length - 1] : best;
    }

    /** Sizes the preview so it keeps its shape, as big as fits. */
    private void fit() {
        h.post(() -> {
            int hw = holder.getWidth();
            int hh = holder.getHeight();
            if (hw == 0 || hh == 0 || previewSize == null) {
                return;
            }
            boolean turned = sensorOrientation % 180 == 90;
            double ratio = turned ? previewSize.getHeight() / (double) previewSize.getWidth()
                    : previewSize.getWidth() / (double) previewSize.getHeight(); // width / height on screen
            int w = hw;
            int hgt = (int) (w / ratio);
            if (hgt > hh) {
                hgt = hh;
                w = (int) (hh * ratio);
            }
            tv.setLayoutParams(new FrameLayout.LayoutParams(w, hgt, Gravity.CENTER));
            tv.setScaleX(front ? -1f : 1f);
        });
    }

    private void startPreview() {
        try {
            SurfaceTexture st = tv.getSurfaceTexture();
            if (st == null || device == null) {
                return;
            }
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            final Surface ps = new Surface(st);
            previewReq = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewReq.addTarget(ps);
            previewReq.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            device.createCaptureSession(Arrays.asList(ps, reader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession s) {
                            if (device == null) {
                                return;
                            }
                            session = s;
                            try {
                                s.setRepeatingRequest(previewReq.build(), null, bg);
                            } catch (Throwable t) {
                                giveUp("Preview problem");
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession s) {
                            giveUp("Camera would not start");
                        }
                    }, bg);
        } catch (Throwable t) {
            giveUp("Camera problem");
        }
    }

    // ------------------------------------------------------------------ taking and saving

    private int displayDegrees() {
        int r = host.getWindowManager().getDefaultDisplay().getRotation();
        return r == Surface.ROTATION_90 ? 90 : r == Surface.ROTATION_180 ? 180 : r == Surface.ROTATION_270 ? 270 : 0;
    }

    private void capture() {
        if (session == null || device == null) {
            return;
        }
        try {
            CaptureRequest.Builder cr = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            cr.addTarget(reader.getSurface());
            cr.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            cr.set(CaptureRequest.CONTROL_AE_MODE, flashAuto ? CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                    : CaptureRequest.CONTROL_AE_MODE_ON);
            int deg = displayDegrees();
            int jpegRot = front ? (sensorOrientation + deg) % 360 : (sensorOrientation - deg + 360) % 360;
            cr.set(CaptureRequest.JPEG_ORIENTATION, jpegRot);
            session.capture(cr.build(), null, bg);
            host.buzz(25);
            Sfx.play(Sfx.CLICK);
            // a quick white flash over the preview
            final View flash = new View(host);
            flash.setBackgroundColor(0xFFFFFFFF);
            addView(flash, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            flash.setAlpha(0.7f);
            flash.animate().alpha(0f).setDuration(260).withEndAction(() -> removeView(flash)).start();
        } catch (Throwable t) {
            host.toast("Could not take the photo");
        }
    }

    private void save(byte[] bytes) {
        String name = "NOVA_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NOVA");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri u = host.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (u == null) {
                    throw new IllegalStateException("no uri");
                }
                try (OutputStream out = host.getContentResolver().openOutputStream(u)) {
                    out.write(bytes);
                }
                v.clear();
                v.put(MediaStore.Images.Media.IS_PENDING, 0);
                host.getContentResolver().update(u, v, null, null);
            } else {
                File dir = host.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                File f = new File(dir, name);
                try (FileOutputStream out = new FileOutputStream(f)) {
                    out.write(bytes);
                }
            }
            h.post(() -> host.toast("Saved to Pictures/NOVA"));
        } catch (Throwable t) {
            h.post(() -> host.toast("Could not save the photo"));
        }
    }

    // ------------------------------------------------------------------ closing

    private void closeCamera() {
        try {
            if (session != null) {
                session.close();
            }
        } catch (Throwable ignored) {
            // already closed
        }
        session = null;
        try {
            if (device != null) {
                device.close();
            }
        } catch (Throwable ignored) {
            // already closed
        }
        device = null;
        opening = false;
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!wanted || failed) {
            return;
        }
        if (hasFocus) {
            if (device == null && tv.isAvailable()) {
                openCamera();
            }
        } else {
            closeCamera();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        wanted = false;
        closeCamera();
        if (reader != null) {
            reader.close();
            reader = null;
        }
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        super.onDetachedFromWindow();
    }
}
