package app.novaos;

/**
 * Evaluates maths like 2+3*(4-1)^2, sqrt(16), sin(30), 5%, pi. Angles for sin, cos and tan are in degrees.
 * Throws IllegalArgumentException with a short message when the text is not valid.
 */
final class Expr {
    private final String s;
    private int pos;

    private Expr(String s) {
        this.s = s.replace(" ", "").replace("×", "*").replace("÷", "/").replace("−", "-").replace(",", ".").toLowerCase();
    }

    static double eval(String text) {
        Expr e = new Expr(text);
        if (e.s.isEmpty()) {
            throw new IllegalArgumentException("empty");
        }
        double v = e.parseSum();
        if (e.pos < e.s.length()) {
            throw new IllegalArgumentException("unexpected '" + e.s.charAt(e.pos) + "'");
        }
        return v;
    }

    /** 12.0 shows as 12, 0.1+0.2 shows as 0.3 */
    static String format(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return "error";
        }
        if (v == Math.rint(v) && Math.abs(v) < 1e15) {
            return String.valueOf((long) v);
        }
        String t = String.format(java.util.Locale.US, "%.10g", v);
        if (t.contains("e")) {
            return t;
        }
        t = t.replaceAll("0+$", "").replaceAll("\\.$", "");
        return t;
    }

    private boolean eat(char c) {
        if (pos < s.length() && s.charAt(pos) == c) {
            pos++;
            return true;
        }
        return false;
    }

    private double parseSum() {
        double v = parseProduct();
        while (true) {
            if (eat('+')) {
                v += parseProduct();
            } else if (eat('-')) {
                v -= parseProduct();
            } else {
                return v;
            }
        }
    }

    private double parseProduct() {
        double v = parsePower();
        while (true) {
            if (eat('*')) {
                v *= parsePower();
            } else if (eat('/')) {
                double d = parsePower();
                if (d == 0) {
                    throw new IllegalArgumentException("divide by zero");
                }
                v /= d;
            } else {
                return v;
            }
        }
    }

    private double parsePower() {
        double v = parseUnary();
        if (eat('^')) {
            v = Math.pow(v, parsePower()); // right to left
        }
        return v;
    }

    private double parseUnary() {
        if (eat('-')) {
            return -parseUnary();
        }
        if (eat('+')) {
            return parseUnary();
        }
        return parsePostfix();
    }

    private double parsePostfix() {
        double v = parseAtom();
        while (true) {
            if (eat('%')) {
                v /= 100.0;
            } else if (eat('!')) {
                v = factorial(v);
            } else {
                return v;
            }
        }
    }

    private double parseAtom() {
        if (eat('(')) {
            double v = parseSum();
            if (!eat(')')) {
                throw new IllegalArgumentException("missing )");
            }
            return v;
        }
        int start = pos;
        if (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) {
                pos++;
            }
            try {
                return Double.parseDouble(s.substring(start, pos));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("bad number");
            }
        }
        while (pos < s.length() && Character.isLetter(s.charAt(pos))) {
            pos++;
        }
        String name = s.substring(start, pos);
        if (name.isEmpty()) {
            throw new IllegalArgumentException(pos < s.length() ? "unexpected '" + s.charAt(pos) + "'" : "unfinished");
        }
        switch (name) {
            case "pi":
                return Math.PI;
            case "e":
                return Math.E;
            default:
                break;
        }
        if (!eat('(')) {
            throw new IllegalArgumentException("unknown '" + name + "'");
        }
        double a = parseSum();
        if (!eat(')')) {
            throw new IllegalArgumentException("missing )");
        }
        switch (name) {
            case "sqrt":
                return Math.sqrt(a);
            case "sin":
                return Math.sin(Math.toRadians(a));
            case "cos":
                return Math.cos(Math.toRadians(a));
            case "tan":
                return Math.tan(Math.toRadians(a));
            case "ln":
                return Math.log(a);
            case "log":
                return Math.log10(a);
            case "abs":
                return Math.abs(a);
            case "round":
                return Math.rint(a);
            case "floor":
                return Math.floor(a);
            case "ceil":
                return Math.ceil(a);
            default:
                throw new IllegalArgumentException("unknown '" + name + "'");
        }
    }

    private static double factorial(double v) {
        if (v < 0 || v != Math.rint(v) || v > 170) {
            throw new IllegalArgumentException("bad factorial");
        }
        double r = 1;
        for (int i = 2; i <= (int) v; i++) {
            r *= i;
        }
        return r;
    }
}
