package app.novaos;

import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * A dim, glowing clock for when the phone is charging and left alone. It drifts a little every minute so the screen
 * is never burned by a fixed image. Touch the screen to leave.
 */
final class NightClock extends FrameLayout {
    private final NovaActivity host;
    private final TextView time;
    private final TextView date;
    private final TextView info;
    private final LinearLayout box;
    private final float previousBrightness;
    private int tick;
    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            update();
            postDelayed(this, 1000);
        }
    };

    NightClock(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(Color.BLACK);
        setClickable(true);
        setOnClickListener(v -> dismiss());

        box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        time = new TextView(host);
        time.setTypeface(Theme.DIGITAL);
        time.setTextSize(84f);
        time.setTextColor((Theme.ACCENT & 0x00FFFFFF) | 0xAA000000);
        time.setShadowLayer(Theme.dp(host, 14), 0, 0, Theme.ACCENT);
        box.addView(time);

        date = new TextView(host);
        date.setTypeface(Theme.MONO);
        date.setTextSize(14f);
        date.setLetterSpacing(0.25f);
        date.setTextColor(0x66FFFFFF);
        date.setGravity(Gravity.CENTER);
        box.addView(date);

        info = new TextView(host);
        info.setTypeface(Theme.MONO);
        info.setTextSize(13f);
        info.setLetterSpacing(0.15f);
        info.setTextColor(0x55FFFFFF);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, Theme.dp(host, 14), 0, 0);
        box.addView(info);

        addView(box, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        WindowManager.LayoutParams wl = host.getWindow().getAttributes();
        previousBrightness = wl.screenBrightness;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        host.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams wl = host.getWindow().getAttributes();
        wl.screenBrightness = 0.04f;
        host.getWindow().setAttributes(wl);
        setAlpha(0f);
        animate().alpha(1f).setDuration(900).start();
        host.tip("nightclock");
        loop.run();
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(loop);
        host.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams wl = host.getWindow().getAttributes();
        wl.screenBrightness = previousBrightness;
        host.getWindow().setAttributes(wl);
        super.onDetachedFromWindow();
    }

    private void update() {
        Date now = new Date();
        time.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        date.setText(new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(now).toUpperCase());
        info.setText(host.batteryLevel() + "%" + (host.charging() ? "  ⚡ charging" : ""));
        if (!host.charging()) {
            dismiss();
            return;
        }
        // drift slowly so no pixel stays lit forever
        if (tick++ % 60 == 0) {
            float dx = (float) (Math.random() - 0.5) * Theme.dp(host, 90);
            float dy = (float) (Math.random() - 0.5) * Theme.dp(host, 160);
            box.animate().translationX(dx).translationY(dy).setDuration(4000).start();
        }
    }

    void dismiss() {
        if (getParent() == null) {
            return;
        }
        host.nightClockGone();
        animate().alpha(0f).setDuration(300).withEndAction(() -> {
            if (getParent() != null) {
                host.root.removeView(this);
            }
        }).start();
    }
}
