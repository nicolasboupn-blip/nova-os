package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Start, stop, lap. Keeps counting when you leave the page, and when the home screen is rebuilt. */
final class StopwatchPage extends LinearLayout {
    private static boolean running;
    private static long accum;
    private static long startedAt;
    private static final List<Long> laps = new ArrayList<>();

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView time;
    private final TextView lapsText;
    private final TextView startBtn;
    private final TextView lapBtn;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                refresh();
                handler.postDelayed(this, running ? 45 : 400);
            } else {
                handler.postDelayed(this, 500);
            }
        }
    };

    StopwatchPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);

        time = new TextView(host);
        time.setTypeface(Theme.MONO);
        time.setTextSize(34f);
        time.setTextColor(Theme.TEXT);
        time.setGravity(Gravity.CENTER);
        time.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        addView(time, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        startBtn = pill("START");
        startBtn.setOnClickListener(v -> toggle());
        lapBtn = pill("LAP");
        lapBtn.setOnClickListener(v -> lap());
        TextView reset = pill("RESET");
        reset.setOnClickListener(v -> reset());
        for (TextView b : new TextView[] {startBtn, lapBtn, reset}) {
            LayoutParams lp = new LayoutParams(0, Theme.dp(host, 38), 1f);
            lp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
            row.addView(b, lp);
        }
        LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        rp.topMargin = Theme.dp(host, 8);
        addView(row, rp);

        lapsText = new TextView(host);
        lapsText.setTypeface(Theme.MONO);
        lapsText.setTextSize(11f);
        lapsText.setTextColor(Theme.DIM);
        lapsText.setGravity(Gravity.CENTER);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        lp.topMargin = Theme.dp(host, 8);
        addView(lapsText, lp);
        refresh();
    }

    private TextView pill(String s) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(11f);
        t.setLetterSpacing(0.1f);
        t.setTextColor(Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setClickable(true);
        Theme.ripple(t);
        return t;
    }

    private static long elapsed() {
        return running ? accum + (SystemClock.elapsedRealtime() - startedAt) : accum;
    }

    private void toggle() {
        if (running) {
            accum += SystemClock.elapsedRealtime() - startedAt;
            running = false;
        } else {
            startedAt = SystemClock.elapsedRealtime();
            running = true;
            Badges.unlock(host, "stopwatch");
        }
        refresh();
    }

    private void lap() {
        if (!running) {
            return;
        }
        laps.add(elapsed());
        host.buzz(15);
        refresh();
    }

    private void reset() {
        running = false;
        accum = 0;
        laps.clear();
        refresh();
    }

    private void refresh() {
        time.setText(TimeFormat.precise(elapsed()));
        startBtn.setText(running ? "STOP" : accum > 0 ? "RESUME" : "START");
        lapBtn.setAlpha(running ? 1f : 0.35f);
        StringBuilder sb = new StringBuilder();
        int n = laps.size();
        for (int i = Math.max(0, n - 3); i < n; i++) {
            long split = laps.get(i) - (i == 0 ? 0 : laps.get(i - 1));
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append("LAP ").append(i + 1).append("   ").append(TimeFormat.precise(split))
                    .append("   ").append(TimeFormat.precise(laps.get(i)));
        }
        lapsText.setText(sb.length() == 0 ? "tap LAP while running" : sb.toString());
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
