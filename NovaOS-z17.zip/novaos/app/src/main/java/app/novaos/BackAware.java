package app.novaos;

/** An overlay that wants the back button first (for example a web page that can go back). */
interface BackAware {
    /** Return true if the back press was used up. */
    boolean onBack();
}
