package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Twenty seconds. Glowing dots pop up and shrink away. Tap them before they vanish. */
final class GameWhack extends Game {
    private static final long TIME = 20_000L;

    GameWhack(NovaActivity host) {
        super(host);
        addView(new Field(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    @Override
    String title() {
        return "WHACK";
    }

    private static final class Target {
        float x, y, r;
        long born;
        long life;
        long hitAt; // 0 while alive
    }

    private final class Field extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();
        private final List<Target> targets = new ArrayList<>();
        private int state; // 0 idle, 1 running, 2 over
        private int score;
        private long start;
        private long nextSpawn;

        Field(Context c) {
            super(c);
            p.setTypeface(Typeface.MONOSPACE);
            p.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN) {
                return true;
            }
            if (state != 1) {
                if (state == 0 || SystemClock.elapsedRealtime() - start > TIME + 600) {
                    begin();
                }
                return true;
            }
            long now = SystemClock.elapsedRealtime();
            for (int i = targets.size() - 1; i >= 0; i--) {
                Target t = targets.get(i);
                if (t.hitAt != 0) {
                    continue;
                }
                float k = 1f - (now - t.born) / (float) t.life;
                float rr = t.r * Math.max(0.35f, k) + dp(14);
                float ddx = e.getX() - t.x;
                float ddy = e.getY() - t.y;
                if (ddx * ddx + ddy * ddy <= rr * rr) {
                    t.hitAt = now;
                    score++;
                    host.buzz(10);
                    break;
                }
            }
            return true;
        }

        private void begin() {
            targets.clear();
            score = 0;
            state = 1;
            start = SystemClock.elapsedRealtime();
            nextSpawn = start + 400;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = SystemClock.elapsedRealtime();
            float w = getWidth();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.TEXT);
            p.setTextSize(26 * d);
            c.drawText(String.valueOf(score), w / 2f, dp(52), p);

            if (state == 1) {
                long elapsed = now - start;
                if (elapsed >= TIME) {
                    state = 2;
                    if (score > best("whack", 0)) {
                        saveBest("whack", score);
                    }
                    if (score >= 20) {
                        Badges.unlock(host, "whack");
                    }
                } else {
                    if (now >= nextSpawn) {
                        Target t = new Target();
                        t.r = dp(34);
                        t.x = dp(40) + rnd.nextFloat() * (w - dp(80));
                        t.y = dp(110) + rnd.nextFloat() * (getHeight() - dp(180));
                        t.born = now;
                        t.life = Math.max(600, 1000 - score * 10);
                        targets.add(t);
                        nextSpawn = now + Math.max(380, 700 - score * 8);
                    }
                    p.setColor(Theme.DIM);
                    p.setTextSize(12 * d);
                    c.drawText(String.format(java.util.Locale.US, "%.1f s", (TIME - elapsed) / 1000f), w / 2f, dp(74), p);
                    float frac = elapsed / (float) TIME;
                    p.setColor(Theme.ACCENT);
                    c.drawRect(0, 0, w * (1f - frac), dp(4), p);
                }
            }

            for (int i = targets.size() - 1; i >= 0; i--) {
                Target t = targets.get(i);
                if (t.hitAt != 0) {
                    float k = (now - t.hitAt) / 260f;
                    if (k >= 1f) {
                        targets.remove(i);
                        continue;
                    }
                    p.setColor((Theme.ACCENT & 0x00FFFFFF) | ((int) (200 * (1f - k)) << 24));
                    c.drawCircle(t.x, t.y, t.r * (1f + k * 1.2f), p);
                    continue;
                }
                float k = 1f - (now - t.born) / (float) t.life;
                if (k <= 0f) {
                    targets.remove(i);
                    continue;
                }
                float rr = t.r * Math.max(0.35f, k);
                p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x44000000);
                c.drawCircle(t.x, t.y, rr * 1.6f, p);
                p.setColor(Theme.ACCENT);
                c.drawCircle(t.x, t.y, rr, p);
                p.setColor(0xFFFFFFFF);
                c.drawCircle(t.x, t.y, rr * 0.4f, p);
            }

            if (state == 0) {
                p.setColor(Theme.TEXT);
                p.setTextSize(20 * d);
                c.drawText("TAP TO START", w / 2f, getHeight() / 2f, p);
                p.setColor(Theme.DIM);
                p.setTextSize(12 * d);
                c.drawText("BEST " + best("whack", 0), w / 2f, getHeight() / 2f + dp(28), p);
            } else if (state == 2) {
                p.setColor(Theme.TEXT);
                p.setTextSize(24 * d);
                c.drawText("TIME! " + score, w / 2f, getHeight() / 2f, p);
                p.setColor(Theme.ACCENT);
                p.setTextSize(12 * d);
                c.drawText("BEST " + best("whack", 0) + " · tap to retry", w / 2f, getHeight() / 2f + dp(28), p);
            }
            if (state == 1 || !targets.isEmpty()) {
                postInvalidateOnAnimation();
            }
        }
    }
}
