package app.novaos;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Days left until your events. Add with +, hold an event to delete it. Past events disappear the next day. */
final class CountdownPage extends LinearLayout {
    private static final String KEY = "cd_events";

    private static final class Event {
        String name;
        LocalDate date;
    }

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView big;
    private final TextView bigName;
    private final LinearLayout list;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                render();
            }
            ui.postDelayed(this, 60_000);
        }
    };

    CountdownPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(host);
        left.setOrientation(VERTICAL);
        big = new TextView(host);
        big.setTypeface(Theme.MONO);
        big.setTextSize(30f);
        big.setTextColor(Theme.TEXT);
        big.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        bigName = new TextView(host);
        bigName.setTypeface(Theme.MONO);
        bigName.setTextSize(11f);
        bigName.setTextColor(Theme.ACCENT);
        bigName.setSingleLine(true);
        left.addView(big);
        left.addView(bigName);
        head.addView(left, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        TextView add = new TextView(host);
        add.setText("+");
        add.setTextSize(22f);
        add.setTextColor(Theme.ACCENT);
        add.setGravity(Gravity.CENTER);
        add.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        add.setClickable(true);
        Theme.ripple(add);
        add.setOnClickListener(v -> askName());
        head.addView(add, new LayoutParams(Theme.dp(host, 48), Theme.dp(host, 44)));
        addView(head, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        lp.topMargin = Theme.dp(host, 8);
        addView(list, lp);
        render();
    }

    private List<Event> events() {
        List<Event> out = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (String line : Prefs.getString(KEY, "").split("\n")) {
            int bar = line.lastIndexOf('|');
            if (bar <= 0) {
                continue;
            }
            try {
                Event e = new Event();
                e.name = line.substring(0, bar);
                e.date = LocalDate.parse(line.substring(bar + 1));
                if (!e.date.isBefore(today)) {
                    out.add(e);
                }
            } catch (RuntimeException ignored) {
                // skip a broken line
            }
        }
        Collections.sort(out, (a, b) -> a.date.compareTo(b.date));
        return out;
    }

    private void save(List<Event> events) {
        StringBuilder sb = new StringBuilder();
        for (Event e : events) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(e.name.replace("\n", " ").replace("|", "/")).append('|').append(e.date);
        }
        Prefs.putString(KEY, sb.toString());
    }

    private void render() {
        List<Event> events = events();
        list.removeAllViews();
        if (events.isEmpty()) {
            big.setText("--");
            bigName.setText("tap + to add an event");
            return;
        }
        Event first = events.get(0);
        long days = ChronoUnit.DAYS.between(LocalDate.now(), first.date);
        big.setText(days == 0 ? "TODAY!" : days + (days == 1 ? " day" : " days"));
        bigName.setText(first.name);
        for (int i = 1; i < events.size() && i <= 3; i++) {
            final Event e = events.get(i);
            long d = ChronoUnit.DAYS.between(LocalDate.now(), e.date);
            TextView row = new TextView(host);
            row.setText(String.format("%-3s %s", d + "d", e.name));
            row.setTypeface(Theme.MONO);
            row.setTextSize(11f);
            row.setTextColor(Theme.DIM);
            row.setSingleLine(true);
            row.setPadding(0, Theme.dp(host, 4), 0, Theme.dp(host, 4));
            list.addView(row);
        }
        // hold the big number to delete that event
        big.setOnLongClickListener(v -> confirmDelete(first));
        bigName.setOnLongClickListener(v -> confirmDelete(first));
    }

    private boolean confirmDelete(final Event e) {
        new AlertDialog.Builder(host)
                .setTitle("Delete \"" + e.name + "\"?")
                .setNegativeButton("Keep", null)
                .setPositiveButton("Delete", (d, w) -> {
                    List<Event> all = events();
                    for (int i = 0; i < all.size(); i++) {
                        if (all.get(i).name.equals(e.name) && all.get(i).date.equals(e.date)) {
                            all.remove(i);
                            break;
                        }
                    }
                    save(all);
                    render();
                }).show();
        return true;
    }

    private void askName() {
        final EditText input = new EditText(host);
        input.setHint("for example Birthday");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(host)
                .setTitle("Event name")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Pick date", (d, w) -> {
                    final String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        return;
                    }
                    LocalDate t = LocalDate.now().plusDays(7);
                    new DatePickerDialog(host, (view, y, m, day) -> {
                        List<Event> all = events();
                        Event e = new Event();
                        e.name = name;
                        e.date = LocalDate.of(y, m + 1, day);
                        all.add(e);
                        Collections.sort(all, (a, b) -> a.date.compareTo(b.date));
                        save(all);
                        render();
                    }, t.getYear(), t.getMonthValue() - 1, t.getDayOfMonth()).show();
                }).show();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
