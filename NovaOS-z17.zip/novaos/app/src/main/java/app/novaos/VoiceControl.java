package app.novaos;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * "Hey Nova ..." voice commands. It only listens while NOVA is on screen and only if you switched it on in Settings.
 * Android shows its own microphone dot while it is listening. Say "Hey Nova" followed by what you want:
 * open camera, set a timer for 5 minutes, set an alarm for 7:30, play music, next song, lock the phone,
 * go home, open terminal, flashlight on, do not disturb on, what time is it, battery, flip a coin, roll a dice, spin the wheel, roulette.
 */
final class VoiceControl implements RecognitionListener {
    private static final Pattern WAKE = Pattern.compile("\\b(?:hey|hay|hi|okay|ok)[ ,]+(?:nova|noba|novo|nover|no va|nova's)\\b");
    private static final Map<String, Integer> WORDS = new HashMap<>();

    static {
        String[] w = {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
            "twelve", "fifteen", "twenty", "thirty", "forty", "forty five", "sixty"};
        int[] v = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 20, 30, 40, 45, 60};
        for (int i = 0; i < w.length; i++) {
            WORDS.put(w[i], v[i]);
        }
    }

    private final NovaActivity host;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private SpeechRecognizer rec;
    private TextToSpeech tts;
    private boolean ttsReady;
    private volatile boolean speaking;
    private long speakStart;
    private static long lastBanner;
    private boolean running;
    private long awaitUntil;

    VoiceControl(NovaActivity host) {
        this.host = host;
    }

    static boolean available(Context c) {
        return SpeechRecognizer.isRecognitionAvailable(c);
    }

    boolean isRunning() {
        return running;
    }

    void start() {
        if (running || !available(host)) {
            return;
        }
        running = true;
        if (System.currentTimeMillis() - lastBanner > 5 * 60_000L) {
            lastBanner = System.currentTimeMillis();
            Banner.show(host, "🎙  Hey Nova is listening", 1800);
        }
        startVoice();
        listen();
    }

    /** Nova's own voice: the phone's text-to-speech, a little lower and calmer than the default. */
    private void startVoice() {
        if (!Prefs.voiceSpeak() || tts != null) {
            return;
        }
        try {
            tts = new TextToSpeech(host.getApplicationContext(), status -> {
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    ttsReady = false;
                    return;
                }
                int r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
                tts.setPitch(0.88f);
                tts.setSpeechRate(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        speaking = true;
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        speaking = false;
                    }

                    @Override
                    public void onError(String utteranceId) {
                        speaking = false;
                    }
                });
                ttsReady = true;
            });
        } catch (RuntimeException e) {
            tts = null;
            ttsReady = false;
        }
    }

    private void speak(String text) {
        if (!Prefs.voiceSpeak() || !ttsReady || tts == null) {
            return;
        }
        // keep only words: the banner text has emoji and symbols
        String clean = text.replaceAll("[^\\p{L}\\p{N}:%., '!?-]", "").trim();
        if (clean.isEmpty()) {
            return;
        }
        speaking = true;
        speakStart = System.currentTimeMillis();
        try {
            if (tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova") != TextToSpeech.SUCCESS) {
                speaking = false;
            }
        } catch (RuntimeException e) {
            speaking = false;
        }
    }

    void stop() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (RuntimeException ignored) {
                // already gone
            }
            tts = null;
            ttsReady = false;
            speaking = false;
        }
        if (rec != null) {
            try {
                rec.cancel();
                rec.destroy();
            } catch (RuntimeException ignored) {
                // already gone
            }
            rec = null;
        }
    }

    private void listen() {
        if (!running) {
            return;
        }
        if (speaking && System.currentTimeMillis() - speakStart > 12_000) {
            speaking = false; // safety: never stay deaf if the voice engine stalls
        }
        if (speaking) {
            // do not listen to Nova's own voice, wait until it has finished
            h.postDelayed(this::listen, 400);
            return;
        }
        try {
            if (rec == null) {
                rec = SpeechRecognizer.createSpeechRecognizer(host);
                rec.setRecognitionListener(this);
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, host.getPackageName());
            rec.startListening(i);
        } catch (RuntimeException e) {
            recreateLater(2500);
        }
    }

    private void recreateLater(long ms) {
        if (rec != null) {
            try {
                rec.destroy();
            } catch (RuntimeException ignored) {
                // already gone
            }
            rec = null;
        }
        h.removeCallbacksAndMessages(null);
        h.postDelayed(this::listen, ms);
    }

    // ------------------------------------------------------------------ listener

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> list = results == null ? null
                : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list != null) {
            for (String raw : list) {
                if (process(raw)) {
                    break;
                }
            }
        }
        h.postDelayed(this::listen, 300);
    }

    @Override
    public void onError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                h.postDelayed(this::listen, 250);
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                running = false;
                Prefs.putBool(Prefs.K_VOICE, false);
                Banner.show(host, "🎙  Microphone not allowed, Hey Nova is off", 2600);
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                recreateLater(1500);
                break;
            default:
                recreateLater(2500);
                break;
        }
    }

    /** Returns true if the sentence was used. */
    private boolean process(String raw) {
        String text = raw.toLowerCase(Locale.ROOT).replace(".", "").replace(",", " ").replaceAll("\\s+", " ").trim();
        Matcher m = WAKE.matcher(text);
        if (m.find()) {
            String cmd = text.substring(m.end()).trim();
            if (cmd.isEmpty()) {
                awaitUntil = System.currentTimeMillis() + 7000;
                Banner.show(host, "🎙  Yes?", 2000);
                host.buzz(15);
                speak("Yes?");
            } else {
                handle(cmd);
            }
            return true;
        }
        if (System.currentTimeMillis() < awaitUntil && !text.isEmpty()) {
            awaitUntil = 0;
            handle(text);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ commands

    private static int number(String s) {
        s = s.trim();
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            Integer v = WORDS.get(s);
            return v == null ? -1 : v;
        }
    }

    private void say(String s) {
        host.buzz(20);
        Banner.show(host, "🎙  " + s, 2600);
        speak(s);
    }

    private void handle(String cmd) {
        cmd = cmd.replaceAll("^(please|can you|could you|would you)\\s+", "").trim();

        Matcher t = Pattern.compile("(?:set|start|make)\\s+(?:a\\s+|an\\s+)?timer\\s+(?:for\\s+)?([a-z0-9 ]+?)\\s*"
                + "(second|sec|minute|min|hour|hr)s?\\b").matcher(cmd);
        if (t.find()) {
            int n = number(t.group(1));
            if (n > 0) {
                String unit = t.group(2);
                int seconds = unit.startsWith("sec") ? n : unit.startsWith("min") ? n * 60 : n * 3600;
                Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    host.startActivity(i);
                    say("Timer set for " + n + " " + unit + (n == 1 ? "" : "s"));
                } catch (Exception e) {
                    say("No clock app for timers");
                }
                return;
            }
        }
        Matcher a = Pattern.compile("alarm\\s+(?:for|at)\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|a m|p m)?").matcher(cmd);
        if (a.find()) {
            int hour = Integer.parseInt(a.group(1));
            int minute = a.group(2) == null ? 0 : Integer.parseInt(a.group(2));
            String ap = a.group(3);
            if (ap != null) {
                boolean pm = ap.startsWith("p");
                if (pm && hour < 12) {
                    hour += 12;
                }
                if (!pm && hour == 12) {
                    hour = 0;
                }
            }
            if (hour < 24 && minute < 60) {
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, hour)
                        .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    host.startActivity(i);
                    say(String.format(Locale.US, "Alarm set for %02d:%02d", hour, minute));
                } catch (Exception e) {
                    say("No clock app for alarms");
                }
                return;
            }
        }
        if (cmd.matches(".*\\b(play|resume|pause|stop)\\b.*\\b(music|song|playing)\\b.*") || cmd.equals("play")
                || cmd.equals("pause")) {
            MusicHelper.toggle(host);
            say("Music");
            return;
        }
        if (cmd.matches(".*\\bnext (song|track)\\b.*") || cmd.equals("skip")) {
            MusicHelper.next(host);
            say("Next song");
            return;
        }
        if (cmd.matches(".*\\b(previous|last) (song|track)\\b.*")) {
            MusicHelper.previous(host);
            say("Previous song");
            return;
        }
        if (cmd.matches(".*\\block\\b.*")) {
            say("Locking");
            h.postDelayed(host::showLock, 600);
            return;
        }
        if (cmd.matches(".*\\b(go home|home screen)\\b.*") || cmd.equals("home")) {
            host.showHome();
            say("Home");
            return;
        }
        if (cmd.matches(".*\\bterminal\\b.*")) {
            host.showTerminal();
            say("Terminal");
            return;
        }
        if (cmd.matches(".*\\bnotes\\b.*")) {
            host.showNotes();
            say("Notes");
            return;
        }
        if (cmd.matches(".*\\bnova settings\\b.*") || cmd.matches("(open )?(the )?settings")) {
            host.showSettings();
            say("Settings");
            return;
        }
        Matcher fl = Pattern.compile("\\b(on|off)\\b.*\\b(flashlight|torch|light)\\b|\\b(flashlight|torch)\\b.*\\b(on|off)\\b")
                .matcher(cmd);
        if (fl.find()) {
            boolean on = !cmd.contains(" off");
            say(torch(on) ? "Flashlight " + (on ? "on" : "off") : "No flashlight");
            return;
        }
        if (cmd.matches(".*\\b(do not disturb|don't disturb|silent mode|quiet mode)\\b.*")) {
            boolean on = !cmd.contains(" off");
            try {
                NotificationManager nm = (NotificationManager) host.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm.isNotificationPolicyAccessGranted()) {
                    nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY
                            : NotificationManager.INTERRUPTION_FILTER_ALL);
                    say("Do not disturb " + (on ? "on" : "off"));
                } else {
                    say("Allow Do Not Disturb access first");
                }
            } catch (RuntimeException e) {
                say("Not available");
            }
            return;
        }
        if (cmd.matches(".*\\bwhat time\\b.*") || cmd.equals("time")) {
            Calendar c = Calendar.getInstance();
            say(String.format(Locale.US, "It is %02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));
            return;
        }
        if (cmd.matches(".*\\b(what day|what'?s the date|what is the date)\\b.*")) {
            say(new java.text.SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new java.util.Date()));
            return;
        }
        if (cmd.matches(".*\\bbattery\\b.*")) {
            say("Battery " + host.batteryLevel() + "%" + (host.charging() ? ", charging" : ""));
            return;
        }
        if (cmd.matches(".*\\bspin\\b.*") || cmd.matches(".*\\b(party )?wheel\\b.*")) {
            say("Spinning the wheel");
            Actions.run(host, "spin");
            return;
        }
        if (cmd.matches(".*\\broulette\\b.*")) {
            say("Roulette table");
            Actions.run(host, "roulette");
            return;
        }
        if (cmd.matches(".*\\b(flip|toss)\\b.*\\bcoin\\b.*")) {
            say("Flipping");
            host.coinFlip(heads -> say(heads ? "Heads" : "Tails"));
            return;
        }
        if (cmd.matches(".*\\broll\\b.*\\b(dice|die)\\b.*")) {
            say("You rolled a " + (1 + rnd.nextInt(6)));
            return;
        }
        Matcher open = Pattern.compile("^(?:open|launch|start|run)\\s+(?:the\\s+)?(.+)$").matcher(cmd);
        if (open.find()) {
            String name = open.group(1).replaceAll("\\s+app$", "").trim();
            host.repo.ensureFresh();
            List<AppEntry> found = host.repo.search(name);
            if (!found.isEmpty()) {
                say("Opening " + found.get(0).label);
                host.launch(found.get(0));
            } else {
                say("No app called " + name);
            }
            return;
        }
        say("I did not get: " + cmd);
    }

    private boolean torch(boolean on) {
        try {
            CameraManager cm = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, on);
                    return true;
                }
            }
        } catch (Exception ignored) {
            // no torch
        }
        return false;
    }

    // ------------------------------------------------------------------ unused callbacks

    @Override
    public void onReadyForSpeech(Bundle params) {
    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onRmsChanged(float rmsdB) {
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
    }

    @Override
    public void onEndOfSpeech() {
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
    }
}
