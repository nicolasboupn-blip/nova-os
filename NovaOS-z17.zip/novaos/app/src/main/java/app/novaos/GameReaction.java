package app.novaos;

import android.os.SystemClock;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Wait for the box to turn green, then tap as fast as you can. Tapping too early costs the round. */
final class GameReaction extends Game {
    private static final int IDLE = 0;
    private static final int WAIT = 1;
    private static final int GO = 2;

    private final TextView pad;
    private final TextView sub;
    private final Random rnd = new Random();
    private int state = IDLE;
    private long goAt;
    private int rounds;
    private int total;

    GameReaction(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(80), dp(20), dp(30));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        sub = label("", 13f, Theme.DIM);
        col.addView(sub);

        pad = label("TAP TO START", 22f, Theme.TEXT);
        pad.setLetterSpacing(0.1f);
        pad.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
        pad.setClickable(true);
        pad.setOnClickListener(v -> tap());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        pp.topMargin = dp(16);
        col.addView(pad, pp);
        updateSub();
    }

    @Override
    String title() {
        return "REACTION";
    }

    private void updateSub() {
        int b = best("react", 0);
        sub.setText((rounds > 0 ? "AVERAGE " + (total / rounds) + " ms   " : "") + (b > 0 ? "BEST " + b + " ms" : "no best yet"));
    }

    private void tap() {
        long now = SystemClock.elapsedRealtime();
        switch (state) {
            case IDLE:
                begin();
                break;
            case WAIT:
                h.removeCallbacksAndMessages(null);
                state = IDLE;
                pad.setBackground(Theme.rounded(0xFF7A1F3A, 28f, host));
                pad.setText("TOO SOON\ntap to retry");
                host.buzz(60);
                break;
            default: {
                int ms = (int) (now - goAt);
                state = IDLE;
                rounds++;
                total += ms;
                int b = best("react", 0);
                if (b == 0 || ms < b) {
                    saveBest("react", ms);
                }
                if (ms < 250) {
                    Badges.unlock(host, "react");
                }
                pad.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
                pad.setText(ms + " ms\ntap to go again");
                updateSub();
                break;
            }
        }
    }

    private void begin() {
        state = WAIT;
        pad.setBackground(Theme.rounded(0xFF5A1E2E, 28f, host));
        pad.setText("WAIT...");
        h.postDelayed(() -> {
            state = GO;
            goAt = SystemClock.elapsedRealtime();
            pad.setBackground(Theme.rounded(0xFF1F9D55, 28f, host));
            pad.setText("TAP!");
            host.buzz(15);
        }, 1500 + rnd.nextInt(3200));
    }
}
