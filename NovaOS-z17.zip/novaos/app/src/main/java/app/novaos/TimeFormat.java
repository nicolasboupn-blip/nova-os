package app.novaos;

import java.util.Locale;

final class TimeFormat {
    private TimeFormat() {
    }

    /** 1:02:03 or 02:03 */
    static String clock(long ms) {
        long s = Math.max(0, ms) / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
                : String.format(Locale.US, "%02d:%02d", m, sec);
    }

    /** 01:02.34 (hundredths) */
    static String precise(long ms) {
        long cs = Math.max(0, ms) / 10;
        long s = cs / 100;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, sec, cs % 100)
                : String.format(Locale.US, "%02d:%02d.%02d", m, sec, cs % 100);
    }
}
