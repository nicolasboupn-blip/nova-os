package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.widget.ImageView;

/**
 * An app icon with a holographic foil sheen: a rainbow band slides across it, drifting slowly by itself and
 * moving with the tilt of the phone, like a trading card. Only draws while on screen.
 */
final class HoloIcon extends ImageView {
    /** Phone tilt, set by the home screen. Between -1 and 1. */
    static float tiltX, tiltY;

    private final Paint foil = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix m = new Matrix();
    private LinearGradient grad;
    private int gradSize;
    private final long born = System.nanoTime();

    HoloIcon(Context c) {
        super(c);
        foil.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        foil.setAlpha(120);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) {
            super.onDraw(c);
            return;
        }
        if (grad == null || gradSize != w) {
            gradSize = w;
            grad = new LinearGradient(0, 0, w * 2f, 0,
                    new int[] {0xFFFF4D8D, 0xFFFFD84D, 0xFF4DFFB0, 0xFF4DB8FF, 0xFFB04DFF, 0xFFFF4D8D},
                    null, Shader.TileMode.REPEAT);
            foil.setShader(grad);
        }
        float t = (System.nanoTime() - born) / 1e9f;
        float offset = (t * 0.10f + tiltX * 0.9f + tiltY * 0.45f) * w * 2f;
        m.setRotate(28f);
        m.postTranslate(offset, 0f);
        grad.setLocalMatrix(m);

        int layer = c.saveLayer(0, 0, w, h, null);
        super.onDraw(c);
        c.drawRect(0, 0, w, h, foil);
        c.restoreToCount(layer);
        if (isShown()) {
            postInvalidateOnAnimation();
        }
    }
}
