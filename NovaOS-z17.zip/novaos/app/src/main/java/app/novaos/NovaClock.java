package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;

import java.util.Calendar;

/**
 * The clock, drawn by hand so it can look four ways (Settings > Clock style):
 * digital, stacked, analog and binary. All of them carry the same slow living glow.
 * scale 1 is the home screen size, the lock screen uses a bigger one.
 */
final class NovaClock extends View {
    static final int DIGITAL = 0;
    static final int STACKED = 1;
    static final int ANALOG = 2;
    static final int BINARY = 3;

    /** Room around the clock for the glow. Callers pull the view back by this much with negative margins. */
    final int pad;

    private final int style;
    private final float scale;
    private final float density;
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Theme.Glow glow;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueAnimator anim;
    private final float textPx;
    private final int contentW;
    private final int contentH;

    private final Runnable second = new Runnable() {
        @Override
        public void run() {
            invalidate();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 1000 - (now % 1000) + 8);
        }
    };

    NovaClock(Context c, float scale) {
        super(c);
        this.scale = scale;
        this.style = Prefs.clockStyle();
        this.density = c.getResources().getDisplayMetrics().density;
        this.pad = Math.round(18 * density);
        this.glow = new Theme.Glow(c);

        textPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 64f * scale, c.getResources().getDisplayMetrics());
        text.setTypeface(Theme.clockFace());
        text.setTextSize(style == STACKED ? textPx * 1.2f : textPx);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);

        switch (style) {
            case STACKED: {
                contentW = Math.round(text.measureText("00"));
                contentH = Math.round(text.getTextSize() * 1.8f);
                break;
            }
            case ANALOG: {
                contentW = Math.round(122 * density * scale);
                contentH = contentW;
                break;
            }
            case BINARY: {
                contentW = Math.round(150 * density * scale);
                contentH = Math.round(112 * density * scale);
                break;
            }
            default: {
                contentW = Math.round(text.measureText("00:00"));
                contentH = Math.round(text.getTextSize() * 0.98f);
                break;
            }
        }
        setMinimumWidth(contentW + 2 * pad);
        setMinimumHeight(contentH + 2 * pad);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(contentW + 2 * pad, contentH + 2 * pad);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim = glow.animator();
        anim.addUpdateListener(a -> {
            glow.at((float) a.getAnimatedValue());
            invalidate();
        });
        anim.start();
        handler.post(second);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.cancel();
        }
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        Calendar now = Calendar.getInstance();
        int h = now.get(Calendar.HOUR_OF_DAY);
        int m = now.get(Calendar.MINUTE);
        int s = now.get(Calendar.SECOND);
        c.save();
        c.translate(pad, pad);
        switch (style) {
            case STACKED:
                drawStacked(c, h, m);
                break;
            case ANALOG:
                drawAnalog(c, h, m, s);
                break;
            case BINARY:
                drawBinary(c, h, m);
                break;
            default:
                drawDigital(c, h, m);
                break;
        }
        c.restore();
    }

    private void shadow(Paint p) {
        if (glow.on) {
            p.setShadowLayer(glow.radius, glow.dx, glow.dy, (glow.alpha << 24) | (Theme.GLOW & 0xFFFFFF));
        } else {
            p.clearShadowLayer();
        }
    }

    private static String two(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private void drawDigital(Canvas c, int h, int m) {
        text.setColor(Theme.TEXT);
        shadow(text);
        float base = contentH - text.descent() * 0.2f - text.getTextSize() * 0.12f;
        c.drawText(two(h) + ":" + two(m), 0, base, text);
    }

    private void drawStacked(Canvas c, int h, int m) {
        float size = text.getTextSize();
        shadow(text);
        text.setColor(Theme.TEXT);
        c.drawText(two(h), 0, size * 0.84f, text);
        text.setColor(Theme.ACCENT);
        c.drawText(two(m), 0, size * 1.74f, text);
    }

    /** Draws a stroke with a soft halo behind it, which works the same on every Android version. */
    private void glowLine(Canvas c, float x1, float y1, float x2, float y2, float width, int color) {
        int a = glow.on ? (int) (40 + 60 * glow.breathe) : 0;
        if (a > 0) {
            line.setColor((a << 24) | (Theme.GLOW & 0xFFFFFF));
            line.setStrokeWidth(width + 12 * density);
            c.drawLine(x1, y1, x2, y2, line);
            line.setColor(((a + 40) << 24) | (Theme.GLOW & 0xFFFFFF));
            line.setStrokeWidth(width + 6 * density);
            c.drawLine(x1, y1, x2, y2, line);
        }
        line.setColor(color);
        line.setStrokeWidth(width);
        c.drawLine(x1, y1, x2, y2, line);
    }

    private void drawAnalog(Canvas c, int h, int m, int s) {
        float r = contentW / 2f;
        float cx = r;
        float cy = r;
        // face ring and ticks
        line.setColor(0x33FFFFFF);
        line.setStrokeWidth(1.5f * density);
        c.drawCircle(cx, cy, r - 2 * density, line);
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30);
            float len = i % 3 == 0 ? 8 * density * scale : 4 * density * scale;
            float r1 = r - 6 * density;
            float r2 = r1 - len;
            line.setColor(i % 3 == 0 ? Theme.TEXT : Theme.DIM);
            line.setStrokeWidth((i % 3 == 0 ? 2.2f : 1.4f) * density);
            c.drawLine(cx + (float) Math.sin(a) * r1, cy - (float) Math.cos(a) * r1,
                    cx + (float) Math.sin(a) * r2, cy - (float) Math.cos(a) * r2, line);
        }
        float hourA = (float) Math.toRadians((h % 12 + m / 60f + s / 3600f) * 30);
        float minA = (float) Math.toRadians((m + s / 60f) * 6);
        float secA = (float) Math.toRadians(s * 6);
        glowLine(c, cx, cy, cx + (float) Math.sin(hourA) * r * 0.5f, cy - (float) Math.cos(hourA) * r * 0.5f,
                4.5f * density, Theme.TEXT);
        glowLine(c, cx, cy, cx + (float) Math.sin(minA) * r * 0.74f, cy - (float) Math.cos(minA) * r * 0.74f,
                3f * density, Theme.TEXT);
        glowLine(c, cx - (float) Math.sin(secA) * r * 0.14f, cy + (float) Math.cos(secA) * r * 0.14f,
                cx + (float) Math.sin(secA) * r * 0.84f, cy - (float) Math.cos(secA) * r * 0.84f,
                1.4f * density, Theme.ACCENT);
        fill.setColor(Theme.ACCENT);
        c.drawCircle(cx, cy, 3.5f * density, fill);
    }

    private void drawBinary(Canvas c, int h, int m) {
        int[] digits = {h / 10, h % 10, m / 10, m % 10};
        int[] bits = {2, 4, 3, 4};
        float gap = 30 * density * scale;
        float dot = 8 * density * scale;
        float left = (contentW - gap * 3) / 2f;
        float top = dot + 2 * density;
        for (int col = 0; col < 4; col++) {
            float x = left + col * gap + (col >= 2 ? 6 * density * scale : 0);
            for (int row = 0; row < 4; row++) {
                int bit = 3 - row;
                if (bit >= bits[col]) {
                    continue;
                }
                float y = top + row * gap * 0.62f;
                boolean on = ((digits[col] >> bit) & 1) == 1;
                if (on) {
                    int a = glow.on ? (int) (50 + 70 * glow.breathe) : 0;
                    if (a > 0) {
                        fill.setColor((a << 24) | (Theme.GLOW & 0xFFFFFF));
                        c.drawCircle(x, y, dot * 2.1f, fill);
                        fill.setColor(((a + 40) << 24) | (Theme.GLOW & 0xFFFFFF));
                        c.drawCircle(x, y, dot * 1.45f, fill);
                    }
                    fill.setColor(col < 2 ? Theme.TEXT : Theme.ACCENT);
                    c.drawCircle(x, y, dot, fill);
                } else {
                    fill.setColor(0x33FFFFFF);
                    c.drawCircle(x, y, dot * 0.42f, fill);
                }
            }
            // the decimal digit under each column, so it can be read at a glance
            text.setTextSize(11f * density * scale);
            text.clearShadowLayer();
            text.setColor(Theme.DIM);
            text.setTextAlign(Paint.Align.CENTER);
            c.drawText(String.valueOf(digits[col]), x, contentH - 2 * density, text);
            text.setTextAlign(Paint.Align.LEFT);
        }
    }
}
