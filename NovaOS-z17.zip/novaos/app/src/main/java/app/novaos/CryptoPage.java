package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Bitcoin, Ethereum, Solana and Dogecoin with a 7-day line. Tap the coin name to switch. Prices from CoinGecko. */
final class CryptoPage extends LinearLayout {
    private static final String[] IDS = {"bitcoin", "ethereum", "solana", "dogecoin"};
    private static final String[] SYMBOLS = {"BTC", "ETH", "SOL", "DOGE"};

    private static final double[] price = new double[4];
    private static final double[] change = new double[4];
    private static final double[][] line = new double[4][];
    private static long loadedAt;

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView name;
    private final TextView priceText;
    private final TextView changeText;
    private final Spark spark;
    private int coin;
    private boolean loading;
    private long lastTry;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                maybeLoad();
            }
            ui.postDelayed(this, 30_000);
        }
    };

    CryptoPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        coin = Prefs.getInt("crypto_coin", 0);
        if (coin < 0 || coin >= IDS.length) {
            coin = 0;
        }

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        name = new TextView(host);
        name.setTypeface(Theme.MONO);
        name.setTextSize(13f);
        name.setLetterSpacing(0.12f);
        name.setTextColor(Theme.ACCENT);
        name.setClickable(true);
        name.setPadding(0, Theme.dp(host, 6), Theme.dp(host, 10), Theme.dp(host, 6));
        name.setOnClickListener(v -> {
            coin = (coin + 1) % IDS.length;
            Prefs.putInt("crypto_coin", coin);
            render();
        });
        head.addView(name);
        changeText = new TextView(host);
        changeText.setTypeface(Theme.MONO);
        changeText.setTextSize(12f);
        changeText.setGravity(Gravity.END);
        head.addView(changeText, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        addView(head, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        priceText = new TextView(host);
        priceText.setTypeface(Theme.MONO);
        priceText.setTextSize(26f);
        priceText.setTextColor(Theme.TEXT);
        priceText.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        addView(priceText, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        spark = new Spark(host);
        LayoutParams sp = new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = Theme.dp(host, 6);
        addView(spark, sp);
        render();
    }

    private void maybeLoad() {
        long now = System.currentTimeMillis();
        if (loading || (loadedAt > 0 && now - loadedAt < 5 * 60_000L) || now - lastTry < 45_000L) {
            return;
        }
        lastTry = now;
        loading = true;
        new Thread(() -> {
            boolean ok = fetch();
            ui.post(() -> {
                loading = false;
                if (ok) {
                    render();
                }
            });
        }).start();
    }

    private static boolean fetch() {
        String body = Http.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids="
                + "bitcoin,ethereum,solana,dogecoin&sparkline=true&price_change_percentage=24h");
        if (body == null) {
            return false;
        }
        try {
            JSONArray arr = new JSONArray(body);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                for (int k = 0; k < IDS.length; k++) {
                    if (IDS[k].equals(o.optString("id"))) {
                        price[k] = o.optDouble("current_price", 0);
                        change[k] = o.optDouble("price_change_percentage_24h", 0);
                        JSONObject sp = o.optJSONObject("sparkline_in_7d");
                        JSONArray pr = sp == null ? null : sp.optJSONArray("price");
                        if (pr != null && pr.length() > 1) {
                            double[] v = new double[pr.length()];
                            for (int j = 0; j < v.length; j++) {
                                v[j] = pr.optDouble(j, 0);
                            }
                            line[k] = v;
                        }
                    }
                }
            }
            loadedAt = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void render() {
        name.setText(SYMBOLS[coin] + " ⇄");
        if (loadedAt == 0) {
            priceText.setText(loading ? "..." : "--");
            changeText.setText("");
            spark.set(null, true);
            return;
        }
        double p = price[coin];
        priceText.setText(String.format(Locale.US, p >= 100 ? "$%,.0f" : p >= 1 ? "$%,.2f" : "$%.4f", p));
        boolean up = change[coin] >= 0;
        changeText.setText(String.format(Locale.US, "%s%.2f%%  24h", up ? "▲ +" : "▼ ", change[coin]));
        changeText.setTextColor(up ? 0xFF4DFF9A : 0xFFFF6B7F);
        spark.set(line[coin], up);
    }

    private static final class Spark extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float d;
        private double[] data;
        private boolean up = true;

        Spark(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
        }

        void set(double[] values, boolean isUp) {
            data = values;
            up = isUp;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            if (data == null || data.length < 2) {
                return;
            }
            double min = Double.MAX_VALUE;
            double max = -Double.MAX_VALUE;
            for (double v : data) {
                min = Math.min(min, v);
                max = Math.max(max, v);
            }
            double span = Math.max(1e-9, max - min);
            float w = getWidth();
            float h = getHeight() - 6 * d;
            path.rewind();
            for (int i = 0; i < data.length; i++) {
                float x = w * i / (data.length - 1);
                float y = 3 * d + h - (float) ((data[i] - min) / span) * h;
                if (i == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            int col = up ? 0xFF4DFF9A : 0xFFFF6B7F;
            p.setColor((col & 0x00FFFFFF) | 0x33000000);
            p.setStrokeWidth(7 * d);
            c.drawPath(path, p);
            p.setColor(col);
            p.setStrokeWidth(2 * d);
            c.drawPath(path, p);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
