package app.novaos;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** The glowing roulette wheel with its ball. Used by the casino table and by the party wheel. */
final class RouletteWheel extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path[] wedges = new Path[37];
    private final float step = 360f / 37f;
    private final RectF oval = new RectF();
    private float cx, cy, radius;
    private float wheelAngle;      // degrees, clockwise
    private float rel = 40f;       // ball angle relative to the wheel
    private float ballR;           // 0..1 of radius
    private boolean ballVisible;
    private int highlight = -1;    // number to glow
    private ValueAnimator anim;
    private float dens;
    private boolean busy;
    private final java.util.Random rnd = new java.util.Random();
    private float dp(float v) {
        return v * dens;
    }
    boolean isBusy() {
        return busy;
    }

    RouletteWheel(Context c) {
        super(c);
        dens = c.getResources().getDisplayMetrics().density;
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextAlign(Paint.Align.CENTER);
        ballR = 0.88f;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        cx = w / 2f;
        cy = h / 2f;
        radius = Math.min(w, h) / 2f - dp(6);
        float outer = radius * 0.80f;
        float inner = radius * 0.50f;
        for (int i = 0; i < 37; i++) {
            float start = -90f + i * step - step / 2f;
            Path path = new Path();
            oval.set(cx - outer, cy - outer, cx + outer, cy + outer);
            path.arcTo(oval, start, step);
            RectF in = new RectF(cx - inner, cy - inner, cx + inner, cy + inner);
            path.arcTo(in, start + step, -step);
            path.close();
            wedges[i] = path;
        }
    }

    void spin(final int number, final Runnable done) {
        int idx = 0;
        for (int i = 0; i < GameRoulette.ORDER.length; i++) {
            if (GameRoulette.ORDER[i] == number) {
                idx = i;
            }
        }
        final float pocketAngle = idx * step;
        final float w0 = wheelAngle;
        final float wEnd = w0 + 360f * (3 + rnd.nextInt(2)) + rnd.nextInt(360);
        final float rel0 = rnd.nextInt(360);
        final float relEnd = pocketAngle - 360f * (6 + rnd.nextInt(2));
        highlight = -1;
        busy = true;
        ballVisible = true;
        if (anim != null) {
            anim.cancel();
        }
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(6800);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            float ew = 1f - (float) Math.pow(1f - t, 2.1);
            float eb = 1f - (float) Math.pow(1f - t, 3.4);
            wheelAngle = w0 + (wEnd - w0) * ew;
            rel = rel0 + (relEnd - rel0) * eb;
            // ball runs on the outer track, then drops into the pockets with a couple of bounces
            float fallStart = 0.50f;
            float fallEnd = 0.84f;
            if (t < fallStart) {
                ballR = 0.90f;
            } else if (t < fallEnd) {
                float s = (t - fallStart) / (fallEnd - fallStart);
                float smooth = s * s * (3f - 2f * s);
                ballR = 0.90f + (0.65f - 0.90f) * smooth;
                if (s > 0.55f) {
                    float b = (s - 0.55f) / 0.45f;
                    ballR += 0.05f * (float) Math.abs(Math.sin(b * 3.0 * Math.PI)) * (1f - b);
                }
            } else {
                ballR = 0.65f;
            }
            invalidate();
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                wheelAngle = wEnd % 360f;
                rel = pocketAngle;
                ballR = 0.65f;
                highlight = number;
                busy = false;
                invalidate();
                done.run();
            }
        });
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (radius <= 0) {
            return;
        }
        // outer rim and ball track, glowing in the accent colour
        p.setStyle(Paint.Style.FILL);
        p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x22000000);
        c.drawCircle(cx, cy, radius * 1.03f, p);
        p.setColor(0xFF0F0B1C);
        c.drawCircle(cx, cy, radius, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2));
        p.setColor(Theme.ACCENT);
        c.drawCircle(cx, cy, radius, p);
        p.setStrokeWidth(dp(1));
        p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x55000000);
        c.drawCircle(cx, cy, radius * 0.84f, p);

        // the turning part
        c.save();
        c.rotate(wheelAngle, cx, cy);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF241B3D);
        c.drawCircle(cx, cy, radius * 0.82f, p);
        for (int i = 0; i < 37; i++) {
            int n = GameRoulette.ORDER[i];
            p.setStyle(Paint.Style.FILL);
            p.setColor(GameRoulette.colorOf(n));
            c.drawPath(wedges[i], p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(0.8f));
            p.setColor(0x88FFFFFF);
            c.drawPath(wedges[i], p);
            if (n == highlight) {
                p.setStrokeWidth(dp(3));
                p.setColor(0xFFFFFFFF);
                c.drawPath(wedges[i], p);
            }
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        p.setTextSize(radius * 0.085f);
        for (int i = 0; i < 37; i++) {
            c.save();
            c.rotate(i * step, cx, cy);
            c.drawText(String.valueOf(GameRoulette.ORDER[i]), cx, cy - radius * 0.68f + p.getTextSize() * 0.35f, p);
            c.restore();
        }
        // hub
        p.setColor(0xFF120D22);
        c.drawCircle(cx, cy, radius * 0.47f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2));
        p.setColor(Theme.ACCENT);
        c.drawCircle(cx, cy, radius * 0.47f, p);
        p.setStrokeWidth(dp(2.5f));
        p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0xAA000000);
        for (int k = 0; k < 4; k++) {
            c.save();
            c.rotate(k * 90f, cx, cy);
            c.drawLine(cx, cy - radius * 0.40f, cx, cy + radius * 0.40f, p);
            c.restore();
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(Theme.ACCENT);
        c.drawCircle(cx, cy, radius * 0.08f, p);
        c.restore();

        // result in the middle once it has stopped
        if (highlight >= 0 && !busy) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(GameRoulette.colorOf(highlight));
            c.drawCircle(cx, cy, radius * 0.22f, p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(radius * 0.22f);
            c.drawText(String.valueOf(highlight), cx, cy + radius * 0.08f, p);
        }

        // the ball
        if (ballVisible) {
            double a = Math.toRadians(wheelAngle + rel);
            float bx = cx + (float) Math.sin(a) * radius * ballR;
            float by = cy - (float) Math.cos(a) * radius * ballR;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x44FFFFFF);
            c.drawCircle(bx, by, radius * 0.07f, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(bx, by, radius * 0.038f, p);
        }
    }
}
