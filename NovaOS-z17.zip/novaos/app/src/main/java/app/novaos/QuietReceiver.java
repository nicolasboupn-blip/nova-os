package app.novaos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Runs at the start and end of quiet hours. */
public class QuietReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Prefs.init(context);
        QuietHours.apply(context);
    }
}
