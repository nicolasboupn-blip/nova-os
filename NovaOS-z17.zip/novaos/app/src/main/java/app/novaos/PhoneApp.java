package app.novaos;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * NOVA's own phone: a dial pad and your contacts. Calls are placed through Android, so the call screen itself is the
 * system's. Each contact can also get a quick text.
 */
final class PhoneApp extends Game {
    private static final String[] KEYS = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
    private static final String[] SUBS = {"", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ", "", "+", ""};

    private static final class Contact {
        final String name;
        final String number;

        Contact(String name, String number) {
            this.name = name;
            this.number = number;
        }
    }

    private final FrameLayoutHolder body = new FrameLayoutHolder();
    private final List<Contact> contacts = new ArrayList<>();
    private final StringBuilder dial = new StringBuilder();
    private TextView dialText;
    private LinearLayout list;
    private String filter = "";
    private boolean showContacts;
    private TextView tabKeys;
    private TextView tabContacts;

    /** Just a named box so the two tabs can swap into the same spot. */
    private final class FrameLayoutHolder {
        LinearLayout box;
    }

    PhoneApp(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(58), dp(16), dp(16));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout tabs = new LinearLayout(host);
        tabs.setGravity(Gravity.CENTER);
        tabKeys = tab("KEYPAD", false);
        tabContacts = tab("CONTACTS", true);
        tabs.addView(tabKeys, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        tabs.addView(tabContacts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(tabs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        body.box = new LinearLayout(host);
        body.box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        bp.topMargin = dp(10);
        col.addView(body.box, bp);

        TextView stock = label("STOCK PHONE", 10f, Theme.DIM);
        stock.setPadding(dp(10), dp(10), dp(10), dp(4));
        stock.setClickable(true);
        stock.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Intent.ACTION_DIAL);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
            } catch (Exception e) {
                host.toast("No phone app found");
            }
        });
        col.addView(stock);
        show(false);
    }

    @Override
    String title() {
        return "PHONE";
    }

    private TextView tab(String s, final boolean contactsTab) {
        TextView t = label(s, 12f, Theme.DIM);
        t.setLetterSpacing(0.2f);
        t.setPadding(0, dp(12), 0, dp(12));
        t.setClickable(true);
        t.setOnClickListener(v -> show(contactsTab));
        return t;
    }

    private void show(boolean contactsTab) {
        showContacts = contactsTab;
        tabKeys.setTextColor(contactsTab ? Theme.DIM : Theme.ACCENT);
        tabContacts.setTextColor(contactsTab ? Theme.ACCENT : Theme.DIM);
        body.box.removeAllViews();
        if (contactsTab) {
            buildContacts();
        } else {
            buildKeypad();
        }
    }

    // ------------------------------------------------------------------ keypad

    private void buildKeypad() {
        dialText = label(dial.toString(), 30f, Theme.TEXT);
        dialText.setSingleLine(true);
        dialText.setEllipsize(android.text.TextUtils.TruncateAt.START);
        body.box.addView(dialText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)));

        LinearLayout grid = new LinearLayout(host);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                final int idx = r * 3 + c;
                LinearLayout key = new LinearLayout(host);
                key.setOrientation(LinearLayout.VERTICAL);
                key.setGravity(Gravity.CENTER);
                key.setBackground(Theme.rounded(0x26FFFFFF, 40f, host));
                key.setClickable(true);
                Theme.ripple(key);
                key.addView(label(KEYS[idx], 24f, Theme.TEXT));
                if (!SUBS[idx].isEmpty()) {
                    key.addView(label(SUBS[idx], 8f, Theme.DIM));
                }
                key.setOnClickListener(v -> typed(KEYS[idx]));
                if (idx == 10) {
                    key.setOnLongClickListener(v -> {
                        typed("+");
                        return true;
                    });
                }
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, dp(66), 1f);
                kp.setMargins(dp(6), dp(5), dp(6), dp(5));
                row.addView(key, kp);
            }
            grid.addView(row, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        body.box.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER);
        TextView text = button("✉ TEXT", () -> {
            if (dial.length() > 0) {
                compose(dial.toString(), dial.toString());
            }
        });
        TextView call = label("CALL", 15f, 0xFF0B1F12);
        call.setLetterSpacing(0.2f);
        call.setBackground(Theme.rounded(0xFF2BD66B, 28f, host));
        call.setClickable(true);
        call.setPadding(dp(30), dp(14), dp(30), dp(14));
        call.setOnClickListener(v -> {
            if (dial.length() > 0) {
                call(dial.toString());
            }
        });
        TextView del = button("⌫", () -> {
            if (dial.length() > 0) {
                dial.deleteCharAt(dial.length() - 1);
                dialText.setText(dial.toString());
            }
        });
        del.setOnLongClickListener(v -> {
            dial.setLength(0);
            dialText.setText("");
            return true;
        });
        actions.addView(text);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dp(10), 0, dp(10), 0);
        actions.addView(call, cp);
        actions.addView(del);
        body.box.addView(actions, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void typed(String k) {
        if (dial.length() < 24) {
            dial.append(k);
            dialText.setText(dial.toString());
            Sfx.play(Sfx.CLICK);
            host.buzz(8);
        }
    }

    // ------------------------------------------------------------------ contacts

    private void buildContacts() {
        EditText search = new EditText(host);
        search.setHint("search");
        search.setHintTextColor(Theme.DIM);
        search.setTextColor(Theme.TEXT);
        search.setTypeface(Theme.MONO);
        search.setTextSize(14f);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setText(filter);
        search.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter = s.toString();
                fillList();
            }
        });
        body.box.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = dp(8);
        body.box.addView(sv, sp);

        if (host.has(Manifest.permission.READ_CONTACTS)) {
            loadContacts();
            fillList();
        } else {
            TextView ask = button("ALLOW CONTACTS", () -> host.ask(new String[] {Manifest.permission.READ_CONTACTS},
                    () -> {
                        loadContacts();
                        fillList();
                    }, () -> host.toast("NOVA needs contacts to list them")));
            list.addView(ask);
        }
    }

    private void loadContacts() {
        contacts.clear();
        Set<String> seen = new HashSet<>();
        try (Cursor c = host.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String num = c.getString(1);
                    if (name == null || num == null) {
                        continue;
                    }
                    String key = name + "|" + num.replaceAll("[^0-9+]", "");
                    if (seen.add(key)) {
                        contacts.add(new Contact(name, num));
                    }
                }
            }
        } catch (Exception e) {
            host.toast("Could not read contacts");
        }
    }

    private void fillList() {
        if (list == null) {
            return;
        }
        list.removeAllViews();
        String f = filter.trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (final Contact c : contacts) {
            if (!f.isEmpty() && !c.name.toLowerCase(Locale.ROOT).contains(f) && !c.number.contains(f)) {
                continue;
            }
            if (shown++ > 250) {
                break;
            }
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(10), dp(6), dp(10));
            row.setClickable(true);
            Theme.ripple(row);
            row.setOnClickListener(v -> call(c.number));
            LinearLayout names = new LinearLayout(host);
            names.setOrientation(LinearLayout.VERTICAL);
            TextView n = label(c.name, 15f, Theme.TEXT);
            n.setGravity(Gravity.START);
            TextView num = label(c.number, 11f, Theme.DIM);
            num.setGravity(Gravity.START);
            names.addView(n);
            names.addView(num);
            row.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            TextView msg = label("✉", 20f, Theme.ACCENT);
            msg.setPadding(dp(16), dp(6), dp(10), dp(6));
            msg.setClickable(true);
            msg.setOnClickListener(v -> compose(c.name, c.number));
            row.addView(msg);
            list.addView(row);
        }
        if (shown == 0) {
            list.addView(label(contacts.isEmpty() ? "NO CONTACTS" : "NO MATCH", 12f, Theme.DIM));
        }
    }

    // ------------------------------------------------------------------ calling and texting

    private void call(final String number) {
        final String clean = number.replaceAll("[^0-9+*#]", "");
        host.ask(new String[] {Manifest.permission.CALL_PHONE}, () -> {
            try {
                Intent i = new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", clean, null));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
            } catch (Exception e) {
                dialStock(clean);
            }
        }, () -> dialStock(clean));
    }

    private void dialStock(String clean) {
        try {
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", clean, null));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            host.startActivity(i);
        } catch (Exception e) {
            host.toast("No phone app found");
        }
    }

    /** A small box to type a text. It is sent straight away; NOVA does not keep a conversation list. */
    private void compose(String who, final String number) {
        final EditText input = new EditText(host);
        input.setHint("message");
        input.setMinLines(2);
        new android.app.AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Text " + who)
                .setView(input)
                .setPositiveButton("Send", (d, w) -> send(number, input.getText().toString()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void send(final String number, final String text) {
        if (text.trim().isEmpty()) {
            return;
        }
        final String clean = number.replaceAll("[^0-9+]", "");
        host.ask(new String[] {Manifest.permission.SEND_SMS}, () -> {
            try {
                android.telephony.SmsManager sm = android.telephony.SmsManager.getDefault();
                ArrayList<String> parts = sm.divideMessage(text);
                sm.sendMultipartTextMessage(clean, null, parts, null, null);
                host.toast("Sent");
                Sfx.play(Sfx.BLIP);
            } catch (Exception e) {
                host.toast("Could not send");
            }
        }, () -> {
            try {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + clean));
                i.putExtra("sms_body", text);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
            } catch (Exception e) {
                host.toast("No messages app found");
            }
        });
    }
}
