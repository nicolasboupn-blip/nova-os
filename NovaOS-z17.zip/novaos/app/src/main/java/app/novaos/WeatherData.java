package app.novaos;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

/**
 * Weather for the city you picked, from Open-Meteo (free, no account). One shared copy, refreshed at most every
 * 20 minutes, used by the weather page, the sun page and the terminal.
 */
final class WeatherData {
    static final class Place {
        String name;
        double lat;
        double lon;
    }

    static final class Day {
        String date;       // yyyy-MM-dd
        int code;
        double max;
        double min;
        String sunrise;    // yyyy-MM-ddTHH:mm local time of the place
        String sunset;
    }

    // current
    static boolean valid;
    static long loadedAt;
    static double temp;
    static double feels;
    static double wind;
    static int code;
    static boolean day = true;
    static int utcOffset;
    static final Day[] days = new Day[5];

    private WeatherData() {
    }

    static boolean hasCity() {
        return !Prefs.getString("w_city", "").isEmpty();
    }

    static String city() {
        return Prefs.getString("w_city", "");
    }

    static void saveCity(Place p) {
        Prefs.putString("w_city", p.name);
        Prefs.putString("w_lat", String.valueOf(p.lat));
        Prefs.putString("w_lon", String.valueOf(p.lon));
        valid = false;
        loadedAt = 0;
    }

    /** Looks a city up by name. Background thread only. Returns null if not found. */
    static Place geocode(String name) {
        try {
            String body = Http.get("https://geocoding-api.open-meteo.com/v1/search?name="
                    + URLEncoder.encode(name.trim(), "UTF-8") + "&count=1&language=en&format=json");
            if (body == null) {
                return null;
            }
            JSONArray results = new JSONObject(body).optJSONArray("results");
            if (results == null || results.length() == 0) {
                return null;
            }
            JSONObject r = results.getJSONObject(0);
            Place p = new Place();
            p.name = r.optString("name", name);
            String country = r.optString("country_code", "");
            if (!country.isEmpty()) {
                p.name += ", " + country;
            }
            p.lat = r.getDouble("latitude");
            p.lon = r.getDouble("longitude");
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    /** Loads the forecast for the saved city. Background thread only. Returns true on success. */
    static boolean load(boolean force) {
        if (!hasCity()) {
            return false;
        }
        if (!force && valid && System.currentTimeMillis() - loadedAt < 20 * 60_000L) {
            return true;
        }
        try {
            String lat = Prefs.getString("w_lat", "0");
            String lon = Prefs.getString("w_lon", "0");
            String body = Http.get("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon
                    + "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day"
                    + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset"
                    + "&timezone=auto&forecast_days=5");
            if (body == null) {
                return false;
            }
            JSONObject root = new JSONObject(body);
            utcOffset = root.optInt("utc_offset_seconds", 0);
            JSONObject cur = root.getJSONObject("current");
            JSONObject daily = root.getJSONObject("daily");
            temp = cur.optDouble("temperature_2m", 0);
            feels = cur.optDouble("apparent_temperature", temp);
            wind = cur.optDouble("wind_speed_10m", 0);
            code = cur.optInt("weather_code", 0);
            day = cur.optInt("is_day", 1) == 1;
            JSONArray time = daily.getJSONArray("time");
            for (int i = 0; i < days.length; i++) {
                Day d = new Day();
                if (i < time.length()) {
                    d.date = time.getString(i);
                    d.code = daily.getJSONArray("weather_code").optInt(i, 0);
                    d.max = daily.getJSONArray("temperature_2m_max").optDouble(i, 0);
                    d.min = daily.getJSONArray("temperature_2m_min").optDouble(i, 0);
                    d.sunrise = daily.getJSONArray("sunrise").optString(i, "");
                    d.sunset = daily.getJSONArray("sunset").optString(i, "");
                }
                days[i] = d;
            }
            valid = true;
            loadedAt = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** A few text lines of weather for any place, for the terminal. Background thread only. Null on failure. */
    static String report(Place p) {
        try {
            String body = Http.get("https://api.open-meteo.com/v1/forecast?latitude=" + p.lat + "&longitude=" + p.lon
                    + "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day"
                    + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset"
                    + "&timezone=auto&forecast_days=4");
            if (body == null) {
                return null;
            }
            JSONObject root = new JSONObject(body);
            JSONObject cur = root.getJSONObject("current");
            JSONObject daily = root.getJSONObject("daily");
            StringBuilder sb = new StringBuilder();
            sb.append(p.name).append('\n');
            sb.append(emoji(cur.optInt("weather_code"), cur.optInt("is_day", 1) == 1)).append(' ')
                    .append(Math.round(cur.optDouble("temperature_2m"))).append("°C  ")
                    .append(describe(cur.optInt("weather_code"))).append('\n');
            sb.append("feels ").append(Math.round(cur.optDouble("apparent_temperature"))).append("°  wind ")
                    .append(Math.round(cur.optDouble("wind_speed_10m"))).append(" km/h\n");
            JSONArray time = daily.getJSONArray("time");
            for (int i = 0; i < time.length(); i++) {
                sb.append(time.getString(i).substring(5)).append("  ")
                        .append(emoji(daily.getJSONArray("weather_code").optInt(i), true)).append(' ')
                        .append(Math.round(daily.getJSONArray("temperature_2m_min").optDouble(i))).append("..")
                        .append(Math.round(daily.getJSONArray("temperature_2m_max").optDouble(i))).append("°\n");
            }
            String sr = daily.getJSONArray("sunrise").optString(0, "");
            String ss = daily.getJSONArray("sunset").optString(0, "");
            if (sr.length() > 11 && ss.length() > 11) {
                sb.append("sun ").append(sr.substring(11)).append(" - ").append(ss.substring(11)).append('\n');
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    static String emoji(int c, boolean isDay) {
        if (c == 0) {
            return isDay ? "☀️" : "🌙";
        }
        if (c <= 2) {
            return isDay ? "🌤" : "☁️";
        }
        if (c == 3) {
            return "☁️";
        }
        if (c == 45 || c == 48) {
            return "🌫";
        }
        if (c >= 51 && c <= 57) {
            return "🌦";
        }
        if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) {
            return "🌧";
        }
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) {
            return "❄️";
        }
        if (c >= 95) {
            return "⛈";
        }
        return "☁️";
    }

    static String describe(int c) {
        switch (c) {
            case 0:
                return "Clear sky";
            case 1:
                return "Mainly clear";
            case 2:
                return "Partly cloudy";
            case 3:
                return "Overcast";
            case 45:
            case 48:
                return "Fog";
            case 51:
            case 53:
            case 55:
                return "Drizzle";
            case 56:
            case 57:
                return "Freezing drizzle";
            case 61:
                return "Light rain";
            case 63:
                return "Rain";
            case 65:
                return "Heavy rain";
            case 66:
            case 67:
                return "Freezing rain";
            case 71:
                return "Light snow";
            case 73:
                return "Snow";
            case 75:
                return "Heavy snow";
            case 77:
                return "Snow grains";
            case 80:
            case 81:
            case 82:
                return "Rain showers";
            case 85:
            case 86:
                return "Snow showers";
            case 95:
                return "Thunderstorm";
            case 96:
            case 99:
                return "Thunderstorm, hail";
            default:
                return "Cloudy";
        }
    }
}
