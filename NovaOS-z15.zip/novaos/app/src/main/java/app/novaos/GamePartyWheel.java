package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Just the wheel. Tap it, it spins, everybody shouts. No coins, no bets, made for playing with friends. */
final class GamePartyWheel extends Game {
    private final Random rnd = new Random();
    private final RouletteWheel wheel;
    private final TextView message;
    private int spins;

    GamePartyWheel(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(14), dp(60), dp(14), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        message = label("TAP THE WHEEL", 16f, Theme.TEXT);
        message.setLetterSpacing(0.14f);
        col.addView(message);

        wheel = new RouletteWheel(host);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        wp.topMargin = dp(16);
        wp.bottomMargin = dp(16);
        col.addView(wheel, wp);
        wheel.setClickable(true);
        wheel.setOnClickListener(v -> spin());
    }

    @Override
    String title() {
        return "PARTY WHEEL";
    }

    private void spin() {
        if (wheel.isBusy()) {
            return;
        }
        final int result = rnd.nextInt(37);
        message.setText("SPINNING…");
        message.setTextColor(Theme.DIM);
        host.buzz(20);
        wheel.spin(result, () -> {
            spins++;
            String colour = result == 0 ? "GREEN" : GameRoulette.colorOf(result) == 0xFFC4243F ? "RED" : "BLACK";
            message.setText(result + "  " + colour + (result != 0 && result % 2 == 0 ? " · EVEN" : result != 0 ? " · ODD" : ""));
            message.setTextColor(Theme.ACCENT);
            host.buzz(60);
        });
    }
}
