package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/**
 * Shake the phone and a golden coin jumps up, spins and lands on heads or tails. The result is decided by a
 * fair 50/50 pick first and the spin is timed to end on it. Tap anywhere to put it away.
 */
final class CoinFlip extends View {
    private final NovaActivity host;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final boolean heads;
    private final int halfTurns;
    private ValueAnimator anim;
    private float t;          // 0..1 through the flip
    private boolean landed;

    CoinFlip(NovaActivity host) {
        super(host);
        this.host = host;
        d = host.getResources().getDisplayMetrics().density;
        Random r = new Random();
        heads = r.nextBoolean();
        // an even number of half turns ends on heads, odd on tails
        int base = 6 + r.nextInt(4);
        halfTurns = (base % 2 == 0) == heads ? base : base + 1;
        setClickable(true);
        setOnClickListener(v -> dismiss());
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        setAlpha(0f);
        animate().alpha(1f).setDuration(180).start();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(1900);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            t = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                landed = true;
                host.buzz(70);
                invalidate();
                postDelayed(CoinFlip.this::dismiss, 3500);
            }
        });
        anim.start();
        host.buzz(25);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.cancel();
        }
        super.onDetachedFromWindow();
    }

    private boolean gone;

    void dismiss() {
        if (gone) {
            return;
        }
        gone = true;
        animate().alpha(0f).setDuration(220).withEndAction(() -> {
            if (getParent() != null) {
                host.root.removeView(this);
            }
        }).start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xAA000000);
        c.drawRect(0, 0, w, h, p);

        float r = Math.min(w, h) * 0.22f;
        float cx = w / 2f;
        float baseY = h * 0.50f;
        // up and down with a gentle bounce at the end
        float arc = (float) Math.sin(Math.min(1f, t) * Math.PI);
        float rise = h * 0.22f * arc;
        float cy = baseY - rise;
        float ease = 1f - (float) Math.pow(1f - t, 2.0);
        float angle = (float) (Math.PI * halfTurns * ease);
        float cosA = (float) Math.cos(angle);
        boolean front = cosA >= 0f;             // front face = heads
        float sx = Math.max(0.04f, Math.abs(cosA));

        // shadow on the ground
        p.setColor(0x44000000);
        float sh = 1f - 0.5f * arc;
        c.drawOval(cx - r * sh, baseY + r * 1.25f - r * 0.12f, cx + r * sh, baseY + r * 1.25f + r * 0.12f, p);

        c.save();
        c.translate(cx, cy);
        c.scale(sx, 1f);
        RadialGradient g = new RadialGradient(-r * 0.3f, -r * 0.35f, r * 1.4f,
                new int[] {0xFFFFF3B0, 0xFFF2C230, 0xFFB8860B}, new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        p.setShader(g);
        c.drawCircle(0, 0, r, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.08f);
        p.setColor(0xFFFFE680);
        c.drawCircle(0, 0, r * 0.93f, p);
        p.setStrokeWidth(r * 0.025f);
        p.setColor(0xFF8A6508);
        c.drawCircle(0, 0, r * 0.78f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF8A6508);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        p.setTextSize(r * (front ? 1.15f : 0.95f));
        c.drawText(front ? "N" : "★", 0, front ? r * 0.40f : r * 0.33f, p);
        // a shine that slides over the face
        p.setColor(0x33FFFFFF);
        c.drawOval(-r * 0.6f, -r * 0.8f, r * 0.1f, -r * 0.3f, p);
        c.restore();

        if (landed) {
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Theme.MONO);
            p.setTextSize(30 * d);
            p.setLetterSpacing(0.2f);
            p.setColor(0xFFFFE680);
            p.setShadowLayer(14 * d, 0, 0, 0xFFF2C230);
            c.drawText(heads ? "HEADS" : "TAILS", cx, baseY + r * 1.25f + 70 * d, p);
            p.setShadowLayer(0, 0, 0, 0);
            p.setLetterSpacing(0f);
            p.setTextSize(12 * d);
            p.setColor(0x88FFFFFF);
            c.drawText("tap to close", cx, baseY + r * 1.25f + 100 * d, p);
        }
    }
}
