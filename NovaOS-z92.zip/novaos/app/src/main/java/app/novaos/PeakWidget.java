package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** PEAKS: a small map of the mountains around your last position, the three highest, and buttons to open the full viewer. */
final class PeakWidget extends NovaWidget {
    private final PeakMapView map;
    private final TextView list;

    PeakWidget(NovaActivity host) {
        super(host);
        setGravity(Gravity.CENTER_HORIZONTAL);
        addView(text("PEAKFINDER", 9f, Theme.DIM), wide());
        map = new PeakMapView(host, false);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(170));
        mp.topMargin = dp(4);
        addView(map, mp);
        list = text("", 10f, Theme.TEXT);
        list.setGravity(Gravity.START);
        list.setPadding(dp(4), dp(6), dp(4), dp(4));
        addView(list, wide());
        LinearLayout r = row();
        r.addView(chip("MAP", () -> host.showOverlay(new PeakFinder(host, PeakFinder.MAP))), weight(1f));
        r.addView(chip("3D CAMERA", () -> host.showOverlay(new PeakFinder(host, PeakFinder.CAMERA))), weight(1.4f));
        addView(r, wide());
    }

    @Override
    long tickMs() {
        return 0;
    }

    @Override
    void refresh() {
        PeakData.restore();
        if (!PeakData.have) {
            list.setText("Tap MAP once to let NOVA find where you are.");
            return;
        }
        PeakData.loadCached(host.getApplicationContext(), (peaks, err) -> {
            map.invalidate();
            if (peaks == null) {
                list.setText("No peaks saved for here yet. Tap MAP (needs internet once).");
                return;
            }
            List<PeakData.Peak> top = new ArrayList<>(peaks);
            top.sort((a, b) -> b.ele - a.ele);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(3, top.size()); i++) {
                PeakData.Peak p = top.get(i);
                sb.append(p.name).append("  ").append(p.ele).append(" m  ").append(p.distText()).append(' ')
                        .append(p.compass()).append('\n');
            }
            list.setText(sb.toString().trim());
        });
    }
}
