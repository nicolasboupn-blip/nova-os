package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.util.SizeF;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The 3D view: the camera picture with the peaks drawn where they really are. Hold the phone up and turn around. The
 * picture comes from the camera; the position of each name comes from the phone's rotation sensor, the peak's
 * direction and its height above you (with the curve of the earth taken into account).
 */
final class PeakArView extends FrameLayout implements SensorEventListener {
    private final NovaActivity host;
    private final TextureView tv;
    private final Overlay overlay;
    private final SensorManager sm;
    private final float[] raw = new float[9];
    private final float[] rot = new float[9];
    private final float[] smooth = new float[9];
    private boolean haveRot;
    private CameraDevice device;
    private CameraCaptureSession session;
    private HandlerThread thread;
    private Handler bg;
    private boolean opening;
    private boolean wanted;
    private Size previewSize;
    private int sensorOrientation = 90;
    private float fovLong = (float) Math.toRadians(66);
    private float fPx = 1000;
    PeakMapView.Pick listener;
    PeakData.Peak selected;

    PeakArView(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xFF000000);
        setClipChildren(true);
        sm = (SensorManager) host.getSystemService(Context.SENSOR_SERVICE);
        tv = new TextureView(host);
        addView(tv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        overlay = new Overlay(host);
        addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                openCamera();
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                closeCamera();
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
    }

    // ------------------------------------------------------------------ life

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        wanted = true;
        if (sm != null) {
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (s != null) {
                sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
            } else {
                host.toast("This phone has no rotation sensor");
            }
        }
        host.ask(new String[] {android.Manifest.permission.CAMERA}, this::openCamera,
                () -> host.toast("Camera is off for NOVA. You can still use the map."));
    }

    @Override
    protected void onDetachedFromWindow() {
        wanted = false;
        if (sm != null) {
            sm.unregisterListener(this);
        }
        closeCamera();
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ sensor

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(raw, e.values);
        int r = host.getWindowManager().getDefaultDisplay().getRotation();
        if (r == Surface.ROTATION_90) {
            SensorManager.remapCoordinateSystem(raw, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, rot);
        } else if (r == Surface.ROTATION_270) {
            SensorManager.remapCoordinateSystem(raw, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, rot);
        } else if (r == Surface.ROTATION_180) {
            SensorManager.remapCoordinateSystem(raw, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, rot);
        } else {
            System.arraycopy(raw, 0, rot, 0, 9);
        }
        if (!haveRot) {
            System.arraycopy(rot, 0, smooth, 0, 9);
            haveRot = true;
        } else {
            for (int i = 0; i < 9; i++) {
                smooth[i] += (rot[i] - smooth[i]) * 0.35f;
            }
        }
        overlay.invalidate();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /** Where the camera looks, in degrees from north, and how high above the horizon. */
    float[] looking() {
        double e = -smooth[2];
        double n = -smooth[5];
        double u = -smooth[8];
        return new float[] {(float) ((Math.toDegrees(Math.atan2(e, n)) + 360) % 360),
            (float) Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, u))))};
    }

    // ------------------------------------------------------------------ camera

    private void openCamera() {
        if (opening || device != null || !wanted || tv.getSurfaceTexture() == null) {
            return;
        }
        if (host.checkSelfPermission(android.Manifest.permission.CAMERA)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        opening = true;
        try {
            CameraManager cm = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            CameraCharacteristics chars = null;
            for (String cid : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(cid);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = cid;
                    chars = c;
                    break;
                }
            }
            if (id == null) {
                opening = false;
                host.toast("No back camera");
                return;
            }
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = so == null ? 90 : so;
            SizeF phys = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            float[] focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            if (phys != null && focal != null && focal.length > 0 && focal[0] > 0) {
                fovLong = (float) (2 * Math.atan(Math.max(phys.getWidth(), phys.getHeight()) / (2 * focal[0])));
            }
            previewSize = choose(map.getOutputSizes(SurfaceTexture.class));
            fit();
            if (thread == null) {
                thread = new HandlerThread("nova-peak-camera");
                thread.start();
                bg = new Handler(thread.getLooper());
            }
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    device = camera;
                    opening = false;
                    startPreview();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    device = null;
                    opening = false;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    device = null;
                    opening = false;
                }
            }, bg);
        } catch (Throwable t) {
            opening = false;
            host.toast("Camera problem");
        }
    }

    private static Size choose(Size[] sizes) {
        Size best = null;
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            double ratio = s.getWidth() / (double) s.getHeight();
            if (area <= 1920 * 1080 && ratio > 1.3 && ratio < 1.8) {
                if (best == null || area > (long) best.getWidth() * best.getHeight()) {
                    best = s;
                }
            }
        }
        return best != null ? best : sizes[0];
    }

    /** Fills the whole screen with the picture (the edges are cropped) and works out the lens in pixels. */
    private void fit() {
        post(() -> {
            int hw = getWidth();
            int hh = getHeight();
            if (hw == 0 || hh == 0 || previewSize == null) {
                return;
            }
            boolean turned = sensorOrientation % 180 == 90;
            double ratio = turned ? previewSize.getHeight() / (double) previewSize.getWidth()
                    : previewSize.getWidth() / (double) previewSize.getHeight();
            int w;
            int h;
            if (hw / (double) hh > ratio) {
                w = hw;
                h = (int) (hw / ratio);
            } else {
                h = hh;
                w = (int) (hh * ratio);
            }
            tv.setLayoutParams(new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
            // the long side of the sensor is the long side of the picture
            fPx = Math.max(w, h) / (2f * (float) Math.tan(fovLong / 2f));
        });
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fit();
    }

    private void startPreview() {
        try {
            SurfaceTexture st = tv.getSurfaceTexture();
            if (st == null || device == null) {
                return;
            }
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            final Surface ps = new Surface(st);
            final CaptureRequest.Builder req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            req.addTarget(ps);
            req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            device.createCaptureSession(java.util.Arrays.asList(ps), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession s) {
                    if (device == null) {
                        return;
                    }
                    session = s;
                    try {
                        s.setRepeatingRequest(req.build(), null, bg);
                    } catch (Throwable t) {
                        // preview stays black
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession s) {
                }
            }, bg);
        } catch (Throwable t) {
            host.toast("Camera problem");
        }
    }

    private void closeCamera() {
        try {
            if (session != null) {
                session.close();
            }
        } catch (Throwable ignored) {
            // already closed
        }
        session = null;
        try {
            if (device != null) {
                device.close();
            }
        } catch (Throwable ignored) {
            // already closed
        }
        device = null;
        opening = false;
    }

    // ------------------------------------------------------------------ drawing

    private final class Overlay extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final List<PeakData.Peak> hits = new ArrayList<>();
        private final List<float[]> hitPos = new ArrayList<>();

        Overlay(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        /** Peak direction in the phone's frame: x right, y up, z out of the screen. */
        private float[] project(double bearingDeg, double upDeg) {
            double b = Math.toRadians(bearingDeg);
            double u = Math.toRadians(upDeg);
            double de = Math.cos(u) * Math.sin(b);
            double dn = Math.cos(u) * Math.cos(b);
            double du = Math.sin(u);
            double dx = smooth[0] * de + smooth[3] * dn + smooth[6] * du;
            double dy = smooth[1] * de + smooth[4] * dn + smooth[7] * du;
            double dz = smooth[2] * de + smooth[5] * dn + smooth[8] * du;
            if (dz >= -0.05) {
                return null; // behind the camera
            }
            return new float[] {getWidth() / 2f + (float) (dx / -dz) * fPx, getHeight() / 2f - (float) (dy / -dz) * fPx};
        }

        @Override
        protected void onDraw(Canvas cv) {
            hits.clear();
            hitPos.clear();
            p.setStyle(Paint.Style.FILL);
            if (!haveRot) {
                p.setColor(0xCCFFFFFF);
                p.setTextSize(13 * d);
                p.setTextAlign(Paint.Align.CENTER);
                cv.drawText("waiting for the compass...", getWidth() / 2f, getHeight() / 2f, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            // the horizon
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(0x88FFFFFF);
            float[] look = looking();
            float[] prev = null;
            for (int a = -60; a <= 60; a += 4) {
                float[] q = project(look[0] + a, 0);
                if (q != null && prev != null) {
                    cv.drawLine(prev[0], prev[1], q[0], q[1], p);
                }
                prev = q;
            }
            // heading ticks along the horizon
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(11 * d);
            p.setTextAlign(Paint.Align.CENTER);
            String[] n8 = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            for (int a = 0; a < 360; a += 45) {
                float[] q = project(a, 0);
                if (q != null) {
                    p.setColor(a == 0 ? 0xFFFF6B6B : 0xDDFFFFFF);
                    cv.drawText(n8[a / 45], q[0], q[1] + 16 * d, p);
                }
            }
            p.setTextAlign(Paint.Align.LEFT);

            List<PeakData.Peak> list;
            synchronized (PeakData.peaks) {
                list = new ArrayList<>(PeakData.peaks);
            }
            // closest to the sky first, then the high ones
            Collections.sort(list, (a, b) -> Double.compare(b.up + b.ele / 4000.0, a.up + a.ele / 4000.0));
            List<RectF> used = new ArrayList<>();
            p.setTextSize(11 * d);
            int shown = 0;
            for (PeakData.Peak pk : list) {
                if (pk.dist > PeakData.km * 1000.0 || shown > 70) {
                    continue;
                }
                float[] q = project(pk.bearing, pk.up);
                if (q == null || q[0] < -40 || q[0] > getWidth() + 40 || q[1] < -40 || q[1] > getHeight() + 40) {
                    continue;
                }
                boolean sel = pk == selected;
                String l1 = pk.name;
                String l2 = pk.ele + " m · " + pk.distText();
                float tw = Math.max(p.measureText(l1), p.measureText(l2)) + 12 * d;
                float th = 32 * d;
                RectF r = null;
                for (int step = 0; step < 6; step++) {
                    RectF t = new RectF(q[0] - tw / 2f, q[1] - 14 * d - th - step * (th + 3 * d), q[0] + tw / 2f,
                            q[1] - 14 * d - step * (th + 3 * d));
                    boolean free = true;
                    for (RectF u : used) {
                        if (RectF.intersects(u, t)) {
                            free = false;
                            break;
                        }
                    }
                    if (free) {
                        r = t;
                        break;
                    }
                }
                if (r == null && !sel) {
                    continue;
                }
                if (r == null) {
                    r = new RectF(q[0] - tw / 2f, q[1] - 14 * d - th, q[0] + tw / 2f, q[1] - 14 * d);
                }
                used.add(r);
                shown++;
                int alpha = pk.hidden && !sel ? 0x88000000 : 0xCC000000;
                p.setStyle(Paint.Style.FILL);
                p.setColor(alpha);
                cv.drawRoundRect(r, 8 * d, 8 * d, p);
                p.setColor(sel ? 0xFFFFFFFF : pk.hidden ? 0xFF9AA3BD : Theme.ACCENT);
                p.setStrokeWidth(1.5f * d);
                cv.drawLine(q[0], r.bottom, q[0], q[1], p);
                cv.drawCircle(q[0], q[1], 3.5f * d, p);
                p.setColor(0xFFFFFFFF);
                cv.drawText(l1, r.left + 6 * d, r.top + 13 * d, p);
                p.setColor(0xFFB9C2DC);
                p.setTextSize(9.5f * d);
                cv.drawText(l2, r.left + 6 * d, r.top + 26 * d, p);
                p.setTextSize(11 * d);
                hits.add(pk);
                hitPos.add(new float[] {r.centerX(), r.centerY()});
            }
            // crosshair and heading
            p.setColor(0xAAFFFFFF);
            p.setStrokeWidth(d);
            cv.drawLine(getWidth() / 2f - 10 * d, getHeight() / 2f, getWidth() / 2f + 10 * d, getHeight() / 2f, p);
            cv.drawLine(getWidth() / 2f, getHeight() / 2f - 10 * d, getWidth() / 2f, getHeight() / 2f + 10 * d, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(12 * d);
            p.setColor(0xFFFFFFFF);
            cv.drawText(Math.round(look[0]) + "° " + n8[(int) Math.round(look[0] / 45.0) % 8] + "   "
                    + (look[1] >= 0 ? "+" : "") + Math.round(look[1]) + "°", getWidth() / 2f, 28 * d, p);
            p.setTextAlign(Paint.Align.LEFT);
            if (!PeakData.have || PeakData.peaks.isEmpty()) {
                p.setColor(0xCCFFFFFF);
                p.setTextAlign(Paint.Align.CENTER);
                cv.drawText(PeakData.have ? "loading peaks..." : "finding your position...", getWidth() / 2f,
                        getHeight() - 40 * d, p);
                p.setTextAlign(Paint.Align.LEFT);
            }
            postInvalidateOnAnimation();
        }

        @Override
        public boolean onTouchEvent(android.view.MotionEvent e) {
            if (e.getAction() == android.view.MotionEvent.ACTION_UP) {
                PeakData.Peak best = null;
                float bd = 40 * d;
                for (int i = 0; i < hits.size(); i++) {
                    float[] q = hitPos.get(i);
                    float dd = (float) Math.hypot(q[0] - e.getX(), q[1] - e.getY());
                    if (dd < bd) {
                        bd = dd;
                        best = hits.get(i);
                    }
                }
                selected = best;
                if (listener != null) {
                    listener.picked(best);
                }
                invalidate();
            }
            return true;
        }
    }
}
