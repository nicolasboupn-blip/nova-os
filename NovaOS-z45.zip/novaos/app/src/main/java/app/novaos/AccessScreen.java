package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import java.util.Random;

/**
 * The "Access" startup: a fake system check with a roulette wheel, the castle, a slot machine and
 * the wizard, then a big open green padlock and "ACCESS ACCEPTED". Tap to skip.
 */
final class AccessScreen extends FrameLayout {
    static final String K_ON = "s_acc_on";
    static final String K_SECS = "s_acc_secs";
    static final String K_AWAY = "s_acc_away";
    static final String K_LAST = "s_acc_last";
    static final String[] AWAY_NAMES = {"Always", "5 min", "15 min", "30 min", "1 hour", "3 hours", "6 hours", "12 hours"};
    static final int[] AWAY_MIN = {0, 5, 15, 30, 60, 180, 360, 720};
    private static final int GREEN = 0xFF39FF88;

    /** True if the sequence should play for this unlock. */
    static boolean shouldPlay() {
        if (!Prefs.getBool(K_ON, false) || Saver.on()) {
            return false;
        }
        int i = Math.max(0, Math.min(AWAY_MIN.length - 1, Prefs.getInt(K_AWAY, 4)));
        int last = Prefs.getInt(K_LAST, 0);
        return last == 0 || Castle.nowMin() - last >= AWAY_MIN[i];
    }

    static int seconds() {
        return Math.max(2, Math.min(20, Prefs.getInt(K_SECS, 8)));
    }

    private static final String[] STATUS = {
        "Greasing the roulette wheel", "Checking the castle gates", "Counting the slot reels",
        "Waking the wizard", "Verifying identity", "Almost there"};
    private static final String[] SYM = {"7", "$", "★", "♦", "BAR"};
    private static final int[] SYM_COL = {0xFFFF3B4E, 0xFF39FF88, 0xFFFFD34D, 0xFF5CC8FF, 0xFFFFFFFF};
    private static final float[][] CURVE = {
        {0f, 0f}, {0.12f, 0.08f}, {0.30f, 0.14f}, {0.42f, 0.55f}, {0.60f, 0.60f},
        {0.78f, 0.90f}, {0.90f, 0.93f}, {1f, 1f}};

    private final NovaActivity host;
    private final boolean test;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Stage stage;
    private final RouletteWheel wheel;
    private final Bitmap castle;
    private final Bitmap wizard;
    private final float dens;
    private ValueAnimator run;
    private ValueAnimator open;
    private float prog;
    private float openT;
    private boolean accepted;
    private boolean left;
    private boolean attached = true;
    private final float[] pos = new float[3];
    private final boolean[] stopped = new boolean[3];
    private final float[] stopAt = {0.55f, 0.70f, 0.84f};
    private long lastNs;

    AccessScreen(NovaActivity host, boolean test) {
        super(host);
        this.host = host;
        this.test = test;
        dens = host.getResources().getDisplayMetrics().density;
        setBackgroundColor(Color.BLACK);
        castle = load(host, "castle_night");
        wizard = WizardView.loadSprite(host);
        stage = new Stage(host);
        addView(stage, new LayoutParams(-1, -1));
        wheel = new RouletteWheel(host);
        addView(wheel, new LayoutParams(10, 10));
        spinWheel();

        run = ValueAnimator.ofFloat(0f, 1f);
        run.setDuration(seconds() * 1000L);
        run.setInterpolator(new LinearInterpolator());
        run.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            prog = curve(t);
            stage.invalidate();
        });
        run.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                accept();
            }
        });
        run.start();
        setOnClickListener(v -> {
            if (accepted) {
                leave();
            } else {
                run.cancel();
            }
        });
    }

    private static Bitmap load(Context c, String name) {
        int id = c.getResources().getIdentifier(name, "drawable", c.getPackageName());
        if (id == 0) {
            return null;
        }
        android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
        o.inScaled = false;
        return android.graphics.BitmapFactory.decodeResource(c.getResources(), id, o);
    }

    private static float curve(float t) {
        for (int i = 1; i < CURVE.length; i++) {
            if (t <= CURVE[i][0]) {
                float a = (t - CURVE[i - 1][0]) / (CURVE[i][0] - CURVE[i - 1][0]);
                return CURVE[i - 1][1] + (CURVE[i][1] - CURVE[i - 1][1]) * a;
            }
        }
        return 1f;
    }

    private void spinWheel() {
        if (accepted || !attached) {
            return;
        }
        wheel.spin(rnd.nextInt(37), () -> handler.postDelayed(this::spinWheel, 150));
    }

    private void accept() {
        if (accepted) {
            return;
        }
        accepted = true;
        prog = 1f;
        for (int i = 0; i < 3; i++) {
            stopped[i] = true;
        }
        wheel.animate().alpha(0.12f).setDuration(500).start();
        Sfx.play(Sfx.WIN);
        host.buzz(80);
        open = ValueAnimator.ofFloat(0f, 1f);
        open.setDuration(900);
        open.setStartDelay(250);
        open.addUpdateListener(a -> {
            openT = (float) a.getAnimatedValue();
            stage.invalidate();
        });
        open.start();
        handler.postDelayed(this::leave, 2900);
    }

    private void leave() {
        if (left) {
            return;
        }
        left = true;
        host.showHome();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int s = (int) Math.min(w * 0.42f, h * 0.30f);
        LayoutParams lp = (LayoutParams) wheel.getLayoutParams();
        lp.width = s;
        lp.height = s;
        lp.leftMargin = (int) (w * 0.25f - s / 2f);
        lp.topMargin = (int) (h * 0.07f + (h * 0.30f - s) / 2f);
        wheel.setLayoutParams(lp);
    }

    @Override
    protected void onDetachedFromWindow() {
        attached = false;
        handler.removeCallbacksAndMessages(null);
        if (run != null) {
            run.removeAllListeners();
            run.cancel();
        }
        if (open != null) {
            open.cancel();
        }
        super.onDetachedFromWindow();
    }

    /** Everything except the wheel is drawn here. */
    private final class Stage extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint px = new Paint();
        private final Path path = new Path();
        private final RectF r = new RectF();
        private Shader castleGlow;
        private Shader barShader;
        private int gw = -1;

        Stage(Context c) {
            super(c);
            px.setFilterBitmap(false);
            p.setTypeface(Typeface.MONOSPACE);
        }

        private float d(float v) {
            return v * dens;
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            float tm = now / 1e9f;
            float dim = accepted ? 1f - 0.8f * Math.min(1f, openT * 2f) : 1f;

            c.save();
            drawCastle(c, w, h, tm, dim);
            drawSlot(c, w, h, dt, dim);
            drawWizard(c, w, h, tm, dim);
            drawHud(c, w, h, tm);
            c.restore();
            if (accepted) {
                drawLock(c, w, h, tm);
            }
            postInvalidateOnAnimation();
        }

        private void drawCastle(Canvas c, int w, int h, float tm, float dim) {
            float cx = w * 0.75f;
            float top = h * 0.07f;
            float ch = h * 0.30f;
            if (gw != w) {
                gw = w;
                castleGlow = null;
            }
            float pulse = 0.75f + 0.25f * (float) Math.sin(tm * 3f);
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, top + ch / 2f, ch * 0.8f,
                    (Theme.ACCENT & 0xFFFFFF) | ((int) (90 * pulse * dim) << 24),
                    Theme.ACCENT & 0xFFFFFF, Shader.TileMode.CLAMP));
            c.drawCircle(cx, top + ch / 2f, ch * 0.8f, p);
            p.setShader(null);
            if (castle != null) {
                int s = Math.max(1, (int) (ch / castle.getHeight()));
                float dw = castle.getWidth() * s;
                float dh = castle.getHeight() * s;
                r.set(cx - dw / 2f, top + (ch - dh) / 2f, cx + dw / 2f, top + (ch + dh) / 2f);
                px.setAlpha((int) (255 * dim));
                c.drawBitmap(castle, null, r, px);
                px.setAlpha(255);
            }
        }

        private void drawSlot(Canvas c, int w, int h, float dt, float dim) {
            float cx = w * 0.25f;
            float cellH = d(46);
            float cellW = d(42);
            float gap = d(6);
            float total = cellW * 3 + gap * 4;
            float top = h * 0.63f + (h * 0.30f - cellH - d(24)) / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb((int) (255 * dim), 40, 12, 24));
            r.set(cx - total / 2f, top - d(10), cx + total / 2f, top + cellH + d(10));
            c.drawRoundRect(r, d(10), d(10), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(d(2.5f));
            p.setColor(Color.argb((int) (255 * dim), 255, 211, 77));
            c.drawRoundRect(r, d(10), d(10), p);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 3; i++) {
                if (!stopped[i] && prog >= stopAt[i]) {
                    stopped[i] = true;
                    host.buzz(25);
                    Sfx.play(Sfx.CLICK);
                }
                if (!stopped[i]) {
                    pos[i] += dt * (14f + i * 2f);
                } else {
                    float target = (float) Math.ceil(pos[i] / SYM.length) * SYM.length;
                    pos[i] += (target - pos[i]) * Math.min(1f, dt * 10f);
                    if (target - pos[i] < 0.02f) {
                        pos[i] = target;
                    }
                }
                float x0 = cx - total / 2f + gap + i * (cellW + gap);
                r.set(x0, top, x0 + cellW, top + cellH);
                p.setColor(Color.argb((int) (255 * dim), 245, 240, 230));
                c.drawRect(r, p);
                c.save();
                c.clipRect(r);
                int base = (int) Math.floor(pos[i]);
                float frac = pos[i] - base;
                p.setTextAlign(Paint.Align.CENTER);
                p.setFakeBoldText(true);
                for (int k = -1; k <= 2; k++) {
                    int idx = Math.floorMod(base + k, SYM.length);
                    // symbol base+k sits (k - frac) rows below the centre line
                    float yc = top + cellH / 2f + (k - frac) * cellH;
                    p.setTextSize(idx == 4 ? d(15) : d(28));
                    p.setColor(SYM_COL[idx] == 0xFFFFFFFF ? 0xFF222222 : SYM_COL[idx]);
                    p.setAlpha((int) (255 * dim));
                    c.drawText(SYM[idx], x0 + cellW / 2f, yc + (idx == 4 ? d(5) : d(10)), p);
                }
                c.restore();
                p.setFakeBoldText(false);
                p.setAlpha(255);
            }
        }

        private void drawWizard(Canvas c, int w, int h, float tm, float dim) {
            float cx = w * 0.75f;
            float top = h * 0.63f;
            float ch = h * 0.30f;
            float bob = (float) Math.sin(tm * 2.4f) * d(4);
            if (wizard != null) {
                int s = Math.max(1, (int) (ch / wizard.getHeight()));
                float dw = wizard.getWidth() * s;
                float dh = wizard.getHeight() * s;
                r.set(cx - dw / 2f, top + (ch - dh) / 2f + bob, cx + dw / 2f, top + (ch + dh) / 2f + bob);
                px.setAlpha((int) (255 * dim));
                c.drawBitmap(wizard, null, r, px);
                px.setAlpha(255);
            }
            // magic sparks orbiting
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 6; i++) {
                float a = tm * 1.8f + i * 1.0472f;
                float sx = cx + (float) Math.cos(a) * d(48);
                float sy = top + ch / 2f + (float) Math.sin(a * 1.3f) * ch * 0.42f + bob;
                p.setColor(Color.argb((int) (200 * dim), 179, 157, 255));
                c.drawCircle(sx, sy, d(2.2f), p);
            }
        }

        private void drawHud(Canvas c, int w, int h, float tm) {
            float bw = w * 0.78f;
            float bx = (w - bw) / 2f;
            float by = h * 0.50f;
            float bh = d(12);
            float fade = accepted ? Math.max(0f, 1f - openT * 2f) : 1f;
            if (fade <= 0f) {
                return;
            }
            p.setTextAlign(Paint.Align.CENTER);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(d(12));
            p.setColor(Theme.DIM);
            p.setAlpha((int) (255 * fade));
            int si = Math.min(STATUS.length - 1, (int) (prog * STATUS.length));
            c.drawText(STATUS[si] + dots(tm), w / 2f, by - d(14), p);
            p.setColor(Color.argb((int) (255 * fade), 30, 26, 50));
            r.set(bx, by, bx + bw, by + bh);
            c.drawRoundRect(r, bh / 2f, bh / 2f, p);
            if (barShader == null || gw != w) {
                barShader = new LinearGradient(bx, 0, bx + bw, 0, Theme.ACCENT, GREEN, Shader.TileMode.CLAMP);
            }
            p.setShader(barShader);
            p.setAlpha((int) (255 * fade));
            r.set(bx, by, bx + Math.max(bh, bw * prog), by + bh);
            c.drawRoundRect(r, bh / 2f, bh / 2f, p);
            p.setShader(null);
            p.setColor(Theme.TEXT);
            p.setAlpha((int) (255 * fade));
            p.setTextSize(d(18));
            c.drawText((int) (prog * 100) + "%", w / 2f, by + bh + d(26), p);
            p.setAlpha(255);
        }

        private String dots(float tm) {
            int n = (int) (tm * 3) % 4;
            return "...".substring(0, n);
        }

        private void drawLock(Canvas c, int w, int h, float tm) {
            float o = openT;
            float bw = Math.min(w * 0.44f, h * 0.22f);
            float bh = bw * 0.80f;
            float cx = w / 2f;
            float cy = h * 0.42f;
            float bTop = cy - bh / 2f + bw * 0.25f;
            // glow
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx, cy, bw * 1.5f,
                    ((int) (140 * Math.min(1f, o + 0.3f)) << 24) | (GREEN & 0xFFFFFF),
                    GREEN & 0xFFFFFF, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, bw * 1.5f, p);
            p.setShader(null);
            // shackle: swings open around its left foot
            float sw = bw * 0.62f;
            float stroke = bw * 0.14f;
            float xl = cx - sw / 2f;
            float xr = cx + sw / 2f;
            float legTop = bTop - bw * 0.34f;
            c.save();
            c.translate(0f, -bw * 0.18f * o);
            c.rotate(-28f * o, xl, bTop);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(stroke);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0xFFD7FFE6);
            path.reset();
            path.moveTo(xl, bTop + stroke);
            path.lineTo(xl, legTop);
            r.set(xl, legTop - sw / 2f, xr, legTop + sw / 2f);
            path.arcTo(r, 180f, 180f, false);
            path.lineTo(xr, bTop + stroke);
            c.drawPath(path, p);
            c.restore();
            p.setStrokeCap(Paint.Cap.BUTT);
            // body
            p.setStyle(Paint.Style.FILL);
            r.set(cx - bw / 2f, bTop, cx + bw / 2f, bTop + bh);
            p.setColor(GREEN);
            c.drawRoundRect(r, bw * 0.12f, bw * 0.12f, p);
            p.setColor(0xFF0B7A3B);
            c.drawCircle(cx, bTop + bh * 0.42f, bw * 0.10f, p);
            r.set(cx - bw * 0.04f, bTop + bh * 0.42f, cx + bw * 0.04f, bTop + bh * 0.72f);
            c.drawRoundRect(r, bw * 0.03f, bw * 0.03f, p);
            // text
            float ta = Math.max(0f, Math.min(1f, (o - 0.3f) / 0.7f));
            p.setTextAlign(Paint.Align.CENTER);
            p.setFakeBoldText(true);
            p.setTextSize(Math.min(w * 0.095f, d(40)));
            p.setColor(GREEN);
            p.setAlpha((int) (255 * ta));
            p.setShadowLayer(d(14), 0, 0, GREEN);
            float ty = bTop + bh + bw * 0.55f;
            c.drawText("ACCESS", cx, ty, p);
            c.drawText("ACCEPTED", cx, ty + p.getTextSize() * 1.15f, p);
            p.setShadowLayer(0, 0, 0, 0);
            p.setFakeBoldText(false);
            p.setAlpha(255);
        }
    }
}
