package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Three Card Poker against the dealer.
 * ANTE, then PLAY (same amount again) or FOLD. The dealer only plays with Queen high or better.
 * ANTE BONUS pays on your hand even if you fold: straight 1 to 1, three of a kind 4 to 1, straight flush 5 to 1.
 * PAIR+ is an optional side bet on your hand alone: pair 1 to 1, flush 4 to 1, straight 6 to 1, three of a kind 30 to 1,
 * straight flush 40 to 1.
 */
final class GamePoker extends Game {
    static final String HELP =
            "THREE CARD POKER, IN SHORT\n\n"
            + "1. Pick a chip and press DEAL. That is your ANTE. You and the dealer each get three cards.\n\n"
            + "2. Look at your hand. PLAY adds the same amount again, and the hands are compared. FOLD gives up the ante.\n\n"
            + "3. The dealer only plays with Queen high or better. If the dealer does not qualify, your ante wins 1 to 1 and your PLAY is returned.\n\n"
            + "4. Better hands win: straight flush, three of a kind, straight, flush, pair, then high card. If both hands are the same, the higher cards win.\n\n"
            + "PAIR+ (optional) is a side bet on your three cards only. It ignores the dealer, and pays even when you fold.\n"
            + "Pair 1 to 1  ·  Flush 4 to 1  ·  Straight 6 to 1  ·  Three of a kind 30 to 1  ·  Straight flush 40 to 1\n\n"
            + "ANTE BONUS pays on your hand even when you fold.\n"
            + "Straight 1 to 1  ·  Three of a kind 4 to 1  ·  Straight flush 5 to 1";

    private static final int[] CHIPS = {5, 10, 25, 50, 100, 1000, 10000, 100000, 1000000};
    private static final String[] SUITS = {"♠", "♥", "♦", "♣"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    private static final String[] HANDS = {"HIGH CARD", "PAIR", "FLUSH", "STRAIGHT", "THREE OF A KIND", "STRAIGHT FLUSH"};

    private final Random rnd = new Random();
    private final int[] player = new int[3];
    private final int[] dealer = new int[3];
    private final LinearLayout dealerRow;
    private final LinearLayout playerRow;
    private final TextView dealerLabel;
    private final TextView playerLabel;
    private final TextView message;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView pairBtn;
    private final TextView helpBtn;
    private final ScrollView helpPanel;
    private final TextView dealBtn;
    private final TextView playBtn;
    private final TextView foldBtn;
    private int chip = 1;
    private boolean pairOn;
    private int ante;
    private int pairStake;
    /** 0 betting, 1 cards out and waiting for PLAY or FOLD. */
    private int state;

    GamePoker(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(56), dp(16), dp(20));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        coinsText = label("", 13f, Theme.TEXT);
        betText = label("", 13f, Theme.ACCENT);
        LinearLayout top = new LinearLayout(host);
        coinsText.setGravity(Gravity.START);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dealerLabel = label("DEALER", 12f, Theme.DIM);
        col.addView(dealerLabel, wrapTop(dp(18)));
        dealerRow = handRow();
        col.addView(dealerRow);

        message = label("ANTE IN, THEN DEAL", 13f, Theme.DIM);
        message.setLetterSpacing(0.08f);
        col.addView(message, wrapTop(dp(12)));

        playerRow = handRow();
        col.addView(playerRow);
        playerLabel = label("YOU", 12f, Theme.DIM);
        col.addView(playerLabel);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(Upgrades.chipName(CHIPS[i]), CHIPS[i] >= 1000 ? 10f : 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (state == 0) {
                    chip = idx;
                    styleChips();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            cp.setMargins(dp(1), 0, dp(1), 0);
            chips.addView(c, cp);
        }
        col.addView(chips, wrapTop(dp(16)));

        LinearLayout extras = new LinearLayout(host);
        extras.setGravity(Gravity.CENTER);
        pairBtn = actionButton("PAIR+ OFF", Theme.PANEL, () -> {
            if (state == 0) {
                pairOn = !pairOn;
                refresh();
            }
        });
        helpBtn = actionButton("HOW TO PLAY", Theme.PANEL, this::toggleHelp);
        extras.addView(pairBtn, actionParams());
        extras.addView(helpBtn, actionParams());
        col.addView(extras, wrapTop(dp(14)));

        helpPanel = new ScrollView(host);
        helpPanel.setBackground(Theme.rounded(0xFF1A1230, 14f, host));
        helpPanel.setPadding(dp(14), dp(12), dp(14), dp(12));
        TextView helpText = label(HELP, 11f, Theme.TEXT);
        helpText.setGravity(Gravity.START);
        helpText.setLineSpacing(dp(3), 1f);
        helpPanel.addView(helpText);
        helpPanel.setVisibility(GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260));
        hp.topMargin = dp(12);
        col.addView(helpPanel, hp);

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER);
        dealBtn = actionButton("DEAL", Theme.ACCENT, this::deal);
        playBtn = actionButton("PLAY x1", Theme.ACCENT, this::play);
        foldBtn = actionButton("FOLD", Theme.PANEL, this::fold);
        actions.addView(dealBtn, actionParams());
        actions.addView(playBtn, actionParams());
        actions.addView(foldBtn, actionParams());
        col.addView(actions, wrapTop(dp(14)));

        styleChips();
        showCards(false);
        refresh();
    }

    @Override
    String title() {
        return "THREE CARD POKER";
    }

    private void toggleHelp() {
        helpPanel.setVisibility(helpPanel.getVisibility() == VISIBLE ? GONE : VISIBLE);
        helpBtn.setText(helpPanel.getVisibility() == VISIBLE ? "CLOSE HELP" : "HOW TO PLAY");
    }

    private LinearLayout.LayoutParams wrapTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout.LayoutParams actionParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private TextView actionButton(String text, int color, Runnable action) {
        TextView b = button(text, action);
        b.setTextColor(color == Theme.ACCENT ? Theme.BG : Theme.TEXT);
        b.setBackground(Theme.rounded(color, 16f, host));
        return b;
    }

    private LinearLayout handRow() {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setMinimumHeight(dp(78));
        return row;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void refresh() {
        coinsText.setText("COINS " + coins());
        betText.setText("ANTE " + Upgrades.chipName(CHIPS[chip]) + (pairOn ? "  ·  PAIR+ ON" : ""));
        pairBtn.setText(pairOn ? "PAIR+ ON" : "PAIR+ OFF");
        pairBtn.setTextColor(pairOn ? Theme.BG : Theme.TEXT);
        pairBtn.setBackground(Theme.rounded(pairOn ? Theme.ACCENT : Theme.PANEL, 16f, host));
        dealBtn.setVisibility(state == 0 ? VISIBLE : GONE);
        playBtn.setVisibility(state == 1 ? VISIBLE : GONE);
        foldBtn.setVisibility(state == 1 ? VISIBLE : GONE);
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    // ------------------------------------------------------------------ cards

    /** A card code is rank * 4 + suit, rank 0 = two ... 12 = ace. */
    private TextView card(int code) {
        int rank = code / 4;
        int suit = code % 4;
        TextView t = label(RANKS[rank] + SUITS[suit], 15f, 0);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFFF4F0FF, 8f, host));
        t.setTextColor(suit % 2 == 0 ? 0xFF1C1626 : 0xFFB3243A);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(70));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView cardBack() {
        TextView t = label("?", 18f, Theme.ACCENT);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFF3B2B66, 8f, host));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(70));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void showCards(boolean reveal) {
        playerRow.removeAllViews();
        dealerRow.removeAllViews();
        if (state == 0 && !reveal) {
            for (int i = 0; i < 3; i++) {
                playerRow.addView(cardBack());
                dealerRow.addView(cardBack());
            }
            playerLabel.setText("YOU");
            dealerLabel.setText("DEALER");
            return;
        }
        for (int i = 0; i < 3; i++) {
            playerRow.addView(card(player[i]));
            dealerRow.addView(reveal ? card(dealer[i]) : cardBack());
        }
        playerLabel.setText("YOU  ·  " + HANDS[score(player) / 1000000 - 1]);
        dealerLabel.setText(reveal ? "DEALER  ·  " + HANDS[score(dealer) / 1000000 - 1] : "DEALER  ·  ?");
    }

    // ------------------------------------------------------------------ rules

    /** Higher is better. rank * 1000000 + a tie breaker, rank 1 high card ... 6 straight flush. */
    static int score(int[] cards) {
        int[] v = new int[3];
        boolean flush = true;
        for (int i = 0; i < 3; i++) {
            v[i] = cards[i] / 4 + 2;
            if (cards[i] % 4 != cards[0] % 4) {
                flush = false;
            }
        }
        Integer[] sorted = {v[0], v[1], v[2]};
        java.util.Arrays.sort(sorted, Collections.reverseOrder());
        for (int i = 0; i < 3; i++) {
            v[i] = sorted[i];
        }
        boolean trips = v[0] == v[1] && v[1] == v[2];
        boolean pair = v[0] == v[1] || v[1] == v[2];
        boolean wheel = v[0] == 14 && v[1] == 3 && v[2] == 2;   // A-2-3 is the lowest straight
        boolean straight = (v[0] == v[1] + 1 && v[1] == v[2] + 1) || wheel;
        int high = wheel ? 3 : v[0];
        int rank;
        int tie;
        if (straight && flush) {
            rank = 6;
            tie = high;
        } else if (trips) {
            rank = 5;
            tie = v[0];
        } else if (straight) {
            rank = 4;
            tie = high;
        } else if (flush) {
            rank = 3;
            tie = v[0] * 10000 + v[1] * 100 + v[2];
        } else if (pair) {
            int p = v[0] == v[1] ? v[0] : v[1];
            int k = v[0] == v[1] ? v[2] : v[0];
            rank = 2;
            tie = p * 100 + k;
        } else {
            rank = 1;
            tie = v[0] * 10000 + v[1] * 100 + v[2];
        }
        return rank * 1000000 + tie;
    }

    private static boolean qualifies(int dealerScore) {
        int rank = dealerScore / 1000000;
        int highest = (dealerScore % 1000000) / 10000;
        return rank >= 2 || (rank == 1 && highest >= 12);   // Queen high or better
    }

    private static int bonusMultiplier(int rank) {
        return rank == 6 ? 5 : rank == 5 ? 4 : rank == 4 ? 1 : 0;
    }

    /** PAIR+ pays winnings of this many times the side bet, on the player's own hand. */
    private static int pairPlusMultiplier(int rank) {
        return rank == 6 ? 40 : rank == 5 ? 30 : rank == 4 ? 6 : rank == 3 ? 4 : rank == 2 ? 1 : 0;
    }

    // ------------------------------------------------------------------ flow

    private void deal() {
        if (state != 0) {
            return;
        }
        final int stake = CHIPS[chip];
        int side = pairOn ? stake : 0;
        if (coins() < stake + side) {
            message.setText(pairOn ? "NOT ENOUGH COINS FOR ANTE + PAIR+" : "NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake - side);
        ante = stake;
        pairStake = side;
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < 52; i++) {
            deck.add(i);
        }
        Collections.shuffle(deck, rnd);
        for (int i = 0; i < 3; i++) {
            player[i] = deck.get(i);
            dealer[i] = deck.get(3 + i);
        }
        state = 1;
        message.setText("PLAY (x1) OR FOLD");
        message.setTextColor(Theme.DIM);
        showCards(false);
        refresh();
    }

    private void play() {
        if (state != 1) {
            return;
        }
        if (coins() < ante) {
            message.setText("NOT ENOUGH COINS TO PLAY. FOLD INSTEAD.");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - ante);
        settle(true);
    }

    private void fold() {
        if (state != 1) {
            return;
        }
        settle(false);
    }

    private void settle(boolean played) {
        state = 2;
        int ps = score(player);
        int ds = score(dealer);
        int rank = ps / 1000000;
        int bonus = ante * bonusMultiplier(rank);
        int pairBack = pairStake > 0 && pairPlusMultiplier(rank) > 0 ? pairStake * (pairPlusMultiplier(rank) + 1) : 0;
        int spent = ante + pairStake + (played ? ante : 0);
        int back;
        String result;
        if (!played) {
            back = 0;
            result = "FOLDED";
        } else if (!qualifies(ds)) {
            back = 3 * ante;
            result = "DEALER DOES NOT QUALIFY";
        } else if (ps > ds) {
            back = 4 * ante;
            result = "YOU WIN";
        } else if (ps == ds) {
            back = 2 * ante;
            result = "PUSH";
        } else {
            back = 0;
            result = "DEALER WINS";
        }
        back += bonus + pairBack;
        Prefs.putInt("slot_coins", coins() + back);
        int net = back - spent;
        showCards(true);
        String extra = (bonus > 0 ? "  BONUS +" + bonus : "") + (pairBack > 0 ? "  PAIR+ " + HANDS[rank - 1] : "");
        if (net > 0) {
            message.setText(result + "  +" + net + extra);
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
        } else if (net == 0) {
            message.setText(result + "  PUSH" + extra);
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText(result + "  " + net + extra);
            message.setTextColor(0xFFFF6B7F);
            host.buzz(30);
        }
        if (rank >= 5) {
            Badges.unlock(host, "dice");
        }
        state = 0;
        refresh();
    }
}
