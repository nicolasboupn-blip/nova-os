package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.Random;

/**
 * WHACK: whack-a-mole on the 8 x 8 pads, on the phone screen and on a connected Launchpad at the same time.
 * Green pads are moles (+1), gold pads are rare and worth 5, red pads are bombs (-3, do not hit them). Hit moles in a row
 * for a streak multiplier. 45 seconds. Everything here runs on the main thread.
 */
final class DeckWhack {
    private DeckWhack() {}

    static final int IDLE = 0, COUNT = 1, RUN = 2;
    static final String[] LEVELS = {"Easy", "Normal", "Hard"};

    private static final int N = DeckBinds.SIZE;
    private static final long DURATION = 45000;
    private static final long STEP = 700; // one number of the countdown
    private static final int NONE = 0, MOLE = 1, GOLD = 2, BOMB = 3;

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static final Random RND = new Random();
    private static final int[] kind = new int[N];
    private static final long[] born = new long[N];
    private static final long[] life = new long[N];

    static int state = IDLE;
    /** Called whenever the score line or the pad colours changed. Set by the open deck. */
    static Runnable listener;
    /** The text of the last finished game, until the next one starts. */
    static String result = "";

    private static NovaActivity host;
    private static int level = 1;
    private static int score;
    private static int streak;
    private static int bestStreak;
    private static int hits;
    private static long t0;
    private static long nextSpawn;
    private static int lastCount;

    static boolean active() {
        return state != IDLE;
    }

    static int best(int lv) {
        return Prefs.getInt("whack_best_" + lv, 0);
    }

    // ------------------------------------------------------------------ the game

    static void start(NovaActivity h, int lv) {
        stop();
        host = h;
        level = Math.max(0, Math.min(2, lv));
        score = 0;
        streak = 0;
        bestStreak = 0;
        hits = 0;
        result = "";
        state = COUNT;
        t0 = SystemClock.uptimeMillis();
        lastCount = 0;
        for (int i = 0; i < N; i++) {
            kind[i] = NONE;
        }
        DeckMidi.lightAll();
        ui.removeCallbacks(TICK);
        ui.post(TICK);
        changed();
    }

    static void stop() {
        boolean was = state != IDLE;
        state = IDLE;
        ui.removeCallbacks(TICK);
        for (int i = 0; i < N; i++) {
            kind[i] = NONE;
        }
        if (was) {
            DeckMidi.lightAll();
            changed();
        }
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            if (state == IDLE) {
                return;
            }
            long now = SystemClock.uptimeMillis();
            if (state == COUNT) {
                int n = 3 - (int) ((now - t0) / STEP);
                if (n <= 0) {
                    state = RUN;
                    t0 = now;
                    nextSpawn = now + 150;
                    snd(0, 84);
                } else if (n != lastCount) {
                    lastCount = n;
                    snd(0, 72);
                }
            } else {
                long elapsed = now - t0;
                if (elapsed >= DURATION) {
                    finish();
                    return;
                }
                tickGame(now, elapsed / (float) DURATION);
            }
            changed();
            ui.postDelayed(this, 40);
        }
    };

    private static void tickGame(long now, float progress) {
        float slow = level == 0 ? 1.4f : level == 1 ? 1f : 0.75f;
        int count = 0;
        for (int i = 0; i < N; i++) {
            if (kind[i] != NONE) {
                if (now - born[i] >= life[i]) {
                    if (kind[i] != BOMB) {
                        streak = 0; // a mole got away
                    }
                    kind[i] = NONE;
                } else {
                    count++;
                }
            }
        }
        int max = 1 + (int) (progress * 3f) + (level == 2 ? 1 : 0);
        if (now >= nextSpawn && count < max) {
            int idx = RND.nextInt(N);
            for (int k = 0; k < N && kind[idx] != NONE; k++) {
                idx = (idx + 1) % N;
            }
            if (kind[idx] == NONE) {
                float baseLife = (1500f - 800f * progress) * slow;
                int roll = RND.nextInt(100);
                int bombChance = level == 0 ? 6 : level == 1 ? 12 : 16;
                if (roll < 8) {
                    kind[idx] = GOLD;
                    life[idx] = (long) (baseLife * 0.6f);
                } else if (roll < 8 + bombChance) {
                    kind[idx] = BOMB;
                    life[idx] = (long) (baseLife * 1.2f);
                } else {
                    kind[idx] = MOLE;
                    life[idx] = (long) baseLife;
                }
                born[idx] = now;
            }
            float gap = (900f - 450f * progress) * slow;
            nextSpawn = now + (long) (gap * (0.7f + 0.6f * RND.nextFloat()));
        }
    }

    private static void finish() {
        state = IDLE;
        ui.removeCallbacks(TICK);
        for (int i = 0; i < N; i++) {
            kind[i] = NONE;
        }
        int old = best(level);
        boolean record = score > old;
        if (record) {
            Prefs.putInt("whack_best_" + level, score);
        }
        result = "TIME UP  ·  " + score + " points  ·  " + hits + " hits  ·  longest streak " + bestStreak
                + (record ? "  ·  NEW BEST!" : "  ·  best " + old) + "  (" + LEVELS[level] + ")";
        int[] notes = {72, 76, 79, 84};
        for (int i = 0; i < notes.length; i++) {
            final int n = notes[i];
            ui.postDelayed(() -> snd(5, n), i * 140L);
        }
        for (int i = 0; i < 4; i++) {
            DeckRipple.hit(RND.nextInt(N));
        }
        DeckMidi.lightAll();
        changed();
    }

    /** A pad was hit, from the screen or from the Launchpad. */
    static void press(int idx) {
        if (state != RUN || idx < 0 || idx >= N) {
            return;
        }
        DeckRipple.hit(idx);
        int mult = 1 + Math.min(4, streak / 5);
        switch (kind[idx]) {
            case MOLE:
                score += mult;
                streak++;
                hits++;
                bestStreak = Math.max(bestStreak, streak);
                kind[idx] = NONE;
                snd(6, 60 + Math.min(streak, 12) * 2);
                buzz(12);
                break;
            case GOLD:
                score += 5 * mult;
                streak++;
                hits++;
                bestStreak = Math.max(bestStreak, streak);
                kind[idx] = NONE;
                snd(5, 88);
                buzz(25);
                break;
            case BOMB:
                score = Math.max(0, score - 3);
                streak = 0;
                kind[idx] = NONE;
                snd(7, 40);
                buzz(60);
                break;
            default:
                streak = 0; // whacked an empty pad
                snd(4, 40);
                break;
        }
        changed();
    }

    // ------------------------------------------------------------------ what the pads show

    private static int color(int idx, long now) {
        switch (kind[idx]) {
            case MOLE:
                return 0x38FF6A;
            case GOLD:
                return 0xFFC800;
            default:
                return 0xFF2030;
        }
    }

    /** The colour of a pad on the phone screen (ARGB). */
    static int argb(int idx) {
        if (kind[idx] == NONE) {
            return 0xFF1B1933;
        }
        long now = SystemClock.uptimeMillis();
        int c = color(idx, now);
        float left = 1f - (now - born[idx]) / (float) life[idx];
        if (left < 0.35f && (now / 110) % 2 == 0) {
            int r = ((c >> 16) & 0xFF) / 3;
            int g = ((c >> 8) & 0xFF) / 3;
            int b = (c & 0xFF) / 3;
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        return 0xFF000000 | c;
    }

    /** The colour of a pad on the Launchpad (red, green, blue 0 to 127). */
    static int[] led(int idx) {
        if (kind[idx] == NONE) {
            return new int[] {2, 2, 5};
        }
        int c = argb(idx);
        return new int[] {((c >> 16) & 0xFF) / 2, ((c >> 8) & 0xFF) / 2, (c & 0xFF) / 2};
    }

    /** The score line above the pads. */
    static String hud() {
        if (state == COUNT) {
            return "GET READY  " + Math.max(1, lastCount) + " ...";
        }
        if (state == RUN) {
            long left = Math.max(0, DURATION - (SystemClock.uptimeMillis() - t0));
            int mult = 1 + Math.min(4, streak / 5);
            return "SCORE " + score + "    TIME " + (left / 1000 + 1) + "    STREAK " + streak + " (x" + mult + ")"
                    + "    BEST " + best(level);
        }
        return result;
    }

    // ------------------------------------------------------------------ small helpers

    private static void changed() {
        Runnable s = DeckRipple.screen;
        if (s != null) {
            s.run();
        }
        DeckMidi.rippleFrame();
        Runnable l = listener;
        if (l != null) {
            l.run();
        }
    }

    private static void snd(int inst, int note) {
        if (DeckSound.enabled()) {
            DeckSound.preview(inst, note);
        }
    }

    private static void buzz(long ms) {
        NovaActivity h = host;
        if (h != null) {
            h.buzz(ms);
        }
    }
}
