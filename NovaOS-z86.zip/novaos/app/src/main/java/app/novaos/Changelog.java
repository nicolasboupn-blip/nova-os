package app.novaos;

import android.app.AlertDialog;

/** What changed in each version, and a one-time "what's new" popup after an update. */
final class Changelog {
    private Changelog() {}

    static final String TEXT =
            "3.12  Achievements and upgrades\n"
            + " - Edit home layout (Settings > HOME LAYOUT): icons wiggle, drag one onto another to swap places, tap DONE\n"
            + " - Castle visitors: knight every ~40 min, merchant every ~10 min, thief every ~3 hours. Admin can send any of them. The merchant and Margon now have short conversations at the gate\n"
            + " - Admin mode unlocks the achievements admin cannot reach by playing (cosmetic collector 5/20/50, Zigzag castle skins, full Zigzag set). No coin rewards\n"
            + " - New VEHICLES page on the status panel: name one of 100 military vehicles from its side silhouette. Right +200 coins, wrong -1000 coins\n"
            + " - Bets of 100K and 1M in slots, roulette, blackjack and dice. Chips share the row evenly now\n"
            + " - New DUEL game on the Games page (page 3): pass-the-phone for 2 to 4 players, best of three rounds. REACTION or TAP RACE\n"
            + " - New LAUNCH DECK: a Launchpad-style 8 x 8 pad grid that pops out from the LAUNCH DECK widget (add it in edit mode) or the terminal command deck. Spotify PREV/PLAY/NEXT, song pads, app pads, and 10 binds of NOVA's own. Hold a pad to change what it does, its label and colour\n"
            + " - LAUNCH DECK water ripples: hit a pad and rings of changing colour spread out over the other pads like waves on water, on screen and on the Launchpad lights. Switch in Settings > LAUNCH DECK\n"
            + " - Ripples are now fully configurable (FX button on the deck, or Settings > LAUNCH DECK): strength, length, speed, ring thickness, number of rings, gap, fade, round/diamond/square, outward/inward, 7 colour styles, colour, richness, brightness, flash, screen and/or Launchpad, smoothness, waves at once, with a live preview and reset\n"
            + " - LAUNCH DECK SOUNDS: every pad can make a sound on the phone (12 instruments incl. drums, any note). Hold a pad > SOUND to choose and hear it. New PLAY mode on the deck: no buttons, only colour pads that make sound; keep your finger down to hold a note, slide across pads, use several fingers. A connected Launchpad plays too. Settings > DECK SOUNDS\n"
            + " - New game WHACK on the LAUNCH DECK: whack-a-mole on the 8 x 8 pads, on the phone and on a connected Launchpad at the same time. Green = 1 point, gold = 5, red = bomb (-3). Streak multiplier, 3 levels, 45 seconds, best score saved. Press WHACK on the deck\n"
            + " - LAUNCH DECK MOUSE: the bottom-right 3 x 3 pads are a mouse. MOUSE (bottom right) opens a white round cursor, CLOSE (bottom left) closes it, the arrows move it (hold to speed up; DOWN is the middle pad, CENTER recentres it from the bottom middle), the two top corner pads tap. Inside NOVA out of the box; over every app after you switch on the optional NOVA mouse service in Android Accessibility settings\n"
            + " - 30 new LAUNCH DECK binds: rewind/fast forward, volume max/50%, ringer, Wi-Fi/Bluetooth/volume/display/battery/airplane/location/Android settings, brightness up/down/max, NOVA home/lock/settings/phone/gallery, roulette/poker/party wheel, show time/battery, 10 and 25 minute timers, alarms, web search. 20 of them are in the starting layout\n"
            + " - LAUNCH DECK works with a Novation Launchpad Mini MK3 plugged in over USB: the real pads run the binds and light up in their colours. Switch in Settings > LAUNCH DECK, status and a USB button in the deck\n"
            + " - Admin mode: BADGES > PICK BADGES is a tick list of every badge. Tick the ones you want, untick the ones you don't (no coin rewards, unticked ones stay off)\n"
            + " - New setting LOCK SCREEN > Remove lock screen: NOVA opens straight to home. Off while a NOVA PIN is set. The terminal lock command still shows it\n"
            + " - Choose which pages the quick panel shows: tap the panel title, then CHOOSE PAGES. The arrows and swipes skip the ones you turned off\n"
            + " - FRIENDS TABLE now has BLACKJACK (1 to 4 players vs the dealer) and POKER (Texas Hold'em, 2 to 4 players, blinds 10/20, side pots, pass the phone so only you see your cards) next to roulette. Same guests and saved coins\n"
            + " - Hold any app on the home screen and drag it: drop it on another app to swap, on empty space to move it to the end of that page, on the screen edge to flip pages, or on REMOVE at the top\n"
            + " - Widgets on the home screen: Settings > EDIT HOME, then + WIDGET. Every widget can sit on page 1 or 2 as HALF (two side by side), WIDE or BIG, and be moved, resized or removed\n"
            + " - 30 new widgets, on the quick panel and placeable: analog, world and binary clock, time progress, moon, hourglass, search, shortcuts, recent apps, device, uptime, volume, clipboard, password, compass, level, light meter, barometer, counter, habits, water, breathe, metronome, magic 8 ball, decider, tic-tac-toe, math quiz, morse, sketch, quote\n"
            + " - The quick panel shows a page number (like 12 / 63) instead of dots\n"
            + " - New SERVERS page on the quick panel: live player counts for your three favourite Arma Reforger servers (WCS Serhiivka East West, Spearhead Yunakivka, NEXTGEN France) from the free ReforgerMods server list, matched by name with nothing to set up. If a row picks the wrong server, tap it and paste a gamemonitoring.net link\n"
            + " - The casino page now scrolls, so Party Wheel, Baccarat and the Friends Table are no longer cut off\n"
            + " - New FRIENDS TABLE in the casino: pass-the-phone roulette for 1 to 4 players. Sit down as YOU with your own coins, or keep up to 20 guest profiles that each keep their own coins between games (new guests start with 1000)\n"
            + " - Sounds: a jackpot cascade on the slots, orb pickup and bust sounds in Snake, card and chip sounds at the casino tables, and win or lose sounds. Game sounds now play on the media volume, and only a full silent phone mutes them\n"
            + " - CODE is a quick-panel page now (swipe to CODE). Tap a project or NEW PROJECT to open the full editor, with SAVE, files, colours, and RUN for HTML and JavaScript\n"
            + " - Roulette straight numbers now pay 40 to 1 (was 35 to 1)\n"
            + " - Dice duel replaced by Texas Hold'em vs the dealer: two cards each, the flop, turn and river come out one card at a time, keep going or fold at each step (folding reveals the board). HOW TO PLAY panel, and the wizard explains it the first time\n"
            + " - Home layout: clock block at top, middle or bottom, and icon size normal, small or large (Settings > HOME LAYOUT)\n"
            + " - New casino game: BACCARAT (player, banker or tie, closest to 9 wins), 6 games on the casino page\n"
            + " - Admins own every item (Settings > ADMIN, on by default, can be turned off). Purchases always cost coins, nothing is free for admins anymore. INVEST is also a button on the SHOP page\n"
            + " - Invest (COIN SHOP > INVEST): 10 coins (Bitcoin, Ethereum, Solana, Dogecoin, XRP, Cardano, Avalanche, Chainlink, Litecoin, Tron) with live prices. Buy with 100, 1K or 10K coins, sell half or all. Game coins only, no real money\n"
            + " - Access startup (Settings > ACCESS SEQUENCE): roulette wheel, castle, slot machine and wizard with a fake progress bar, then ACCESS ACCEPTED and an open green padlock. Look: Hacker (code rain, glitchy pictures, terminal bar) or Cinematic. Set how long it takes and how long you must be away before it plays\n"
            + " - 65 achievements in bronze, silver and gold. Each pays coins (50, 150, 400) and has a progress counter. Scroll the BADGES page. Your best 3 show on your NOVA Net profile\n"
            + " - Coin Shop > UPGRADES: 4th daily quest, spin tickets, lucky charm, high roller bets (100, 250), auto-spin x10 (hold the lever), golden magnet, castle gold mine (earns while you are away), bigger vault, 3% interest, 3-pack of streak shields\n"
            + " - Phone upgrades: 5 icons per row, a fifth dock button (NET), icon shapes, 3 new animated wallpapers (Nebula, Ocean, Petals), sound packs (Retro, Bell, Wood), auto night colours, dancer pack (DJ, skateboard, fishing)\n"
            + " - NOVA Net style (bubble colours, profile frame), stickers, castle decorations (fireflies, lanterns, fountain)\n"
            + " - Zigzag castle skins now only recolour the roofs and windows (walls and rock keep their natural colours), with a pulsing aura and rising zigzag sparks\n"
            + " - Casino rule: the clock and date hide while the SLOTS or CASINO page is open on the home panel\n"
            + " - Roulette cheat mode: a tiny v-number in the top right corner shows the next pocket (it looks like a version tag)\n"
            + " - New big bets: 1K and 10K chips in Roulette, Blackjack and Dice, and 1000 and 10000 bets on the slot machine\n"
            + " - Settings: a search bar at the top (type a word, only matching settings and their headings stay), and the sections are in a better order: looks first, then lock and startup, controls, notifications, extras, updates and admin last\n"
            + " - Fixed: admin mode switched the night colours on by itself, so no theme showed after 21:00\n"
            + " - New character looks: Tracksuit, Wizard robe, Royal plate and the Ponytail, Curly and Undercut hair\n\n"
            + "3.11  Dancer and slots\n"
            + " - Fixed a crash after confetti (a view was removed while the screen was drawing it)\n"
            + " - Admin: CALL HIM BACK (also terminal: dragon call) ends the dragon's trip and he flies home. The admin panel shows when he is due back\n"
            + " - Your character lives in the top corner of the home screen. He dances to your music (4 dances) and otherwise waves, drinks coffee, reads, texts, does jumping jacks, sleeps at night and holds an umbrella when it rains. Tap him for the next thing. He cheers on quests and big coin wins. Switch him off in Settings\n"
            + " - Slot machine: new look (gold cabinet, chasing lights, curved reels, win line), a rolling ratchet sound with a clunk as each reel stops\n"
            + " - The 777 jackpot now pays 70% of the coins the machine kept since the last jackpot, plus 100 (never less than the old x10)\n\n"
            + "3.10  NOVA Net\n"
            + " - Accounts, friends, direct and group chats and ranklists, on a server you host yourself (server folder, README inside)\n"
            + " - Settings > NOVA NET (or the Shop page): enter your server address, then create an account\n"
            + " - Ranks: coins this week, coins all time, castle stage, quest streak, quests done, cosmetics. Show everyone or only friends\n"
            + " - Block and report people, hide yourself from the ranks, change password, delete account\n"
            + " - Friends without an Android phone can use the web version at your-server/app\n\n"
            + "3.9.2  Zigzag, redrawn\n"
            + " - New Zigzag shield (metal rim, gem, lightning bolt) and big solid wings with pointed feather tips\n"
            + " - New Zigzag cape in every edition, with a zigzag hem that sways. Buy it in the Coin Shop or wear it in My Character\n"
            + " - The full set now includes the cape (still 20% off)\n\n"
            + "3.9.1  Fixes\n"
            + " - The wizard and the dragon no longer fade in and out: they were drawn see-through by mistake\n"
            + " - The castle by day has warmer colours\n\n"
            + "3.9  Admin in the panel\n"
            + " - New ADMIN page on the home panel (admin mode only): every lever plus a command line, compact and scrollable, not full screen\n"
            + " - New admin commands: boost, spin reset, shield, bank\n\n"
            + "3.8  The Zigzag collection\n"
            + " - 7 editions (I to V, Black, Gold), each with a shield, wings that flap and an animated castle skin\n"
            + " - Coin Shop > Zigzag editions: buy parts or the full set at 20% off. Wear them in My Character and the Castle Workshop\n\n"
            + "3.7.1  Fix\n"
            + " - MAP page: the buttons were cut off, so it never loaded. Fixed, and it now finds you by itself once location is allowed\n\n"
            + "3.7  The Coin Shop\n"
            + " - My character: a pixel art figure of you. Skin, hair, tops, hats, glasses, capes, shoes. Dress him with coins (Shop page or long-press the wizard)\n"
            + " - Double coins now comes in 1 hour (150), 1 day (3000) and 1 week (20000)\n"
            + " - Settings > Coin Shop, or long-press the wizard\n"
            + " - Double-coins potion, quest re-roll, streak shields, fireworks, dragon treats, mystery chest\n"
            + " - Titles from Squire to Emperor, pet hats, 6 premium colour themes\n"
            + " - The bank: save coins and earn 2% a day\n"
            + " - New SHOP page on the status panel with a free daily lucky spin\n"
            + " - Your name on the home screen under the date: elegant, graffiti or neon (Settings > Your name on home)\n"
            + " - New MAP page on the status panel: tap LOCATE to see where you are (OpenStreetMap, nothing saved)\n"
            + " - Castle visitors (from castle stage 2): a knight pays tribute, a merchant sells shop items at 40% off, a thief steals coins unless you tap him in time\n\n"
            + "3.6  New dragon, new pig\n"
            + " - Ember redrawn: bat wings that flap, sleeping and awake poses, fire, 8 colours\n"
            + " - He carries the roast pig to you in his claws, and the pig has a new look\n"
            + " - The extra towers and the sword are gone\n"
            + " - Admin only: Ember can coil around the main tower\n\n"
            + "3.5  The castle update\n"
            + " - Castle workshop: 10 upgrades (water wheel, lava, sword and banner of your country, towers, dragon, styles)\n"
            + " - Ember the dragon grows up, breathes fire, talks, travels for days, brings roast pigs\n"
            + " - Wizard wardrobe: robes and staff orbs. Second pet at stage 7.\n"
            + " - Long-press the wizard: jokes, riddles, fortune, 8-ball, spells, lesson of the day\n"
            + " - 4 new games: fishing, horse race, treasure map, word of the day\n"
            + " - To-do + habits and a focus timer on the home panel\n"
            + " - Daily login bonus with a streak, sound volume, night tint, reduce motion, left-handed mode\n"
            + " - Backup and restore, health check, safe mode, admin panel\n\n"
            + "3.3  Pets, surprises, quests, critters, pranks, wizard reactions\n"
            + "3.2  Wizard suggestions\n"
            + "3.1  Battery saver\n"
            + "3.0  Gallery and castle";

    static void show(NovaActivity host) {
        new AlertDialog.Builder(host).setTitle("What's new in NOVA " + Theme.OS_VERSION)
                .setMessage(TEXT).setPositiveButton("Nice", null).show();
    }

    static void showIfNew(NovaActivity host) {
        if (Prefs.getInt("setup_done", 0) == 0) {
            return;
        }
        String seen = Prefs.getString("whatsnew", "");
        if (!seen.equals(Theme.OS_VERSION)) {
            Prefs.putString("whatsnew", Theme.OS_VERSION);
            if (!seen.isEmpty()) {
                show(host);
            }
        }
    }
}
