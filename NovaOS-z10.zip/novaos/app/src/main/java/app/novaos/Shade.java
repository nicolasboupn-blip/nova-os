package app.novaos;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

/** Swipe-down panel: quick toggles on top, notifications below. */
final class Shade extends FrameLayout {
    static boolean torchOn = false;

    private final NovaActivity host;
    private final LinearLayout panel;
    private final TextView flashTile;
    private final TextView dndTile;
    private final TextView recTile;
    private final LinearLayout list;
    private final CameraManager cm;
    private final String torchId;
    private boolean closing = false;

    Shade(final NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0x99000000);
        setClickable(true);
        setOnClickListener(v -> close());

        cm = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
        torchId = findTorch();
        int pad = Theme.dp(host, 16);

        panel = new LinearLayout(host);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(Theme.rounded(Theme.BG2, 28f, host));
        panel.setPadding(pad, Theme.dp(host, 48), pad, pad);
        panel.setClickable(true); // taps on the panel do not close it
        addView(panel, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // header: label, clock, close
        LinearLayout head = row();
        TextView title = mono("CONTROL", 12f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        head.addView(title, weight());
        TextClock clock = new TextClock(host);
        clock.setFormat12Hour("HH:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTypeface(Theme.MONO);
        clock.setTextSize(12f);
        clock.setTextColor(Theme.DIM);
        head.addView(clock);
        TextView x = mono("   CLOSE", 12f, Theme.DIM);
        x.setClickable(true);
        x.setOnClickListener(v -> close());
        head.addView(x);
        panel.addView(head, block(0));

        // quick tiles
        LinearLayout tiles = row();
        flashTile = tile("FLASH", v -> toggleTorch());
        tiles.addView(flashTile, tileWeight());
        tiles.addView(tile("WI-FI", v -> openIntent(new Intent(
                Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS))),
                tileWeight());
        tiles.addView(tile("BLUETOOTH", v -> openIntent(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))),
                tileWeight());
        tiles.addView(tile("SETTINGS", v -> openIntent(new Intent(Settings.ACTION_SETTINGS))), tileWeight());
        panel.addView(tiles, block(16));

        LinearLayout tiles2 = row();
        dndTile = tile("DND", v -> toggleDnd());
        tiles2.addView(dndTile, tileWeight());
        recTile = tile("REC", v -> {
            host.toggleRecording();
            close();
        });
        tiles2.addView(recTile, tileWeight());
        tiles2.addView(tile("LOCK", v -> {
            close();
            host.root.postDelayed(host::showLock, 230);
        }), tileWeight());
        panel.addView(tiles2, block(8));

        panel.addView(brightnessRow(), block(14));

        // notifications header
        LinearLayout nh = row();
        TextView nt = mono("NOTIFICATIONS", 11f, Theme.ACCENT);
        nt.setLetterSpacing(0.2f);
        nh.addView(nt, weight());
        TextView clear = mono("CLEAR", 11f, Theme.DIM);
        clear.setClickable(true);
        clear.setOnClickListener(v -> {
            NovaNotificationService.clearAll();
            render();
        });
        nh.addView(clear);
        panel.addView(nh, block(22));

        ScrollView sv = new ScrollView(host);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        int maxH = (int) (host.getResources().getDisplayMetrics().heightPixels * 0.36f);
        panel.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH));

        NovaNotificationService.listener = this::render;
        render();
    }

    void open() {
        panel.setTranslationY(-Theme.dp(host, 700));
        panel.animate().translationY(0).setDuration(220).start();
    }

    void close() {
        if (closing) {
            return;
        }
        closing = true;
        NovaNotificationService.listener = null;
        panel.animate().translationY(-Theme.dp(host, 700)).setDuration(180)
                .withEndAction(host::hideShade).start();
    }

    private void render() {
        flashTile.setText(torchOn ? "FLASH ON" : "FLASH OFF");
        flashTile.setTextColor(torchOn ? Theme.BG : Theme.TEXT);
        flashTile.setBackground(Theme.rounded(torchOn ? Theme.ACCENT : Theme.PANEL, 18f, host));

        boolean dnd = dndOn();
        dndTile.setText(!dndAllowed() ? "DND" : dnd ? "DND ON" : "DND OFF");
        dndTile.setTextColor(dnd ? Theme.BG : Theme.TEXT);
        dndTile.setBackground(Theme.rounded(dnd ? Theme.ACCENT : Theme.PANEL, 18f, host));

        boolean rec = RecordService.running;
        recTile.setText(rec ? "STOP REC" : "REC");
        recTile.setTextColor(rec ? 0xFFFFFFFF : Theme.TEXT);
        recTile.setBackground(Theme.rounded(rec ? 0xFFD6334F : Theme.PANEL, 18f, host));

        list.removeAllViews();
        if (!NovaNotificationService.hasAccess(host)) {
            TextView b = mono("TAP TO ALLOW NOTIFICATIONS HERE", 12f, Theme.ACCENT);
            b.setPadding(0, Theme.dp(host, 8), 0, Theme.dp(host, 8));
            b.setClickable(true);
            b.setOnClickListener(v -> openIntent(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
            list.addView(b, block(0));
            return;
        }
        List<NovaNotificationService.Item> items = NovaNotificationService.snapshot();
        if (items.isEmpty()) {
            list.addView(mono("no notifications yet", 12f, Theme.DIM), block(0));
            return;
        }
        for (NovaNotificationService.Item it : items) {
            list.addView(card(it), block(8));
        }
    }

    private static final int MIN_BRIGHT = 8;

    /**
     * A brightness slider. Android only lets an app change the screen brightness after you
     * allow "modify system settings" for it, so until then the row is a button that opens that page.
     */
    private View brightnessRow() {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        int pad = Theme.dp(host, 14);
        box.setPadding(pad, Theme.dp(host, 12), pad, Theme.dp(host, 10));

        LinearLayout top = row();
        TextView label = mono("BRIGHTNESS", 11f, Theme.DIM);
        label.setLetterSpacing(0.12f);
        top.addView(label, weight());
        final TextView value = mono("", 11f, Theme.TEXT);
        top.addView(value);
        box.addView(top);

        if (!Settings.System.canWrite(host)) {
            value.setText("");
            TextView ask = mono("TAP TO ALLOW BRIGHTNESS CONTROL", 12f, Theme.ACCENT);
            ask.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 4));
            ask.setClickable(true);
            ask.setOnClickListener(v -> openIntent(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    android.net.Uri.parse("package:" + host.getPackageName()))));
            box.addView(ask);
            return box;
        }

        int current = 128;
        try {
            current = Settings.System.getInt(host.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException ignored) {
            // keep the middle value
        }
        current = Math.max(MIN_BRIGHT, Math.min(255, current));
        value.setText(current * 100 / 255 + "%");

        SeekBar bar = new SeekBar(host);
        bar.setMax(255 - MIN_BRIGHT);
        bar.setProgress(current - MIN_BRIGHT);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v = progress + MIN_BRIGHT;
                value.setText(v * 100 / 255 + "%");
                if (fromUser) {
                    setBrightness(v);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = Theme.dp(host, 4);
        box.addView(bar, bp);
        return box;
    }

    /** Switches off auto-brightness and sets the level (8-255). */
    private void setBrightness(int level) {
        try {
            Settings.System.putInt(host.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(host.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, level);
        } catch (Exception e) {
            host.toast("Could not change brightness");
        }
    }

    private View card(final NovaNotificationService.Item it) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
        c.setPadding(Theme.dp(host, 14), Theme.dp(host, 12), Theme.dp(host, 14), Theme.dp(host, 12));
        c.setClickable(true);
        c.setOnClickListener(v -> openItem(it));

        c.addView(mono(it.app.toUpperCase(Locale.ROOT), 10f, Theme.ACCENT));
        TextView t = new TextView(host);
        t.setText(it.title.isEmpty() ? it.app : it.title);
        t.setTextSize(14f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(t);
        if (!it.text.isEmpty()) {
            TextView b = new TextView(host);
            b.setText(it.text);
            b.setTextSize(13f);
            b.setTextColor(Theme.DIM);
            b.setMaxLines(2);
            b.setEllipsize(TextUtils.TruncateAt.END);
            c.addView(b);
        }
        return c;
    }

    private void openItem(NovaNotificationService.Item it) {
        if (it.open != null) {
            try {
                it.open.send();
            } catch (PendingIntent.CanceledException e) {
                host.toast("Can't open that one");
                return;
            }
        }
        close();
    }

    private void toggleTorch() {
        if (torchId == null || cm == null) {
            host.toast("No flashlight on this phone");
            return;
        }
        try {
            cm.setTorchMode(torchId, !torchOn);
            torchOn = !torchOn;
        } catch (Exception e) {
            host.toast("Flashlight is busy");
        }
        render();
    }

    private NotificationManager nm() {
        return (NotificationManager) host.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    private boolean dndAllowed() {
        NotificationManager n = nm();
        return n != null && n.isNotificationPolicyAccessGranted();
    }

    private boolean dndOn() {
        NotificationManager n = nm();
        if (n == null || !n.isNotificationPolicyAccessGranted()) {
            return false;
        }
        int f = n.getCurrentInterruptionFilter();
        return f != NotificationManager.INTERRUPTION_FILTER_ALL
                && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
    }

    /** Do Not Disturb. Android asks you to allow NOVA to change it once. */
    private void toggleDnd() {
        NotificationManager n = nm();
        if (n == null) {
            host.toast("Not available on this phone");
            return;
        }
        if (!n.isNotificationPolicyAccessGranted()) {
            openIntent(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return;
        }
        n.setInterruptionFilter(dndOn()
                ? NotificationManager.INTERRUPTION_FILTER_ALL : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        render();
    }

    private void openIntent(Intent i) {
        try {
            host.startActivity(i);
        } catch (Exception e) {
            host.toast("Not available on this phone");
            return;
        }
        close();
    }

    private String findTorch() {
        if (cm == null) {
            return null;
        }
        try {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    return id;
                }
            }
        } catch (CameraAccessException e) {
            return null;
        }
        return null;
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private TextView tile(String label, View.OnClickListener l) {
        TextView t = mono(label, 11f, Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.1f);
        t.setPadding(0, Theme.dp(host, 18), 0, Theme.dp(host, 18));
        t.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams tileWeight() {
        LinearLayout.LayoutParams p = weight();
        p.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
        return p;
    }

    private LinearLayout.LayoutParams block(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = Theme.dp(host, topDp);
        return p;
    }
}
