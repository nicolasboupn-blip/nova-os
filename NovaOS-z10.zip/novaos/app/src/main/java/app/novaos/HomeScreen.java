package app.novaos;

import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Two home pages. Page one: clock, the switchable panel, your first pinned apps and the dock.
 * Page two: the rest of your pinned apps. Swipe sideways to move between them, swipe up for the app drawer,
 * long-press an empty spot to draw a gesture. After an unlock it plays a short welcome animation.
 */
final class HomeScreen extends FrameLayout {
    private static final int COLUMNS = 4;
    static final int PAGE_ONE_APPS = 8;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Handler introHandler = new Handler(Looper.getMainLooper());
    private final TextView battery;
    private final android.view.GestureDetector swipe;
    private final int slop;
    private ValueAnimator nameGlow;

    private LinearLayout page1;
    private LinearLayout page2;
    private StatusPanel panel;
    private final View[] pageDots = new View[2];

    // sideways paging
    private float progress;       // 0 = page one, 1 = page two, in between while dragging
    private int pageIndex;
    private float downX, downY;
    private boolean tracking;
    private boolean dragging;
    private VelocityTracker velocity;
    private ValueAnimator settle;

    // welcome animation
    private final List<View> early = new ArrayList<>();
    private final List<View> late = new ArrayList<>();
    private boolean introWanted;
    private boolean introStarted;
    private boolean introRunning;
    private TextView welcome;
    private ValueAnimator welcomeGlow;
    private ValueAnimator welcomeSpacing;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshBattery();
            handler.postDelayed(this, 30000);
        }
    };

    HomeScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        this.slop = ViewConfiguration.get(host).getScaledTouchSlop();
        introWanted = host.takeIntro();
        setClipChildren(false);
        int side = Theme.dp(host, 24);

        // code wallpaper behind everything, typing itself at the chosen opacity
        if (Prefs.homeCode()) {
            CodeWallpaper code = new CodeWallpaper(host, true);
            code.setAlpha(Theme.wallAlpha());
            code.setPadding(side, Theme.dp(host, 44), side, 0);
            addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        host.repo.ensureFresh();
        List<AppEntry> pinned = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                pinned.add(e);
            }
        }
        List<AppEntry> first = pinned.subList(0, Math.min(PAGE_ONE_APPS, pinned.size()));
        List<AppEntry> rest = pinned.size() > PAGE_ONE_APPS
                ? pinned.subList(PAGE_ONE_APPS, pinned.size()) : new ArrayList<AppEntry>();

        // ------------------------------------------------------------ page one
        page1 = new LinearLayout(host);
        page1.setOrientation(LinearLayout.VERTICAL);
        page1.setClipChildren(false);
        page1.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        addView(page1, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout status = new LinearLayout(host);
        status.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = mono(Theme.OS_NAME, 12f, Theme.ACCENT);
        name.setLetterSpacing(0.3f);
        nameGlow = Theme.glow(name);
        battery = mono("", 12f, Theme.DIM);
        status.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        status.addView(battery);
        page1.addView(status);
        late.add(status);

        NovaClock clock = new NovaClock(host, 1f);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 28) - clock.pad;
        clp.leftMargin = -clock.pad;
        clp.bottomMargin = -clock.pad + Theme.dp(host, 2);
        page1.addView(clock, clp);
        early.add(clock);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(15f);
        date.setTextColor(Theme.DIM);
        page1.addView(date);
        early.add(date);

        if (Prefs.systemPanel()) {
            panel = new StatusPanel(host);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            plp.topMargin = Theme.dp(host, 22);
            page1.addView(panel, plp);
            late.add(panel);
        }
        page1.addView(new View(host), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        if (first.isEmpty()) {
            TextView empty = mono("Long-press an app in the drawer to pin it here.", 12f, Theme.DIM);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            elp.bottomMargin = Theme.dp(host, 20);
            page1.addView(empty, elp);
            late.add(empty);
        } else {
            View rows = grid(first);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = Theme.dp(host, 20);
            page1.addView(rows, rlp);
            late.add(rows);
        }
        View dock1 = dock();
        page1.addView(dock1, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        late.add(dock1);

        // ------------------------------------------------------------ page two
        page2 = new LinearLayout(host);
        page2.setOrientation(LinearLayout.VERTICAL);
        page2.setClipChildren(false);
        page2.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        addView(page2, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView p2name = mono("PAGE 2", 12f, Theme.ACCENT);
        p2name.setLetterSpacing(0.3f);
        page2.addView(p2name);
        if (rest.isEmpty()) {
            TextView hint = mono("Nothing here yet.\n\nPin more than " + PAGE_ONE_APPS
                    + " apps (long-press one in the\ndrawer) and the extra ones land on this page.", 12f, Theme.DIM);
            hint.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
            hint.setGravity(Gravity.CENTER);
            page2.addView(hint, hp);
        } else {
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
            gp.topMargin = Theme.dp(host, 24);
            LinearLayout holder = new LinearLayout(host);
            holder.setOrientation(LinearLayout.VERTICAL);
            holder.setClipChildren(false);
            holder.addView(grid(rest));
            page2.addView(holder, gp);
        }
        page2.addView(dock(), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // little page dots, top center
        LinearLayout dots = new LinearLayout(host);
        for (int i = 0; i < 2; i++) {
            pageDots[i] = new View(host);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Theme.dp(host, 5), Theme.dp(host, 5));
            dp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
            dots.addView(pageDots[i], dp);
        }
        LayoutParams dlp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        dlp.topMargin = Theme.dp(host, 50);
        addView(dots, dlp);
        showDots();

        swipe = new android.view.GestureDetector(host,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (!dragging && e1 != null && e2 != null
                                && e1.getY() - e2.getY() > Theme.dp(host, 80) && Math.abs(vy) > 600
                                && Math.abs(vy) > Math.abs(vx)) {
                            host.showDrawer();
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onLongPress(MotionEvent e) {
                        if (!dragging && !introRunning) {
                            host.buzz(25);
                            host.showOverlay(new GestureLayer(host));
                        }
                    }
                });

        refreshBattery();
        if (introWanted) {
            prepareIntro();
        }
    }

    // ---------------------------------------------------------------- building blocks

    /** A 4-column grid of app icons. */
    private View grid(List<AppEntry> apps) {
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setClipChildren(false);
        LinearLayout row = null;
        int n = 0;
        for (AppEntry e : apps) {
            if (n % COLUMNS == 0) {
                row = new LinearLayout(host);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                rows.addView(row, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            row.addView(cell(e), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            n++;
        }
        while (n % COLUMNS != 0) {
            row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
            n++;
        }
        return rows;
    }

    private View dock() {
        LinearLayout dock = new LinearLayout(host);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        dock.setPadding(Theme.dp(host, 6), Theme.dp(host, 4), Theme.dp(host, 6), Theme.dp(host, 4));
        dock.addView(dockButton("APPS", v -> host.showDrawer()), weight());
        dock.addView(dockButton("NOTES", v -> host.showNotes()), weight());
        dock.addView(dockButton("TERMINAL", v -> host.showTerminal()), weight());
        dock.addView(dockButton("SETUP", v -> host.showSettings()), weight());
        return dock;
    }

    private View cell(final AppEntry e) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setClipChildren(false);
        c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));

        final ImageView icon = new ImageView(host);
        icon.setImageDrawable(Theme.tint(host, e.icon));
        c.addView(icon, new LinearLayout.LayoutParams(Theme.dp(host, 58), Theme.dp(host, 58)));

        TextView t = new TextView(host);
        t.setText(e.label);
        t.setTextSize(11f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 6);
        c.addView(t, tlp);

        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.confirmUnpin(e);
            return true;
        });
        // a touch makes the icon's particles burst outward
        c.setOnTouchListener((v, ev) -> {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && Prefs.touchGlow()) {
                Drawable d = icon.getDrawable();
                if (d instanceof ParticleGlow) {
                    ((ParticleGlow) d).burst();
                }
            }
            return false;
        });
        return c;
    }

    // ---------------------------------------------------------------- paging

    private void showDots() {
        for (int i = 0; i < pageDots.length; i++) {
            pageDots[i].setBackground(Theme.rounded(i == pageIndex ? Theme.ACCENT : 0x44FFFFFF, 3f, host));
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        applyProgress();
    }

    private void applyProgress() {
        float w = getWidth();
        page1.setTranslationX(-progress * w);
        page2.setTranslationX((1f - progress) * w);
        page2.setAlpha(Math.max(0f, Math.min(1f, 0.35f + progress * 0.65f)));
    }

    private void settleTo(final int target, long ms) {
        if (settle != null) {
            settle.cancel();
        }
        pageIndex = target;
        showDots();
        settle = ValueAnimator.ofFloat(progress, target);
        settle.setDuration(ms);
        settle.setInterpolator(new DecelerateInterpolator(1.5f));
        settle.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            applyProgress();
        });
        settle.start();
    }

    private boolean insidePanel(MotionEvent e) {
        if (panel == null || panel.getWidth() == 0) {
            return false;
        }
        int[] at = new int[2];
        panel.getLocationOnScreen(at);
        float x = e.getRawX();
        float y = e.getRawY();
        return x >= at[0] && x <= at[0] + panel.getWidth() && y >= at[1] && y <= at[1] + panel.getHeight();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (introRunning) {
                    finishIntro();
                }
                if (settle != null) {
                    settle.cancel();
                }
                downX = e.getRawX();
                downY = e.getRawY();
                dragging = false;
                // the panel has its own sideways swipe, so it keeps touches that start on it
                tracking = !insidePanel(e);
                if (velocity != null) {
                    velocity.recycle();
                }
                velocity = VelocityTracker.obtain();
                velocity.addMovement(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (velocity != null) {
                    velocity.addMovement(e);
                }
                if (tracking && !dragging && !introRunning) {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    boolean ok = (pageIndex == 0 && dx < 0) || (pageIndex == 1 && dx > 0);
                    if (ok && Math.abs(dx) > slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                        dragging = true;
                        return true;
                    }
                }
                break;
            default:
                break;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (dragging) {
            if (velocity != null) {
                velocity.addMovement(e);
            }
            float w = Math.max(1f, getWidth());
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX;
                    progress = Math.max(-0.1f, Math.min(1.1f, pageIndex - dx / w));
                    applyProgress();
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float vx = 0f;
                    if (velocity != null) {
                        velocity.computeCurrentVelocity(1000);
                        vx = velocity.getXVelocity();
                    }
                    int target;
                    if (e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                        target = progress > 0.5f ? 1 : 0;
                    } else if (vx < -900) {
                        target = 1;
                    } else if (vx > 900) {
                        target = 0;
                    } else {
                        target = progress > 0.5f ? 1 : 0;
                    }
                    dragging = false;
                    settleTo(target, 280);
                    return true;
                }
                default:
                    return true;
            }
        }
        return swipe.onTouchEvent(e) || super.onTouchEvent(e);
    }

    // ---------------------------------------------------------------- welcome animation

    /** Hides everything and adds the big greeting in the middle. Plays once the screen is attached. */
    private void prepareIntro() {
        introRunning = true;
        for (View v : early) {
            v.setAlpha(0f);
        }
        float rise = Theme.dp(host, 70);
        for (View v : late) {
            v.setAlpha(0f);
            v.setTranslationY(rise);
        }
        welcome = new TextView(host);
        welcome.setText(Prefs.greeting().toUpperCase(Locale.getDefault()));
        welcome.setTypeface(Theme.clockFace());
        welcome.setTextSize(34f);
        welcome.setTextColor(Theme.TEXT);
        welcome.setLetterSpacing(0.9f);
        welcome.setAlpha(0f);
        welcomeGlow = Theme.glow(welcome);
        addView(welcome, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    /**
     * Greeting fades and settles in, then the time, then the rest rises from below,
     * one piece after another. About 2.3 seconds in total.
     */
    private void playIntro() {
        final DecelerateInterpolator out = new DecelerateInterpolator(1.6f);

        welcome.setScaleX(1.12f);
        welcome.setScaleY(1.12f);
        welcome.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
        welcomeSpacing = ValueAnimator.ofFloat(0.9f, 0.4f);
        welcomeSpacing.setDuration(1000);
        welcomeSpacing.setInterpolator(new DecelerateInterpolator());
        welcomeSpacing.addUpdateListener(a -> welcome.setLetterSpacing((float) a.getAnimatedValue()));
        welcomeSpacing.start();

        introHandler.postDelayed(() -> welcome.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f)
                .setDuration(350).start(), 900);

        introHandler.postDelayed(() -> {
            for (View v : early) {
                v.setPivotX(0f);
                v.setPivotY(v.getHeight() / 2f);
                v.setScaleX(0.9f);
                v.setScaleY(0.9f);
                v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
            }
        }, 950);

        for (int i = 0; i < late.size(); i++) {
            final View v = late.get(i);
            introHandler.postDelayed(() -> v.animate().alpha(1f).translationY(0f)
                    .setDuration(560).setInterpolator(out).start(), 1500L + 90L * i);
        }

        introHandler.postDelayed(() -> introRunning = false, 1500L + 90L * late.size() + 600L);
    }

    /** Tap anywhere during the animation to jump straight to the finished home screen. */
    private void finishIntro() {
        introRunning = false;
        introHandler.removeCallbacksAndMessages(null);
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        if (welcome != null) {
            welcome.animate().cancel();
            welcome.setAlpha(0f);
        }
        for (View v : early) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setScaleX(1f);
            v.setScaleY(1f);
        }
        for (View v : late) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setTranslationY(0f);
        }
    }

    // ---------------------------------------------------------------- bits

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView dockButton(String label, OnClickListener click) {
        TextView b = mono(label, 11f, Theme.TEXT);
        b.setLetterSpacing(0.12f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private void refreshBattery() {
        if (!Prefs.battery()) {
            battery.setText("");
            return;
        }
        int level = host.batteryLevel();
        if (level < 0) {
            battery.setText("");
            return;
        }
        battery.setText(level + "%" + (host.charging() ? " · charging" : ""));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.postDelayed(tick, 30000);
        if (introRunning && !introStarted) {
            introStarted = true;
            playIntro();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        introHandler.removeCallbacksAndMessages(null);
        if (settle != null) {
            settle.cancel();
        }
        if (velocity != null) {
            velocity.recycle();
            velocity = null;
        }
        nameGlow.cancel();
        if (welcomeGlow != null) {
            welcomeGlow.cancel();
        }
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        super.onDetachedFromWindow();
    }
}
