package app.novaos;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The PIN screen. Every digit lights a glowing dot. A right PIN makes the dots flash and a ring of light
 * spreads out. A wrong one shakes the dots, turns them red and buzzes.
 */
final class PinPad extends FrameLayout {
    interface Listener {
        void onUnlocked();

        void onCancel();
    }

    private static final int RED = 0xFFFF4D6D;

    private final NovaActivity host;
    private final Listener listener;
    private final int length;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Dot[] dots;
    private final LinearLayout dotRow;
    private final TextView message;
    private final View ring;
    private final StringBuilder entered = new StringBuilder();
    private int wrong;
    private boolean busy;

    PinPad(final NovaActivity host, int length, boolean bio, final Runnable onBio, Listener listener) {
        super(host);
        this.host = host;
        this.listener = listener;
        this.length = length;
        setBackgroundColor(0xF2060410);
        setClickable(true);

        // the expanding ring of light that plays when the PIN is right
        ring = new View(host);
        GradientDrawable g = new GradientDrawable();
        g.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        g.setGradientRadius(Theme.dp(host, 160));
        g.setColors(new int[] {(0xAA << 24) | (Theme.GLOW & 0xFFFFFF), (0x33 << 24) | (Theme.GLOW & 0xFFFFFF), 0});
        ring.setBackground(g);
        ring.setAlpha(0f);
        LayoutParams rp = new LayoutParams(Theme.dp(host, 320), Theme.dp(host, 320), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        rp.topMargin = Theme.dp(host, 126) - Theme.dp(host, 160) + Theme.dp(host, 8);
        addView(ring, rp);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(Theme.dp(host, 36), Theme.dp(host, 76), Theme.dp(host, 36), Theme.dp(host, 28));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView title = mono("ENTER PIN", 13f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        col.addView(title);

        dotRow = new LinearLayout(host);
        dotRow.setGravity(Gravity.CENTER);
        dots = new Dot[length];
        for (int i = 0; i < length; i++) {
            dots[i] = new Dot(host);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Theme.dp(host, 30), Theme.dp(host, 30));
            dp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
            dotRow.addView(dots[i], dp);
        }
        LinearLayout.LayoutParams drp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        drp.topMargin = Theme.dp(host, 26);
        col.addView(dotRow, drp);

        message = mono(" ", 11f, Theme.DIM);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mp.topMargin = Theme.dp(host, 14);
        col.addView(message, mp);

        // keypad
        LinearLayout keys = new LinearLayout(host);
        keys.setOrientation(LinearLayout.VERTICAL);
        String[][] rows = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {bio ? "FP" : "", "0", "DEL"}};
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER);
            for (String k : r) {
                row.addView(key(k, onBio), new LinearLayout.LayoutParams(Theme.dp(host, 84), Theme.dp(host, 74)));
            }
            keys.addView(row);
        }
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        kp.topMargin = Theme.dp(host, 36);
        col.addView(keys, kp);

        TextView cancel = mono("CANCEL", 12f, Theme.DIM);
        cancel.setLetterSpacing(0.2f);
        cancel.setPadding(Theme.dp(host, 24), Theme.dp(host, 16), Theme.dp(host, 24), Theme.dp(host, 16));
        cancel.setClickable(true);
        cancel.setOnClickListener(v -> listener.onCancel());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.topMargin = Theme.dp(host, 14);
        col.addView(cancel, cp);
    }

    private TextView mono(String t, float size, int color) {
        TextView v = new TextView(host);
        v.setText(t);
        v.setTypeface(Theme.MONO);
        v.setTextSize(size);
        v.setTextColor(color);
        return v;
    }

    private View key(final String k, final Runnable onBio) {
        if (k.isEmpty()) {
            return new View(host);
        }
        String shown = k.equals("DEL") ? "⌫" : k.equals("FP") ? "◉" : k;
        final TextView t = mono(shown, k.length() == 1 ? 26f : 22f, k.equals("FP") ? Theme.ACCENT : Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> {
            if (k.equals("DEL")) {
                backspace();
            } else if (k.equals("FP")) {
                if (onBio != null) {
                    onBio.run();
                }
            } else {
                digit(k, t);
            }
        });
        return t;
    }

    // ------------------------------------------------------------------ input

    private void digit(String d, TextView key) {
        if (busy || entered.length() >= length) {
            return;
        }
        // the key lights up for a moment
        key.setTextColor(Theme.ACCENT);
        key.animate().scaleX(1.25f).scaleY(1.25f).setDuration(70).withEndAction(() ->
                key.animate().scaleX(1f).scaleY(1f).setDuration(130).withEndAction(() ->
                        key.setTextColor(Theme.TEXT)).start()).start();
        entered.append(d);
        dots[entered.length() - 1].setFilled(true, Theme.ACCENT);
        message.setText(" ");
        if (entered.length() == length) {
            check();
        }
    }

    private void backspace() {
        if (busy || entered.length() == 0) {
            return;
        }
        dots[entered.length() - 1].setFilled(false, Theme.ACCENT);
        entered.deleteCharAt(entered.length() - 1);
    }

    private void check() {
        busy = true;
        if (Prefs.checkPin(entered.toString())) {
            wrong = 0;
            success();
        } else {
            fail();
        }
    }

    /** Called when the PIN or the fingerprint was right. */
    void accept() {
        if (!busy) {
            busy = true;
            for (Dot d : dots) {
                d.setFilled(true, Theme.ACCENT);
            }
            success();
        }
    }

    // ------------------------------------------------------------------ effects

    private void success() {
        message.setText("UNLOCKED");
        message.setTextColor(Theme.ACCENT);
        for (Dot d : dots) {
            d.flash();
        }
        ring.setScaleX(0.2f);
        ring.setScaleY(0.2f);
        ring.setAlpha(1f);
        ring.animate().scaleX(1.5f).scaleY(1.5f).alpha(0f).setDuration(650)
                .setInterpolator(new DecelerateInterpolator(1.3f)).start();
        host.buzz(30);
        handler.postDelayed(listener::onUnlocked, 480);
    }

    private void fail() {
        wrong++;
        for (Dot d : dots) {
            d.setFilled(true, RED);
        }
        message.setText(wrong >= 5 ? "TOO MANY TRIES" : "WRONG PIN");
        message.setTextColor(RED);
        host.buzz(120);
        float s = Theme.dp(host, 1);
        ObjectAnimator shake = ObjectAnimator.ofFloat(dotRow, View.TRANSLATION_X,
                0f, -26 * s, 24 * s, -19 * s, 16 * s, -10 * s, 6 * s, 0f);
        shake.setDuration(460);
        shake.start();
        handler.postDelayed(() -> {
            entered.setLength(0);
            for (Dot d : dots) {
                d.setFilled(false, Theme.ACCENT);
            }
            if (wrong >= 5) {
                lockout(30);
            } else {
                busy = false;
            }
        }, 560);
    }

    private void lockout(final int seconds) {
        if (seconds <= 0) {
            wrong = 0;
            busy = false;
            message.setText(" ");
            return;
        }
        message.setText("TRY AGAIN IN " + seconds + "s");
        message.setTextColor(RED);
        handler.postDelayed(() -> lockout(seconds - 1), 1000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ one dot

    /** A ring that fills with a glowing disc when a digit is typed. */
    private static final class Dot extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private float fill;      // 0 empty .. 1 filled
        private float flash;     // extra glow while unlocking
        private int color = Theme.ACCENT;
        private ValueAnimator anim;

        Dot(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        void setFilled(boolean on, int c) {
            color = c;
            if (anim != null) {
                anim.cancel();
            }
            anim = ValueAnimator.ofFloat(fill, on ? 1f : 0f);
            anim.setDuration(on ? 160 : 120);
            anim.addUpdateListener(a -> {
                fill = (float) a.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }

        void flash() {
            ValueAnimator f = ValueAnimator.ofFloat(0f, 1f, 0.35f);
            f.setDuration(620);
            f.addUpdateListener(a -> {
                flash = (float) a.getAnimatedValue();
                invalidate();
            });
            f.start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = 8 * d;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.6f * d);
            paint.setColor(0x66FFFFFF);
            c.drawCircle(cx, cy, r, paint);
            paint.setStyle(Paint.Style.FILL);
            int rgb = color & 0xFFFFFF;
            float glow = Math.max(fill * 0.7f, flash);
            if (glow > 0f) {
                paint.setColor(((int) (46 * glow) << 24) | rgb);
                c.drawCircle(cx, cy, r * (2.1f + flash * 0.6f), paint);
                paint.setColor(((int) (90 * glow) << 24) | rgb);
                c.drawCircle(cx, cy, r * 1.5f, paint);
            }
            if (fill > 0f) {
                paint.setColor(((int) (255 * fill) << 24) | rgb);
                c.drawCircle(cx, cy, r * (0.35f + 0.65f * fill), paint);
            }
        }
    }
}
