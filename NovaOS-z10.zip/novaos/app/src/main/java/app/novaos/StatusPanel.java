package app.novaos;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.session.MediaController;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The box in the middle of the home screen. It has several pages (system, network, music, battery today,
 * app usage, slots). Press the arrows on its sides, or swipe it, and the page slides away and the next one slides in.
 */
final class StatusPanel extends LinearLayout {
    private static final String[] TITLES = {"SYSTEM", "NETWORK", "MUSIC", "BATTERY TODAY", "APP USAGE", "SLOTS"};
    private static final int SYSTEM = 0;
    private static final int NET = 1;
    private static final int MUSIC = 2;
    private static final int BATTERY = 3;
    private static final int APPS = 4;
    private static final int SLOTS = 5;

    /** The page you left open stays selected when the home screen is rebuilt. */
    private static int lastPage = 0;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinearLayout[] pages = new LinearLayout[TITLES.length];
    private final FrameLayout holder;
    private final TextView title;
    private final View[] dots = new View[TITLES.length];
    private int current;
    private int count;
    private boolean animating;

    // system
    private TextView batteryText, alarmText, storageText, ramText, tempText;
    private View barFill;

    // network
    private TextView connText, wifiText, speedText, mobileText, mobileUsedText;
    private long lastRx, lastTx, lastMobRx, lastMobTx, lastAt;
    private boolean testing;

    // music
    private TextView musicTitle, musicArtist, playBtn;

    // battery today
    private BatteryGraph graph;
    private TextView usedText, drainText, screenText;

    // app usage
    private LinearLayout usageBody;
    private TextView usageTotal;
    private UsageHelper.Result usage;
    private boolean loadingUsage;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            count++;
            switch (current) {
                case NET:
                    refreshNet();
                    break;
                case MUSIC:
                    if (count % 2 == 0) {
                        refreshMusic();
                    }
                    break;
                case SYSTEM:
                    if (count % 30 == 0) {
                        refreshSystem();
                    }
                    break;
                case BATTERY:
                case APPS:
                    if (count % 30 == 0) {
                        refreshPage(current);
                    }
                    break;
                default:
                    break;
            }
            handler.postDelayed(this, 1000);
        }
    };

    StatusPanel(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        int pad = Theme.dp(host, 12);
        setPadding(pad, Theme.dp(host, 8), pad, pad);

        // header: left arrow, title with page dots, right arrow
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(arrow("‹", -1), new LinearLayout.LayoutParams(Theme.dp(host, 44), Theme.dp(host, 40)));
        LinearLayout mid = new LinearLayout(host);
        mid.setOrientation(VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        title = mono("", 11f, Theme.ACCENT);
        title.setLetterSpacing(0.2f);
        mid.addView(title);
        LinearLayout dotRow = new LinearLayout(host);
        dotRow.setGravity(Gravity.CENTER);
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new View(host);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Theme.dp(host, 5), Theme.dp(host, 5));
            dp.setMargins(Theme.dp(host, 3), Theme.dp(host, 6), Theme.dp(host, 3), 0);
            dotRow.addView(dots[i], dp);
        }
        mid.addView(dotRow);
        head.addView(mid, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        head.addView(arrow("›", 1), new LinearLayout.LayoutParams(Theme.dp(host, 44), Theme.dp(host, 40)));
        addView(head, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // pages
        for (int i = 0; i < pages.length; i++) {
            pages[i] = new LinearLayout(host);
            pages[i].setOrientation(VERTICAL);
        }
        buildSystem(pages[SYSTEM]);
        buildNet(pages[NET]);
        buildMusic(pages[MUSIC]);
        buildBattery(pages[BATTERY]);
        buildUsage(pages[APPS]);
        pages[SLOTS].addView(new SlotMachine(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        holder = new FrameLayout(host);
        for (LinearLayout p : pages) {
            p.setPadding(Theme.dp(host, 4), Theme.dp(host, 2), Theme.dp(host, 4), 0);
            holder.addView(p, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        }
        pages[MUSIC].setPadding(Theme.dp(host, 4), Theme.dp(host, 14), Theme.dp(host, 4), 0);
        addView(holder, new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 172)));

        // swiping the box sideways changes the page, swiping up still opens the app drawer
        final GestureDetector gd = new GestureDetector(host, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) {
                    return false;
                }
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > Theme.dp(host, 50) && Math.abs(vx) > 450) {
                    go(dx < 0 ? 1 : -1);
                    return true;
                }
                if (-dy > Theme.dp(host, 80) && Math.abs(vy) > 600) {
                    host.showDrawer();
                    return true;
                }
                return false;
            }
        });
        setOnTouchListener((v, ev) -> gd.onTouchEvent(ev));

        current = Math.max(0, Math.min(TITLES.length - 1, lastPage));
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == current ? VISIBLE : GONE);
        }
        showHeader();
        refreshPage(current);
    }

    private TextView arrow(String glyph, final int dir) {
        TextView t = mono(glyph, 26f, Theme.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> go(dir));
        return t;
    }

    private void showHeader() {
        title.setText(TITLES[current]);
        for (int i = 0; i < dots.length; i++) {
            dots[i].setBackground(Theme.rounded(i == current ? Theme.ACCENT : 0x44FFFFFF, 3f, host));
        }
    }

    // ------------------------------------------------------------------ switching

    /** Slides the current page away and the next one in. dir is +1 for the next page, -1 for the one before. */
    void go(int dir) {
        final int from = current;
        final int to = (current + dir + pages.length) % pages.length;
        // finish any slide that is still running, so quick taps never leave two pages showing
        for (int i = 0; i < pages.length; i++) {
            pages[i].animate().cancel();
            if (i != from) {
                pages[i].setVisibility(GONE);
            }
            pages[i].setTranslationX(0f);
            pages[i].setAlpha(1f);
        }
        current = to;
        lastPage = to;
        showHeader();
        refreshPage(to);

        float w = holder.getWidth() > 0 ? holder.getWidth() : Theme.dp(host, 300);
        final LinearLayout out = pages[from];
        final LinearLayout in = pages[to];
        out.animate().translationX(-dir * w * 0.6f).alpha(0f).setDuration(240)
                .setInterpolator(new DecelerateInterpolator(1.4f))
                .withEndAction(() -> {
                    if (out != pages[current]) {
                        out.setVisibility(GONE);
                    }
                    out.setTranslationX(0f);
                    out.setAlpha(1f);
                }).start();
        in.setVisibility(VISIBLE);
        in.setTranslationX(dir * w * 0.6f);
        in.setAlpha(0f);
        in.animate().translationX(0f).alpha(1f).setDuration(260)
                .setInterpolator(new DecelerateInterpolator(1.4f)).start();
    }

    private void refreshPage(int p) {
        switch (p) {
            case SYSTEM:
                refreshSystem();
                break;
            case NET:
                refreshNet();
                break;
            case MUSIC:
                refreshMusic();
                break;
            case BATTERY:
                refreshBattery();
                loadUsage();
                break;
            case APPS:
                loadUsage();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.postDelayed(tick, 1000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        for (LinearLayout p : pages) {
            p.animate().cancel();
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ system page

    private void buildSystem(LinearLayout p) {
        batteryText = statValue(p, "BATTERY");
        LinearLayout bar = new LinearLayout(host);
        bar.setOrientation(HORIZONTAL);
        bar.setWeightSum(100f);
        bar.setBackground(Theme.rounded(0x33FFFFFF, 3f, host));
        barFill = new View(host);
        barFill.setBackground(Theme.rounded(Theme.ACCENT, 3f, host));
        bar.addView(barFill, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 0f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 6));
        blp.topMargin = Theme.dp(host, 6);
        p.addView(bar, blp);
        alarmText = statValue(p, "NEXT ALARM");
        storageText = statValue(p, "STORAGE");
        ramText = statValue(p, "RAM");
        tempText = statValue(p, "BATTERY TEMP");
    }

    private void refreshSystem() {
        int level = host.batteryLevel();
        if (level >= 0) {
            batteryText.setText(level + "%" + (host.charging() ? " · charging" : ""));
            ((LinearLayout.LayoutParams) barFill.getLayoutParams()).weight = level;
            barFill.getParent().requestLayout();
        } else {
            batteryText.setText("--");
        }
        alarmText.setText(nextAlarm());
        storageText.setText(storage());
        ramText.setText(ram());
        tempText.setText(batteryTemp());
    }

    private String nextAlarm() {
        try {
            AlarmManager am = (AlarmManager) host.getSystemService(Context.ALARM_SERVICE);
            AlarmManager.AlarmClockInfo info = am == null ? null : am.getNextAlarmClock();
            if (info == null) {
                return "none";
            }
            long at = info.getTriggerTime();
            long mins = Math.max(0L, (at - System.currentTimeMillis()) / 60000L);
            String when = new SimpleDateFormat(mins < 24 * 60 ? "HH:mm" : "EEE HH:mm",
                    Locale.getDefault()).format(new Date(at));
            String in = mins >= 60 ? (mins / 60) + "h " + (mins % 60) + "m" : mins + "m";
            return when + " · in " + in;
        } catch (Exception e) {
            return "none";
        }
    }

    private String storage() {
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            long total = fs.getTotalBytes();
            long used = total - fs.getAvailableBytes();
            return String.format(Locale.US, "%.0f / %.0f GB", used / 1e9, total / 1e9);
        } catch (Exception e) {
            return "--";
        }
    }

    private String ram() {
        try {
            ActivityManager am = (ActivityManager) host.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return String.format(Locale.US, "%.1f / %.1f GB", (mi.totalMem - mi.availMem) / 1e9, mi.totalMem / 1e9);
        } catch (Exception e) {
            return "--";
        }
    }

    private String batteryTemp() {
        try {
            Intent i = host.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = i == null ? -1 : i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            return t < 0 ? "--" : String.format(Locale.US, "%.1f °C", t / 10f);
        } catch (Exception e) {
            return "--";
        }
    }

    // ------------------------------------------------------------------ network page

    private void buildNet(LinearLayout p) {
        connText = statValue(p, "CONNECTION");
        wifiText = statValue(p, "WI-FI");
        speedText = statValue(p, "SPEED TEST");
        speedText.setText("tap to run");
        speedText.setTextColor(Theme.ACCENT);
        View speedRow = (View) speedText.getParent();
        speedRow.setClickable(true);
        speedRow.setOnClickListener(v -> runSpeedTest());
        mobileText = statValue(p, "MOBILE");
        mobileUsedText = statValue(p, "MOBILE USED");
    }

    private void refreshNet() {
        long now = SystemClock.elapsedRealtime();
        long totalRx = TrafficStats.getTotalRxBytes();
        long totalTx = TrafficStats.getTotalTxBytes();
        long mobRx = Math.max(0L, TrafficStats.getMobileRxBytes());
        long mobTx = Math.max(0L, TrafficStats.getMobileTxBytes());
        long wifiRx = totalRx - mobRx;
        long wifiTx = totalTx - mobTx;

        String wifiRates = "";
        String mobRates = "";
        if (lastAt > 0 && now > lastAt && now - lastAt < 4000 && totalRx != TrafficStats.UNSUPPORTED
                && wifiRx >= lastRx && wifiTx >= lastTx && mobRx >= lastMobRx && mobTx >= lastMobTx) {
            double s = (now - lastAt) / 1000.0;
            wifiRates = "v " + rate((wifiRx - lastRx) / s) + "  ^ " + rate((wifiTx - lastTx) / s);
            mobRates = "v " + rate((mobRx - lastMobRx) / s) + "  ^ " + rate((mobTx - lastMobTx) / s);
        }
        lastRx = wifiRx;
        lastTx = wifiTx;
        lastMobRx = mobRx;
        lastMobTx = mobTx;
        lastAt = now;

        String link = linkSpeed();
        if (link.isEmpty()) {
            wifiText.setText(wifiRates);
        } else {
            wifiText.setText(wifiRates.isEmpty() ? link : link + "  " + wifiRates);
        }
        mobileText.setText(mobRates.isEmpty() ? "--" : mobRates);
        mobileUsedText.setText(bytes(mobRx + mobTx) + " since restart");
        connText.setText(connection());
    }

    private static String rate(double bytesPerSecond) {
        if (bytesPerSecond >= 1024 * 1024) {
            return String.format(Locale.US, "%.1f MB/s", bytesPerSecond / (1024 * 1024));
        }
        if (bytesPerSecond >= 1024) {
            return String.format(Locale.US, "%d KB/s", (long) (bytesPerSecond / 1024));
        }
        return String.format(Locale.US, "%d B/s", (long) bytesPerSecond);
    }

    private static String bytes(long b) {
        if (b >= 1_000_000_000L) {
            return String.format(Locale.US, "%.2f GB", b / 1e9);
        }
        if (b >= 1_000_000L) {
            return String.format(Locale.US, "%.0f MB", b / 1e6);
        }
        if (b >= 1_000L) {
            return String.format(Locale.US, "%.0f KB", b / 1e3);
        }
        return b + " B";
    }

    private String connection() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null) {
                return "offline";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "Wi-Fi";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return "mobile data";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return "ethernet";
            }
            return "connected";
        } catch (Exception e) {
            return "--";
        }
    }

    @SuppressWarnings("deprecation")
    private String linkSpeed() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null || !nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "no Wi-Fi";
            }
            WifiManager wm = (WifiManager) host.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
            int mbps = wi == null ? -1 : wi.getLinkSpeed();
            return mbps > 0 ? mbps + " Mbps" : "connected";
        } catch (Exception e) {
            return "";
        }
    }

    /** Downloads up to 15 MB for at most 7 seconds and shows the real internet speed. Wi-Fi only. */
    private void runSpeedTest() {
        if (testing) {
            return;
        }
        String link = linkSpeed();
        if (link.isEmpty()) {
            speedText.setText("unavailable");
            return;
        }
        if (link.equals("no Wi-Fi")) {
            speedText.setText("connect to Wi-Fi first");
            return;
        }
        testing = true;
        speedText.setText("testing...");
        new Thread(() -> {
            String result;
            try {
                HttpURLConnection c = (HttpURLConnection)
                        new URL("https://speed.cloudflare.com/__down?bytes=15000000").openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                long start = System.nanoTime();
                long got = 0;
                byte[] buf = new byte[65536];
                int n;
                try (InputStream in = c.getInputStream()) {
                    while ((n = in.read(buf)) > 0) {
                        got += n;
                        if (System.nanoTime() - start > 7_000_000_000L) {
                            break;
                        }
                    }
                }
                double sec = (System.nanoTime() - start) / 1e9;
                result = String.format(Locale.US, "%.1f Mbps", got * 8 / sec / 1e6);
            } catch (Exception e) {
                result = "test failed";
            }
            final String shown = result;
            host.runOnUiThread(() -> {
                speedText.setText(shown);
                testing = false;
            });
        }).start();
    }

    // ------------------------------------------------------------------ music page

    private void buildMusic(LinearLayout music) {
        musicTitle = mono("", 14f, Theme.TEXT);
        musicTitle.setSingleLine(true);
        musicTitle.setEllipsize(TextUtils.TruncateAt.END);
        music.addView(musicTitle, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        musicArtist = mono("", 11f, Theme.DIM);
        musicArtist.setSingleLine(true);
        musicArtist.setEllipsize(TextUtils.TruncateAt.END);
        music.addView(musicArtist);

        LinearLayout controls = new LinearLayout(host);
        playBtn = control("PLAY", v -> {
            MusicHelper.toggle(host);
            handler.postDelayed(this::refreshMusic, 350);
        });
        controls.addView(control("<<", v -> {
            MusicHelper.previous(host);
            handler.postDelayed(this::refreshMusic, 350);
        }), weight());
        controls.addView(playBtn, weight());
        controls.addView(control(">>", v -> {
            MusicHelper.next(host);
            handler.postDelayed(this::refreshMusic, 350);
        }), weight());
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 14);
        music.addView(controls, clp);

        // without notification access NOVA can't see what is playing: tapping the page opens that setting
        music.setOnClickListener(v -> {
            if (!NovaNotificationService.hasAccess(host)) {
                openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            }
        });
    }

    private TextView control(String label, OnClickListener click) {
        TextView b = mono(label, 14f, Theme.ACCENT);
        b.setLetterSpacing(0.1f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 12), 0, Theme.dp(host, 8));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private void refreshMusic() {
        if (!NovaNotificationService.hasAccess(host)) {
            musicTitle.setText("Tap to allow music info");
            musicArtist.setText("Turn on notification access for NOVA");
            playBtn.setText("PLAY");
            return;
        }
        MediaController c = MusicHelper.controller(host);
        if (c == null) {
            musicTitle.setText("nothing playing");
            musicArtist.setText("");
            playBtn.setText("PLAY");
            return;
        }
        musicTitle.setText(MusicHelper.title(c));
        musicArtist.setText(MusicHelper.artist(c));
        playBtn.setText(MusicHelper.isPlaying(c) ? "PAUSE" : "PLAY");
    }

    // ------------------------------------------------------------------ battery today

    private void buildBattery(LinearLayout p) {
        graph = new BatteryGraph(host);
        p.addView(graph, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 82)));
        usedText = statValue(p, "USED TODAY");
        drainText = statValue(p, "AVERAGE DRAIN");
        screenText = statValue(p, "SCREEN ON");
        View row = (View) screenText.getParent();
        row.setOnClickListener(v -> {
            if (!UsageHelper.hasAccess(host)) {
                openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            }
        });
    }

    private void refreshBattery() {
        BatteryLog.Day d = BatteryLog.today();
        graph.setDay(d);
        usedText.setText(d.samples.size() < 2 ? "collecting..." : d.used + "%"
                + (d.charged > 0 ? "   charged +" + d.charged + "%" : ""));
        drainText.setText(d.perHour > 0 ? String.format(Locale.US, "%.1f %%/h", d.perHour) : "--");
        bindScreenOn();
    }

    private void bindScreenOn() {
        if (screenText == null) {
            return;
        }
        if (!UsageHelper.hasAccess(host)) {
            screenText.setText("tap to allow");
            screenText.setTextColor(Theme.ACCENT);
        } else if (usage != null) {
            screenText.setText(UsageHelper.duration(usage.screenOnMs));
            screenText.setTextColor(Theme.TEXT);
        } else {
            screenText.setText("...");
        }
    }

    // ------------------------------------------------------------------ app usage

    private void buildUsage(LinearLayout p) {
        usageTotal = statValue(p, "TOTAL TODAY");
        usageBody = new LinearLayout(host);
        usageBody.setOrientation(VERTICAL);
        p.addView(usageBody, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    /** Reads today's usage on a background thread, then fills in both the battery and the usage page. */
    private void loadUsage() {
        if (!UsageHelper.hasAccess(host)) {
            usageTotal.setText("--");
            usageBody.removeAllViews();
            TextView ask = mono("TAP TO ALLOW USAGE ACCESS", 12f, Theme.ACCENT);
            ask.setPadding(0, Theme.dp(host, 16), 0, 0);
            ask.setClickable(true);
            ask.setOnClickListener(v -> openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            usageBody.addView(ask);
            TextView why = mono("Android needs you to allow this once\nto show how long each app was used.", 10f, Theme.DIM);
            why.setPadding(0, Theme.dp(host, 8), 0, 0);
            usageBody.addView(why);
            bindScreenOn();
            return;
        }
        if (loadingUsage) {
            return;
        }
        loadingUsage = true;
        new Thread(() -> {
            UsageHelper.Result r;
            try {
                r = UsageHelper.today(host);
            } catch (Exception e) {
                r = new UsageHelper.Result();
            }
            final UsageHelper.Result res = r;
            host.runOnUiThread(() -> {
                loadingUsage = false;
                if (!isAttachedToWindow()) {
                    return;
                }
                usage = res;
                bindUsage();
                bindScreenOn();
            });
        }).start();
    }

    private void bindUsage() {
        usageTotal.setText(UsageHelper.duration(usage.totalMs));
        usageBody.removeAllViews();
        if (usage.apps.isEmpty()) {
            usageBody.addView(mono("nothing yet today", 11f, Theme.DIM));
            return;
        }
        long max = usage.apps.get(0).ms;
        int shown = Math.min(5, usage.apps.size());
        for (int i = 0; i < shown; i++) {
            UsageHelper.Row r = usage.apps.get(i);
            AppEntry e = host.repo.find(r.pkg);
            String name = e != null ? e.label : r.pkg;

            LinearLayout row = new LinearLayout(host);
            row.setOrientation(VERTICAL);
            row.setPadding(0, Theme.dp(host, 5), 0, 0);
            LinearLayout top = new LinearLayout(host);
            TextView n = mono(name, 11f, Theme.TEXT);
            n.setSingleLine(true);
            n.setEllipsize(TextUtils.TruncateAt.END);
            top.addView(n, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            top.addView(mono(UsageHelper.duration(r.ms), 11f, Theme.DIM));
            row.addView(top);

            LinearLayout bar = new LinearLayout(host);
            bar.setWeightSum(100f);
            bar.setBackground(Theme.rounded(0x22FFFFFF, 2f, host));
            View fill = new View(host);
            fill.setBackground(Theme.rounded(Theme.ACCENT, 2f, host));
            bar.addView(fill, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, Math.max(3f, r.ms * 100f / max)));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 3));
            bp.topMargin = Theme.dp(host, 3);
            row.addView(bar, bp);
            usageBody.addView(row);
        }
    }

    // ------------------------------------------------------------------ bits

    private void openSettings(String action) {
        try {
            host.startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {
            host.toast("Not available on this phone");
        }
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView statValue(LinearLayout parent, String key) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setPadding(0, Theme.dp(host, 8), 0, 0);
        TextView k = mono(key, 11f, Theme.DIM);
        k.setLetterSpacing(0.12f);
        r.addView(k, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        TextView v = mono("", 11f, Theme.TEXT);
        r.addView(v);
        parent.addView(r, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        return v;
    }
}
