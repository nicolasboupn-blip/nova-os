package app.novaos;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.projection.MediaProjectionManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The whole OS lives in this one activity. Because it declares the HOME category,
 * Android offers it as a home app, and when it is the default one Android starts it
 * at boot and whenever you press the home button.
 */
@SuppressWarnings("deprecation")
public class NovaActivity extends Activity {
    static final int BOOT = 0;
    static final int LOCK = 1;
    static final int HOME = 2;
    static final int DRAWER = 3;
    static final int TERMINAL = 4;
    static final int NOTES = 5;
    static final int SETTINGS = 6;

    private static final int REQ_HOME = 77;
    private static final int MAX_FAVS = 20;

    FrameLayout root;
    AppRepo repo;
    SharedPreferences prefs;
    int screen = -1;
    private boolean needLock = false;
    private Shade shade;
    private float shadeStartY;
    private boolean shadeArmed;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            needLock = true;
        }
    };

    /** Writes the battery level into the day log whenever Android reports a change. */
    private final BroadcastReceiver batteryRx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (i == null) {
                return;
            }
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
            if (scale > 0) {
                BatteryLog.record(prefs, level * 100 / scale, chg);
            }
        }
    };

    private final BroadcastReceiver pkgChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            repo.markDirty();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Prefs.init(this);
        Theme.load();
        prefs = getSharedPreferences("nova", MODE_PRIVATE);
        repo = new AppRepo(this);

        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        root = new FrameLayout(this);
        root.setBackground(Theme.background());
        // Keeps the keyboard from covering the terminal and notes.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                bottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });
        setContentView(root);
        goImmersive();

        reg(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
        reg(batteryRx, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_CHANGED);
        pf.addDataScheme("package");
        reg(pkgChanged, pf);

        if (bootChanged()) {
            showBoot(false);
        } else {
            showLock();
        }
    }

    private void reg(BroadcastReceiver r, IntentFilter f) {
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(r, f);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(screenOff);
            unregisterReceiver(pkgChanged);
            unregisterReceiver(batteryRx);
        } catch (Exception ignored) {
            // already unregistered
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (needLock) {
            needLock = false;
            if (screen != BOOT && screen != LOCK) {
                showLock();
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing the phone's home button lands here.
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME)
                && screen != LOCK && screen != BOOT) {
            showHome();
        }
    }

    @Override
    public void onBackPressed() {
        if (hideOverlay()) {
            return;
        }
        // A home screen never closes itself. Back goes up one level instead.
        if (screen == DRAWER || screen == TERMINAL || screen == NOTES || screen == SETTINGS) {
            showHome();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            goImmersive();
        }
    }

    /** Hides Android's status bar and navigation bar so only NOVA is visible. */
    private void goImmersive() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ---------------------------------------------------------------- screens

    private void show(View v, int which) {
        hideKeyboard();
        screen = which;
        shade = null;
        overlay = null;
        root.setBackground(Theme.background());
        // the screen we are leaving fades and drifts away while the new one settles in
        // one continuous move: the old screen fades out while the new one fades in, no pause in between
        android.view.animation.Interpolator ease = new android.view.animation.AccelerateDecelerateInterpolator();
        for (int i = 0; i < root.getChildCount(); i++) {
            final View old = root.getChildAt(i);
            old.setClickable(false);
            old.animate().cancel();
            old.animate().alpha(0f).scaleX(1.02f).scaleY(1.02f).setDuration(560)
                    .setInterpolator(ease)
                    .withEndAction(() -> root.removeView(old)).start();
        }
        v.setAlpha(0f);
        v.setScaleX(0.98f);
        v.setScaleY(0.98f);
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(560)
                .setInterpolator(ease).start();
    }

    private static final int REQ_UPDATE = 78;
    private static final int REQ_CAPTURE = 79;

    // ------------------------------------------------------------- effects and overlays

    private View overlay;

    /** Puts a full-screen view (like the matrix rain) above everything. Back or showing another screen removes it. */
    void showOverlay(View v) {
        hideOverlay();
        overlay = v;
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    boolean hideOverlay() {
        if (overlay == null) {
            return false;
        }
        root.removeView(overlay);
        overlay = null;
        return true;
    }

    /** Confetti pops out of a point on the screen and falls away. */
    void confetti(float x, float y) {
        root.addView(new ConfettiView(this, x, y), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** A short buzz. Does nothing if the phone has no vibrator. */
    void buzz(long ms) {
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        } catch (RuntimeException ignored) {
            // no vibration available
        }
    }

    /** Starts or stops recording the screen. Android shows its own "start recording" confirmation first. */
    void toggleRecording() {
        if (RecordService.running) {
            RecordService.stop(this);
            toast("Recording saved to Movies/NOVA");
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            toast("Screen recording is not available");
            return;
        }
        try {
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (Exception e) {
            toast("Screen recording is not available");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_UPDATE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            installApk(data.getData());
        } else if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                RecordService.start(this, resultCode, data);
                toast("Recording started");
            } else {
                toast("Recording cancelled");
            }
        }
    }

    /** Lets you pick a NOVA .apk from your phone and hands it to Android's installer. No GitHub needed. */
    void pickUpdate() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        try {
            startActivityForResult(i, REQ_UPDATE);
        } catch (Exception e) {
            toast("No file picker on this phone");
        }
    }

    void installApk(android.net.Uri uri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("Could not start the installer");
        }
    }

    void showBoot(boolean quick) {
        show(new BootScreen(this, quick), BOOT);
    }

    /** Swiping the lock screen plays the quick startup (if on), then opens home. */
    void unlock() {
        armIntro();
        Prefs.incUnlocks();
        beep();
        if (Prefs.bootOnUnlock()) {
            showBoot(true);
        } else {
            showHome();
        }
    }

    private boolean introArmed;

    /** Marks the next home screen to play the welcome animation. Called on every unlock. */
    private void armIntro() {
        introArmed = Prefs.intro();
    }

    /** True once per unlock, for the home screen that is about to be built. */
    boolean takeIntro() {
        boolean b = introArmed;
        introArmed = false;
        return b;
    }

    private void beep() {
        if (!Prefs.beep()) {
            return;
        }
        try {
            final ToneGenerator t = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60);
            t.startTone(ToneGenerator.TONE_PROP_ACK, 120);
            root.postDelayed(t::release, 400);
        } catch (RuntimeException ignored) {
            // no tone on this phone
        }
    }

    void showLock() {
        show(new LockScreen(this), LOCK);
    }

    void showHome() {
        show(new HomeScreen(this), HOME);
        maybeAskDefault();
    }

    void showDrawer() {
        show(new DrawerScreen(this), DRAWER);
    }

    void showTerminal() {
        show(new TerminalScreen(this), TERMINAL);
    }

    void showSettings() {
        show(new SettingsScreen(this), SETTINGS);
    }

    /** Re-applies the palette and redraws Settings so the new colors show straight away. */
    void refreshTheme() {
        Theme.load();
        showSettings();
    }

    void showNotes() {
        show(new NotesScreen(this), NOTES);
    }

    /** Swipe down from the top edge to open the control panel, on any screen. */
    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        int a = ev.getActionMasked();
        if (a == android.view.MotionEvent.ACTION_DOWN) {
            shadeStartY = ev.getRawY();
            shadeArmed = shade == null && overlay == null && screen != BOOT && shadeStartY < Theme.dp(this, 110);
        } else if (a == android.view.MotionEvent.ACTION_MOVE && shadeArmed) {
            if (ev.getRawY() - shadeStartY > Theme.dp(this, 90)) {
                shadeArmed = false;
                showShade();
            }
        } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
            shadeArmed = false;
        }
        return super.dispatchTouchEvent(ev);
    }

    void showShade() {
        if (shade != null) {
            return;
        }
        hideKeyboard();
        shade = new Shade(this);
        root.addView(shade, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        shade.open();
    }

    void hideShade() {
        if (shade != null) {
            root.removeView(shade);
            shade = null;
        }
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && root != null) {
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    void launch(AppEntry e) {
        hideKeyboard();
        if (!repo.launch(e)) {
            toast("Could not open " + e.label);
        }
    }

    // ------------------------------------------------------------------ boot

    /** True on first run and after every phone reboot, so the boot animation plays then. */
    private boolean bootChanged() {
        int now = -1;
        try {
            now = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT);
        } catch (Exception ignored) {
            // setting not readable on this phone
        }
        int last = prefs.getInt("boot_count", -2);
        prefs.edit().putInt("boot_count", now).apply();
        return now != last;
    }

    // -------------------------------------------------------- default home app

    boolean isDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return rm.isRoleHeld(RoleManager.ROLE_HOME);
            }
        }
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && getPackageName().equals(ri.activityInfo.packageName);
    }

    private void maybeAskDefault() {
        if (prefs.getBoolean("asked_home", false) || isDefaultHome()) {
            return;
        }
        prefs.edit().putBoolean("asked_home", true).apply();
        root.postDelayed(this::requestHome, 600);
    }

    /** Asks Android to make NOVA the default home app (this is what enables start at boot). */
    void requestHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    toast(Theme.OS_NAME + " is already your home app");
                } else {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME);
                }
                return;
            }
        }
        openHomeSettings();
    }

    /** Opens Android's "Home app" setting, where you can pick the stock launcher again. */
    void openHomeSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                toast("Open Settings > Apps > Default apps > Home app");
            }
        }
    }

    // --------------------------------------------------------------- favorites

    List<String> favs() {
        String s = prefs.getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            out.addAll(repo.defaultPackages());
            saveFavs(out);
            return out;
        }
        if (!s.isEmpty()) {
            out.addAll(Arrays.asList(s.split(",")));
        }
        return out;
    }

    private void saveFavs(List<String> l) {
        prefs.edit().putString("favs", TextUtils.join(",", l)).apply();
    }

    void togglePin(AppEntry e) {
        List<String> l = favs();
        if (l.contains(e.pkg)) {
            l.remove(e.pkg);
            toast("Removed from home");
        } else if (l.size() >= MAX_FAVS) {
            toast("Home is full (" + MAX_FAVS + " apps)");
            return;
        } else {
            l.add(e.pkg);
            toast("Pinned to home");
        }
        saveFavs(l);
    }

    void confirmUnpin(final AppEntry e) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setMessage("Remove from home?")
                .setPositiveButton("Remove", (d, w) -> {
                    togglePin(e);
                    if (screen == HOME) {
                        showHome();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Long-press menu for an app in the drawer. */
    void appMenu(final AppEntry e) {
        boolean pinned = favs().contains(e.pkg);
        String[] items = {pinned ? "Remove from home" : "Pin to home", "App info", "Uninstall"};
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        togglePin(e);
                    } else if (which == 1) {
                        openPackageIntent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, e.pkg);
                    } else {
                        openPackageIntent(Intent.ACTION_DELETE, e.pkg);
                    }
                })
                .show();
    }

    private void openPackageIntent(String action, String pkg) {
        try {
            startActivity(new Intent(action, Uri.parse("package:" + pkg)));
        } catch (Exception ex) {
            toast("Not available for this app");
        }
    }

    // --------------------------------------------------------------- battery

    int batteryLevel() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return -1;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return scale > 0 ? level * 100 / scale : -1;
    }

    boolean charging() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return false;
        }
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
    }

    // ------------------------------------------------------------------ menu

    void showMenu() {
        String[] items = {
            "Switch back to Android",
            "Make " + Theme.OS_NAME + " my home app",
            "Replay boot animation",
            "Lock",
            "About"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(Theme.OS_NAME + " " + Theme.OS_VERSION)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            openHomeSettings();
                            break;
                        case 1:
                            requestHome();
                            break;
                        case 2:
                            showBoot(false);
                            break;
                        case 3:
                            showLock();
                            break;
                        default:
                            showAbout();
                            break;
                    }
                })
                .show();
    }

    private void showAbout() {
        String msg = Theme.OS_NAME + " " + Theme.OS_VERSION + "\n\n"
                + "A home screen that replaces the Android look and starts when your phone boots.\n\n"
                + "Default home app: " + (isDefaultHome() ? "yes" : "no") + "\n"
                + "Android " + Build.VERSION.RELEASE + ", " + Build.MANUFACTURER + " " + Build.MODEL;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("About")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }
}
