package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * A slot machine with play coins (no real money, just for fun). Three reels with six symbols each,
 * a lever on the side. Pull it and the reels spin and stop one after another. Wins make the reels glow
 * and shower the screen with confetti.
 */
final class SlotMachine extends LinearLayout {
    static final String[] SYMBOLS = {"🍒", "🍋", "🔔", "⭐", "💎", "7"};
    // payout multiplier for three of a kind, per symbol above
    private static final int[] TRIPLE = {3, 3, 4, 6, 10, 20};
    private static final int N = SYMBOLS.length;
    private static final int[] BETS = {5, 10, 25, 50};
    private static final String K_COINS = "slot_coins";
    private static final String K_BET = "slot_bet";

    private final NovaActivity host;
    private final Reel[] reels = new Reel[3];
    private final Lever lever;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView message;
    private final Random rnd = new Random();
    private boolean spinning;
    private int coins;
    private int betIndex;

    SlotMachine(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        coins = Prefs.getInt(K_COINS, 100);
        betIndex = Math.max(0, Math.min(BETS.length - 1, Prefs.getInt(K_BET, 1)));

        // top line: coins, message, bet
        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        coinsText = label(11f, Theme.TEXT);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (!spinning && coins < BETS[betIndex]) {
                coins = 100;
                save();
                say("+100 FREE COINS", Theme.ACCENT);
            }
        });
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        message = label(11f, Theme.DIM);
        message.setGravity(Gravity.CENTER);
        top.addView(message, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.4f));
        betText = label(11f, Theme.ACCENT);
        betText.setGravity(Gravity.END);
        betText.setClickable(true);
        betText.setOnClickListener(v -> {
            if (!spinning) {
                betIndex = (betIndex + 1) % BETS.length;
                Prefs.putInt(K_BET, betIndex);
                refresh();
            }
        });
        top.addView(betText, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        addView(top, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // reels and lever
        LinearLayout mid = new LinearLayout(host);
        mid.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            reels[i] = new Reel(host);
            reels[i].pos = rnd.nextInt(N);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, Theme.dp(host, 92), 1f);
            rp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
            mid.addView(reels[i], rp);
        }
        lever = new Lever(host);
        lever.setOnClickListener(v -> pull());
        mid.addView(lever, new LinearLayout.LayoutParams(Theme.dp(host, 46), Theme.dp(host, 92)));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        mp.topMargin = Theme.dp(host, 6);
        addView(mid, mp);

        TextView table = label(9.5f, Theme.DIM);
        table.setText("777 ×20  💎 ×10  ⭐ ×6  🔔 ×4  pair = bet back");
        table.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        tp.topMargin = Theme.dp(host, 6);
        addView(table, tp);
        refresh();
    }

    private TextView label(float size, int color) {
        TextView t = new TextView(host);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setSingleLine(true);
        return t;
    }

    private void save() {
        Prefs.putInt(K_COINS, coins);
        refresh();
    }

    private void refresh() {
        coinsText.setText(coins < BETS[betIndex] && !spinning ? "TAP: FREE COINS" : "COINS " + coins);
        betText.setText("BET " + BETS[betIndex]);
    }

    private void say(String s, int color) {
        message.setText(s);
        message.setTextColor(color);
    }

    // ------------------------------------------------------------------ the pull

    private void pull() {
        if (spinning) {
            return;
        }
        int bet = BETS[betIndex];
        if (coins < bet) {
            say("OUT OF COINS", Theme.ACCENT);
            return;
        }
        coins -= bet;
        Prefs.putInt(K_COINS, coins);
        spinning = true;
        refresh();
        say("", Theme.DIM);
        lever.pull();

        final int[] result = roll();
        final int[] done = {0};
        for (int i = 0; i < 3; i++) {
            final Reel r = reels[i];
            r.setGlow(0f);
            int cur = Math.round(r.pos);
            int curSym = ((cur % N) + N) % N;
            int steps = ((result[i] - curSym) % N + N) % N;
            float target = cur + (3 + i * 2) * N + steps;
            ValueAnimator a = ValueAnimator.ofFloat(r.pos, target);
            a.setDuration(1500L + 600L * i);
            a.setInterpolator(new DecelerateInterpolator(1.5f));
            a.addUpdateListener(an -> r.setPos((float) an.getAnimatedValue()));
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    done[0]++;
                    if (done[0] == 3) {
                        settle(result);
                    }
                }
            });
            a.start();
        }
    }

    /**
     * Picks the three symbols. The odds are set by hand (about 17% for three of a kind, 20% for a pair,
     * and a little under what you bet back on average, like a real machine).
     */
    private int[] roll() {
        double p = rnd.nextDouble();
        double[] cut = {0.004, 0.010, 0.020, 0.030, 0.045, 0.060}; // 7, gem, star, bell, cherry, lemon
        int[] symOrder = {5, 4, 3, 2, 0, 1};
        double acc = 0;
        for (int i = 0; i < cut.length; i++) {
            acc += cut[i];
            if (p < acc) {
                int s = symOrder[i];
                return new int[] {s, s, s};
            }
        }
        acc += 0.20;
        if (p < acc) {
            int a = rnd.nextInt(N);
            int b = (a + 1 + rnd.nextInt(N - 1)) % N;
            int[] out = {a, a, a};
            out[rnd.nextInt(3)] = b;
            return out;
        }
        // a loss: three different symbols
        int a = rnd.nextInt(N);
        int b = (a + 1 + rnd.nextInt(N - 1)) % N;
        int c;
        do {
            c = rnd.nextInt(N);
        } while (c == a || c == b);
        return new int[] {a, b, c};
    }

    private void settle(int[] r) {
        spinning = false;
        int bet = BETS[betIndex];
        if (r[0] == r[1] && r[1] == r[2]) {
            int win = bet * TRIPLE[r[0]];
            coins += win;
            Prefs.putInt(K_COINS, coins);
            say("WIN +" + win + "!", Theme.ACCENT);
            for (Reel x : reels) {
                x.setGlow(1f);
            }
            int[] at = new int[2];
            getLocationOnScreen(at);
            host.confetti(at[0] + getWidth() / 2f, at[1] + getHeight() * 0.45f);
            host.buzz(60);
        } else if (r[0] == r[1] || r[1] == r[2] || r[0] == r[2]) {
            coins += bet;
            Prefs.putInt(K_COINS, coins);
            say("PAIR · BET BACK", Theme.TEXT);
            for (int i = 0; i < 3; i++) {
                boolean part = (r[i] == r[(i + 1) % 3]) || (r[i] == r[(i + 2) % 3]);
                if (part) {
                    reels[i].setGlow(0.45f);
                }
            }
        } else {
            say(coins < BETS[betIndex] ? "BROKE..." : "NO LUCK", Theme.DIM);
        }
        refresh();
    }

    @Override
    protected void onDetachedFromWindow() {
        for (Reel r : reels) {
            r.stopGlow();
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ reel

    /** One column of symbols that scrolls downward. pos 3.0 means symbol number 3 sits in the middle. */
    private static final class Reel extends View {
        float pos;
        private float glow;
        private ValueAnimator pulse;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;

        Reel(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            paint.setTextAlign(Paint.Align.CENTER);
            frame.setStyle(Paint.Style.STROKE);
        }

        void setPos(float p) {
            pos = p;
            invalidate();
        }

        void setGlow(float g) {
            stopGlow();
            glow = g;
            if (g > 0.5f) {
                pulse = ValueAnimator.ofFloat(0.55f, 1f);
                pulse.setDuration(520);
                pulse.setRepeatCount(5);
                pulse.setRepeatMode(ValueAnimator.REVERSE);
                pulse.addUpdateListener(a -> {
                    glow = (float) a.getAnimatedValue();
                    invalidate();
                });
                pulse.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator animation) {
                        glow = 0.4f;
                        invalidate();
                    }
                });
                pulse.start();
            }
            invalidate();
        }

        void stopGlow() {
            if (pulse != null) {
                pulse.removeAllListeners();
                pulse.cancel();
                pulse = null;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            rect.set(2 * d, 2 * d, w - 2 * d, h - 2 * d);
            paint.setColor(0x55000000);
            paint.setStyle(Paint.Style.FILL);
            c.drawRoundRect(rect, 14 * d, 14 * d, paint);

            // the symbols, clipped to the window
            c.save();
            c.clipRect(rect);
            float cell = h * 0.52f;
            float cy = h / 2f;
            int base = (int) Math.floor(pos);
            paint.setTextSize(cell * 0.62f);
            for (int k = -2; k <= 3; k++) {
                int i = base + k;
                float y = cy + (pos - i) * cell;
                float dist = Math.min(1.4f, Math.abs(y - cy) / cell);
                int idx = ((i % N) + N) % N;
                paint.setAlpha((int) (255 * (1f - 0.62f * dist)));
                float size = cell * 0.62f * (1f - 0.18f * dist);
                paint.setTextSize(size);
                if (idx == N - 1) {
                    paint.setColor(0xFFFF4D6D);
                    paint.setFakeBoldText(true);
                } else {
                    paint.setColor(0xFFFFFFFF);
                    paint.setFakeBoldText(false);
                }
                paint.setAlpha((int) (255 * (1f - 0.62f * dist)));
                float base2 = y - (paint.ascent() + paint.descent()) / 2f;
                c.drawText(SYMBOLS[idx], w / 2f, base2, paint);
            }
            paint.setFakeBoldText(false);
            c.restore();

            // the glow frame
            float g = glow;
            int rgb = Theme.GLOW & 0xFFFFFF;
            if (g > 0f) {
                for (int i = 3; i >= 1; i--) {
                    frame.setColor((((int) (70 * g / i)) << 24) | rgb);
                    frame.setStrokeWidth((2 + i * 3.5f) * d);
                    c.drawRoundRect(rect, 14 * d, 14 * d, frame);
                }
                frame.setColor(((int) (120 + 135 * g) << 24) | (Theme.ACCENT & 0xFFFFFF));
            } else {
                frame.setColor(0x33FFFFFF);
            }
            frame.setStrokeWidth(1.6f * d);
            c.drawRoundRect(rect, 14 * d, 14 * d, frame);
        }
    }

    // ------------------------------------------------------------------ lever

    /** The arm on the side. Tap it and the knob swings down and back up. */
    private static final class Lever extends View {
        private float t; // 0 = up, 1 = down
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private ValueAnimator swing;

        Lever(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setClickable(true);
        }

        void pull() {
            if (swing != null) {
                swing.cancel();
            }
            swing = ValueAnimator.ofFloat(0f, 1f, 0f);
            swing.setDuration(750);
            swing.addUpdateListener(a -> {
                t = (float) a.getAnimatedValue();
                invalidate();
            });
            swing.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            return super.onTouchEvent(e);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (swing != null) {
                swing.cancel();
            }
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float r = 12 * d;
            float topY = r + 4 * d;
            float botY = h - r - 6 * d;
            // the groove
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x33FFFFFF);
            c.drawRoundRect(cx - 3 * d, topY, cx + 3 * d, botY, 3 * d, 3 * d, paint);
            // arm and knob
            float ky = topY + (botY - topY) * t;
            paint.setColor(0x66FFFFFF);
            paint.setStrokeWidth(3 * d);
            c.drawLine(cx, botY, cx, ky, paint);
            int rgb = Theme.GLOW & 0xFFFFFF;
            paint.setColor((0x30 << 24) | rgb);
            c.drawCircle(cx, ky, r * 1.9f, paint);
            paint.setColor((0x60 << 24) | rgb);
            c.drawCircle(cx, ky, r * 1.4f, paint);
            paint.setColor(Theme.ACCENT);
            c.drawCircle(cx, ky, r, paint);
            paint.setColor(0x55FFFFFF);
            c.drawCircle(cx - r * 0.3f, ky - r * 0.3f, r * 0.35f, paint);
        }
    }
}
