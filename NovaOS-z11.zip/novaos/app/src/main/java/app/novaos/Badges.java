package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Small achievements. Unlocking one slides a glowing banner down from the top and pops confetti. */
final class Badges {
    static final class Badge {
        final String id;
        final String icon;
        final String name;
        final String how;

        Badge(String id, String icon, String name, String how) {
            this.id = id;
            this.icon = icon;
            this.name = name;
            this.how = how;
        }
    }

    static final Badge[] ALL = {
        new Badge("spin1", "🎰", "First pull", "Pull the slot lever once"),
        new Badge("spin100", "🔁", "Regular", "Spin the slots 100 times"),
        new Badge("jackpot", "7️⃣", "Jackpot", "Land three 7s"),
        new Badge("broke", "💸", "Rock bottom", "Run out of slot coins"),
        new Badge("snake", "🐍", "Snake charmer", "Score 15 in Snake"),
        new Badge("g2048", "🔢", "Five twelve", "Make a 512 tile in 2048"),
        new Badge("memory", "🧠", "Sharp mind", "Finish Memory in 10 moves or less"),
        new Badge("react", "⚡", "Quick draw", "React in under 250 ms"),
        new Badge("hilo", "🃏", "Hot streak", "Win 5 in a row in Higher or Lower"),
        new Badge("whack", "🎯", "Sharpshooter", "Score 20 in Whack"),
        new Badge("stopwatch", "⏱", "Timekeeper", "Start the stopwatch"),
        new Badge("timer", "⏰", "Time's up", "Let a timer run out")
    };

    private Badges() {
    }

    static boolean has(String id) {
        return Prefs.getInt("badge_" + id, 0) == 1;
    }

    static int count() {
        int n = 0;
        for (Badge b : ALL) {
            if (has(b.id)) {
                n++;
            }
        }
        return n;
    }

    static Badge find(String id) {
        for (Badge b : ALL) {
            if (b.id.equals(id)) {
                return b;
            }
        }
        return null;
    }

    /** Adds one to a counter and returns the new value. */
    static int bump(String key) {
        int v = Prefs.getInt("stat_" + key, 0) + 1;
        Prefs.putInt("stat_" + key, v);
        return v;
    }

    /** Gives the badge once. Does nothing if you already have it. */
    static void unlock(final NovaActivity host, String id) {
        final Badge b = find(id);
        if (b == null || has(id)) {
            return;
        }
        Prefs.putInt("badge_" + id, 1);
        host.buzz(40);

        final TextView banner = new TextView(host);
        banner.setText(b.icon + "  BADGE · " + b.name.toUpperCase());
        banner.setTypeface(Theme.MONO);
        banner.setTextSize(13f);
        banner.setLetterSpacing(0.1f);
        banner.setTextColor(Theme.TEXT);
        banner.setGravity(Gravity.CENTER);
        banner.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        banner.setPadding(Theme.dp(host, 20), Theme.dp(host, 12), Theme.dp(host, 20), Theme.dp(host, 12));
        banner.setElevation(Theme.dp(host, 12));
        banner.setShadowLayer(Theme.dp(host, 8), 0f, 0f, Theme.ACCENT);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Theme.dp(host, 48);
        host.root.addView(banner, lp);
        banner.setAlpha(0f);
        banner.setTranslationY(-Theme.dp(host, 40));
        banner.animate().alpha(1f).translationY(0f).setDuration(380).start();
        host.confetti(host.root.getWidth() / 2f, Theme.dp(host, 90));
        banner.postDelayed(() -> banner.animate().alpha(0f).translationY(-Theme.dp(host, 30)).setDuration(400)
                .withEndAction(() -> {
                    if (banner.getParent() != null) {
                        host.root.removeView(banner);
                    }
                }).start(), 2800);
    }

    /** True if the view is still shown, so late callbacks do not touch dead screens. */
    static boolean alive(View v) {
        return v != null && v.isAttachedToWindow();
    }
}
