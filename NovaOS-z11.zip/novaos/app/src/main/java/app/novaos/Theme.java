package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

/** Name, colors and fonts of the OS. The palette comes from Settings > Accent. */
final class Theme {
    static final String OS_NAME = "NOVA";
    static final String OS_VERSION = "2.2";

    static final String[] PRESET_NAMES = {"Purple", "Ice", "Neon", "Mint", "Crimson", "Gold", "Mono", "Sunset"};

    // accent, glow, background 2, background, panel
    private static final int[][] PRESETS = {
        {0xFFB39DFF, 0xFF8A5CFF, 0xFF1A1234, 0xFF0C0917, 0xFF22193F}, // purple
        {0xFF9AE6FF, 0xFF3FA7D6, 0xFF0F1E2E, 0xFF07111C, 0xFF172B40}, // ice
        {0xFFFF9AD5, 0xFFD6408F, 0xFF2A0F24, 0xFF14070F, 0xFF3A1833}, // neon
        {0xFF9CF5C8, 0xFF2FBF8A, 0xFF0F2A22, 0xFF06130F, 0xFF173B30}, // mint
        {0xFFFF8A9A, 0xFFE0344F, 0xFF2A0F14, 0xFF14070A, 0xFF3A1820}, // crimson
        {0xFFFFD98A, 0xFFE0A526, 0xFF2A2008, 0xFF140F04, 0xFF3A2D12}, // gold
        {0xFFEDEDED, 0xFFB8B8B8, 0xFF1A1A1A, 0xFF0A0A0A, 0xFF262626}, // mono
        {0xFFFFB38A, 0xFFFF6A3D, 0xFF2A140F, 0xFF140A07, 0xFF3A2018}  // sunset
    };

    static int BG = 0xFF0C0917;
    static int BG2 = 0xFF1A1234;
    static int PANEL = 0xFF22193F;
    static int ACCENT = 0xFFB39DFF;
    static int GLOW = 0xFF8A5CFF;
    static int TEXT = 0xFFF2EEFF;
    static int DIM = 0xFF8E84B3;

    // hacker mode: accent, glow, background 2, background, panel
    private static final int[] HACKER = {0xFF39FF88, 0xFF00D26A, 0xFF04130A, 0xFF020805, 0xFF0A2214};

    static final Typeface MONO = Typeface.MONOSPACE;
    static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    /** Thin, condensed face for the clock. Looks more like a screen display than a phone clock. */
    static final Typeface DIGITAL = Typeface.create("sans-serif-condensed-light", Typeface.NORMAL);

    /** Turns any icon into a purple monochrome version, so every app matches NOVA. */
    private static final ColorFilter PURPLE_ICONS = new ColorMatrixColorFilter(new ColorMatrix(new float[] {
        0.209f, 0.411f, 0.080f, 0f, 20f,
        0.185f, 0.364f, 0.071f, 0f, 0f,
        0.299f, 0.587f, 0.114f, 0f, 60f,
        0f,     0f,     0f,     1f, 0f
    }));

    /** Same idea as the purple filter, but green, for hacker mode. */
    private static final ColorFilter GREEN_ICONS = new ColorMatrixColorFilter(new ColorMatrix(new float[] {
        0.10f, 0.20f, 0.04f, 0f, 0f,
        0.34f, 0.66f, 0.13f, 0f, 14f,
        0.12f, 0.22f, 0.05f, 0f, 8f,
        0f,    0f,    0f,    1f, 0f
    }));

    /**
     * Pushes every icon to pure black or white: anything darker than about a third brightness
     * goes black, everything lighter (grays included) goes white. Transparency is kept.
     */
    private static final ColorFilter BW_ICONS = new ColorMatrixColorFilter(new ColorMatrix(new float[] {
        1.70f, 5.72f, 0.58f, 0f, -672f,
        1.70f, 5.72f, 0.58f, 0f, -672f,
        1.70f, 5.72f, 0.58f, 0f, -672f,
        0f,    0f,    0f,    1f, 0f
    }));

    private Theme() {}

    /** Applies the chosen accent palette. Call once at start and again after a change. */
    static void load() {
        int i = Math.max(0, Math.min(PRESETS.length - 1, Prefs.accent()));
        int[] p = PRESETS[i];
        if (Prefs.hacker()) {
            p = HACKER;
            TEXT = 0xFFD8FFE4;
            DIM = 0xFF4F8F66;
        } else {
            TEXT = 0xFFF2EEFF;
            DIM = 0xFF8E84B3;
        }
        ACCENT = p[0];
        GLOW = p[1];
        BG2 = p[2];
        BG = p[3];
        PANEL = p[4];
    }

    static int presetAccent(int i) {
        return PRESETS[i][0];
    }

    /** The clock face chosen in Settings. */
    static Typeface clockFace() {
        if (Prefs.hacker()) {
            return Typeface.MONOSPACE;
        }
        switch (Prefs.clockFont()) {
            case 1:
                return LIGHT;
            case 2:
                return Typeface.MONOSPACE;
            case 3:
                return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            default:
                return DIGITAL;
        }
    }

    /** Opacity of the code wallpaper on the home screen, from Settings. */
    static float wallAlpha() {
        float[] levels = {0.14f, 0.22f, 0.35f};
        return Prefs.hacker() ? 0.35f : levels[Math.max(0, Math.min(2, Prefs.homeStrength()))];
    }

    /** Battery level 0-100, read from Android's sticky battery broadcast. */
    static int batteryPct(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return 100;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return level < 0 || scale <= 0 ? 100 : level * 100 / scale;
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** Styles an app icon the way Settings > App icons says. Returns a drawable ready for an ImageView. */
    static Drawable tint(Context c, Drawable original) {
        if (original == null) {
            return null;
        }
        // work on a private copy so one screen never changes how another screen draws the same icon
        Drawable.ConstantState cs = original.getConstantState();
        Drawable d = cs != null ? cs.newDrawable().mutate() : original;
        int style = Prefs.iconStyle();
        if (style == 2) {
            d.setColorFilter(null);
            return d;
        }
        if (style == 1) {
            d.setColorFilter(Prefs.hacker() ? GREEN_ICONS : PURPLE_ICONS);
            return d;
        }
        Bitmap bw = BW_CACHE.get(original);
        if (bw == null) {
            bw = blackAndWhite(d);
            BW_CACHE.put(original, bw);
        }
        android.graphics.drawable.BitmapDrawable flat =
                new android.graphics.drawable.BitmapDrawable(c.getResources(), bw);
        flat.setFilterBitmap(true);
        return new ParticleGlow(c, flat, GLOW, System.identityHashCode(original));
    }

    private static final java.util.WeakHashMap<Drawable, Bitmap> BW_CACHE = new java.util.WeakHashMap<>();

    /**
     * Rebuilds an icon as a black tile with a white symbol. It finds the icon's background color
     * from its edges, and everything that differs from that background becomes the white symbol.
     * That works the same for dark icons, bright icons and colored ones, so all of them match.
     */
    private static Bitmap blackAndWhite(Drawable src) {
        final int s = 96;
        Bitmap in = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        src.setBounds(0, 0, s, s);
        src.draw(new Canvas(in));
        int[] px = new int[s * s];
        in.getPixels(px, 0, s, 0, 0, s, s);
        in.recycle();

        // background color: average of opaque pixels along a ring just inside the edge
        long r = 0, g = 0, b = 0;
        int n = 0;
        int m = Math.round(s * 0.09f);
        for (int i = Math.round(s * 0.22f); i < s * 0.78f; i += 2) {
            int[] at = {m * s + i, (s - 1 - m) * s + i, i * s + m, i * s + (s - 1 - m)};
            for (int idx : at) {
                int p = px[idx];
                if ((p >>> 24) > 200) {
                    r += (p >> 16) & 0xFF;
                    g += (p >> 8) & 0xFF;
                    b += p & 0xFF;
                    n++;
                }
            }
        }
        boolean solid = n >= 8;
        int br = solid ? (int) (r / n) : 0;
        int bg = solid ? (int) (g / n) : 0;
        int bb = solid ? (int) (b / n) : 0;

        // tile shape: the icon's own shape, or a rounded square if the icon has no background
        int[] tile = new int[s * s];
        if (solid) {
            for (int i = 0; i < tile.length; i++) {
                tile[i] = px[i] >>> 24;
            }
        } else {
            Bitmap shape = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            android.graphics.Paint pt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            pt.setColor(0xFF000000);
            new Canvas(shape).drawRoundRect(new android.graphics.RectF(s * 0.04f, s * 0.04f, s * 0.96f, s * 0.96f),
                    s * 0.3f, s * 0.3f, pt);
            int[] sp = new int[s * s];
            shape.getPixels(sp, 0, s, 0, 0, s, s);
            shape.recycle();
            for (int i = 0; i < tile.length; i++) {
                tile[i] = sp[i] >>> 24;
            }
        }

        int[] out = new int[s * s];
        for (int i = 0; i < out.length; i++) {
            int p = px[i];
            float k;
            if (solid) {
                int dr = ((p >> 16) & 0xFF) - br;
                int dg = ((p >> 8) & 0xFF) - bg;
                int db = (p & 0xFF) - bb;
                float diff = (float) Math.sqrt(dr * dr + dg * dg + db * db) / 441f;
                k = Math.max(0f, Math.min(1f, (diff - 0.10f) / 0.22f));
            } else {
                k = (p >>> 24) / 255f;
            }
            int v = Math.round(10 + (232 - 10) * k); // near-black tile, soft white symbol
            out[i] = (tile[i] << 24) | (v << 16) | (v << 8) | v;
        }
        Bitmap res = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        res.setPixels(out, 0, s, 0, 0, s, s);
        return res;
    }

    /**
     * Slow, living glow for a text view. One cycle takes about 9 seconds: the light
     * drifts around the letters in a loop, and it brightens and dims as it goes.
     * Turned off in Settings, it stays silent. Cancel the returned animator when the view goes away.
     */
    static ValueAnimator glow(final TextView v) {
        final Glow g = new Glow(v.getContext());
        ValueAnimator a = g.animator();
        a.addUpdateListener(an -> {
            if (!g.on) {
                v.setShadowLayer(0f, 0f, 0f, 0);
                return;
            }
            g.at((float) an.getAnimatedValue());
            v.setShadowLayer(g.radius, g.dx, g.dy, (g.alpha << 24) | (GLOW & 0xFFFFFF));
        });
        a.start();
        return a;
    }

    /**
     * The numbers behind the living glow, so text and custom-drawn views glow identically.
     * Call at(t) with t from 0 to 1 and read radius, dx, dy and alpha.
     */
    static final class Glow {
        final boolean on = Prefs.glowClock();
        private final float density;
        private final float k;
        private final long period;
        float radius;
        float dx;
        float dy;
        int alpha;
        /** 0 (dim) to 1 (bright), one swell per cycle. */
        float breathe;

        Glow(Context c) {
            density = c.getResources().getDisplayMetrics().density;
            int level = Prefs.glowStrength();
            k = level == 0 ? 0.5f : level == 2 ? 1.4f : 1f;
            // hacker mode: one cycle takes 9s at a full battery and speeds up to 3s at empty
            period = Prefs.hacker() ? 3000 + 60 * batteryPct(c) : 9000;
        }

        ValueAnimator animator() {
            ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
            a.setDuration(period);
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setRepeatMode(ValueAnimator.RESTART);
            a.setInterpolator(new LinearInterpolator());
            return a;
        }

        void at(float t) {
            double ang = t * 2 * Math.PI;
            breathe = (float) (0.5 + 0.5 * Math.sin(ang));
            radius = (8f + 12f * breathe) * density * k;
            float orbit = 5f * density;
            dx = (float) (Math.cos(ang) * orbit);
            dy = (float) (Math.sin(ang) * orbit * 0.6f);
            alpha = Math.min(255, (int) ((80 + 175 * breathe) * k));
        }
    }

    static GradientDrawable rounded(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable background() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[] {BG2, BG});
    }

    /** Touch ripple for buttons. */
    static void ripple(View v) {
        TypedValue tv = new TypedValue();
        if (v.getContext().getTheme().resolveAttribute(
                android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
            v.setBackgroundResource(tv.resourceId);
        }
    }
}
