package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The games page: six boxes. Press one and it grows from where it sits until it fills the whole screen
 * as that game. The X (or the back button) shrinks it back into its box.
 */
final class MiniGames extends LinearLayout {
    private static final String[] NAMES = {"SNAKE", "2048", "MEMORY", "REACTION", "HI / LO", "WHACK"};
    private static final String[] ICONS = {"🐍", "🔢", "🧠", "⚡", "🃏", "🎯"};
    private static final String[] KEYS = {"snake", "2048", "memory", "react", "", "whack"};
    private static final String[] UNITS = {"", "", " moves", " ms", "", ""};

    private final NovaActivity host;
    private final TextView[] bests = new TextView[6];

    MiniGames(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        for (int row = 0; row < 2; row++) {
            LinearLayout line = new LinearLayout(host);
            for (int col = 0; col < 3; col++) {
                final int idx = row * 3 + col;
                LinearLayout box = new LinearLayout(host);
                box.setOrientation(VERTICAL);
                box.setGravity(Gravity.CENTER);
                box.setBackground(Theme.rounded(0x26FFFFFF, 14f, host));
                box.setClickable(true);
                Theme.ripple(box);
                TextView icon = new TextView(host);
                icon.setText(ICONS[idx]);
                icon.setTextSize(24f);
                icon.setGravity(Gravity.CENTER);
                box.addView(icon);
                TextView name = new TextView(host);
                name.setText(NAMES[idx]);
                name.setTypeface(Theme.MONO);
                name.setTextSize(9f);
                name.setLetterSpacing(0.1f);
                name.setTextColor(Theme.TEXT);
                name.setGravity(Gravity.CENTER);
                box.addView(name);
                bests[idx] = new TextView(host);
                bests[idx].setTypeface(Theme.MONO);
                bests[idx].setTextSize(8f);
                bests[idx].setTextColor(Theme.DIM);
                bests[idx].setGravity(Gravity.CENTER);
                box.addView(bests[idx]);
                box.setOnClickListener(v -> open(idx, v));
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Theme.dp(host, 74), 1f);
                bp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                line.addView(box, bp);
            }
            addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        refreshBests();
    }

    void refreshBests() {
        for (int i = 0; i < 6; i++) {
            if (KEYS[i].isEmpty()) {
                bests[i].setText("coins " + Prefs.getInt("slot_coins", 100));
                continue;
            }
            int b = Game.best(KEYS[i], 0);
            bests[i].setText(b > 0 ? "best " + b + UNITS[i] : "play");
        }
    }

    private Game create(int idx) {
        switch (idx) {
            case 0:
                return new GameSnake(host);
            case 1:
                return new Game2048(host);
            case 2:
                return new GameMemory(host);
            case 3:
                return new GameReaction(host);
            case 4:
                return new GameHiLo(host);
            default:
                return new GameWhack(host);
        }
    }

    private void open(int idx, final View box) {
        final Frame frame = new Frame(host, create(idx), box, this);
        host.showOverlay(frame);
        frame.grow();
    }

    /** The full-screen window around a game: dark background, title, and a close button. */
    private static final class Frame extends FrameLayout {
        private final NovaActivity host;
        private final View from;
        private final MiniGames owner;
        private boolean closing;

        Frame(final NovaActivity host, Game game, View from, MiniGames owner) {
            super(host);
            this.host = host;
            this.from = from;
            this.owner = owner;
            setBackgroundColor(Theme.BG);
            setClickable(true);
            addView(game, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

            TextView title = new TextView(host);
            title.setText(game.title());
            title.setTypeface(Theme.MONO);
            title.setTextSize(12f);
            title.setLetterSpacing(0.3f);
            title.setTextColor(Theme.ACCENT);
            LayoutParams tp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.START);
            tp.setMargins(Theme.dp(host, 20), Theme.dp(host, 22), 0, 0);
            addView(title, tp);

            TextView close = new TextView(host);
            close.setText("✕");
            close.setTextSize(20f);
            close.setTextColor(Theme.TEXT);
            close.setGravity(Gravity.CENTER);
            close.setClickable(true);
            Theme.ripple(close);
            close.setOnClickListener(v -> shrink());
            addView(close, new LayoutParams(Theme.dp(host, 52), Theme.dp(host, 52), Gravity.TOP | Gravity.END));
        }

        /** Where the box centre sits, in this frame's own coordinates. */
        private float[] origin() {
            int[] a = new int[2];
            int[] b = new int[2];
            from.getLocationOnScreen(a);
            getLocationOnScreen(b);
            return new float[] {a[0] - b[0] + from.getWidth() / 2f, a[1] - b[1] + from.getHeight() / 2f};
        }

        void grow() {
            setAlpha(0f);
            post(() -> {
                if (from.getWidth() == 0 || getWidth() == 0) {
                    setAlpha(1f);
                    return;
                }
                float[] o = origin();
                setPivotX(o[0]);
                setPivotY(o[1]);
                setScaleX(from.getWidth() / (float) getWidth());
                setScaleY(from.getHeight() / (float) getHeight());
                animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
                        .setInterpolator(new DecelerateInterpolator(1.8f)).start();
            });
        }

        void shrink() {
            if (closing) {
                return;
            }
            closing = true;
            owner.refreshBests();
            if (!from.isAttachedToWindow() || getWidth() == 0) {
                host.hideOverlay();
                return;
            }
            float[] o = origin();
            setPivotX(o[0]);
            setPivotY(o[1]);
            animate().alpha(0f).scaleX(from.getWidth() / (float) getWidth())
                    .scaleY(from.getHeight() / (float) getHeight()).setDuration(240)
                    .withEndAction(host::hideOverlay).start();
        }

        @Override
        protected void onDetachedFromWindow() {
            owner.refreshBests();
            super.onDetachedFromWindow();
        }
    }
}
