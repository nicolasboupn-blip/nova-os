package app.novaos;

import android.content.Context;
import android.content.SharedPreferences;

/** Every setting NOVA has. Read it anywhere, change it from the Settings screen. */
final class Prefs {
    static final String K_ACCENT = "s_accent";
    static final String K_GLOW_CLOCK = "s_glow_clock";
    static final String K_GLOW_EDGES = "s_glow_edges";
    static final String K_BATTERY = "s_battery";
    static final String K_CODE_WALL = "s_code_wall";
    static final String K_WALL_TEXT = "s_wall_text";
    static final String K_BOOT_UNLOCK = "s_boot_unlock";
    static final String K_BEEP = "s_beep";
    static final String K_GREETING = "s_greeting";
    static final String K_UNLOCKS = "s_unlocks";
    static final String K_HOME_CODE = "s_home_code";
    static final String K_HOME_STRENGTH = "s_home_strength";
    static final String K_SYSTEM_PANEL = "s_system_panel";
    static final String K_CLOCK_FONT = "s_clock_font";
    static final String K_GLOW_STRENGTH = "s_glow_strength";
    static final String K_ICON_STYLE = "s_icon_style";
    static final String K_HACKER = "s_hacker";
    static final String K_INTRO = "s_intro";
    static final String K_CLOCK_STYLE = "s_clock_style";
    static final String K_GREET_AUTO = "s_greet_auto";
    static final String K_TOUCH_GLOW = "s_touch_glow";
    static final String K_PIN = "s_pin";
    static final String K_BIO = "s_bio";
    static final String K_GREET_HOLD = "s_greet_hold";

    private static SharedPreferences sp;

    private Prefs() {}

    static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("nova", Context.MODE_PRIVATE);
        }
    }

    static int accent() {
        return sp.getInt(K_ACCENT, 0);
    }

    static boolean glowClock() {
        return sp.getBoolean(K_GLOW_CLOCK, true);
    }

    static boolean glowEdges() {
        return sp.getBoolean(K_GLOW_EDGES, true);
    }

    static boolean battery() {
        return sp.getBoolean(K_BATTERY, true);
    }

    static boolean codeWall() {
        return sp.getBoolean(K_CODE_WALL, true);
    }

    static boolean bootOnUnlock() {
        return sp.getBoolean(K_BOOT_UNLOCK, false);
    }

    static boolean beep() {
        return sp.getBoolean(K_BEEP, false);
    }

    static String wallText() {
        return sp.getString(K_WALL_TEXT, "");
    }

    static String greeting() {
        if (greetAuto()) {
            int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
            if (h >= 5 && h < 12) {
                return "good morning";
            } else if (h >= 12 && h < 18) {
                return "good afternoon";
            } else if (h >= 18 && h < 22) {
                return "good evening";
            }
            return "good night";
        }
        String g = sp.getString(K_GREETING, "welcome");
        return g.trim().isEmpty() ? "welcome" : g.trim();
    }

    /** Code wallpaper behind the home screen. */
    static boolean homeCode() {
        return sp.getBoolean(K_HOME_CODE, true);
    }

    /** 0 = subtle, 1 = medium, 2 = strong. */
    static int homeStrength() {
        return sp.getInt(K_HOME_STRENGTH, 0);
    }

    static boolean systemPanel() {
        return sp.getBoolean(K_SYSTEM_PANEL, true);
    }

    /** 0 = digital, 1 = classic. */
    static int clockFont() {
        return sp.getInt(K_CLOCK_FONT, 0);
    }

    /** 0 = soft, 1 = normal, 2 = strong. */
    static int glowStrength() {
        return sp.getInt(K_GLOW_STRENGTH, 1);
    }

    /** 0 = black and white with a glowing edge, 1 = single-color tint, 2 = original icons. */
    static int iconStyle() {
        return sp.getInt(K_ICON_STYLE, 0);
    }

    /** Green terminal look; the glow pulses faster as the battery drops. */
    static boolean hacker() {
        return sp.getBoolean(K_HACKER, false);
    }

    /** The "welcome" animation that plays after you unlock. */
    static boolean intro() {
        return sp.getBoolean(K_INTRO, true);
    }

    /** 0 = digital, 1 = stacked, 2 = analog, 3 = binary. */
    static int clockStyle() {
        return sp.getInt(K_CLOCK_STYLE, 0);
    }

    /** How long the big greeting stays in the welcome animation, in half seconds. 0 means until you tap. */
    static int greetHold() {
        return Math.max(0, Math.min(20, sp.getInt(K_GREET_HOLD, 2)));
    }

    /** Greeting that follows the time of day ("good morning"...), instead of your own text. */
    static boolean greetAuto() {
        return sp.getBoolean(K_GREET_AUTO, true);
    }

    /** App icons throw sparks when you touch them. */
    static boolean touchGlow() {
        return sp.getBoolean(K_TOUCH_GLOW, true);
    }

    /** Fingerprint unlock on the lock screen (only used together with a PIN). */
    static boolean bio() {
        return sp.getBoolean(K_BIO, false);
    }

    // ---- NOVA PIN (stored as a salted hash, never the digits)

    static boolean hasPin() {
        return !sp.getString(K_PIN, "").isEmpty();
    }

    static int pinLength() {
        String p = sp.getString(K_PIN, "");
        int i = p.indexOf(':');
        return i < 0 ? 0 : Integer.parseInt(p.substring(0, i));
    }

    static void setPin(String digits) {
        String salt = Long.toHexString(System.nanoTime());
        sp.edit().putString(K_PIN, digits.length() + ":" + salt + ":" + hash(salt + digits)).apply();
    }

    static void clearPin() {
        sp.edit().remove(K_PIN).apply();
    }

    static boolean checkPin(String digits) {
        String[] p = sp.getString(K_PIN, "").split(":");
        return p.length == 3 && p[2].equals(hash(p[1] + digits));
    }

    private static String hash(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    // ---- small bits of state that are not settings (kept through "reset all settings")

    static int getInt(String key, int def) {
        return sp.getInt(key, def);
    }

    static String getString(String key, String def) {
        return sp.getString(key, def);
    }

    static int unlocks() {
        return sp.getInt(K_UNLOCKS, 0);
    }

    static void incUnlocks() {
        sp.edit().putInt(K_UNLOCKS, unlocks() + 1).apply();
    }

    static void putBool(String key, boolean v) {
        sp.edit().putBoolean(key, v).apply();
    }

    static void putInt(String key, int v) {
        sp.edit().putInt(key, v).apply();
    }

    static void putString(String key, String v) {
        sp.edit().putString(key, v).apply();
    }

    /** Puts every setting back to its default. The unlock counter is kept. */
    static void reset() {
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) {
            if (k.startsWith("s_") && !k.equals(K_UNLOCKS) && !k.equals(K_PIN)) {
                e.remove(k);
            }
        }
        e.apply();
    }
}
