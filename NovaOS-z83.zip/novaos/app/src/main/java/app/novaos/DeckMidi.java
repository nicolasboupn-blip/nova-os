package app.novaos;

import android.content.Context;
import android.content.pm.PackageManager;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiInputPort;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Connects a Novation Launchpad Mini MK3 plugged into the phone over USB to the launch deck. It puts the Launchpad
 * into Programmer mode (every pad is a plain note, 11 bottom-left to 88 top-right), lights each pad in its deck
 * colour, and runs the bind when a pad is pressed. Uses Android's built-in USB MIDI, so no extra permission.
 */
final class DeckMidi {
    private DeckMidi() {}

    static final String K_ON = "deck_usb";

    private static final int[] HEADER = {0xF0, 0x00, 0x20, 0x29, 0x02, 0x0D};

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static NovaActivity host;
    private static MidiManager mm;
    private static MidiManager.DeviceCallback callback;
    private static MidiDevice device;
    private static MidiDeviceInfo connected;
    private static boolean opening;
    private static final List<MidiInputPort> ins = new ArrayList<>();
    private static final List<MidiOutputPort> outs = new ArrayList<>();
    private static int lastNote = -1;
    private static long lastAt;

    /** A line the deck screen shows so you can see what is going on. */
    static String status = "off";
    static Runnable listener;

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    private static void setStatus(String s) {
        status = s;
        Runnable l = listener;
        if (l != null) {
            ui.post(l);
        }
    }

    // ------------------------------------------------------------------ finding the Launchpad

    /** Starts watching for a Launchpad. Safe to call again. */
    static void start(NovaActivity h) {
        host = h;
        if (!enabled()) {
            setStatus("switched off in Settings");
            return;
        }
        if (!h.getPackageManager().hasSystemFeature(PackageManager.FEATURE_MIDI)) {
            setStatus("this phone has no USB MIDI support");
            return;
        }
        if (mm == null) {
            mm = (MidiManager) h.getSystemService(Context.MIDI_SERVICE);
        }
        if (mm == null) {
            setStatus("this phone has no USB MIDI support");
            return;
        }
        if (callback == null) {
            callback = new MidiManager.DeviceCallback() {
                @Override
                public void onDeviceAdded(MidiDeviceInfo info) {
                    tryConnect(info);
                }

                @Override
                public void onDeviceRemoved(MidiDeviceInfo info) {
                    if (connected != null && info.getId() == connected.getId()) {
                        closePorts(false);
                        setStatus("Launchpad unplugged");
                    }
                }
            };
            mm.registerDeviceCallback(callback, ui);
        }
        scan();
    }

    /** Looks at every USB MIDI device that is plugged in now. */
    static void scan() {
        if (mm == null || device != null || opening) {
            return;
        }
        setStatus("looking for a Launchpad...");
        for (MidiDeviceInfo info : mm.getDevices()) {
            if (tryConnect(info)) {
                return;
            }
        }
        setStatus("no Launchpad found. Plug it in with a data cable");
    }

    /** The USB button in the deck. */
    static void rescan(NovaActivity h) {
        if (!enabled()) {
            h.toast("Switch on \"Launchpad over USB\" in Settings first");
            return;
        }
        if (mm == null || callback == null) {
            start(h);
        } else {
            host = h;
            scan();
        }
    }

    /** Called when the Settings switch changes. */
    static void applySetting(NovaActivity h) {
        if (enabled()) {
            start(h);
        } else {
            closePorts(true);
            setStatus("switched off in Settings");
        }
    }

    static void stop() {
        closePorts(true);
        if (mm != null && callback != null) {
            try {
                mm.unregisterDeviceCallback(callback);
            } catch (Exception ignored) {
                // already gone
            }
        }
        callback = null;
        mm = null;
        host = null;
    }

    private static boolean isLaunchpad(MidiDeviceInfo info) {
        if (info.getType() != MidiDeviceInfo.TYPE_USB) {
            return false;
        }
        Bundle p = info.getProperties();
        String all = (p.getString(MidiDeviceInfo.PROPERTY_NAME, "") + " "
                + p.getString(MidiDeviceInfo.PROPERTY_PRODUCT, "") + " "
                + p.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER, "")).toLowerCase(Locale.ROOT);
        return all.contains("launchpad") || all.contains("lpmini") || all.contains("novation");
    }

    private static boolean tryConnect(MidiDeviceInfo info) {
        if (mm == null || device != null || opening || !isLaunchpad(info)) {
            return false;
        }
        opening = true;
        final MidiDeviceInfo inf = info;
        setStatus("Launchpad found, connecting...");
        mm.openDevice(info, d -> {
            opening = false;
            if (d == null) {
                setStatus("could not open the Launchpad (is another app using it?)");
                return;
            }
            attach(d, inf);
        }, ui);
        return true;
    }

    private static final MidiReceiver RX = new MidiReceiver() {
        @Override
        public void onSend(byte[] data, int offset, int count, long timestamp) throws IOException {
            parse(data, offset, count);
        }
    };

    private static void attach(MidiDevice d, MidiDeviceInfo info) {
        device = d;
        connected = info;
        for (MidiDeviceInfo.PortInfo p : info.getPorts()) {
            try {
                if (p.getType() == MidiDeviceInfo.PortInfo.TYPE_INPUT) {
                    MidiInputPort ip = d.openInputPort(p.getPortNumber());
                    if (ip != null) {
                        ins.add(ip);
                    }
                } else {
                    MidiOutputPort op = d.openOutputPort(p.getPortNumber());
                    if (op != null) {
                        op.connect(RX);
                        outs.add(op);
                    }
                }
            } catch (Exception ignored) {
                // that port is busy, the others may still work
            }
        }
        if (ins.isEmpty() || outs.isEmpty()) {
            setStatus("Launchpad opened but its MIDI ports would not open");
            closePorts(false);
            return;
        }
        send(sysex(0x0E, 0x01)); // Programmer mode
        setStatus("Launchpad connected");
        ui.postDelayed(DeckMidi::lightAll, 300);
    }

    private static void closePorts(boolean sayGoodbye) {
        DeckMouse.releaseAll();
        if (sayGoodbye && device != null) {
            send(sysex(0x0E, 0x00)); // back to Live mode
        }
        for (MidiOutputPort op : outs) {
            try {
                op.disconnect(RX);
                op.close();
            } catch (Exception ignored) {
                // already closed
            }
        }
        for (MidiInputPort ip : ins) {
            try {
                ip.close();
            } catch (Exception ignored) {
                // already closed
            }
        }
        outs.clear();
        ins.clear();
        if (device != null) {
            try {
                device.close();
            } catch (Exception ignored) {
                // already closed
            }
        }
        device = null;
        connected = null;
        opening = false;
    }

    // ------------------------------------------------------------------ sending

    private static byte[] sysex(int... body) {
        byte[] m = new byte[HEADER.length + body.length + 1];
        int p = 0;
        for (int b : HEADER) {
            m[p++] = (byte) b;
        }
        for (int b : body) {
            m[p++] = (byte) b;
        }
        m[p] = (byte) 0xF7;
        return m;
    }

    private static void send(byte[] m) {
        for (MidiInputPort ip : ins) {
            try {
                ip.send(m, 0, m.length);
            } catch (IOException ignored) {
                // the cable went away, onDeviceRemoved tidies up
            }
        }
    }

    /** The programmer-mode note of a deck pad. Deck row 0 is the top row, and the Launchpad counts rows from the bottom. */
    private static int noteOf(int idx) {
        return (DeckBinds.N - idx / DeckBinds.N) * 10 + (idx % DeckBinds.N + 1);
    }

    private static int[] rgb(DeckBinds.Bind b) {
        if (b.type.equals("none")) {
            return new int[] {0, 0, 0};
        }
        float k = b.empty() || DeckBinds.dimmed(b) ? 0.18f : 1f;
        int c = b.color;
        return new int[] {
            Math.min(127, (int) (((c >> 16) & 0xFF) * k / 2f)),
            Math.min(127, (int) (((c >> 8) & 0xFF) * k / 2f)),
            Math.min(127, (int) ((c & 0xFF) * k / 2f))};
    }

    private static final int[][] LAST = new int[DeckBinds.SIZE][];

    /** The LED colour of a pad right now: its bind colour, with any ripple that is passing over it. */
    private static int[] ledOf(int i, DeckBinds.Bind b) {
        int[] c = rgb(b);
        if (!DeckRipple.busy()) {
            return c;
        }
        int base = 0xFF000000 | ((c[0] * 2) << 16) | ((c[1] * 2) << 8) | (c[2] * 2);
        int t = DeckRipple.tint(i, base);
        return new int[] {
            Math.min(127, ((t >> 16) & 0xFF) / 2),
            Math.min(127, ((t >> 8) & 0xFF) / 2),
            Math.min(127, (t & 0xFF) / 2)};
    }

    /** Paints all 64 pads in the colours of their binds. Called when connected and whenever a bind changes. */
    static void lightAll() {
        sendLeds(true);
    }

    /** One frame of the water effect: only the pads whose colour changed are sent. */
    static void rippleFrame() {
        sendLeds(false);
    }

    private static void sendLeds(boolean force) {
        if (ins.isEmpty()) {
            return;
        }
        List<DeckBinds.Bind> all = DeckBinds.all();
        int[] pad = new int[DeckBinds.SIZE];
        int[][] col = new int[DeckBinds.SIZE][];
        int n = 0;
        for (int i = 0; i < DeckBinds.SIZE; i++) {
            int[] c = ledOf(i, all.get(i));
            if (!force && LAST[i] != null && java.util.Arrays.equals(LAST[i], c)) {
                continue;
            }
            LAST[i] = c;
            pad[n] = i;
            col[n] = c;
            n++;
        }
        final int per = 16; // 16 pads per message keeps every message small
        for (int s = 0; s < n; s += per) {
            int cnt = Math.min(per, n - s);
            int[] body = new int[1 + cnt * 5];
            int p = 0;
            body[p++] = 0x03; // RGB colour command
            for (int k = s; k < s + cnt; k++) {
                body[p++] = 0x03; // static RGB
                body[p++] = noteOf(pad[k]);
                body[p++] = col[k][0];
                body[p++] = col[k][1];
                body[p++] = col[k][2];
            }
            send(sysex(body));
        }
    }

    private static void setPad(int note, int[] c) {
        send(sysex(0x03, 0x03, note, c[0], c[1], c[2]));
    }

    // ------------------------------------------------------------------ pad presses

    private static void parse(byte[] d, int offset, int count) {
        int i = offset;
        int end = offset + count;
        while (i < end) {
            int s = d[i] & 0xFF;
            if (s == 0xF0) {
                while (i < end && (d[i] & 0xFF) != 0xF7) {
                    i++;
                }
                i++;
                continue;
            }
            if (s < 0x80) {
                i++;
                continue;
            }
            int type = s & 0xF0;
            if (type == 0xC0 || type == 0xD0) {
                i += 2;
                continue;
            }
            if (type >= 0x80 && type <= 0xE0) {
                if (i + 2 >= end) {
                    break;
                }
                int note = d[i + 1] & 0x7F;
                int vel = d[i + 2] & 0x7F;
                if (type == 0x90 && vel > 0) {
                    pressed(note);
                } else if (type == 0x80 || type == 0x90) {
                    released(note);
                }
                i += 3;
                continue;
            }
            i++;
        }
    }

    private static void pressed(final int note) {
        long now = SystemClock.uptimeMillis();
        if (note == lastNote && now - lastAt < 40) {
            return; // the same press arriving on two ports
        }
        lastNote = note;
        lastAt = now;
        int r = note / 10;
        int c = note % 10;
        if (r < 1 || r > DeckBinds.N || c < 1 || c > DeckBinds.N) {
            return;
        }
        final int idx = (DeckBinds.N - r) * DeckBinds.N + (c - 1);
        ui.post(() -> run(idx, note));
    }

    /** A pad came up: only the mouse arrows care, because they keep moving while held. */
    private static void released(final int note) {
        int r = note / 10;
        int c = note % 10;
        if (r < 1 || r > DeckBinds.N || c < 1 || c > DeckBinds.N) {
            return;
        }
        final int idx = (DeckBinds.N - r) * DeckBinds.N + (c - 1);
        if (DeckBinds.isMouse(idx)) {
            final String type = DeckBinds.get(idx).type;
            ui.post(() -> DeckMouse.release(type));
        }
    }

    private static void run(int idx, final int note) {
        NovaActivity h = host;
        if (h == null) {
            return;
        }
        final DeckBinds.Bind b = DeckBinds.get(idx);
        DeckRipple.hit(idx);
        if (b.empty()) {
            h.toast("Empty pad. Hold it in the LAUNCH DECK on screen to set it");
            return;
        }
        if (!DeckRipple.active()) {
            // without the water effect the pad just flashes white
            setPad(note, new int[] {127, 127, 127});
            ui.postDelayed(() -> setPad(note, rgb(b)), 160);
        }
        if (b.type.startsWith("m_")) {
            DeckMouse.press(h, b.type); // the arrows keep going until the pad comes up
            return;
        }
        DeckBinds.run(h, b, () -> h.hideOverlay());
    }
}
