package app.novaos;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/**
 * The water effect on the deck: hit a pad and rings of changing colour spread out over the other pads, like a stone
 * dropped in water, then fade. It shows on the on-screen deck and on the Launchpad's lights. Everything here runs on the
 * main thread.
 */
final class DeckRipple {
    private DeckRipple() {}

    static final String K_ON = "deck_ripple";

    private static final float SPEED = 8f;      // pads per second
    private static final float DURATION = 1.5f; // seconds until the last ring has faded
    private static final float WIDTH = 0.65f;   // how thick a ring is, in pads
    private static final int FRAME_MS = 60;

    private static final class Hit {
        final int idx;
        final long start;
        final float hue;

        Hit(int idx, long start, float hue) {
            this.idx = idx;
            this.start = start;
            this.hue = hue;
        }
    }

    private static final List<Hit> HITS = new ArrayList<>();
    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static float nextHue = 190f;
    private static boolean running;

    /** Set by the open deck screen so it repaints its pads on every frame. */
    static Runnable screen;

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    /** True when ripples are switched on and the battery saver is not asking for calm. */
    static boolean active() {
        return enabled() && !Saver.on();
    }

    static boolean busy() {
        return !HITS.isEmpty();
    }

    /** A pad was hit: start rings from it. Each hit gets a different set of colours. */
    static void hit(int idx) {
        if (!active()) {
            return;
        }
        nextHue = (nextHue + 67f) % 360f;
        HITS.add(new Hit(idx, SystemClock.uptimeMillis(), nextHue));
        if (HITS.size() > 4) {
            HITS.remove(0);
        }
        if (!running) {
            running = true;
            ui.post(TICK);
        }
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.uptimeMillis();
            for (int i = HITS.size() - 1; i >= 0; i--) {
                if ((now - HITS.get(i).start) / 1000f > DURATION) {
                    HITS.remove(i);
                }
            }
            // when the last ring is gone this frame paints the normal colours again
            Runnable s = screen;
            if (s != null) {
                s.run();
            }
            DeckMidi.rippleFrame();
            if (HITS.isEmpty()) {
                running = false;
                return;
            }
            ui.postDelayed(this, FRAME_MS);
        }
    };

    private static float gauss(float d) {
        return (float) Math.exp(-(d * d) / (2f * WIDTH * WIDTH));
    }

    private static int mix(int a, int b, float k) {
        int out = 0;
        for (int shift = 24; shift >= 0; shift -= 8) {
            int ca = (a >>> shift) & 0xFF;
            int cb = (b >>> shift) & 0xFF;
            out |= (Math.round(ca + (cb - ca) * k) & 0xFF) << shift;
        }
        return out;
    }

    /**
     * The colour of pad idx (0 to 63, row by row from the top left) right now: its own colour (base, as ARGB) with any
     * ring that is passing over it. The pad that was hit flashes white for a moment instead.
     */
    static int tint(int idx, int base) {
        if (HITS.isEmpty()) {
            return base;
        }
        long now = SystemClock.uptimeMillis();
        int out = base;
        int row = idx / DeckBinds.N;
        int col = idx % DeckBinds.N;
        for (Hit h : HITS) {
            float t = (now - h.start) / 1000f;
            if (t > DURATION) {
                continue;
            }
            if (idx == h.idx) {
                if (t < 0.18f) {
                    out = 0xFFFFFFFF;
                }
                continue;
            }
            float dist = (float) Math.hypot(row - h.idx / DeckBinds.N, col - h.idx % DeckBinds.N);
            float radius = t * SPEED;
            float fade = 1f - t / DURATION;
            // three rings one behind the other, each in its own colour
            for (int ring = 0; ring < 3; ring++) {
                float r = radius - ring * 2f;
                if (r <= 0f) {
                    continue;
                }
                float k = gauss(dist - r) * (ring == 0 ? 1f : ring == 1 ? 0.7f : 0.45f) * fade;
                if (k < 0.03f) {
                    continue;
                }
                float hue = (h.hue + ring * 110f + dist * 28f) % 360f;
                int vivid = 0xFF000000 | (Color.HSVToColor(new float[] {hue, 0.85f, 1f}) & 0xFFFFFF);
                out = mix(out, vivid, Math.min(1f, k));
            }
        }
        return out;
    }
}
