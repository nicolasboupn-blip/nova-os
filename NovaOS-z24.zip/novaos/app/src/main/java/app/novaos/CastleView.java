package app.novaos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * The wizard's castle on the home screen. A pixel-art picture that is lit at night and sunlit by day, with the rock
 * crumbling into cubes. You upgrade it with coins (see Castle): a water wheel (or lava), a sword and a banner of your
 * country, extra towers, a dragon that grows up, and castle styles such as hell or frozen. The wizard lives inside.
 */
final class CastleView extends View {
    static final int SW = 140;      // sprite size in pixels
    static final int SH = 194;
    private static final int DOOR_X = 56;
    private static final int DOOR_TOP = 108;
    private static final int DOOR_BOTTOM = 117;
    private static final int ROCK_FROM = 124;

    private static final class Cube {
        float x, y, vx, vy, size, life, age;
        int color;
    }

    private final NovaActivity host;
    private final int sc;
    private final Paint p = new Paint();
    private final Rect src = new Rect(0, 0, SW, SH);
    private final Rect dst = new Rect();
    private final Random rnd = new Random();
    private final List<Cube> cubes = new ArrayList<>();
    private final int[] rockX = new int[SW * (SH - ROCK_FROM)];
    private final int[] rockY = new int[SW * (SH - ROCK_FROM)];
    private int rockN;
    private final long born = System.nanoTime();
    private long last = System.nanoTime();
    private float spawnDebt;
    private float dayness;
    private long dayChecked;
    private boolean ok;

    // the picture: originals, the working copies (with upgrades and style baked in) and the blend
    private final int[] origNight = new int[SW * SH];
    private final int[] origDay = new int[SW * SH];
    private final int[] nightPx = new int[SW * SH];
    private final int[] dayPx = new int[SW * SH];
    private final int[] mixPx = new int[SW * SH];
    private final float[] thr = new float[SW * SH];
    private Bitmap mix;
    private int mixLevel = -1;
    private int builtVersion = -1;
    private int builtStage = -1;
    private int builtStyle = -1;

    // life
    private int weather;
    private float flash;
    private float nextFlash = 6f;
    private final float[] dropX = new float[48];
    private final float[] dropY = new float[48];

    // Ember: 0 asleep, 1 awake, 2 flying a loop, 3 flying home, 4 hopping (baby)
    private int dState;
    private float dTimer = 12f + new Random().nextInt(20);
    private float dFly;
    private boolean dFired;
    private boolean dRight = true;
    private float dX, dY;
    private boolean carryPig;
    private boolean pigDropped;
    private String speech;
    private float speechT;
    private float nextSpeech = 60f;
    private float hop;
    private long tickAt;

    CastleView(NovaActivity host) {
        super(host);
        this.host = host;
        int w = host.getResources().getDisplayMetrics().widthPixels;
        sc = Math.max(2, Math.round(w * 0.44f / SW));
        p.setFilterBitmap(false);
        p.setAntiAlias(false);
        Bitmap night = load("castle_night");
        Bitmap day = load("castle_day");
        if (night != null && day != null) {
            night.getPixels(origNight, 0, SW, 0, 0, SW, SH);
            day.getPixels(origDay, 0, SW, 0, 0, SW, SH);
            Random tr = new Random(42);
            for (int i = 0; i < thr.length; i++) {
                thr[i] = tr.nextFloat();
            }
            mix = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888);
            ok = true;
            for (int y = ROCK_FROM; y < SH; y++) {
                for (int x = 0; x < SW; x++) {
                    if (origNight[y * SW + x] >>> 24 > 0) {
                        rockX[rockN] = x;
                        rockY[rockN] = y;
                        rockN++;
                    }
                }
            }
        }
        for (int i = 0; i < dropX.length; i++) {
            dropX[i] = rnd.nextFloat();
            dropY[i] = rnd.nextFloat();
        }
        weather = Prefs.getInt("wx_kind", 0);
    }

    private Bitmap load(String name) {
        int id = getContext().getResources().getIdentifier(name, "drawable", getContext().getPackageName());
        if (id == 0) {
            return null;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeResource(getContext().getResources(), id, o);
    }

    int spriteW() {
        return SW * sc;
    }

    int spriteH() {
        return SH * sc;
    }

    /** Where it goes in the home screen: top right (or top left in left-handed mode), level with the clock. */
    FrameLayout.LayoutParams params() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(spriteW(), spriteH(),
                android.view.Gravity.TOP | (Prefs.getBool("s_lefty", false) ? android.view.Gravity.START
                        : android.view.Gravity.END));
        lp.topMargin = Theme.dp(host, 52);
        lp.rightMargin = Theme.dp(host, 6);
        lp.leftMargin = Theme.dp(host, 6);
        return lp;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        host.castle = this;
        if (WeatherData.hasCity()) {
            new Thread(() -> {
                try {
                    if (WeatherData.load(false)) {
                        int code = WeatherData.code;
                        int kind = code >= 95 ? 3 : (code >= 71 && code <= 77) || code == 85 || code == 86 ? 2
                                : (code >= 51 && code <= 67) || (code >= 80 && code <= 82) ? 1 : 0;
                        Prefs.putInt("wx_kind", kind);
                        weather = kind;
                    }
                } catch (Exception ignored) {
                    // no weather, no problem
                }
            }).start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (host.castle == this) {
            host.castle = null;
        }
        super.onDetachedFromWindow();
    }

    /** 0 at night, 1 in daylight, eased around sunrise and sunset. */
    private float computeDay() {
        Calendar c = Calendar.getInstance();
        float h = c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f;
        int fake = Prefs.getInt("adm_hour", -1);
        if (fake >= 0) {
            h = fake;
        }
        return smooth(5.5f, 8f, h) * (1f - smooth(18f, 20.5f, h));
    }

    private static float smooth(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    /** The door, bottom middle, in the coordinates of the given parent. */
    float[] door(View parent) {
        int[] a = new int[2];
        int[] b = new int[2];
        getLocationOnScreen(a);
        parent.getLocationOnScreen(b);
        float sx = getScaleX();
        return new float[] {a[0] - b[0] + DOOR_X * sc * sx, a[1] - b[1] + DOOR_BOTTOM * sc * sx};
    }

    /** True if a screen touch lands on the castle itself (not the empty air around it). */
    boolean hit(float rawX, float rawY) {
        int[] a = new int[2];
        getLocationOnScreen(a);
        int px = (int) ((rawX - a[0]) / sc);
        int py = (int) ((rawY - a[1]) / sc);
        if (!ok) {
            return false;
        }
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int x = px + dx;
                int y = py + dy;
                if (x >= 0 && y >= 0 && x < SW && y < SH && nightPx[y * SW + x] >>> 24 > 128) {
                    return true;
                }
            }
        }
        return false;
    }

    /** A little burst of cubes at the door, when the wizard goes in or out. */
    void puff() {
        for (int i = 0; i < 22; i++) {
            Cube c = new Cube();
            c.x = (DOOR_X + rnd.nextFloat() * 4f - 2f) * sc;
            c.y = (DOOR_BOTTOM - rnd.nextFloat() * 6f) * sc;
            c.vx = (rnd.nextFloat() - 0.5f) * 90f * sc / 3f;
            c.vy = -rnd.nextFloat() * 70f * sc / 3f;
            c.size = sc * (1 + rnd.nextInt(2));
            c.life = 0.8f + rnd.nextFloat() * 0.8f;
            c.color = rnd.nextBoolean() ? 0xFFFFD84D : Theme.ACCENT;
            cubes.add(c);
        }
    }

    private void spawnCrumb() {
        if (rockN == 0 || cubes.size() > 90) {
            return;
        }
        int i = rnd.nextInt(rockN);
        Cube c = new Cube();
        c.x = rockX[i] * sc;
        c.y = rockY[i] * sc;
        c.vx = (rnd.nextFloat() - 0.4f) * 14f * sc / 3f;
        c.vy = 8f * sc / 3f + rnd.nextFloat() * 22f * sc / 3f;
        c.size = sc * (rnd.nextInt(5) == 0 ? 2 : 1);
        c.life = 2.2f + rnd.nextFloat() * 2.6f;
        if (rnd.nextInt(100) < 28) {
            c.color = Theme.ACCENT;
        } else {
            int[] arr = dayness > 0.5f ? dayPx : nightPx;
            c.color = arr[rockY[i] * SW + rockX[i]] | 0xFF000000;
        }
        cubes.add(c);
    }

    // ------------------------------------------------------------------ building the picture

    private static void put(int[] a, int x, int y, int col) {
        if (x >= 0 && y >= 0 && x < SW && y < SH) {
            a[y * SW + x] = col | 0xFF000000;
        }
    }

    private static void box(int[] a, int x, int y, int w, int h, int col) {
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                put(a, x + i, y + j, col);
            }
        }
    }

    private static int shade(int col, int d) {
        int r = Math.max(0, Math.min(255, ((col >> 16) & 255) + d));
        int g = Math.max(0, Math.min(255, ((col >> 8) & 255) + d));
        int b = Math.max(0, Math.min(255, (col & 255) + d));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int sample(int[] a, int x, int y, int fallback) {
        int c = a[y * SW + x];
        return c >>> 24 > 200 ? c : fallback;
    }

    private void buildSprite() {
        int stage = Castle.stage();
        int style = Castle.style();
        System.arraycopy(origNight, 0, nightPx, 0, nightPx.length);
        System.arraycopy(origDay, 0, dayPx, 0, dayPx.length);
        if (stage >= 1) {
            drawTrough(nightPx, false);
            drawTrough(dayPx, true);
        }
        if (stage >= 3) {
            drawSword(nightPx, false);
            drawSword(dayPx, true);
        }
        if (stage >= 4) {
            drawTower(nightPx, false, stage >= 10);
            drawTower(dayPx, true, stage >= 10);
        }
        if (style != 0) {
            grade(style);
        }
        builtVersion = Castle.version;
        builtStage = stage;
        builtStyle = style;
        mixLevel = -1;
    }

    /** The wooden channel the little waterfall (or lava fall) comes out of. */
    private void drawTrough(int[] a, boolean day) {
        int wood = day ? 0xFFA9743A : 0xFF4A2F18;
        box(a, 91, 108, 10, 3, wood);
        box(a, 91, 111, 2, 8, wood);
        box(a, 99, 111, 2, 8, wood);
        box(a, 93, 111, 6, 1, shade(wood, -20));
    }

    private void drawSword(int[] a, boolean day) {
        int blade = day ? 0xFFE0E6EF : 0xFFB8C0CC;
        int edge = 0xFFFFFFFF;
        int gold = day ? 0xFFF0B83A : 0xFFC99520;
        int grip = day ? 0xFF8B5A2B : 0xFF5A3A1A;
        box(a, 44, 101, 2, 16, blade);
        box(a, 44, 101, 1, 16, edge);
        box(a, 41, 99, 8, 2, gold);
        box(a, 44, 96, 2, 3, grip);
        box(a, 43, 94, 4, 2, gold);
        box(a, 43, 117, 4, 1, shade(blade, -60));
    }

    private static int hash(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= h >>> 13;
        return (h * 1274126177 >>> 8) & 0xFFFF;
    }

    private void drawTower(int[] a, boolean day, boolean grand) {
        int stone = day ? 0xFFBDB2A0 : 0xFF625C66;
        int rock = day ? 0xFF4A6F94 : 0xFF1E3050;
        // a rocky mound under the new tower, joined to the castle's own rock
        for (int y = 112; y <= 152; y++) {
            int dy = Math.max(0, y - 120);
            int right = 141 - (int) (dy * dy / 11f) - hash(y, 3) % 3;
            int left = 110 + (int) (dy * 0.5f);
            for (int x = left; x <= right && x < SW; x++) {
                int n = hash(x, y) % 7 * 4 - 10;
                if (x > right - 3 && hash(x, y + 9) % 3 == 0) {
                    continue;   // ragged edge
                }
                int col = shade(rock, n + (y < 119 ? 12 : 0) - (x - left) / 6);
                if (a[y * SW + x] >>> 24 < 200) {
                    put(a, x, y, col);
                }
            }
        }
        // a stone wall joining the tower to the castle
        for (int y = 100; y <= 128; y++) {
            for (int x = 114; x <= 122; x++) {
                if (a[y * SW + x] >>> 24 < 200) {
                    put(a, x, y, shade(stone, -34 + ((x + y) % 4) * 3));
                }
            }
        }
        int roof = sample(a, 74, 14, day ? 0xFF3A6D96 : 0xFF0F284A);
        int x0 = grand ? 118 : 122;
        int x1 = grand ? 138 : 137;
        int w = x1 - x0 + 1;
        int top = grand ? 46 : 80;
        int bottom = 138;
        for (int y = top; y <= bottom; y++) {
            boolean brickRow = (y - top) % 5 == 0;
            for (int x = x0; x <= x1; x++) {
                float k = (x - x0) / (float) (w - 1);          // 0 left .. 1 right: a round tower, lit from the left
                int d = (int) (22 - 52 * k);
                if (brickRow) {
                    d -= 14;
                } else if (((x + (y - top) / 5 * 3) % 6) == 0) {
                    d -= 9;
                }
                int col = shade(stone, d);
                if (y >= 117 && hash(x, y) % 12 < (y - 116) * 1.2f) {
                    col = shade(rock, hash(y, x) % 3 * 6);        // the tower grows out of the rock
                }
                put(a, x, y, col);
            }
        }
        if (grand) {
            for (int x = x0; x <= x1 - 1; x += 5) {   // merlons
                box(a, x, top - 4, 3, 4, shade(stone, x < x0 + 8 ? 14 : -10));
            }
            box(a, x0 - 1, top - 1, w + 2, 2, shade(stone, -34));   // the ledge
            box(a, x0 - 1, top + 1, w + 2, 1, shade(stone, -50));
        } else {
            int h = 20;
            for (int i = 0; i < h; i++) {
                int half = (int) (w / 2f * (1f - i / (float) h)) + 1;
                int cx = (x0 + x1) / 2;
                for (int x = cx - half; x <= cx + half; x++) {
                    float k = (x - (cx - half)) / (float) Math.max(1, half * 2);
                    put(a, x, top - 1 - i, shade(roof, (int) (14 - 34 * k)));
                }
            }
            box(a, x0 - 1, top - 1, w + 2, 2, shade(roof, -20));
        }
        // narrow windows, warm at night
        int lit = day ? 0xFFB0CBE6 : 0xFFE6A23C;
        int count = grand ? 5 : 3;
        int step = grand ? 16 : 14;
        int first = top + 10;
        for (int i = 0; i < count; i++) {
            int wy = first + i * step;
            int wx = (x0 + x1) / 2 - 1;
            box(a, wx, wy, 3, 6, 0xFF1A1424);
            box(a, wx + 1, wy + 1, 1, 4, lit);
        }
    }

    /** Re-colours the whole castle for a style. */
    private void grade(int style) {
        for (int i = 0; i < nightPx.length; i++) {
            boolean windowN = false;
            int c = origNight[i];
            if (c >>> 24 > 0) {
                int r = (c >> 16) & 255;
                int b = c & 255;
                windowN = r > 115 && r - b > 46;
            }
            nightPx[i] = gradePx(nightPx[i], style, false, windowN);
            dayPx[i] = gradePx(dayPx[i], style, true, windowN);
        }
    }

    private static int clamp(float v) {
        return v < 0 ? 0 : v > 255 ? 255 : (int) v;
    }

    private static int gradePx(int c, int style, boolean day, boolean window) {
        if (c >>> 24 == 0) {
            return c;
        }
        float r = (c >> 16) & 255;
        float g = (c >> 8) & 255;
        float b = c & 255;
        switch (style) {
            case 1: // hell
                if (window) {
                    return 0xFFFF5A14;
                }
                r = r * (day ? 1.15f : 1.35f) + 28;
                g = g * 0.55f;
                b = b * 0.45f;
                break;
            case 2: // frozen
                if (window) {
                    return 0xFFB8EEFF;
                }
                r = r * 0.85f + (day ? 45 : 18);
                g = g * 1.0f + (day ? 60 : 36);
                b = b * 1.1f + (day ? 80 : 56);
                break;
            case 3: // haunted
                if (window) {
                    return 0xFF6EFF8C;
                }
                r = r * 0.7f;
                g = g * 1.15f + 16;
                b = b * 0.8f + 10;
                break;
            case 4: // royal gold
                if (window) {
                    return 0xFFFFF1A8;
                }
                r = r * 1.2f + 44;
                g = g * 1.05f + 28;
                b = b * 0.55f;
                break;
            case 5: // cyber
                if (window) {
                    return 0xFFFF3CC8;
                }
                {
                    float l = (r + g + b) / 3f;
                    r = l * 0.55f + 12;
                    g = l * 0.95f + 14;
                    b = l * 1.35f + 36;
                }
                break;
            default: // sakura
                if (window) {
                    return 0xFFFFB0C8;
                }
                r = r * 1.05f + 34;
                g = g * 0.9f + 14;
                b = b * 1.0f + 26;
                break;
        }
        return 0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
    }

    // ------------------------------------------------------------------ live decorations

    private void drawUpgrades(Canvas c, float t, boolean eco) {
        int stage = Castle.stage();
        p.setStyle(Paint.Style.FILL);
        if (stage >= 1) {
            drawWheel(c, t, eco);
        }
        if (stage >= 3) {
            drawBanner(c, t);
        }
        if (stage >= 10) {
            // torches on the grand tower
            for (int i = 0; i < 2; i++) {
                float fx = (i == 0 ? 118.5f : 137f) * sc;
                float fy = 41 * sc;
                float f = eco ? 0.5f : 0.5f + 0.5f * (float) Math.sin(t * 9f + i * 2f);
                p.setColor(0xFFFF7A1A);
                c.drawRect(fx, fy - sc * (2 + f * 2), fx + sc * 1.5f, fy, p);
                p.setColor(0xFFFFE070);
                c.drawRect(fx + sc * 0.3f, fy - sc * (1 + f), fx + sc * 1.2f, fy, p);
            }
        }
    }

    private void drawWheel(Canvas c, float t, boolean eco) {
        boolean lava = Castle.lava();
        float cx = 96f * sc;
        float cy = 131f * sc;
        float R = 8f * sc;
        if (lava) {
            p.setColor(0x33FF5A1A);
            c.drawCircle(cx, cy, R * 2.1f, p);
        }
        // the fall
        int a = lava ? 0xFFFF5A1A : 0xFF4AA3FF;
        int b = lava ? 0xFFFFC040 : 0xFFD0ECFF;
        int phase = eco ? 0 : (int) (t * 10f);
        for (int r = 0; r < 12; r++) {
            p.setColor((r + phase) % 3 == 0 ? b : a);
            c.drawRect(94.5f * sc, (111 + r) * sc, 97.5f * sc, (112 + r) * sc, p);
        }
        // the wheel
        float ang = eco ? 0.3f : t * (lava ? 0.55f : 0.95f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sc * 1.4f);
        p.setColor(lava ? 0xFF3A2A28 : 0xFF7A4A22);
        c.drawCircle(cx, cy, R, p);
        p.setStrokeWidth(sc * 1.0f);
        for (int i = 0; i < 8; i++) {
            double an = ang + i * Math.PI / 4;
            float ex = cx + (float) Math.cos(an) * R;
            float ey = cy + (float) Math.sin(an) * R;
            p.setColor(lava ? 0xFF4A332E : 0xFF9A6A32);
            c.drawLine(cx, cy, ex, ey, p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 8; i++) {
            double an = ang + i * Math.PI / 4;
            float ex = cx + (float) Math.cos(an) * R;
            float ey = cy + (float) Math.sin(an) * R;
            p.setColor(lava ? 0xFFFF8A2A : 0xFFB5834A);
            c.drawRect(ex - sc, ey - sc, ex + sc, ey + sc, p);
        }
        p.setColor(0xFF2A1A10);
        c.drawCircle(cx, cy, sc * 1.6f, p);
        // drips
        if (!eco && rnd.nextInt(100) < 35 && cubes.size() < 90) {
            Cube q = new Cube();
            q.x = cx + (rnd.nextFloat() - 0.5f) * R * 1.6f;
            q.y = cy + R * 0.8f;
            q.vx = (rnd.nextFloat() - 0.5f) * 8f * sc / 3f;
            q.vy = lava ? -12f * sc / 3f - rnd.nextFloat() * 14f * sc / 3f : 30f * sc / 3f;
            q.size = sc;
            q.life = 0.9f + rnd.nextFloat() * 0.5f;
            q.color = lava ? (rnd.nextBoolean() ? 0xFFFFA030 : 0xFFFF5A1A) : (rnd.nextBoolean() ? 0xFFBFE4FF : 0xFF4AA3FF);
            cubes.add(q);
        }
    }

    /** The weathered banner of your country, hanging by the door and swaying a little. */
    private void drawBanner(Canvas c, float t) {
        int idx = Castle.flag();
        int c1 = Prefs.getInt("cs_fc1", 0xFFC0392B);
        int c2 = Prefs.getInt("cs_fc2", 0xFFF1C40F);
        int c3 = Prefs.getInt("cs_fc3", 0xFF2980B9);
        float bx = 62f;
        float by = 100f;
        int bw = 10;
        int bh = 16;
        float lum = 0.62f + 0.3f * dayness;
        p.setStyle(Paint.Style.FILL);
        // the bar it hangs from
        p.setColor(0xFF5A3A1A);
        c.drawRect((bx - 1) * sc, (by - 1.5f) * sc, (bx + bw + 1) * sc, by * sc, p);
        p.setColor(0xFFD9A524);
        c.drawRect((bx - 1.5f) * sc, (by - 2f) * sc, (bx - 0.5f) * sc, (by - 0.5f) * sc, p);
        c.drawRect((bx + bw + 0.5f) * sc, (by - 2f) * sc, (bx + bw + 1.5f) * sc, (by - 0.5f) * sc, p);
        for (int ry = 0; ry < bh; ry++) {
            float sway = (float) Math.sin(t * 1.8f + ry * 0.35f) * 0.45f * (ry / (float) bh);
            for (int cx = 0; cx < bw; cx++) {
                if (ry >= 12 && Math.abs(cx - (bw - 1) / 2f) < (ry - 11) * 1.2f) {
                    continue; // swallowtail notch
                }
                int h = (cx * 73856093) ^ (ry * 19349663);
                h = (h >>> 3) & 1023;
                if (h % 29 == 0 && ry > 4) {
                    continue; // a hole, it is old
                }
                int col = Castle.flagColor(idx, cx / (float) (bw - 1), ry / (float) (bh - 1), c1, c2, c3);
                float k = lum * (h % 7 == 0 ? 0.72f : 1f);
                int r = (int) (((col >> 16) & 255) * k * 0.9f + 22);
                int g = (int) (((col >> 8) & 255) * k * 0.9f + 17);
                int b = (int) ((col & 255) * k * 0.88f + 11);
                p.setColor(0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b));
                float x = (bx + cx + sway) * sc;
                float y = (by + ry) * sc;
                c.drawRect(x, y, x + sc, y + sc, p);
            }
        }
    }

    private int styleTick;

    private void drawStyleLife(Canvas c, float dt, float t, boolean eco) {
        int style = Castle.style();
        if (style == 0 || eco) {
            return;
        }
        float W = SW * sc;
        float H = SH * sc;
        p.setStyle(Paint.Style.FILL);
        switch (style) {
            case 1: { // hell: flames on the roofs and a glow of lava below
                int[][] pts = {{27, 74}, {74, 12}, {95, 46}, {120, 86}, {12, 98}, {60, 52}, {104, 70}};
                for (int i = 0; i < pts.length; i++) {
                    float fx = pts[i][0] * sc;
                    float fy = pts[i][1] * sc;
                    float f = 0.5f + 0.5f * (float) Math.sin(t * 8f + i * 1.7f);
                    p.setColor(0xCCFF4A1A);
                    c.drawRect(fx - sc, fy - sc * (3 + 3 * f), fx + sc * 2, fy, p);
                    p.setColor(0xDDFF9A2A);
                    c.drawRect(fx, fy - sc * (2 + 2 * f), fx + sc, fy, p);
                    p.setColor(0xCCFFE070);
                    c.drawRect(fx, fy - sc * (1 + f), fx + sc * 0.6f, fy, p);
                }
                p.setColor(0x22FF3A10);
                c.drawRect(0, H * 0.55f, W, H * 0.78f, p);
                if (rnd.nextInt(100) < 40 && cubes.size() < 90) {
                    Cube q = new Cube();
                    q.x = rnd.nextFloat() * W;
                    q.y = H * 0.62f;
                    q.vx = (rnd.nextFloat() - 0.5f) * 10f * sc / 3f;
                    q.vy = -(18f + rnd.nextFloat() * 24f) * sc / 3f;
                    q.size = sc;
                    q.life = 1.4f;
                    q.color = rnd.nextBoolean() ? 0xFFFF7A1A : 0xFFFFD84D;
                    cubes.add(q);
                }
                break;
            }
            case 2: { // frozen: icicles and drifting snow
                p.setColor(0xFFDFF6FF);
                int[] xs = {12, 20, 30, 41, 62, 70, 82, 92, 104, 112, 124, 132};
                for (int i = 0; i < xs.length; i++) {
                    int len = 2 + (i * 7) % 4;
                    float x = xs[i] * sc;
                    float y = (113 + (i % 3) * 2) * sc;
                    c.drawRect(x, y, x + sc, y + len * sc, p);
                    c.drawRect(x, y + len * sc, x + sc * 0.5f, y + (len + 1) * sc, p);
                }
                break;
            }
            case 3: { // haunted: mist and ghosts
                for (int i = 0; i < 4; i++) {
                    float mx = ((t * 6f + i * 40f) % (SW + 40)) - 20f;
                    p.setColor(0x2290FFB0);
                    c.drawRect(mx * sc, (118 + i * 6) * sc, (mx + 38) * sc, (121 + i * 6) * sc, p);
                }
                for (int i = 0; i < 2; i++) {
                    float gx = (30 + i * 60 + (float) Math.sin(t * 0.8f + i * 3f) * 18f) * sc;
                    float gy = (70 + (float) Math.sin(t * 1.3f + i) * 8f) * sc;
                    p.setColor(0x99DFFFE8);
                    c.drawRect(gx, gy, gx + sc * 5, gy + sc * 6, p);
                    c.drawRect(gx + sc, gy - sc, gx + sc * 4, gy, p);
                    p.setColor(0xCC1A3A2A);
                    c.drawRect(gx + sc, gy + sc, gx + sc * 2, gy + sc * 3, p);
                    c.drawRect(gx + sc * 3, gy + sc, gx + sc * 4, gy + sc * 3, p);
                }
                break;
            }
            case 4: { // royal gold: sparkles
                for (int i = 0; i < 9; i++) {
                    float k = (t * 0.7f + i * 0.37f) % 1f;
                    float sx = (20 + (i * 53) % 100) * sc;
                    float sy = (30 + (i * 37) % 90) * sc;
                    float a = (float) Math.sin(k * Math.PI);
                    p.setColor(((int) (230 * a) << 24) | 0xFFF0A0);
                    c.drawRect(sx - sc, sy, sx + sc * 2, sy + sc, p);
                    c.drawRect(sx, sy - sc, sx + sc, sy + sc * 2, p);
                }
                break;
            }
            case 5: { // cyber: a scanline sweeps down
                float y = ((t * 18f) % SH) * sc;
                p.setColor(0x3340FFFF);
                c.drawRect(0, y, W, y + sc * 2, p);
                p.setColor(0x1AFF40D0);
                c.drawRect(0, (y + H * 0.5f) % H, W, (y + H * 0.5f) % H + sc, p);
                break;
            }
            default: { // sakura: petals
                styleTick++;
                for (int i = 0; i < 14; i++) {
                    float k = (t * 0.12f + i * 0.071f) % 1f;
                    float px = ((i * 31) % 100 + (float) Math.sin(t + i) * 6f + 20f) * sc;
                    float py = k * H * 0.85f;
                    p.setColor(0xCCFFB7D0);
                    c.drawRect(px, py, px + sc * 1.5f, py + sc, p);
                }
                break;
            }
        }
    }

    private void drawSeason(Canvas c, float t, boolean eco) {
        if (eco || !Prefs.getBool("s_seasons", true)) {
            return;
        }
        int month = Calendar.getInstance().get(Calendar.MONTH);
        p.setStyle(Paint.Style.FILL);
        if (month == Calendar.OCTOBER) {   // pumpkins on the ledge
            int[] xs = {14, 50, 84, 116};
            for (int i = 0; i < xs.length; i++) {
                float x = xs[i] * sc;
                float y = (121 + (i % 2) * 3) * sc;
                p.setColor(0xFFE8731A);
                c.drawRect(x, y, x + sc * 5, y + sc * 4, p);
                p.setColor(0xFF3A7A22);
                c.drawRect(x + sc * 2, y - sc, x + sc * 3, y, p);
                float glow = 0.6f + 0.4f * (float) Math.sin(t * 3f + i);
                p.setColor(((int) (255 * glow) << 24) | 0xFFE070);
                c.drawRect(x + sc, y + sc, x + sc * 2, y + sc * 2, p);
                c.drawRect(x + sc * 3, y + sc, x + sc * 4, y + sc * 2, p);
            }
        } else if (month == Calendar.DECEMBER) {   // string lights
            int[] cols = {0xFFFF4A4A, 0xFF4AFF7A, 0xFFFFE04A, 0xFF4AB0FF};
            for (int i = 0; i < 24; i++) {
                float x = (8 + i * 5) * sc;
                float y = (120 + (float) Math.sin(i * 0.8f) * 2f) * sc;
                boolean on = ((int) (t * 2f) + i) % 3 != 0;
                p.setColor((on ? 0xFF000000 : 0x66000000) | (cols[i % 4] & 0xFFFFFF));
                c.drawRect(x, y, x + sc * 1.5f, y + sc * 1.5f, p);
            }
        } else if (month == Calendar.FEBRUARY) {   // hearts
            for (int i = 0; i < 5; i++) {
                float k = (t * 0.1f + i * 0.2f) % 1f;
                float x = (30 + i * 20 + (float) Math.sin(t + i) * 4f) * sc;
                float y = (1f - k) * SH * 0.7f * sc;
                p.setColor(((int) (200 * (1f - k)) << 24) | 0xFF4A7A);
                c.drawRect(x, y, x + sc * 3, y + sc * 2, p);
                c.drawRect(x + sc * 0.5f, y + sc * 2, x + sc * 2.5f, y + sc * 3, p);
            }
        }
    }

    private void drawLife(Canvas c, float dt, float t) {
        float W = SW * sc;
        float H = SH * sc;
        p.setStyle(Paint.Style.FILL);
        float darkness = 1f - dayness;
        if (darkness > 0.3f) {
            for (int i = 0; i < 3; i++) {
                float ph = i * 2.1f;
                float bx = W * (0.5f + 0.44f * (float) Math.cos(t * 0.5f + ph));
                float by = H * (0.16f + 0.10f * (float) Math.sin(t * 0.9f + ph * 1.7f)) + i * sc * 6;
                boolean up = (int) (t * 7f + i) % 2 == 0;
                p.setColor(((int) (230 * darkness) << 24) | 0x140C1E);
                c.drawRect(bx - sc, by, bx + sc, by + sc * 1.5f, p);
                c.drawRect(bx - 4 * sc, by + (up ? -sc : sc * 0.5f), bx - sc, by + (up ? 0.5f * sc : 1.5f * sc), p);
                c.drawRect(bx + sc, by + (up ? -sc : sc * 0.5f), bx + 4 * sc, by + (up ? 0.5f * sc : 1.5f * sc), p);
            }
        }
        int wx = weather;
        int forced = Prefs.getInt("adm_wx", -1);
        if (forced >= 0) {
            wx = forced;
        }
        if (Castle.style() == 2 && wx == 0) {
            wx = 2;
        }
        if (wx > 0) {
            boolean snow = wx == 2;
            for (int i = 0; i < dropX.length; i++) {
                dropY[i] += dt * (snow ? 0.12f : 0.9f);
                dropX[i] += dt * (snow ? 0.03f * (float) Math.sin(t + i) : -0.12f);
                if (dropY[i] > 1f) {
                    dropY[i] -= 1f;
                    dropX[i] = rnd.nextFloat();
                }
                if (dropX[i] < 0f) {
                    dropX[i] += 1f;
                }
                float px = dropX[i] * W;
                float py = dropY[i] * H * 0.8f;
                if (snow) {
                    p.setColor(0xDDFFFFFF);
                    c.drawRect(px, py, px + sc, py + sc, p);
                } else {
                    p.setColor(0x99A8C8FF);
                    c.drawRect(px, py, px + sc * 0.6f, py + sc * 3f, p);
                }
            }
            if (wx == 3) {
                nextFlash -= dt;
                if (nextFlash <= 0f) {
                    flash = 0.35f;
                    nextFlash = 6f + rnd.nextInt(8);
                }
                if (flash > 0f) {
                    flash -= dt;
                    p.setColor(((int) (Math.max(0f, flash) * 500) << 24) | 0xFFFFFF);
                    c.drawRect(0, 0, W, H * 0.7f, p);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Ember the dragon

    private static final String[] LINES = {
        "Fear me, small wizard.", "I smell gold... and pork.", "Do NOT call me lizard.",
        "My tower, my rules.", "Pigs. Bring pigs.", "I am very big now.", "*yawn* I was not sleeping.",
        "Poke me again. I dare you.", "Gold. More gold.", "Nice castle. Mine now."};

    private int perchX() {
        return Castle.has(10) ? 128 : 27;
    }

    private int perchY() {
        return Castle.has(10) ? 45 : 74;
    }

    private void dr(Canvas c, float x, float y, float u, int ux, int uy, int w, int h, int col, boolean right) {
        float x0 = right ? x + ux * u : x - (ux + w) * u;
        p.setColor(col);
        c.drawRect(x0, y + uy * u, x0 + w * u, y + (uy + h) * u, p);
    }

    private int dragonBody(float t) {
        int ci = Castle.dragonColor();
        if (ci == 7) {
            float[] hsv = {(t * 60f) % 360f, 0.6f, 0.9f};
            return Color.HSVToColor(hsv);
        }
        return Castle.DRAGON_RGB[ci];
    }

    /** A dragon, side view, feet at (x, y). pose: 0 asleep, 1 awake, 2 flying. */
    private void paintDragon(Canvas c, float x, float y, float u, boolean right, int pose, int flap, int tail,
            float t) {
        int body = dragonBody(t);
        int belly = Castle.dragonColor() == 6 ? 0xFFC9B8E0 : 0xFFE8C46A;
        int wing = (Theme.ACCENT & 0x00FFFFFF) | 0xE6000000;
        p.setStyle(Paint.Style.FILL);
        if (pose == 2) {
            dr(c, x, y, u, -5, -4, 9, 3, body, right);
            dr(c, x, y, u, -3, -2, 6, 1, belly, right);
            dr(c, x, y, u, -10, -3 + tail, 5, 1, body, right);
            dr(c, x, y, u, -12, -3 + tail, 2, 1, wing, right);
            dr(c, x, y, u, 4, -6, 4, 3, body, right);
            dr(c, x, y, u, 8, -5, 2, 2, body, right);
            dr(c, x, y, u, 5, -8, 1, 2, 0xFFE8E0D0, right);
            dr(c, x, y, u, 7, -6, 1, 1, 0xFFFF3A2A, right);
            if (flap == 0) {
                dr(c, x, y, u, -7, -8, 3, 4, wing, right);
                dr(c, x, y, u, -5, -11, 5, 3, wing, right);
                dr(c, x, y, u, -1, -12, 4, 2, wing, right);
            } else {
                dr(c, x, y, u, -6, -2, 8, 2, wing, right);
                dr(c, x, y, u, -9, 0, 5, 2, wing, right);
            }
            return;
        }
        dr(c, x, y, u, -5, -5, 9, 4, body, right);
        dr(c, x, y, u, -3, -2, 6, 1, belly, right);
        dr(c, x, y, u, -3, -1, 2, 1, body, right);
        dr(c, x, y, u, 1, -1, 2, 1, body, right);
        dr(c, x, y, u, -9, -3, 4, 1, body, right);
        dr(c, x, y, u, -11, -2 + tail, 2, 1, body, right);
        dr(c, x, y, u, -12, -1 + tail, 1, 2, wing, right);
        if (pose == 0) {
            dr(c, x, y, u, -4, -7, 6, 2, wing, right);
            dr(c, x, y, u, 3, -5, 4, 3, body, right);
            dr(c, x, y, u, 7, -4, 2, 2, body, right);
            dr(c, x, y, u, 4, -6, 1, 1, 0xFFE8E0D0, right);
            dr(c, x, y, u, 5, -4, 2, 1, 0xFF1A1030, right);
        } else {
            dr(c, x, y, u, -4, -9, 6, 4, wing, right);
            dr(c, x, y, u, -4, -10, 1, 1, wing, right);
            dr(c, x, y, u, 3, -8, 2, 4, body, right);
            dr(c, x, y, u, 4, -10, 4, 3, body, right);
            dr(c, x, y, u, 8, -9, 2, 2, body, right);
            dr(c, x, y, u, 4, -12, 1, 2, 0xFFE8E0D0, right);
            dr(c, x, y, u, 6, -12, 1, 2, 0xFFE8E0D0, right);
            dr(c, x, y, u, 6, -9, 1, 1, 0xFFFF3A2A, right);
        }
    }

    /** Fire from stage 10, smoke before that, a few sparks for babies. */
    private void breathe(float x, float y, float u, boolean right) {
        int stage = Castle.stage();
        int[] fire = {0xFFFF8A2A, 0xFFFFD84D, 0xFFFF4A2A, Theme.ACCENT};
        int[] smoke = {0xFF9A9AA6, 0xFF6E6E7A, 0xFFC4C4CE};
        int[] spark = {0xFFFFD84D, 0xFFFFFFFF};
        int n = stage >= 10 ? 26 : stage >= 9 ? 16 : 6;
        for (int i = 0; i < n; i++) {
            Cube q = new Cube();
            q.x = x + (right ? 10 : -10) * u;
            q.y = y - 8 * u;
            q.vx = (right ? 1 : -1) * (40f + rnd.nextFloat() * 90f) * sc / 3f * (stage >= 10 ? 1f : 0.5f);
            q.vy = (rnd.nextFloat() - (stage >= 10 ? 0.6f : 1f)) * 36f * sc / 3f;
            q.size = sc * (1 + rnd.nextInt(2));
            q.life = 0.45f + rnd.nextFloat() * 0.5f;
            int[] pal = stage >= 10 ? fire : stage >= 9 ? smoke : spark;
            q.color = pal[rnd.nextInt(pal.length)];
            cubes.add(q);
        }
        if (stage >= 10) {
            Sfx.play(Sfx.LOSE);
        }
    }

    private void say(String s) {
        speech = s;
        speechT = 4.5f;
    }

    private void drawDragon(Canvas c, float dt, float t, boolean eco) {
        float size = Castle.dragonSize();
        if (size <= 0f) {
            return;
        }
        int stage = Castle.stage();
        float u = sc * 1.25f * size;
        float px = perchX() * sc;
        float py = perchY() * sc;
        boolean away = Castle.awayMinutes() > 0;
        boolean grown = stage >= 9;
        int tail = (int) (t * 2f) % 2;
        if (eco) {
            dState = 0;
        }
        if (away) {
            return;
        }
        float W = SW * sc;
        float H = SH * sc;
        hop = 0f;
        switch (dState) {
            case 0:
                dX = px;
                dY = py;
                dRight = true;
                if (!eco) {
                    dTimer -= dt;
                    if (dTimer <= 0f) {
                        dState = 1;
                        dTimer = 5f + rnd.nextInt(4);
                        dFired = false;
                    }
                }
                break;
            case 1:
                dX = px;
                dY = py;
                dTimer -= dt;
                if (!dFired && dTimer < 3f && rnd.nextInt(3) != 0) {
                    dFired = true;
                    breathe(dX, dY, u, true);
                }
                if (!grown && rnd.nextInt(40) == 0) {
                    hop = 1f; // babies bounce
                }
                if (stage >= 10 && nextSpeech <= 0f && speech == null) {
                    say(LINES[rnd.nextInt(LINES.length)]);
                    nextSpeech = 90f + rnd.nextInt(110);
                }
                if (dTimer <= 0f) {
                    if (grown && rnd.nextInt(10) < 6) {
                        dState = 2;
                        dFly = 0f;
                        dFired = false;
                        carryPig = false;
                    } else {
                        dState = 0;
                        dTimer = 25f + rnd.nextInt(40);
                    }
                }
                break;
            case 2:
            case 3: {
                dFly += dt / (dState == 3 ? 5f : 10f);
                float k = dFly;
                if (k >= 1f) {
                    dState = 0;
                    dTimer = 35f + rnd.nextInt(50);
                    dX = px;
                    dY = py;
                    carryPig = false;
                    break;
                }
                if (dState == 2) {
                    float amp = W * (Castle.has(10) ? -0.62f : 0.62f);
                    dX = px + amp * (1f - (float) Math.cos(2 * Math.PI * k)) / 2f;
                    dY = py - (float) Math.sin(Math.PI * k) * H * 0.20f + (float) Math.sin(k * 40f) * sc * 1.5f;
                    dRight = (amp > 0) == (k < 0.5f);
                    if (k > 0.18f && k < 0.2f && !dFired) {
                        dFired = true;
                        breathe(dX, dY, u, dRight);
                    }
                    if (k > 0.3f) {
                        dFired = false;
                    }
                    if (carryPig && !pigDropped && k > 0.45f) {
                        pigDropped = true;
                        carryPig = false;
                        host.dropPig();
                    }
                } else {
                    // coming home from far away
                    dX = W + 12 * u + (px - W - 12 * u) * k;
                    dY = py - H * 0.18f * (1f - k) + (float) Math.sin(k * 30f) * sc;
                    dRight = false;
                }
                break;
            }
            default:
                dState = 0;
                break;
        }
        int pose = dState == 0 ? 0 : dState == 1 ? 1 : 2;
        int flap = (int) (t * 6f) % 2;
        float yy = dY - hop * sc * 3f;
        paintDragon(c, dX, yy, u, dRight, pose, flap, tail, t);
        if (carryPig) {
            p.setColor(0xFFE8A07A);
            c.drawRect(dX - 2 * u, yy + 0.5f * u, dX + 3 * u, yy + 2.5f * u, p);
            p.setColor(0xFFB5603A);
            c.drawRect(dX - 2 * u, yy + 0.5f * u, dX + 3 * u, yy + 1.2f * u, p);
        }
        if (dState == 0 && !eco && (int) (t * 0.6f) % 2 == 0) {
            p.setColor(0xCCB9C8FF);
            p.setTextSize(sc * 5f);
            c.drawText("z", dX + 8 * u, dY - 9 * u - (t % 3) * sc * 2f, p);
        }
        // what the dragon says
        if (speech != null) {
            speechT -= dt;
            if (speechT <= 0f) {
                speech = null;
            } else {
                p.setTextSize(sc * 4.2f);
                p.setTypeface(Theme.MONO);
                float tw = p.measureText(speech);
                float bw = tw + sc * 6;
                float bh = sc * 8;
                float bx = Math.max(sc * 2, Math.min(W - bw - sc * 2, dX - bw - 4 * u));
                float by = Math.max(sc * 2, dY - 16 * u);
                p.setColor(0xF2140F26);
                c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), sc * 2, sc * 2, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(sc * 0.6f);
                p.setColor(Theme.ACCENT);
                c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), sc * 2, sc * 2, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Theme.TEXT);
                c.drawText(speech, bx + sc * 3, by + sc * 5.4f, p);
            }
        }
        nextSpeech -= dt;
    }

    private String awayText() {
        int m = Castle.awayMinutes();
        return m >= 1440 ? (m / 1440) + "d " + ((m % 1440) / 60) + "h" : (m / 60) + "h " + (m % 60) + "m";
    }

    /** True if a screen touch lands on the dragon (or his empty perch). Wakes him and makes him roar. */
    boolean pokeDragon(float rawX, float rawY) {
        float size = Castle.dragonSize();
        if (!Prefs.castleLife() || size <= 0f) {
            return false;
        }
        int[] a = new int[2];
        getLocationOnScreen(a);
        float x = rawX - a[0];
        float y = rawY - a[1];
        float u = sc * 1.25f * size;
        if (Castle.awayMinutes() > 0) {
            if (Math.abs(x - perchX() * sc) < 14 * sc && Math.abs(y - perchY() * sc) < 16 * sc) {
                host.wizardSay("Ember is away exploring. Back in " + awayText() + ".");
                return true;
            }
            return false;
        }
        if (Math.abs(x - dX) > 14 * u || y < dY - 14 * u || y > dY + 2 * u) {
            return false;
        }
        if (Saver.on()) {
            host.wizardSay("Shh, Ember is asleep. Battery saver keeps him in bed.");
            return true;
        }
        if (dState == 0) {
            dState = 1;
            dTimer = 5f;
        }
        dFired = true;
        breathe(dX, dY, u, dRight);
        host.buzz(40);
        host.tip("dragon");
        Quests.event(host, "dragon");
        if (Castle.has(10)) {
            say(LINES[rnd.nextInt(LINES.length)]);
        } else if (rnd.nextInt(2) == 0) {
            host.wizardSay(Castle.stage() < 9 ? "He's just a baby! Be gentle." : "ROAR! That's Ember. He bites. Sometimes.");
        }
        return true;
    }

    /** Admin and the dragon menu: make him do something now. */
    void dragonDo(String what) {
        float u = sc * 1.25f * Math.max(0.5f, Castle.dragonSize());
        switch (what) {
            case "wake":
                dState = 1;
                dTimer = 8f;
                break;
            case "sleep":
                dState = 0;
                dTimer = 60f;
                break;
            case "fly":
                if (Castle.stage() >= 9) {
                    dState = 2;
                    dFly = 0f;
                    dFired = false;
                }
                break;
            case "fire":
                dState = 1;
                dTimer = 6f;
                breathe(dX, dY, u, dRight);
                break;
            case "home":
                dState = 3;
                dFly = 0f;
                break;
            case "pig":
                if (Castle.stage() >= 9) {
                    dState = 2;
                    dFly = 0f;
                    carryPig = true;
                    pigDropped = false;
                }
                break;
            default:
                if (what.startsWith("say:")) {
                    say(what.substring(4));
                }
                break;
        }
        invalidate();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        float t = (now - born) / 1e9f;
        if (!ok) {
            return;
        }
        if (builtVersion != Castle.version || builtStage != Castle.stage() || builtStyle != Castle.style()) {
            buildSprite();
        }
        if (now - dayChecked > 20_000_000_000L || dayChecked == 0) {
            dayness = computeDay();
            dayChecked = now == 0 ? 1 : now;
        }
        // the dragon may leave for days or come back
        if (now - tickAt > 30_000_000_000L || tickAt == 0) {
            tickAt = now == 0 ? 1 : now;
            if (Castle.tickDragon()) {
                dState = 3;
                dFly = 0f;
                carryPig = false;
                host.wizardSay("Ember is back from his trip!");
                Castle.orderPigFree(host);
            }
            Castle.autoPig(host);
        }
        dst.set(0, 0, SW * sc, SH * sc);
        p.setAlpha(255);
        int level = Math.round(dayness * 40f);
        if (level != mixLevel) {
            mixLevel = level;
            float lv = level / 40f;
            for (int i = 0; i < mixPx.length; i++) {
                mixPx[i] = thr[i] < lv ? dayPx[i] : nightPx[i];
            }
            mix.setPixels(mixPx, 0, SW, 0, 0, SW, SH);
        }
        c.drawBitmap(mix, src, dst, p);
        final boolean eco = Saver.on();
        final boolean life = Prefs.castleLife() && !eco;
        drawUpgrades(c, t, eco);
        drawStyleLife(c, dt, t, eco);
        drawSeason(c, t, eco);
        if (life) {
            drawLife(c, dt, t);
        }
        if (Prefs.castleLife()) {
            drawDragon(c, dt, t, !life);
        }
        // the wizard's light in the doorway while he is at home
        if (host.wizInside && dayness < 0.9f) {
            float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.6);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (210 * pulse * (1f - dayness)) << 24) | 0xFFC04D);
            c.drawRect((DOOR_X - 2) * sc, (DOOR_TOP + 3) * sc, (DOOR_X + 2) * sc, DOOR_BOTTOM * sc, p);
        }
        // crumbling cubes
        spawnDebt += eco ? 0f : dt * 11f;
        while (spawnDebt >= 1f) {
            spawnDebt -= 1f;
            spawnCrumb();
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = cubes.size() - 1; i >= 0; i--) {
            Cube q = cubes.get(i);
            q.age += dt;
            if (q.age >= q.life) {
                cubes.remove(i);
                continue;
            }
            q.x += q.vx * dt + (float) Math.sin(t * 2f + i) * 0.15f * sc;
            q.y += q.vy * dt;
            float a = 1f - q.age / q.life;
            p.setColor((q.color & 0x00FFFFFF) | ((int) (230 * a) << 24));
            c.drawRect(q.x, q.y, q.x + q.size, q.y + q.size, p);
        }
        if (isShown()) {
            postInvalidateDelayed(eco && cubes.isEmpty() ? 4000 : 33);
        }
    }
}
