package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The dog or cat. It lives in the castle with the wizard, comes out with him and trots after him. Tap it for a little
 * love. (The parrot is not here: it sits on the wizard's shoulder, see WizardView.)
 */
final class PetView extends View {
    private static final class Heart {
        float x, y, age;
        String s;
    }

    private final NovaActivity host;
    private final int slot;
    private final Paint p = new Paint();
    private final Random rnd = new Random();
    private final int s;
    private final List<Heart> hearts = new ArrayList<>();
    private final long born = System.nanoTime();
    private long last = System.nanoTime();
    private boolean flip;
    private boolean visibleBefore;
    private boolean moving;
    private float happyUntil;
    private long sleepAt;

    PetView(NovaActivity host, int slot) {
        super(host);
        this.host = host;
        this.slot = slot;
        setTag(NovaActivity.KEEP);
        float d = host.getResources().getDisplayMetrics().density;
        s = Math.max(2, Math.round(d * 1.6f));
        p.setAntiAlias(false);
        setElevation(Theme.dp(host, 5));
    }

    FrameLayout.LayoutParams params() {
        return new FrameLayout.LayoutParams(Pets.PW * s + s * 8, Pets.PH * s + s * 16, Gravity.TOP | Gravity.START);
    }

    private boolean hidden() {
        return host.wizardView() == null || (host.wizInside && Prefs.castle()) || !Pets.hasBody(slot);
    }

    /** Where the pet wants to stand: just beside the wizard's feet. */
    private float[] target(WizardView w) {
        float wx = w.getTranslationX();
        float wy = w.getTranslationY();
        boolean right = (wx < ((View) getParent()).getWidth() / 2f) == (slot == 0);
        float tx = right ? wx + w.getWidth() * 0.80f : wx - getWidth() * 0.65f;
        float ty = wy + w.getHeight() - getHeight() + s * 3;
        return new float[] {tx, ty};
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        float t = (now - born) / 1e9f;
        WizardView w = host.wizardView();
        if (hidden() || !(getParent() instanceof View)) {
            visibleBefore = false;
            postInvalidateDelayed(400);
            return;
        }
        float[] tg = target(w);
        if (!visibleBefore) {
            visibleBefore = true;
            setTranslationX(tg[0]);
            setTranslationY(tg[1]);
            hearts.clear();
            addHeart("♥");
        }
        // trot after the wizard
        float dx = tg[0] - getTranslationX();
        float dy = tg[1] - getTranslationY();
        float dist = (float) Math.hypot(dx, dy);
        moving = dist > s * 3;
        if (moving) {
            float step = Math.min(dist, (60f + dist * 1.6f) * s / 2f * dt);
            setTranslationX(getTranslationX() + dx / dist * step);
            setTranslationY(getTranslationY() + dy / dist * step);
            if (Math.abs(dx) > s * 2) {
                flip = dx < 0;
            }
            sleepAt = 0;
        } else if (sleepAt == 0) {
            sleepAt = System.currentTimeMillis();
        }
        boolean sleeping = !moving && sleepAt != 0 && System.currentTimeMillis() - sleepAt > 90000
                || (w.isSleeping() && !moving);
        boolean eco = Saver.on();
        int frame = moving ? (int) (t * 8) % 2 : (eco ? 0 : (int) (t * 2.5f) % 2);
        boolean happy = t < happyUntil || Pets.joy() > 85;
        float bob = sleeping || eco || moving ? 0 : (float) Math.sin(t * 3f) * 0.4f * s;
        float baseY = getHeight() - Pets.PH * s;
        drawIt(c, baseY + bob + (sleeping ? s : 0), frame, happy, sleeping, t);
        // hungry
        if (Pets.food() < 25 && !sleeping && (int) (t * 1.5f) % 2 == 0) {
            p.setColor(0xFFFF5A5A);
            c.drawRect(s * 11, baseY - s * 4, s * 12, baseY - s * 1, p);
            c.drawRect(s * 11, baseY, s * 12, baseY + s, p);
        }
        if (sleeping) {
            p.setColor(0xCCB9C8FF);
            p.setTextSize(s * 5f);
            c.drawText("z", s * 14f, baseY - s * 1f - (t % 2) * s * 2f, p);
        }
        // floating hearts
        for (int i = hearts.size() - 1; i >= 0; i--) {
            Heart h = hearts.get(i);
            h.age += dt;
            if (h.age > 1.4f) {
                hearts.remove(i);
                continue;
            }
            p.setColor(((int) (255 * (1f - h.age / 1.4f)) << 24) | 0xFF5A8A);
            p.setTextSize(s * 6f);
            c.drawText(h.s, h.x, h.y - h.age * s * 14f, p);
        }
        postInvalidateOnAnimation();
    }

    private long trickUntil;
    private long lastTap;

    private void drawIt(Canvas c, float y, int frame, boolean happy, boolean sleeping, float t) {
        float g = Pets.growth(slot);
        float us = s * g;
        float yy = y + (Pets.PH * s) * (1f - g);
        float hop = 0f;
        boolean fl = flip;
        long now = System.currentTimeMillis();
        if (now < trickUntil) {
            float k = (trickUntil - now) / 900f;
            hop = (float) Math.abs(Math.sin(k * Math.PI * 2)) * s * 6f;
            fl = ((int) (k * 6f)) % 2 == 0 ? flip : !flip;
        }
        if (sleeping) {
            p.setColor(0xFF8A5A2B);
            c.drawRect(s * 2, yy + Pets.PH * us - us, s * 4 + Pets.PW * us, yy + Pets.PH * us + us, p);
            p.setColor(0xFFB5813F);
            c.drawRect(s * 2, yy + Pets.PH * us - us, s * 4 + Pets.PW * us, yy + Pets.PH * us - us * 0.4f, p);
        }
        Pets.drawPet(c, p, Pets.kind(slot), Pets.color(slot), s * 4, yy - hop, us, frame, fl, happy, sleeping);
    }

    private void addHeart(String sym) {
        Heart h = new Heart();
        h.x = s * 8 + rnd.nextInt(s * 12);
        h.y = getHeight() - Pets.PH * s;
        h.s = sym;
        hearts.add(h);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (hidden()) {
            return false;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            return true;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            sleepAt = 0;
            long nowTap = System.currentTimeMillis();
            if (nowTap - lastTap < 400) {
                trickUntil = nowTap + 900;
                addHeart("\u2605");
                host.wizardSay(Pets.kind(slot) == Pets.DOG ? "Good trick!" : "Show off.");
            }
            lastTap = nowTap;
            happyUntil = (System.nanoTime() - born) / 1e9f + 4f;
            addHeart("♥");
            addHeart("♥");
            Pets.bumpJoy(6);
            host.buzz(10);
            Sfx.play(Sfx.BLIP);
            WizardView w = host.wizardView();
            if (w != null && rnd.nextInt(3) == 0) {
                w.say(Pets.kind(slot) == Pets.DOG ? "Woof! Good dog." : "Meow. It likes you.");
            }
            Quests.event(host, "pet");
            return true;
        }
        return true;
    }
}
