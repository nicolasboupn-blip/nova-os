package app.novaos;

/**
 * The castle's upgrade ladder. Ten stages you buy with play coins:
 * water wheel, lava, sword and banner, extra tower and wardrobe, baby dragon, bigger dragon, second pet,
 * castle styles, full-grown dragon, and the grand tower (fire, speech, days away, colours, roast pigs).
 */
final class Castle {
    static final String[] NAMES = {
        "Water wheel", "Lava", "Sword and banner", "Tower and wardrobe", "Baby dragon",
        "Dragon grows", "Second pet", "Castle styles", "Full-grown dragon", "The grand tower"};
    static final String[] INFO = {
        "A wooden wheel turns beside a little waterfall.",
        "Replaces the water with glowing lava.",
        "A sword stuck in the wall and a medieval banner of your country.",
        "A new tower, and the wizard's wardrobe (robes and staff orbs).",
        "A baby dragon hatches and naps on the tower.",
        "Your dragon grows a bit bigger.",
        "A second companion moves into the castle.",
        "Change the whole castle: hell, frozen, haunted, golden, cyber and more.",
        "Your dragon is fully grown. He flies big loops over the castle.",
        "A grand tower. The dragon breathes fire, talks, goes off for days, changes colour and brings roast pigs."};
    static final int[] COST = {300, 1200, 600, 900, 1200, 1500, 2000, 2500, 3500, 5000};

    static final String[] STYLES = {"Normal", "Hell", "Frozen", "Haunted", "Royal gold", "Cyber", "Sakura"};
    static final String[] ROBES = {"Classic", "Crimson", "Royal purple", "Emerald", "Midnight", "Rainbow"};
    static final int[] ROBE_COST = {0, 150, 150, 150, 250, 500};
    static final String[] ORBS = {"Gold", "Sky blue", "Green", "Pink", "Fire red"};
    static final float[] ROBE_HUE = {0f, 355f, 275f, 140f, 235f, 0f};
    static final int[] ORB_RGB = {0xFFD84D, 0x6EC8FF, 0x6EFF8C, 0xFF8AC8, 0xFF4A2A};
    static final int[] ORB_COST = {0, 100, 100, 100, 150};
    static final String[] DRAGON_COLORS = {"Purple", "Red", "Green", "Blue", "Gold", "Black", "White", "Rainbow"};
    static final int[] DRAGON_RGB = {0xFF7A4CB8, 0xFFC0392B, 0xFF2E9E57, 0xFF2F7FD0, 0xFFD9A524, 0xFF2B2B33,
        0xFFEDEDF2, 0xFF7A4CB8};

    // flags: {name, kind, c1, c2, c3}. kinds: 0 horizontal stripes, 1 vertical stripes, 2 cross on field,
    // 3 nordic cross, 4 disc on field, 5 union jack-ish, 6 stars and stripes
    static final String[] FLAG_NAMES = {"Switzerland", "Germany", "France", "Italy", "Austria", "Netherlands",
        "Ukraine", "Poland", "Spain", "United Kingdom", "USA", "Sweden", "Japan", "Brazil", "Custom"};
    static final int[][] FLAGS = {
        {2, 0xFFD52B1E, 0xFFFFFFFF, 0},
        {0, 0xFF111111, 0xFFDD0000, 0xFFFFCE00},
        {1, 0xFF0055A4, 0xFFFFFFFF, 0xFFEF4135},
        {1, 0xFF009246, 0xFFFFFFFF, 0xFFCE2B37},
        {0, 0xFFED2939, 0xFFFFFFFF, 0xFFED2939},
        {0, 0xFFAE1C28, 0xFFFFFFFF, 0xFF21468B},
        {0, 0xFF0057B7, 0xFF0057B7, 0xFFFFD700},
        {0, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFDC143C},
        {0, 0xFFAA151B, 0xFFF1BF00, 0xFFAA151B},
        {5, 0xFF012169, 0xFFFFFFFF, 0xFFC8102E},
        {6, 0xFFB22234, 0xFFFFFFFF, 0xFF3C3B6E},
        {3, 0xFF006AA7, 0xFFFECC00, 0},
        {4, 0xFFFFFFFF, 0xFFBC002D, 0},
        {0, 0xFF009C3B, 0xFFFFDF00, 0xFF002776},
        {0, 0xFFC0392B, 0xFFF1C40F, 0xFF2980B9}};

    private Castle() {}

    static int stage() {
        return Math.max(0, Math.min(10, Prefs.getInt("cs_stage", 0)));
    }

    /** Bumped whenever something that changes the castle's picture changes. */
    static int version;

    static void changed() {
        version++;
    }

    static boolean has(int stageNumber) {
        return stage() >= stageNumber;
    }

    static boolean lava() {
        return has(2) && Prefs.getInt("cs_lava", 1) == 1;
    }

    static int style() {
        return has(8) ? Math.max(0, Math.min(STYLES.length - 1, Prefs.getInt("cs_style", 0))) : 0;
    }

    static int flag() {
        return Math.max(0, Math.min(FLAG_NAMES.length - 1, Prefs.getInt("cs_flag", 0)));
    }

    static int robe() {
        return Math.max(0, Math.min(ROBES.length - 1, Prefs.getInt("wz_robe", 0)));
    }

    static int orb() {
        return Math.max(0, Math.min(ORBS.length - 1, Prefs.getInt("wz_orb", 0)));
    }

    static boolean owns(String kind, int i) {
        return i == 0 || Prefs.getInt("own_" + kind + i, 0) == 1;
    }

    static boolean admin() {
        return Prefs.getInt("admin_on", 0) == 1;
    }

    /** Buys the next stage. Returns an error text, or null on success. */
    static String buyNext(NovaActivity host) {
        int s = stage();
        if (s >= 10) {
            return "The castle is finished!";
        }
        int cost = COST[s];
        if (Coins.get() < cost && !admin()) {
            return "You need " + cost + " coins";
        }
        if (!admin()) {
            Coins.add(-cost);
        }
        Prefs.putInt("cs_stage", s + 1);
        onUnlocked(host, s + 1);
        changed();
        return null;
    }

    /** Admin: jump straight to any stage without paying. */
    static void setStage(NovaActivity host, int stage) {
        Prefs.putInt("cs_stage", Math.max(0, Math.min(10, stage)));
        if (stage >= 5 && Prefs.getInt("dr_born", 0) == 0) {
            Prefs.putInt("dr_born", (int) (System.currentTimeMillis() / 60000L));
        }
        changed();
    }

    private static void onUnlocked(NovaActivity host, int stage) {
        Sfx.play(Sfx.WIN);
        host.buzz(40);
        if (stage == 5) {
            Prefs.putInt("dr_born", (int) (System.currentTimeMillis() / 60000L));
        }
        if (stage == 8) {
            Prefs.putInt("cs_style", 0);
        }
        String[] say = {
            "A water wheel! The mill is turning.", "Lava! Hot, hot, hot.", "A sword in the stone wall. Very legendary.",
            "A new tower, and a wardrobe for me!", "An egg... it hatched! Meet our baby dragon.",
            "Look at him grow!", "A second companion is moving in.", "The castle can change its look now!",
            "He is fully grown. Mind the wings.", "The grand tower is done. Ember rules the skies."};
        host.wizardSay(say[stage - 1]);
        if (stage >= 5) {
            Quests.event(host, "castle");
        }
    }

    // ------------------------------------------------------------------ the dragon

    /** How big the dragon is: 0 means there is none yet. */
    static float dragonSize() {
        int s = stage();
        if (s < 5) {
            return 0f;
        }
        if (s < 6) {
            return 0.55f;
        }
        if (s < 9) {
            return 0.85f;
        }
        if (s < 10) {
            return 1.2f;
        }
        return 1.4f;
    }

    static int dragonColor() {
        return has(10) ? Math.max(0, Math.min(DRAGON_COLORS.length - 1, Prefs.getInt("dr_color", 0))) : 0;
    }

    static int nowMin() {
        return (int) (System.currentTimeMillis() / 60000L);
    }

    /** Minutes until the dragon is back, 0 if he is home. */
    static int awayMinutes() {
        int until = Prefs.getInt("dr_away", 0);
        return until > nowMin() ? until - nowMin() : 0;
    }

    static boolean locked() {
        return Prefs.getInt("dr_lock", 0) == 1;
    }

    /** Called now and then: maybe sends the dragon off, or welcomes him back. Returns true if he just came home. */
    static boolean tickDragon() {
        if (!has(10)) {
            return false;
        }
        int until = Prefs.getInt("dr_away", 0);
        int now = nowMin();
        if (until != 0 && until <= now) {
            Prefs.putInt("dr_away", 0);
            Prefs.putInt("dr_next_leave", now + 60 * 24 * (4 + new java.util.Random().nextInt(5)));
            return true;
        }
        if (until == 0 && !locked()) {
            int next = Prefs.getInt("dr_next_leave", 0);
            if (next == 0) {
                Prefs.putInt("dr_next_leave", now + 60 * 24 * (3 + new java.util.Random().nextInt(5)));
            } else if (next <= now) {
                Prefs.putInt("dr_away", now + 60 * 24 * (1 + new java.util.Random().nextInt(3)));
            }
        }
        return false;
    }

    static void recall() {
        Prefs.putInt("dr_away", 0);
        Prefs.putInt("dr_next_leave", nowMin() + 60 * 24 * 5);
        changed();
    }

    static void sendAway(int hours) {
        Prefs.putInt("dr_away", nowMin() + hours * 60);
        changed();
    }

    static void setLocked(boolean on) {
        Prefs.putInt("dr_lock", on ? 1 : 0);
        if (on) {
            recall();
        }
    }

    // ------------------------------------------------------------------ roast pigs

    static long lastPigMs() {
        return Prefs.getInt("dr_pig_t", 0) * 60000L;
    }

    /** Can the dragon bring a pig now? Admins never wait. */
    static boolean pigReady() {
        if (!has(10) || awayMinutes() > 0) {
            return false;
        }
        return admin() || nowMin() - Prefs.getInt("dr_pig_t", 0) >= 240;
    }

    static void pigDelivered() {
        Prefs.putInt("dr_pig_t", nowMin());
    }

    /** The dragon brings a pig (he flies it in if the castle is on screen). Returns false if he cannot yet. */
    static boolean orderPig(NovaActivity host) {
        if (!pigReady()) {
            return false;
        }
        pigDelivered();
        if (host.castle != null) {
            host.castle.dragonDo("pig");
        } else {
            host.dropPig();
        }
        host.wizardSay("Ember is bringing a roast pig!");
        return true;
    }

    /** A pig as a welcome-home present. */
    static void orderPigFree(NovaActivity host) {
        pigDelivered();
        host.root.postDelayed(host::dropPig, 4500);
    }

    /** Admins get a roast pig every few hours without asking. */
    static void autoPig(NovaActivity host) {
        if (!admin() || !has(10) || awayMinutes() > 0 || !host.homeIdle()) {
            return;
        }
        int next = Prefs.getInt("dr_pig_next", 0);
        int now = nowMin();
        if (next == 0) {
            Prefs.putInt("dr_pig_next", now + 120 + new java.util.Random().nextInt(180));
        } else if (next <= now) {
            Prefs.putInt("dr_pig_next", now + 180 + new java.util.Random().nextInt(240));
            orderPig(host);
        }
    }

    // ------------------------------------------------------------------ flags

    /** Colour of a banner at (u, v) in 0..1. */
    static int flagColor(int idx, float u, float v, int c1, int c2, int c3) {
        int[] f = FLAGS[idx];
        int a = idx == FLAG_NAMES.length - 1 ? c1 : f[1];
        int b = idx == FLAG_NAMES.length - 1 ? c2 : f[2];
        int c = idx == FLAG_NAMES.length - 1 ? c3 : f[3];
        switch (f[0]) {
            case 0:
                return v < 0.333f ? a : v < 0.667f ? b : c;
            case 1:
                return u < 0.333f ? a : u < 0.667f ? b : c;
            case 2: { // white cross on a red field (Switzerland)
                boolean cross = (Math.abs(u - 0.5f) < 0.11f && Math.abs(v - 0.5f) < 0.30f)
                        || (Math.abs(v - 0.5f) < 0.11f && Math.abs(u - 0.5f) < 0.30f);
                return cross ? b : a;
            }
            case 3: { // nordic cross
                boolean cross = Math.abs(u - 0.36f) < 0.09f || Math.abs(v - 0.5f) < 0.09f;
                return cross ? b : a;
            }
            case 4: // a disc on a white field
                return Math.hypot((u - 0.5f) * 0.7f, v - 0.5f) < 0.26f ? b : a;
            case 5: { // simplified union flag
                boolean white = Math.abs(u - 0.5f) < 0.14f || Math.abs(v - 0.5f) < 0.14f
                        || Math.abs((u - 0.5f) - (v - 0.5f) * 0.6f) < 0.07f
                        || Math.abs((u - 0.5f) + (v - 0.5f) * 0.6f) < 0.07f;
                boolean red = Math.abs(u - 0.5f) < 0.07f || Math.abs(v - 0.5f) < 0.07f;
                return red ? c : white ? b : a;
            }
            default: { // stars and stripes, simplified
                if (u < 0.5f && v < 0.5f) {
                    return c;
                }
                return ((int) (v * 7f)) % 2 == 0 ? a : b;
            }
        }
    }
}
