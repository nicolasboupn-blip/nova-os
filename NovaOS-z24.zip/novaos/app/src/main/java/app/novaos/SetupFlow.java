package app.novaos;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The first-boot setup: a short welcome with the wizard. Pick a name, an accent colour, a wallpaper and a few extras.
 * Runs once, and can be run again from Settings. Skip works at any time.
 */
final class SetupFlow extends FrameLayout implements BackAware {
    private static final int PAGES = 6;

    private final NovaActivity host;
    private final Bitmap sprite;
    private int page;
    private EditText nameField;

    SetupFlow(NovaActivity host) {
        super(host);
        this.host = host;
        this.sprite = WizardView.loadSprite(host);
        setClickable(true);
        render();
    }

    @Override
    public boolean onBack() {
        if (page > 0) {
            page--;
            render();
        }
        return true; // setup stays until you finish or skip
    }

    private TextView mono(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private TextView button(String s, boolean strong, final Runnable action) {
        TextView t = mono(s, 13f, strong ? Theme.BG : Theme.DIM);
        t.setLetterSpacing(0.14f);
        t.setBackground(Theme.rounded(strong ? Theme.ACCENT : 0x26FFFFFF, 16f, host));
        t.setPadding(Theme.dp(host, 22), Theme.dp(host, 13), Theme.dp(host, 22), Theme.dp(host, 13));
        t.setClickable(true);
        t.setOnClickListener(v -> {
            Sfx.play(Sfx.CLICK);
            action.run();
        });
        return t;
    }

    private void saveName() {
        if (nameField != null) {
            Prefs.putString(Prefs.K_USER, nameField.getText().toString().trim());
        }
    }

    private void render() {
        removeAllViews();
        setBackgroundColor(Theme.BG);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(Theme.dp(host, 28), Theme.dp(host, 70), Theme.dp(host, 28), Theme.dp(host, 40));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // the wizard on every page
        View portrait = new View(host) {
            @Override
            protected void onDraw(Canvas c) {
                if (sprite == null) {
                    return;
                }
                int s = Math.max(2, getHeight() / 49);
                int w = 29 * s;
                int h = 49 * s;
                Paint p = new Paint();
                p.setFilterBitmap(false);
                int x = (getWidth() - w) / 2;
                int y = (getHeight() - h) / 2;
                p.setColor(0x33FFD84D);
                c.drawCircle(x + 5 * s, y + 8.5f * s, 8 * s, p);
                c.drawBitmap(sprite, new Rect(0, 0, 29, 49), new Rect(x, y, x + w, y + h), p);
            }
        };
        col.addView(portrait, new LinearLayout.LayoutParams(Theme.dp(host, 150), Theme.dp(host, 150)));

        String title;
        String text;
        switch (page) {
            case 0:
                title = "WELCOME TO NOVA";
                text = "I am Merlo. Let me set things up in a few steps. You can change everything later in Settings.";
                break;
            case 1:
                title = "WHAT'S YOUR NAME?";
                text = "NOVA will greet you with it.";
                break;
            case 2:
                title = "PICK YOUR COLOUR";
                text = "This is NOVA's accent. It glows everywhere.";
                break;
            case 3:
                title = "PICK A MOOD";
                text = "A moving wallpaper behind your home screen.";
                break;
            case 4:
                title = "A FEW EXTRAS";
                text = "Switch on what you like.";
                break;
            default:
                title = "YOUR COMPANION";
                text = "Pick one friend. It lives in my castle. After setup you can change it once a month, "
                        + "or with the password.";
                break;
        }
        TextView t = mono(title, 15f, Theme.ACCENT);
        t.setLetterSpacing(0.2f);
        t.setPadding(0, Theme.dp(host, 12), 0, Theme.dp(host, 8));
        col.addView(t);
        TextView d = mono(text, 12f, Theme.DIM);
        d.setLineSpacing(0f, 1.2f);
        col.addView(d);

        LinearLayout content = new LinearLayout(host);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        col.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        nameField = null;
        if (page == 1) {
            nameField = new EditText(host);
            nameField.setText(Prefs.userName());
            nameField.setHint("your name");
            nameField.setHintTextColor(Theme.DIM);
            nameField.setTextColor(Theme.TEXT);
            nameField.setTypeface(Theme.MONO);
            nameField.setTextSize(18f);
            nameField.setGravity(Gravity.CENTER);
            nameField.setSingleLine(true);
            nameField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
            nameField.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
            nameField.setPadding(Theme.dp(host, 16), Theme.dp(host, 14), Theme.dp(host, 16), Theme.dp(host, 14));
            content.addView(nameField, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        } else if (page == 2) {
            accents(content);
        } else if (page == 3) {
            moods(content);
        } else if (page == 4) {
            extras(content);
        } else if (page == 5) {
            PetPicker.build(host, content, null);
        }

        // dots
        LinearLayout dots = new LinearLayout(host);
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < PAGES; i++) {
            View dot = new View(host);
            dot.setBackground(Theme.rounded(i == page ? Theme.ACCENT : 0x44FFFFFF, 4f, host));
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Theme.dp(host, 8), Theme.dp(host, 8));
            dp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
            dots.addView(dot, dp);
        }
        LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dotp.bottomMargin = Theme.dp(host, 18);
        col.addView(dots, dotp);

        LinearLayout nav = new LinearLayout(host);
        nav.setGravity(Gravity.CENTER);
        if (page > 0) {
            nav.addView(button("BACK", false, () -> {
                saveName();
                page--;
                render();
            }));
        } else {
            nav.addView(button("SKIP", false, this::finish));
        }
        View gap = new View(host);
        nav.addView(gap, new LinearLayout.LayoutParams(Theme.dp(host, 12), 1));
        nav.addView(button(page == PAGES - 1 ? "FINISH" : "NEXT", true, () -> {
            saveName();
            if (page == PAGES - 1) {
                finish();
            } else {
                page++;
                render();
            }
        }));
        col.addView(nav);
    }

    private void accents(LinearLayout into) {
        int per = 4;
        for (int start = 0; start < Theme.PRESET_NAMES.length; start += per) {
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER);
            for (int i = start; i < Math.min(start + per, Theme.PRESET_NAMES.length); i++) {
                final int idx = i;
                LinearLayout cell = new LinearLayout(host);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(0, Theme.dp(host, 8), 0, Theme.dp(host, 8));
                cell.setClickable(true);
                cell.setOnClickListener(v -> {
                    Prefs.putInt(Prefs.K_ACCENT, idx);
                    Theme.load();
                    Sfx.play(Sfx.CLICK);
                    render();
                });
                View dot = new View(host);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(Theme.presetAccent(i));
                if (Prefs.accent() == i) {
                    g.setStroke(Theme.dp(host, 3), Theme.TEXT);
                }
                dot.setBackground(g);
                cell.addView(dot, new LinearLayout.LayoutParams(Theme.dp(host, 46), Theme.dp(host, 46)));
                TextView n = mono(Theme.PRESET_NAMES[i].toUpperCase(), 9f, Theme.DIM);
                n.setPadding(0, Theme.dp(host, 5), 0, 0);
                cell.addView(n);
                row.addView(cell, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            }
            into.addView(row, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
    }

    private void moods(LinearLayout into) {
        LinearLayout row = null;
        for (int i = 0; i < LiveWallpaper.NAMES.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(host);
                row.setGravity(Gravity.CENTER);
                into.addView(row, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            final int idx = i;
            boolean on = Prefs.liveWall() == i;
            TextView chip = mono(LiveWallpaper.NAMES[i].toUpperCase(), 11f, on ? Theme.BG : Theme.TEXT);
            chip.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 14f, host));
            chip.setPadding(Theme.dp(host, 10), Theme.dp(host, 12), Theme.dp(host, 10), Theme.dp(host, 12));
            chip.setClickable(true);
            chip.setOnClickListener(v -> {
                Prefs.putInt(Prefs.K_LIVE, idx);
                if (idx == 6) {
                    host.askVizPermission();
                }
                Sfx.play(Sfx.CLICK);
                render();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(Theme.dp(host, 4), Theme.dp(host, 4), Theme.dp(host, 4), Theme.dp(host, 4));
            row.addView(chip, lp);
        }
    }

    private void extras(LinearLayout into) {
        extra(into, "Wizard mascot (me!)", Prefs.K_WIZARD, Prefs.wizard());
        extra(into, "Sounds", Prefs.K_SFX, Prefs.sfx());
        extra(into, "Charging clock", Prefs.K_NIGHT, Prefs.nightClock());
        extra(into, "Parallax tilt", Prefs.K_PARALLAX, Prefs.parallax());
        extra(into, "Notification edge light", Prefs.K_EDGE_FLASH, Prefs.edgeFlash());
    }

    private void extra(LinearLayout into, String label, final String key, boolean on) {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Theme.dp(host, 8), 0, Theme.dp(host, 8));
        TextView t = new TextView(host);
        t.setText(label);
        t.setTextSize(15f);
        t.setTextColor(Theme.TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Switch sw = new android.widget.Switch(host);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener((b, v) -> Prefs.putBool(key, v));
        row.addView(sw);
        into.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void finish() {
        saveName();
        Prefs.putInt("setup_done", 1);
        Pets.lockNow();
        Theme.load();
        host.hideOverlay();
        host.showHome();
        host.root.postDelayed(() -> {
            host.syncWizard();
            host.tip("hello");
            host.tip("setup");
        }, 1200);
    }
}
