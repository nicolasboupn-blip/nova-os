package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** A short to-do list that pays coins, and a few habits to tick once a day. */
final class TodoPage extends LinearLayout {
    private final NovaActivity host;
    private boolean habits;
    private static final int MAX_SHOWN = 4;

    TodoPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setPadding(Theme.dp(host, 16), Theme.dp(host, 4), Theme.dp(host, 16), Theme.dp(host, 4));
        refresh();
    }

    private static int today() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
    }

    private List<String> load(String key) {
        List<String> l = new ArrayList<>();
        for (String s : Prefs.getString(key, "").split("\n")) {
            if (!s.trim().isEmpty()) {
                l.add(s);
            }
        }
        return l;
    }

    private void save(String key, List<String> l) {
        Prefs.putString(key, String.join("\n", l));
    }

    private TextView label(String s, float sp, int col) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(col);
        return t;
    }

    void refresh() {
        removeAllViews();
        LinearLayout tabs = new LinearLayout(host);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = label("TO-DO", 11f, habits ? Theme.DIM : Theme.ACCENT);
        a.setPadding(0, 0, Theme.dp(host, 16), Theme.dp(host, 6));
        a.setOnClickListener(v -> {
            habits = false;
            refresh();
        });
        TextView b = label("HABITS", 11f, habits ? Theme.ACCENT : Theme.DIM);
        b.setPadding(0, 0, Theme.dp(host, 16), Theme.dp(host, 6));
        b.setOnClickListener(v -> {
            habits = true;
            refresh();
        });
        TextView add = label("+ ADD", 11f, Theme.ACCENT);
        add.setPadding(Theme.dp(host, 10), 0, 0, Theme.dp(host, 6));
        add.setOnClickListener(v -> addDialog());
        tabs.addView(a);
        tabs.addView(b);
        tabs.addView(new android.view.View(host), new LinearLayout.LayoutParams(0, 1, 1f));
        tabs.addView(add);
        addView(tabs);
        final String key = habits ? "habits" : "todos";
        final List<String> items = load(key);
        if (items.isEmpty()) {
            addView(label(habits ? "No habits yet. Add one, tick it daily, keep a streak."
                    : "Nothing to do. Add a task: each finished one pays 5 coins.", 11f, Theme.DIM));
            return;
        }
        int shown = 0;
        for (int i = 0; i < items.size() && shown < MAX_SHOWN; i++) {
            final int idx = i;
            final String raw = items.get(i);
            String text = raw;
            boolean done = false;
            String sub = "";
            if (habits) {
                // text|lastDay|streak
                String[] f = raw.split("\\|");
                text = f[0];
                int last = f.length > 1 ? parse(f[1]) : 0;
                int streak = f.length > 2 ? parse(f[2]) : 0;
                done = last == today();
                sub = streak > 0 ? "  🔥" + streak : "";
            }
            TextView row = label((done ? "☑  " : "☐  ") + text + sub, 13f, done ? Theme.DIM : Theme.TEXT);
            row.setPadding(0, Theme.dp(host, 7), 0, Theme.dp(host, 7));
            row.setClickable(true);
            row.setOnClickListener(v -> tick(key, items, idx));
            row.setOnLongClickListener(v -> {
                items.remove(idx);
                save(key, items);
                refresh();
                return true;
            });
            addView(row);
            shown++;
        }
        if (items.size() > MAX_SHOWN) {
            addView(label("+" + (items.size() - MAX_SHOWN) + " more (finish some first)", 10f, Theme.DIM));
        }
        addView(label("Tap to check off. Hold to delete.", 9f, Theme.DIM));
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void tick(String key, List<String> items, int idx) {
        if (!habits) {
            items.remove(idx);
            save(key, items);
            Coins.add(5);
            Sfx.play(Sfx.COIN);
            Quests.event(host, "coin");
            host.toast("+5 coins");
            refresh();
            return;
        }
        String[] f = items.get(idx).split("\\|");
        int last = f.length > 1 ? parse(f[1]) : 0;
        int streak = f.length > 2 ? parse(f[2]) : 0;
        if (last == today()) {
            return;
        }
        Calendar y = Calendar.getInstance();
        y.add(Calendar.DAY_OF_YEAR, -1);
        int yday = y.get(Calendar.YEAR) * 1000 + y.get(Calendar.DAY_OF_YEAR);
        streak = last == yday ? streak + 1 : 1;
        items.set(idx, f[0] + "|" + today() + "|" + streak);
        save(key, items);
        int bonus = Math.min(10, 2 + streak);
        Coins.add(bonus);
        Sfx.play(Sfx.COIN);
        host.toast("+" + bonus + " coins, streak " + streak);
        refresh();
    }

    private void addDialog() {
        final EditText in = new EditText(host);
        in.setHint(habits ? "e.g. Drink water" : "e.g. Call mum");
        new AlertDialog.Builder(host).setTitle(habits ? "New habit" : "New task").setView(in)
                .setPositiveButton("ADD", (d, w) -> {
                    String t = in.getText().toString().trim().replace("|", " ").replace("\n", " ");
                    if (t.isEmpty()) {
                        return;
                    }
                    String key = habits ? "habits" : "todos";
                    List<String> l = load(key);
                    l.add(habits ? t + "|0|0" : t);
                    save(key, l);
                    refresh();
                }).setNegativeButton("Cancel", null).show();
    }
}
