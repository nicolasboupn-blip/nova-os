package app.novaos;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import java.util.Random;

/**
 * A notification arrives as a little pixel creature that walks across the screen. Tap it to squash it, and it
 * dismisses that notification for you. If you ignore it, it just walks off the other side.
 */
final class CritterView extends View {
    private final NovaActivity host;
    private final Paint p = new Paint();
    private final Random rnd = new Random();
    private final int s;
    private final int kind;
    private final int color;
    private final String key;
    private final boolean leftToRight;
    private ValueAnimator walk;
    private boolean squashed;
    private float squashAt;
    private final long born = System.nanoTime();

    CritterView(NovaActivity host, String key) {
        super(host);
        this.host = host;
        this.key = key;
        setTag(NovaActivity.KEEP);
        s = Math.max(3, Math.round(host.getResources().getDisplayMetrics().density * 3.2f));
        kind = rnd.nextInt(3);
        int[] cols = {0xFF4CD964, 0xFF5AC8FA, 0xFFFF6B9A, 0xFFFFC93C, 0xFFB39DFF};
        color = cols[rnd.nextInt(cols.length)];
        leftToRight = rnd.nextBoolean();
        setElevation(Theme.dp(host, 8));
    }

    /** Puts it on the screen and sets it walking. */
    void start(final FrameLayout root) {
        int w = 12 * s;
        int h = 11 * s + s * 4;
        root.addView(this, new FrameLayout.LayoutParams(w, h));
        final float rootW = root.getWidth();
        final float y = root.getHeight() * 0.80f - rnd.nextInt(Theme.dp(host, 90));
        setTranslationY(y);
        final float from = leftToRight ? -w : rootW;
        final float to = leftToRight ? rootW : -w;
        setTranslationX(from);
        walk = ValueAnimator.ofFloat(0f, 1f);
        walk.setDuration(7500);
        walk.setInterpolator(new LinearInterpolator());
        walk.addUpdateListener(a -> setTranslationX(from + (to - from) * (float) a.getAnimatedValue()));
        walk.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                remove();
            }
        });
        walk.start();
        host.keepOnTop();
    }

    private void remove() {
        if (getParent() instanceof FrameLayout) {
            ((FrameLayout) getParent()).removeView(this);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float t = (System.nanoTime() - born) / 1e9f;
        p.setStyle(Paint.Style.FILL);
        float hop = squashed ? 0f : Math.abs((float) Math.sin(t * 7f)) * s * 2f;
        float base = getHeight() - s;
        if (squashed) {
            float k = (t - squashAt);
            p.setColor((color & 0x00FFFFFF) | ((int) (255 * Math.max(0f, 1f - k * 2f)) << 24));
            c.drawRect(s, base - s, 11 * s, base, p);
            for (int i = 0; i < 6; i++) {
                float ang = i * 1.05f;
                c.drawRect(6 * s + (float) Math.cos(ang) * k * s * 14f, base - s * 2
                        + (float) Math.sin(ang) * k * s * 8f, 6 * s + (float) Math.cos(ang) * k * s * 14f + s,
                        base - s * 2 + (float) Math.sin(ang) * k * s * 8f + s, p);
            }
            if (k > 0.5f) {
                post(this::remove);
            }
            postInvalidateOnAnimation();
            return;
        }
        boolean flip = !leftToRight;
        float y = base - hop;
        if (kind == 0) {            // slime
            p.setColor(color);
            c.drawRect(2 * s, y - 5 * s, 10 * s, y, p);
            c.drawRect(3 * s, y - 7 * s, 9 * s, y - 5 * s, p);
            p.setColor(0xFFFFFFFF);
            c.drawRect(4 * s, y - 5 * s, 5 * s, y - 3 * s, p);
            c.drawRect(7 * s, y - 5 * s, 8 * s, y - 3 * s, p);
            p.setColor(0xFF000000);
            c.drawRect(flip ? 4 * s : 5 * s - s / 2f, y - 4.5f * s, flip ? 4.5f * s : 5 * s, y - 3.5f * s, p);
            c.drawRect(flip ? 7 * s : 8 * s - s / 2f, y - 4.5f * s, flip ? 7.5f * s : 8 * s, y - 3.5f * s, p);
        } else if (kind == 1) {     // ghost
            p.setColor(0xDDFFFFFF);
            c.drawRect(2 * s, y - 9 * s, 10 * s, y - 2 * s, p);
            c.drawRect(3 * s, y - 10 * s, 9 * s, y - 9 * s, p);
            int wave = (int) (t * 8f) % 2;
            for (int i = 0; i < 4; i++) {
                c.drawRect((2 + i * 2) * s, y - 2 * s, (3 + i * 2) * s, y - (i % 2 == wave ? 0 : 1) * s, p);
            }
            p.setColor(0xFF000000);
            c.drawRect(4 * s, y - 7 * s, 5 * s, y - 5 * s, p);
            c.drawRect(7 * s, y - 7 * s, 8 * s, y - 5 * s, p);
            p.setColor(color);
            c.drawRect(3 * s, y - 4 * s, 4 * s, y - 3 * s, p);
        } else {                    // beetle
            p.setColor(color);
            c.drawRect(2 * s, y - 6 * s, 10 * s, y - 2 * s, p);
            c.drawRect(3 * s, y - 7 * s, 9 * s, y - 6 * s, p);
            p.setColor(0xFF000000);
            c.drawRect(6 * s - s / 2f, y - 7 * s, 6 * s + s / 2f, y - 2 * s, p);
            c.drawRect((flip ? 2 : 9) * s, y - 5 * s, (flip ? 3 : 10) * s, y - 4 * s, p);
            int leg = (int) (t * 10f) % 2;
            for (int i = 0; i < 3; i++) {
                c.drawRect((3 + i * 3) * s, y - 2 * s, (3 + i * 3) * s + s, y - (leg == i % 2 ? 0 : 1) * s, p);
            }
            p.setColor(0xFFFFFFFF);
            c.drawRect(3.5f * s, y - 6 * s, 4.5f * s, y - 5 * s, p);
        }
        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (squashed) {
            return false;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            return true;
        }
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            squashed = true;
            squashAt = (System.nanoTime() - born) / 1e9f;
            if (walk != null) {
                walk.cancel();
            }
            Sfx.play(Sfx.COIN);
            host.buzz(18);
            Coins.add(2);
            NovaNotificationService.dismiss(key);
            Quests.event(host, "critter");
            invalidate();
            return true;
        }
        return true;
    }
}
