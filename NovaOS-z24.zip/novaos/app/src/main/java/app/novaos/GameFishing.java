package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** Cast your line, wait for the bobber to dip, then tap fast. Rarer fish are worth more coins. */
final class GameFishing extends Game {
    private static final String[] FISH = {"a boot", "a sardine", "a trout", "a salmon", "a golden carp", "a tiny dragon"};
    private static final int[] COINS = {0, 2, 5, 10, 25, 60};

    private final TextView pond;
    private final TextView info;
    private final TextView act;
    private final Random rnd = new Random();
    private int state;     // 0 idle, 1 waiting, 2 bite
    private long biteAt;
    private int caught;
    private int earned;

    GameFishing(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(80), dp(24), dp(30));
        addView(col, new LayoutParams(-1, -1));
        info = label("", 13f, Theme.DIM);
        col.addView(info);
        pond = label("🎣", 64f, Theme.TEXT);
        pond.setBackground(Theme.rounded(0xFF12324A, 28f, host));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, 0, 1f);
        pp.topMargin = dp(16);
        pp.bottomMargin = dp(16);
        col.addView(pond, pp);
        act = button("CAST", this::tap);
        col.addView(act);
        refresh();
    }

    @Override
    String title() {
        return "FISHING";
    }

    private void refresh() {
        info.setText("CAUGHT " + caught + "   COINS +" + earned + "   BEST " + best("fish", 0));
    }

    private void tap() {
        if (state == 0) {
            state = 1;
            pond.setText("🌊\n...");
            act.setText("WAIT");
            h.postDelayed(() -> {
                state = 2;
                biteAt = android.os.SystemClock.elapsedRealtime();
                pond.setText("❗");
                host.buzz(40);
                Sfx.play(Sfx.BLIP);
                act.setText("PULL!");
                h.postDelayed(() -> {
                    if (state == 2) {
                        state = 0;
                        pond.setText("🐟💨\nit got away");
                        act.setText("CAST");
                    }
                }, 900);
            }, 1500 + rnd.nextInt(3500));
        } else if (state == 1) {
            h.removeCallbacksAndMessages(null);
            state = 0;
            pond.setText("🎣\ntoo early!");
            act.setText("CAST");
        } else {
            long ms = android.os.SystemClock.elapsedRealtime() - biteAt;
            h.removeCallbacksAndMessages(null);
            state = 0;
            int r = rnd.nextInt(100);
            int kind = r < 12 ? 0 : r < 40 ? 1 : r < 68 ? 2 : r < 86 ? 3 : r < 97 ? 4 : 5;
            if (ms > 600) {
                kind = Math.max(0, kind - 2);   // slow hands, smaller fish
            }
            caught++;
            earned += COINS[kind];
            Coins.add(COINS[kind]);
            if (caught > best("fish", 0)) {
                saveBest("fish", caught);
            }
            pond.setText("🐟\nYou caught " + FISH[kind] + (COINS[kind] > 0 ? "\n+" + COINS[kind] + " coins" : ""));
            if (COINS[kind] > 0) {
                Sfx.play(Sfx.COIN);
            }
            if (kind == 5) {
                host.wizardSay("A tiny dragon?! Ember will be jealous.");
            }
            act.setText("CAST");
            refresh();
        }
    }
}
