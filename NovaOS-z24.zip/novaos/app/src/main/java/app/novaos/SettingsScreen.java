package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Everything you can change about NOVA, in one place. */
final class SettingsScreen extends LinearLayout {
    private final NovaActivity host;

    SettingsScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 20);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        // title row
        LinearLayout head = new LinearLayout(host);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("SETTINGS", 12f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView back = label("BACK", 12f, Theme.DIM);
        back.setClickable(true);
        back.setOnClickListener(v -> host.showHome());
        head.addView(back);
        addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(host);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(VERTICAL);
        sv.addView(body);
        addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        heading(body, "ACCENT");
        body.addView(accentRow(), block(8));

        heading(body, "APP ICONS");
        body.addView(choice("Icon style", Prefs.K_ICON_STYLE,
                new String[] {"Glow", "Purple", "Original"}, Prefs.iconStyle()));
        body.addView(hint("Glow: black and white icons with glowing particles drifting around them."));
        body.addView(toggle("Sparks when you touch an icon", Prefs.K_TOUCH_GLOW, Prefs.touchGlow()));
        body.addView(toggle("Holographic icons (rainbow foil, moves with tilt)", Prefs.K_HOLO, Prefs.holo()));
        body.addView(toggle("Draw on home (double-tap empty space)", Prefs.K_DRAW, Prefs.drawOn()));

        heading(body, "CLOCK & GLOW");
        body.addView(toggle("Glow around the clock", Prefs.K_GLOW_CLOCK, Prefs.glowClock()));
        body.addView(toggle("Purple edge light", Prefs.K_GLOW_EDGES, Prefs.glowEdges()));
        body.addView(toggle("Battery in header", Prefs.K_BATTERY, Prefs.battery()));
        body.addView(choice("Glow strength", Prefs.K_GLOW_STRENGTH,
                new String[] {"Soft", "Normal", "Strong"}, Prefs.glowStrength()));
        body.addView(choice("Clock style", Prefs.K_CLOCK_STYLE,
                new String[] {"Digital", "Stacked", "Analog", "Binary"}, Prefs.clockStyle()));
        body.addView(choice("Clock font", Prefs.K_CLOCK_FONT,
                new String[] {"Digital", "Classic", "Mono", "Bold"}, Prefs.clockFont()));
        body.addView(toggle("Hacker mode", Prefs.K_HACKER, Prefs.hacker(), () -> host.refreshTheme()));
        body.addView(hint("Green terminal look. The glow pulses faster as your battery drops."));

        heading(body, "HOME SCREEN");
        body.addView(toggle("Code wallpaper", Prefs.K_HOME_CODE, Prefs.homeCode()));
        body.addView(choice("Wallpaper strength", Prefs.K_HOME_STRENGTH,
                new String[] {"Subtle", "Medium", "Strong"}, Prefs.homeStrength()));
        body.addView(toggle("System panel", Prefs.K_SYSTEM_PANEL, Prefs.systemPanel()));

        heading(body, "BATTERY SAVER");
        body.addView(choice("Battery saver", Prefs.K_SAVER, new String[] {"Off", "Auto (20%)", "Always"},
                Prefs.saverMode(), Saver::refresh));
        body.addView(hint("Saver pauses what moves or listens all the time: animated wallpapers, parallax, holo icons, "
                + "pulsing glows, the castle's crumbling and the wizard's sparks, shake and Hey Nova, "
                + "and the cinematic startup. Auto turns it on at 20% or less when not charging. "
                + "Everything else works as normal."));

        heading(body, "LIVE & MOTION");
        body.addView(choice("Animated wallpaper", Prefs.K_LIVE, LiveWallpaper.NAMES, Prefs.liveWall(),
                () -> {
                    if (Prefs.liveWall() == 6) {
                        host.askVizPermission();
                    }
                }));
        body.addView(hint("Now playing moves with your music. With microphone access it follows the real sound, "
                + "otherwise it dances to a made-up beat. Needs notification access to show the song."));
        body.addView(toggle("Shake for a golden coin flip", Prefs.K_SHAKE, Prefs.shakeCoin()));
        body.addView(toggle("Parallax (layers move as you tilt)", Prefs.K_PARALLAX, Prefs.parallax()));
        body.addView(toggle("Edge lighting on notifications", Prefs.K_EDGE_FLASH, Prefs.edgeFlash()));
        body.addView(choice("Haptic feel (tap to test)", Prefs.K_HAPTIC,
                new String[] {"Off", "Soft", "Crisp", "Strong"}, Prefs.haptic()));
        body.addView(label("TEST BUZZ", 12f, Theme.ACCENT), block(8));
        body.getChildAt(body.getChildCount() - 1).setOnClickListener(v -> host.buzz(30));
        body.getChildAt(body.getChildCount() - 1).setClickable(true);

        heading(body, "QUIET & NOTIFICATIONS");
        body.addView(toggle("Quiet hours (auto Do Not Disturb)", Prefs.K_QUIET, Prefs.quiet(),
                () -> QuietHours.apply(host)));
        final TextView qs = label("FROM " + QuietHours.format(Prefs.quietStart()), 12f, Theme.ACCENT);
        qs.setClickable(true);
        qs.setOnClickListener(v -> new android.app.TimePickerDialog(host, (tp, h, m) -> {
            Prefs.putInt(Prefs.K_QSTART, h * 60 + m);
            qs.setText("FROM " + QuietHours.format(h * 60 + m));
            QuietHours.apply(host);
        }, Prefs.quietStart() / 60, Prefs.quietStart() % 60, true).show());
        body.addView(qs, block(10));
        final TextView qe = label("UNTIL " + QuietHours.format(Prefs.quietEnd()), 12f, Theme.ACCENT);
        qe.setClickable(true);
        qe.setOnClickListener(v -> new android.app.TimePickerDialog(host, (tp, h, m) -> {
            Prefs.putInt(Prefs.K_QEND, h * 60 + m);
            qe.setText("UNTIL " + QuietHours.format(h * 60 + m));
            QuietHours.apply(host);
        }, Prefs.quietEnd() / 60, Prefs.quietEnd() % 60, true).show());
        body.addView(qe, block(10));
        TextView dnd = label("ALLOW DND ACCESS", 12f, Theme.ACCENT);
        dnd.setClickable(true);
        dnd.setOnClickListener(v -> {
            try {
                host.startActivity(new android.content.Intent(
                        android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            } catch (Exception ignored) {
            }
        });
        body.addView(dnd, block(10));
        body.addView(hint("Quiet hours turns Do Not Disturb on and off by itself. It needs DND access once. "
                + "Timing can be a few minutes off."));
        body.addView(toggle("Notification digest", Prefs.K_DIGEST, Prefs.digest()));
        body.addView(hint("Low-priority notifications fold into one row in the shade."));

        body.addView(toggle("Ask for music when Momentum 4 connects", Prefs.K_HP_ASK, Prefs.headphoneAsk()));
        heading(body, "HEY NOVA");
        body.addView(toggle("Voice commands", Prefs.K_VOICE, Prefs.voice(), () -> host.syncVoice()));
        body.addView(toggle("Nova speaks answers", Prefs.K_VOICE_SPEAK, Prefs.voiceSpeak()));
        body.addView(hint("Say \"Hey Nova\" then a command. Listens only while NOVA is on screen. "
                + "Your phone may beep when it starts listening."));

        heading(body, "LOCK SCREEN");
        body.addView(toggle("Code wallpaper", Prefs.K_CODE_WALL, Prefs.codeWall()));
        body.addView(toggle("Startup animation on unlock", Prefs.K_BOOT_UNLOCK, Prefs.bootOnUnlock()));
        body.addView(toggle("Beep on unlock", Prefs.K_BEEP, Prefs.beep()));
        body.addView(pinRow());
        if (Prefs.hasPin() && BioAuth.available(host)) {
            body.addView(toggle("Fingerprint unlock", Prefs.K_BIO, Prefs.bio()));
        }
        body.addView(hint("A NOVA PIN adds a PIN pad to NOVA's lock screen. Your phone's own lock still works as before."));
        body.addView(hint("Your own wallpaper text (empty = NOVA's own code)"));
        body.addView(input(Prefs.K_WALL_TEXT, Prefs.wallText(), true), block(6));

        heading(body, "WIZARD & EXTRAS");
        body.addView(toggle("Wizard mascot (explains things you discover)", Prefs.K_WIZARD, Prefs.wizard(), () -> {
            host.syncWizard();
            if (Prefs.wizard()) {
                host.tip("hello");
            }
        }));
        body.addView(toggle("Castle on the home screen (the wizard lives in it)", Prefs.K_CASTLE,
                Prefs.castleSwitch(), () -> host.wizInside = true));
        body.addView(choice("Wizard suggestions", Prefs.K_NUDGE, new String[] {"Off", "5 min", "1 hour", "12 hours"},
                Prefs.nudgeMode()));
        body.addView(hint("After you unlock and reach the home screen, and this long since the last time, there is a "
                + "50% chance the wizard slides your panel to Slots and asks if you want to gamble. Say no and he tries "
                + "games without coins, then music. Needs the wizard on."));
        body.addView(toggle("Surprises (shooting stars, treasure chests, golden coins)", Prefs.K_EVENTS, Prefs.eventsOn()));
        body.addView(toggle("Castle life (dragon, bats, your weather)", Prefs.K_CLIFE, Prefs.castleLife()));
        body.addView(toggle("Wizard reactions (naps, yawns, cheers)", Prefs.K_REACT, Prefs.reactions()));
        body.addView(toggle("Daily quests", Prefs.K_QUESTS, Prefs.questsOn()));
        body.addView(toggle("Notification critters (tap to dismiss)", Prefs.K_CRITTERS, Prefs.critters()));
        body.addView(toggle("Icon pranks", Prefs.K_PRANKS, Prefs.pranks()));
        final TextView petRow = label("COMPANION: " + Pets.label().toUpperCase()
                + (Pets.locked() ? "  \uD83D\uDD12" : "") + "   \u203A", 12f, Theme.ACCENT);
        petRow.setClickable(true);
        petRow.setOnClickListener(v -> PetPicker.dialog(host, () -> petRow.setText("COMPANION: "
                + Pets.label().toUpperCase() + (Pets.locked() ? "  \uD83D\uDD12" : "") + "   \u203A")));
        body.addView(petRow, block(10));
        TextView shop = label("CASTLE WORKSHOP   \u203A", 12f, Theme.ACCENT);
        shop.setClickable(true);
        shop.setOnClickListener(v -> CastleWorkshop.open(host));
        body.addView(shop, block(10));
        body.addView(toggle("Left-handed home (castle on the left)", "s_lefty", Prefs.getBool("s_lefty", false), () -> {
            if (host.home() != null) {
                host.showHome();
            }
        }));
        body.addView(toggle("Seasonal castle decorations (pumpkins, lights, hearts)", "s_seasons",
                Prefs.getBool("s_seasons", true)));
        TextView again = label("SHOW ALL TIPS AGAIN", 12f, Theme.ACCENT);
        again.setClickable(true);
        again.setOnClickListener(v -> {
            for (String id : Tips.allIds()) {
                Prefs.putInt("tip_" + id, 0);
            }
            host.toast("The wizard will explain everything again");
        });
        body.addView(again, block(10));
        body.addView(toggle("Sounds", Prefs.K_SFX, Prefs.sfx(), () -> Sfx.play(Sfx.BLIP)));
        body.addView(toggle("Charging clock (dim clock when charging and idle)", Prefs.K_NIGHT, Prefs.nightClock()));
        body.addView(toggle("Use NOVA's own Phone, Camera and Gallery", Prefs.K_NATIVE, Prefs.nativeApps()));
        body.addView(hint("When on, opening the stock phone, camera or gallery from NOVA opens NOVA's own. "
                + "Each has a STOCK button if you want the normal app."));
        TextView setup = label("RUN SETUP AGAIN", 12f, Theme.ACCENT);
        setup.setClickable(true);
        setup.setOnClickListener(v -> {
            host.showHome();
            host.root.postDelayed(host::showSetup, 900);
        });
        body.addView(setup, block(14));

        heading(body, "CASINO");
        body.addView(toggle("Cheat mode (roulette)", Prefs.K_CHEAT, Prefs.cheat()));
        body.addView(hint("A secret tell. The word COINS in the top left shows the next result: "
                + "COINS = black, coins = red, Coins = green zero."));

        heading(body, "STARTUP");
        body.addView(choice("Startup style", Prefs.K_BOOT_STYLE, new String[] {"Normal", "Cinematic"}, Prefs.bootStyle()));
        body.addView(hint("Cinematic: a longer system check with a progress bar and an animated logo after a restart."));

        heading(body, "AFTER UNLOCK");
        body.addView(toggle("Welcome animation", Prefs.K_INTRO, Prefs.intro()));
        body.addView(slider("Greeting stays for", Prefs.K_GREET_HOLD, 20, Prefs.greetHold(), v ->
                v == 0 ? "until you tap" : String.format(java.util.Locale.US, "%.1f s", v / 2f)));
        body.addView(hint("At 0 the greeting waits, and your tap carries on with the animation."));
        body.addView(toggle("Greeting by time of day", Prefs.K_GREET_AUTO, Prefs.greetAuto()));
        body.addView(hint("Your own greeting (used when the switch above is off)"));
        body.addView(input(Prefs.K_GREETING, rawGreeting(), false), block(6));

        heading(body, "GESTURES");
        body.addView(label("Shapes taught: " + GestureLayer.count(host), 14f, Theme.TEXT), block(8));
        body.addView(hint("Long-press an empty spot on the home screen, then draw a letter or symbol. "
                + "NOVA asks what it should do: open an app, or an action like spinning the wheel. "
                + "Next time you draw it, it runs."));
        TextView forget = label("FORGET ALL SHAPES", 12f, Theme.ACCENT);
        forget.setClickable(true);
        forget.setPadding(0, Theme.dp(host, 14), 0, 0);
        forget.setOnClickListener(v -> {
            GestureLayer.clear(host);
            host.toast("All shapes forgotten");
            host.showSettings();
        });
        body.addView(forget);

        heading(body, "STATS");
        body.addView(label("Unlocks: " + Prefs.unlocks() + "    Apps: " + host.repo.all.size(),
                14f, Theme.TEXT), block(8));
        body.addView(label("Slot coins: " + Prefs.getInt("slot_coins", 100), 14f, Theme.TEXT), block(8));
        if (!UsageHelper.hasAccess(host)) {
            TextView usage = label("ALLOW APP USAGE ACCESS", 12f, Theme.ACCENT);
            usage.setClickable(true);
            usage.setPadding(0, Theme.dp(host, 14), 0, 0);
            usage.setOnClickListener(v -> {
                try {
                    host.startActivity(new android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    host.toast("Not available on this phone");
                }
            });
            body.addView(usage);
            body.addView(hint("Needed for the APP USAGE and screen-time numbers on the home panel."));
        }

        heading(body, "COMFORT & CARE");
        body.addView(slider("NOVA sound volume", "s_vol", 100, Prefs.getInt("s_vol", 100), v -> v + "%"));
        body.addView(toggle("Reduce motion (calms animations, saves battery)", "s_reduce", Prefs.getBool("s_reduce", false)));
        body.addView(toggle("Warm evening tint", "s_tint", Prefs.getBool("s_tint", false), host::applyTint));
        body.addView(hint("Reduce motion keeps the castle and wizard still, like the battery saver does."));
        TextView safe = label("SAFE MODE: SWITCH THE EXTRAS OFF   \u203A", 12f, Theme.ACCENT);
        safe.setClickable(true);
        safe.setOnClickListener(v -> {
            CrashLog.safeMode(host);
            host.toast("Safe mode: castle life, surprises, critters, pranks and reactions are off");
        });
        body.addView(safe, block(10));
        TextView health = label("HEALTH CHECK   \u203A", 12f, Theme.ACCENT);
        health.setClickable(true);
        health.setOnClickListener(v -> healthCheck());
        body.addView(health, block(10));
        TextView news = label("WHAT'S NEW / CHANGELOG   \u203A", 12f, Theme.ACCENT);
        news.setClickable(true);
        news.setOnClickListener(v -> Changelog.show(host));
        body.addView(news, block(10));
        TextView bk = label("BACKUP: COPY ALL SETTINGS   \u203A", 12f, Theme.ACCENT);
        bk.setClickable(true);
        bk.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    host.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("nova", Admin.exportAll()));
            host.toast("Copied. Paste it somewhere safe.");
        });
        body.addView(bk, block(10));
        TextView rs = label("RESTORE FROM CLIPBOARD   \u203A", 12f, Theme.ACCENT);
        rs.setClickable(true);
        rs.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    host.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            android.content.ClipData d = cm.getPrimaryClip();
            String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
            int n = Admin.importAll(t);
            host.toast(n < 0 ? "The clipboard has no NOVA backup" : n + " values restored. Restart NOVA to see all of it.");
        });
        body.addView(rs, block(10));
        TextView fb = label("SEND FEEDBACK (with the last crash log)   \u203A", 12f, Theme.ACCENT);
        fb.setClickable(true);
        fb.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_SUBJECT, "NOVA " + Theme.OS_VERSION + " feedback");
            String crash = CrashLog.read(host);
            i.putExtra(android.content.Intent.EXTRA_TEXT, "NOVA " + Theme.OS_VERSION + " on " + android.os.Build.MODEL
                    + " (Android " + android.os.Build.VERSION.RELEASE + ")\n\nMy feedback:\n\n\n"
                    + (crash.isEmpty() ? "" : "--- last crash ---\n" + crash));
            host.startActivity(android.content.Intent.createChooser(i, "Send feedback"));
        });
        body.addView(fb, block(10));

        heading(body, "ADMIN");
        TextView adm = label(Castle.admin() ? "OPEN ADMIN PANEL   \u203A" : "ADMIN ACCESS   \u203A", 12f, Theme.ACCENT);
        adm.setClickable(true);
        adm.setOnClickListener(v -> {
            if (Castle.admin()) {
                AdminPanel.open(host);
                return;
            }
            final EditText pw = new EditText(host);
            pw.setHint("password");
            pw.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            new android.app.AlertDialog.Builder(host).setTitle("Admin password").setView(pw)
                    .setPositiveButton("OK", (d, w) -> {
                        if (Admin.unlock(pw.getText().toString())) {
                            host.toast("Admin mode on");
                            adm.setText("OPEN ADMIN PANEL   \u203A");
                        } else {
                            host.toast("Wrong password");
                        }
                    }).setNegativeButton("Cancel", null).show();
        });
        body.addView(adm, block(10));
        body.addView(hint("Admin mode: free castle upgrades, a panel of secret levers, and terminal commands (type adm)."));

        heading(body, "UPDATES");
        String ver;
        try {
            android.content.pm.PackageInfo pi = host.getPackageManager().getPackageInfo(host.getPackageName(), 0);
            ver = pi.versionName + " (build " + pi.versionCode + ")";
        } catch (Exception e) {
            ver = "unknown";
        }
        body.addView(label("Version " + ver, 14f, Theme.TEXT), block(8));
        TextView status = label("", 12f, Theme.DIM);
        status.setPadding(0, Theme.dp(host, 10), 0, 0);
        TextView check = label("CHECK FOR UPDATE", 12f, Theme.ACCENT);
        check.setClickable(true);
        check.setPadding(0, Theme.dp(host, 14), 0, 0);
        check.setOnClickListener(v -> Updater.check(host, status));
        body.addView(check);
        body.addView(status);

        TextView upd = label("INSTALL UPDATE FROM A FILE", 12f, Theme.ACCENT);
        upd.setClickable(true);
        upd.setPadding(0, Theme.dp(host, 14), 0, 0);
        upd.setOnClickListener(v -> host.pickUpdate());
        body.addView(upd);
        body.addView(hint("Pick a NOVA .apk file from your phone. Android then asks you to confirm."));

        TextView reset = label("RESET ALL SETTINGS", 12f, Theme.ACCENT);
        reset.setClickable(true);
        reset.setPadding(0, Theme.dp(host, 28), 0, Theme.dp(host, 16));
        reset.setOnClickListener(v -> {
            Prefs.reset();
            host.refreshTheme();
        });
        body.addView(reset);
    }

    /** The palettes, four to a row. */
    /** A row with a label, the current value and a slider underneath. */
    private void healthCheck() {
        StringBuilder sb = new StringBuilder();
        String listeners = android.provider.Settings.Secure.getString(host.getContentResolver(),
                "enabled_notification_listeners");
        sb.append(listeners != null && listeners.contains(host.getPackageName()) ? "OK  " : "OFF ")
                .append("Notification access (music card, critters, badges)\n");
        boolean usage = false;
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager) host.getSystemService(android.content.Context.APP_OPS_SERVICE);
            usage = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), host.getPackageName())
                    == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
            // unknown
        }
        sb.append(usage ? "OK  " : "OFF ").append("Usage access (APP USAGE page)\n");
        sb.append(host.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED ? "OK  " : "OFF ")
                .append("Microphone (Hey Nova, voice notes)\n");
        sb.append(host.checkSelfPermission(android.Manifest.permission.CAMERA)
                == android.content.pm.PackageManager.PERMISSION_GRANTED ? "OK  " : "OFF ")
                .append("Camera\n");
        sb.append(WeatherData.hasCity() ? "OK  " : "OFF ").append("Weather city (castle weather)\n");
        sb.append(Saver.on() ? "ON  " : "off ").append("Battery saver right now\n");
        Runtime rt = Runtime.getRuntime();
        sb.append("\nMemory ").append((rt.totalMemory() - rt.freeMemory()) >> 20).append(" MB of ")
                .append(rt.maxMemory() >> 20).append(" MB\nNOVA ").append(Theme.OS_VERSION);
        new android.app.AlertDialog.Builder(host).setTitle("Health check").setMessage(sb.toString())
                .setPositiveButton("OK", null).show();
    }

    private View slider(String text, final String key, int max, int current,
                        final java.util.function.IntFunction<String> format) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(VERTICAL);
        box.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 4));

        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        top.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView value = label(format.apply(current), 12f, Theme.ACCENT);
        top.addView(value);
        box.addView(top);

        android.widget.SeekBar bar = new android.widget.SeekBar(host);
        bar.setMax(max);
        bar.setProgress(current);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                value.setText(format.apply(progress));
                if (fromUser) {
                    Prefs.putInt(key, progress);
                }
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar sb) {
            }
        });
        box.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private String rawGreeting() {
        String g = Prefs.getString(Prefs.K_GREETING, "welcome");
        return g;
    }

    /** Sets, changes or removes the NOVA PIN. */
    private View pinRow() {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        TextView l = new TextView(host);
        l.setText(Prefs.hasPin() ? "NOVA PIN (" + Prefs.pinLength() + " digits)" : "NOVA PIN");
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView set = label(Prefs.hasPin() ? "CHANGE" : "SET", 12f, Theme.ACCENT);
        set.setClickable(true);
        set.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), Theme.dp(host, 10), Theme.dp(host, 6));
        set.setOnClickListener(v -> askPin());
        r.addView(set);
        if (Prefs.hasPin()) {
            TextView rm = label("REMOVE", 12f, Theme.DIM);
            rm.setClickable(true);
            rm.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), 0, Theme.dp(host, 6));
            rm.setOnClickListener(v -> {
                Prefs.clearPin();
                Prefs.putBool(Prefs.K_BIO, false);
                host.toast("PIN removed");
                host.showSettings();
            });
            r.addView(rm);
        }
        return r;
    }

    private void askPin() {
        final EditText e = new EditText(host);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setHint("4 to 8 digits");
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(Theme.DIM);
        e.setPadding(Theme.dp(host, 24), Theme.dp(host, 16), Theme.dp(host, 24), Theme.dp(host, 16));
        new android.app.AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Choose a PIN")
                .setView(e)
                .setPositiveButton("Save", (d, w) -> {
                    String p = e.getText().toString().trim();
                    if (p.length() < 4 || p.length() > 8) {
                        host.toast("Use 4 to 8 digits");
                        return;
                    }
                    Prefs.setPin(p);
                    host.toast("PIN saved");
                    host.showSettings();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** The palettes, four to a row. */
    private View accentRow() {
        LinearLayout all = new LinearLayout(host);
        all.setOrientation(VERTICAL);
        int per = 4;
        for (int start = 0; start < Theme.PRESET_NAMES.length; start += per) {
            LinearLayout row = new LinearLayout(host);
            row.setOrientation(HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            for (int i = start; i < Math.min(start + per, Theme.PRESET_NAMES.length); i++) {
                final int idx = i;
                LinearLayout col = new LinearLayout(host);
                col.setOrientation(VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.setClickable(true);
                col.setPadding(0, Theme.dp(host, 4), 0, Theme.dp(host, 4));
                col.setOnClickListener(v -> {
                    Prefs.putInt(Prefs.K_ACCENT, idx);
                    host.refreshTheme();
                });

                View dot = new View(host);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(Theme.presetAccent(i));
                if (Prefs.accent() == i) {
                    g.setStroke(Theme.dp(host, 3), Theme.TEXT);
                }
                dot.setBackground(g);
                col.addView(dot, new LinearLayout.LayoutParams(Theme.dp(host, 44), Theme.dp(host, 44)));

                TextView name = label(Theme.PRESET_NAMES[i].toUpperCase(), 10f, Theme.DIM);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                np.topMargin = Theme.dp(host, 6);
                col.addView(name, np);

                row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            }
            all.addView(row);
        }
        return all;
    }

    private View toggle(String text, final String key, boolean value) {
        return toggle(text, key, value, null);
    }

    private View toggle(String text, final String key, boolean value, final Runnable after) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));

        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch s = new Switch(host);
        s.setChecked(value);
        s.setOnCheckedChangeListener((b, on) -> {
            Prefs.putBool(key, on);
            if (after != null) {
                r.post(after);
            }
        });
        r.addView(s);
        return r;
    }

    /** A row that cycles through a few options each time you tap its value. */
    private View choice(String text, final String key, final String[] options, int current) {
        return choice(text, key, options, current, null);
    }

    private View choice(String text, final String key, final String[] options, int current, final Runnable after) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));

        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final int[] idx = {Math.max(0, Math.min(options.length - 1, current))};
        final TextView v = label(options[idx[0]].toUpperCase(), 12f, Theme.ACCENT);
        v.setClickable(true);
        v.setOnClickListener(x -> {
            idx[0] = (idx[0] + 1) % options.length;
            Prefs.putInt(key, idx[0]);
            v.setText(options[idx[0]].toUpperCase());
            if (after != null) {
                after.run();
            }
        });
        r.addView(v);
        return r;
    }

    private EditText input(final String key, String value, boolean multi) {
        EditText e = new EditText(host);
        e.setText(value);
        e.setTextSize(14f);
        e.setTextColor(Theme.TEXT);
        e.setHint("type here");
        e.setHintTextColor(Theme.DIM);
        e.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        e.setPadding(Theme.dp(host, 14), Theme.dp(host, 12), Theme.dp(host, 14), Theme.dp(host, 12));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                Prefs.putString(key, s.toString());
            }
        });
        return e;
    }

    private void heading(LinearLayout body, String text) {
        TextView t = label(text, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams p = block(24);
        body.addView(t, p);
    }

    private void hint(LinearLayout body, String text) {
        body.addView(hint(text));
    }

    private TextView hint(String text) {
        TextView t = label(text, 12f, Theme.DIM);
        t.setTypeface(android.graphics.Typeface.DEFAULT);
        t.setPadding(0, Theme.dp(host, 14), 0, 0);
        return t;
    }

    private TextView label(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams block(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = Theme.dp(host, topDp);
        return p;
    }
}
