package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The CASTLE page of the status panel: a summary and the way into the workshop. */
final class CastlePage extends LinearLayout {
    private final NovaActivity host;
    private final TextView info;
    private final TextView sub;

    CastlePage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        setPadding(Theme.dp(host, 20), Theme.dp(host, 6), Theme.dp(host, 20), Theme.dp(host, 6));
        info = new TextView(host);
        info.setTypeface(Theme.MONO);
        info.setTextSize(13f);
        info.setTextColor(Theme.TEXT);
        info.setGravity(Gravity.CENTER);
        addView(info);
        sub = new TextView(host);
        sub.setTypeface(Theme.MONO);
        sub.setTextSize(10f);
        sub.setTextColor(Theme.DIM);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        addView(sub);
        TextView b = new TextView(host);
        b.setText("OPEN WORKSHOP");
        b.setTypeface(Theme.MONO);
        b.setTextSize(12f);
        b.setLetterSpacing(0.1f);
        b.setTextColor(Theme.BG);
        b.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
        b.setPadding(Theme.dp(host, 20), Theme.dp(host, 9), Theme.dp(host, 20), Theme.dp(host, 9));
        b.setClickable(true);
        b.setOnClickListener(v -> CastleWorkshop.open(host));
        addView(b);
        refresh();
    }

    void refresh() {
        int s = Castle.stage();
        info.setText("Stage " + s + " / 10" + (s < 10 ? "\nNext: " + Castle.NAMES[s] + " (" + Castle.COST[s] + ")"
                : "\nThe castle is finished!"));
        sub.setText("Coins: " + Coins.get() + (Castle.style() != 0 ? "  Style: " + Castle.STYLES[Castle.style()] : ""));
    }
}
