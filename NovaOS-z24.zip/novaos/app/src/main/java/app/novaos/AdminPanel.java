package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.InputType;
import android.view.Choreographer;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** The admin panel: every secret lever in one place. Only reachable with admin mode on. */
final class AdminPanel extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout body;

    private AdminPanel(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF4060410);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 18);
        body.setPadding(pad, Theme.dp(host, 40), pad, Theme.dp(host, 60));
        sv.addView(body);
        addView(sv, new LayoutParams(-1, -1));
        build();
    }

    static void open(NovaActivity host) {
        if (!Admin.on()) {
            host.toast("Admin mode is off");
            return;
        }
        host.showOverlay(new AdminPanel(host));
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    // ------------------------------------------------------------------ small helpers

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private void head(String s) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, Theme.dp(host, 18), 0, Theme.dp(host, 6));
        body.addView(t);
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.TEXT);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setPadding(Theme.dp(host, 11), Theme.dp(host, 8), Theme.dp(host, 11), Theme.dp(host, 8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private final List<View> pending = new ArrayList<>();

    private void add(String label, Runnable r) {
        pending.add(chip(label, r));
    }

    private void flush() {
        LinearLayout row = null;
        int used = 0;
        int max = host.getResources().getDisplayMetrics().widthPixels - Theme.dp(host, 36);
        for (View c : pending) {
            c.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int w = c.getMeasuredWidth() + Theme.dp(host, 8);
            if (row == null || used + w > max) {
                row = new LinearLayout(host);
                row.setPadding(0, 0, 0, Theme.dp(host, 6));
                body.addView(row);
                used = 0;
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Theme.dp(host, 6);
            row.addView(c, lp);
            used += w;
        }
        pending.clear();
    }

    private void note(String s) {
        body.addView(text(s, 10f, Theme.DIM));
    }

    private void ask(String title, String hint, boolean number, final java.util.function.Consumer<String> done) {
        final EditText in = new EditText(host);
        in.setHint(hint);
        in.setTypeface(Theme.MONO);
        in.setInputType(number ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(host).setTitle(title).setView(in)
                .setPositiveButton("OK", (d, w) -> done.accept(in.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    private void act(String logLine, Runnable r) {
        Admin.log(logLine);
        r.run();
        Sfx.play(Sfx.BLIP);
    }

    private void build() {
        body.removeAllViews();
        TextView title = text("ADMIN PANEL", 16f, Theme.TEXT);
        title.setLetterSpacing(0.2f);
        body.addView(title);
        note("Coins " + Coins.get() + "   Castle stage " + Castle.stage() + "   NOVA " + Theme.OS_VERSION);

        head("COINS");
        add("+100", () -> act("coins +100", () -> Coins.add(100)));
        add("+1000", () -> act("coins +1000", () -> Coins.add(1000)));
        add("+10000", () -> act("coins +10000", () -> Coins.add(10000)));
        add("SET...", () -> ask("Set coins", "amount", true, s -> {
            if (!s.isEmpty()) {
                Admin.setCoins(Integer.parseInt(s));
                build();
            }
        }));
        add("ZERO", () -> act("coins zero", () -> Admin.setCoins(0)));
        flush();

        head("SURPRISES NOW");
        add("STAR", () -> surprise(0));
        add("CHEST", () -> surprise(1));
        add("GOLD COIN", () -> surprise(2));
        add("ROAST PIG", () -> act("pig drop", host::dropPig));
        flush();
        note("Close this panel to see them on the home screen.");

        head("DRAGON");
        add("FLY", () -> dragon("fly"));
        add("FIRE", () -> dragon("fire"));
        add("WAKE", () -> dragon("wake"));
        add("SLEEP", () -> dragon("sleep"));
        add("RETURN FLIGHT", () -> dragon("home"));
        add("BRING PIG", () -> {
            Prefs.putInt("dr_pig_t", 0);
            act("dragon pig", () -> Castle.orderPig(host));
        });
        flush();
        add("RECALL NOW", () -> act("dragon recalled", Castle::recall));
        add(Castle.locked() ? "UNLOCK TOWER" : "LOCK ON TOWER", () -> {
            Admin.log("dragon lock " + !Castle.locked());
            Castle.setLocked(!Castle.locked());
            build();
        });
        add("SEND AWAY 1 DAY", () -> act("dragon away 24h", () -> Castle.sendAway(24)));
        add("DRAGON SAYS...", () -> ask("Dragon says", "text", false, s -> dragon("say:" + s)));
        flush();

        head("TIME TRAVEL");
        add("REAL", () -> act("hour real", () -> Admin.fakeTime(-1)));
        for (int h : new int[] {0, 6, 9, 12, 18, 22}) {
            final int hh = h;
            add(h + ":00", () -> act("hour " + hh, () -> Admin.fakeTime(hh)));
        }
        flush();
        note("Changes the castle's sky. Now: " + (Prefs.getInt("adm_hour", -1) < 0 ? "real time" : Prefs.getInt("adm_hour", -1) + ":00"));

        head("CASTLE WEATHER");
        add("AUTO", () -> act("weather auto", () -> Admin.forceWeather(-1)));
        add("CLEAR", () -> act("weather clear", () -> Admin.forceWeather(0)));
        add("RAIN", () -> act("weather rain", () -> Admin.forceWeather(1)));
        add("SNOW", () -> act("weather snow", () -> Admin.forceWeather(2)));
        add("STORM", () -> act("weather storm", () -> Admin.forceWeather(3)));
        flush();

        head("PETS");
        add("UNLOCK PET CHOICE", () -> act("pet unlocked", () -> {
            Admin.unlockPets();
            host.toast("Pet can be changed now");
        }));
        add("FEED FULL", () -> act("pets fed", () -> Admin.setPet(100, 100)));
        add("STARVE", () -> act("pets starved", () -> Admin.setPet(5, 5)));
        flush();

        head("QUESTS");
        add("COMPLETE ALL", () -> act("quests done", () -> Admin.completeQuests(host)));
        add("RESET", () -> act("quests reset", Admin::resetQuests));
        add("RE-ROLL", () -> act("quests re-rolled", () -> Prefs.putInt("q_day", 0)));
        add("STREAK +1", () -> act("streak +1", () -> Prefs.putInt("q_streak", Prefs.getInt("q_streak", 0) + 1)));
        add("STREAK 0", () -> act("streak 0", () -> Prefs.putInt("q_streak", 0)));
        flush();

        head("WIZARD");
        add("SAY...", () -> ask("The wizard says", "text", false, s -> {
            if (!s.isEmpty()) {
                Admin.log("wizard says: " + s);
                host.wizardSay(s);
            }
        }));
        add("SLEEP", () -> wiz(true));
        add("WAKE", () -> wiz(false));
        add("SUMMON CRITTER", () -> act("critter", () -> {
            if (host.root != null) {
                new CritterView(host, "admin").start(host.root);
            }
        }));
        add("ICON PRANK", () -> act("prank", () -> {
            if (host.home() != null) {
                host.home().prankNow();
            }
        }));
        add("SUGGESTION CHAIN", () -> act("nudge chain", () -> {
            host.hideOverlay();
            host.postHome(() -> Nudge.force(host), 800);
        }));
        flush();

        head("BATTERY");
        boolean forced = Prefs.getInt("adm_saver", 0) == 1;
        add(forced ? "SAVER: FORCED ON (tap: off)" : "FORCE SAVER ON", () -> {
            Admin.log("saver forced " + !forced);
            Prefs.putInt("adm_saver", forced ? 0 : 1);
            Saver.refresh();
            build();
        });
        flush();
        add("FAKE LEVEL OFF", () -> fakeBatt(-1));
        for (int b : new int[] {5, 15, 21, 50, 100}) {
            final int bb = b;
            add(b + "%", () -> fakeBatt(bb));
        }
        flush();

        head("CASINO");
        add(Prefs.cheat() ? "ROULETTE CHEAT: ON (tap: off)" : "ROULETTE CHEAT: OFF (tap: on)", () -> {
            Prefs.putBool(Prefs.K_CHEAT, !Prefs.cheat());
            Admin.log("roulette cheat " + Prefs.cheat());
            build();
        });
        flush();
        note("Cheat on: the word COINS in roulette shows the next colour. Green = Coins, red = coins, black = COINS.");

        head("BADGES");
        add("UNLOCK ALL", () -> act("badges all", () -> Admin.unlockAllBadges(host)));
        add("RESET ALL", () -> act("badges reset", Admin::resetBadges));
        flush();

        head("DEBUG");
        add("CRASH LOG", () -> showText("Crash log", CrashLog.read(host).isEmpty() ? "(no crash saved)" : CrashLog.read(host)));
        add("CLEAR CRASH LOG", () -> act("crash log cleared", () -> CrashLog.clear(host)));
        add(Prefs.getInt("adm_fps", 0) == 1 ? "FPS: ON (tap: off)" : "FPS + MEMORY", () -> {
            boolean on = Prefs.getInt("adm_fps", 0) == 1;
            Prefs.putInt("adm_fps", on ? 0 : 1);
            fps(!on);
            build();
        });
        add("ADMIN LOG", () -> showText("Admin log", Admin.getLog()));
        flush();

        head("BACKUP");
        add("COPY ALL SETTINGS", () -> {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("nova", Admin.exportAll()));
            Admin.log("settings exported");
            host.toast("Copied. Paste it somewhere safe.");
        });
        add("RESTORE FROM CLIPBOARD", () -> {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm.getPrimaryClip();
            String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
            int n = Admin.importAll(t);
            host.toast(n < 0 ? "The clipboard has no NOVA backup" : n + " values restored");
        });
        flush();

        head("RESET DATA (cannot be undone)");
        add("CASTLE", () -> reset("cs_", "castle"));
        add("DRAGON", () -> reset("dr_", "dragon"));
        add("PETS", () -> reset("pet", "pets"));
        add("WARDROBE", () -> {
            Prefs.removePrefix("own_");
            reset("wz_", "wardrobe");
        });
        add("COINS to 100", () -> act("coins 100", () -> Admin.setCoins(100)));
        flush();

        head("ADMIN MODE");
        add("TURN ADMIN OFF", () -> {
            Admin.lockOff();
            host.hideOverlay();
            host.toast("Admin mode off");
        });
        flush();
        note("Terminal: type 'adm' for secret commands.");
    }

    private void surprise(int type) {
        Admin.log("surprise " + type);
        host.hideOverlay();
        if (host.eventLayer != null) {
            host.eventLayer.spawnNow(type);
        } else {
            host.toast("Go to the home screen first");
        }
    }

    private void dragon(String what) {
        Admin.log("dragon " + what);
        if (host.castle == null) {
            host.toast("Go to the home screen first, the castle must be visible");
            return;
        }
        host.hideOverlay();
        host.castle.dragonDo(what);
    }

    private void wiz(boolean sleep) {
        Admin.log(sleep ? "wizard sleeps" : "wizard wakes");
        WizardView w = host.wizardView();
        if (w != null) {
            w.sleepNow(sleep);
        }
    }

    private void fakeBatt(int level) {
        Admin.log("fake battery " + level);
        Prefs.putInt("adm_batt", level);
        Saver.refresh();
        host.toast(level < 0 ? "Real battery level" : "Pretending battery is " + level + "%");
    }

    private void reset(String prefix, String name) {
        final String p = prefix;
        new AlertDialog.Builder(host).setTitle("Reset " + name + "?")
                .setPositiveButton("RESET", (d, w) -> {
                    Admin.resetFeature(p, name);
                    host.syncWizard();
                    build();
                }).setNegativeButton("Cancel", null).show();
    }

    private void showText(String title, final String text) {
        TextView t = text(text, 10f, Theme.TEXT);
        t.setTextIsSelectable(true);
        t.setPadding(Theme.dp(host, 16), Theme.dp(host, 10), Theme.dp(host, 16), Theme.dp(host, 10));
        ScrollView sv = new ScrollView(host);
        sv.addView(t);
        new AlertDialog.Builder(host).setTitle(title).setView(sv)
                .setPositiveButton("Copy", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("nova", text));
                }).setNegativeButton("Close", null).show();
    }

    // ------------------------------------------------------------------ FPS and memory

    private static FpsView fpsView;

    /** Shows or hides the frame rate and memory counter above everything. */
    static void fps(NovaActivity host, boolean on) {
        if (!on) {
            if (fpsView != null && fpsView.getParent() != null) {
                ((android.view.ViewGroup) fpsView.getParent()).removeView(fpsView);
            }
            fpsView = null;
            return;
        }
        if (fpsView != null || host.root == null) {
            return;
        }
        fpsView = new FpsView(host);
        fpsView.setTag(NovaActivity.KEEP);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.TOP | android.view.Gravity.START);
        lp.topMargin = Theme.dp(host, 2);
        lp.leftMargin = Theme.dp(host, 4);
        host.root.addView(fpsView, lp);
    }

    private void fps(boolean on) {
        fps(host, on);
    }

    private static final class FpsView extends TextView implements Choreographer.FrameCallback {
        private int frames;
        private long since;
        private boolean running;

        FpsView(Context c) {
            super(c);
            setTypeface(Theme.MONO);
            setTextSize(9f);
            setTextColor(0xFF7CFF8A);
            setBackgroundColor(0x88000000);
            setPadding(8, 2, 8, 2);
            setElevation(100f);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            running = true;
            since = System.nanoTime();
            Choreographer.getInstance().postFrameCallback(this);
        }

        @Override
        protected void onDetachedFromWindow() {
            running = false;
            super.onDetachedFromWindow();
        }

        @Override
        public void doFrame(long nanos) {
            if (!running) {
                return;
            }
            frames++;
            long now = System.nanoTime();
            if (now - since >= 1_000_000_000L) {
                Runtime rt = Runtime.getRuntime();
                long used = (rt.totalMemory() - rt.freeMemory()) >> 20;
                setText(frames + " fps  " + used + " MB");
                frames = 0;
                since = now;
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    }
}
