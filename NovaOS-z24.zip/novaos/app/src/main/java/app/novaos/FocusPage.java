package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A pomodoro timer: 25 minutes of focus pay coins, then a 5 minute break. Runs while the home screen is open. */
final class FocusPage extends LinearLayout {
    private final NovaActivity host;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final TextView time;
    private final TextView state;
    private final TextView btn;
    private long endAt;      // 0 when idle
    private boolean onBreak;
    private int mins = 25;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            update();
            if (endAt != 0) {
                h.postDelayed(this, 500);
            }
        }
    };

    FocusPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        time = new TextView(host);
        time.setTypeface(Theme.MONO);
        time.setTextSize(34f);
        time.setTextColor(Theme.TEXT);
        time.setGravity(Gravity.CENTER);
        time.setClickable(true);
        time.setOnClickListener(v -> {
            if (endAt == 0) {
                mins = mins == 25 ? 15 : mins == 15 ? 45 : mins == 45 ? 5 : 25;
                update();
            }
        });
        addView(time);
        state = new TextView(host);
        state.setTypeface(Theme.MONO);
        state.setTextSize(10f);
        state.setTextColor(Theme.DIM);
        state.setGravity(Gravity.CENTER);
        addView(state);
        btn = new TextView(host);
        btn.setTypeface(Theme.MONO);
        btn.setTextSize(12f);
        btn.setLetterSpacing(0.1f);
        btn.setTextColor(Theme.BG);
        btn.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
        btn.setPadding(Theme.dp(host, 22), Theme.dp(host, 9), Theme.dp(host, 22), Theme.dp(host, 9));
        btn.setClickable(true);
        btn.setOnClickListener(v -> toggle());
        LayoutParams lp = new LayoutParams(-2, -2);
        lp.topMargin = Theme.dp(host, 8);
        addView(btn, lp);
        update();
    }

    private void toggle() {
        if (endAt != 0) {
            endAt = 0;
            onBreak = false;
            state.setText("stopped");
        } else {
            onBreak = false;
            endAt = System.currentTimeMillis() + mins * 60000L;
            Sfx.play(Sfx.BLIP);
            h.post(tick);
        }
        update();
    }

    private void update() {
        if (endAt != 0 && System.currentTimeMillis() >= endAt) {
            if (!onBreak) {
                int prize = mins >= 45 ? 30 : mins >= 25 ? 15 : mins >= 15 ? 8 : 2;
                Coins.add(prize);
                Sfx.play(Sfx.WIN);
                host.buzz(60);
                host.wizardSay("Focus done! +" + prize + " coins. Take a 5 minute break.");
                Quests.event(host, "coin");
                onBreak = true;
                endAt = System.currentTimeMillis() + 5 * 60000L;
            } else {
                endAt = 0;
                onBreak = false;
                host.wizardSay("Break over. Ready for another round?");
                Sfx.play(Sfx.BLIP);
            }
        }
        long left = endAt == 0 ? mins * 60000L : Math.max(0, endAt - System.currentTimeMillis());
        long s = left / 1000;
        time.setText(String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60));
        state.setText(endAt == 0 ? "tap the time to change: " + mins + " min" : onBreak ? "break" : "focus");
        btn.setText(endAt == 0 ? "START FOCUS" : "STOP");
    }

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (endAt != 0) {
            h.post(tick);
        }
    }
}
