package app.novaos;

/** The play coins shared by the whole casino. Just for fun, no real money. */
final class Coins {
    private Coins() {}

    static int get() {
        return Prefs.getInt("slot_coins", 100);
    }

    static void add(int n) {
        Prefs.putInt("slot_coins", Math.max(0, get() + n));
    }
}
