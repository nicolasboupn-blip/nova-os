package app.novaos;

import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.Random;

/**
 * Merlo the wizard. He stands somewhere on the screen, bobs, wanders to a new spot now and then, can be dragged,
 * and talks in a speech bubble the first time you discover something. Tap him for a hint.
 */
final class WizardView extends View {
    private static final int SW = 29;     // sprite size in pixels
    private static final int SH = 49;
    private static final float ORB_X = 5f; // where the glowing staff tip is in the sprite
    private static final float ORB_Y = 8.5f;

    private final NovaActivity host;
    private final Bitmap sprite;
    private final int scale;
    private final Paint p = new Paint();
    private final Rect src = new Rect(0, 0, SW, SH);
    private final Rect dst = new Rect();
    private final Random rnd = new Random();
    private final long born = System.nanoTime();
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private View bubble;
    private RadialGradient glow;
    private ValueAnimator walk;
    private boolean moving;
    private boolean dragging;
    private float downX, downY, startTx, startTy;
    private long pausedUntil;
    private long lastActive = System.currentTimeMillis();
    private boolean sleeping;
    private boolean sleepingWas;

    private String parrotLine() {
        String[] l = {"Squawk! Pretty wizard!", "Pieces of eight!", "Who's a clever bird? ME.", "Squawk! Snacks?",
            "Hello! Hello!", "Don't forget to spin the slots!"};
        return l[rnd.nextInt(l.length)];
    }

    boolean isSleeping() {
        return sleeping;
    }

    void sleepNow(boolean on) {
        if (on) {
            sleeping = true;
        } else {
            wake(false);
        }
    }

    private void wake(boolean grumble) {
        lastActive = System.currentTimeMillis();
        if (sleeping) {
            sleeping = false;
            if (grumble) {
                say("Huh?! I was only resting my eyes.");
            }
        }
    }
    private final Runnable wander = new Runnable() {
        @Override
        public void run() {
            if (!isAttachedToWindow()) {
                return;
            }
            if (System.currentTimeMillis() > pausedUntil && bubble == null && !dragging && !atHome()) {
                float[][] spots = {{0.70f, 0.72f}, {0.02f, 0.70f}, {0.70f, 0.30f}, {0.02f, 0.34f}, {0.38f, 0.76f}};
                float[] s = spots[rnd.nextInt(spots.length)];
                goTo(s[0], s[1]);
            }
            postDelayed(this, 40000 + rnd.nextInt(50000));
        }
    };

    WizardView(NovaActivity host) {
        super(host);
        this.host = host;
        setTag(NovaActivity.KEEP);
        float d = host.getResources().getDisplayMetrics().density;
        scale = Math.max(2, Math.round(d * 1.8f));
        sprite = loadSprite(host);
        p.setFilterBitmap(false);
        p.setAntiAlias(false);
        setElevation(Theme.dp(host, 6));
    }

    /** The wizard picture, or null if it is missing. */
    private int glowCol;
    private Bitmap tinted;
    private int tintKey = -1;
    private float tintAt = -9f;

    /** The wizard with his chosen robe colour (hue-shifted from the original teal). */
    private Bitmap robed(float t) {
        int robe = Castle.robe();
        if (robe == 0 || sprite == null) {
            return sprite;
        }
        boolean rainbow = robe == Castle.ROBES.length - 1;
        if (tinted != null && !rainbow && tintKey == robe) {
            return tinted;
        }
        if (rainbow && tinted != null && t - tintAt < 0.2f) {
            return tinted;
        }
        tintAt = t;
        tintKey = robe;
        if (tinted == null) {
            tinted = Bitmap.createBitmap(sprite.getWidth(), sprite.getHeight(), Bitmap.Config.ARGB_8888);
        }
        float target = rainbow ? (t * 50f) % 360f : Castle.ROBE_HUE[robe];
        float vmul = robe == 4 ? 0.75f : 1f;
        int w = sprite.getWidth();
        int h = sprite.getHeight();
        int[] px = new int[w * h];
        sprite.getPixels(px, 0, w, 0, 0, w, h);
        float[] hsv = new float[3];
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            if (c >>> 24 == 0) {
                continue;
            }
            android.graphics.Color.colorToHSV(c, hsv);
            if (hsv[1] > 0.25f && hsv[0] > 150f && hsv[0] < 250f) {
                hsv[0] = target;
                hsv[2] = Math.min(1f, hsv[2] * vmul * 1.05f);
                px[i] = (android.graphics.Color.HSVToColor(hsv) & 0x00FFFFFF) | (c & 0xFF000000);
            }
        }
        tinted.setPixels(px, 0, w, 0, 0, w, h);
        return tinted;
    }

    static Bitmap loadSprite(android.content.Context c) {
        int id = c.getResources().getIdentifier("wizard", "drawable", c.getPackageName());
        if (id == 0) {
            return null;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeResource(c.getResources(), id, o);
    }

    int spriteW() {
        return SW * scale;
    }

    int spriteH() {
        return SH * scale;
    }

    FrameLayout.LayoutParams params() {
        return new FrameLayout.LayoutParams(spriteW() + scale * 6, spriteH() + scale * 6, Gravity.TOP | Gravity.START);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(() -> {
            float fx = Prefs.getInt("wiz_x", 70) / 100f;
            float fy = Prefs.getInt("wiz_y", 72) / 100f;
            place(fx, fy);
        });
        postDelayed(wander, 30000);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(wander);
        if (walk != null) {
            walk.cancel();
        }
        super.onDetachedFromWindow();
    }

    /** True while he is at home in his castle: he is not drawn and does not catch touches. */
    private boolean atHome() {
        return host.wizInside && Prefs.castle();
    }

    /** Walks out of the castle door and carries on as before. */
    void emerge() {
        if (!atHome() && !host.wizInside) {
            return;
        }
        host.wizInside = false;
        if (getParent() == null) {
            return;
        }
        CastleView cv = host.castle;
        float tx;
        float ty;
        if (cv != null) {
            float[] d = cv.door((View) getParent());
            tx = d[0] - getWidth() / 2f;
            ty = d[1] - getHeight();
            cv.puff();
        } else {
            tx = getTranslationX();
            ty = getTranslationY();
        }
        setTranslationX(Math.max(0, Math.min(maxX(), tx)));
        setTranslationY(Math.max(0, Math.min(maxY(), ty)));
        setPivotX(getWidth() / 2f);
        setPivotY(getHeight());
        setAlpha(0f);
        setScaleX(0.25f);
        setScaleY(0.25f);
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).withEndAction(() -> {
            if (host.castle != null) {
                float[] d = host.castle.door((View) getParent());
                goToPx(d[0] - getWidth() / 2f - Theme.dp(host, 30), d[1] + Theme.dp(host, 56));
            }
        }).start();
        pausedUntil = System.currentTimeMillis() + 20000;
        invalidate();
    }

    /** Walks back to the door and goes inside. */
    void goHome() {
        CastleView cv = host.castle;
        if (cv == null || getParent() == null) {
            return;
        }
        dismissBubble(false);
        queue.clear();
        float[] d = cv.door((View) getParent());
        goToPx(d[0] - getWidth() / 2f, d[1] - getHeight(), () -> {
            cv.puff();
            setPivotX(getWidth() / 2f);
            setPivotY(getHeight());
            animate().alpha(0f).scaleX(0.25f).scaleY(0.25f).setDuration(450).withEndAction(() -> {
                host.wizInside = true;
                setAlpha(1f);
                setScaleX(1f);
                setScaleY(1f);
                invalidate();
            }).start();
        });
    }

    private void goToPx(float tx, float ty) {
        goToPx(tx, ty, null);
    }

    private void goToPx(float tx, float ty, final Runnable done) {
        if (getParent() == null) {
            return;
        }
        final float ex = Math.max(0, Math.min(maxX(), tx));
        final float ey = Math.max(0, Math.min(maxY(), ty));
        final float x0 = getTranslationX();
        final float y0 = getTranslationY();
        if (walk != null) {
            walk.cancel();
        }
        moving = true;
        walk = ValueAnimator.ofFloat(0f, 1f);
        walk.setDuration(2200);
        walk.setInterpolator(new DecelerateInterpolator(1.3f));
        walk.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            setTranslationX(x0 + (ex - x0) * t);
            setTranslationY(y0 + (ey - y0) * t);
        });
        walk.addListener(new android.animation.AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override
            public void onAnimationCancel(android.animation.Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                moving = false;
                if (done != null && !cancelled) {
                    done.run();
                }
            }
        });
        walk.start();
    }

    private float maxX() {
        return Math.max(0, ((View) getParent()).getWidth() - getWidth());
    }

    private float maxY() {
        return Math.max(0, ((View) getParent()).getHeight() - getHeight());
    }

    private void place(float fx, float fy) {
        if (getParent() == null) {
            return;
        }
        setTranslationX(Math.max(0, Math.min(maxX(), maxX() * fx)));
        setTranslationY(Math.max(0, Math.min(maxY(), maxY() * fy)));
    }

    private void goTo(float fx, float fy) {
        if (getParent() == null) {
            return;
        }
        final float tx = Math.max(0, Math.min(maxX(), maxX() * fx));
        final float ty = Math.max(0, Math.min(maxY(), maxY() * fy));
        final float x0 = getTranslationX();
        final float y0 = getTranslationY();
        if (walk != null) {
            walk.cancel();
        }
        moving = true;
        walk = ValueAnimator.ofFloat(0f, 1f);
        walk.setDuration(2200);
        walk.setInterpolator(new DecelerateInterpolator(1.3f));
        walk.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            setTranslationX(x0 + (tx - x0) * t);
            setTranslationY(y0 + (ty - y0) * t);
        });
        walk.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                moving = false;
            }
        });
        walk.start();
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        if (atHome()) {
            postInvalidateDelayed(300); // wakes up again when he comes out
            return;
        }
        float t = (System.nanoTime() - born) / 1e9f;
        if (!sleeping && Prefs.reactions() && !moving && bubble == null && host.homeIdle()
                && System.currentTimeMillis() - lastActive > 240000) {
            sleeping = true;
        }
        float bob = sleeping || Saver.on() && !moving ? 0f
                : (float) Math.sin(t * (moving ? 7.0 : 2.0)) * scale * (moving ? 1.6f : 0.9f);
        float ox = scale * 3;
        float oy = scale * 3 + bob;
        // the glow of the staff tip, pulsing
        float orbX = ox + ORB_X * scale;
        float orbY = oy + ORB_Y * scale;
        final boolean eco = Saver.on();
        float pulse = eco ? 0.85f : 0.75f + 0.25f * (float) Math.sin(t * 3.2);
        int orbCol = Castle.ORB_RGB[Castle.orb()];
        if (glow == null || glowCol != orbCol) {
            glowCol = orbCol;
            int rgb = orbCol & 0xFFFFFF;
            glow = new RadialGradient(0f, 0f, 1f, new int[] {0x99000000 | rgb, 0x33000000 | rgb, rgb},
                    new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }
        c.save();
        c.translate(orbX, orbY);
        c.scale(scale * 9f * pulse, scale * 9f * pulse);
        p.setShader(glow);
        c.drawCircle(0f, 0f, 1f, p);
        p.setShader(null);
        c.restore();
        // tiny sparks drifting up from the orb
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < (eco ? 0 : 5); i++) {
            float ph = (t * 0.55f + i * 0.2f) % 1f;
            float sx = orbX + (float) Math.sin(i * 2.3 + t) * scale * 3f;
            float sy = orbY - ph * scale * 12f;
            p.setColor(((int) (200 * (1f - ph)) << 24) | (Castle.ORB_RGB[Castle.orb()] & 0xFFFFFF));
            c.drawRect(sx, sy, sx + scale, sy + scale, p);
        }
        if (sprite != null) {
            dst.set((int) ox, (int) oy, (int) ox + SW * scale, (int) oy + SH * scale);
            if (sleeping) {
                c.save();
                c.rotate(-5f, ox + SW * scale / 2f, oy + SH * scale);
            }
            c.drawBitmap(robed(t), src, dst, p);
            if (sleeping) {
                c.restore();
            }
        }
        int flap = !sleeping && (int) (t * 3f) % 4 == 0 ? 1 : 0;
        if (Pets.kind(0) == Pets.PARROT) {
            Pets.drawParrot(c, p, ox + 21 * scale, oy + 17 * scale + (sleeping ? scale : 0), scale, flap);
        }
        if (Pets.kind(1) == Pets.PARROT && Castle.has(7)) {
            Pets.drawParrot(c, p, ox + 3 * scale, oy + 18 * scale + (sleeping ? scale : 0), scale, flap, true);
        }
        if (sleeping) {
            p.setColor(0xCCB9C8FF);
            p.setTextSize(scale * 7f);
            float zy = (t % 2.4f) / 2.4f;
            p.setAlpha((int) (255 * (1f - zy)));
            c.drawText("Z", ox + 22 * scale, oy + 8 * scale - zy * scale * 8f, p);
            p.setTextSize(scale * 5f);
            c.drawText("z", ox + 25 * scale, oy + 12 * scale - zy * scale * 6f, p);
            p.setAlpha(255);
        }
        if (isShown()) {
            if (eco && !moving && bubble == null) {
                postInvalidateDelayed(1000);
            } else {
                postInvalidateOnAnimation();
            }
        }
    }

    // ------------------------------------------------------------------ touch: drag or tap

    private boolean longPressed;
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (!dragging) {
                longPressed = true;
                host.buzz(30);
                WizardMenu.open(host);
            }
        }
    };

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (atHome()) {
            return false;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                sleepingWas = sleeping;
                wake(false);
                downX = e.getRawX();
                downY = e.getRawY();
                startTx = getTranslationX();
                startTy = getTranslationY();
                dragging = false;
                if (walk != null) {
                    walk.cancel();
                    moving = false;
                }
                getParent().requestDisallowInterceptTouchEvent(true);
                longPressed = false;
                removeCallbacks(longPress);
                postDelayed(longPress, 650);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - downX;
                float dy = e.getRawY() - downY;
                if (!dragging && Math.hypot(dx, dy) > ViewConfiguration.get(getContext()).getScaledTouchSlop()) {
                    dragging = true;
                    removeCallbacks(longPress);
                    host.buzz(10);
                }
                if (dragging) {
                    setTranslationX(Math.max(0, Math.min(maxX(), startTx + dx)));
                    setTranslationY(Math.max(0, Math.min(maxY(), startTy + dy)));
                    if (bubble != null) {
                        dismissBubble(false);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                removeCallbacks(longPress);
                if (longPressed) {
                    longPressed = false;
                    return true;
                }
                if (dragging) {
                    dragging = false;
                    pausedUntil = System.currentTimeMillis() + 150000;
                    float mx = Math.max(1f, maxX());
                    float my = Math.max(1f, maxY());
                    Prefs.putInt("wiz_x", Math.round(getTranslationX() / mx * 100f));
                    Prefs.putInt("wiz_y", Math.round(getTranslationY() / my * 100f));
                } else {
                    if (bubble != null) {
                        dismissBubble(true);
                    } else if (sleepingWas) {
                        say("Huh?! I was only resting my eyes.");
                    } else {
                        say((Pets.kind(0) == Pets.PARROT || Pets.kind(1) == Pets.PARROT) && rnd.nextInt(3) == 0 ? parrotLine() : Tips.forTap());
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                dragging = false;
                return true;
            default:
                return true;
        }
    }

    // ------------------------------------------------------------------ the speech bubble

    void say(final String text) {
        lastActive = System.currentTimeMillis();
        sleeping = false;
        if (atHome()) {
            emerge();
            postDelayed(() -> say(text), 1700);
            return;
        }
        if (bubble != null) {
            if (queue.size() < 3) {
                queue.add(text);
            }
            return;
        }
        if (!(getParent() instanceof FrameLayout)) {
            return;
        }
        final TextView b = new TextView(host);
        b.setTag(NovaActivity.KEEP);
        b.setText(text);
        b.setTypeface(Theme.MONO);
        b.setTextSize(12f);
        b.setTextColor(Theme.TEXT);
        b.setLineSpacing(0f, 1.15f);
        b.setBackground(Theme.rounded(0xF2140F26, 18f, host));
        b.setPadding(Theme.dp(host, 16), Theme.dp(host, 12), Theme.dp(host, 16), Theme.dp(host, 12));
        b.setElevation(Theme.dp(host, 14));
        b.setShadowLayer(Theme.dp(host, 6), 0f, 0f, Theme.ACCENT);
        b.setMaxWidth(Math.min(((FrameLayout) getParent()).getWidth() - Theme.dp(host, 32), Theme.dp(host, 280)));
        b.setOnClickListener(v -> dismissBubble(true));
        showBubble(b, Math.max(5000, 70L * text.length()), true);
    }

    /** Puts a bubble next to the wizard and removes it again after a while. */
    private void showBubble(final View b, long stay, final boolean next) {
        final FrameLayout root = (FrameLayout) getParent();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        root.addView(b, lp);
        b.measure(View.MeasureSpec.makeMeasureSpec(root.getWidth(), View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(root.getHeight(), View.MeasureSpec.AT_MOST));
        float bw = b.getMeasuredWidth();
        float bh = b.getMeasuredHeight();
        float cx = getTranslationX() + getWidth() / 2f;
        float x = Math.max(Theme.dp(host, 12), Math.min(root.getWidth() - bw - Theme.dp(host, 12), cx - bw / 2f));
        boolean above = getTranslationY() > bh + Theme.dp(host, 60);
        float y = above ? getTranslationY() - bh + scale * 4 : getTranslationY() + getHeight() - scale * 4;
        y = Math.max(Theme.dp(host, 40), Math.min(root.getHeight() - bh - Theme.dp(host, 20), y));
        b.setTranslationX(x);
        b.setTranslationY(y);
        b.setAlpha(0f);
        b.setScaleX(0.9f);
        b.setScaleY(0.9f);
        b.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        bubble = b;
        host.keepOnTop();
        Sfx.play(Sfx.BLIP);
        host.buzz(12);
        b.postDelayed(() -> {
            if (bubble == b) {
                dismissBubble(next);
            }
        }, stay);
    }

    /**
     * A question with YES and NO. NO (or YES) runs its action. If nobody answers it simply goes away.
     */
    void ask(final String question, final Runnable yes, final Runnable no) {
        if (atHome()) {
            emerge();
            postDelayed(() -> ask(question, yes, no), 1700);
            return;
        }
        if (!(getParent() instanceof FrameLayout)) {
            return;
        }
        if (bubble != null) {
            dismissBubble(false);
        }
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setTag(NovaActivity.KEEP);
        box.setBackground(Theme.rounded(0xF2140F26, 18f, host));
        box.setPadding(Theme.dp(host, 16), Theme.dp(host, 12), Theme.dp(host, 16), Theme.dp(host, 12));
        box.setElevation(Theme.dp(host, 14));
        TextView q = new TextView(host);
        q.setText(question);
        q.setTypeface(Theme.MONO);
        q.setTextSize(13f);
        q.setTextColor(Theme.TEXT);
        box.addView(q);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, Theme.dp(host, 10), 0, 0);
        row.addView(answerPill("YES", true, () -> {
            dismissBubble(false);
            if (yes != null) {
                yes.run();
            }
        }));
        row.addView(answerPill("NO", false, () -> {
            dismissBubble(false);
            if (no != null) {
                no.run();
            }
        }));
        box.addView(row);
        showBubble(box, 12000, false);
    }

    private TextView answerPill(String label, boolean strong, final Runnable action) {
        TextView t = new TextView(host);
        t.setText(label);
        t.setTypeface(Theme.MONO);
        t.setTextSize(12f);
        t.setLetterSpacing(0.15f);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(strong ? 0xFF140F26 : Theme.TEXT);
        t.setBackground(Theme.rounded(strong ? Theme.ACCENT : 0x33FFFFFF, 14f, host));
        t.setPadding(Theme.dp(host, 22), Theme.dp(host, 9), Theme.dp(host, 22), Theme.dp(host, 9));
        t.setClickable(true);
        t.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Theme.dp(host, 6), 0, Theme.dp(host, 6), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void dismissBubble(boolean next) {
        final View b = bubble;
        bubble = null;
        if (b != null) {
            b.animate().alpha(0f).setDuration(200).withEndAction(() -> {
                if (b.getParent() != null) {
                    ((FrameLayout) b.getParent()).removeView(b);
                }
            }).start();
        }
        if (next && !queue.isEmpty()) {
            final String n = queue.poll();
            postDelayed(() -> say(n), 450);
        }
    }

    /** Called when the wizard is switched off. */
    void remove() {
        dismissBubble(false);
        queue.clear();
    }
}
