package app.novaos;

import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

/** A scrambled word of the day. Unscramble it once a day for coins. Same word for the whole day. */
final class GameWord extends Game {
    private static final String[] WORDS = {"CASTLE", "WIZARD", "DRAGON", "ROCKET", "PLANET", "SILVER", "GOLDEN",
        "BRIDGE", "FOREST", "ANCHOR", "BANNER", "CANDLE", "DESERT", "ENGINE", "FALCON", "GARDEN", "HAMMER", "ISLAND",
        "JUNGLE", "KNIGHT", "LAUNCH", "MIRROR", "NEEDLE", "ORANGE", "PUZZLE", "QUARTZ", "RIDDLE", "SPIRIT", "TEMPLE",
        "VELVET", "WINDOW", "ZIPPER", "THUNDER", "PYRAMID", "VOLCANO", "COMPASS", "LANTERN", "MONSTER", "PHOENIX"};

    private final String word;
    private final String scrambled;
    private final TextView info;
    private final EditText in;

    GameWord(NovaActivity host) {
        super(host);
        Calendar c = Calendar.getInstance();
        int day = c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
        Random r = new Random(day * 7L + 3);
        word = WORDS[r.nextInt(WORDS.length)];
        char[] ch = word.toCharArray();
        String s;
        int tries = 0;
        do {
            for (int i = ch.length - 1; i > 0; i--) {
                int j = r.nextInt(i + 1);
                char t = ch[i];
                ch[i] = ch[j];
                ch[j] = t;
            }
            s = new String(ch);
        } while (s.equals(word) && ++tries < 10);
        scrambled = s;
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(90), dp(24), dp(30));
        addView(col, new LayoutParams(-1, -1));
        info = label("", 13f, Theme.DIM);
        col.addView(info);
        TextView big = label(scrambled, 38f, Theme.ACCENT);
        big.setLetterSpacing(0.2f);
        big.setPadding(0, dp(30), 0, dp(30));
        col.addView(big);
        in = new EditText(host);
        in.setTypeface(Theme.MONO);
        in.setTextColor(Theme.TEXT);
        in.setGravity(Gravity.CENTER);
        in.setHint("your answer");
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        col.addView(in, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = dp(20);
        col.addView(button("CHECK", this::check), bp);
        info.setText(done() ? "Solved today. Come back tomorrow!" : "Unscramble the word. 25 coins once a day.");
    }

    @Override
    String title() {
        return "WORD OF THE DAY";
    }

    private boolean done() {
        Calendar c = Calendar.getInstance();
        return Prefs.getInt("word_day", 0) == c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
    }

    private void check() {
        String a = in.getText().toString().trim().toUpperCase(Locale.ROOT);
        if (a.equals(word)) {
            if (done()) {
                info.setText("Right again! (no more coins today)");
                return;
            }
            Calendar c = Calendar.getInstance();
            Prefs.putInt("word_day", c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR));
            Coins.add(25);
            Sfx.play(Sfx.WIN);
            info.setText("Yes! " + word + ". +25 coins");
        } else {
            Sfx.play(Sfx.LOSE);
            info.setText("Not " + a + ". Try again.");
        }
    }
}
