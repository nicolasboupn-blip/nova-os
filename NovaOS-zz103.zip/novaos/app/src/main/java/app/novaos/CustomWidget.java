package app.novaos;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;
import java.util.function.Supplier;

/**
 * A widget you build yourself from blocks in the WIDGET BUILDER (settings). Three slots: MY WIDGET 1 to 3.
 * 61 kinds of block: clocks, dates and progress, phone facts, tools, little games, things about you, and text.
 * Moving things (clocks, stopwatch) only change their text each tick, so buttons keep working while they run.
 */
final class CustomWidget extends NovaWidget {
    // The first eleven keep their numbers forever: saved widgets store the number.
    static final String[] TYPES = {"Text", "Clock", "Date", "Battery bar", "Button", "Counter", "Day progress",
        "Scene status", "Top song", "Line", "Space",
        "Analog clock", "Big clock", "Clock 12 hour", "Weekday", "Day number", "Month and year", "Week number",
        "Day of the year", "Year progress", "Month progress", "Week progress", "Countdown to a date",
        "Days since a date", "Greeting", "My name", "Battery big", "Charging status", "Storage bar", "Memory bar",
        "Uptime", "Phone model", "Android version", "Network", "Volume bar", "Brightness bar", "Moon phase",
        "World clock", "Hours left today", "Days to the weekend", "Quote", "Fun fact", "Coin flip", "Dice",
        "Random number", "Magic 8 ball", "Tally + / -", "Stopwatch", "Timer", "Checklist item", "Habit streak",
        "Water today", "Mood today", "Manual progress bar", "Heading", "App button", "Top 3 songs", "Scenes row",
        "Big emoji", "Rainbow text", "Status strip"};

    /** The block picker is split into groups so 61 kinds stay easy to find. */
    static final String[] GROUPS = {"TIME", "DATE", "PHONE", "YOU", "TOOLS", "GAMES", "TEXT & LOOK"};
    static final int[][] GROUP_ITEMS = {
        {1, 11, 12, 13, 37, 47, 48, 6, 38, 60},
        {2, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 39, 36},
        {3, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35},
        {24, 25, 7, 8, 56, 57, 50, 51, 52, 49},
        {4, 55, 5, 46, 53, 40, 41},
        {42, 43, 44, 45},
        {0, 54, 58, 59, 9, 10}};

    static final class Block {
        int type;
        String a = "";
        String b = "";
    }

    /** What the two edit fields of a block are called, or null when it has none. Index 0 is field A, 1 is field B. */
    static String[] hints(int type) {
        switch (type) {
            case 0:
                return new String[] {"text", "size (8 to 60)"};
            case 1:
            case 12:
                return new String[] {"12 for am/pm, empty for 24 hour", null};
            case 4:
                return new String[] {"button label", "scene:Name, a link, or an app package"};
            case 5:
            case 46:
                return new String[] {"counter name", null};
            case 22:
                return new String[] {"date, like 2026-12-24", "label, like Christmas"};
            case 23:
                return new String[] {"date, like 2026-01-01", "label"};
            case 37:
                return new String[] {"time zone, like Asia/Tokyo", "label, like Tokyo"};
            case 44:
                return new String[] {"highest number (default 100)", null};
            case 43:
                return new String[] {"sides (default 6)", null};
            case 48:
                return new String[] {"minutes (default 5)", null};
            case 49:
                return new String[] {"what to do", null};
            case 50:
                return new String[] {"habit name", null};
            case 51:
                return new String[] {"goal in glasses (default 8)", null};
            case 53:
                return new String[] {"label", "percent 0 to 100"};
            case 54:
            case 58:
                return new String[] {"text", null};
            case 55:
                return new String[] {"app package, like com.spotify.music", "label (optional)"};
            case 59:
                return new String[] {"text", "size (8 to 60)"};
            default:
                return null;
        }
    }

    static void defaults(Block b) {
        switch (b.type) {
            case 0:
                b.a = "Hello";
                break;
            case 4:
                b.a = "OPEN";
                break;
            case 5:
            case 46:
                b.a = "Count";
                break;
            case 22:
                b.a = new SimpleDateFormat("yyyy", Locale.ROOT).format(new Date()) + "-12-24";
                b.b = "Christmas";
                break;
            case 23:
                b.a = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
                b.b = "Since";
                break;
            case 37:
                b.a = "Asia/Tokyo";
                b.b = "Tokyo";
                break;
            case 49:
                b.a = "Do the thing";
                break;
            case 50:
                b.a = "Habit";
                break;
            case 53:
                b.a = "Progress";
                b.b = "50";
                break;
            case 54:
                b.a = "Heading";
                break;
            case 58:
                b.a = "✨";
                break;
            case 59:
                b.a = "Rainbow";
                b.b = "28";
                break;
            default:
                break;
        }
    }

    private final int slot;
    private final List<Runnable> updaters = new ArrayList<>();
    private boolean everySecond;
    private boolean fast;
    private static final Map<String, long[]> WATCH = new HashMap<>();   // stopwatch / timer state by slot_index
    private static final Random RND = new Random();

    CustomWidget(NovaActivity host, int slot) {
        super(host);
        this.slot = slot;
    }

    static String key(int slot) {
        return "mw_" + slot;
    }

    static List<Block> load(int slot) {
        List<Block> out = new ArrayList<>();
        String raw = Prefs.getString(key(slot), "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String l : raw.split("\n")) {
            String[] p = l.split("\t", -1);
            try {
                Block b = new Block();
                b.type = Math.max(0, Math.min(TYPES.length - 1, Integer.parseInt(p[0])));
                b.a = p.length > 1 ? p[1] : "";
                b.b = p.length > 2 ? p[2] : "";
                out.add(b);
            } catch (NumberFormatException ignored) {
                // skip a broken line
            }
        }
        return out;
    }

    static void save(int slot, List<Block> blocks) {
        StringBuilder sb = new StringBuilder();
        for (Block b : blocks) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(b.type).append('\t').append(clean(b.a)).append('\t').append(clean(b.b));
        }
        Prefs.putString(key(slot), sb.toString());
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    @Override
    long tickMs() {
        return fast ? 250 : everySecond ? 1000 : 20000;
    }

    @Override
    void tick() {
        for (Runnable r : new ArrayList<>(updaters)) {
            try {
                r.run();
            } catch (RuntimeException ignored) {
                // one broken block must not stop the others
            }
        }
    }

    @Override
    void refresh() {
        removeAllViews();
        updaters.clear();
        everySecond = false;
        fast = false;
        List<Block> blocks = load(slot);
        if (blocks.isEmpty()) {
            addView(text("MY WIDGET " + slot + " is empty. Settings > PROFILE & SCENES > WIDGET BUILDER.", 10f,
                    Theme.DIM), wide());
            return;
        }
        for (int i = 0; i < blocks.size(); i++) {
            try {
                View v = block(blocks.get(i), i);
                if (v != null) {
                    addView(v, wide());
                }
            } catch (RuntimeException e) {
                addView(text("block " + (i + 1) + " could not start", 9f, Theme.DIM), wide());
            }
        }
        tick();
    }

    // ------------------------------------------------------------------ helpers

    /** A text that updates itself on every tick. */
    private TextView live(float sp, int color, final Supplier<String> s) {
        final TextView t = text(s.get(), sp, color);
        updaters.add(() -> t.setText(s.get()));
        return t;
    }

    private TextView plain(String s, float sp, int color) {
        return text(s, sp, color);
    }

    private float size(String s, float def) {
        try {
            return Math.max(8f, Math.min(60f, Float.parseFloat(s.trim())));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private int num(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private String pad(long n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    private int battery() {
        try {
            BatteryManager bm = (BatteryManager) host.getSystemService(Context.BATTERY_SERVICE);
            return Math.max(0, Math.min(100, bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    private LinearLayout labelledBar(final Supplier<String> label, final Supplier<Float> frac) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(VERTICAL);
        final TextView l = text(label.get(), 10f, Theme.DIM);
        l.setGravity(Gravity.START);
        c.addView(l);
        final WidgetBar bar = new WidgetBar(host);
        bar.set(frac.get());
        c.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
        updaters.add(() -> {
            l.setText(label.get());
            bar.set(frac.get());
        });
        return c;
    }

    private static String dayStamp() {
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date());
    }

    private static long daysBetween(long from, long to) {
        return Math.floorDiv(to - from, 86400000L);
    }

    private long parseDate(String s) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            f.setLenient(false);
            return f.parse(s.trim()).getTime();
        } catch (Exception e) {
            return -1;
        }
    }

    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static final String[] QUOTES = {
        "Small steps still move you forward.", "Done is better than perfect.", "Start where you are.",
        "Energy goes where attention flows.", "Be kind. Everyone is fighting something.",
        "You do not have to see the whole staircase.", "Make it work, then make it beautiful.",
        "Rest is part of the work.", "Today is a good day to begin.", "Curiosity beats talent.",
        "Slow is smooth, smooth is fast.", "Nothing changes if nothing changes.", "Progress, not perfection.",
        "Stay hungry, stay humble.", "The best time to start was yesterday. The next best is now.",
        "Fall seven times, stand up eight.", "Less, but better.", "Keep it simple.",
        "What you do every day matters more than what you do once.", "Breathe. You have got this."};

    private static final String[] FACTS = {
        "Honey never spoils.", "A day on Venus is longer than its year.", "Octopuses have three hearts.",
        "Bananas are berries, strawberries are not.", "Switzerland has four national languages.",
        "The Eiffel Tower grows a bit taller in summer.", "Sharks are older than trees.",
        "Wombat droppings are cube shaped.", "There are more stars than grains of sand on Earth, probably.",
        "Your bones are about five times stronger than steel of the same weight.",
        "A group of flamingos is called a flamboyance.", "Lightning is hotter than the surface of the Sun.",
        "The Matterhorn is about 4478 m high.", "Sound travels about four times faster in water than in air.",
        "Antarctica is the largest desert on Earth."};

    private static final String[] BALL = {"Yes.", "No.", "Ask again later.", "Definitely.", "Very doubtful.",
        "Without a doubt.", "Maybe.", "Outlook good.", "Do not count on it.", "Signs point to yes.",
        "Cannot say now.", "Absolutely not."};

    // ------------------------------------------------------------------ the blocks

    private View block(final Block b, final int idx) {
        final String k = "mwc_" + slot + "_" + idx;
        switch (b.type) {
            case 0:
                return plain(b.a, size(b.b, 14f), Theme.TEXT);
            case 1: {
                everySecond = true;
                final boolean h12 = b.a.equals("12");
                return live(34f, Theme.TEXT, () -> new SimpleDateFormat(h12 ? "h:mm:ss a" : "HH:mm:ss",
                        Locale.getDefault()).format(new Date()));
            }
            case 2:
                return live(14f, Theme.TEXT, () -> new SimpleDateFormat("EEEE d MMMM", Locale.getDefault())
                        .format(new Date()));
            case 3:
                return labelledBar(() -> "BATTERY " + battery() + "%", () -> battery() / 100f);
            case 4:
                return chip(b.a.isEmpty() ? "BUTTON" : b.a, () -> press(b));
            case 5: {
                final TextView c = chip(b.a + "  " + Prefs.getInt(k, 0), () -> { });
                c.setOnClickListener(v -> {
                    Prefs.putInt(k, Prefs.getInt(k, 0) + 1);
                    c.setText(b.a + "  " + Prefs.getInt(k, 0));
                    host.buzz(12);
                });
                c.setOnLongClickListener(v -> {
                    Prefs.putInt(k, 0);
                    c.setText(b.a + "  0");
                    return true;
                });
                return c;
            }
            case 6:
                return labelledBar(() -> {
                    Calendar c = Calendar.getInstance();
                    return "DAY " + dayPct(c) + "%";
                }, () -> dayPct(Calendar.getInstance()) / 100f);
            case 7:
                return live(14f, Theme.ACCENT, () -> Scenes.status().isEmpty() ? "no scene on" : Scenes.status());
            case 8: {
                List<SongLog.Song> top = SongLog.top(3, 1);
                return plain(top.isEmpty() ? "no songs yet" : "♪ " + top.get(0).title, 13f, Theme.TEXT);
            }
            case 9: {
                View line = new View(host);
                line.setBackgroundColor(0x33FFFFFF);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
                lp.topMargin = dp(6);
                lp.bottomMargin = dp(6);
                line.setLayoutParams(lp);
                return line;
            }
            case 10:
                return spacer(14);
            case 11: {
                everySecond = true;
                final AnalogFace face = new AnalogFace(host);
                updaters.add(face::invalidate);
                face.setLayoutParams(new LinearLayout.LayoutParams(dp(130), dp(130)));
                LinearLayout w = new LinearLayout(host);
                w.setGravity(Gravity.CENTER);
                w.addView(face);
                return w;
            }
            case 12: {
                everySecond = true;
                final boolean h12 = b.a.equals("12");
                return live(56f, Theme.TEXT, () -> new SimpleDateFormat(h12 ? "h:mm" : "HH:mm", Locale.getDefault())
                        .format(new Date()));
            }
            case 13:
                everySecond = true;
                return live(30f, Theme.TEXT, () -> new SimpleDateFormat("h:mm a", Locale.getDefault())
                        .format(new Date()));
            case 14:
                return live(22f, Theme.ACCENT, () -> new SimpleDateFormat("EEEE", Locale.getDefault())
                        .format(new Date()));
            case 15:
                return live(56f, Theme.TEXT, () -> String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)));
            case 16:
                return live(16f, Theme.TEXT, () -> new SimpleDateFormat("MMMM yyyy", Locale.getDefault())
                        .format(new Date()));
            case 17:
                return live(16f, Theme.TEXT, () -> "Week " + Calendar.getInstance().get(Calendar.WEEK_OF_YEAR));
            case 18:
                return live(14f, Theme.TEXT, () -> {
                    Calendar c = Calendar.getInstance();
                    return "Day " + c.get(Calendar.DAY_OF_YEAR) + " of " + c.getActualMaximum(Calendar.DAY_OF_YEAR);
                });
            case 19:
                return labelledBar(() -> "YEAR " + Math.round(yearFrac() * 100) + "%", this::yearFrac);
            case 20:
                return labelledBar(() -> "MONTH " + Math.round(monthFrac() * 100) + "%", this::monthFrac);
            case 21:
                return labelledBar(() -> "WEEK " + Math.round(weekFrac() * 100) + "%", this::weekFrac);
            case 22: {
                final long target = parseDate(b.a);
                final String label = b.b.isEmpty() ? "to go" : b.b;
                return countBlock(target < 0 ? null : () -> {
                    long d = daysBetween(startOfToday(), target);
                    return d < 0 ? "passed" : d == 0 ? "today!" : d + (d == 1 ? " day" : " days");
                }, label);
            }
            case 23: {
                final long target = parseDate(b.a);
                final String label = b.b.isEmpty() ? "since" : b.b;
                return countBlock(target < 0 ? null : () -> {
                    long d = daysBetween(target, startOfToday());
                    return Math.max(0, d) + (d == 1 ? " day" : " days");
                }, label);
            }
            case 24:
                return live(16f, Theme.TEXT, () -> {
                    int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                    String g = h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon"
                            : "Good evening";
                    return g + ", " + Profile.name();
                });
            case 25:
                return plain(Profile.name(), 28f, Theme.ACCENT);
            case 26:
                return live(44f, Theme.TEXT, () -> battery() + "%");
            case 27:
                return live(14f, Theme.TEXT, () -> {
                    try {
                        BatteryManager bm = (BatteryManager) host.getSystemService(Context.BATTERY_SERVICE);
                        return (bm.isCharging() ? "⚡ charging  " : "on battery  ") + battery() + "%";
                    } catch (RuntimeException e) {
                        return battery() + "%";
                    }
                });
            case 28:
                return labelledBar(() -> {
                    StatFs s = new StatFs(Environment.getDataDirectory().getPath());
                    return "STORAGE  " + gb(s.getAvailableBytes()) + " free of " + gb(s.getTotalBytes());
                }, () -> {
                    StatFs s = new StatFs(Environment.getDataDirectory().getPath());
                    return 1f - (float) s.getAvailableBytes() / Math.max(1L, s.getTotalBytes());
                });
            case 29:
                return labelledBar(() -> {
                    ActivityManager.MemoryInfo mi = memory();
                    return "MEMORY  " + gb(mi.totalMem - mi.availMem) + " used of " + gb(mi.totalMem);
                }, () -> {
                    ActivityManager.MemoryInfo mi = memory();
                    return 1f - (float) mi.availMem / Math.max(1L, mi.totalMem);
                });
            case 30:
                return live(14f, Theme.TEXT, () -> {
                    long s = SystemClock.elapsedRealtime() / 1000;
                    return "up " + (s / 86400) + "d " + ((s % 86400) / 3600) + "h " + ((s % 3600) / 60) + "m";
                });
            case 31:
                return plain(Build.MANUFACTURER + " " + Build.MODEL, 14f, Theme.TEXT);
            case 32:
                return plain("Android " + Build.VERSION.RELEASE + "  (SDK " + Build.VERSION.SDK_INT + ")", 13f,
                        Theme.TEXT);
            case 33:
                return live(14f, Theme.TEXT, this::network);
            case 34:
                return labelledBar(() -> "VOLUME " + Math.round(volume() * 100) + "%", this::volume);
            case 35:
                return labelledBar(() -> "BRIGHTNESS " + Math.round(brightness() * 100) + "%", this::brightness);
            case 36:
                return live(15f, Theme.TEXT, this::moon);
            case 37: {
                final TimeZone tz = TimeZone.getTimeZone(b.a.trim().isEmpty() ? "UTC" : b.a.trim());
                final String label = b.b.isEmpty() ? tz.getID() : b.b;
                everySecond = true;
                final SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
                f.setTimeZone(tz);
                LinearLayout w = new LinearLayout(host);
                w.setOrientation(VERTICAL);
                w.addView(live(30f, Theme.TEXT, () -> f.format(new Date())), wide());
                w.addView(plain(label, 10f, Theme.DIM), wide());
                return w;
            }
            case 38:
                return live(15f, Theme.TEXT, () -> {
                    long left = 86400000L - (System.currentTimeMillis() - startOfToday());
                    return (left / 3600000) + "h " + ((left % 3600000) / 60000) + "m left today";
                });
            case 39:
                return live(15f, Theme.TEXT, () -> {
                    int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
                    if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) {
                        return "It is the weekend!";
                    }
                    int d = Calendar.SATURDAY - dow;
                    return d + (d == 1 ? " day" : " days") + " to the weekend";
                });
            case 40:
                return cycler(QUOTES, Calendar.getInstance().get(Calendar.DAY_OF_YEAR), 13f, true);
            case 41:
                return cycler(FACTS, Calendar.getInstance().get(Calendar.DAY_OF_YEAR), 12f, true);
            case 42: {
                final TextView c = chip("FLIP A COIN", () -> { });
                c.setOnClickListener(v -> {
                    c.setText(RND.nextBoolean() ? "HEADS" : "TAILS");
                    host.buzz(15);
                });
                return c;
            }
            case 43: {
                final int sides = Math.max(2, Math.min(100, num(b.a, 6)));
                final TextView c = chip("ROLL A D" + sides, () -> { });
                c.setOnClickListener(v -> {
                    c.setText("🎲 " + (1 + RND.nextInt(sides)));
                    host.buzz(15);
                });
                return c;
            }
            case 44: {
                final int max = Math.max(2, num(b.a, 100));
                final TextView c = chip("RANDOM 1 TO " + max, () -> { });
                c.setOnClickListener(v -> {
                    c.setText(String.valueOf(1 + RND.nextInt(max)));
                    host.buzz(15);
                });
                return c;
            }
            case 45: {
                final TextView c = chip("ASK THE 8 BALL", () -> { });
                c.setOnClickListener(v -> c.setText("🎱 " + BALL[RND.nextInt(BALL.length)]));
                return c;
            }
            case 46: {
                LinearLayout r = row();
                final TextView n = text(b.a + "  " + Prefs.getInt(k, 0), 13f, Theme.TEXT);
                r.addView(chip("−", () -> {
                    Prefs.putInt(k, Prefs.getInt(k, 0) - 1);
                    n.setText(b.a + "  " + Prefs.getInt(k, 0));
                }), weight(1f));
                r.addView(n, weight(2f));
                r.addView(chip("+", () -> {
                    Prefs.putInt(k, Prefs.getInt(k, 0) + 1);
                    n.setText(b.a + "  " + Prefs.getInt(k, 0));
                    host.buzz(10);
                }), weight(1f));
                return r;
            }
            case 47:
                return stopwatch(k);
            case 48:
                return timer(k, Math.max(1, num(b.a, 5)));
            case 49: {
                final TextView c = chip("", () -> { });
                final Runnable paint = () -> c.setText((Prefs.getInt(k, 0) == 1 ? "☑  " : "☐  ") + b.a);
                paint.run();
                c.setGravity(Gravity.START);
                c.setOnClickListener(v -> {
                    Prefs.putInt(k, Prefs.getInt(k, 0) == 1 ? 0 : 1);
                    paint.run();
                    host.buzz(10);
                });
                return c;
            }
            case 50:
                return habit(b.a, k);
            case 51:
                return water(Math.max(1, num(b.a, 8)), k);
            case 52:
                return mood(k);
            case 53: {
                LinearLayout c = new LinearLayout(host);
                c.setOrientation(VERTICAL);
                TextView l = text(b.a + "  " + Math.max(0, Math.min(100, num(b.b, 0))) + "%", 10f, Theme.DIM);
                l.setGravity(Gravity.START);
                c.addView(l);
                WidgetBar bar = new WidgetBar(host);
                bar.set(Math.max(0, Math.min(100, num(b.b, 0))) / 100f);
                c.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
                return c;
            }
            case 54: {
                TextView t = plain(b.a, 24f, Theme.ACCENT);
                t.setTypeface(Theme.MONO, android.graphics.Typeface.BOLD);
                return t;
            }
            case 55:
                return appButton(b);
            case 56:
                return live(12f, Theme.TEXT, () -> {
                    List<SongLog.Song> top = SongLog.top(3, 3);
                    if (top.isEmpty()) {
                        return "no songs yet";
                    }
                    StringBuilder sb = new StringBuilder();
                    for (SongLog.Song s : top) {
                        if (sb.length() > 0) {
                            sb.append('\n');
                        }
                        sb.append("♪ ").append(s.title).append(s.artist == null || s.artist.isEmpty() ? ""
                                : " · " + s.artist);
                    }
                    return sb.toString();
                });
            case 57: {
                HorizontalScrollView hs = new HorizontalScrollView(host);
                hs.setHorizontalScrollBarEnabled(false);
                LinearLayout r = new LinearLayout(host);
                List<Scenes.Scene> all = Scenes.all();
                for (int i = 0; i < all.size(); i++) {
                    final int si = i;
                    TextView c = chip(all.get(i).emoji + " " + all.get(i).name, () -> Scenes.apply(host, si));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                    lp.rightMargin = dp(4);
                    r.addView(c, lp);
                }
                hs.addView(r);
                return hs;
            }
            case 58:
                return plain(b.a, 48f, Theme.TEXT);
            case 59: {
                TextView t = plain("", size(b.b, 28f), Theme.TEXT);
                SpannableString sp = new SpannableString(b.a);
                for (int i = 0; i < b.a.length(); i++) {
                    sp.setSpan(new ForegroundColorSpan(Color.HSVToColor(new float[] {
                        (i * 360f / Math.max(6, b.a.length())) % 360f, 0.55f, 1f})), i, i + 1,
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                t.setText(sp);
                return t;
            }
            case 60:
                return live(13f, Theme.TEXT, () -> new SimpleDateFormat("HH:mm  ·  EEE d MMM", Locale.getDefault())
                        .format(new Date()) + "  ·  " + battery() + "%");
            default:
                return spacer(14);
        }
    }

    private View spacer(int dp) {
        View v = new View(host);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(dp)));
        return v;
    }

    // ------------------------------------------------------------------ numbers for the bars

    private static int dayPct(Calendar c) {
        return (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)) * 100 / 1440;
    }

    private float yearFrac() {
        Calendar c = Calendar.getInstance();
        return Math.min(1f, (c.get(Calendar.DAY_OF_YEAR) - 1 + dayPct(c) / 100f) / c.getActualMaximum(Calendar.DAY_OF_YEAR));
    }

    private float monthFrac() {
        Calendar c = Calendar.getInstance();
        return Math.min(1f, (c.get(Calendar.DAY_OF_MONTH) - 1 + dayPct(c) / 100f) / c.getActualMaximum(Calendar.DAY_OF_MONTH));
    }

    private float weekFrac() {
        Calendar c = Calendar.getInstance();
        int dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7; // Monday = 0
        return Math.min(1f, (dow + dayPct(c) / 100f) / 7f);
    }

    private String gb(long bytes) {
        return String.format(Locale.ROOT, "%.1f GB", bytes / 1073741824.0);
    }

    private ActivityManager.MemoryInfo memory() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) host.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi;
    }

    private float volume() {
        try {
            android.media.AudioManager am = (android.media.AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            return am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                    / (float) Math.max(1, am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC));
        } catch (RuntimeException e) {
            return 0f;
        }
    }

    private float brightness() {
        try {
            return android.provider.Settings.System.getInt(host.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, 128) / 255f;
        } catch (RuntimeException e) {
            return 0.5f;
        }
    }

    private String network() {
        try {
            ConnectivityManager cm = (ConnectivityManager) host.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            if (nc == null) {
                return "offline";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "Wi-Fi";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return "mobile data";
            }
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                return "ethernet";
            }
            return "online";
        } catch (RuntimeException e) {
            return "unknown";
        }
    }

    private String moon() {
        double days = (System.currentTimeMillis() - 947182440000L) / 86400000.0; // new moon on 6 Jan 2000
        double age = ((days % 29.530588853) + 29.530588853) % 29.530588853;
        String[] names = {"New moon", "Waxing crescent", "First quarter", "Waxing gibbous", "Full moon",
            "Waning gibbous", "Last quarter", "Waning crescent"};
        String[] icons = {"🌑", "🌒", "🌓", "🌔", "🌕",
            "🌖", "🌗", "🌘"};
        int i = (int) Math.floor((age / 29.530588853) * 8 + 0.5) % 8;
        return icons[i] + "  " + names[i];
    }

    // ------------------------------------------------------------------ bigger blocks

    private View countBlock(Supplier<String> s, String label) {
        LinearLayout w = new LinearLayout(host);
        w.setOrientation(VERTICAL);
        if (s == null) {
            w.addView(plain("set a date like 2026-12-24", 11f, Theme.DIM), wide());
            return w;
        }
        w.addView(live(32f, Theme.ACCENT, s), wide());
        w.addView(plain(label, 10f, Theme.DIM), wide());
        return w;
    }

    private View cycler(final String[] list, int start, float sp, boolean italic) {
        final int[] at = {start % list.length};
        final TextView t = text(list[at[0]], sp, Theme.TEXT);
        if (italic) {
            t.setTypeface(Theme.MONO, android.graphics.Typeface.ITALIC);
        }
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        t.setClickable(true);
        t.setOnClickListener(v -> {
            at[0] = (at[0] + 1) % list.length;
            t.setText(list[at[0]]);
        });
        return t;
    }

    private View stopwatch(final String k) {
        fast = true;
        final long[] st = WATCH.computeIfAbsent("sw" + k, x -> new long[] {0, 0, 0}); // running, startedAt, accumulated
        LinearLayout w = new LinearLayout(host);
        w.setOrientation(VERTICAL);
        final Supplier<String> time = () -> {
            long ms = st[2] + (st[0] == 1 ? SystemClock.elapsedRealtime() - st[1] : 0);
            return pad(ms / 60000) + ":" + pad((ms / 1000) % 60) + "." + (ms / 100) % 10;
        };
        w.addView(live(34f, Theme.TEXT, time), wide());
        LinearLayout r = row();
        final TextView go = chip(st[0] == 1 ? "STOP" : "START", () -> { });
        go.setOnClickListener(v -> {
            if (st[0] == 1) {
                st[2] += SystemClock.elapsedRealtime() - st[1];
                st[0] = 0;
            } else {
                st[1] = SystemClock.elapsedRealtime();
                st[0] = 1;
            }
            go.setText(st[0] == 1 ? "STOP" : "START");
        });
        r.addView(go, weight(1f));
        r.addView(chip("RESET", () -> {
            st[0] = 0;
            st[2] = 0;
            go.setText("START");
        }), weight(1f));
        w.addView(r, wide());
        return w;
    }

    private View timer(final String k, final int minutes) {
        fast = true;
        final long[] st = WATCH.computeIfAbsent("tm" + k, x -> new long[] {0, 0, 0}); // running, endsAt, leftWhenStopped
        if (st[2] == 0 && st[0] == 0) {
            st[2] = minutes * 60000L;
        }
        LinearLayout w = new LinearLayout(host);
        w.setOrientation(VERTICAL);
        final Supplier<String> time = () -> {
            long left = st[0] == 1 ? Math.max(0, st[1] - SystemClock.elapsedRealtime()) : st[2];
            if (st[0] == 1 && left == 0) {
                st[0] = 0;
                st[2] = minutes * 60000L;
                host.buzz(400);
                host.toast("Timer done");
            }
            return pad(left / 60000) + ":" + pad((left / 1000) % 60);
        };
        w.addView(live(34f, Theme.TEXT, time), wide());
        LinearLayout r = row();
        final TextView go = chip(st[0] == 1 ? "PAUSE" : "START", () -> { });
        go.setOnClickListener(v -> {
            if (st[0] == 1) {
                st[2] = Math.max(0, st[1] - SystemClock.elapsedRealtime());
                st[0] = 0;
            } else {
                st[1] = SystemClock.elapsedRealtime() + st[2];
                st[0] = 1;
            }
            go.setText(st[0] == 1 ? "PAUSE" : "START");
        });
        r.addView(go, weight(1f));
        r.addView(chip("RESET", () -> {
            st[0] = 0;
            st[2] = minutes * 60000L;
            go.setText("START");
        }), weight(1f));
        w.addView(r, wide());
        return w;
    }

    private View habit(final String name, final String k) {
        final TextView c = chip("", () -> { });
        final Runnable paint = () -> {
            int last = Prefs.getInt(k + "_d", 0);
            int n = Prefs.getInt(k + "_n", 0);
            int today = Integer.parseInt(dayStamp());
            int yesterday = Integer.parseInt(new SimpleDateFormat("yyyyMMdd", Locale.ROOT)
                    .format(new Date(System.currentTimeMillis() - 86400000L)));
            int shown = last == today || last == yesterday ? n : 0;
            c.setText((last == today ? "✅ " : "⬜ ") + name + "   🔥 " + shown);
        };
        paint.run();
        c.setOnClickListener(v -> {
            int today = Integer.parseInt(dayStamp());
            int yesterday = Integer.parseInt(new SimpleDateFormat("yyyyMMdd", Locale.ROOT)
                    .format(new Date(System.currentTimeMillis() - 86400000L)));
            int last = Prefs.getInt(k + "_d", 0);
            if (last == today) {
                host.toast("Already done today");
                return;
            }
            Prefs.putInt(k + "_n", last == yesterday ? Prefs.getInt(k + "_n", 0) + 1 : 1);
            Prefs.putInt(k + "_d", today);
            host.buzz(20);
            paint.run();
        });
        c.setOnLongClickListener(v -> {
            Prefs.putInt(k + "_d", 0);
            Prefs.putInt(k + "_n", 0);
            paint.run();
            return true;
        });
        return c;
    }

    private View water(final int goal, final String k) {
        LinearLayout w = new LinearLayout(host);
        w.setOrientation(VERTICAL);
        final Supplier<Integer> count = () -> Prefs.getInt(k + "_d", 0) == Integer.parseInt(dayStamp())
                ? Prefs.getInt(k + "_n", 0) : 0;
        final TextView label = text("", 12f, Theme.TEXT);
        final WidgetBar bar = new WidgetBar(host);
        final Runnable paint = () -> {
            label.setText("💧 " + count.get() + " / " + goal + " glasses");
            bar.set(count.get() / (float) goal);
        };
        paint.run();
        w.addView(label, wide());
        w.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
        LinearLayout r = row();
        r.addView(chip("−", () -> {
            Prefs.putInt(k + "_d", Integer.parseInt(dayStamp()));
            Prefs.putInt(k + "_n", Math.max(0, count.get() - 1));
            paint.run();
        }), weight(1f));
        r.addView(chip("+ GLASS", () -> {
            Prefs.putInt(k + "_d", Integer.parseInt(dayStamp()));
            Prefs.putInt(k + "_n", count.get() + 1);
            host.buzz(12);
            paint.run();
        }), weight(2f));
        w.addView(r, wide());
        return w;
    }

    private View mood(final String k) {
        final String[] faces = {"😄", "🙂", "😐", "🙁", "😢"};
        LinearLayout w = new LinearLayout(host);
        w.setOrientation(VERTICAL);
        w.addView(plain("how is today?", 10f, Theme.DIM), wide());
        LinearLayout r = row();
        final List<TextView> chips = new ArrayList<>();
        final Runnable paint = () -> {
            int today = Integer.parseInt(dayStamp());
            int mood = Prefs.getInt(k + "_d", 0) == today ? Prefs.getInt(k + "_m", -1) : -1;
            for (int i = 0; i < chips.size(); i++) {
                pick(chips.get(i), i == mood);
            }
        };
        for (int i = 0; i < faces.length; i++) {
            final int mi = i;
            TextView c = chip(faces[i], () -> {
                Prefs.putInt(k + "_d", Integer.parseInt(dayStamp()));
                Prefs.putInt(k + "_m", mi);
                host.buzz(12);
            });
            c.setTextSize(20f);
            c.setOnClickListener(v -> {
                Prefs.putInt(k + "_d", Integer.parseInt(dayStamp()));
                Prefs.putInt(k + "_m", mi);
                host.buzz(12);
                for (int j = 0; j < chips.size(); j++) {
                    pick(chips.get(j), j == mi);
                }
            });
            chips.add(c);
            r.addView(c, weight(1f));
        }
        paint.run();
        w.addView(r, wide());
        return w;
    }

    private View appButton(final Block b) {
        final String pkg = b.a.trim();
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(8), dp(6), dp(8), dp(6));
        r.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        String label = b.b.isEmpty() ? pkg : b.b;
        try {
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, host.getPackageManager().getApplicationIcon(pkg)));
            r.addView(iv, new LinearLayout.LayoutParams(dp(30), dp(30)));
            if (b.b.isEmpty()) {
                label = host.getPackageManager().getApplicationLabel(
                        host.getPackageManager().getApplicationInfo(pkg, 0)).toString();
            }
        } catch (Exception e) {
            label = pkg.isEmpty() ? "set an app package" : "no app: " + pkg;
        }
        TextView t = text(label, 12f, Theme.TEXT);
        t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = dp(10);
        r.addView(t, tp);
        r.setClickable(true);
        r.setOnClickListener(v -> {
            Intent i = host.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                host.toast("No app with that package");
            } else {
                host.startActivity(i);
            }
        });
        return r;
    }

    private void press(Block b) {
        String t = b.b.trim();
        if (t.isEmpty()) {
            host.toast("This button has no target yet");
            return;
        }
        try {
            if (t.toLowerCase(Locale.ROOT).startsWith("scene:")) {
                String n = t.substring(6).trim();
                List<Scenes.Scene> all = Scenes.all();
                for (int i = 0; i < all.size(); i++) {
                    if (all.get(i).name.equalsIgnoreCase(n)) {
                        Scenes.apply(host, i);
                        return;
                    }
                }
                host.toast("No scene called " + n);
            } else if (t.contains(":") || t.contains("/")) {
                DeckBinds.playLink(host, t);
            } else {
                Intent i = host.getPackageManager().getLaunchIntentForPackage(t);
                if (i == null) {
                    host.toast("No app with that package");
                } else {
                    host.startActivity(i);
                }
            }
        } catch (RuntimeException e) {
            host.toast("Could not do that");
        }
    }

    /** A round clock face with hour, minute and second hands. */
    private static final class AnalogFace extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        AnalogFace(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth();
            float cx = w / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - 4;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f);
            p.setColor(Theme.ACCENT);
            cv.drawCircle(cx, cy, r, p);
            p.setStrokeWidth(2f);
            for (int i = 0; i < 12; i++) {
                double a = Math.toRadians(i * 30);
                float in = r * (i % 3 == 0 ? 0.80f : 0.88f);
                cv.drawLine(cx + (float) Math.sin(a) * in, cy - (float) Math.cos(a) * in,
                        cx + (float) Math.sin(a) * r * 0.95f, cy - (float) Math.cos(a) * r * 0.95f, p);
            }
            Calendar c = Calendar.getInstance();
            double sec = c.get(Calendar.SECOND);
            double min = c.get(Calendar.MINUTE) + sec / 60.0;
            double hr = (c.get(Calendar.HOUR) % 12) + min / 60.0;
            hand(cv, cx, cy, hr * 30, r * 0.5f, 5f, Theme.TEXT);
            hand(cv, cx, cy, min * 6, r * 0.75f, 3.5f, Theme.TEXT);
            hand(cv, cx, cy, sec * 6, r * 0.85f, 1.8f, Theme.ACCENT);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.ACCENT);
            cv.drawCircle(cx, cy, 5f, p);
        }

        private void hand(Canvas cv, float cx, float cy, double deg, float len, float width, int color) {
            double a = Math.toRadians(deg);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(width);
            p.setColor(color);
            cv.drawLine(cx, cy, cx + (float) Math.sin(a) * len, cy - (float) Math.cos(a) * len, p);
        }
    }
}
