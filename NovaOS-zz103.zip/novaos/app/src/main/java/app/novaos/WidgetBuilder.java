package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Build your own widget out of blocks. Pick MY WIDGET 1, 2 or 3, add blocks, move them around. Then add it to a page. */
final class WidgetBuilder extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout list;
    private final LinearLayout preview;
    private int slot = 1;

    WidgetBuilder(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("WIDGET BUILDER", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));
        TextView hint = text("61 kinds of blocks: clocks, dates, phone facts, tools, games. Tap + BLOCK, then use the arrows to put them in order. Add MY WIDGET 1, 2 or 3 to your home with PUT ON HOME SCREEN.", 9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        hint.setPadding(0, dp(6), 0, dp(8));
        col.addView(hint);

        LinearLayout slots = new LinearLayout(host);
        for (int i = 1; i <= 3; i++) {
            final int s = i;
            TextView c = chip("SLOT " + i, () -> {
                slot = s;
                build();
            });
            c.setTag("slot" + i);
            slots.addView(c);
        }
        slots.addView(chip("+ BLOCK", this::addBlock));
        col.addView(slots);
        LinearLayout acts = new LinearLayout(host);
        acts.setPadding(0, dp(8), 0, 0);
        acts.addView(chip("PUT ON HOME SCREEN", this::putOnHome));
        acts.addView(chip("CLEAR", () -> {
            CustomWidget.save(slot, new java.util.ArrayList<>());
            build();
        }));
        col.addView(acts);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout inner = new LinearLayout(host);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(0, dp(10), 0, dp(30));
        preview = new LinearLayout(host);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setPadding(dp(12), dp(10), dp(12), dp(10));
        preview.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        inner.addView(preview, new LinearLayout.LayoutParams(-1, -2));
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        inner.addView(list, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(inner);
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        addView(col, new FrameLayout.LayoutParams(-1, -1));
        build();
    }

    private void build() {
        preview.removeAllViews();
        preview.addView(text("PREVIEW · MY WIDGET " + slot, 9f, Theme.DIM));
        CustomWidget cw = new CustomWidget(host, slot);
        preview.addView(cw, new LinearLayout.LayoutParams(-1, -2));
        cw.refresh();
        for (int i = 1; i <= 3; i++) {
            View chipV = findViewWithTag("slot" + i);
            if (chipV instanceof TextView) {
                ((TextView) chipV).setTextColor(i == slot ? Theme.BG : Theme.ACCENT);
                chipV.setBackground(Theme.rounded(i == slot ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
            }
        }
        list.removeAllViews();
        final List<CustomWidget.Block> blocks = CustomWidget.load(slot);
        for (int i = 0; i < blocks.size(); i++) {
            final int idx = i;
            final CustomWidget.Block b = blocks.get(i);
            LinearLayout r = new LinearLayout(host);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(10), dp(8), dp(6), dp(8));
            r.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
            String desc = CustomWidget.TYPES[b.type] + (b.a.isEmpty() ? "" : "  ·  " + b.a);
            TextView t = text(desc, 11f, Theme.TEXT);
            t.setGravity(Gravity.START);
            t.setSingleLine(true);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(chip("▲", () -> move(blocks, idx, -1)));
            r.addView(chip("▼", () -> move(blocks, idx, 1)));
            r.addView(chip("\u29C9", () -> {
                if (blocks.size() >= 30) {
                    host.toast("30 blocks is the most");
                    return;
                }
                CustomWidget.Block copy = new CustomWidget.Block();
                copy.type = b.type;
                copy.a = b.a;
                copy.b = b.b;
                blocks.add(idx + 1, copy);
                CustomWidget.save(slot, blocks);
                build();
            }));
            r.addView(chip("✎", () -> editBlock(blocks, b)));
            r.addView(chip("✕", () -> {
                blocks.remove(idx);
                CustomWidget.save(slot, blocks);
                build();
            }));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(6);
            list.addView(r, lp);
        }
    }

    private void putOnHome() {
        final String id = "mine" + slot;
        new AlertDialog.Builder(host).setTitle("Which home page?")
                .setItems(new String[] {"Page 1", "Page 2"}, (d, page) ->
                        new AlertDialog.Builder(host).setTitle("Size")
                                .setItems(new String[] {"HALF", "WIDE (full width)", "BIG (full width, tall)"},
                                        (d2, size) -> {
                                            List<Widgets.Placed> placed = Widgets.load();
                                            placed.add(new Widgets.Placed(page, id, size));
                                            Widgets.save(placed);
                                            host.hideOverlay();
                                            host.showHome();
                                            if (Prefs.getInt(AltHome.K_LAYOUT, 0) == 0) {
                                                host.toast("MY WIDGET " + slot + " is on page " + (page + 1));
                                            } else {
                                                // the other home screens keep widgets in the WIDGETS sheet
                                                host.toast("Added. Open WIDGETS on your home screen to see it");
                                                host.root.postDelayed(() -> host.showOverlay(new WidgetsSheet(host)), 700);
                                            }
                                        }).show()).show();
    }

    private void move(List<CustomWidget.Block> blocks, int idx, int d) {
        int j = idx + d;
        if (j < 0 || j >= blocks.size()) {
            return;
        }
        CustomWidget.Block b = blocks.remove(idx);
        blocks.add(j, b);
        CustomWidget.save(slot, blocks);
        build();
    }

    private void addBlock() {
        new AlertDialog.Builder(host).setTitle("Add a block: pick a group")
                .setItems(CustomWidget.GROUPS, (d, group) -> {
                    final int[] items = CustomWidget.GROUP_ITEMS[group];
                    String[] names = new String[items.length];
                    for (int i = 0; i < items.length; i++) {
                        names[i] = CustomWidget.TYPES[items[i]];
                    }
                    new AlertDialog.Builder(host).setTitle(CustomWidget.GROUPS[group])
                            .setItems(names, (d2, which) -> add(items[which])).show();
                }).show();
    }

    private void add(int type) {
        List<CustomWidget.Block> blocks = CustomWidget.load(slot);
        if (blocks.size() >= 30) {
            host.toast("30 blocks is the most");
            return;
        }
        CustomWidget.Block b = new CustomWidget.Block();
        b.type = type;
        CustomWidget.defaults(b);
        blocks.add(b);
        CustomWidget.save(slot, blocks);
        build();
        if (CustomWidget.hints(type) != null) {
            editBlock(blocks, b);
        }
    }

    private void editBlock(final List<CustomWidget.Block> blocks, final CustomWidget.Block b) {
        String[] hints = CustomWidget.hints(b.type);
        if (hints == null) {
            host.toast("Nothing to edit on this block");
            return;
        }
        final EditText a = new EditText(host);
        final EditText c = new EditText(host);
        a.setSingleLine(true);
        c.setSingleLine(true);
        a.setText(b.a);
        c.setText(b.b);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        if (hints[0] != null) {
            a.setHint(hints[0]);
            box.addView(a);
        }
        if (hints[1] != null) {
            c.setHint(hints[1]);
            box.addView(c);
        }
        new AlertDialog.Builder(host).setTitle(CustomWidget.TYPES[b.type]).setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    if (hints[0] != null) {
                        b.a = a.getText().toString().trim();
                    }
                    if (hints[1] != null) {
                        b.b = c.getText().toString().trim();
                    }
                    CustomWidget.save(slot, blocks);
                    build();
                }).setNegativeButton("Cancel", null).show();
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }
}
