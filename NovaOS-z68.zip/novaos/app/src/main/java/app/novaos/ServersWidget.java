package app.novaos;

import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The SERVERS page on the quick panel: live player counts for four favourite Arma Reforger servers, read from the
 * BattleMetrics API. Each favourite is a search phrase. The best match (most players, name containing every word of
 * the phrase) is shown, and tapping a row lets you lock it to one exact server or change the phrase.
 * Refreshes by itself every minute while the page is on screen.
 */
final class ServersWidget extends LinearLayout {
    private static final int FAVS = 4;
    private static final String BASE = "https://api.battlemetrics.com";
    private static final String[] DEFAULTS = {"WCS Serhiivka East", "WCS Serhiivka West",
        "Spearhead Yunakivka", "NEXTGEN France"};
    private static final long REFRESH_MS = 60_000L;

    private static final class Match {
        String id = "";
        String name = "";
        int players;
        int max;
        boolean online;
    }

    private static final class Result {
        Match m;
        String err = "";
    }

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView[] labels = new TextView[FAVS];
    private final TextView[] subs = new TextView[FAVS];
    private final TextView[] counts = new TextView[FAVS];
    private final Result[] results = new Result[FAVS];
    private final TextView status;
    private String statusText = "tap a row to pick a server";
    private boolean loading;
    private long lastLoad;

    private final Runnable auto = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                load(false);
            }
            ui.postDelayed(this, REFRESH_MS);
        }
    };

    ServersWidget(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        for (int i = 0; i < FAVS; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
            row.setClickable(true);
            Theme.ripple(row);
            row.setOnClickListener(v -> pick(idx));
            LinearLayout left = new LinearLayout(host);
            left.setOrientation(VERTICAL);
            labels[i] = mono(query(i).toUpperCase(Locale.ROOT), 11f, Theme.TEXT);
            labels[i].setSingleLine(true);
            labels[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i] = mono("", 8f, Theme.DIM);
            subs[i].setSingleLine(true);
            subs[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i].setVisibility(GONE);
            left.addView(labels[i]);
            left.addView(subs[i]);
            row.addView(left, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            counts[i] = mono("--", 13f, Theme.DIM);
            counts[i].setPadding(dp(8), 0, 0, 0);
            row.addView(counts[i]);
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(3);
            addView(row, lp);
        }
        LinearLayout bottom = new LinearLayout(host);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        status = mono(statusText, 9f, Theme.DIM);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.END);
        bottom.addView(status, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        bottom.addView(button("TOKEN", this::editToken));
        bottom.addView(button("REFRESH", () -> load(true)));
        LayoutParams bp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(4);
        addView(bottom, bp);
        render();
    }

    /** Called when the page is shown. */
    void refresh() {
        render();
        load(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.postDelayed(auto, REFRESH_MS);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ settings

    private static String query(int i) {
        String q = Prefs.getString("srv_q" + i, DEFAULTS[i]);
        return q == null || q.trim().isEmpty() ? DEFAULTS[i] : q.trim();
    }

    private static String token() {
        String t = Prefs.getString("bm_token", "");
        return t == null ? "" : t.trim();
    }

    // ------------------------------------------------------------------ loading

    private void load(boolean force) {
        long now = System.currentTimeMillis();
        if (loading || (!force && now - lastLoad < 40_000L)) {
            return;
        }
        loading = true;
        lastLoad = now;
        statusText = "updating...";
        status.setText(statusText);
        new Thread(() -> {
            final Result[] res = new Result[FAVS];
            for (int i = 0; i < FAVS; i++) {
                res[i] = fetchOne(i);
            }
            ui.post(() -> {
                loading = false;
                int bad = 0;
                String firstErr = "";
                for (int i = 0; i < FAVS; i++) {
                    results[i] = res[i];
                    if (res[i].m == null) {
                        bad++;
                        if (firstErr.isEmpty()) {
                            firstErr = res[i].err;
                        }
                    }
                }
                String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                statusText = bad == FAVS ? firstErr + " · " + time : "updated " + time;
                render();
            });
        }).start();
    }

    private Result fetchOne(int i) {
        Result r = new Result();
        String id = Prefs.getString("srv_id" + i, "");
        String tok = token();
        String url = id == null || id.isEmpty() ? searchUrl(query(i)) : BASE + "/servers/" + id;
        String body = Http.get(url, tok.isEmpty() ? null : tok);
        if (body == null) {
            r.err = errFor(Http.lastCode);
            return r;
        }
        try {
            Object data = new JSONObject(body).opt("data");
            if (data instanceof JSONObject) {
                r.m = parse((JSONObject) data);
            } else if (data instanceof JSONArray) {
                r.m = best(parseAll((JSONArray) data), query(i));
            }
            if (r.m == null) {
                r.err = "not found";
            }
        } catch (Exception e) {
            r.err = "bad reply";
        }
        return r;
    }

    private static String searchUrl(String q) {
        try {
            return BASE + "/servers?filter%5Bgame%5D=reforger&filter%5Bsearch%5D=" + URLEncoder.encode(q, "UTF-8")
                    + "&page%5Bsize%5D=8&sort=-players";
        } catch (Exception e) {
            return BASE + "/servers?filter%5Bgame%5D=reforger&page%5Bsize%5D=8&sort=-players";
        }
    }

    private static String errFor(int code) {
        if (code == 401 || code == 403) {
            return "needs token";
        }
        if (code == 429) {
            return "rate limit";
        }
        return code <= 0 ? "no network" : "error " + code;
    }

    private static Match parse(JSONObject o) {
        JSONObject a = o.optJSONObject("attributes");
        if (a == null) {
            return null;
        }
        Match m = new Match();
        m.id = o.optString("id");
        m.name = a.optString("name");
        m.players = a.optInt("players", 0);
        m.max = a.optInt("maxPlayers", 0);
        m.online = "online".equalsIgnoreCase(a.optString("status"));
        return m;
    }

    private static List<Match> parseAll(JSONArray arr) {
        List<Match> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            Match m = o == null ? null : parse(o);
            if (m != null) {
                out.add(m);
            }
        }
        return out;
    }

    /** The busiest server whose name has every word of the phrase, or just the first result if none does. */
    private static Match best(List<Match> list, String q) {
        if (list.isEmpty()) {
            return null;
        }
        String[] words = q.toLowerCase(Locale.ROOT).split("\\s+");
        Match top = null;
        for (Match m : list) {
            String n = m.name.toLowerCase(Locale.ROOT);
            boolean all = true;
            for (String w : words) {
                if (!n.contains(w)) {
                    all = false;
                    break;
                }
            }
            if (all && (top == null || m.players > top.players)) {
                top = m;
            }
        }
        return top != null ? top : list.get(0);
    }

    // ------------------------------------------------------------------ drawing

    private void render() {
        for (int i = 0; i < FAVS; i++) {
            labels[i].setText(query(i).toUpperCase(Locale.ROOT));
            Result r = results[i];
            if (r == null) {
                counts[i].setText(loading ? "..." : "--");
                counts[i].setTextColor(Theme.DIM);
                subs[i].setVisibility(GONE);
                continue;
            }
            if (r.m == null) {
                counts[i].setText(r.err);
                counts[i].setTextColor(0xFFFF6B7F);
                counts[i].setTextSize(10f);
                subs[i].setVisibility(GONE);
                continue;
            }
            counts[i].setTextSize(13f);
            counts[i].setText(r.m.online ? r.m.players + "/" + r.m.max : "offline");
            counts[i].setTextColor(r.m.online ? Theme.ACCENT : Theme.DIM);
            subs[i].setText(r.m.name);
            subs[i].setVisibility(r.m.name.equalsIgnoreCase(query(i)) ? GONE : VISIBLE);
        }
        status.setText(statusText);
    }

    // ------------------------------------------------------------------ dialogs

    /** Tap a row: shows the servers matching its phrase so you can lock one, or change the phrase. */
    private void pick(final int i) {
        status.setText("searching...");
        new Thread(() -> {
            final List<Match> list = new ArrayList<>();
            String tok = token();
            String body = Http.get(searchUrl(query(i)), tok.isEmpty() ? null : tok);
            if (body != null) {
                try {
                    list.addAll(parseAll(new JSONObject(body).getJSONArray("data")));
                } catch (Exception ignored) {
                    // an unreadable reply just means an empty list
                }
            }
            final int code = Http.lastCode;
            ui.post(() -> showPicker(i, list, code));
        }).start();
    }

    private void showPicker(final int i, final List<Match> list, int code) {
        status.setText(statusText);
        AlertDialog.Builder b = new AlertDialog.Builder(host).setTitle(query(i));
        if (list.isEmpty()) {
            b.setMessage(code == 200 ? "No servers match this search. Try a shorter phrase." : errFor(code));
        } else {
            String[] items = new String[list.size()];
            for (int k = 0; k < items.length; k++) {
                Match m = list.get(k);
                items[k] = m.name + "  (" + (m.online ? m.players + "/" + m.max : "offline") + ")";
            }
            b.setItems(items, (d, which) -> {
                Prefs.putString("srv_id" + i, list.get(which).id);
                load(true);
            });
        }
        b.setPositiveButton("CHANGE SEARCH", (d, w) -> editQuery(i));
        b.setNeutralButton("AUTO", (d, w) -> {
            Prefs.putString("srv_id" + i, "");
            load(true);
        });
        b.setNegativeButton("CLOSE", null);
        b.show();
    }

    private void editQuery(final int i) {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setText(query(i));
        new AlertDialog.Builder(host)
                .setTitle("Search BattleMetrics")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    String q = e.getText().toString().trim();
                    if (!q.isEmpty()) {
                        Prefs.putString("srv_q" + i, q);
                        Prefs.putString("srv_id" + i, "");
                        load(true);
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void editToken() {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setHint("optional BattleMetrics token");
        e.setText(token());
        new AlertDialog.Builder(host)
                .setTitle("BattleMetrics token")
                .setMessage("Only needed if the counts say \"needs token\". Make a free one at battlemetrics.com/developers")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    Prefs.putString("bm_token", e.getText().toString().trim());
                    load(true);
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    // ------------------------------------------------------------------ small helpers

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView mono(String text, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String text, Runnable action) {
        TextView b = mono(text, 9f, Theme.TEXT);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }
}
