package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * A slot machine with play coins (no real money, just for fun). Three reels with six symbols each,
 * a lever on the side. Pull it and the reels spin and stop one after another. Wins make the reels glow
 * and shower the screen with confetti.
 */
final class SlotMachine extends LinearLayout {
    static final String[] SYMBOLS = {"🍒", "🍋", "🔔", "⭐", "💎", "7"};
    // payout multiplier for three of a kind, per symbol above
    private static final int[] TRIPLE = {2, 2, 3, 4, 5, 10};
    private static final int N = SYMBOLS.length;
    private final int[] BETS = Upgrades.bets();
    private int autoLeft;
    private static final String K_COINS = "slot_coins";
    private static final String K_BET = "slot_bet";
    /** Coins lost on this machine since the last jackpot. The 777 jackpot pays 70% of it, plus 100. */
    private static final String K_POT = "slot_pot";

    private final NovaActivity host;
    private final Reel[] reels = new Reel[3];
    private final Lever lever;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView message;
    private final TextView potText;
    private final Marquee marquee;
    private final Random rnd = new Random();
    private boolean spinning;
    private int coins;
    private int betIndex;

    SlotMachine(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        coins = Prefs.getInt(K_COINS, 100);
        betIndex = Math.max(0, Math.min(BETS.length - 1, Prefs.getInt(K_BET, 1)));

        // top line: coins, message, bet
        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        coinsText = label(11f, Theme.TEXT);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (!spinning && coins < BETS[betIndex]) {
                coins = 100;
                save();
                say("+100 FREE COINS", Theme.ACCENT);
            }
        });
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        message = label(11f, Theme.DIM);
        message.setGravity(Gravity.CENTER);
        top.addView(message, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.4f));
        betText = label(11f, Theme.ACCENT);
        betText.setGravity(Gravity.END);
        betText.setClickable(true);
        betText.setOnClickListener(v -> {
            if (!spinning) {
                betIndex = (betIndex + 1) % BETS.length;
                Prefs.putInt(K_BET, betIndex);
                refresh();
            }
        });
        top.addView(betText, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        addView(top, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        // the cabinet: gold frame, marquee lights, three reels and the lever
        LinearLayout cab = new LinearLayout(host);
        cab.setOrientation(VERTICAL);
        GradientDrawable frame = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {0xFF4B3688, 0xFF1B1238});
        frame.setCornerRadius(Theme.dp(host, 16));
        frame.setStroke(Theme.dp(host, 2), 0xFFE9B949);
        cab.setBackground(frame);
        cab.setPadding(Theme.dp(host, 7), Theme.dp(host, 5), Theme.dp(host, 7), Theme.dp(host, 6));
        marquee = new Marquee(host);
        cab.addView(marquee, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 9)));
        LinearLayout mid = new LinearLayout(host);
        mid.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            reels[i] = new Reel(host);
            reels[i].pos = rnd.nextInt(N);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, Theme.dp(host, 76), 1f);
            rp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), 0);
            mid.addView(reels[i], rp);
        }
        lever = new Lever(host);
        lever.setOnClickListener(v -> {
            if (autoLeft > 0) {
                autoLeft = 0;
                say("AUTO OFF", Theme.DIM);
                return;
            }
            pull();
        });
        lever.setOnLongClickListener(v -> {
            if (!Upgrades.has("autospin")) {
                host.toast("Auto-spin x10 is in the Coin Shop");
            } else if (!spinning) {
                autoLeft = 9;
                pull();
            }
            return true;
        });
        mid.addView(lever, new LinearLayout.LayoutParams(Theme.dp(host, 42), Theme.dp(host, 76)));
        cab.addView(mid, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        mp.topMargin = Theme.dp(host, 5);
        addView(cab, mp);

        potText = label(10f, 0xFFFFD35A);
        potText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        pp.topMargin = Theme.dp(host, 5);
        addView(potText, pp);
        TextView table = label(9f, Theme.DIM);
        table.setText("💎 ×5  ⭐ ×4  🔔 ×3  🍒🍋 ×2  pair = bet back");
        table.setGravity(Gravity.CENTER);
        addView(table, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        refresh();
    }

    private TextView label(float size, int color) {
        TextView t = new TextView(host);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setSingleLine(true);
        return t;
    }

    private void save() {
        Prefs.putInt(K_COINS, coins);
        refresh();
    }

    private void refresh() {
        coinsText.setText(coins < BETS[betIndex] && !spinning ? "TAP: FREE COINS" : "COINS " + coins);
        betText.setText("BET " + BETS[betIndex]);
        potText.setText("777 = 70% OF LOST + 100  \u00B7  POT " + Prefs.getInt(K_POT, 0));
    }

    private void say(String s, int color) {
        message.setText(s);
        message.setTextColor(color);
    }

    // ------------------------------------------------------------------ the pull

    private void pull() {
        if (spinning) {
            return;
        }
        coins = Prefs.getInt(K_COINS, coins);
        int bet = BETS[betIndex];
        if (coins < bet) {
            say("OUT OF COINS", Theme.ACCENT);
            return;
        }
        coins -= bet;
        Prefs.putInt(K_COINS, coins);
        Quests.event(host, "spin");
        int spins = Badges.bump("spins");
        Badges.unlock(host, "spin1");
        if (spins >= 100) {
            Badges.unlock(host, "spin100");
        }
        spinning = true;
        refresh();
        say("", Theme.DIM);
        lever.pull();
        marquee.mode(1);
        Sfx.play(Sfx.CLICK);

        final int[] result = roll();
        final int[] done = {0};
        final float[] from = new float[3];
        final float[] to = new float[3];
        final long[] dur = new long[3];
        for (int i = 0; i < 3; i++) {
            final Reel r = reels[i];
            r.setGlow(0f);
            int cur = Math.round(r.pos);
            int curSym = ((cur % N) + N) % N;
            int steps = ((result[i] - curSym) % N + N) % N;
            float target = cur + (3 + i * 2) * N + steps;
            from[i] = r.pos;
            to[i] = target;
            dur[i] = 1500L + 600L * i;
        }
        Sfx.playReels(from, to, dur);
        for (int i = 0; i < 3; i++) {
            final Reel r = reels[i];
            ValueAnimator a = ValueAnimator.ofFloat(from[i], to[i]);
            a.setDuration(dur[i]);
            a.setInterpolator(new DecelerateInterpolator(1.5f));
            a.addUpdateListener(an -> r.setPos((float) an.getAnimatedValue()));
            a.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    done[0]++;
                    if (done[0] == 3) {
                        settle(result);
                    }
                }
            });
            a.start();
        }
    }

    /**
     * Picks the three symbols. The odds are set by hand and are very harsh: about 1.5% for three of a kind,
     * 3% for a pair, and roughly 9 coins back for every 100 bet.
     */
    private int[] roll() {
        double p = rnd.nextDouble();
        boolean charm = Upgrades.charm();
        double[] cut = {charm ? 0.08 : 0.06, 0.0005, 0.001, 0.002, 0.003, 0.005}; // 7, gem, star, bell, cherry, lemon
        int[] symOrder = {5, 4, 3, 2, 0, 1};
        double acc = 0;
        for (int i = 0; i < cut.length; i++) {
            acc += cut[i];
            if (p < acc) {
                int s = symOrder[i];
                return new int[] {s, s, s};
            }
        }
        acc += charm ? 0.06 : 0.03;
        if (p < acc) {
            int a = rnd.nextInt(N);
            int b = (a + 1 + rnd.nextInt(N - 1)) % N;
            int[] out = {a, a, a};
            out[rnd.nextInt(3)] = b;
            return out;
        }
        // a loss: three different symbols
        int a = rnd.nextInt(N);
        int b = (a + 1 + rnd.nextInt(N - 1)) % N;
        int c;
        do {
            c = rnd.nextInt(N);
        } while (c == a || c == b);
        return new int[] {a, b, c};
    }

    private void settle(int[] r) {
        spinning = false;
        int bet = BETS[betIndex];
        int pot = Prefs.getInt(K_POT, 0);
        int payout;
        if (r[0] == r[1] && r[1] == r[2]) {
            int win = bet * TRIPLE[r[0]];
            boolean jackpot = r[0] == SYMBOLS.length - 1;
            if (jackpot) {
                // the machine gives back 70% of what it took since the last jackpot, and 100 on top
                win = Math.max(win, Math.round(pot * 0.7f) + 100);
                pot = 0;
            }
            payout = win;
            coins += win;
            Prefs.putInt(K_COINS, coins);
            say((jackpot ? "JACKPOT +" : "WIN +") + win + "!", Theme.ACCENT);
            Prefs.putInt("stat_slotwon", Prefs.getInt("stat_slotwon", 0) + win);
            if (jackpot) {
                Badges.bump("jackpots");
                Badges.unlock(host, "jackpot");
            }
            for (Reel x : reels) {
                x.setGlow(1f);
            }
            marquee.mode(2);
            Sfx.play(Sfx.WIN);
            int[] at = new int[2];
            getLocationOnScreen(at);
            host.confetti(at[0] + getWidth() / 2f, at[1] + getHeight() * 0.45f);
            if (jackpot) {
                host.confetti(at[0] + getWidth() * 0.25f, at[1] + getHeight() * 0.4f);
                host.confetti(at[0] + getWidth() * 0.75f, at[1] + getHeight() * 0.4f);
            }
            host.buzz(60);
        } else if (r[0] == r[1] || r[1] == r[2] || r[0] == r[2]) {
            payout = bet;
            coins += bet;
            Prefs.putInt(K_COINS, coins);
            say("PAIR · BET BACK", Theme.TEXT);
            Sfx.play(Sfx.COIN);
            marquee.mode(0);
            for (int i = 0; i < 3; i++) {
                boolean part = (r[i] == r[(i + 1) % 3]) || (r[i] == r[(i + 2) % 3]);
                if (part) {
                    reels[i].setGlow(0.45f);
                }
            }
        } else {
            payout = 0;
            say(coins < BETS[betIndex] ? "BROKE..." : "NO LUCK", Theme.DIM);
            Sfx.play(Sfx.LOSE);
            marquee.mode(0);
            if (coins < BETS[0]) {
                Badges.unlock(host, "broke");
            }
        }
        // whatever the machine kept goes into the pot for the next jackpot
        pot += Math.max(0, bet - payout);
        Prefs.putInt(K_POT, pot);
        refresh();
        if (autoLeft > 0) {
            autoLeft--;
            if (payout >= bet * 5 || coins < BETS[betIndex]) {
                autoLeft = 0;
            } else {
                postDelayed(() -> {
                    if (isAttachedToWindow() && autoLeft >= 0 && !spinning) {
                        pull();
                    }
                }, 1100);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        for (Reel r : reels) {
            r.stopGlow();
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ reel

    /** One column of symbols that scrolls downward. pos 3.0 means symbol number 3 sits in the middle. */
    private static final class Reel extends View {
        float pos;
        private float glow;
        private ValueAnimator pulse;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float d;
        private float blur;
        private Shader glass;
        private Shader shade;
        private int shapeH;
        private final Path tri = new Path();

        Reel(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            paint.setTextAlign(Paint.Align.CENTER);
            frame.setStyle(Paint.Style.STROKE);
        }

        void setPos(float p) {
            blur = Math.min(1f, Math.abs(p - pos) / 0.55f);
            pos = p;
            invalidate();
        }

        void setGlow(float g) {
            stopGlow();
            glow = g;
            if (g > 0.5f) {
                pulse = ValueAnimator.ofFloat(0.55f, 1f);
                pulse.setDuration(520);
                pulse.setRepeatCount(5);
                pulse.setRepeatMode(ValueAnimator.REVERSE);
                pulse.addUpdateListener(a -> {
                    glow = (float) a.getAnimatedValue();
                    invalidate();
                });
                pulse.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator animation) {
                        glow = 0.4f;
                        invalidate();
                    }
                });
                pulse.start();
            }
            invalidate();
        }

        void stopGlow() {
            if (pulse != null) {
                pulse.removeAllListeners();
                pulse.cancel();
                pulse = null;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            rect.set(2 * d, 2 * d, w - 2 * d, h - 2 * d);
            if (shapeH != (int) h) {
                shapeH = (int) h;
                glass = new LinearGradient(0, 0, 0, h, new int[] {0xFF0E0820, 0xFF3A2C6A, 0xFF0E0820},
                        new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
                shade = new LinearGradient(0, 0, 0, h, new int[] {0xE6000000, 0x00000000, 0x00000000, 0xE6000000},
                        new float[] {0f, 0.34f, 0.66f, 1f}, Shader.TileMode.CLAMP);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(glass);
            c.drawRoundRect(rect, 12 * d, 12 * d, paint);
            paint.setShader(null);

            // the symbols, clipped to the window
            c.save();
            c.clipRect(rect);
            float cell = h * 0.52f;
            float cy = h / 2f;
            int base = (int) Math.floor(pos);
            paint.setTextSize(cell * 0.62f);
            for (int k = -2; k <= 3; k++) {
                int i = base + k;
                float y = cy + (pos - i) * cell;
                float dist = Math.min(1.4f, Math.abs(y - cy) / cell);
                int idx = ((i % N) + N) % N;
                paint.setAlpha((int) (255 * (1f - 0.62f * dist)));
                float size = cell * 0.62f * (1f - 0.18f * dist);
                paint.setTextSize(size);
                if (idx == N - 1) {
                    paint.setColor(0xFFFF4D6D);
                    paint.setFakeBoldText(true);
                } else {
                    paint.setColor(0xFFFFFFFF);
                    paint.setFakeBoldText(false);
                }
                paint.setAlpha((int) (255 * (1f - 0.62f * dist)));
                float base2 = y - (paint.ascent() + paint.descent()) / 2f;
                if (blur > 0.25f) {
                    // a fast reel smears: draw the symbol again above and below, fainter
                    int a0 = (int) (255 * (1f - 0.62f * dist) * 0.45f);
                    paint.setAlpha(a0);
                    c.drawText(SYMBOLS[idx], w / 2f, base2 - blur * cell * 0.3f, paint);
                    c.drawText(SYMBOLS[idx], w / 2f, base2 + blur * cell * 0.3f, paint);
                    paint.setAlpha((int) (255 * (1f - 0.62f * dist) * (1f - 0.5f * blur)));
                }
                c.drawText(SYMBOLS[idx], w / 2f, base2, paint);
            }
            paint.setFakeBoldText(false);
            // the drum curves away at the top and bottom
            paint.setShader(shade);
            paint.setAlpha(255);
            c.drawRect(rect, paint);
            paint.setShader(null);
            c.restore();

            // the win line with little arrows on both sides
            paint.setColor(0x66FF4D6D);
            c.drawRect(rect.left, cy - 0.6f * d, rect.right, cy + 0.6f * d, paint);
            paint.setColor(0xFFFF4D6D);
            tri.reset();
            tri.moveTo(rect.left, cy - 4 * d);
            tri.lineTo(rect.left + 5 * d, cy);
            tri.lineTo(rect.left, cy + 4 * d);
            tri.close();
            tri.moveTo(rect.right, cy - 4 * d);
            tri.lineTo(rect.right - 5 * d, cy);
            tri.lineTo(rect.right, cy + 4 * d);
            tri.close();
            c.drawPath(tri, paint);
            // a glass highlight
            paint.setColor(0x14FFFFFF);
            c.drawRoundRect(rect.left + 3 * d, rect.top + 3 * d, rect.left + 9 * d, rect.bottom - 3 * d, 3 * d, 3 * d, paint);

            // the glow frame
            float g = glow;
            int rgb = Theme.GLOW & 0xFFFFFF;
            if (g > 0f) {
                for (int i = 3; i >= 1; i--) {
                    frame.setColor((((int) (70 * g / i)) << 24) | rgb);
                    frame.setStrokeWidth((2 + i * 3.5f) * d);
                    c.drawRoundRect(rect, 14 * d, 14 * d, frame);
                }
                frame.setColor(((int) (120 + 135 * g) << 24) | (Theme.ACCENT & 0xFFFFFF));
            } else {
                frame.setColor(0x55E9B949);
            }
            frame.setStrokeWidth(1.6f * d);
            c.drawRoundRect(rect, 14 * d, 14 * d, frame);
        }
    }

    // ------------------------------------------------------------------ lever

    /** The arm on the side. Tap it and the knob swings down and back up. */
    private static final class Lever extends View {
        private float t; // 0 = up, 1 = down
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private ValueAnimator swing;

        Lever(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            setClickable(true);
        }

        void pull() {
            if (swing != null) {
                swing.cancel();
            }
            swing = ValueAnimator.ofFloat(0f, 1f, 0f);
            swing.setDuration(750);
            swing.addUpdateListener(a -> {
                t = (float) a.getAnimatedValue();
                invalidate();
            });
            swing.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            return super.onTouchEvent(e);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (swing != null) {
                swing.cancel();
            }
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float r = 12 * d;
            float topY = r + 4 * d;
            float botY = h - r - 6 * d;
            // the groove
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x33FFFFFF);
            c.drawRoundRect(cx - 3 * d, topY, cx + 3 * d, botY, 3 * d, 3 * d, paint);
            // arm and knob
            float ky = topY + (botY - topY) * t;
            paint.setColor(0x66FFFFFF);
            paint.setStrokeWidth(3 * d);
            c.drawLine(cx, botY, cx, ky, paint);
            int rgb = Theme.GLOW & 0xFFFFFF;
            paint.setColor((0x30 << 24) | rgb);
            c.drawCircle(cx, ky, r * 1.9f, paint);
            paint.setColor((0x60 << 24) | rgb);
            c.drawCircle(cx, ky, r * 1.4f, paint);
            paint.setColor(Theme.ACCENT);
            c.drawCircle(cx, ky, r, paint);
            paint.setColor(0x55FFFFFF);
            c.drawCircle(cx - r * 0.3f, ky - r * 0.3f, r * 0.35f, paint);
        }
    }

    // ------------------------------------------------------------------ marquee lights

    /** A row of bulbs along the top of the cabinet: they twinkle, chase while the reels spin and flash on a win. */
    private static final class Marquee extends View {
        private int mode;
        private long until;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                if (!isAttachedToWindow()) {
                    return;
                }
                if (mode == 2 && System.currentTimeMillis() > until) {
                    mode = 0;
                }
                if (isShown()) {
                    invalidate();
                }
                postDelayed(this, mode == 0 ? 160 : 70);
            }
        };

        Marquee(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        void mode(int m) {
            mode = m;
            until = System.currentTimeMillis() + 3200;
            invalidate();
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(loop);
            post(loop);
        }

        @Override
        protected void onDetachedFromWindow() {
            removeCallbacks(loop);
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas c) {
            int n = 17;
            float w = getWidth();
            float h = getHeight();
            long t = System.currentTimeMillis();
            for (int i = 0; i < n; i++) {
                float x = w * (i + 0.5f) / n;
                boolean on;
                if (mode == 1) {
                    on = ((i - (t / 55)) % 4 + 4) % 4 < 2;
                } else if (mode == 2) {
                    on = ((t / 140) % 2 == 0) == (i % 2 == 0);
                } else {
                    on = (i + t / 450) % 3 == 0;
                }
                int col = i % 2 == 0 ? 0xFFFFD35A : 0xFFFF6B9A;
                paint.setStyle(Paint.Style.FILL);
                if (on) {
                    paint.setColor((0x40 << 24) | (col & 0xFFFFFF));
                    c.drawCircle(x, h / 2f, h * 0.62f, paint);
                }
                paint.setColor(on ? col : ((0x55 << 24) | (col & 0xFFFFFF)));
                c.drawCircle(x, h / 2f, h * 0.3f, paint);
            }
        }
    }
}
