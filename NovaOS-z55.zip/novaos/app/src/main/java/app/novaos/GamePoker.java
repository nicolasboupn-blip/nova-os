package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Three Card Poker against the dealer. Ante, then PLAY (same amount again) or FOLD. The dealer needs Queen high or
 * better to qualify. Ante pays 1 to 1 on a win, play pays 1 to 1 if the dealer qualifies. Ante bonus: straight 1 to 1,
 * three of a kind 4 to 1, straight flush 5 to 1, paid even when you fold.
 */
final class GamePoker extends Game {
    private static final int[] CHIPS = {5, 10, 25, 50, 100, 1000, 10000, 100000, 1000000};
    private static final String[] SUITS = {"♠", "♥", "♦", "♣"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    private static final String[] HANDS = {"HIGH CARD", "PAIR", "FLUSH", "STRAIGHT", "THREE OF A KIND", "STRAIGHT FLUSH"};

    private final Random rnd = new Random();
    private final int[] player = new int[3];
    private final int[] dealer = new int[3];
    private final LinearLayout dealerRow;
    private final LinearLayout playerRow;
    private final TextView dealerLabel;
    private final TextView playerLabel;
    private final TextView message;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView dealBtn;
    private final TextView playBtn;
    private final TextView foldBtn;
    private int chip = 1;
    private int ante;
    /** 0 betting, 1 cards out and waiting for PLAY or FOLD, 2 settling. */
    private int state;

    GamePoker(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(60), dp(20), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        coinsText = label("", 13f, Theme.TEXT);
        betText = label("", 13f, Theme.ACCENT);
        LinearLayout top = new LinearLayout(host);
        coinsText.setGravity(Gravity.START);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dealerLabel = label("DEALER", 13f, Theme.DIM);
        col.addView(dealerLabel, wrapTop(dp(28)));
        dealerRow = handRow();
        col.addView(dealerRow);

        message = label("ANTE IN, THEN DEAL", 14f, Theme.DIM);
        message.setLetterSpacing(0.1f);
        col.addView(message, wrapTop(dp(18)));

        playerRow = handRow();
        col.addView(playerRow);
        playerLabel = label("YOU", 13f, Theme.DIM);
        col.addView(playerLabel);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(Upgrades.chipName(CHIPS[i]), CHIPS[i] >= 1000 ? 10f : 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (state == 0) {
                    chip = idx;
                    styleChips();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            cp.setMargins(dp(1), 0, dp(1), 0);
            chips.addView(c, cp);
        }
        col.addView(chips, wrapTop(dp(22)));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER);
        dealBtn = actionButton("DEAL", Theme.ACCENT, this::deal);
        playBtn = actionButton("PLAY x1", Theme.ACCENT, this::play);
        foldBtn = actionButton("FOLD", Theme.PANEL, this::fold);
        actions.addView(dealBtn, actionParams());
        actions.addView(playBtn, actionParams());
        actions.addView(foldBtn, actionParams());
        col.addView(actions, wrapTop(dp(18)));

        styleChips();
        showCards(false);
        refresh();
    }

    @Override
    String title() {
        return "THREE CARD POKER";
    }

    private LinearLayout.LayoutParams wrapTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout.LayoutParams actionParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private TextView actionButton(String text, int color, Runnable action) {
        TextView b = button(text, action);
        b.setTextColor(color == Theme.ACCENT ? Theme.BG : Theme.TEXT);
        b.setBackground(Theme.rounded(color, 16f, host));
        return b;
    }

    private LinearLayout handRow() {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setMinimumHeight(dp(78));
        return row;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void refresh() {
        coinsText.setText("COINS " + coins());
        betText.setText("ANTE " + Upgrades.chipName(CHIPS[chip]));
        dealBtn.setVisibility(state == 0 ? VISIBLE : GONE);
        playBtn.setVisibility(state == 1 ? VISIBLE : GONE);
        foldBtn.setVisibility(state == 1 ? VISIBLE : GONE);
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    // ------------------------------------------------------------------ cards

    /** A card code is rank * 4 + suit, rank 0 = two ... 12 = ace. */
    private TextView card(int code) {
        int rank = code / 4;
        int suit = code % 4;
        TextView t = label(RANKS[rank] + SUITS[suit], 15f, 0);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFFF4F0FF, 8f, host));
        t.setTextColor(suit % 2 == 0 ? 0xFF1C1626 : 0xFFB3243A);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(70));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView cardBack() {
        TextView t = label("?", 18f, Theme.ACCENT);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFF3B2B66, 8f, host));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(70));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void showCards(boolean reveal) {
        playerRow.removeAllViews();
        dealerRow.removeAllViews();
        if (state == 0 && !reveal) {
            for (int i = 0; i < 3; i++) {
                playerRow.addView(cardBack());
                dealerRow.addView(cardBack());
            }
            playerLabel.setText("YOU");
            dealerLabel.setText("DEALER");
            return;
        }
        for (int i = 0; i < 3; i++) {
            playerRow.addView(card(player[i]));
            dealerRow.addView(reveal ? card(dealer[i]) : cardBack());
        }
        playerLabel.setText("YOU  " + HANDS[score(player) / 1000000 - 1]);
        dealerLabel.setText(reveal ? "DEALER  " + HANDS[score(dealer) / 1000000 - 1] : "DEALER");
    }

    // ------------------------------------------------------------------ rules

    /** Higher is better. rank * 1000000 + a tie breaker, rank 1 high card ... 6 straight flush. */
    static int score(int[] cards) {
        int[] v = new int[3];
        boolean flush = true;
        for (int i = 0; i < 3; i++) {
            v[i] = cards[i] / 4 + 2;
            if (cards[i] % 4 != cards[0] % 4) {
                flush = false;
            }
        }
        Integer[] sorted = {v[0], v[1], v[2]};
        java.util.Arrays.sort(sorted, Collections.reverseOrder());
        for (int i = 0; i < 3; i++) {
            v[i] = sorted[i];
        }
        boolean trips = v[0] == v[1] && v[1] == v[2];
        boolean pair = v[0] == v[1] || v[1] == v[2];
        boolean wheel = v[0] == 14 && v[1] == 3 && v[2] == 2;   // A-2-3 is the lowest straight
        boolean straight = (v[0] == v[1] + 1 && v[1] == v[2] + 1) || wheel;
        int high = wheel ? 3 : v[0];
        int rank;
        int tie;
        if (straight && flush) {
            rank = 6;
            tie = high;
        } else if (trips) {
            rank = 5;
            tie = v[0];
        } else if (straight) {
            rank = 4;
            tie = high;
        } else if (flush) {
            rank = 3;
            tie = v[0] * 10000 + v[1] * 100 + v[2];
        } else if (pair) {
            int p = v[0] == v[1] ? v[0] : v[1];
            int k = v[0] == v[1] ? v[2] : v[0];
            rank = 2;
            tie = p * 100 + k;
        } else {
            rank = 1;
            tie = v[0] * 10000 + v[1] * 100 + v[2];
        }
        return rank * 1000000 + tie;
    }

    private static boolean qualifies(int dealerScore) {
        int rank = dealerScore / 1000000;
        int highest = (dealerScore % 1000000) / 10000;
        return rank >= 2 || (rank == 1 && highest >= 12);   // Queen high or better
    }

    private static int bonusMultiplier(int rank) {
        return rank == 6 ? 5 : rank == 5 ? 4 : rank == 4 ? 1 : 0;
    }

    // ------------------------------------------------------------------ flow

    private void deal() {
        if (state != 0) {
            return;
        }
        final int stake = CHIPS[chip];
        if (coins() < stake) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake);
        ante = stake;
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < 52; i++) {
            deck.add(i);
        }
        Collections.shuffle(deck, rnd);
        for (int i = 0; i < 3; i++) {
            player[i] = deck.get(i);
            dealer[i] = deck.get(3 + i);
        }
        state = 1;
        message.setText("PLAY (x1) OR FOLD");
        message.setTextColor(Theme.DIM);
        showCards(false);
        refresh();
    }

    private void play() {
        if (state != 1) {
            return;
        }
        if (coins() < ante) {
            message.setText("NOT ENOUGH COINS TO PLAY. FOLD OR LEAVE.");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - ante);
        state = 2;
        settle(true);
    }

    private void fold() {
        if (state != 1) {
            return;
        }
        state = 2;
        settle(false);
    }

    private void settle(boolean played) {
        int ps = score(player);
        int ds = score(dealer);
        int bonus = ante * bonusMultiplier(ps / 1000000);
        int spent = played ? ante * 2 : ante;
        int back;
        String result;
        if (!played) {
            back = 0;
            result = "FOLDED";
        } else if (!qualifies(ds)) {
            back = 3 * ante;
            result = "DEALER DOES NOT QUALIFY";
        } else if (ps > ds) {
            back = 4 * ante;
            result = "YOU WIN";
        } else if (ps == ds) {
            back = 2 * ante;
            result = "PUSH";
        } else {
            back = 0;
            result = "DEALER WINS";
        }
        back += bonus;
        Prefs.putInt("slot_coins", coins() + back);
        int net = back - spent;
        showCards(true);
        String extra = bonus > 0 ? "  BONUS +" + bonus : "";
        if (net > 0) {
            message.setText(result + "  +" + net + extra);
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
        } else if (net == 0) {
            message.setText(result + "  PUSH" + extra);
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText(result + "  " + net + extra);
            message.setTextColor(0xFFFF6B7F);
            host.buzz(30);
        }
        state = 0;
        refresh();
    }
}
