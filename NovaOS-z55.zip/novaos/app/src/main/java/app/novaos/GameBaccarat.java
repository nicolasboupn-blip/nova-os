package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Baccarat: the player hand and the banker hand, closest to 9 wins. Bet PLAYER (pays 1 to 1), BANKER (pays 1 to 1
 * minus 5% commission) or TIE (pays 8 to 1). Standard third-card rules.
 */
final class GameBaccarat extends Game {
    private static final int[] CHIPS = {5, 10, 25, 50, 100, 1000, 10000, 100000, 1000000};
    private static final String[] BET_NAMES = {"PLAYER", "BANKER", "TIE"};
    private static final String[] SUITS = {"♠", "♥", "♦", "♣"};
    private static final String[] RANKS = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

    private final Random rnd = new Random();
    private final LinearLayout[] hands = new LinearLayout[2];
    private final TextView[] totals = new TextView[2];
    private final TextView message;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView[] betViews = new TextView[3];
    private final TextView dealBtn;
    private int chip = 1;
    private int bet = 2;
    private boolean dealing;

    GameBaccarat(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(60), dp(20), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(host);
        coinsText = label("", 13f, Theme.TEXT);
        coinsText.setGravity(Gravity.START);
        betText = label("", 13f, Theme.ACCENT);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        totals[0] = label("BANKER", 13f, Theme.DIM);
        col.addView(totals[0], wrapTop(dp(28)));
        hands[0] = handRow();
        col.addView(hands[0]);

        message = label("PICK A SIDE AND DEAL", 14f, Theme.DIM);
        message.setLetterSpacing(0.1f);
        col.addView(message, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 0, 1f));

        totals[1] = label("PLAYER", 13f, Theme.DIM);
        col.addView(totals[1]);
        hands[1] = handRow();
        col.addView(hands[1]);

        LinearLayout bets = new LinearLayout(host);
        bets.setGravity(Gravity.CENTER);
        for (int i = 0; i < BET_NAMES.length; i++) {
            final int idx = i;
            TextView b = button(BET_NAMES[i] + (i == 2 ? " 8:1" : ""), () -> {
                if (!dealing) {
                    bet = idx;
                    styleAll();
                    refresh();
                }
            });
            b.setTextSize(11f);
            b.setPadding(dp(8), dp(10), dp(8), dp(10));
            betViews[i] = b;
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            bp.setMargins(dp(3), 0, dp(3), 0);
            bets.addView(b, bp);
        }
        col.addView(bets, wrapTop(dp(22)));

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(Upgrades.chipName(CHIPS[i]), CHIPS[i] >= 1000 ? 10f : 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (!dealing) {
                    chip = idx;
                    styleAll();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            cp.setMargins(dp(1), 0, dp(1), 0);
            chips.addView(c, cp);
        }
        col.addView(chips, wrapTop(dp(16)));

        dealBtn = button("DEAL", this::deal);
        dealBtn.setTextColor(Theme.BG);
        dealBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(16);
        col.addView(dealBtn, rp);

        styleAll();
        refresh();
    }

    @Override
    String title() {
        return "BACCARAT";
    }

    private LinearLayout.LayoutParams wrapTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout handRow() {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setMinimumHeight(dp(70));
        return row;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void refresh() {
        coinsText.setText("COINS " + coins());
        betText.setText("BET " + Upgrades.chipName(CHIPS[chip]) + " ON " + BET_NAMES[bet]);
    }

    private void styleAll() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
        for (int i = 0; i < betViews.length; i++) {
            boolean on = i == bet;
            betViews[i].setBackground(Theme.rounded(on ? Theme.ACCENT : Theme.PANEL, 16f, host));
            betViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
        }
    }

    // ------------------------------------------------------------------ cards

    /** A card as value 1..13 and suit 0..3. Value 1 is the ace. */
    private static int pip(int value) {
        return Math.min(value, 10) % 10;
    }

    private TextView card(int value, int suit) {
        TextView t = label(RANKS[value - 1] + SUITS[suit], 15f, suit % 2 == 0 ? Theme.TEXT : 0xFFFF6B7F);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFFF4F0FF, 8f, host));
        t.setTextColor(suit % 2 == 0 ? 0xFF1C1626 : 0xFFB3243A);
        t.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(68));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private static int score(List<Integer> hand) {
        int s = 0;
        for (int v : hand) {
            s += pip(v);
        }
        return s % 10;
    }

    /** One step of the hand, shown after a short pause. */
    private void place(int side, List<Integer> values, List<Integer> suits, int count, boolean showTotal) {
        hands[side].removeAllViews();
        for (int i = 0; i < count; i++) {
            hands[side].addView(card(values.get(i), suits.get(i)));
        }
        if (showTotal) {
            totals[side].setText((side == 0 ? "BANKER  " : "PLAYER  ") + score(values.subList(0, count)));
        }
    }

    private void deal() {
        if (dealing) {
            return;
        }
        final int stake = CHIPS[chip];
        if (coins() < stake) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake);
        dealing = true;
        message.setText("");
        refresh();

        List<Integer> p = new ArrayList<>();
        List<Integer> b = new ArrayList<>();
        List<Integer> ps = new ArrayList<>();
        List<Integer> bs = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            (i % 2 == 0 ? p : b).add(1 + rnd.nextInt(13));
            (i % 2 == 0 ? ps : bs).add(rnd.nextInt(4));
        }
        // third cards, standard rules
        boolean playerDrew = false;
        int pScore = score(p);
        int bScore = score(b);
        boolean natural = pScore >= 8 || bScore >= 8;
        if (!natural) {
            if (pScore <= 5) {
                p.add(1 + rnd.nextInt(13));
                ps.add(rnd.nextInt(4));
                playerDrew = true;
            }
            int p3 = playerDrew ? pip(p.get(2)) : -1;
            boolean bankerDraws;
            if (!playerDrew) {
                bankerDraws = bScore <= 5;
            } else if (bScore <= 2) {
                bankerDraws = true;
            } else if (bScore == 3) {
                bankerDraws = p3 != 8;
            } else if (bScore == 4) {
                bankerDraws = p3 >= 2 && p3 <= 7;
            } else if (bScore == 5) {
                bankerDraws = p3 >= 4 && p3 <= 7;
            } else if (bScore == 6) {
                bankerDraws = p3 == 6 || p3 == 7;
            } else {
                bankerDraws = false;
            }
            if (bankerDraws) {
                b.add(1 + rnd.nextInt(13));
                bs.add(rnd.nextInt(4));
            }
        }
        final List<Integer> pv = p, bv = b, psu = ps, bsu = bs;
        final int pFinal = score(p), bFinal = score(b);
        // reveal: player's two, banker's two, then the third cards
        place(1, pv, psu, 2, false);
        place(0, bv, bsu, 2, false);
        h.postDelayed(() -> {
            place(1, pv, psu, pv.size(), false);
            place(0, bv, bsu, bv.size(), false);
        }, 600);
        h.postDelayed(() -> {
            place(1, pv, psu, pv.size(), true);
            place(0, bv, bsu, bv.size(), true);
            settle(stake, pFinal, bFinal);
        }, 1400);
    }

    private void settle(int stake, int pScore, int bScore) {
        dealing = false;
        int winner = pScore > bScore ? 0 : bScore > pScore ? 1 : 2;   // 0 player, 1 banker, 2 tie
        String result = winner == 2 ? "TIE " + pScore + "-" + bScore
                : (winner == 0 ? "PLAYER" : "BANKER") + " WINS " + Math.max(pScore, bScore) + "-" + Math.min(pScore, bScore);
        int back;
        if (bet == winner) {
            back = winner == 0 ? stake * 2 : winner == 1 ? Math.round(stake * 1.95f) : stake * 9;
        } else if (winner == 2) {
            back = stake;   // tie: player and banker bets get their money back
        } else {
            back = 0;
        }
        Prefs.putInt("slot_coins", coins() + back);
        int net = back - stake;
        if (net > 0) {
            message.setText(result + "  +" + net);
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
        } else if (net == 0) {
            message.setText(result + "  PUSH");
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText(result + "  " + net);
            message.setTextColor(0xFFFF6B7F);
            host.buzz(30);
        }
        refresh();
    }
}
