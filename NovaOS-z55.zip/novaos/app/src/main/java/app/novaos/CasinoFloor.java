package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * The casino floor seen from above. Three slot machines along the left wall, roulette, blackjack and poker on the
 * right, and guests walking in through the door at the bottom. Margon wanders the aisle in his purple hat. Everyone is
 * drawn in code, from above, so you see their hair. Tap a machine or table to play, tap Margon to hear him.
 */
final class CasinoFloor extends FrameLayout {
    static final float W = 20f, H = 30f;
    private static final float[] SLOT_Y = {4f, 9f, 14f};
    private static final RectF ROULETTE = new RectF(13.8f, 4.0f, 18.6f, 7.2f);
    private static final RectF BLACKJACK = new RectF(13.8f, 10.6f, 18.4f, 13.5f);
    private static final RectF POKER = new RectF(14.2f, 17.4f, 18.2f, 21.4f);
    /** Seats and stools: 0-2 slot stools, 3-5 roulette, 6-8 blackjack, 9-11 poker. */
    private static final float[][] SPOTS = {
        {4.2f, 5.3f}, {4.2f, 10.3f}, {4.2f, 15.3f},
        {15.0f, 7.9f}, {16.2f, 8.2f}, {17.4f, 7.9f},
        {14.8f, 13.9f}, {16.2f, 14.1f}, {17.6f, 13.9f},
        {15.0f, 21.7f}, {16.2f, 22.0f}, {17.4f, 21.7f}
    };
    private static final int[] HAIR = {0xFF2B1A10, 0xFFC9A227, 0xFFB5462E, 0xFF15151A, 0xFFD9D9E0, 0xFF6B3FA0, 0xFF2F5FBF};
    private static final int[] SHIRT = {0xFFE0475B, 0xFF3FA7D6, 0xFF2EB872, 0xFFF2B33D, 0xFFEEEEF4, 0xFF7A5CFA, 0xFF3A3A4A};
    private static final int[] SKIN = {0xFFF1C7A0, 0xFFC68E64, 0xFF8D5B3A, 0xFF5A3822};
    private static final String[] MARGON_SAYS = {
        "Mind the aisle!", "Yes, I'm a wizard.", "The house always wins.", "Tip the dragon first.", "Lose with dignity."
    };

    private final NovaActivity host;
    private final Floor floor;

    CasinoFloor(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(Theme.BG);
        floor = new Floor(host);
        addView(floor, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        TextView hint = new TextView(host);
        hint.setText("CASINO FLOOR  ·  TAP A MACHINE, TABLE OR MARGON  ·  BACK TO LEAVE");
        hint.setTypeface(Theme.MONO);
        hint.setTextSize(9f);
        hint.setTextColor(Theme.DIM);
        hint.setGravity(Gravity.CENTER);
        hint.setBackgroundColor(0x99000000);
        hint.setPadding(Theme.dp(host, 10), Theme.dp(host, 8), Theme.dp(host, 10), Theme.dp(host, 8));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP);
        hp.topMargin = Theme.dp(host, 28);
        addView(hint, hp);
    }

    /** Play a casino game from the floor. Closing the game brings the floor back. */
    private void openGame(Game g) {
        GameFrame frame = new GameFrame(host, g, null, () -> reopenFloor(host));
        host.showOverlay(frame);
        frame.grow();
    }

    /**
     * Brings the floor back after a game closes. Showing the floor removes the game, which runs its close callback
     * again, so the flag stops that second call from reopening the floor a second time.
     */
    private static boolean reopening;

    private static void reopenFloor(NovaActivity host) {
        if (reopening) {
            return;
        }
        reopening = true;
        try {
            host.showOverlay(new CasinoFloor(host));
        } finally {
            reopening = false;
        }
    }

    /** The slot machine page, as a full game. */
    static final class SlotsGame extends Game {
        SlotsGame(NovaActivity host) {
            super(host);
            addView(new SlotMachine(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        }

        @Override
        String title() {
            return "SLOTS";
        }
    }

    private static final class Guest {
        float x, y, tx, ty, heading, wait, life, phase, speed;
        /** 0 walking, 1 standing or wandering, 2 leaving. */
        int state;
        int spot = -1;
        int hair, style, shirt, skin;
    }

    /** The floor itself: draws the room, runs the walking and handles taps. */
    private final class Floor extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random rnd = new Random();
        private final List<Guest> guests = new ArrayList<>();
        private final boolean[] taken = new boolean[SPOTS.length];
        private float mx = 10f, my = 16f, mtx = 10f, mty = 16f, mheading, mwait, sayT;
        private String say = "";
        private float spawnIn = 0.5f, time;
        private long lastNs;
        private float sc = 1f, ox, oy;
        private boolean running;

        Floor(NovaActivity host) {
            super(host);
            paint.setTypeface(Typeface.MONOSPACE);
            running = true;
            spawn();
            spawn();
        }

        @Override
        protected void onDetachedFromWindow() {
            running = false;
            super.onDetachedFromWindow();
        }

        private void wander(Guest g) {
            g.tx = 6f + rnd.nextFloat() * 7f;
            g.ty = 4f + rnd.nextFloat() * 22f;
        }

        private void spawn() {
            Guest g = new Guest();
            g.x = 10f + (rnd.nextFloat() - 0.5f) * 1.2f;
            g.y = H - 0.3f;
            g.hair = HAIR[rnd.nextInt(HAIR.length)];
            g.shirt = SHIRT[rnd.nextInt(SHIRT.length)];
            g.skin = SKIN[rnd.nextInt(SKIN.length)];
            g.style = rnd.nextInt(4);
            g.speed = 1.9f + rnd.nextFloat() * 0.6f;
            g.phase = rnd.nextFloat() * 6f;
            List<Integer> free = new ArrayList<>();
            for (int i = 0; i < SPOTS.length; i++) {
                if (!taken[i]) {
                    free.add(i);
                }
            }
            if (!free.isEmpty() && rnd.nextFloat() < 0.7f) {
                int s = free.get(rnd.nextInt(free.size()));
                taken[s] = true;
                g.spot = s;
                g.tx = SPOTS[s][0];
                g.ty = SPOTS[s][1];
            } else {
                g.life = 14f + rnd.nextFloat() * 16f;
                wander(g);
            }
            g.heading = (float) Math.atan2(g.ty - g.y, g.tx - g.x);
            guests.add(g);
        }

        private void leave(Guest g) {
            if (g.spot >= 0) {
                taken[g.spot] = false;
                g.spot = -1;
            }
            g.state = 2;
            g.tx = 10f + (rnd.nextFloat() - 0.5f) * 0.6f;
            g.ty = H + 0.8f;
        }

        private void update(float dt) {
            time += dt;
            if (sayT > 0) {
                sayT -= dt;
            }
            // Margon wanders the aisle, stopping now and then
            float dx = mtx - mx;
            float dy = mty - my;
            float d = (float) Math.hypot(dx, dy);
            if (mwait > 0) {
                mwait -= dt;
            } else if (d < 0.1f) {
                mwait = 2f + rnd.nextFloat() * 3f;
                mtx = 6.5f + rnd.nextFloat() * 6.5f;
                mty = 5f + rnd.nextFloat() * 21f;
            } else {
                float step = Math.min(d, 0.9f * dt);
                mx += dx / d * step;
                my += dy / d * step;
                mheading = (float) Math.atan2(dy, dx);
            }

            // guests come and go
            spawnIn -= dt;
            if (spawnIn <= 0f && guests.size() < 9) {
                spawn();
                spawnIn = 1.8f + rnd.nextFloat() * 2.7f;
            }
            Iterator<Guest> it = guests.iterator();
            while (it.hasNext()) {
                Guest g = it.next();
                if (g.state == 1) {
                    g.wait -= dt;
                    if (g.spot < 0) {
                        g.life -= dt;
                    }
                    if (g.spot >= 0 && g.wait <= 0f) {
                        leave(g);
                    } else if (g.spot < 0 && g.life <= 0f) {
                        leave(g);
                    } else if (g.spot < 0 && g.wait <= 0f) {
                        wander(g);
                        g.state = 0;
                    }
                    continue;
                }
                float gx = g.tx - g.x;
                float gy = g.ty - g.y;
                float gd = (float) Math.hypot(gx, gy);
                if (gd > 0.08f) {
                    float step = Math.min(gd, g.speed * dt);
                    g.x += gx / gd * step;
                    g.y += gy / gd * step;
                    g.heading = (float) Math.atan2(gy, gx);
                    g.phase += dt * 9f;
                } else if (g.state == 2) {
                    it.remove();
                } else {
                    g.state = 1;
                    g.wait = g.spot >= 0 ? 4f + rnd.nextFloat() * 6f : 1.2f + rnd.nextFloat() * 2f;
                }
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            update(dt);

            float s = Math.min(getWidth() / W, getHeight() / H);
            sc = s;
            ox = (getWidth() - W * s) / 2f;
            oy = (getHeight() - H * s) / 2f;
            c.save();
            c.translate(ox, oy);
            c.scale(s, s);
            drawRoom(c);
            drawSlots(c);
            drawTables(c);

            Collections.sort(guests, (a, b) -> Float.compare(a.y, b.y));
            boolean margonDrawn = false;
            for (Guest g : guests) {
                if (!margonDrawn && g.y > my) {
                    drawMargon(c);
                    margonDrawn = true;
                }
                drawPerson(c, g.x, g.y, g.heading, g.hair, g.style, g.shirt, g.skin,
                        g.state == 0 ? (float) Math.sin(g.phase) * 0.04f : 0f, false);
            }
            if (!margonDrawn) {
                drawMargon(c);
            }
            if (sayT > 0 && !say.isEmpty()) {
                drawSay(c);
            }
            c.restore();
            if (running) {
                postInvalidateOnAnimation();
            }
        }

        private void drawRoom(Canvas c) {
            for (int j = 0; j < H; j++) {
                for (int i = 0; i < W; i++) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(((i + j) & 1) == 0 ? 0xFF4A1426 : 0xFF3D0F1F);
                    c.drawRect(i, j, i + 1, j + 1, paint);
                }
            }
            // back wall with a gold trim, side walls
            paint.setColor(0xFF1A0E22);
            c.drawRect(0, 0, W, 1.4f, paint);
            paint.setColor(0xFFC9A227);
            c.drawRect(0, 1.4f, W, 1.55f, paint);
            paint.setColor(0xFF1A0E22);
            c.drawRect(0, 0, 0.5f, H, paint);
            c.drawRect(W - 0.5f, 0, W, H, paint);
            // front wall with the door in the middle
            c.drawRect(0, H - 0.5f, 9f, H, paint);
            c.drawRect(11f, H - 0.5f, W, H, paint);
            paint.setColor(0xFFC9A227);
            c.drawRect(8.8f, H - 0.55f, 9f, H, paint);
            c.drawRect(11f, H - 0.55f, 11.2f, H, paint);
            paint.setColor(0xFF0C0917);
            c.drawRect(9f, H - 0.5f, 11f, H, paint);
            // ceiling lights, slowly breathing
            for (float lx : new float[] {4f, 10f, 16f}) {
                paint.setColor(0xFFFFD27A);
                paint.setAlpha((int) (110 + 90 * Math.sin(time * 1.6f + lx)));
                c.drawCircle(lx, 0.7f, 0.28f, paint);
            }
            paint.setAlpha(255);
            // the seats, a dim ring each
            paint.setColor(0x55FFFFFF);
            for (float[] p : SPOTS) {
                c.drawCircle(p[0], p[1], 0.2f, paint);
            }
        }

        private void drawSlots(Canvas c) {
            int[] symbols = {0xFFE0475B, 0xFFF2B33D, 0xFF2EB872, 0xFF3FA7D6};
            for (int i = 0; i < SLOT_Y.length; i++) {
                float y0 = SLOT_Y[i];
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xFF2B1B3D);
                c.drawRoundRect(new RectF(1.0f, y0, 3.2f, y0 + 2.6f), 0.25f, 0.25f, paint);
                paint.setColor(0xFF0C0917);
                c.drawRoundRect(new RectF(1.3f, y0 + 0.35f, 2.9f, y0 + 1.6f), 0.12f, 0.12f, paint);
                for (int r = 0; r < 3; r++) {
                    int idx = (int) (time * (3f + i) + r * 2 + i) & 3;
                    paint.setColor(symbols[idx]);
                    float rx = 1.4f + r * 0.5f;
                    c.drawRect(rx, y0 + 0.6f, rx + 0.42f, y0 + 1.3f, paint);
                }
                paint.setColor(0xFFC9A227);
                c.drawRect(1.3f, y0 + 1.9f, 2.9f, y0 + 2.2f, paint);
                // a blinking lamp on top
                paint.setColor(((int) (time * 2 + i) & 1) == 0 ? 0xFFE0475B : 0xFF55202B);
                c.drawCircle(2.1f, y0 - 0.22f, 0.12f, paint);
                paint.setColor(Theme.DIM);
                paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(0.42f);
                c.drawText("SLOT " + (i + 1), 2.1f, y0 - 0.4f, paint);
            }
        }

        private void drawTables(Canvas c) {
            final int felt = 0xFF1E6B3A, gold = 0xFFC9A227;
            // roulette: oval felt with a spinning wheel
            paint.setColor(felt);
            c.drawOval(ROULETTE, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(0.12f);
            paint.setColor(gold);
            c.drawOval(ROULETTE, paint);
            paint.setStyle(Paint.Style.FILL);
            float cx = 16.2f, cy = 5.6f;
            for (int k = 0; k < 8; k++) {
                paint.setColor(k % 2 == 0 ? 0xFFB3243A : 0xFF15151A);
                c.drawArc(cx - 0.8f, cy - 0.8f, cx + 0.8f, cy + 0.8f, k * 45f + time * 40f, 45f, true, paint);
            }
            paint.setColor(0xFFF2EEFF);
            c.drawCircle(cx + (float) Math.cos(time * 3f) * 0.55f, cy + (float) Math.sin(time * 3f) * 0.55f, 0.1f, paint);
            paint.setColor(Theme.TEXT);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(0.42f);
            c.drawText("ROULETTE", cx, 3.7f, paint);

            // blackjack: a long felt with two cards on it
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(felt);
            c.drawRoundRect(BLACKJACK, 0.6f, 0.6f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(gold);
            c.drawRoundRect(BLACKJACK, 0.6f, 0.6f, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFF4F0FF);
            c.drawRect(15.4f, 11.6f, 15.9f, 12.4f, paint);
            c.drawRect(16.5f, 11.6f, 17.0f, 12.4f, paint);
            paint.setColor(Theme.TEXT);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("BLACKJACK", 16.1f, 10.4f, paint);

            // poker: a round teal table
            paint.setColor(0xFF1B5A6A);
            c.drawCircle(16.2f, 19.4f, 1.9f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(gold);
            c.drawCircle(16.2f, 19.4f, 1.9f, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFF4F0FF);
            c.drawRect(15.6f, 19.0f, 16.1f, 19.8f, paint);
            c.drawRect(16.3f, 19.0f, 16.8f, 19.8f, paint);
            paint.setColor(Theme.TEXT);
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("POKER", 16.2f, 17.2f, paint);
        }

        /** A person from above: shoulders, then the head, so the hair is what you see. */
        private void drawPerson(Canvas c, float x, float y, float heading, int hair, int style, int shirt, int skin,
                                float bob, boolean margon) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x66000000);
            c.drawOval(x - 0.28f + 0.06f, y - 0.38f + 0.1f, x + 0.28f + 0.06f, y + 0.38f + 0.1f, paint);
            c.save();
            c.rotate((float) Math.toDegrees(heading), x, y);
            // shoulders: forward is along the walking direction
            paint.setColor(shirt);
            c.drawOval(x - 0.26f + bob, y - 0.4f, x + 0.26f + bob, y + 0.4f, paint);
            if (style == 1) {
                // long hair falls down the back
                paint.setColor(hair);
                c.drawOval(x - 0.5f, y - 0.2f, x - 0.08f, y + 0.2f, paint);
            }
            if (style == 3) {
                paint.setColor(skin);
                c.drawCircle(x + 0.02f, y, 0.24f, paint);
                paint.setColor(0x33000000);
                c.drawCircle(x + 0.06f, y - 0.06f, 0.08f, paint);
            } else {
                paint.setColor(hair);
                c.drawCircle(x + 0.02f, y, 0.26f, paint);
                if (style == 2) {
                    // a bun at the back of the head
                    c.drawCircle(x - 0.2f, y, 0.12f, paint);
                }
                paint.setColor(0x44FFFFFF);
                c.drawCircle(x + 0.07f, y - 0.09f, 0.08f, paint);
            }
            c.restore();
        }

        /** Margon from above: a big purple hat brim, the pointed tip to the front and his white hair under it. */
        private void drawMargon(Canvas c) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x66000000);
            c.drawOval(mx - 0.3f + 0.06f, my - 0.44f + 0.1f, mx + 0.3f + 0.06f, my + 0.44f + 0.1f, paint);
            c.save();
            c.rotate((float) Math.toDegrees(mheading), mx, my);
            paint.setColor(0xFF4B2A96);
            c.drawOval(mx - 0.3f, my - 0.48f, mx + 0.3f, my + 0.48f, paint);     // robe shoulders
            paint.setColor(0xFFEDEDF5);
            c.drawCircle(mx - 0.08f, my, 0.3f, paint);                           // white hair at the back
            paint.setColor(0xFF2A1B5E);
            c.drawCircle(mx, my, 0.44f, paint);                                  // the hat brim
            paint.setColor(0xFF4B2A96);
            c.drawCircle(mx, my, 0.3f, paint);                                   // the crown
            paint.setColor(0xFF4B2A96);
            android.graphics.Path tip = new android.graphics.Path();
            tip.moveTo(mx - 0.05f, my - 0.22f);
            tip.lineTo(mx - 0.05f, my + 0.22f);
            tip.lineTo(mx + 0.62f, my);
            tip.close();
            c.drawPath(tip, paint);                                              // the pointed tip
            paint.setColor(0xFFF2B33D);
            c.drawCircle(mx + 0.5f, my, 0.08f, paint);                           // the gold star on the tip
            c.restore();
        }

        private void drawSay(Canvas c) {
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(0.42f);
            paint.setTextAlign(Paint.Align.CENTER);
            float w = paint.measureText(say) + 0.6f;
            float bx = Math.max(w / 2f + 0.3f, Math.min(W - w / 2f - 0.3f, mx));
            float by = my - 1.2f;
            paint.setColor(0xEE1C1626);
            c.drawRoundRect(new RectF(bx - w / 2f, by - 0.6f, bx + w / 2f, by + 0.1f), 0.2f, 0.2f, paint);
            paint.setColor(Theme.TEXT);
            c.drawText(say, bx, by - 0.2f, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) {
                return true;
            }
            float tx = (e.getX() - ox) / sc;
            float ty = (e.getY() - oy) / sc;
            if (Math.hypot(tx - mx, ty - my) < 1.0f) {
                say = MARGON_SAYS[rnd.nextInt(MARGON_SAYS.length)];
                sayT = 3f;
                host.buzz(10);
                return true;
            }
            for (int i = 0; i < SLOT_Y.length; i++) {
                if (tx > 0.8f && tx < 3.4f && ty > SLOT_Y[i] - 0.6f && ty < SLOT_Y[i] + 3.0f) {
                    openGame(new SlotsGame(host));
                    return true;
                }
            }
            if (ROULETTE.contains(tx, ty)) {
                openGame(new GameRoulette(host));
            } else if (BLACKJACK.contains(tx, ty)) {
                openGame(new GameBlackjack(host));
            } else if (POKER.contains(tx, ty)) {
                openGame(new GamePoker(host));
            }
            return true;
        }
    }
}
