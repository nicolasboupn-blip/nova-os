package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * DCS COCKPIT: one widget with swipeable pages fed by live DCS data (see DcsLink and the PC script NovaExport.lua).
 * THROTTLE (thrust lever + main buttons), AIRCRAFT (your jet with moving parts coloured), CARRIER (side view and lineup),
 * RADAR (everything around you), TARGET (your lock) and FLIGHT (all the numbers). In AUTO it shows the page that fits
 * what you are doing; swipe to choose yourself. SIM flies a made-up mission so everything can be tried without DCS.
 */
final class DcsCockpitWidget extends NovaWidget {
    private static final String[] PAGES = {"THROTTLE", "AIRCRAFT", "CARRIER", "RADAR", "TARGET", "FLIGHT"};
    private static final int P_THROTTLE = 0;
    private static final int P_PLANE = 1;
    private static final int P_CARRIER = 2;
    private static final int P_RADAR = 3;
    private static final int P_TARGET = 4;
    private static final int P_FLIGHT = 5;
    private static final String K_AUTO = "dcs_auto";
    private static final String K_PAGE = "dcs_page";
    private static final String K_THR = "dcs_throttle";
    private static final String K_THR_MODE = "dcs_thr_mode";
    private static final String K_RANGE = "dcs_radar_nm";
    private static final String K_VOICE = "dcs_voice";
    private static final int GREEN = 0xFF30D158;
    private static final int AMBER = 0xFFFFB020;
    private static final int RED = 0xFFFF453A;
    private static final int BLUE = 0xFF0A84FF;

    private final boolean big;
    private final TextView status;
    private final TextView autoChip;
    private final TextView simChip;
    private final Pager pager;
    private final LinearLayout dots;
    private int page;
    private long manualUntil;
    private final View[] views = new View[PAGES.length];
    private final List<Object[]> lit = new ArrayList<>();
    private final Runnable onData = this::data;
    private TextToSpeech tts;
    private long lastSay;
    private boolean ballCalled;
    private float lastFuel = -1;
    private long lastFuelAt;
    private float burn;

    DcsCockpitWidget(NovaActivity host) {
        this(host, false);
    }

    DcsCockpitWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setSingleLine(true);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        autoChip = chip("AUTO", () -> {
            boolean on = !Prefs.getBool(K_AUTO, true);
            Prefs.putBool(K_AUTO, on);
            manualUntil = 0;
            refresh();
            data();
        });
        top.addView(autoChip, margin());
        simChip = chip("SIM", () -> {
            DcsLink.setSim(!DcsLink.sim);
            host.toast(DcsLink.sim ? "SIM flight started: try every page and button" : "SIM off");
            refresh();
        });
        top.addView(simChip, margin());
        top.addView(chip("SETUP", this::setup), margin());
        if (!big) {
            top.addView(chip("⤢", this::openBig), margin());
        }
        addView(top, wide());
        dots = row();
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < PAGES.length; i++) {
            final int p = i;
            TextView d = text(PAGES[i], 8f, Theme.DIM);
            d.setPadding(dp(4), dp(4), dp(4), dp(4));
            d.setOnClickListener(v -> manual(p));
            dots.addView(d);
        }
        addView(dots, wide());
        pager = new Pager();
        int h = big ? (int) (getResources().getDisplayMetrics().heightPixels * 0.72f) : dp(330);
        addView(pager, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, h));
        page = Math.max(0, Math.min(PAGES.length - 1, Prefs.getInt(K_PAGE, 0)));
        show(page);
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        return lp;
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            DcsLink.start(host);
            DcsLink.listen(onData);
            if (PcHid.hid == null && android.os.Build.VERSION.SDK_INT >= 28
                    && (android.os.Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                    android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
                PcHid.start(host);
            }
            refresh();
        } else {
            DcsLink.unlisten(onData);
            DcsLink.stop();
        }
    }

    @Override
    long tickMs() {
        return 1000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        DcsLink.State s = DcsLink.st;
        String src = DcsLink.sim ? "● SIM" : DcsLink.live() ? "● DCS" : "○ waiting for DCS";
        status.setText(src + (DcsLink.live() && !s.name.isEmpty() ? "  " + nice(s.name) : "")
                + (PcHid.connected() ? "  · keys ✔" : "  · keys ✖"));
        status.setTextColor(DcsLink.live() ? GREEN : Theme.DIM);
        boolean auto = Prefs.getBool(K_AUTO, true);
        autoChip.setText(auto ? (SystemClock.uptimeMillis() < manualUntil ? "AUTO ⏸" : "AUTO") : "MANUAL");
        pick(autoChip, auto);
        pick(simChip, DcsLink.sim);
    }

    static String nice(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("FA-18") || u.contains("F/A-18")) {
            return "F/A-18C";
        }
        return n.replace("_", " ");
    }

    /** hornet, flanker, frogfoot or other. */
    static String family(String n) {
        String u = n.toUpperCase(Locale.ROOT);
        if (u.contains("18")) {
            return "hornet";
        }
        if (u.contains("SU-27") || u.contains("SU-33") || u.contains("J-11") || u.contains("SU-30")) {
            return "flanker";
        }
        if (u.contains("SU-25")) {
            return "frogfoot";
        }
        return u.isEmpty() ? "hornet" : "other";
    }

    // ------------------------------------------------------------------ pages and swiping

    private final class Pager extends FrameLayout {
        private float sx;
        private float sy;
        private boolean swiping;
        private final int slop = ViewConfiguration.get(host).getScaledTouchSlop();

        Pager() {
            super(host);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getX();
                    sy = e.getY();
                    swiping = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getX() - sx;
                    float dy = e.getY() - sy;
                    if (!swiping && Math.abs(dx) > slop * 3 && Math.abs(dx) > Math.abs(dy) * 1.6f
                            && !(page == P_THROTTLE && sx < getWidth() * 0.45f && sy < getHeight() * 0.5f)) {
                        swiping = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    }
                    return false;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP && swiping) {
                float dx = e.getX() - sx;
                manual((page + (dx < 0 ? 1 : -1) + PAGES.length) % PAGES.length);
                swiping = false;
            }
            return true;
        }
    }

    private void manual(int p) {
        manualUntil = SystemClock.uptimeMillis() + 30000;
        show(p);
        refresh();
    }

    private void show(int p) {
        page = p;
        Prefs.putInt(K_PAGE, p);
        pager.removeAllViews();
        if (views[p] == null) {
            views[p] = make(p);
        }
        pager.addView(views[p], new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        for (int i = 0; i < dots.getChildCount(); i++) {
            TextView d = (TextView) dots.getChildAt(i);
            d.setTextColor(i == p ? Theme.ACCENT : Theme.DIM);
            d.setText(i == p ? "● " + PAGES[i] : PAGES[i]);
        }
        views[p].invalidate();
    }

    private View make(int p) {
        switch (p) {
            case P_THROTTLE:
                return throttlePage();
            case P_PLANE:
                return new PlaneView();
            case P_CARRIER:
                return new CarrierView();
            case P_RADAR:
                return new RadarView();
            case P_TARGET:
                return new TargetView();
            default:
                return new FlightView();
        }
    }

    /** New data: pick the page in AUTO, redraw, light the buttons, carrier calls. */
    private void data() {
        DcsLink.State s = DcsLink.st;
        if (DcsLink.live() && Prefs.getBool(K_AUTO, true) && SystemClock.uptimeMillis() > manualUntil) {
            int want = choose(s);
            if (want != page) {
                show(want);
            }
        }
        if (views[page] != null) {
            views[page].invalidate();
        }
        if (btnGrid != null && !fam().equals(builtFam)) {
            fillButtons(btnGrid);
        }
        for (Object[] l : lit) {
            light((TextView) l[0], (int) l[1], (float) l[2]);
        }
        // fuel burn per minute, for "minutes left"
        long now = SystemClock.elapsedRealtime();
        float fuel = s.fuel + s.fuelExt;
        if (lastFuel < 0 || now - lastFuelAt > 10000) {
            if (lastFuel >= 0 && now - lastFuelAt < 60000) {
                float perMin = (lastFuel - fuel) / ((now - lastFuelAt) / 60000f);
                burn = burn == 0 ? perMin : burn * 0.6f + perMin * 0.4f;
            }
            lastFuel = fuel;
            lastFuelAt = now;
        }
        calls(s);
    }

    private int choose(DcsLink.State s) {
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap != null && ap[0] > 0 && ap[0] < 9000 && Math.abs(ap[4]) < 25 && s.alt < 1200 && (s.gear > 0.5f || s.hook > 0.5f)) {
            return P_CARRIER;
        }
        if (s.lockDist > 0) {
            return P_TARGET;
        }
        for (DcsLink.Obj o : DcsLink.objs) {
            if (o.cat == 1 && o.coal != 0 && o.coal != s.coal && Math.hypot(o.x - s.x, o.z - s.z) < 37000) {
                return P_RADAR;
            }
        }
        if (s.agl < 5 && s.ias < 60) {
            return P_THROTTLE;
        }
        return P_FLIGHT;
    }

    private void calls(DcsLink.State s) {
        if (!Prefs.getBool(K_VOICE, true)) {
            return;
        }
        double[] ap = DcsLink.approach(s, DcsLink.objs);
        if (ap == null || ap[0] <= 0 || ap[0] > 9000 || s.gear < 0.5f) {
            ballCalled = false;
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (!ballCalled && ap[0] < 1400) {
            ballCalled = true;
            say("three quarter mile, call the ball");
        } else if (ap[0] < 3000 && now - lastSay > 4000) {
            if (ap[4] > 1.5) {
                say("right of line up");
            } else if (ap[4] < -1.5) {
                say("left of line up");
            } else if (ap[3] > 0.7) {
                say("high");
            } else if (ap[3] < -0.7) {
                say("low, power");
            }
        }
    }

    private void say(String text) {
        lastSay = SystemClock.uptimeMillis();
        if (tts == null) {
            tts = new TextToSpeech(host.getApplicationContext(), st -> {
                if (st == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.US);
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
                }
            });
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dcs");
    }

    // ------------------------------------------------------------------ THROTTLE page

    /** {label, key spec, part (0 gear 1 flaps 2 airbrake 3 hook 4 canopy, -1 none), sim value (-1 toggle), hold}. */
    private static Object[][] buttons(String fam) {
        if (fam.equals("hornet")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS HALF", "LSHIFT+F", 1, 0.5f, false},
                {"FLAPS FULL", "LCTRL+F", 1, 1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"HOOK", "LCTRL+H", 3, -1f, false}, {"WHEEL BRAKE", "W", -1, -1f, true},
                {"GUN", "C", -1, -1f, false}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
                {"AUTO START", "LWIN+HOME", -1, -1f, false}, {"EJECT", "x3:LCTRL+E", -1, -1f, false},
            };
        }
        if (fam.equals("frogfoot")) {
            return new Object[][] {
                {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
                {"GUN", "C", -1, -1f, false}, {"NEXT WEAPON", "D", -1, -1f, false}, {"FIRE", "SPACE", -1, -1f, true},
                {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false},
                {"SHKVAL", "O", -1, -1f, false}, {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false},
                {"FLARE", "DEL", -1, -1f, false},
            };
        }
        return new Object[][] {
            {"GEAR", "G", 0, -1f, false}, {"FLAPS", "F", 1, -1f, false}, {"AIRBRAKE", "B", 2, -1f, false},
            {"GUN", "C", -1, -1f, false}, {"MISSILE", "D", -1, -1f, false}, {"FIRE GUN", "SPACE", -1, -1f, true},
            {"WHEEL BRAKE", "W", -1, -1f, true}, {"CANOPY", "LCTRL+C", 4, -1f, false}, {"RADAR", "I", -1, -1f, false},
            {"LOCK", "ENTER", -1, -1f, false}, {"CHAFF", "INS", -1, -1f, false}, {"FLARE", "DEL", -1, -1f, false},
        };
    }

    private String fam() {
        return family(DcsLink.st.name);
    }

    private View throttlePage() {
        final LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        LinearLayout topHalf = row();
        final Lever lever = new Lever();
        topHalf.addView(lever, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        final TextView info = text("", 11f, Theme.TEXT);
        info.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        info.setPadding(dp(10), 0, 0, 0);
        topHalf.addView(info, new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f));
        lever.info = info;
        col.addView(topHalf, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        final LinearLayout grid = new LinearLayout(host);
        grid.setOrientation(VERTICAL);
        fillButtons(grid);
        col.addView(grid, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        col.setTag(grid);
        return col;
    }

    private String btnKey(String fam, int i, String def) {
        return Prefs.getString("dcsbtn_" + fam + "_" + i, def);
    }

    private String builtFam = "";
    private LinearLayout btnGrid;

    private void fillButtons(final LinearLayout grid) {
        btnGrid = grid;
        builtFam = fam();
        grid.removeAllViews();
        lit.clear();
        final String fam = fam();
        final Object[][] b = buttons(fam);
        LinearLayout r = null;
        for (int i = 0; i < b.length; i++) {
            if (i % 3 == 0) {
                r = row();
                grid.addView(r, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
            }
            final int idx = i;
            final Object[] d = b[i];
            String saved = btnKey(fam, i, d[0] + "|" + d[1]);
            final String label = saved.contains("|") ? saved.substring(0, saved.indexOf('|')) : (String) d[0];
            final String spec = saved.contains("|") ? saved.substring(saved.indexOf('|') + 1) : (String) d[1];
            final TextView t = text(label + "\n" + DcsKeysWidget.pretty(spec), big ? 12f : 10f, 0xFFFFFFFF);
            t.setGravity(Gravity.CENTER);
            t.setBackground(Theme.rounded(0x33FFFFFF, 12f, host));
            final int part = (int) d[2];
            final boolean hold = (boolean) d[4];
            t.setOnTouchListener((v, e) -> {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setTag(SystemClock.uptimeMillis());
                    v.setAlpha(0.6f);
                    host.buzz(10);
                    if (hold) {
                        press(spec, part, (float) d[3], true, true);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1f);
                    long held = SystemClock.uptimeMillis() - (long) v.getTag();
                    if (hold) {
                        press(spec, part, (float) d[3], false, true);
                    } else if (a == MotionEvent.ACTION_UP && held > 700) {
                        editButton(grid, fam, idx, label, spec);
                    } else if (a == MotionEvent.ACTION_UP) {
                        press(spec, part, (float) d[3], true, false);
                    }
                }
                return true;
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, 1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(t, p);
            if (part >= 0) {
                lit.add(new Object[] {t, part, (float) d[3]});
            }
        }
        TextView hint = text("Hold a button 1 s to change its key · keys are DCS names (US positions)", 8.5f, Theme.DIM);
        grid.addView(hint, wide());
    }

    private void press(String spec, int part, float simValue, boolean down, boolean holdMode) {
        if (DcsLink.sim) {
            if (part >= 0 && down) {
                DcsLink.simPress(part, simValue);
            }
            return;
        }
        if (!PcHid.connected()) {
            if (down) {
                host.toast("Not connected: tap CONNECT in KEY DECK or PC REMOTE (or try SIM)");
            }
            return;
        }
        Object[] k = DcsKeysWidget.parse(spec);
        int code = PcHid.rawCode((String) k[1]);
        if (holdMode) {
            PcHid.hold((int) k[0], code, down);
        } else {
            PcHid.tap((int) k[0], code, (int) k[2], 40);
        }
    }

    private void editButton(final LinearLayout grid, final String fam, final int i, String label, String spec) {
        LinearLayout f = new LinearLayout(host);
        f.setOrientation(VERTICAL);
        f.setPadding(dp(18), dp(6), dp(18), 0);
        final EditText name = new EditText(host);
        name.setText(label);
        name.setHint("Name");
        name.setSingleLine(true);
        f.addView(name);
        final EditText key = new EditText(host);
        key.setText(spec);
        key.setHint("Key, e.g. G, LCTRL+H, RALT+SPACE, x3:LCTRL+E");
        key.setSingleLine(true);
        f.addView(key);
        new AlertDialog.Builder(host).setTitle("Button for " + fam)
                .setView(f)
                .setPositiveButton("SAVE", (d, w) -> {
                    String k = key.getText().toString().trim().toUpperCase(Locale.ROOT);
                    Object[] p = DcsKeysWidget.parse(k.isEmpty() ? "G" : k);
                    if (PcHid.rawCode((String) p[1]) == 0) {
                        host.toast("Unknown key: " + p[1]);
                        return;
                    }
                    Prefs.putString("dcsbtn_" + fam + "_" + i, name.getText().toString().trim().toUpperCase(Locale.ROOT) + "|" + k);
                    fillButtons(grid);
                })
                .setNeutralButton("DEFAULT", (d, w) -> {
                    Prefs.remove("dcsbtn_" + fam + "_" + i);
                    fillButtons(grid);
                })
                .setNegativeButton("CANCEL", null).show();
    }

    private void light(TextView t, int part, float simValue) {
        DcsLink.State s = DcsLink.st;
        float v = part == 0 ? s.gear : part == 1 ? s.flaps : part == 2 ? s.brake : part == 3 ? s.hook : s.canopy;
        int c;
        if (part == 1 && simValue > 0 && simValue < 1) {
            c = Math.abs(v - 0.5f) < 0.15f ? GREEN : 0x33FFFFFF;
        } else if (part == 1 && simValue >= 1) {
            c = v > 0.9f ? GREEN : 0x33FFFFFF;
        } else {
            c = v > 0.95f ? GREEN : v > 0.05f ? AMBER : 0x33FFFFFF;
        }
        if (!DcsLink.live()) {
            c = 0x33FFFFFF;
        }
        t.setBackground(Theme.rounded(c == 0x33FFFFFF ? c : (c & 0x00FFFFFF) | 0xAA000000, 12f, host));
    }

    /** The thrust lever: drag up and down. MIL at 80 %, afterburner above. */
    private final class Lever extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float value = Prefs.getInt(K_THR, 0) / 1000f;
        TextView info;
        private float sent = -1;
        private float est;
        private final Runnable keyLoop = new Runnable() {
            @Override
            public void run() {
                int plus = PcHid.rawCode("KPPLUS");
                int minus = PcHid.rawCode("KPMINUS");
                if (value > est + 0.02f) {
                    PcHid.hold(0, minus, false);
                    PcHid.hold(0, plus, true);
                    est += 0.012f;
                    postDelayed(this, 40);
                } else if (value < est - 0.02f) {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, true);
                    est -= 0.012f;
                    postDelayed(this, 40);
                } else {
                    PcHid.hold(0, plus, false);
                    PcHid.hold(0, minus, false);
                }
            }
        };

        Lever() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float top = dp(10);
            float bot = h - dp(10);
            float cx = w / 2f;
            float tw = Math.min(w * 0.36f, dp(64));
            // track
            p.setColor(0x22FFFFFF);
            c.drawRoundRect(new RectF(cx - tw / 2, top, cx + tw / 2, bot), dp(10), dp(10), p);
            float mil = bot - (bot - top) * 0.8f;
            p.setColor(0x33FF9500);
            c.drawRoundRect(new RectF(cx - tw / 2, top, cx + tw / 2, mil), dp(10), dp(10), p);
            p.setColor(Theme.DIM);
            p.setTextSize(dp(9));
            p.setTypeface(Theme.MONO);
            c.drawText("AB", cx + tw / 2 + dp(4), top + dp(10), p);
            c.drawText("MIL", cx + tw / 2 + dp(4), mil + dp(3), p);
            c.drawText("IDLE", cx + tw / 2 + dp(4), bot, p);
            p.setColor(0x66FFFFFF);
            c.drawRect(cx - tw / 2 - dp(4), mil - dp(1), cx + tw / 2 + dp(4), mil + dp(1), p);
            // fill and handle
            float y = bot - (bot - top) * value;
            p.setColor(value > 0.8f ? 0xFFFF9500 : Theme.ACCENT);
            p.setAlpha(110);
            c.drawRoundRect(new RectF(cx - tw / 2, y, cx + tw / 2, bot), dp(10), dp(10), p);
            p.setAlpha(255);
            c.drawRoundRect(new RectF(cx - tw / 2 - dp(8), y - dp(14), cx + tw / 2 + dp(8), y + dp(14)), dp(8), dp(8), p);
            p.setColor(0xFF000000);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(11));
            c.drawText(Math.round(value * 100) + "%", cx, y + dp(4), p);
            p.setTextAlign(Paint.Align.LEFT);
            if (info != null) {
                DcsLink.State s = DcsLink.st;
                boolean axis = Prefs.getInt(K_THR_MODE, 0) == 0;
                info.setText("THRUST " + Math.round(value * 100) + "%" + (value > 0.8f ? "  AB" : value > 0.78f ? "  MIL" : "")
                        + "\n" + (DcsLink.live() ? Math.round(s.ias * 1.94384f) + " kt  ·  RPM " + Math.round(Math.max(s.rpmL, s.rpmR))
                        + "%" : "no DCS data")
                        + "\n\nMode: " + (axis ? "AXIS (bind Thrust to NOVA Remote Z)" : "KEYS (Num+ / Num−)")
                        + "\ntap here to switch");
                info.setOnClickListener(v -> {
                    Prefs.putInt(K_THR_MODE, axis ? 1 : 0);
                    invalidate();
                });
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN || e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float top = dp(10);
                float bot = getHeight() - dp(10);
                float old = value;
                value = Math.max(0, Math.min(1, (bot - e.getY()) / (bot - top)));
                if ((old <= 0.8f) != (value <= 0.8f)) {
                    host.buzz(35);
                }
                apply();
                invalidate();
            }
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                Prefs.putInt(K_THR, Math.round(value * 1000));
            }
            return true;
        }

        private void apply() {
            DcsLink.throttle = value;
            if (DcsLink.sim || !PcHid.connected()) {
                return;
            }
            if (Prefs.getInt(K_THR_MODE, 0) == 0) {
                if (Math.abs(value - sent) > 0.004f) {
                    sent = value;
                    PcHid.axis(value);
                }
            } else {
                removeCallbacks(keyLoop);
                post(keyLoop);
            }
        }
    }

    // ------------------------------------------------------------------ AIRCRAFT page

    /** Your aircraft from above: red = fully out, blue = partly out, grey = in. */
    private final class PlaneView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PlaneView() {
            super(host);
        }

        private int col(float v) {
            return v > 0.95f ? RED : v > 0.05f ? BLUE : 0xFF4A4A52;
        }

        private Path poly(float[] pts, float cx, float oy, float sc, boolean mirror) {
            Path path = new Path();
            for (int i = 0; i < pts.length; i += 2) {
                float x = cx + pts[i] * sc;
                float y = oy + pts[i + 1] * sc;
                if (i == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            if (mirror) {
                for (int i = pts.length - 2; i >= 0; i -= 2) {
                    path.lineTo(cx - pts[i] * sc, oy + pts[i + 1] * sc);
                }
            }
            path.close();
            return path;
        }

        private void part(Canvas c, float[] pts, float cx, float oy, float sc, float v, boolean both) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(col(v));
            c.drawPath(poly(pts, cx, oy, sc, false), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setColor(0x99FFFFFF);
            c.drawPath(poly(pts, cx, oy, sc, false), p);
            if (both) {
                float[] m = pts.clone();
                for (int i = 0; i < m.length; i += 2) {
                    m[i] = -m[i];
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(col(v));
                c.drawPath(poly(m, cx, oy, sc, false), p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0x99FFFFFF);
                c.drawPath(poly(m, cx, oy, sc, false), p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            String fam = family(s.name);
            float w = getWidth();
            float h = getHeight();
            float listW = w * 0.32f;
            float sc = Math.min((w - listW) / 100f, (h - dp(10)) / 105f);
            float cx = (w - listW) / 2f;
            float oy = (h - 100 * sc) / 2f;
            float[] body;
            float[] tails;
            float[] stab;
            float[] flap;
            float[] brake;
            float[] gearN;
            float[] gearM;
            float[] canopy;
            float[] hookP = null;
            boolean brakeBoth;
            if (fam.equals("flanker")) {
                body = new float[] {0, 0, 2.5f, 6, 4.5f, 16, 6, 26, 12, 36, 46, 58, 46, 63, 14, 66, 12, 80, 8, 98, 4, 101};
                tails = new float[] {9, 64, 11, 64, 12, 90, 10, 90};
                stab = new float[] {11, 82, 32, 93, 32, 97, 10, 96};
                flap = new float[] {14, 62.5f, 36, 58.5f, 37, 61.5f, 14, 66};
                brake = new float[] {-3.5f, 22, 3.5f, 22, 3.5f, 32, -3.5f, 32};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 20, 1.2f, 20, 1.2f, 25, -1.2f, 25};
                gearM = new float[] {7, 54, 10, 54, 10, 60, 7, 60};
                canopy = new float[] {-2.8f, 8, 2.8f, 8, 3, 18, -3, 18};
                if (s.name.toUpperCase(Locale.ROOT).contains("33")) {
                    hookP = new float[] {-0.8f, 98, 0.8f, 98, 0.8f, 106, -0.8f, 106};
                }
            } else if (fam.equals("frogfoot")) {
                body = new float[] {0, 0, 2.5f, 5, 4, 15, 5, 38, 48, 42, 48, 49, 8, 56, 6, 74, 4, 86, 22, 92, 22, 96, 2, 97};
                tails = new float[] {-0.8f, 72, 0.8f, 72, 0.8f, 96, -0.8f, 96};
                stab = new float[] {2, 86, 22, 92, 22, 96, 2, 97};
                flap = new float[] {7, 52, 30, 49.5f, 30, 53, 7, 56};
                brake = new float[] {46, 43, 49, 43, 49, 49, 46, 49};
                brakeBoth = true;
                gearN = new float[] {-1.2f, 14, 1.2f, 14, 1.2f, 19, -1.2f, 19};
                gearM = new float[] {9, 46, 12, 46, 12, 53, 9, 53};
                canopy = new float[] {-2.5f, 7, 2.5f, 7, 2.7f, 16, -2.7f, 16};
            } else {
                body = new float[] {0, 0, 2.5f, 6, 4, 14, 5, 22, 14, 40, 46, 55, 46, 60, 16, 64, 9, 72, 9, 78, 28, 90, 28, 94, 8, 94, 6, 100};
                tails = new float[] {9, 66, 11.5f, 66, 13, 86, 10.5f, 86};
                stab = new float[] {9, 78, 28, 90, 28, 94, 8, 94};
                flap = new float[] {16, 62, 33, 59.5f, 33.5f, 62.5f, 16, 65.5f};
                brake = new float[] {-3, 70, 3, 70, 3, 77, -3, 77};
                brakeBoth = false;
                gearN = new float[] {-1.2f, 17, 1.2f, 17, 1.2f, 22, -1.2f, 22};
                gearM = new float[] {6.5f, 50, 9.5f, 50, 9.5f, 56, 6.5f, 56};
                canopy = new float[] {-2.6f, 8, 2.6f, 8, 2.8f, 19, -2.8f, 19};
                hookP = new float[] {-0.8f, 96, 0.8f, 96, 0.8f, 105, -0.8f, 105};
            }
            // body with a soft shade
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF2E2F36);
            c.drawPath(poly(body, cx, oy, sc, true), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(0xCCFFFFFF);
            c.drawPath(poly(body, cx, oy, sc, true), p);
            // panel lines
            p.setStrokeWidth(dp(0.7f));
            p.setColor(0x33FFFFFF);
            c.drawLine(cx, oy + 4 * sc, cx, oy + 96 * sc, p);
            c.drawLine(cx - 4 * sc, oy + 30 * sc, cx + 4 * sc, oy + 30 * sc, p);
            c.drawLine(cx - 6 * sc, oy + 48 * sc, cx + 6 * sc, oy + 48 * sc, p);
            p.setStyle(Paint.Style.FILL);
            // fixed parts
            p.setColor(0xFF3A3B44);
            c.drawPath(poly(stab, cx, oy, sc, false), p);
            float[] stabM = stab.clone();
            for (int i = 0; i < stabM.length; i += 2) {
                stabM[i] = -stabM[i];
            }
            c.drawPath(poly(stabM, cx, oy, sc, false), p);
            p.setColor(0xFF55565F);
            c.drawPath(poly(tails, cx, oy, sc, false), p);
            float[] tailsM = tails.clone();
            for (int i = 0; i < tailsM.length; i += 2) {
                tailsM[i] = -tailsM[i];
            }
            if (!fam.equals("frogfoot")) {
                c.drawPath(poly(tailsM, cx, oy, sc, false), p);
            }
            // moving parts
            part(c, flap, cx, oy, sc, s.flaps, true);
            part(c, brake, cx, oy, sc, s.brake, brakeBoth);
            part(c, gearN, cx, oy, sc, s.gear, false);
            part(c, gearM, cx, oy, sc, s.gear, true);
            part(c, canopy, cx, oy, sc, s.canopy, false);
            if (hookP != null) {
                part(c, hookP, cx, oy, sc, s.hook, false);
            }
            // the list on the right
            float lx = w - listW + dp(6);
            float ly = dp(18);
            p.setTypeface(Theme.MONO);
            p.setTextSize(dp(big ? 13 : 10.5f));
            p.setColor(Theme.TEXT);
            c.drawText(DcsLink.live() ? nice(s.name.isEmpty() ? "F/A-18C" : s.name) : "no data", lx, ly, p);
            ly += dp(20);
            Object[][] rows = {{"GEAR", s.gear}, {"FLAPS", s.flaps}, {"AIRBRAKE", s.brake}, {"HOOK", s.hook},
                {"CANOPY", s.canopy}, {"WHEEL BRAKE", s.wheel}};
            for (Object[] r : rows) {
                if (r[0].equals("HOOK") && hookP == null) {
                    continue;
                }
                float v = (float) r[1];
                p.setColor(col(v));
                c.drawCircle(lx + dp(5), ly - dp(4), dp(5), p);
                p.setColor(Theme.TEXT);
                c.drawText(r[0] + " " + Math.round(v * 100) + "%", lx + dp(14), ly, p);
                ly += dp(18);
            }
            ly += dp(8);
            p.setTextSize(dp(9));
            p.setColor(RED);
            c.drawText("■ fully out", lx, ly, p);
            p.setColor(BLUE);
            c.drawText("■ partly out", lx, ly + dp(13), p);
            p.setColor(0xFF8E8E93);
            c.drawText("■ in", lx, ly + dp(26), p);
        }
    }

    // ------------------------------------------------------------------ CARRIER page

    private final class CarrierView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        CarrierView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            double[] ap = DcsLink.live() ? DcsLink.approach(s, DcsLink.objs) : null;
            if (ap == null) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(12));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(!DcsLink.live() ? "No DCS data (try SIM)" : DcsLink.objectsLive() ? "No carrier within 25 km"
                        : "No carrier data (server may block it)", w / 2, h / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            double along = ap[0];
            double lateral = ap[1];
            double height = ap[2];
            double gs = ap[3];
            double lu = ap[4];
            // ---- side view (top 55 %)
            float sh = h * 0.52f;
            float l = dp(8);
            float r = w - dp(8);
            float deckY = sh - dp(14);
            double range = Math.max(1500, Math.min(9000, along * 1.3));
            float ppm = (float) ((r - l - dp(40)) / range);
            float tdX = r - dp(40);
            // water and ship
            p.setColor(0xFF0B2A44);
            c.drawRect(l, deckY + dp(4), r, sh, p);
            p.setColor(0xFF6E7380);
            c.drawRect(tdX - dp(6), deckY - dp(4), r, deckY + dp(6), p);
            c.drawRect(tdX + dp(18), deckY - dp(14), tdX + dp(26), deckY - dp(4), p);
            // glide slope line 3.5 deg and the +-0.7 band
            p.setStrokeWidth(dp(1.5f));
            for (int k = -1; k <= 1; k++) {
                double ang = Math.toRadians(3.5 + k * 0.7);
                float x0 = tdX;
                float y0 = deckY;
                float x1 = l;
                float y1 = (float) (deckY - Math.tan(ang) * range * ppm * 1.0 * vertScale(range, sh));
                p.setColor(k == 0 ? GREEN : 0x5530D158);
                c.drawLine(x0, y0, x1, y1, p);
            }
            // the jet
            float jx = (float) (tdX - along * ppm);
            float jy = (float) (deckY - height * ppm * vertScale(range, sh));
            jy = Math.max(dp(8), Math.min(deckY, jy));
            int gc = Math.abs(gs) < 0.35 ? GREEN : Math.abs(gs) < 0.8 ? AMBER : RED;
            p.setColor(gc);
            Path jet = new Path();
            jet.moveTo(jx + dp(10), jy);
            jet.lineTo(jx - dp(8), jy - dp(5));
            jet.lineTo(jx - dp(5), jy);
            jet.lineTo(jx - dp(8), jy + dp(4));
            jet.close();
            c.drawPath(jet, p);
            p.setTextSize(dp(big ? 14 : 12));
            p.setColor(gc);
            c.drawText(gs > 0.35 ? "HIGH" : gs < -0.35 ? "LOW" : "ON GLIDE SLOPE", l + dp(4), dp(16), p);
            // ---- lineup strip
            float ly = sh + dp(10);
            float lh = h * 0.18f;
            p.setColor(0x14FFFFFF);
            c.drawRoundRect(new RectF(l, ly, r, ly + lh), dp(8), dp(8), p);
            float mid = (l + r) / 2;
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(dp(2));
            c.drawLine(mid, ly + dp(4), mid, ly + lh - dp(4), p);
            float full = 4f;
            float dotX = mid + (float) (Math.max(-full, Math.min(full, lu)) / full * (r - l) / 2 * 0.9);
            int lc = Math.abs(lu) < 0.6 ? GREEN : Math.abs(lu) < 1.5 ? AMBER : RED;
            p.setColor(lc);
            c.drawCircle(dotX, ly + lh / 2, dp(8), p);
            p.setTextSize(dp(10));
            c.drawText(lu > 0.6 ? "RIGHT → fly left" : lu < -0.6 ? "← LEFT: fly right" : "LINED UP", l + dp(6), ly + dp(13), p);
            // ---- AoA and numbers
            float by = ly + lh + dp(16);
            float aoa = s.aoa;
            int ac = aoa > 8.8f ? AMBER : aoa < 7.4f ? RED : GREEN;
            String as = aoa > 8.8f ? "SLOW ˄" : aoa < 7.4f ? "FAST ˅" : "ON SPEED ◯";
            p.setColor(ac);
            p.setTextSize(dp(big ? 15 : 12));
            c.drawText(as + "  AoA " + String.format(Locale.ROOT, "%.1f", aoa), l, by, p);
            p.setColor(Theme.TEXT);
            p.setTextSize(dp(big ? 13 : 10.5f));
            double nm = along / 1852.0;
            c.drawText(String.format(Locale.ROOT, "%.2f nm  ·  %d ft  ·  %d kt  ·  GS %+.1f°  LU %+.1f°",
                    nm, Math.round(height * 3.28084), Math.round(s.ias * 1.94384), gs, lu), l, by + dp(18), p);
            p.setColor(s.gear > 0.95f ? GREEN : RED);
            c.drawText("GEAR", l, by + dp(36), p);
            p.setColor(s.hook > 0.95f ? GREEN : RED);
            c.drawText("HOOK", l + dp(50), by + dp(36), p);
            p.setColor(s.flaps > 0.9f ? GREEN : AMBER);
            c.drawText("FLAPS", l + dp(100), by + dp(36), p);
            p.setColor(Theme.DIM);
            p.setTextSize(dp(9));
            c.drawText(nm < 0.75 ? "call the ball" : "", r - dp(80), by + dp(36), p);
        }

        /** Exaggerates height so the glide slope is easy to read. */
        private float vertScale(double range, float sh) {
            return (float) Math.max(1, Math.min(6, (sh * 0.7) / (Math.tan(Math.toRadians(5)) * range * ((getWidth() - dp(56)) / range))));
        }
    }

    // ------------------------------------------------------------------ RADAR page

    private final class RadarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String picked;

        RadarView() {
            super(host);
            setOnClickListener(v -> {
            });
        }

        private int nm() {
            int[] r = {10, 20, 40, 80};
            return r[Math.max(0, Math.min(3, Prefs.getInt(K_RANGE, 1)))];
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                if (e.getY() < dp(26) && e.getX() > getWidth() - dp(70)) {
                    Prefs.putInt(K_RANGE, (Prefs.getInt(K_RANGE, 1) + 1) % 4);
                } else {
                    picked = nearest(e.getX(), e.getY());
                }
                invalidate();
            }
            return true;
        }

        private float[] place(DcsLink.State s, DcsLink.Obj o, float cx, float cy, float R) {
            double dn = o.x - s.x;
            double de = o.z - s.z;
            double hd = Math.toRadians(s.hdg);
            // heading up: rotate so your nose points up
            double right = de * Math.cos(hd) - dn * Math.sin(hd);
            double fwd = dn * Math.cos(hd) + de * Math.sin(hd);
            double scale = R / (nm() * 1852.0);
            return new float[] {(float) (cx + right * scale), (float) (cy - fwd * scale), (float) Math.hypot(dn, de)};
        }

        private String nearest(float x, float y) {
            DcsLink.State s = DcsLink.st;
            float[] g = geo();
            String best = null;
            float bd = dp(30);
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, g[0], g[1], g[2]);
                float d = (float) Math.hypot(q[0] - x, q[1] - y);
                if (d < bd) {
                    bd = d;
                    best = o.id;
                }
            }
            return best;
        }

        private float[] geo() {
            float w = getWidth();
            float h = getHeight();
            float R = Math.min(w / 2f, h * 0.8f) - dp(8);
            return new float[] {w / 2f, h * 0.84f, R};
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float[] g = geo();
            float cx = g[0];
            float cy = g[1];
            float R = g[2];
            int acc = Theme.ACCENT;
            p.setTypeface(Theme.MONO);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            for (int i = 1; i <= 4; i++) {
                float rr = R * i / 4f;
                p.setColor((acc & 0x00FFFFFF) | 0x40000000);
                c.drawCircle(cx, cy, rr, p);
            }
            c.drawLine(cx, cy, cx, cy - R, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(9));
            p.setColor(Theme.DIM);
            for (int i = 1; i <= 4; i++) {
                c.drawText(nm() * i / 4 + "", cx + dp(3), cy - R * i / 4f + dp(10), p);
            }
            p.setColor(Theme.ACCENT);
            p.setTextSize(dp(11));
            c.drawText(nm() + " NM ▾", getWidth() - dp(66), dp(16), p);
            c.drawText("HDG " + Math.round((s.hdg + 360) % 360), dp(6), dp(16), p);
            // you
            Path me = new Path();
            me.moveTo(cx, cy - dp(9));
            me.lineTo(cx - dp(6), cy + dp(6));
            me.lineTo(cx + dp(6), cy + dp(6));
            me.close();
            p.setColor(0xFFFFFFFF);
            c.drawPath(me, p);
            if (!DcsLink.objectsLive()) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(11));
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(DcsLink.live() ? "No contacts data (server may block it)" : "No DCS data (try SIM)", cx, cy - R / 2, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            DcsLink.Obj sel = null;
            for (DcsLink.Obj o : DcsLink.objs) {
                float[] q = place(s, o, cx, cy, R);
                if (q[2] > nm() * 1852.0) {
                    continue;
                }
                int col = o.coal == 0 ? 0xFF8E8E93 : o.coal == s.coal ? BLUE : RED;
                p.setColor(col);
                if (o.cat == 1) {
                    double rel = Math.toRadians(o.hdg - s.hdg);
                    c.drawCircle(q[0], q[1], dp(4), p);
                    p.setStrokeWidth(dp(1.5f));
                    c.drawLine(q[0], q[1], q[0] + (float) Math.sin(rel) * dp(10), q[1] - (float) Math.cos(rel) * dp(10), p);
                } else if (o.cat == 3) {
                    Path d = new Path();
                    d.moveTo(q[0], q[1] - dp(6));
                    d.lineTo(q[0] + dp(6), q[1]);
                    d.lineTo(q[0], q[1] + dp(6));
                    d.lineTo(q[0] - dp(6), q[1]);
                    d.close();
                    c.drawPath(d, p);
                } else {
                    c.drawRect(q[0] - dp(3), q[1] - dp(3), q[0] + dp(3), q[1] + dp(3), p);
                }
                if (o.name != null && o.name.equals(s.lockName) && s.lockDist > 0) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(0xFFFFFFFF);
                    c.drawRect(q[0] - dp(8), q[1] - dp(8), q[0] + dp(8), q[1] + dp(8), p);
                    p.setStyle(Paint.Style.FILL);
                }
                if (o.id.equals(picked)) {
                    sel = o;
                    p.setStyle(Paint.Style.STROKE);
                    p.setColor(Theme.ACCENT);
                    c.drawCircle(q[0], q[1], dp(11), p);
                    p.setStyle(Paint.Style.FILL);
                }
            }
            if (sel != null) {
                float[] q = place(s, sel, cx, cy, R);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(10.5f));
                c.drawText(sel.name + "  " + String.format(Locale.ROOT, "%.1f nm", q[2] / 1852.0) + "  "
                        + Math.round(sel.alt * 3.28084) + " ft", dp(6), dp(32), p);
            } else {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(9));
                c.drawText("tap a contact · blue friend · red enemy · ◆ ship · ■ ground", dp(6), dp(32), p);
            }
        }
    }

    // ------------------------------------------------------------------ TARGET and FLIGHT pages

    private final class TargetView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        TargetView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            p.setTypeface(Theme.MONO);
            p.setTextAlign(Paint.Align.CENTER);
            if (!DcsLink.live() || s.lockDist <= 0) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(20));
                c.drawText("NO LOCK", w / 2, getHeight() / 2f, p);
                p.setTextAlign(Paint.Align.LEFT);
                return;
            }
            float y = dp(40);
            p.setColor(RED);
            p.setTextSize(dp(big ? 30 : 22));
            c.drawText(s.lockName.isEmpty() ? "TARGET" : s.lockName, w / 2, y, p);
            p.setColor(Theme.TEXT);
            p.setTextSize(dp(big ? 44 : 32));
            c.drawText(String.format(Locale.ROOT, "%.1f nm", s.lockDist / 1852.0), w / 2, y + dp(big ? 64 : 48), p);
            p.setTextSize(dp(big ? 18 : 14));
            p.setColor(s.lockClose > 0 ? AMBER : GREEN);
            c.drawText("closing " + Math.round(s.lockClose * 1.94384f) + " kt", w / 2, y + dp(big ? 100 : 76), p);
            p.setColor(Theme.TEXT);
            if (s.lockAlt >= 0) {
                c.drawText("altitude " + Math.round(s.lockAlt * 3.28084) + " ft  (" + (s.lockAlt > s.alt ? "above" : "below") + " you)",
                        w / 2, y + dp(big ? 128 : 98), p);
            }
            if (s.lockClose > 1) {
                c.drawText("meet in about " + Math.round(s.lockDist / s.lockClose) + " s", w / 2, y + dp(big ? 156 : 120), p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    private final class FlightView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        FlightView() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            DcsLink.State s = DcsLink.st;
            float w = getWidth();
            float h = getHeight();
            p.setTypeface(Theme.MONO);
            boolean lbs = family(s.name).equals("hornet");
            float fuel = s.fuel + s.fuelExt;
            String fuelS = lbs ? Math.round(fuel * 2.20462f) + " lb" : Math.round(fuel) + " kg";
            String mins = burn > 1 ? Math.round(fuel / burn) + " min" : "—";
            String[][] cells = {
                {"IAS", Math.round(s.ias * 1.94384f) + " kt"}, {"MACH", String.format(Locale.ROOT, "%.2f", s.mach)},
                {"ALT", Math.round(s.alt * 3.28084f) + " ft"}, {"RADAR ALT", Math.round(s.agl * 3.28084f) + " ft"},
                {"HEADING", Math.round((s.hdg + 360) % 360) + "°"}, {"VERT SPEED", Math.round(s.vs * 196.85f) + " fpm"},
                {"AoA", String.format(Locale.ROOT, "%.1f°", s.aoa)}, {"G", String.format(Locale.ROOT, "%.1f  (max %.1f)", s.g, DcsLink.maxG)},
                {"FUEL", fuelS}, {"TIME LEFT", mins},
                {"CHAFF / FLARE", (s.chaff < 0 ? "—" : s.chaff) + " / " + (s.flare < 0 ? "—" : s.flare)},
                {"GUN / WEAPONS", (s.shells < 0 ? "—" : s.shells) + " / " + (s.weapons < 0 ? "—" : s.weapons)},
            };
            float cw = w / 2f;
            float ch = (h - dp(30)) / 6f;
            for (int i = 0; i < cells.length; i++) {
                float x = (i % 2) * cw + dp(8);
                float y = (i / 2) * ch + dp(14);
                p.setColor(Theme.DIM);
                p.setTextSize(dp(big ? 11 : 9));
                c.drawText(cells[i][0], x, y, p);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(big ? 20 : 15));
                c.drawText(DcsLink.live() ? cells[i][1] : "—", x, y + dp(big ? 22 : 18), p);
            }
            float y = h - dp(10);
            String[] names = {"GEAR", "FLAPS", "BRAKE", "HOOK"};
            float[] vals = {s.gear, s.flaps, s.brake, s.hook};
            for (int i = 0; i < 4; i++) {
                p.setColor(vals[i] > 0.95f ? GREEN : vals[i] > 0.05f ? AMBER : 0xFF5A5A60);
                p.setTextSize(dp(11));
                c.drawText("● " + names[i], dp(8) + i * (w / 4f), y, p);
            }
        }
    }

    // ------------------------------------------------------------------ setup and full screen

    static String script(android.content.Context c) {
        try (InputStream in = c.getAssets().open("NovaExport.lua")) {
            byte[] b = new byte[in.available()];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void setup() {
        String ip = "?";
        try {
            for (java.net.NetworkInterface ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                for (java.net.InetAddress a : java.util.Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address && ni.getName().startsWith("wlan")) {
                        ip = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
            // no Wi-Fi
        }
        String msg = "DATA (radar, carrier, panels)\n"
                + "1. On the PC open:  Saved Games\\DCS\\Scripts  (make the Scripts folder if it is missing; on the beta it is "
                + "DCS.openbeta).\n"
                + "2. No Export.lua there? Save the NOVA script as  Export.lua.\n"
                + "   Already have one (Tacview, SRS...)? Save it as  NovaExport.lua  and add this line at the end of Export.lua:\n"
                + "   dofile(lfs.writedir()..[[Scripts\\NovaExport.lua]])\n"
                + "3. Phone and PC on the same Wi-Fi / router. If Windows asks, allow DCS through the firewall.\n"
                + "4. Start a mission: the dot here turns green.\n"
                + "   Nothing arrives? Open the script and change 255.255.255.255 to this phone's IP: " + ip + "\n\n"
                + "THRUST LEVER\n"
                + "AXIS mode: in DCS Options > Controls > your aircraft > Axis Commands > Thrust, click the cell under "
                + "NOVA Remote and move the lever. If NOVA Remote has no axis column, remove the phone in Windows Bluetooth "
                + "and pair again once.\nKEYS mode needs no setup (uses Num+ / Num−).\n\n"
                + "BUTTONS use the KEY DECK / PC REMOTE Bluetooth connection.";
        new AlertDialog.Builder(host).setTitle("DCS COCKPIT setup")
                .setMessage(msg)
                .setPositiveButton("SHARE SCRIPT", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "NovaExport.lua");
                    i.putExtra(Intent.EXTRA_TEXT, script(host));
                    host.startActivity(Intent.createChooser(i, "Send the DCS script to your PC"));
                })
                .setNeutralButton("TYPE IT ON THE PC", (d, w) -> {
                    if (!PcHid.connected()) {
                        host.toast("Connect the phone to the PC first (KEY DECK > CONNECT)");
                        return;
                    }
                    host.toast("Opening Notepad and typing the script (about 3 minutes, don't touch the PC)");
                    PcHid.run("K:WIN+R|W:600|T:notepad|K:ENTER|W:2000");
                    PcHid.type(script(host));
                })
                .setNegativeButton("VOICE " + (Prefs.getBool(K_VOICE, true) ? "ON" : "OFF"), (d, w) -> {
                    Prefs.putBool(K_VOICE, !Prefs.getBool(K_VOICE, true));
                    host.toast("Carrier calls " + (Prefs.getBool(K_VOICE, true) ? "on" : "off"));
                }).show();
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(10), dp(40), dp(10), dp(12));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("DCS COCKPIT", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", () -> {
            host.hideOverlay();
            PcHid.releaseAll();
            refresh();
        }));
        v.addView(head, wide());
        ScrollView sv = new ScrollView(host);
        sv.addView(new DcsCockpitWidget(host, true));
        v.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    static int dim(int c) {
        return Color.argb(80, Color.red(c), Color.green(c), Color.blue(c));
    }
}
