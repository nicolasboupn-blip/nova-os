package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Small shared tools for the extra home screen layouts: app icons as bitmaps (for layouts that paint themselves),
 * the main colour of an icon, the list of apps you opened (for RECENT and TIMELINE) and media buttons.
 */
final class HomeKit {
    private static final Map<String, Bitmap> ICONS = new HashMap<>();
    private static final Map<String, Integer> COLORS = new HashMap<>();
    private static final String K_HISTORY = "home_history";
    private static final int MAX_HISTORY = 80;

    private HomeKit() {
    }

    /** The app icon painted into a square bitmap of px pixels, with the current icon look. */
    static Bitmap icon(Context c, AppEntry e, int px) {
        px = Math.max(8, px);
        String key = e.pkg + "/" + e.cls + "/" + px + "/" + Prefs.iconStyle() + "/" + Theme.ACCENT;
        Bitmap b = ICONS.get(key);
        if (b != null) {
            return b;
        }
        if (ICONS.size() > 400) {
            ICONS.clear();
        }
        b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Drawable d = Theme.tint(c, e.icon);
        if (d != null) {
            Rect old = d.copyBounds();
            d.setBounds(0, 0, px, px);
            d.draw(cv);
            d.setBounds(old);
        }
        ICONS.put(key, b);
        return b;
    }

    /** The main colour of an app's icon (a bit brighter and richer than the plain average), for cards and spines. */
    static int color(Context c, AppEntry e) {
        Integer got = COLORS.get(e.pkg);
        if (got != null) {
            return got;
        }
        int out = Theme.ACCENT;
        try {
            Drawable d = e.icon;
            Bitmap b = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            Rect old = d.copyBounds();
            d.setBounds(0, 0, 24, 24);
            d.draw(cv);
            d.setBounds(old);
            long r = 0;
            long g = 0;
            long bl = 0;
            long w = 0;
            for (int y = 0; y < 24; y++) {
                for (int x = 0; x < 24; x++) {
                    int p = b.getPixel(x, y);
                    if (Color.alpha(p) < 128) {
                        continue;
                    }
                    float[] hsv = new float[3];
                    Color.colorToHSV(p, hsv);
                    // colourful pixels count more than white or grey ones
                    int weight = 1 + Math.round(hsv[1] * hsv[2] * 8);
                    r += Color.red(p) * weight;
                    g += Color.green(p) * weight;
                    bl += Color.blue(p) * weight;
                    w += weight;
                }
            }
            if (w > 0) {
                float[] hsv = new float[3];
                Color.colorToHSV(Color.rgb((int) (r / w), (int) (g / w), (int) (bl / w)), hsv);
                hsv[1] = Math.min(1f, hsv[1] * 1.25f);
                hsv[2] = Math.max(0.45f, Math.min(0.85f, hsv[2]));
                out = Color.HSVToColor(hsv);
            }
        } catch (RuntimeException ignored) {
            // odd icon: keep the accent colour
        }
        COLORS.put(e.pkg, out);
        return out;
    }

    /** Black or white, whichever reads better on the given colour. */
    static int onColor(int bg) {
        double l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0;
        return l > 0.62 ? 0xFF101010 : 0xFFFFFFFF;
    }

    static int darker(int c, float f) {
        return Color.argb(Color.alpha(c), Math.round(Color.red(c) * f), Math.round(Color.green(c) * f),
                Math.round(Color.blue(c) * f));
    }

    // ------------------------------------------------------------------ history of opened apps

    /** Called every time an app is opened from NOVA. */
    static void opened(String pkg) {
        String old = Prefs.getString(K_HISTORY, "");
        StringBuilder b = new StringBuilder(pkg).append('@').append(System.currentTimeMillis());
        String[] parts = old.isEmpty() ? new String[0] : old.split(";");
        for (int i = 0; i < parts.length && i < MAX_HISTORY - 1; i++) {
            b.append(';').append(parts[i]);
        }
        Prefs.putString(K_HISTORY, b.toString());
    }

    /** Every open as {package, time}, newest first. */
    static List<Object[]> history() {
        List<Object[]> out = new ArrayList<>();
        String s = Prefs.getString(K_HISTORY, "");
        if (s.isEmpty()) {
            return out;
        }
        for (String p : s.split(";")) {
            int at = p.lastIndexOf('@');
            if (at <= 0) {
                continue;
            }
            try {
                out.add(new Object[] {p.substring(0, at), Long.parseLong(p.substring(at + 1))});
            } catch (NumberFormatException ignored) {
                // broken entry
            }
        }
        return out;
    }

    /** Opens since midnight, newest first. */
    static List<Object[]> today() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long mid = c.getTimeInMillis();
        List<Object[]> out = new ArrayList<>();
        for (Object[] o : history()) {
            if ((long) o[1] >= mid) {
                out.add(o);
            }
        }
        return out;
    }

    /** The last different apps you opened, newest first. */
    static List<AppEntry> recent(NovaActivity host, int n) {
        List<AppEntry> out = new ArrayList<>();
        for (Object[] o : history()) {
            AppEntry e = host.repo.find((String) o[0]);
            if (e != null && !out.contains(e)) {
                out.add(e);
                if (out.size() >= n) {
                    break;
                }
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ media buttons

    /** Sends play/pause, next or previous to whatever is playing music. */
    static void media(Context c, int keyCode) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
        } catch (RuntimeException ignored) {
            // no music app
        }
    }
}
