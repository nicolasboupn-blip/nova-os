package app.novaos;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Make your own look for NOVA: seven colours, how round the corners are, borders, how see-through panels are, the
 * font and three background effects. The card at the top shows it live. USE MY STYLE applies it everywhere. COPY CODE
 * gives one line you can send to a friend, PASTE CODE reads such a line.
 */
final class ThemeDesigner extends FrameLayout implements BackAware {
    private static final String[] COLOR_NAMES = {"Background", "Background 2 (top)", "Panels", "Accent", "Glow", "Text",
        "Dim text"};

    private final NovaActivity host;
    private final FrameLayout card;
    private final LinearLayout controls;

    ThemeDesigner(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("THEME DESIGNER", 15f, 0xFFB39DFF);
        title.setLetterSpacing(0.15f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(chip("TRY ON HOME", this::tryOnHome));
        head.addView(chip("USE IT", this::useIt));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        card = new FrameLayout(host);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(270));
        clp.topMargin = dp(10);
        col.addView(card, clp);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        controls = new LinearLayout(host);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(0, dp(6), 0, dp(40));
        sv.addView(controls);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(8);
        col.addView(sv, slp);

        addView(col, new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        build();
        preview();
    }

    // ------------------------------------------------------------------ the live card

    private void preview() {
        card.removeAllViews();
        final int bg = UiStyle.customColor(0);
        int bg2 = UiStyle.customColor(1);
        int panel = UiStyle.customColor(2);
        final int accent = UiStyle.customColor(3);
        int text = UiStyle.customColor(5);
        int dim = UiStyle.customColor(6);
        final float radius = Prefs.getInt(UiStyle.K_RADIUS, 100) / 100f;
        float border = Prefs.getInt(UiStyle.K_BORDER, 0) * 0.5f;
        int bcol = Prefs.getInt(UiStyle.K_BCOL, 0x33FFFFFF);
        float glass = Math.max(0.3f, Math.min(1f, Prefs.getInt(UiStyle.K_GLASS, 100) / 100f));
        android.graphics.Typeface face = UiStyle.fontOf(Prefs.getInt(UiStyle.K_FONT, 0));
        int fx = Prefs.getInt(UiStyle.K_FX, 0);

        // a small copy of the home screen: wallpaper, clock, a widget panel, app icons and the dock
        GradientDrawable back = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {bg2, bg});
        back.setCornerRadius(dp(18));
        card.setBackground(back);
        card.setClipToOutline(true);
        if ((fx & UiStyle.FX_AURORA) != 0) {
            card.addView(new Fx(host, 1, accent, UiStyle.customColor(4)), new FrameLayout.LayoutParams(-1, -1));
        }
        if ((fx & UiStyle.FX_DOTS) != 0) {
            card.addView(new Fx(host, 2, text, 0), new FrameLayout.LayoutParams(-1, -1));
        }

        LinearLayout home = new LinearLayout(host);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(14), dp(10), dp(14), dp(10));
        TextView clock = new TextView(host);
        clock.setText("12:34");
        clock.setTextColor(text);
        clock.setTypeface(face);
        clock.setTextSize(30f);
        home.addView(clock);
        TextView date = new TextView(host);
        date.setText("Saturday 17 October");
        date.setTextColor(dim);
        date.setTypeface(face);
        date.setTextSize(11f);
        home.addView(date);

        LinearLayout panelBox = new LinearLayout(host);
        panelBox.setOrientation(LinearLayout.HORIZONTAL);
        panelBox.setGravity(Gravity.CENTER_VERTICAL);
        panelBox.setPadding(dp(12), dp(9), dp(12), dp(9));
        GradientDrawable pd = new GradientDrawable();
        pd.setColor((panel & 0xFFFFFF) | (Math.round(glass * 255) << 24));
        pd.setCornerRadius(dp(16 * radius));
        if (border > 0f) {
            pd.setStroke(Math.max(1, dp(border)), bcol);
        }
        panelBox.setBackground(pd);
        LinearLayout lines = new LinearLayout(host);
        lines.setOrientation(LinearLayout.VERTICAL);
        TextView w1 = new TextView(host);
        w1.setText("WEATHER  18\u00B0");
        w1.setTextColor(text);
        w1.setTypeface(face);
        w1.setTextSize(13f);
        lines.addView(w1);
        TextView w2 = new TextView(host);
        w2.setText("clear, light wind");
        w2.setTextColor(dim);
        w2.setTypeface(face);
        w2.setTextSize(10f);
        lines.addView(w2);
        panelBox.addView(lines, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView btn = new TextView(host);
        btn.setText("OPEN");
        btn.setTextColor(bg);
        btn.setTypeface(face);
        btn.setTextSize(11f);
        btn.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable bd = new GradientDrawable();
        bd.setColor(accent);
        bd.setCornerRadius(dp(12 * radius));
        btn.setBackground(bd);
        panelBox.addView(btn);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = dp(8);
        home.addView(panelBox, plp);

        String[] names = {"Phone", "Chat", "Maps", "Music", "Photos", "Notes", "Shop", "Games"};
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 4; c++) {
                row.addView(icon(names[r * 4 + c], r * 4 + c, accent, panel, text, face, radius),
                        new LinearLayout.LayoutParams(0, -2, 1f));
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
            rlp.topMargin = dp(8);
            home.addView(row, rlp);
        }
        card.addView(home, new FrameLayout.LayoutParams(-1, -1));

        // the dock
        LinearLayout dock = new LinearLayout(host);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable dd = new GradientDrawable();
        dd.setColor((panel & 0xFFFFFF) | (Math.round(glass * 255) << 24));
        dd.setCornerRadius(dp(22 * radius));
        if (border > 0f) {
            dd.setStroke(Math.max(1, dp(border)), bcol);
        }
        dock.setBackground(dd);
        for (int i = 0; i < 4; i++) {
            View ic = new View(host);
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == 0 ? accent : (text & 0xFFFFFF) | 0x55000000);
            g.setCornerRadius(dp(10 * radius));
            ic.setBackground(g);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(26), dp(26));
            ilp.setMargins(dp(8), 0, dp(8), 0);
            dock.addView(ic, ilp);
        }
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dlp.bottomMargin = dp(8);
        card.addView(dock, dlp);
        if ((fx & UiStyle.FX_SCAN) != 0) {
            card.addView(new Fx(host, 3, 0, 0), new FrameLayout.LayoutParams(-1, -1));
        }
    }

    private View icon(String name, int i, int accent, int panel, int text, android.graphics.Typeface face, float radius) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        View sq = new View(host);
        GradientDrawable g = new GradientDrawable();
        g.setColor(i % 3 == 0 ? accent : (panel | 0xFF000000));
        g.setCornerRadius(dp(13 * radius));
        sq.setBackground(g);
        c.addView(sq, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView t = new TextView(host);
        t.setText(name);
        t.setTextColor(text);
        t.setTypeface(face);
        t.setTextSize(8f);
        c.addView(t);
        return c;
    }

    /** Background effects for the little home screen: 1 soft light, 2 dot grid, 3 scan lines. */
    private static final class Fx extends View {
        private final int mode;
        private final int c1;
        private final int c2;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        Fx(Context c, int mode, int c1, int c2) {
            super(c);
            this.mode = mode;
            this.c1 = c1;
            this.c2 = c2;
        }

        @Override
        protected void onDraw(android.graphics.Canvas cv) {
            int w = getWidth();
            int h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            if (mode == 1) {
                float t = (System.currentTimeMillis() % 20000L) / 20000f * 6.2832f;
                p.setShader(new android.graphics.RadialGradient(w * (0.3f + 0.2f * (float) Math.sin(t)), h * 0.35f,
                        w * 0.5f, (c1 & 0xFFFFFF) | 0x66000000, 0, android.graphics.Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, w, h, p);
                p.setShader(new android.graphics.RadialGradient(w * (0.75f + 0.15f * (float) Math.cos(t)), h * 0.7f,
                        w * 0.45f, (c2 & 0xFFFFFF) | 0x55000000, 0, android.graphics.Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, w, h, p);
                p.setShader(null);
                postInvalidateOnAnimation();
            } else if (mode == 2) {
                p.setColor((c1 & 0xFFFFFF) | 0x33000000);
                for (float x = 8 * d; x < w; x += 16 * d) {
                    for (float y = 8 * d; y < h; y += 16 * d) {
                        cv.drawCircle(x, y, 1.2f * d, p);
                    }
                }
            } else {
                p.setColor(0x22000000);
                for (float y = 0; y < h; y += 3 * d) {
                    cv.drawRect(0, y, w, y + d, p);
                }
            }
        }
    }

    // ------------------------------------------------------------------ the controls

    private void build() {
        controls.removeAllViews();
        section("START FROM A STYLE");
        LinearLayout starts = new LinearLayout(host);
        starts.addView(chip("AURORA", () -> start(UiStyle.AURORA)));
        starts.addView(chip("TERMINAL", () -> start(UiStyle.TERMINAL)));
        starts.addView(chip("BLOCK", () -> start(UiStyle.BLOCK)));
        controls.addView(starts);

        section("COLOURS (tap one)");
        for (int i = 0; i < COLOR_NAMES.length; i++) {
            final int k = i;
            controls.addView(colorRow(COLOR_NAMES[i], UiStyle.customColor(i), c -> {
                UiStyle.setCustomColor(k, c);
                refresh();
            }));
        }

        section("SHAPE");
        controls.addView(slider(UiStyle.K_RADIUS, "Corner roundness", 0, 200, 100, v -> v + " %"));
        controls.addView(slider(UiStyle.K_BORDER, "Border thickness", 0, 8, 0, v -> (v * 0.5f) + " dp"));
        controls.addView(colorRow("Border colour", Prefs.getInt(UiStyle.K_BCOL, 0x33FFFFFF), c -> {
            Prefs.putInt(UiStyle.K_BCOL, c);
            refresh();
        }));
        controls.addView(slider(UiStyle.K_GLASS, "Panel see-through (100 = solid)", 30, 100, 100, v -> v + " %"));

        section("FONT");
        controls.addView(fontRow());

        section("BACKGROUND EFFECTS");
        controls.addView(fxRow("Scan lines over everything", UiStyle.FX_SCAN));
        controls.addView(fxRow("Moving soft light", UiStyle.FX_AURORA));
        controls.addView(fxRow("Dot grid", UiStyle.FX_DOTS));

        section("SHARE");
        LinearLayout share = new LinearLayout(host);
        share.addView(chip("COPY CODE", () -> {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("NOVA style", UiStyle.exportCode()));
            host.toast("Style code copied. Send it to a friend");
        }));
        share.addView(chip("PASTE CODE", () -> {
            try {
                ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
                if (UiStyle.importCode(t)) {
                    host.toast("Style loaded. Tap USE IT");
                    refresh();
                    build();
                } else {
                    host.toast("That is not a NOVA style code");
                }
            } catch (Exception e) {
                host.toast("Could not read the clipboard");
            }
        }));
        controls.addView(share);
        TextView note = text("Tap USE IT at the top to switch NOVA to MY STYLE. You can come back here any time.", 11f,
                0xFF8E84B3);
        note.setTypeface(android.graphics.Typeface.DEFAULT);
        note.setPadding(0, dp(12), 0, 0);
        controls.addView(note);
    }

    private void refresh() {
        preview();
    }

    private void start(int style) {
        UiStyle.copyInto(style);
        build();
        preview();
    }

    /** Shows the real home screen in this style. A bar at the bottom lets you keep it or go back to editing. */
    private void tryOnHome() {
        final int before = Prefs.getInt(UiStyle.K_STYLE, 0);
        Prefs.putInt(UiStyle.K_STYLE, UiStyle.CUSTOM);
        Theme.load();
        host.showHome();
        host.getWindow().getDecorView().postDelayed(() -> host.showOverlay(new TryBar(host, before)), 700);
    }

    /** A floating bar over the real home screen. Touches elsewhere go through to the home screen. */
    private static final class TryBar extends FrameLayout implements BackAware {
        private final NovaActivity host;
        private final int before;

        TryBar(final NovaActivity host, final int before) {
            super(host);
            this.host = host;
            this.before = before;
            LinearLayout bar = new LinearLayout(host);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            int pad = Theme.dp(host, 10);
            bar.setPadding(pad, pad, pad, pad);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xEE141126);
            g.setCornerRadius(Theme.dp(host, 22));
            g.setStroke(Theme.dp(host, 1), 0x55FFFFFF);
            bar.setBackground(g);
            TextView t = new TextView(host);
            t.setText("Trying MY STYLE");
            t.setTextColor(0xFFF2EEFF);
            t.setTextSize(12f);
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            bar.addView(btn("KEEP", () -> host.hideOverlay()));
            bar.addView(btn("EDIT", () -> {
                host.showOverlay(new ThemeDesigner(host));
            }));
            bar.addView(btn("UNDO", () -> {
                Prefs.putInt(UiStyle.K_STYLE, before);
                host.hideOverlay();
                Theme.load();
                host.showHome();
            }));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            lp.setMargins(Theme.dp(host, 14), 0, Theme.dp(host, 14), Theme.dp(host, 90));
            addView(bar, lp);
        }

        private TextView btn(String s, final Runnable r) {
            TextView t = new TextView(host);
            t.setText(s);
            t.setTextColor(0xFFB39DFF);
            t.setTextSize(12f);
            t.setTypeface(android.graphics.Typeface.MONOSPACE);
            t.setPadding(Theme.dp(host, 10), Theme.dp(host, 8), Theme.dp(host, 10), Theme.dp(host, 8));
            t.setOnClickListener(v -> r.run());
            return t;
        }

        @Override
        public boolean onBack() {
            host.hideOverlay();
            return true;
        }
    }

    private void useIt() {
        Prefs.putInt(UiStyle.K_STYLE, UiStyle.CUSTOM);
        host.refreshTheme();
    }

    private void section(String s) {
        TextView t = text(s, 10f, 0xFFB39DFF);
        t.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(18);
        p.bottomMargin = dp(4);
        controls.addView(t, p);
    }

    private View colorRow(String label, int color, final java.util.function.IntConsumer set) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final View sw = new View(host);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color | 0xFF000000);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0x66FFFFFF);
        sw.setBackground(g);
        r.addView(sw, new LinearLayout.LayoutParams(dp(54), dp(30)));
        r.setClickable(true);
        r.setOnClickListener(v -> ColorPicker.show(host, label, color, c -> {
            set.accept(c);
            build();
        }));
        return r;
    }

    private View slider(final String key, String label, int min, int max, int def,
            final java.util.function.IntFunction<String> fmt) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(2));
        LinearLayout top = new LinearLayout(host);
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        top.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        int cur = Math.max(min, Math.min(max, Prefs.getInt(key, def)));
        final TextView value = text(fmt.apply(cur), 12f, 0xFFB39DFF);
        top.addView(value);
        box.addView(top);
        SeekBar bar = new SeekBar(host);
        bar.setMin(min);
        bar.setMax(max);
        bar.setProgress(cur);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                value.setText(fmt.apply(p));
                if (user) {
                    Prefs.putInt(key, p);
                    preview();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        box.addView(bar);
        return box;
    }

    private View fontRow() {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text("Font", 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView v = text(UiStyle.FONTS[Math.max(0, Math.min(UiStyle.FONTS.length - 1,
                Prefs.getInt(UiStyle.K_FONT, 0)))] + "  ›", 13f, 0xFFB39DFF);
        v.setClickable(true);
        v.setPadding(dp(10), dp(6), 0, dp(6));
        v.setOnClickListener(x -> {
            int n = (Prefs.getInt(UiStyle.K_FONT, 0) + 1) % UiStyle.FONTS.length;
            Prefs.putInt(UiStyle.K_FONT, n);
            v.setText(UiStyle.FONTS[n] + "  ›");
            v.setTypeface(UiStyle.fontOf(n));
            preview();
        });
        r.addView(v);
        return r;
    }

    private View fxRow(String label, final int bit) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Switch s = new android.widget.Switch(host);
        s.setChecked((Prefs.getInt(UiStyle.K_FX, 0) & bit) != 0);
        s.setOnCheckedChangeListener((b, on) -> {
            int cur = Prefs.getInt(UiStyle.K_FX, 0);
            Prefs.putInt(UiStyle.K_FX, on ? cur | bit : cur & ~bit);
            preview();
        });
        r.addView(s);
        return r;
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, 0xFFF2EEFF);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x26FFFFFF);
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
