package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Looks like the yellow dot-matrix sign at the Zürich bus stops: a black panel in a silver frame, amber LED text with the
 * line and where it goes on the left and the minutes with a ' on the right.
 */
final class BusBoardView extends View {
    static final int ROWS = 4;
    private static final int AMBER = 0xFFFFAA1E;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private Bitmap off;
    private Bitmap mask;
    private String head = "";
    private String clock = "";
    private final List<BusData.Dep> deps = new ArrayList<>();
    private String message = "";

    BusBoardView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        text.setTypeface(Typeface.create(Theme.MONO, Typeface.BOLD));
        text.setColor(AMBER);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, Math.round((12 + 26 + ROWS * 27) * d));
    }

    /** What the sign shows. message is used instead of the rows when there are no buses to show. */
    void set(String stop, String time, List<BusData.Dep> list, String msg) {
        head = stop;
        clock = time;
        deps.clear();
        if (list != null) {
            deps.addAll(list);
        }
        message = msg == null ? "" : msg;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int iw = Math.max(1, Math.round(w - 12 * d));
        int ih = Math.max(1, Math.round(h - 12 * d));
        float pitch = 1.6f * d;
        off = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888);
        mask = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888);
        Canvas co = new Canvas(off);
        Canvas cm = new Canvas(mask);
        cm.drawColor(0xFF050505);
        Paint dim = new Paint(Paint.ANTI_ALIAS_FLAG);
        dim.setColor(0xFF1E1407);
        Paint hole = new Paint(Paint.ANTI_ALIAS_FLAG);
        hole.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        for (float y = pitch / 2; y < ih; y += pitch) {
            for (float x = pitch / 2; x < iw; x += pitch) {
                co.drawCircle(x, y, pitch * 0.4f, dim);
                cm.drawCircle(x, y, pitch * 0.41f, hole);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        off = null;
        mask = null;
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFB9BEC4);
        r.set(0, 0, w, h);
        cv.drawRoundRect(r, 10 * d, 10 * d, p);
        p.setColor(0xFF8F959C);
        r.set(2 * d, 2 * d, w - 2 * d, h - 2 * d);
        cv.drawRoundRect(r, 9 * d, 9 * d, p);
        p.setColor(0xFFB9BEC4);
        r.set(3.5f * d, 3.5f * d, w - 3.5f * d, h - 3.5f * d);
        cv.drawRoundRect(r, 8 * d, 8 * d, p);
        float ix = 6 * d;
        float iy = 6 * d;
        float iw = w - 12 * d;
        float ih = h - 12 * d;
        p.setColor(0xFF050505);
        r.set(ix, iy, ix + iw, iy + ih);
        cv.drawRoundRect(r, 5 * d, 5 * d, p);
        if (off == null || mask == null) {
            return;
        }
        cv.save();
        cv.clipRect(r);
        cv.drawBitmap(off, ix, iy, null);

        float left = ix + 10 * d;
        float right = ix + iw - 10 * d;
        // header: the stop and the time
        text.setTextSize(11f * d);
        text.setTextAlign(Paint.Align.LEFT);
        float hy = iy + 19 * d;
        cv.drawText(fit(head, right - left - 70 * d), left, hy, text);
        text.setTextAlign(Paint.Align.RIGHT);
        cv.drawText(clock, right, hy, text);

        long now = System.currentTimeMillis();
        if (deps.isEmpty()) {
            text.setTextAlign(Paint.Align.LEFT);
            text.setTextSize(15f * d);
            String[] lines = message.split("\n");
            for (int i = 0; i < lines.length && i < ROWS; i++) {
                cv.drawText(fit(lines[i], right - left), left, iy + (26 + 22 + i * 27) * d, text);
            }
        } else {
            for (int i = 0; i < ROWS && i < deps.size(); i++) {
                BusData.Dep dep = deps.get(i);
                float by = iy + (26 + 22 + i * 27) * d;
                text.setTextSize(17f * d);
                text.setTextAlign(Paint.Align.RIGHT);
                cv.drawText(dep.line, left + 26 * d, by, text);
                long mins = Math.max(0, (dep.at - now) / 60000L);
                text.setTextAlign(Paint.Align.RIGHT);
                cv.drawText(mins + "'", right, by, text);
                text.setTextAlign(Paint.Align.LEFT);
                cv.drawText(fit(dep.to, right - left - 36 * d - 46 * d), left + 34 * d, by, text);
            }
        }
        cv.drawBitmap(mask, ix, iy, null);
        cv.restore();
    }

    /** Cuts a text so it fits the width. */
    private String fit(String s, float width) {
        if (s == null) {
            return "";
        }
        int n = text.breakText(s, true, Math.max(10, width), null);
        return n >= s.length() ? s : s.substring(0, Math.max(0, n));
    }
}
