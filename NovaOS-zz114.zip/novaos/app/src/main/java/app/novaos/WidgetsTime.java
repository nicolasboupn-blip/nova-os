package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Time widgets: analog clock, world clock, binary clock, time progress, moon phase, hourglass. */
final class WidgetsTime {
    private WidgetsTime() {
    }

    // ================================================================== ANALOG CLOCK

    static final class Analog extends NovaWidget {
        private final Face face;
        private final TextView date;

        Analog(NovaActivity host) {
            super(host);
            face = new Face(host);
            addView(face, fill());
            date = text("", 10f, Theme.DIM);
            addView(date, wide());
        }

        @Override
        long tickMs() {
            return 1000;
        }

        @Override
        void tick() {
            face.invalidate();
            date.setText(new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(new Date()));
        }

        private static final class Face extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Face(Context c) {
                super(c);
                p.setStrokeCap(Paint.Cap.ROUND);
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - Theme.dp(getContext(), 3);
                if (r <= 0) {
                    return;
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x14FFFFFF);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.03f);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x77000000);
                c.drawCircle(cx, cy, r, p);
                for (int i = 0; i < 60; i++) {
                    double a = Math.PI * 2 * i / 60;
                    boolean big = i % 5 == 0;
                    float in = r * (big ? 0.80f : 0.88f);
                    float out = r * 0.93f;
                    p.setStrokeWidth(r * (big ? 0.035f : 0.012f));
                    p.setColor(big ? Theme.TEXT : Theme.DIM);
                    c.drawLine(cx + (float) Math.sin(a) * in, cy - (float) Math.cos(a) * in,
                            cx + (float) Math.sin(a) * out, cy - (float) Math.cos(a) * out, p);
                }
                Calendar now = Calendar.getInstance();
                float s = now.get(Calendar.SECOND);
                float m = now.get(Calendar.MINUTE) + s / 60f;
                float h = now.get(Calendar.HOUR) + m / 60f;
                hand(c, cx, cy, h / 12f, r * 0.50f, r * 0.065f, Theme.TEXT);
                hand(c, cx, cy, m / 60f, r * 0.74f, r * 0.045f, Theme.TEXT);
                hand(c, cx, cy, s / 60f, r * 0.84f, r * 0.018f, Theme.ACCENT);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Theme.ACCENT);
                c.drawCircle(cx, cy, r * 0.055f, p);
            }

            private void hand(Canvas c, float cx, float cy, float turn, float len, float w, int color) {
                double a = Math.PI * 2 * turn;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(w);
                p.setColor(color);
                c.drawLine(cx - (float) Math.sin(a) * len * 0.15f, cy + (float) Math.cos(a) * len * 0.15f,
                        cx + (float) Math.sin(a) * len, cy - (float) Math.cos(a) * len, p);
            }
        }
    }

    // ================================================================== WORLD CLOCK

    static final class World extends NovaWidget {
        static final String[] CITIES = {"Zurich", "London", "New York", "Los Angeles", "Chicago", "Sao Paulo",
            "Moscow", "Dubai", "Kyiv", "Istanbul", "Delhi", "Bangkok", "Singapore", "Hong Kong", "Beijing", "Tokyo",
            "Seoul", "Sydney", "Auckland", "Honolulu"};
        static final String[] ZONES = {"Europe/Zurich", "Europe/London", "America/New_York", "America/Los_Angeles",
            "America/Chicago", "America/Sao_Paulo", "Europe/Moscow", "Asia/Dubai", "Europe/Kiev", "Europe/Istanbul",
            "Asia/Kolkata", "Asia/Bangkok", "Asia/Singapore", "Asia/Hong_Kong", "Asia/Shanghai", "Asia/Tokyo",
            "Asia/Seoul", "Australia/Sydney", "Pacific/Auckland", "Pacific/Honolulu"};
        private static final int[] DEFAULT = {2, 1, 15, 17};
        private final TextView[] names = new TextView[4];
        private final TextView[] offs = new TextView[4];
        private final TextView[] times = new TextView[4];

        World(NovaActivity host) {
            super(host);
            for (int i = 0; i < 4; i++) {
                final int idx = i;
                LinearLayout r = row();
                r.setClickable(true);
                Theme.ripple(r);
                r.setOnClickListener(v -> choose(idx));
                LinearLayout left = new LinearLayout(host);
                left.setOrientation(VERTICAL);
                names[i] = text("", 10f, Theme.TEXT);
                names[i].setGravity(android.view.Gravity.START);
                offs[i] = text("", 8f, Theme.DIM);
                offs[i].setGravity(android.view.Gravity.START);
                left.addView(names[i]);
                left.addView(offs[i]);
                r.addView(left, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
                times[i] = text("", 17f, Theme.TEXT);
                r.addView(times[i]);
                LinearLayout.LayoutParams lp = fill();
                lp.setMargins(dp(4), 0, dp(4), 0);
                addView(r, lp);
            }
            addView(text("tap a city to change it", 8f, Theme.DIM), wide());
        }

        private int city(int i) {
            int c = Prefs.getInt("wc_" + i, DEFAULT[i]);
            return c >= 0 && c < CITIES.length ? c : DEFAULT[i];
        }

        private void choose(int i) {
            new AlertDialog.Builder(host).setTitle("City")
                    .setItems(CITIES, (d, which) -> {
                        Prefs.putInt("wc_" + i, which);
                        tick();
                    }).show();
        }

        @Override
        long tickMs() {
            return 15000;
        }

        @Override
        void tick() {
            Date now = new Date();
            TimeZone here = TimeZone.getDefault();
            int hereDay = dayKey(Calendar.getInstance(here));
            String pattern = DateFormat.is24HourFormat(host) ? "HH:mm" : "h:mm a";
            for (int i = 0; i < 4; i++) {
                int c = city(i);
                TimeZone tz = TimeZone.getTimeZone(ZONES[c]);
                SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.getDefault());
                f.setTimeZone(tz);
                names[i].setText(CITIES[c].toUpperCase(Locale.ROOT));
                times[i].setText(f.format(now));
                float diff = (tz.getOffset(now.getTime()) - here.getOffset(now.getTime())) / 3600000f;
                String h = diff == 0 ? "same time" : (diff > 0 ? "+" : "") + trim(diff) + "h";
                int day = dayKey(Calendar.getInstance(tz)) - hereDay;
                String d = day > 0 ? " · tomorrow" : day < 0 ? " · yesterday" : "";
                offs[i].setText(h + d);
            }
        }

        private static int dayKey(Calendar c) {
            return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
        }

        private static String trim(float f) {
            return f == Math.round(f) ? String.valueOf(Math.round(f)) : String.valueOf(f);
        }
    }

    // ================================================================== BINARY CLOCK

    static final class Binary extends NovaWidget {
        private final Bits bits;
        private final TextView label;

        Binary(NovaActivity host) {
            super(host);
            bits = new Bits(host);
            addView(bits, fill());
            label = text("", 10f, Theme.DIM);
            addView(label, wide());
        }

        @Override
        long tickMs() {
            return 1000;
        }

        @Override
        void tick() {
            Calendar c = Calendar.getInstance();
            int h = c.get(Calendar.HOUR_OF_DAY);
            int m = c.get(Calendar.MINUTE);
            int s = c.get(Calendar.SECOND);
            bits.set(new int[] {h / 10, h % 10, m / 10, m % 10, s / 10, s % 10});
            label.setText(String.format(Locale.ROOT, "%02d:%02d:%02d  ·  read the columns top 8 4 2 1", h, m, s));
        }

        private static final class Bits extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private int[] digits = new int[6];

            Bits(Context c) {
                super(c);
            }

            void set(int[] d) {
                digits = d;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float size = Math.min(getWidth() / 7.2f, getHeight() / 4.3f);
                float startX = (getWidth() - 7f * size) / 2f;
                float top = (getHeight() - 4f * size) / 2f;
                for (int k = 0; k < 6; k++) {
                    float x = startX + k * size + (k / 2) * size * 0.5f + size / 2f;
                    for (int b = 0; b < 4; b++) {
                        float y = top + (3 - b) * size + size / 2f;
                        boolean on = (digits[k] & (1 << b)) != 0;
                        p.setColor(on ? Theme.ACCENT : 0x22FFFFFF);
                        c.drawCircle(x, y, size * 0.34f, p);
                    }
                }
            }
        }
    }

    // ================================================================== TIME PROGRESS

    static final class Progress extends NovaWidget {
        private static final String[] NAMES = {"DAY", "WEEK", "MONTH", "YEAR"};
        private final WidgetBar[] bars = new WidgetBar[4];
        private final TextView[] pct = new TextView[4];
        private final TextView foot;

        Progress(NovaActivity host) {
            super(host);
            for (int i = 0; i < 4; i++) {
                LinearLayout r = row();
                TextView n = text(NAMES[i], 9f, Theme.DIM);
                n.setGravity(android.view.Gravity.START);
                r.addView(n, new LinearLayout.LayoutParams(dp(44), LayoutParams.WRAP_CONTENT));
                bars[i] = new WidgetBar(host);
                r.addView(bars[i], new LinearLayout.LayoutParams(0, dp(8), 1f));
                pct[i] = text("", 10f, Theme.TEXT);
                r.addView(pct[i], new LinearLayout.LayoutParams(dp(40), LayoutParams.WRAP_CONTENT));
                addView(r, fill());
            }
            foot = text("", 9f, Theme.DIM);
            addView(foot, wide());
        }

        @Override
        long tickMs() {
            return 30000;
        }

        @Override
        void tick() {
            Calendar c = Calendar.getInstance();
            float dayFrac = (c.get(Calendar.HOUR_OF_DAY) * 3600 + c.get(Calendar.MINUTE) * 60
                    + c.get(Calendar.SECOND)) / 86400f;
            int dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7; // Monday = 0
            float[] f = {
                dayFrac,
                (dow + dayFrac) / 7f,
                (c.get(Calendar.DAY_OF_MONTH) - 1 + dayFrac) / c.getActualMaximum(Calendar.DAY_OF_MONTH),
                (c.get(Calendar.DAY_OF_YEAR) - 1 + dayFrac) / c.getActualMaximum(Calendar.DAY_OF_YEAR)};
            for (int i = 0; i < 4; i++) {
                bars[i].set(f[i]);
                pct[i].setText(Math.round(f[i] * 1000) / 10f + "%");
            }
            foot.setText("week " + c.get(Calendar.WEEK_OF_YEAR) + "  ·  day " + c.get(Calendar.DAY_OF_YEAR)
                    + " of " + c.getActualMaximum(Calendar.DAY_OF_YEAR));
        }
    }

    // ================================================================== MOON

    static final class Moon extends NovaWidget {
        /** A known new moon: 6 Jan 2000, 18:14 UTC. */
        private static final long NEW_MOON_MS = 947182440000L;
        private static final double SYNODIC = 29.530588853;
        private final Disc disc;
        private final TextView name;
        private final TextView info;

        Moon(NovaActivity host) {
            super(host);
            disc = new Disc(host);
            addView(disc, fill());
            name = text("", 12f, Theme.TEXT);
            addView(name, wide());
            info = text("", 9f, Theme.DIM);
            addView(info, wide());
        }

        @Override
        long tickMs() {
            return 600000;
        }

        @Override
        void tick() {
            double days = (System.currentTimeMillis() - NEW_MOON_MS) / 86400000.0;
            double age = ((days % SYNODIC) + SYNODIC) % SYNODIC;
            double phase = age / SYNODIC;
            double lit = (1 - Math.cos(2 * Math.PI * phase)) / 2;
            disc.set(phase);
            name.setText(phaseName(phase));
            double toFull = ((0.5 - phase + 1) % 1) * SYNODIC;
            double toNew = ((1 - phase) % 1) * SYNODIC;
            String next = toFull < toNew ? "full moon in " + days(toFull) : "new moon in " + days(toNew);
            info.setText(Math.round(lit * 100) + "% lit  ·  " + next);
        }

        private static String days(double d) {
            long n = Math.round(d);
            return n <= 0 ? "today" : n == 1 ? "1 day" : n + " days";
        }

        private static String phaseName(double p) {
            if (p < 0.033 || p > 0.967) {
                return "NEW MOON";
            }
            if (p < 0.217) {
                return "WAXING CRESCENT";
            }
            if (p < 0.283) {
                return "FIRST QUARTER";
            }
            if (p < 0.467) {
                return "WAXING GIBBOUS";
            }
            if (p < 0.533) {
                return "FULL MOON";
            }
            if (p < 0.717) {
                return "WANING GIBBOUS";
            }
            if (p < 0.783) {
                return "LAST QUARTER";
            }
            return "WANING CRESCENT";
        }

        private static final class Disc extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF oval = new RectF();
            private double phase;

            Disc(Context c) {
                super(c);
            }

            void set(double ph) {
                phase = ph;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) * 0.86f;
                if (r <= 0) {
                    return;
                }
                int dark = 0xFF26242E;
                int lit = 0xFFE9E4D0;
                p.setStyle(Paint.Style.FILL);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x22000000);
                c.drawCircle(cx, cy, r * 1.12f, p);
                p.setColor(dark);
                c.drawCircle(cx, cy, r, p);
                // the lit half: right while waxing, left while waning
                oval.set(cx - r, cy - r, cx + r, cy + r);
                p.setColor(lit);
                c.drawArc(oval, phase < 0.5 ? -90 : 90, 180, true, p);
                // the terminator: an ellipse that eats into the lit half (crescent) or adds to it (gibbous)
                double k = Math.cos(2 * Math.PI * phase);
                float w = (float) Math.abs(k) * r;
                oval.set(cx - w, cy - r, cx + w, cy + r);
                p.setColor(k > 0 ? dark : lit);
                c.drawOval(oval, p);
            }
        }
    }

    // ================================================================== HOURGLASS

    static final class Hourglass extends NovaWidget {
        private static final int[] MINUTES = {1, 3, 5, 10};
        /** Shared by every hourglass so the panel and home screen show the same one. */
        private static long total = 60000L;
        private static long endAt;
        private static long pausedLeft = -1;
        private static Runnable alarm;
        private static final android.os.Handler ALARM = new android.os.Handler(android.os.Looper.getMainLooper());

        private final Glass glass;
        private final TextView time;
        private final TextView[] chips = new TextView[MINUTES.length];

        Hourglass(NovaActivity host) {
            super(host);
            glass = new Glass(host);
            glass.setClickable(true);
            glass.setOnClickListener(v -> toggle());
            glass.setOnLongClickListener(v -> {
                reset();
                return true;
            });
            addView(glass, fill());
            time = text("", 13f, Theme.TEXT);
            addView(time, wide());
            LinearLayout r = row();
            for (int i = 0; i < MINUTES.length; i++) {
                final int m = MINUTES[i];
                chips[i] = chip(m + "M", () -> {
                    total = m * 60000L;
                    reset();
                    toggle();
                });
                r.addView(chips[i], weight(1f));
            }
            addView(r, wide());
        }

        private static boolean running() {
            return endAt > 0 && pausedLeft < 0;
        }

        private static long left() {
            if (pausedLeft >= 0) {
                return pausedLeft;
            }
            if (endAt <= 0) {
                return total;
            }
            return Math.max(0, endAt - System.currentTimeMillis());
        }

        private void toggle() {
            if (running()) {
                pausedLeft = left();
                cancelAlarm();
            } else {
                long l = left() <= 0 ? total : left();
                endAt = System.currentTimeMillis() + l;
                pausedLeft = -1;
                final NovaActivity h = host;
                alarm = () -> {
                    endAt = 0;
                    pausedLeft = -1;
                    Sfx.play(Sfx.WIN);
                    h.buzz(400);
                    h.toast("Hourglass: time is up");
                };
                ALARM.postDelayed(alarm, l);
            }
            Sfx.play(Sfx.CLICK);
            tick();
        }

        private void reset() {
            cancelAlarm();
            endAt = 0;
            pausedLeft = -1;
            tick();
        }

        private static void cancelAlarm() {
            if (alarm != null) {
                ALARM.removeCallbacks(alarm);
                alarm = null;
            }
        }

        @Override
        long tickMs() {
            return 200;
        }

        @Override
        void tick() {
            long l = left();
            glass.set(total > 0 ? l / (float) total : 1f, running());
            long s = (l + 999) / 1000;
            String state = running() ? "" : endAt > 0 ? "  · paused" : "  · tap the glass";
            time.setText(String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60) + state);
            for (int i = 0; i < MINUTES.length; i++) {
                pick(chips[i], total == MINUTES[i] * 60000L);
            }
        }

        private static final class Glass extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Path path = new Path();
            private float top = 1f;
            private boolean flowing;

            Glass(Context c) {
                super(c);
            }

            void set(float topFrac, boolean run) {
                top = Math.max(0f, Math.min(1f, topFrac));
                flowing = run;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float h = getHeight() * 0.92f;
                float w = Math.min(getWidth() * 0.5f, h * 0.62f);
                float cx = getWidth() / 2f;
                float y0 = (getHeight() - h) / 2f;
                float mid = y0 + h / 2f;
                float neck = w * 0.06f;
                // sand in the top bulb: a triangle that shrinks toward the neck
                p.setStyle(Paint.Style.FILL);
                p.setColor(Theme.ACCENT);
                float th = (h / 2f) * top;
                if (th > 1) {
                    float hw = (w / 2f) * (th / (h / 2f));
                    path.reset();
                    path.moveTo(cx - hw, mid - th);
                    path.lineTo(cx + hw, mid - th);
                    path.lineTo(cx + neck, mid);
                    path.lineTo(cx - neck, mid);
                    path.close();
                    c.drawPath(path, p);
                }
                // sand piled in the bottom bulb
                float bh = (h / 2f) * (1f - top);
                if (bh > 1) {
                    float hw = (w / 2f);
                    float yb = y0 + h;
                    float hwTop = hw * (1f - bh / (h / 2f));
                    path.reset();
                    path.moveTo(cx - hw, yb);
                    path.lineTo(cx + hw, yb);
                    path.lineTo(cx + Math.max(neck, hwTop), yb - bh);
                    path.lineTo(cx - Math.max(neck, hwTop), yb - bh);
                    path.close();
                    c.drawPath(path, p);
                }
                if (flowing && top > 0f) {
                    p.setStrokeWidth(neck);
                    c.drawLine(cx, mid, cx, y0 + h - bh, p);
                }
                // the glass outline
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Theme.dp(getContext(), 2));
                p.setColor(Theme.TEXT);
                path.reset();
                path.moveTo(cx - w / 2f, y0);
                path.lineTo(cx + w / 2f, y0);
                path.lineTo(cx + neck, mid);
                path.lineTo(cx + w / 2f, y0 + h);
                path.lineTo(cx - w / 2f, y0 + h);
                path.lineTo(cx - neck, mid);
                path.close();
                c.drawPath(path, p);
            }
        }
    }
}
