package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;

/**
 * Extra home screens, part three: SUBWAY (your apps as stops on a tram line map), CAROUSEL (big covers that turn in 3D),
 * SIDEBAR (a rail of round apps on the left, widgets on the right), WHEEL (a music player with a click wheel),
 * RADIO (an old radio: turn the dial to tune into an app) and MASONRY (a wall of cards in two columns).
 */
final class HomesC {
    private HomesC() {
    }

    // ================================================================== SUBWAY

    /** A line map like the one above the doors in a tram: your pinned, recent and other apps are the stops. */
    static final class Subway extends AltHome {
        static final int[] COLORS = {0xFFE2001A, 0xFF0072BC, 0xFF009B3A};
        private final TextView time;

        Subway(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFFF4F4F2);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.setBackgroundColor(0xFF1D1D1B);
            head.setPadding(dp(16), dp(44), dp(16), dp(14));
            TextView badge = text("N", 20f, 0xFFFFFFFF);
            badge.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            badge.setGravity(Gravity.CENTER);
            badge.setBackgroundColor(COLORS[0]);
            head.addView(badge, lp(dp(40), dp(40)));
            LinearLayout dir = new LinearLayout(host);
            dir.setOrientation(LinearLayout.VERTICAL);
            dir.setPadding(dp(12), 0, 0, 0);
            TextView dl = text("Direction", 10f, 0xFFB0B0B0);
            dl.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            dl.setGravity(Gravity.START);
            dir.addView(dl);
            TextView dn = text("All apps", 20f, 0xFFFFFFFF);
            dn.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            dn.setGravity(Gravity.START);
            dir.addView(dn);
            dir.setOnClickListener(v -> host.showDrawer());
            head.addView(dir, lp(0, -2, 1f));
            time = text(clock(), 26f, 0xFFFFD100);
            time.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            head.addView(time);
            col.addView(head, lp(-1, -2));

            List<List<AppEntry>> lines = new ArrayList<>();
            List<AppEntry> pins = pinned();
            List<AppEntry> rec = HomeKit.recent(host, 8);
            rec.removeAll(pins);
            List<AppEntry> rest = new ArrayList<>();
            for (AppEntry e : host.repo.all) {
                if (rest.size() >= 12) {
                    break;
                }
                if (!pins.contains(e) && !rec.contains(e)) {
                    rest.add(e);
                }
            }
            lines.add(pins);
            lines.add(rec);
            lines.add(rest);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(new LineMap(host, lines, new String[] {"PINNED", "RECENT", "MORE"}));
            col.addView(sv, lp(-1, 0, 1f));
            LinearLayout foot = new LinearLayout(host);
            foot.setBackgroundColor(0xFF1D1D1B);
            foot.setPadding(dp(8), dp(4), dp(8), dp(12));
            String[] n = {"ALL", "WIDGETS", "BUS", "SETTINGS"};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new WidgetsSheet(host)), () -> BusScreen.open(host),
                () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 11f, 0xFFFFFFFF);
                t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, dp(12), 0, dp(10));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                foot.addView(t, lp(0, -2, 1f));
            }
            col.addView(foot, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        final class LineMap extends View {
            private final List<Object[]> stops = new ArrayList<>(); // {AppEntry or String header, line index}
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final GestureDetector gd;
            private final float d;
            private final float gap;
            private final float x;

            LineMap(Context c, List<List<AppEntry>> lines, String[] names) {
                super(c);
                d = getResources().getDisplayMetrics().density;
                gap = 54 * d;
                x = 46 * d;
                for (int l = 0; l < lines.size(); l++) {
                    if (lines.get(l).isEmpty()) {
                        continue;
                    }
                    stops.add(new Object[] {names[l], l});
                    for (AppEntry e : lines.get(l)) {
                        stops.add(new Object[] {e, l});
                    }
                }
                gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        AppEntry a = at(e.getY());
                        if (a != null) {
                            host.launch(a);
                        }
                        return true;
                    }

                    @Override
                    public void onLongPress(MotionEvent e) {
                        AppEntry a = at(e.getY());
                        if (a != null) {
                            host.appMenu(a);
                        }
                    }
                });
            }

            private float yOf(int i) {
                return 40 * d + i * gap;
            }

            private AppEntry at(float y) {
                int i = Math.round((y - 40 * d) / gap);
                if (i >= 0 && i < stops.size() && stops.get(i)[0] instanceof AppEntry) {
                    return (AppEntry) stops.get(i)[0];
                }
                return null;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                return gd.onTouchEvent(e);
            }

            @Override
            protected void onMeasure(int ws, int hs) {
                setMeasuredDimension(MeasureSpec.getSize(ws), Math.round(yOf(Math.max(1, stops.size())) + 20 * d));
            }

            @Override
            protected void onDraw(Canvas c) {
                if (stops.isEmpty()) {
                    p.setColor(0xFF555555);
                    p.setTextSize(14 * d);
                    c.drawText("Pin some apps to build your line.", x, 60 * d, p);
                    return;
                }
                // the line itself, coloured per section; the change between sections is dashed
                for (int i = 0; i < stops.size() - 1; i++) {
                    int l = (int) stops.get(i + 1)[1];
                    boolean change = stops.get(i + 1)[0] instanceof String;
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(7 * d);
                    p.setColor(COLORS[l % COLORS.length]);
                    p.setPathEffect(change ? new DashPathEffect(new float[] {6 * d, 6 * d}, 0) : null);
                    if (change) {
                        p.setColor(0xFF9A9A9A);
                        p.setStrokeWidth(3 * d);
                    }
                    c.drawLine(x, yOf(i), x, yOf(i + 1), p);
                }
                p.setPathEffect(null);
                int minutes = 0;
                for (int i = 0; i < stops.size(); i++) {
                    Object o = stops.get(i)[0];
                    int l = (int) stops.get(i)[1];
                    int col = COLORS[l % COLORS.length];
                    float y = yOf(i);
                    if (o instanceof String) {
                        // a section start: line badge and name
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(col);
                        c.drawRect(x - 13 * d, y - 13 * d, x + 13 * d, y + 13 * d, p);
                        p.setColor(0xFFFFFFFF);
                        p.setTextAlign(Paint.Align.CENTER);
                        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                        p.setTextSize(14 * d);
                        c.drawText(String.valueOf(l + 1), x, y + 5 * d, p);
                        p.setTextAlign(Paint.Align.LEFT);
                        p.setColor(col);
                        p.setTextSize(12 * d);
                        c.drawText((String) o, x + 26 * d, y + 5 * d, p);
                        minutes = 0;
                        continue;
                    }
                    AppEntry e = (AppEntry) o;
                    minutes += 2;
                    boolean first = i == 1;
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(first ? col : 0xFFFFFFFF);
                    c.drawCircle(x, y, 9 * d, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(4 * d);
                    p.setColor(col);
                    c.drawCircle(x, y, 9 * d, p);
                    p.setStyle(Paint.Style.FILL);
                    Bitmap b = HomeKit.icon(host, e, Math.round(26 * d));
                    c.drawBitmap(b, x + 22 * d, y - 13 * d, null);
                    p.setTypeface(Typeface.create("sans-serif", first ? Typeface.BOLD : Typeface.NORMAL));
                    p.setTextAlign(Paint.Align.LEFT);
                    p.setColor(0xFF1D1D1B);
                    p.setTextSize(17 * d);
                    String name = e.label;
                    float maxW = getWidth() - x - 110 * d;
                    int n = p.breakText(name, true, maxW, null);
                    if (n < name.length()) {
                        name = name.substring(0, Math.max(1, n - 1)) + "…";
                    }
                    c.drawText(name, x + 58 * d, y + 6 * d, p);
                    p.setTextAlign(Paint.Align.RIGHT);
                    p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                    p.setTextSize(13 * d);
                    p.setColor(0xFF8A8A8A);
                    c.drawText(minutes + "'", getWidth() - 18 * d, y + 5 * d, p);
                }
            }
        }
    }

    // ================================================================== CAROUSEL

    /** Big covers in a row that turn in 3D as you swipe, with a mirror below. Tap the middle one to open it. */
    static final class Carousel extends AltHome {
        private final TextView time;
        private final TextView name;
        private final List<AppEntry> apps;
        private final LinearLayout strip;
        private final Flow flow;
        private final int cardW;
        private int centered;

        Carousel(NovaActivity host) {
            super(host);
            apps = appsFor(24);
            cardW = dp(180);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(0, dp(56), 0, 0);
            time = text(clock(), 52f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            col.addView(time);
            TextView d = text(date(), 13f, Theme.DIM);
            col.addView(d);
            flow = new Flow(host);
            flow.setHorizontalScrollBarEnabled(false);
            flow.setOverScrollMode(OVER_SCROLL_NEVER);
            strip = new LinearLayout(host);
            strip.setGravity(Gravity.CENTER_VERTICAL);
            int side = (getResources().getDisplayMetrics().widthPixels - cardW) / 2;
            strip.setPadding(side, 0, side, 0);
            for (int i = 0; i < apps.size(); i++) {
                final int idx = i;
                Cover cv = new Cover(host, apps.get(i));
                cv.setOnClickListener(v -> {
                    if (idx == centered) {
                        host.launch(apps.get(idx));
                    } else {
                        snapTo(idx);
                    }
                });
                cv.setOnLongClickListener(v -> {
                    host.appMenu(apps.get(idx));
                    return true;
                });
                strip.addView(cv, lp(cardW, Math.round(cardW * 1.55f)));
            }
            flow.addView(strip);
            LinearLayout.LayoutParams fp = lp(-1, 0, 1f);
            fp.topMargin = dp(10);
            col.addView(flow, fp);
            name = text("", 18f, Theme.TEXT);
            name.setPadding(0, 0, 0, dp(12));
            col.addView(name);
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            flow.post(this::transform);
        }

        private void snapTo(int i) {
            i = Math.max(0, Math.min(apps.size() - 1, i));
            flow.smoothScrollTo(i * cardW, 0);
        }

        private void transform() {
            float mid = flow.getScrollX() + flow.getWidth() / 2f;
            int best = 0;
            float bestD = Float.MAX_VALUE;
            for (int i = 0; i < strip.getChildCount(); i++) {
                View v = strip.getChildAt(i);
                float c = v.getLeft() + v.getWidth() / 2f;
                float off = (c - mid) / cardW;
                float k = Math.max(-1f, Math.min(1f, off));
                v.setCameraDistance(cardW * 12f);
                v.setRotationY(-k * 55f);
                float s = 1f - Math.min(1f, Math.abs(off)) * 0.22f;
                v.setScaleX(s);
                v.setScaleY(s);
                v.setTranslationX(-Math.signum(off) * Math.min(Math.abs(off), 3f) * cardW * 0.28f);
                v.setTranslationZ(-Math.abs(off) * 10f);
                v.setAlpha(Math.max(0.25f, 1f - Math.abs(off) * 0.22f));
                if (Math.abs(off) < bestD) {
                    bestD = Math.abs(off);
                    best = i;
                }
            }
            centered = best;
            name.setText(apps.isEmpty() ? "Pin some apps" : apps.get(best).label);
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        final class Flow extends HorizontalScrollView {
            private boolean flung;

            Flow(Context c) {
                super(c);
            }

            @Override
            protected void onScrollChanged(int l, int t, int ol, int ot) {
                super.onScrollChanged(l, t, ol, ot);
                transform();
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    flung = false;
                }
                boolean r = super.onTouchEvent(e);
                if ((e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL)
                        && !flung) {
                    post(() -> snapTo(Math.round(getScrollX() / (float) cardW)));
                }
                return r;
            }

            @Override
            public void fling(int vx) {
                flung = true;
                int now = Math.round(getScrollX() / (float) cardW);
                int jump = Math.max(-4, Math.min(4, vx / 2500));
                snapTo(now + (jump == 0 ? Integer.signum(vx) : jump));
            }
        }

        /** One cover: the app colour with its icon, and a faded mirror image underneath. */
        static final class Cover extends View {
            private final AppEntry e;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private Bitmap card;

            Cover(Context c, AppEntry e) {
                super(c);
                this.e = e;
                setClickable(true);
            }

            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                int side = Math.max(1, w - Math.round(16 * getResources().getDisplayMetrics().density));
                card = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
                Canvas k = new Canvas(card);
                int col = HomeKit.color(getContext(), e);
                Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
                q.setShader(new LinearGradient(0, 0, side, side, col, HomeKit.darker(col, 0.45f), Shader.TileMode.CLAMP));
                k.drawRoundRect(new RectF(0, 0, side, side), side * 0.08f, side * 0.08f, q);
                Bitmap ic = HomeKit.icon(getContext(), e, Math.round(side * 0.5f));
                k.drawBitmap(ic, side * 0.25f, side * 0.22f, null);
                q.setShader(null);
                q.setColor(0xFFFFFFFF);
                q.setTextAlign(Paint.Align.CENTER);
                q.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                q.setTextSize(side * 0.085f);
                String t = e.label;
                int n = q.breakText(t, true, side * 0.86f, null);
                k.drawText(n < t.length() ? t.substring(0, Math.max(1, n)) : t, side / 2f, side * 0.88f, q);
            }

            @Override
            protected void onDraw(Canvas c) {
                if (card == null) {
                    return;
                }
                float x = (getWidth() - card.getWidth()) / 2f;
                float y = getHeight() * 0.06f;
                c.drawBitmap(card, x, y, null);
                // the mirror
                c.save();
                float my = y + card.getHeight() * 2 + 4;
                Matrix m = new Matrix();
                m.preScale(1, -1);
                m.postTranslate(x, my);
                p.setAlpha(80);
                c.clipRect(x, y + card.getHeight() + 4, x + card.getWidth(), y + card.getHeight() * 1.45f);
                c.drawBitmap(card, m, p);
                c.restore();
                p.setAlpha(255);
                p.setShader(new LinearGradient(0, y + card.getHeight(), 0, y + card.getHeight() * 1.45f,
                        0x00000000, Theme.BG | 0xFF000000, Shader.TileMode.CLAMP));
                c.drawRect(x - 1, y + card.getHeight() + 2, x + card.getWidth() + 1, y + card.getHeight() * 1.46f, p);
                p.setShader(null);
            }
        }
    }

    // ================================================================== SIDEBAR

    /** A rail of round apps down the left side, and on the right your clock, cards and widgets. */
    static final class Sidebar extends AltHome {
        private final TextView greet;

        Sidebar(NovaActivity host) {
            super(host);
            LinearLayout row = new LinearLayout(host);
            LinearLayout rail = new LinearLayout(host);
            rail.setOrientation(LinearLayout.VERTICAL);
            rail.setGravity(Gravity.CENTER_HORIZONTAL);
            rail.setPadding(0, dp(44), 0, dp(14));
            rail.setBackgroundColor(HomeKit.darker(Theme.PANEL | 0xFF000000, 0.7f));
            TextView logo = text("N", 22f, HomeKit.onColor(Theme.ACCENT));
            logo.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            logo.setGravity(Gravity.CENTER);
            logo.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
            logo.setOnClickListener(v -> host.showOverlay(new ProfileScreen(host)));
            rail.addView(logo, lp(dp(50), dp(50)));
            View sep = new View(host);
            sep.setBackgroundColor(Theme.DIM);
            sep.setAlpha(0.4f);
            LinearLayout.LayoutParams spl = lp(dp(30), dp(2));
            spl.setMargins(0, dp(10), 0, dp(6));
            rail.addView(sep, spl);
            LinearLayout icons = new LinearLayout(host);
            icons.setOrientation(LinearLayout.VERTICAL);
            icons.setGravity(Gravity.CENTER_HORIZONTAL);
            for (AppEntry e : appsFor(16)) {
                icons.addView(railIcon(e), lp(dp(76), dp(62)));
            }
            ScrollView isv = new ScrollView(host);
            isv.setVerticalScrollBarEnabled(false);
            isv.addView(icons);
            rail.addView(isv, lp(-1, 0, 1f));
            rail.addView(round("+", () -> host.showDrawer()), lp(dp(50), dp(50)));
            LinearLayout.LayoutParams gp = lp(dp(50), dp(50));
            gp.topMargin = dp(8);
            rail.addView(round("⚙", () -> host.showSettings()), gp);
            row.addView(rail, lp(dp(76), -1));

            LinearLayout right = new LinearLayout(host);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setPadding(dp(14), dp(44), dp(14), dp(16));
            greet = text(greeting(), 22f, Theme.TEXT);
            greet.setGravity(Gravity.START);
            greet.setTypeface(Theme.LIGHT);
            right.addView(greet);
            TextView d = text(date(), 12f, Theme.DIM);
            d.setGravity(Gravity.START);
            d.setPadding(0, dp(2), 0, dp(14));
            right.addView(d);
            right.addView(card(null, HomeMix.hero(host)), top(0));
            right.addView(card(null, new HomeMix.Mix(host, 280)), top(10));
            List<AppEntry> rec = HomeKit.recent(host, 4);
            if (!rec.isEmpty()) {
                LinearLayout r = new LinearLayout(host);
                for (AppEntry e : rec) {
                    r.addView(appTile(e, 40, true), lp(0, -2, 1f));
                }
                right.addView(card("JUMP BACK IN", r), top(10));
            }
            right.addView(card("SHORTCUTS", shortcuts()), top(10));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(right);
            row.addView(sv, lp(0, -1, 1f));
            addView(row, new FrameLayout.LayoutParams(-1, -1));
        }

        private View shortcuts() {
            LinearLayout r = new LinearLayout(host);
            r.setPadding(0, dp(6), 0, 0);
            String[] n = {"WIDGETS", "TERMINAL", "NOTES"};
            Runnable[] a = {() -> host.showOverlay(new WidgetsSheet(host)), () -> host.showTerminal(), () -> host.showNotes()};
            for (int i = 0; i < n.length; i++) {
                TextView t = chip(n[i], a[i]);
                t.setTextSize(10f);
                t.setBackground(Theme.rounded(Theme.BG2, 14f, host));
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                r.addView(t, p);
            }
            return r;
        }

        private LinearLayout.LayoutParams top(int m) {
            LinearLayout.LayoutParams p = lp(-1, -2);
            p.topMargin = dp(m);
            return p;
        }

        private View round(String s, final Runnable r) {
            TextView t = text(s, 20f, Theme.ACCENT);
            t.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Theme.PANEL);
            t.setBackground(g);
            t.setOnClickListener(v -> r.run());
            press(t);
            return t;
        }

        private View railIcon(final AppEntry e) {
            FrameLayout f = new FrameLayout(host);
            final View pill = new View(host);
            pill.setBackground(Theme.rounded(Theme.TEXT, 4f, host));
            pill.setScaleY(0.3f);
            pill.setAlpha(0f);
            FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(5), dp(36), Gravity.START | Gravity.CENTER_VERTICAL);
            pp.leftMargin = -dp(2);
            f.addView(pill, pp);
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            Upgrades.shapeIcon(iv);
            f.addView(iv, new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER));
            f.setOnTouchListener((v, ev) -> {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    pill.animate().alpha(1f).scaleY(1f).setDuration(120).start();
                } else if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    pill.animate().alpha(0f).scaleY(0.3f).setDuration(200).start();
                }
                return false;
            });
            f.setOnClickListener(v -> host.launch(e));
            f.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            return f;
        }

        @Override
        long tickMs() {
            return 30000;
        }

        @Override
        void tick() {
            greet.setText(greeting());
        }
    }

    // ================================================================== WHEEL

    /** A music player with a click wheel: turn your finger on the wheel to move, press the middle to choose,
     *  MENU to go back. The wheel's buttons also play, pause and skip music. */
    static final class Wheel extends AltHome {
        private final LinearLayout list;
        private final TextView title;
        private final TextView status;
        private final List<String> labels = new ArrayList<>();
        private final List<Runnable> actions = new ArrayList<>();
        private final List<Boolean> subs = new ArrayList<>();
        private int sel;
        private String menu = "NOVA";
        private static final int ROWS = 7;

        Wheel(NovaActivity host) {
            super(host);
            setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xFFF7F7F7, 0xFFD9D9DB}));
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.setPadding(dp(26), dp(48), dp(26), dp(24));
            LinearLayout bezel = new LinearLayout(host);
            bezel.setOrientation(LinearLayout.VERTICAL);
            bezel.setBackground(Theme.rounded(0xFF141414, 12f, host));
            bezel.setPadding(dp(8), dp(8), dp(8), dp(8));
            LinearLayout screen = new LinearLayout(host);
            screen.setOrientation(LinearLayout.VERTICAL);
            screen.setBackgroundColor(0xFFFFFFFF);
            LinearLayout bar = new LinearLayout(host);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xFFFBFBFB, 0xFFC5CBD3}));
            bar.setPadding(dp(8), dp(4), dp(8), dp(4));
            TextView play = sans("▶", 10f, 0xFF2F6FD1, false);
            bar.addView(play, lp(dp(40), -2));
            title = sans("NOVA", 13f, 0xFF111111, true);
            title.setGravity(Gravity.CENTER);
            bar.addView(title, lp(0, -2, 1f));
            status = sans("", 10f, 0xFF333333, false);
            status.setGravity(Gravity.END);
            bar.addView(status, lp(dp(70), -2));
            screen.addView(bar, lp(-1, -2));
            list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            screen.addView(list, lp(-1, dp(ROWS * 30)));
            bezel.addView(screen, lp(-1, -2));
            col.addView(bezel, lp(-1, -2));
            col.addView(new View(host), lp(-1, 0, 1f));
            ClickWheel wheel = new ClickWheel(host);
            int size = Math.min(getResources().getDisplayMetrics().widthPixels - dp(70), dp(290));
            col.addView(wheel, lp(size, size));
            col.addView(new View(host), lp(-1, 0, 0.6f));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            mainMenu();
            tick();
        }

        private TextView sans(String s, float sp, int c, boolean bold) {
            TextView t = text(s, sp, c);
            t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
            t.setSingleLine(true);
            return t;
        }

        private void set(String name, List<String> l, List<Runnable> a, List<Boolean> s) {
            menu = name;
            labels.clear();
            labels.addAll(l);
            actions.clear();
            actions.addAll(a);
            subs.clear();
            subs.addAll(s);
            sel = 0;
            title.setText(name);
            render();
        }

        private void mainMenu() {
            List<String> l = new ArrayList<>();
            List<Runnable> a = new ArrayList<>();
            List<Boolean> s = new ArrayList<>();
            l.add("Pinned");
            a.add(() -> appMenu("Pinned", pinned()));
            s.add(true);
            l.add("All Apps");
            a.add(() -> appMenu("All Apps", new ArrayList<>(host.repo.all)));
            s.add(true);
            l.add("Recent");
            a.add(() -> appMenu("Recent", HomeKit.recent(host, 12)));
            s.add(true);
            l.add("Music");
            a.add(this::musicMenu);
            s.add(true);
            l.add("Widgets");
            a.add(() -> host.showOverlay(new WidgetsSheet(host)));
            s.add(false);
            l.add("Notes");
            a.add(() -> host.showNotes());
            s.add(false);
            l.add("Terminal");
            a.add(() -> host.showTerminal());
            s.add(false);
            l.add("Settings");
            a.add(() -> host.showSettings());
            s.add(false);
            set("NOVA", l, a, s);
        }

        private void musicMenu() {
            List<String> l = new ArrayList<>();
            List<Runnable> a = new ArrayList<>();
            List<Boolean> s = new ArrayList<>();
            l.add("Play / Pause");
            a.add(() -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
            s.add(false);
            l.add("Next");
            a.add(() -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_NEXT));
            s.add(false);
            l.add("Previous");
            a.add(() -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PREVIOUS));
            s.add(false);
            set("Music", l, a, s);
        }

        private void appMenu(String name, List<AppEntry> apps) {
            List<String> l = new ArrayList<>();
            List<Runnable> a = new ArrayList<>();
            List<Boolean> s = new ArrayList<>();
            for (final AppEntry e : apps) {
                l.add(e.label);
                a.add(() -> host.launch(e));
                s.add(false);
            }
            if (apps.isEmpty()) {
                l.add("(empty)");
                a.add(() -> { });
                s.add(false);
            }
            set(name, l, a, s);
        }

        private void render() {
            list.removeAllViews();
            int first = Math.max(0, Math.min(sel - ROWS / 2, labels.size() - ROWS));
            for (int i = first; i < Math.min(labels.size(), first + ROWS); i++) {
                final int idx = i;
                boolean on = i == sel;
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(8), 0, dp(8), 0);
                if (on) {
                    r.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                            new int[] {0xFF6AAEF0, 0xFF2F6FD1}));
                }
                TextView t = sans(labels.get(i), 14f, on ? 0xFFFFFFFF : 0xFF111111, on);
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                r.addView(t, lp(0, -2, 1f));
                if (subs.get(i)) {
                    r.addView(sans("›", 16f, on ? 0xFFFFFFFF : 0xFF8A8A8A, true));
                }
                r.setOnClickListener(v -> {
                    sel = idx;
                    select();
                });
                list.addView(r, lp(-1, dp(30)));
            }
        }

        private void step(int d) {
            if (labels.isEmpty()) {
                return;
            }
            int n = Math.max(0, Math.min(labels.size() - 1, sel + d));
            if (n != sel) {
                sel = n;
                host.buzz(3);
                render();
            }
        }

        private void select() {
            if (sel >= 0 && sel < actions.size()) {
                actions.get(sel).run();
            }
        }

        private void back() {
            if (!"NOVA".equals(menu)) {
                mainMenu();
            }
        }

        @Override
        void tick() {
            status.setText(clock() + "  ▮" + battery());
        }

        /** The wheel: drag around it to scroll, tap MENU / play / skip, press the centre to choose. */
        final class ClickWheel extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float lastAngle;
            private float acc;
            private float travel;
            private boolean inCenter;
            private boolean pressedCenter;
            private float downX;
            private float downY;

            ClickWheel(Context c) {
                super(c);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            }

            private float angle(float x, float y) {
                return (float) Math.toDegrees(Math.atan2(y - getHeight() / 2f, x - getWidth() / 2f));
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy);
                float dist = (float) Math.hypot(e.getX() - cx, e.getY() - cy);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (dist > r) {
                            return false;
                        }
                        inCenter = dist < r * 0.36f;
                        pressedCenter = inCenter;
                        lastAngle = angle(e.getX(), e.getY());
                        acc = 0;
                        travel = 0;
                        downX = e.getX();
                        downY = e.getY();
                        getParent().requestDisallowInterceptTouchEvent(true);
                        invalidate();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (inCenter) {
                            return true;
                        }
                        float a = angle(e.getX(), e.getY());
                        float da = a - lastAngle;
                        if (da > 180) {
                            da -= 360;
                        } else if (da < -180) {
                            da += 360;
                        }
                        lastAngle = a;
                        acc += da;
                        travel += Math.abs(da);
                        while (acc > 22) {
                            acc -= 22;
                            step(1);
                        }
                        while (acc < -22) {
                            acc += 22;
                            step(-1);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        pressedCenter = false;
                        invalidate();
                        if (inCenter) {
                            host.buzz(8);
                            select();
                        } else if (travel < 10 && Math.hypot(e.getX() - downX, e.getY() - downY) < dp(14)) {
                            float dx = e.getX() - cx;
                            float dy = e.getY() - cy;
                            host.buzz(8);
                            if (Math.abs(dy) > Math.abs(dx)) {
                                if (dy < 0) {
                                    back();
                                } else {
                                    HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
                                }
                            } else if (dx > 0) {
                                HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_NEXT);
                            } else {
                                HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PREVIOUS);
                            }
                        }
                        return true;
                    default:
                        pressedCenter = false;
                        invalidate();
                        return true;
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - 2;
                float d = getResources().getDisplayMetrics().density;
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, cy - r, 0, cy + r, 0xFFFFFFFF, 0xFFE4E4E6, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, r, p);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.2f * d);
                p.setColor(0xFFBDBDC2);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFA4A4AA);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(15 * d);
                c.drawText("MENU", cx, cy - r * 0.68f, p);
                p.setTextSize(18 * d);
                c.drawText("⏭", cx + r * 0.7f, cy + 6 * d, p);
                c.drawText("⏮", cx - r * 0.7f, cy + 6 * d, p);
                c.drawText("⏯", cx, cy + r * 0.76f, p);
                p.setShader(new LinearGradient(0, cy - r * 0.34f, 0, cy + r * 0.34f,
                        pressedCenter ? 0xFFD8D8DC : 0xFFF4F4F6, pressedCenter ? 0xFFC4C4C8 : 0xFFDDDDE1, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, r * 0.34f, p);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(0xFFC8C8CC);
                c.drawCircle(cx, cy, r * 0.34f, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
    }

    // ================================================================== RADIO

    /** An old radio: drag the dial (or the knob) to tune, each app is a station. When it's tuned in, press PLAY. */
    static final class Radio extends AltHome {
        private final List<AppEntry> apps;
        private final Dial dial;
        private final TextView display;
        private final TextView clockL;
        private final Meter meter;

        Radio(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF1A110A);
            apps = appsFor(20);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), dp(46), dp(14), dp(16));
            LinearLayout body = new LinearLayout(host);
            body.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable wood = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[] {0xFF7A4E2D, 0xFF5A3720, 0xFF3E2414});
            wood.setCornerRadius(dp(26));
            body.setBackground(wood);
            body.setPadding(dp(16), dp(18), dp(16), dp(18));

            TextView brand = text("NOVA  ·  Sensation 26", 12f, 0xFFE8D2A8);
            brand.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
            brand.setPadding(0, 0, 0, dp(10));
            body.addView(brand);
            dial = new Dial(host);
            body.addView(dial, lp(-1, dp(110)));

            LinearLayout mid = new LinearLayout(host);
            mid.setGravity(Gravity.CENTER_VERTICAL);
            mid.setPadding(0, dp(14), 0, dp(14));
            LinearLayout glass = new LinearLayout(host);
            glass.setOrientation(LinearLayout.VERTICAL);
            glass.setBackground(Theme.rounded(0xFF140E08, 10f, host));
            glass.setPadding(dp(12), dp(8), dp(12), dp(8));
            display = text("", 15f, 0xFFFFB347);
            display.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            display.setGravity(Gravity.START);
            display.setSingleLine(true);
            display.setEllipsize(android.text.TextUtils.TruncateAt.END);
            glass.addView(display, lp(-1, -2));
            meter = new Meter(host);
            glass.addView(meter, lp(-1, dp(14)));
            mid.addView(glass, lp(0, -2, 1f));
            Knob knob = new Knob(host);
            LinearLayout.LayoutParams kp = lp(dp(84), dp(84));
            kp.leftMargin = dp(12);
            mid.addView(knob, kp);
            body.addView(mid, lp(-1, -2));

            body.addView(new Grille(host), lp(-1, 0, 1f));
            clockL = text(clock(), 34f, 0xFFFFB347);
            clockL.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            clockL.setBackground(Theme.rounded(0xFF140E08, 10f, host));
            clockL.setPadding(dp(14), dp(2), dp(14), dp(2));
            LinearLayout.LayoutParams cp = lp(-2, -2);
            cp.gravity = Gravity.CENTER_HORIZONTAL;
            cp.topMargin = dp(12);
            body.addView(clockL, cp);

            LinearLayout keys = new LinearLayout(host);
            keys.setPadding(0, dp(14), 0, 0);
            keys.addView(ivory("ALL", () -> host.showDrawer()), lp(0, dp(56), 1f));
            keys.addView(ivory("WIDGET", () -> host.showOverlay(new WidgetsSheet(host))), lp(0, dp(56), 1f));
            keys.addView(ivory("SETUP", () -> host.showSettings()), lp(0, dp(56), 1f));
            View playKey = ivory("▶ PLAY", () -> {
                AppEntry e = dial.tuned();
                if (e != null && dial.signal() > 0.55f) {
                    host.launch(e);
                } else {
                    host.toast("Only static here. Turn the dial to a station.");
                }
            });
            keys.addView(playKey, lp(0, dp(56), 1.4f));
            body.addView(keys, lp(-1, -2));
            col.addView(body, lp(-1, -1));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            update();
        }

        private View ivory(String s, final Runnable r) {
            TextView t = text(s, 10f, 0xFF3A2414);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            t.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[] {0xFFFFF8E6, 0xFFE6D9BC});
            g.setCornerRadii(new float[] {dp(3), dp(3), dp(3), dp(3), dp(8), dp(8), dp(8), dp(8)});
            g.setStroke(dp(1), 0xFF8A6A48);
            t.setBackground(g);
            t.setOnClickListener(v -> {
                host.buzz(10);
                v.animate().translationY(dp(4)).setDuration(60).withEndAction(() ->
                        v.animate().translationY(0).setDuration(120).start()).start();
                r.run();
            });
            LinearLayout.LayoutParams p = lp(0, dp(56), 1f);
            p.setMargins(dp(3), 0, dp(3), 0);
            t.setLayoutParams(p);
            return t;
        }

        private void update() {
            AppEntry e = dial.tuned();
            float sig = dial.signal();
            String f = String.format(Locale.US, "FM %5.1f", dial.freq());
            display.setText(e == null || sig < 0.3f ? f + "   ~ ~ ~" : f + "  ♪ " + e.label);
            meter.set(sig);
        }

        @Override
        void tick() {
            clockL.setText(clock());
        }

        /** The tuning scale: frequencies and station names slide under a fixed red needle. */
        final class Dial extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final float d;
            private final float spacing;
            private float offset;
            private float lastX;
            private float downX;
            private boolean moved;
            private android.animation.ValueAnimator snap;

            Dial(Context c) {
                super(c);
                d = getResources().getDisplayMetrics().density;
                spacing = 110 * d;
            }

            float length() {
                return Math.max(1, (apps.size() + 1) * spacing);
            }

            float freq() {
                return 88f + 20f * (offset + spacing) / length();
            }

            private float pos(int i) {
                return (i + 1) * spacing;
            }

            AppEntry tuned() {
                if (apps.isEmpty()) {
                    return null;
                }
                int i = Math.round(offset / spacing);
                return apps.get(Math.max(0, Math.min(apps.size() - 1, i)));
            }

            float signal() {
                if (apps.isEmpty()) {
                    return 0f;
                }
                float k = offset / spacing;
                float off = Math.abs(k - Math.round(k));
                return Math.max(0f, 1f - off * 2.4f);
            }

            void nudge(float px) {
                if (snap != null) {
                    snap.cancel();
                }
                offset = Math.max(0, Math.min((apps.size() - 1) * spacing, offset + px));
                invalidate();
                update();
            }

            void settle() {
                float target = Math.round(offset / spacing) * spacing;
                snap = android.animation.ValueAnimator.ofFloat(offset, target);
                snap.setDuration(260);
                snap.addUpdateListener(a -> {
                    offset = (float) a.getAnimatedValue();
                    invalidate();
                    update();
                });
                snap.start();
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = downX = e.getX();
                        moved = false;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getX() - downX) > ViewConfiguration.get(getContext()).getScaledTouchSlop()) {
                            moved = true;
                        }
                        nudge(lastX - e.getX());
                        lastX = e.getX();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            // tap on a station name: tune straight to it
                            float x = offset + (e.getX() - getWidth() / 2f);
                            nudge(Math.round(x / spacing) * spacing - offset);
                        }
                        settle();
                        return true;
                    default:
                        settle();
                        return true;
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, 0xFFF6EBD0, 0xFFE2D1A8, Shader.TileMode.CLAMP));
                c.drawRoundRect(new RectF(0, 0, w, h), 10 * d, 10 * d, p);
                p.setShader(null);
                float cx = w / 2f;
                float base = h * 0.62f;
                p.setColor(0xFF4A3420);
                p.setStrokeWidth(1.2f * d);
                // little ticks every 0.2 MHz worth of scale
                float len = length();
                float px = len / 100f;
                for (int i = 0; i <= 100; i++) {
                    float x = cx + i * px - spacing - offset;
                    if (x < -10 || x > w + 10) {
                        continue;
                    }
                    float tk = i % 10 == 0 ? 16 * d : i % 5 == 0 ? 11 * d : 6 * d;
                    c.drawLine(x, base, x, base + tk, p);
                    if (i % 10 == 0) {
                        p.setTextAlign(Paint.Align.CENTER);
                        p.setTextSize(10 * d);
                        p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                        c.drawText(String.valueOf(88 + i / 5), x, base + 28 * d, p);
                    }
                }
                c.drawLine(0, base, w, base, p);
                p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
                p.setTextSize(12 * d);
                for (int i = 0; i < apps.size(); i++) {
                    float x = cx + pos(i) - spacing - offset;
                    if (x < -spacing || x > w + spacing) {
                        continue;
                    }
                    String n = apps.get(i).label;
                    if (n.length() > 12) {
                        n = n.substring(0, 11) + "…";
                    }
                    p.setColor(0xFF3A2414);
                    p.setTextAlign(Paint.Align.CENTER);
                    c.save();
                    c.rotate(-18f, x, base - 14 * d);
                    c.drawText(n, x, base - 14 * d, p);
                    c.restore();
                    p.setColor(0xFFB33A2A);
                    c.drawCircle(x, base - 4 * d, 2.5f * d, p);
                }
                // the needle, with a soft glow behind
                p.setColor(0x40FF5A3A);
                c.drawRect(cx - 6 * d, 4 * d, cx + 6 * d, h - 4 * d, p);
                p.setColor(0xFFD83A1E);
                c.drawRect(cx - 1.5f * d, 4 * d, cx + 1.5f * d, h - 4 * d, p);
                // shading at the sides, like glass over a curved scale
                p.setShader(new LinearGradient(0, 0, w * 0.18f, 0, 0x66000000, 0x00000000, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w * 0.18f, h, p);
                p.setShader(new LinearGradient(w, 0, w * 0.82f, 0, 0x66000000, 0x00000000, Shader.TileMode.CLAMP));
                c.drawRect(w * 0.82f, 0, w, h, p);
                p.setShader(null);
            }
        }

        /** The tuning knob: turn it to move the dial. */
        final class Knob extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float rot;
            private float last;

            Knob(Context c) {
                super(c);
            }

            private float angle(MotionEvent e) {
                return (float) Math.toDegrees(Math.atan2(e.getY() - getHeight() / 2f, e.getX() - getWidth() / 2f));
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        last = angle(e);
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float a = angle(e);
                        float da = a - last;
                        if (da > 180) {
                            da -= 360;
                        } else if (da < -180) {
                            da += 360;
                        }
                        last = a;
                        rot += da;
                        dial.nudge(da * 1.6f * getResources().getDisplayMetrics().density);
                        invalidate();
                        return true;
                    }
                    default:
                        dial.settle();
                        return true;
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - 2;
                p.setShader(new LinearGradient(0, 0, 0, getHeight(), 0xFFE9DCC0, 0xFF9C8664, Shader.TileMode.CLAMP));
                c.drawCircle(cx, cy, r, p);
                p.setShader(null);
                p.setColor(0xFF6A5638);
                for (int i = 0; i < 24; i++) {
                    double a = Math.toRadians(rot + i * 15);
                    c.drawCircle(cx + (float) Math.cos(a) * (r - 4), cy + (float) Math.sin(a) * (r - 4), 2.2f, p);
                }
                p.setColor(0xFFD8C7A2);
                c.drawCircle(cx, cy, r * 0.62f, p);
                p.setColor(0xFF3A2414);
                double a = Math.toRadians(rot - 90);
                p.setStrokeWidth(4);
                c.drawLine(cx + (float) Math.cos(a) * r * 0.2f, cy + (float) Math.sin(a) * r * 0.2f,
                        cx + (float) Math.cos(a) * r * 0.55f, cy + (float) Math.sin(a) * r * 0.55f, p);
            }
        }

        /** Signal strength bars under the station name. */
        static final class Meter extends View {
            private float v;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Meter(Context c) {
                super(c);
            }

            void set(float v) {
                this.v = v;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                int n = 16;
                float bw = getWidth() / (float) n;
                for (int i = 0; i < n; i++) {
                    p.setColor(i < Math.round(v * n) ? (i > 12 ? 0xFFFF6A3A : 0xFFFFB347) : 0xFF3A2A18);
                    c.drawRect(i * bw + 1, getHeight() * 0.3f, (i + 1) * bw - 2, getHeight() * 0.85f, p);
                }
            }
        }

        /** The speaker cloth with rows of little holes. */
        static final class Grille extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Grille(Context c) {
                super(c);
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                p.setColor(0xFF2A1A0E);
                c.drawRoundRect(new RectF(0, 0, getWidth(), getHeight()), 14 * d, 14 * d, p);
                p.setColor(0xFF4A3220);
                float g = 9 * d;
                int row = 0;
                for (float y = g; y < getHeight() - g / 2; y += g * 0.87f) {
                    for (float x = g + (row % 2) * g / 2; x < getWidth() - g / 2; x += g) {
                        c.drawCircle(x, y, 2.4f * d, p);
                    }
                    row++;
                }
            }
        }
    }

    // ================================================================== MASONRY

    /** A wall of cards in two columns, each a different height and in the app's own colour, like a pin board. */
    static final class Masonry extends AltHome {
        private final TextView time;
        private final TextView dateL;
        private final TextView batt;

        Masonry(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(10), dp(44), dp(10), dp(16));
            TextView search = text("⌕  Search your apps", 13f, Theme.DIM);
            search.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            search.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
            search.setPadding(dp(18), dp(13), dp(18), dp(13));
            search.setOnClickListener(v -> host.showDrawer());
            LinearLayout.LayoutParams sp = lp(-1, -2);
            sp.setMargins(dp(4), 0, dp(4), dp(10));
            col.addView(search, sp);

            LinearLayout two = new LinearLayout(host);
            LinearLayout a = new LinearLayout(host);
            a.setOrientation(LinearLayout.VERTICAL);
            LinearLayout b = new LinearLayout(host);
            b.setOrientation(LinearLayout.VERTICAL);
            two.addView(a, lp(0, -2, 1f));
            two.addView(b, lp(0, -2, 1f));
            int ha = 0;
            int hb = 0;

            LinearLayout clockCard = new LinearLayout(host);
            clockCard.setOrientation(LinearLayout.VERTICAL);
            clockCard.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
            clockCard.setPadding(dp(16), dp(16), dp(16), dp(16));
            time = text(clock(), 44f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            time.setGravity(Gravity.START);
            clockCard.addView(time);
            dateL = text(date(), 12f, Theme.DIM);
            dateL.setGravity(Gravity.START);
            clockCard.addView(dateL);
            batt = text("", 11f, Theme.ACCENT);
            batt.setGravity(Gravity.START);
            batt.setPadding(0, dp(10), 0, 0);
            clockCard.addView(batt);
            clockCard.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            a.addView(clockCard, cardLp(-2));
            ha += 160;

            for (AppEntry e : appsFor(18)) {
                int h = 120 + (Math.abs(e.pkg.hashCode()) % 4) * 30;
                if (ha <= hb) {
                    a.addView(appCard(e), cardLp(dp(h)));
                    ha += h + 10;
                } else {
                    b.addView(appCard(e), cardLp(dp(h)));
                    hb += h + 10;
                }
            }
            col.addView(two, lp(-1, -2));
            LinearLayout links = new LinearLayout(host);
            links.setPadding(0, dp(10), 0, 0);
            String[] n = {"ALL APPS", "PROFILE", "TERMINAL", "SETTINGS"};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new ProfileScreen(host)), () -> host.showTerminal(),
                () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = chip(n[i], r[i]);
                t.setTextSize(9.5f);
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(3), 0, dp(3), 0);
                links.addView(t, p);
            }
            col.addView(links, lp(-1, -2));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private LinearLayout.LayoutParams cardLp(int h) {
            LinearLayout.LayoutParams p = lp(-1, h);
            p.setMargins(dp(4), dp(4), dp(4), dp(6));
            return p;
        }

        private View appCard(final AppEntry e) {
            int c = HomeKit.color(host, e);
            FrameLayout f = new FrameLayout(host);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[] {c, HomeKit.darker(c, 0.62f)});
            g.setCornerRadius(dp(22));
            f.setBackground(g);
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.START);
            ip.setMargins(dp(14), dp(14), 0, 0);
            f.addView(iv, ip);
            LinearLayout bottom = new LinearLayout(host);
            bottom.setOrientation(LinearLayout.VERTICAL);
            TextView n = text(e.label, 15f, HomeKit.onColor(HomeKit.darker(c, 0.62f)));
            n.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            n.setGravity(Gravity.START);
            n.setMaxLines(2);
            n.setEllipsize(android.text.TextUtils.TruncateAt.END);
            bottom.addView(n);
            TextView o = text("open ›", 10f, HomeKit.onColor(HomeKit.darker(c, 0.62f)));
            o.setAlpha(0.75f);
            o.setGravity(Gravity.START);
            bottom.addView(o);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            bp.setMargins(dp(14), 0, dp(10), dp(12));
            f.addView(bottom, bp);
            f.setOnClickListener(v -> host.launch(e));
            f.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            press(f);
            return f;
        }

        @Override
        void tick() {
            time.setText(clock());
            dateL.setText(date());
            batt.setText(battery() + "% battery  ·  " + new SimpleDateFormat("'week' w", Locale.getDefault()).format(new Date()));
        }
    }
}
