package app.novaos;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Optional. When switched on in Android's Accessibility settings, the deck's mouse can float above every app and tap
 * what is under it. It asks for no event access and no screen reading: it only draws the cursor and performs the
 * taps that a deck pad asks for.
 */
public class MouseService extends AccessibilityService {
    static volatile MouseService instance;

    private WindowManager wm;
    private CursorView cursor;
    private WindowManager.LayoutParams lp;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // NOVA never reads events
    }

    @Override
    public void onInterrupt() {
        // nothing to interrupt
    }

    @Override
    public boolean onUnbind(Intent intent) {
        hide();
        instance = null;
        DeckMouse.serviceGone();
        return super.onUnbind(intent);
    }

    void show(float x, float y) {
        if (wm == null) {
            return;
        }
        hide();
        cursor = new CursorView(this);
        int s = cursor.size();
        lp = new WindowManager.LayoutParams(s, s, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Math.round(x - s / 2f);
        lp.y = Math.round(y - s / 2f);
        try {
            wm.addView(cursor, lp);
        } catch (Exception e) {
            cursor = null;
        }
    }

    void move(float x, float y) {
        if (cursor == null || lp == null) {
            return;
        }
        int s = cursor.size();
        lp.x = Math.round(x - s / 2f);
        lp.y = Math.round(y - s / 2f);
        try {
            wm.updateViewLayout(cursor, lp);
        } catch (Exception ignored) {
            // the window went away
        }
    }

    void hide() {
        if (cursor != null && wm != null) {
            try {
                wm.removeView(cursor);
            } catch (Exception ignored) {
                // already removed
            }
        }
        cursor = null;
    }

    void tap(float x, float y) {
        if (cursor != null) {
            cursor.pulse();
        }
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 40)).build();
        dispatchGesture(g, null, null);
    }
}
