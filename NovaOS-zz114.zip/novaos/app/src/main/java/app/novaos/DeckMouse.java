package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Mouse mode for the launch deck. The bottom-right 3 x 3 pads become a mouse pad: arrows move a round cursor (hold to
 * go faster), the middle pad centres it, the two top corner pads tap, the bottom-right pad opens the mouse and the
 * bottom-left pad closes it.
 *
 * With the optional NOVA mouse accessibility service switched on in Android, the cursor floats above every app and
 * the tap really taps what is under it. Without it the cursor lives inside NOVA and taps NOVA's own screens.
 */
final class DeckMouse {
    private DeckMouse() {}

    static boolean on;
    /** Told whenever the mouse opens or closes, so the pad colours can change. */
    static Runnable listener;

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static NovaActivity host;
    private static CursorView inApp;
    private static float x = -1f;
    private static float y = -1f;
    private static int sw;
    private static int sh;
    private static float density = 3f;
    private static final boolean[] DIR = new boolean[4]; // up, down, left, right
    private static boolean running;
    private static long heldSince;
    private static long lastTick;

    private static final Runnable LOOP = new Runnable() {
        @Override
        public void run() {
            if (!on || !(DIR[0] || DIR[1] || DIR[2] || DIR[3])) {
                running = false;
                return;
            }
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(50L, now - lastTick) / 1000f;
            lastTick = now;
            // starts slow for exact aiming, speeds up the longer you hold
            float speed = density * (90f + Math.min(900f, (now - heldSince) * 0.7f));
            float dx = ((DIR[3] ? 1 : 0) - (DIR[2] ? 1 : 0)) * speed * dt;
            float dy = ((DIR[1] ? 1 : 0) - (DIR[0] ? 1 : 0)) * speed * dt;
            moveBy(dx, dy);
            ui.postDelayed(this, 16);
        }
    };

    static boolean everywhere() {
        return MouseService.instance != null;
    }

    private static void changed() {
        DeckMidi.lightAll();
        Runnable l = listener;
        if (l != null) {
            ui.post(l);
        }
    }

    // ------------------------------------------------------------------ pad presses

    /** A mouse pad went down. type is one of the m_ bind types. */
    static void press(NovaActivity h, String type) {
        host = h;
        DisplayMetrics dm = new DisplayMetrics();
        h.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;
        density = dm.density;
        if (type.equals("m_open")) {
            open(h);
            return;
        }
        if (!on) {
            h.toast("Press the bottom-right pad of the mouse first to open it");
            return;
        }
        switch (type) {
            case "m_close":
                close();
                break;
            case "m_center":
                x = sw / 2f;
                y = sh / 2f;
                place();
                break;
            case "m_tap":
                tap();
                break;
            case "m_up":
                hold(0, true);
                break;
            case "m_down":
                hold(1, true);
                break;
            case "m_left":
                hold(2, true);
                break;
            case "m_right":
                hold(3, true);
                break;
            default:
                break;
        }
    }

    /** A mouse pad came up. */
    static void release(String type) {
        switch (type) {
            case "m_up":
                hold(0, false);
                break;
            case "m_down":
                hold(1, false);
                break;
            case "m_left":
                hold(2, false);
                break;
            case "m_right":
                hold(3, false);
                break;
            default:
                break;
        }
    }

    static void releaseAll() {
        for (int i = 0; i < 4; i++) {
            DIR[i] = false;
        }
    }

    private static void hold(int dir, boolean down) {
        DIR[dir] = down;
        if (down && !running) {
            running = true;
            heldSince = SystemClock.uptimeMillis();
            lastTick = heldSince;
            // a quick press still moves a little, straight away
            moveBy(dir == 2 ? -density * 6f : dir == 3 ? density * 6f : 0f,
                    dir == 0 ? -density * 6f : dir == 1 ? density * 6f : 0f);
            ui.post(LOOP);
        }
    }

    // ------------------------------------------------------------------ open, close, move, tap

    private static void open(NovaActivity h) {
        if (on) {
            h.toast("The mouse is already open");
            return;
        }
        on = true;
        if (x < 0f || y < 0f) {
            x = sw / 2f;
            y = sh / 2f;
        }
        MouseService svc = MouseService.instance;
        if (svc != null) {
            svc.show(x, y);
        } else {
            showInApp();
            hintOnce();
        }
        changed();
    }

    static void close() {
        if (!on) {
            return;
        }
        on = false;
        releaseAll();
        MouseService svc = MouseService.instance;
        if (svc != null) {
            svc.hide();
        }
        if (inApp != null && host != null) {
            host.root.removeView(inApp);
            inApp = null;
        }
        changed();
    }

    /** The accessibility service was switched off while the mouse was open. */
    static void serviceGone() {
        ui.post(DeckMouse::close);
    }

    private static void showInApp() {
        if (host == null || host.root == null) {
            return;
        }
        inApp = new CursorView(host);
        inApp.setTag(NovaActivity.KEEP);
        int s = inApp.size();
        host.root.addView(inApp, new FrameLayout.LayoutParams(s, s));
        host.keepOnTop();
        place();
    }

    private static void moveBy(float dx, float dy) {
        x = Math.max(0f, Math.min(sw, x + dx));
        y = Math.max(0f, Math.min(sh, y + dy));
        place();
    }

    private static void place() {
        MouseService svc = MouseService.instance;
        if (svc != null) {
            svc.move(x, y);
        } else if (inApp != null) {
            int s = inApp.size();
            inApp.setTranslationX(x - s / 2f);
            inApp.setTranslationY(y - s / 2f);
        }
    }

    private static void tap() {
        MouseService svc = MouseService.instance;
        if (svc != null) {
            svc.tap(x, y);
            return;
        }
        if (inApp == null || host == null) {
            return;
        }
        inApp.pulse();
        final NovaActivity h = host;
        final float px = x;
        final float py = y;
        final long t = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, px, py, 0);
        h.dispatchTouchEvent(down);
        down.recycle();
        ui.postDelayed(() -> {
            MotionEvent up = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, px, py, 0);
            h.dispatchTouchEvent(up);
            up.recycle();
        }, 50);
    }

    /** Says once what the optional service does, with a button to the Android screen where it is switched on. */
    private static void hintOnce() {
        if (host == null || Prefs.getBool("mouse_hint", false)) {
            return;
        }
        Prefs.putBool("mouse_hint", true);
        final NovaActivity h = host;
        new AlertDialog.Builder(h).setTitle("Mouse over other apps?")
                .setMessage("Right now the mouse only works inside NOVA.\n\nTo move it over other apps and tap them, "
                        + "switch on \"NOVA mouse\" in Android's Accessibility settings. It only draws the cursor and "
                        + "taps where you press a pad. It does not read your screen or what you type.\n\n"
                        + "You can skip this and keep using the mouse inside NOVA.")
                .setPositiveButton("OPEN ACCESSIBILITY SETTINGS", (d, w) -> openAccessibilitySettings(h))
                .setNegativeButton("Just NOVA", null).show();
    }

    static void openAccessibilitySettings(NovaActivity h) {
        try {
            h.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            h.toast("Open Settings > Accessibility > NOVA mouse");
        }
    }
}

/** The round cursor: white with a black edge. */
final class CursorView extends View {
    static final float SIZE_DP = 36f;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float stroke;
    private final int size;

    CursorView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        size = Math.round(SIZE_DP * d);
        stroke = 3f * d;
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        edge.setColor(0xFF000000);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(stroke);
        setClickable(false);
        setFocusable(false);
    }

    int size() {
        return size;
    }

    @Override
    protected void onDraw(Canvas c) {
        float r = Math.min(getWidth(), getHeight()) / 2f - stroke;
        c.drawCircle(getWidth() / 2f, getHeight() / 2f, r, fill);
        c.drawCircle(getWidth() / 2f, getHeight() / 2f, r, edge);
    }

    /** A small squeeze when it taps. */
    void pulse() {
        animate().scaleX(0.7f).scaleY(0.7f).setDuration(70)
                .withEndAction(() -> animate().scaleX(1f).scaleY(1f).setDuration(110).start()).start();
    }
}
