package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * No camera: a flat picture of the horizon around you. Every peak is a stick standing in the ground at its direction,
 * as tall as it looks (its angle above the horizon), with its name, height and distance. Turn the phone and the picture
 * follows the compass; drag to look around by hand; pinch to see more or less of the circle (down to all 360 degrees).
 */
final class PeakSticks extends View implements SensorEventListener {
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SensorManager sm;
    private final float[] rot = new float[9];
    private final ScaleGestureDetector pinch;
    private final GestureDetector gestures;
    private final List<PeakData.Peak> hit = new ArrayList<>();
    private final List<RectF> hitBox = new ArrayList<>();
    private float heading;          // degrees from north in the middle of the picture
    private boolean haveSensor;
    private boolean manual;
    private float fov = 100f;       // degrees shown across the width
    PeakData.Peak selected;
    PeakMapView.Pick listener;

    PeakSticks(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        pinch = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector g) {
                fov = Math.max(30f, Math.min(360f, fov / g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                manual = true;
                heading = (heading + dx / Math.max(1, getWidth()) * fov + 360f) % 360f;
                invalidate();
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                tap(e.getX(), e.getY());
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                manual = false; // follow the compass again
                return true;
            }
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (sm != null) {
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (s != null) {
                sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sm != null) {
            sm.unregisterListener(this);
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(rot, e.values);
        // held upright the back of the phone points where the camera would look; flat on a table the top edge is used
        double ce = -rot[2];
        double cn = -rot[5];
        double up = -rot[8];
        double te = rot[1];
        double tn = rot[4];
        boolean upright = Math.abs(up) < 0.7;
        float h = (float) ((Math.toDegrees(Math.atan2(upright ? ce : te, upright ? cn : tn)) + declination() + 720.0) % 360.0);
        haveSensor = true;
        if (!manual) {
            float diff = ((h - heading + 540f) % 360f) - 180f;
            heading = (heading + diff * 0.18f + 360f) % 360f;
            invalidate();
        }
    }

    private double declination() {
        if (!PeakData.have) {
            return 0;
        }
        try {
            return new android.hardware.GeomagneticField((float) PeakData.myLat, (float) PeakData.myLon,
                    (float) PeakData.myAlt(), System.currentTimeMillis()).getDeclination();
        } catch (RuntimeException e) {
            return 0;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private float xFor(double bearing, int w) {
        double diff = ((bearing - heading + 540.0) % 360.0) - 180.0;
        return (float) (w / 2.0 + diff / fov * w);
    }

    @Override
    protected void onDraw(Canvas cv) {
        try {
            paint(cv);
        } catch (RuntimeException e) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(12 * d);
            cv.drawText("Could not draw: " + e.getClass().getSimpleName(), 12 * d, 40 * d, p);
        }
    }

    private void paint(Canvas cv) {
        int w = getWidth();
        int h = getHeight();
        hit.clear();
        hitBox.clear();
        float ground = h * 0.80f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33000000);
        cv.drawRoundRect(new RectF(0, 0, w, h), 14 * d, 14 * d, p);
        p.setColor(0x44FFFFFF);
        cv.drawRect(0, ground, w, h, p);

        // compass marks along the ground
        String[] n8 = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        p.setTextAlign(Paint.Align.CENTER);
        for (int a = 0; a < 360; a += 15) {
            float x = xFor(a, w);
            if (x < -20 || x > w + 20) {
                continue;
            }
            boolean main = a % 45 == 0;
            p.setColor(a == 0 ? 0xFFFF6B6B : 0xAAFFFFFF);
            p.setStrokeWidth(d);
            cv.drawLine(x, ground, x, ground + (main ? 10 : 5) * d, p);
            if (main) {
                p.setTextSize(13 * d);
                cv.drawText(n8[a / 45], x, ground + 26 * d, p);
            } else if (fov <= 120f) {
                p.setTextSize(9 * d);
                p.setColor(0x88FFFFFF);
                cv.drawText(String.valueOf(a), x, ground + 22 * d, p);
            }
        }

        List<PeakData.Peak> list;
        synchronized (PeakData.peaks) {
            list = new ArrayList<>(PeakData.peaks);
        }
        double maxUp = 8;
        for (PeakData.Peak pk : list) {
            if (pk.dist <= PeakData.km * 1000.0) {
                maxUp = Math.max(maxUp, pk.up);
            }
        }
        float pxPerDeg = (float) ((ground - 52 * d) / maxUp);
        // sticks, nearest/highest drawn on top; labels do not overlap
        list.sort((a, b) -> Double.compare(a.up + a.ele / 8000.0, b.up + b.ele / 8000.0));
        List<RectF> used = new ArrayList<>();
        p.setTextAlign(Paint.Align.LEFT);
        // names for the most striking peaks first
        List<PeakData.Peak> byRank = new ArrayList<>(list);
        java.util.Collections.reverse(byRank);
        for (PeakData.Peak pk : list) {
            if (pk.dist > PeakData.km * 1000.0) {
                continue;
            }
            float x = xFor(pk.bearing, w);
            if (x < -10 || x > w + 10) {
                continue;
            }
            float top = ground - Math.max(6 * d, (float) pk.up * pxPerDeg);
            boolean sel = pk == selected;
            p.setStrokeWidth((sel ? 3.5f : 2.2f) * d);
            p.setColor(sel ? 0xFFFFFFFF : pk.hidden ? 0x669AA3BD : (Theme.ACCENT & 0xFFFFFF) | 0xCC000000);
            cv.drawLine(x, ground, x, top, p);
            p.setStyle(Paint.Style.FILL);
            cv.drawCircle(x, top, 3.5f * d, p);
            hit.add(pk);
            hitBox.add(new RectF(x - 14 * d, top - 14 * d, x + 14 * d, ground));
        }
        p.setTextSize(10.5f * d);
        int named = 0;
        for (PeakData.Peak pk : byRank) {
            if (pk.dist > PeakData.km * 1000.0 || named > 40) {
                continue;
            }
            float x = xFor(pk.bearing, w);
            if (x < 0 || x > w) {
                continue;
            }
            boolean sel = pk == selected;
            float top = ground - Math.max(6 * d, (float) pk.up * pxPerDeg);
            String l1 = pk.name;
            String l2 = pk.ele + " m · " + pk.distText();
            float tw = Math.max(p.measureText(l1), p.measureText(l2)) + 8 * d;
            RectF r = null;
            for (int step = 0; step < 5; step++) {
                float yb = top - 8 * d - step * 30 * d;
                RectF t = new RectF(x - tw / 2f, yb - 28 * d, x + tw / 2f, yb);
                boolean free = t.top > 4 * d;
                for (RectF u : used) {
                    if (free && RectF.intersects(u, t)) {
                        free = false;
                    }
                }
                if (free) {
                    r = t;
                    break;
                }
            }
            if (r == null && !sel) {
                continue;
            }
            if (r == null) {
                r = new RectF(x - tw / 2f, Math.max(4 * d, top - 36 * d), x + tw / 2f, Math.max(32 * d, top - 8 * d));
            }
            used.add(r);
            named++;
            p.setStyle(Paint.Style.FILL);
            p.setColor(pk.hidden && !sel ? 0x99000000 : 0xCC000000);
            cv.drawRoundRect(r, 6 * d, 6 * d, p);
            p.setColor(0xFFFFFFFF);
            cv.drawText(l1, r.left + 4 * d, r.top + 12 * d, p);
            p.setColor(0xFFB9C2DC);
            p.setTextSize(9 * d);
            cv.drawText(l2, r.left + 4 * d, r.top + 24 * d, p);
            p.setTextSize(10.5f * d);
        }

        // where you look
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(12 * d);
        cv.drawText(Math.round(heading) % 360 + "° " + n8[(int) Math.round(heading / 45.0) % 8]
                + (manual ? "   (dragged, double-tap to follow the compass)" : haveSensor ? "" : "   (no compass: drag)"),
                w / 2f, h - 8 * d, p);
        p.setStrokeWidth(d);
        p.setColor(0x66FFFFFF);
        cv.drawLine(w / 2f, 0, w / 2f, ground, p);
        p.setTextAlign(Paint.Align.LEFT);
        if (PeakData.peaks.isEmpty()) {
            p.setColor(0xCCFFFFFF);
            p.setTextAlign(Paint.Align.CENTER);
            cv.drawText(PeakData.have ? "loading peaks..." : "finding your position...", w / 2f, h / 2f, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void tap(float x, float y) {
        PeakData.Peak best = null;
        for (int i = hit.size() - 1; i >= 0; i--) {
            if (hitBox.get(i).contains(x, y)) {
                best = hit.get(i);
                break;
            }
        }
        selected = best;
        if (listener != null) {
            listener.picked(best);
        }
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        pinch.onTouchEvent(e);
        if (!pinch.isInProgress()) {
            gestures.onTouchEvent(e);
        }
        return true;
    }
}
