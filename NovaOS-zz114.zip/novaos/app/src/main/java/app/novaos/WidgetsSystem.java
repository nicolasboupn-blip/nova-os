package app.novaos;

import android.app.AlertDialog;
import android.app.SearchManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.net.URLEncoder;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Phone widgets: search, shortcuts, recent apps, device, uptime, volume, clipboard, password, and four sensors. */
final class WidgetsSystem {
    private WidgetsSystem() {
    }

    // ================================================================== SEARCH

    static final class Search extends NovaWidget {
        private final EditText box;
        private final LinearLayout apps;

        Search(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER_VERTICAL);
            box = new EditText(host);
            box.setHint("search apps and the web");
            box.setSingleLine(true);
            box.setTypeface(Theme.MONO);
            box.setTextSize(13f);
            box.setTextColor(Theme.TEXT);
            box.setHintTextColor(Theme.DIM);
            box.setBackground(Theme.rounded(0x22FFFFFF, 14f, host));
            box.setPadding(dp(14), dp(10), dp(14), dp(10));
            box.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            box.setOnEditorActionListener((v, action, ev) -> {
                web(box.getText().toString(), 0);
                return true;
            });
            box.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    showApps(s.toString().trim());
                }
            });
            addView(box, wide());
            apps = row();
            LinearLayout.LayoutParams alp = wide();
            alp.topMargin = dp(6);
            addView(apps, alp);
            LinearLayout r = row();
            r.addView(chip("WEB", () -> web(box.getText().toString(), 0)), weight(1f));
            r.addView(chip("MAPS", () -> web(box.getText().toString(), 1)), weight(1f));
            r.addView(chip("YOUTUBE", () -> web(box.getText().toString(), 2)), weight(1f));
            LinearLayout.LayoutParams rlp = wide();
            rlp.topMargin = dp(6);
            addView(r, rlp);
        }

        private void showApps(String q) {
            apps.removeAllViews();
            if (q.isEmpty()) {
                return;
            }
            List<AppEntry> hits = host.repo.search(q);
            for (int i = 0; i < hits.size() && i < 3; i++) {
                final AppEntry e = hits.get(i);
                apps.addView(chip(e.label, () -> {
                    box.setText("");
                    host.launch(e);
                }), weight(1f));
            }
        }

        private void web(String q, int where) {
            q = q.trim();
            if (q.isEmpty()) {
                box.requestFocus();
                return;
            }
            Intent i;
            try {
                String enc = URLEncoder.encode(q, "UTF-8");
                if (where == 1) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc));
                } else if (where == 2) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + enc));
                } else {
                    i = new Intent(Intent.ACTION_WEB_SEARCH);
                    i.putExtra(SearchManager.QUERY, q);
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(i);
            } catch (Exception e) {
                try {
                    host.startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))));
                } catch (Exception again) {
                    host.toast("No app can open that search");
                }
            }
        }
    }

    // ================================================================== SHORTCUTS

    static final class Shortcuts extends NovaWidget {
        private static final int SLOTS = 4;
        private final LinearLayout bar;

        Shortcuts(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            bar = row();
            addView(bar, wide());
            addView(text("tap + to add · hold to change", 8f, Theme.DIM), wide());
        }

        @Override
        void refresh() {
            bar.removeAllViews();
            for (int i = 0; i < SLOTS; i++) {
                final int idx = i;
                String pkg = Prefs.getString("sc_" + i, "");
                final AppEntry e = pkg == null || pkg.isEmpty() ? null : host.repo.find(pkg);
                LinearLayout cell = new LinearLayout(host);
                cell.setOrientation(VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(2), dp(6), dp(2), dp(6));
                cell.setClickable(true);
                Theme.ripple(cell);
                if (e == null) {
                    TextView plus = text("+", 22f, Theme.ACCENT);
                    plus.setBackground(Theme.rounded(0x22FFFFFF, 14f, host));
                    cell.addView(plus, new LinearLayout.LayoutParams(dp(40), dp(40)));
                    cell.addView(text("add", 9f, Theme.DIM));
                    cell.setOnClickListener(v -> choose(idx));
                } else {
                    ImageView icon = new ImageView(host);
                    icon.setImageDrawable(Theme.tint(host, e.icon));
                    cell.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
                    TextView t = text(e.label, 9f, Theme.TEXT);
                    t.setSingleLine(true);
                    t.setEllipsize(TextUtils.TruncateAt.END);
                    cell.addView(t, wide());
                    cell.setOnClickListener(v -> host.launch(e));
                }
                cell.setOnLongClickListener(v -> {
                    new AlertDialog.Builder(host).setTitle("Shortcut " + (idx + 1))
                            .setItems(new String[] {"Change app", "Remove"}, (d, w) -> {
                                if (w == 0) {
                                    choose(idx);
                                } else {
                                    Prefs.putString("sc_" + idx, "");
                                    refresh();
                                }
                            }).show();
                    return true;
                });
                bar.addView(cell, weight(1f));
            }
        }

        private void choose(final int idx) {
            host.repo.ensureFresh();
            final List<AppEntry> all = new ArrayList<>(host.repo.all);
            Collections.sort(all, (a, b) -> a.label.compareToIgnoreCase(b.label));
            String[] names = new String[all.size()];
            for (int i = 0; i < names.length; i++) {
                names[i] = all.get(i).label;
            }
            new AlertDialog.Builder(host).setTitle("Pick an app")
                    .setItems(names, (d, w) -> {
                        Prefs.putString("sc_" + idx, all.get(w).pkg);
                        refresh();
                    }).show();
        }
    }

    // ================================================================== RECENT APPS

    static final class Recent extends NovaWidget {
        private final LinearLayout bar;
        private final TextView note;
        private boolean loading;

        Recent(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            bar = row();
            addView(bar, wide());
            note = text("", 9f, Theme.DIM);
            addView(note, wide());
        }

        @Override
        void refresh() {
            if (!UsageHelper.hasAccess(host)) {
                bar.removeAllViews();
                bar.addView(chip("ALLOW USAGE ACCESS", () -> {
                    try {
                        host.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                    } catch (Exception e) {
                        host.toast("Open Settings > Apps > Special access > Usage access");
                    }
                }), wide());
                note.setText("NOVA needs usage access to see which apps you used last");
                return;
            }
            if (loading) {
                return;
            }
            loading = true;
            final Context app = host.getApplicationContext();
            final String me = host.getPackageName();
            new Thread(() -> {
                final List<String> pkgs = new ArrayList<>();
                final List<Long> when = new ArrayList<>();
                try {
                    UsageStatsManager usm = (UsageStatsManager) app.getSystemService(Context.USAGE_STATS_SERVICE);
                    long now = System.currentTimeMillis();
                    List<UsageStats> list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,
                            now - 3 * 86400000L, now);
                    if (list != null) {
                        Collections.sort(list, (a, b) -> Long.compare(b.getLastTimeUsed(), a.getLastTimeUsed()));
                        for (UsageStats u : list) {
                            String p = u.getPackageName();
                            if (!p.equals(me) && u.getTotalTimeInForeground() > 0 && !pkgs.contains(p)) {
                                pkgs.add(p);
                                when.add(u.getLastTimeUsed());
                            }
                        }
                    }
                } catch (Exception ignored) {
                    // no data, the widget says so
                }
                ui.post(() -> {
                    loading = false;
                    show(pkgs, when);
                });
            }).start();
        }

        private void show(List<String> pkgs, List<Long> when) {
            bar.removeAllViews();
            int shown = 0;
            for (int i = 0; i < pkgs.size() && shown < 4; i++) {
                final AppEntry e = host.repo.find(pkgs.get(i));
                if (e == null) {
                    continue;
                }
                LinearLayout cell = new LinearLayout(host);
                cell.setOrientation(VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(2), dp(6), dp(2), dp(6));
                cell.setClickable(true);
                Theme.ripple(cell);
                cell.setOnClickListener(v -> host.launch(e));
                ImageView icon = new ImageView(host);
                icon.setImageDrawable(Theme.tint(host, e.icon));
                cell.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
                TextView t = text(e.label, 9f, Theme.TEXT);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                cell.addView(t, wide());
                cell.addView(text(ago(when.get(i)), 8f, Theme.DIM), wide());
                bar.addView(cell, weight(1f));
                shown++;
            }
            note.setText(shown == 0 ? "no apps used in the last 3 days" : "");
        }

        private static String ago(long t) {
            long m = Math.max(0, (System.currentTimeMillis() - t) / 60000);
            if (m < 1) {
                return "now";
            }
            if (m < 60) {
                return m + "m ago";
            }
            if (m < 1440) {
                return (m / 60) + "h ago";
            }
            return (m / 1440) + "d ago";
        }
    }

    // ================================================================== DEVICE

    static final class Device extends NovaWidget {
        Device(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            String maker = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
            if (!maker.isEmpty()) {
                maker = Character.toUpperCase(maker.charAt(0)) + maker.substring(1);
            }
            addView(text(maker + " " + Build.MODEL, 14f, Theme.TEXT), wide());
            DisplayMetrics dm = new DisplayMetrics();
            host.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            String abi = Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?";
            String[] lines = {
                "Android " + Build.VERSION.RELEASE + "  ·  API " + Build.VERSION.SDK_INT,
                "patch " + Build.VERSION.SECURITY_PATCH,
                Runtime.getRuntime().availableProcessors() + " cores  ·  " + abi,
                dm.widthPixels + " × " + dm.heightPixels + "  ·  " + dm.densityDpi + " dpi",
                "kernel " + System.getProperty("os.version", "?"),
                Theme.OS_NAME + " " + Theme.OS_VERSION};
            for (String l : lines) {
                TextView t = text(l, 10f, Theme.DIM);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams lp = wide();
                lp.topMargin = dp(2);
                addView(t, lp);
            }
        }
    }

    // ================================================================== UPTIME

    static final class Uptime extends NovaWidget {
        private final TextView big;
        private final TextView booted;
        private final TextView awake;
        private final WidgetBar bar;

        Uptime(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            addView(text("PHONE RUNNING FOR", 9f, Theme.DIM), wide());
            big = text("", 22f, Theme.TEXT);
            addView(big, wide());
            booted = text("", 9f, Theme.DIM);
            addView(booted, wide());
            bar = new WidgetBar(host);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(6));
            blp.setMargins(dp(16), dp(10), dp(16), dp(4));
            addView(bar, blp);
            awake = text("", 9f, Theme.DIM);
            addView(awake, wide());
        }

        @Override
        long tickMs() {
            return 1000;
        }

        @Override
        void tick() {
            long up = SystemClock.elapsedRealtime();
            long s = up / 1000;
            long d = s / 86400;
            big.setText((d > 0 ? d + "d " : "") + String.format(Locale.ROOT, "%02d:%02d:%02d",
                    (s / 3600) % 24, (s / 60) % 60, s % 60));
            booted.setText("since " + new SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault())
                    .format(new Date(System.currentTimeMillis() - up)));
            float f = up > 0 ? SystemClock.uptimeMillis() / (float) up : 0f;
            bar.set(f);
            awake.setText("awake " + Math.round(f * 100) + "%  ·  deep sleep " + Math.round((1 - f) * 100) + "%");
        }
    }

    // ================================================================== VOLUME

    static final class Volume extends NovaWidget {
        private static final int[] STREAMS = {AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING,
            AudioManager.STREAM_ALARM, AudioManager.STREAM_NOTIFICATION};
        private static final String[] NAMES = {"MEDIA", "RING", "ALARM", "NOTIFY"};
        private final AudioManager am;
        private final SeekBar[] bars = new SeekBar[STREAMS.length];
        private final TextView[] vals = new TextView[STREAMS.length];
        private boolean setting;

        Volume(NovaActivity host) {
            super(host);
            am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            for (int i = 0; i < STREAMS.length; i++) {
                final int idx = i;
                LinearLayout r = row();
                TextView n = text(NAMES[i], 9f, Theme.DIM);
                n.setGravity(Gravity.START);
                r.addView(n, new LinearLayout.LayoutParams(dp(44), LayoutParams.WRAP_CONTENT));
                bars[i] = new SeekBar(host);
                bars[i].setProgressTintList(ColorStateList.valueOf(Theme.ACCENT));
                bars[i].setThumbTintList(ColorStateList.valueOf(Theme.ACCENT));
                bars[i].setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
                bars[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar s, int p, boolean user) {
                        if (user && !setting) {
                            set(idx, p);
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar s) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar s) {
                    }
                });
                r.addView(bars[i], new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
                vals[i] = text("", 9f, Theme.TEXT);
                r.addView(vals[i], new LinearLayout.LayoutParams(dp(26), LayoutParams.WRAP_CONTENT));
                addView(r, fill());
            }
        }

        private void set(int i, int v) {
            try {
                am.setStreamVolume(STREAMS[i], v, 0);
            } catch (SecurityException e) {
                host.toast("Do Not Disturb is blocking that");
            }
            refresh();
        }

        @Override
        void refresh() {
            if (am == null) {
                return;
            }
            setting = true;
            for (int i = 0; i < STREAMS.length; i++) {
                int max = am.getStreamMaxVolume(STREAMS[i]);
                int cur = am.getStreamVolume(STREAMS[i]);
                bars[i].setMax(max);
                bars[i].setProgress(cur);
                vals[i].setText(max > 0 ? Math.round(cur * 100f / max) + "" : "-");
            }
            setting = false;
        }

        @Override
        long tickMs() {
            return 3000;
        }

        @Override
        void tick() {
            refresh();
        }
    }

    // ================================================================== CLIPBOARD

    static final class Clip extends NovaWidget {
        /** Kept in memory only, never saved: copied text can be private. */
        private static final List<String> HISTORY = new ArrayList<>();
        private final ClipboardManager cm;
        private final TextView current;
        private final LinearLayout older;
        private final ClipboardManager.OnPrimaryClipChangedListener listener = this::read;

        Clip(NovaActivity host) {
            super(host);
            cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            current = text("", 12f, Theme.TEXT);
            current.setMaxLines(3);
            current.setEllipsize(TextUtils.TruncateAt.END);
            current.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
            current.setPadding(dp(10), dp(8), dp(10), dp(8));
            addView(current, wide());
            older = new LinearLayout(host);
            older.setOrientation(VERTICAL);
            LinearLayout.LayoutParams olp = fill();
            olp.topMargin = dp(4);
            addView(older, olp);
            LinearLayout r = row();
            r.addView(text("history stays in memory only", 8f, Theme.DIM), weight(1f));
            r.addView(chip("CLEAR", this::clear));
            addView(r, wide());
        }

        @Override
        void onLive(boolean on) {
            if (cm == null) {
                return;
            }
            if (on) {
                cm.addPrimaryClipChangedListener(listener);
            } else {
                cm.removePrimaryClipChangedListener(listener);
            }
        }

        @Override
        void refresh() {
            read();
        }

        private void read() {
            String now = "";
            try {
                ClipData d = cm == null ? null : cm.getPrimaryClip();
                if (d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null) {
                    now = d.getItemAt(0).getText().toString().trim();
                }
            } catch (Exception ignored) {
                // not readable right now
            }
            if (!now.isEmpty()) {
                HISTORY.remove(now);
                HISTORY.add(0, now);
                while (HISTORY.size() > 6) {
                    HISTORY.remove(HISTORY.size() - 1);
                }
            }
            current.setText(now.isEmpty() ? "clipboard is empty" : now);
            current.setTextColor(now.isEmpty() ? Theme.DIM : Theme.TEXT);
            older.removeAllViews();
            for (int i = 0; i < HISTORY.size() && older.getChildCount() < 3; i++) {
                final String s = HISTORY.get(i);
                if (s.equals(now)) {
                    continue;
                }
                TextView t = text(s.replace('\n', ' '), 10f, Theme.DIM);
                t.setGravity(Gravity.START);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(dp(6), dp(4), dp(6), dp(4));
                t.setClickable(true);
                Theme.ripple(t);
                t.setOnClickListener(v -> {
                    cm.setPrimaryClip(ClipData.newPlainText("text", s));
                    host.toast("Copied again");
                });
                older.addView(t, wide());
            }
        }

        private void clear() {
            HISTORY.clear();
            try {
                if (Build.VERSION.SDK_INT >= 28) {
                    cm.clearPrimaryClip();
                } else {
                    cm.setPrimaryClip(ClipData.newPlainText("", ""));
                }
            } catch (Exception ignored) {
                // nothing to clear
            }
            read();
        }
    }

    // ================================================================== PASSWORD

    static final class Password extends NovaWidget {
        private static final String LOWER = "abcdefghijkmnopqrstuvwxyz";
        private static final String UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
        private static final String DIGITS = "23456789";
        private static final String SYMBOLS = "!@#$%^&*-_=+?";
        private static final int[] LENGTHS = {12, 16, 24};
        private final SecureRandom rnd = new SecureRandom();
        private final TextView out;
        private final TextView strength;
        private final TextView[] lenChips = new TextView[LENGTHS.length];
        private final TextView symChip;
        private String pw = "";

        Password(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            out = text("", 14f, Theme.TEXT);
            out.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
            out.setPadding(dp(10), dp(10), dp(10), dp(10));
            out.setClickable(true);
            out.setOnClickListener(v -> copy());
            addView(out, wide());
            strength = text("", 9f, Theme.DIM);
            addView(strength, wide());
            LinearLayout r1 = row();
            for (int i = 0; i < LENGTHS.length; i++) {
                final int l = LENGTHS[i];
                lenChips[i] = chip(String.valueOf(l), () -> {
                    Prefs.putInt("pw_len", l);
                    make();
                });
                r1.addView(lenChips[i], weight(1f));
            }
            symChip = chip("!#$", () -> {
                Prefs.putBool("pw_sym", !Prefs.getBool("pw_sym", true));
                make();
            });
            r1.addView(symChip, weight(1f));
            addView(r1, wide());
            LinearLayout r2 = row();
            r2.addView(chip("NEW", this::make), weight(1f));
            r2.addView(chip("COPY", this::copy), weight(1f));
            addView(r2, wide());
            make();
        }

        private void make() {
            int len = Prefs.getInt("pw_len", 16);
            boolean sym = Prefs.getBool("pw_sym", true);
            String[] sets = sym ? new String[] {LOWER, UPPER, DIGITS, SYMBOLS} : new String[] {LOWER, UPPER, DIGITS};
            StringBuilder all = new StringBuilder();
            for (String s : sets) {
                all.append(s);
            }
            List<Character> chars = new ArrayList<>();
            for (String s : sets) {
                chars.add(s.charAt(rnd.nextInt(s.length())));
            }
            while (chars.size() < len) {
                chars.add(all.charAt(rnd.nextInt(all.length())));
            }
            Collections.shuffle(chars, rnd);
            StringBuilder b = new StringBuilder();
            for (char c : chars) {
                b.append(c);
            }
            pw = b.toString();
            out.setText(pw);
            int bits = (int) Math.round(len * (Math.log(all.length()) / Math.log(2)));
            strength.setText("about " + bits + " bits  ·  " + (bits >= 90 ? "very strong" : bits >= 70 ? "strong"
                    : "ok") + "  ·  tap to copy");
            for (int i = 0; i < LENGTHS.length; i++) {
                pick(lenChips[i], LENGTHS[i] == len);
            }
            pick(symChip, sym);
        }

        private void copy() {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) {
                return;
            }
            ClipData clip = ClipData.newPlainText("password", pw);
            if (Build.VERSION.SDK_INT >= 33) {
                PersistableBundle extras = new PersistableBundle();
                extras.putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true);
                clip.getDescription().setExtras(extras);
            }
            cm.setPrimaryClip(clip);
            host.toast("Password copied");
        }
    }

    // ================================================================== sensor base

    /** A widget that listens to one sensor while it is on screen. */
    abstract static class SensorWidget extends NovaWidget implements SensorEventListener {
        final SensorManager sm;
        final Sensor sensor;

        SensorWidget(NovaActivity host, int type) {
            super(host);
            sm = (SensorManager) host.getSystemService(Context.SENSOR_SERVICE);
            sensor = sm == null ? null : sm.getDefaultSensor(type);
        }

        @Override
        void onLive(boolean on) {
            if (sensor == null) {
                return;
            }
            if (on) {
                sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
            } else {
                sm.unregisterListener(this);
            }
        }

        @Override
        public void onAccuracyChanged(Sensor s, int accuracy) {
        }
    }

    // ================================================================== COMPASS

    static final class Compass extends SensorWidget {
        private final Dial dial;
        private final TextView head;
        private final float[] rot = new float[9];
        private final float[] orient = new float[3];
        private float shown = Float.NaN;

        Compass(NovaActivity host) {
            super(host, Sensor.TYPE_ROTATION_VECTOR);
            dial = new Dial(host);
            addView(dial, fill());
            head = text(sensor == null ? "no compass sensor on this phone" : "hold the phone flat", 12f, Theme.TEXT);
            addView(head, wide());
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            SensorManager.getRotationMatrixFromVector(rot, e.values);
            SensorManager.getOrientation(rot, orient);
            float az = (float) ((Math.toDegrees(orient[0]) + 360) % 360);
            if (Float.isNaN(shown)) {
                shown = az;
            } else {
                float diff = ((az - shown + 540) % 360) - 180;
                shown = (shown + diff * 0.2f + 360) % 360;
            }
            dial.set(shown);
            int deg = Math.round(shown) % 360;
            String[] dirs = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            head.setText(dirs[Math.round(deg / 45f) % 8] + "  " + deg + "°");
        }

        private static final class Dial extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float heading;

            Dial(Context c) {
                super(c);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Theme.MONO);
            }

            void set(float h) {
                heading = h;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) * 0.92f;
                if (r <= 0) {
                    return;
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x14FFFFFF);
                c.drawCircle(cx, cy, r, p);
                c.save();
                c.rotate(-heading, cx, cy);
                p.setStyle(Paint.Style.STROKE);
                for (int i = 0; i < 72; i++) {
                    boolean big = i % 9 == 0;
                    p.setStrokeWidth(big ? r * 0.03f : r * 0.01f);
                    p.setColor(big ? Theme.TEXT : Theme.DIM);
                    double a = Math.PI * 2 * i / 72;
                    float in = r * (big ? 0.82f : 0.9f);
                    c.drawLine(cx + (float) Math.sin(a) * in, cy - (float) Math.cos(a) * in,
                            cx + (float) Math.sin(a) * r * 0.97f, cy - (float) Math.cos(a) * r * 0.97f, p);
                }
                p.setStyle(Paint.Style.FILL);
                p.setTextSize(r * 0.2f);
                String[] card = {"N", "E", "S", "W"};
                for (int i = 0; i < 4; i++) {
                    double a = Math.PI / 2 * i;
                    p.setColor(i == 0 ? Theme.ACCENT : Theme.TEXT);
                    c.drawText(card[i], cx + (float) Math.sin(a) * r * 0.62f,
                            cy - (float) Math.cos(a) * r * 0.62f + p.getTextSize() * 0.35f, p);
                }
                c.restore();
                // fixed pointer at the top: where the phone points
                p.setColor(Theme.ACCENT);
                android.graphics.Path tri = new android.graphics.Path();
                tri.moveTo(cx, cy - r * 1.02f);
                tri.lineTo(cx - r * 0.07f, cy - r * 0.86f);
                tri.lineTo(cx + r * 0.07f, cy - r * 0.86f);
                tri.close();
                c.drawPath(tri, p);
            }
        }
    }

    // ================================================================== LEVEL

    static final class Level extends SensorWidget {
        private final Bubble bubble;
        private final TextView label;
        private float ax;
        private float ay;
        private float az = 9.81f;

        Level(NovaActivity host) {
            super(host, Sensor.TYPE_ACCELEROMETER);
            bubble = new Bubble(host);
            addView(bubble, fill());
            label = text(sensor == null ? "no motion sensor on this phone" : "", 11f, Theme.TEXT);
            addView(label, wide());
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            ax += (e.values[0] - ax) * 0.2f;
            ay += (e.values[1] - ay) * 0.2f;
            az += (e.values[2] - az) * 0.2f;
            float rx = (float) Math.toDegrees(Math.atan2(ax, Math.abs(az)));
            float ry = (float) Math.toDegrees(Math.atan2(ay, Math.abs(az)));
            boolean flat = Math.abs(rx) < 1f && Math.abs(ry) < 1f;
            bubble.set(ax / 9.81f, -ay / 9.81f, flat);
            label.setText(flat ? "LEVEL" : String.format(Locale.ROOT, "X %.1f°   Y %.1f°", rx, ry));
            label.setTextColor(flat ? Theme.ACCENT : Theme.TEXT);
        }

        private static final class Bubble extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float bx;
            private float by;
            private boolean ok;

            Bubble(Context c) {
                super(c);
            }

            void set(float x, float y, boolean level) {
                bx = Math.max(-1f, Math.min(1f, x * 3f));
                by = Math.max(-1f, Math.min(1f, y * 3f));
                ok = level;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) * 0.92f;
                if (r <= 0) {
                    return;
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x14FFFFFF);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(r * 0.012f);
                p.setColor(Theme.DIM);
                c.drawCircle(cx, cy, r * 0.22f, p);
                c.drawLine(cx - r, cy, cx + r, cy, p);
                c.drawLine(cx, cy - r, cx, cy + r, p);
                float br = r * 0.18f;
                float lim = r - br;
                float x = cx + bx * lim;
                float y = cy + by * lim;
                p.setStyle(Paint.Style.FILL);
                p.setColor(ok ? Theme.ACCENT : 0xCCE6F2C8);
                c.drawCircle(x, y, br, p);
                p.setColor(0x66FFFFFF);
                c.drawCircle(x - br * 0.35f, y - br * 0.35f, br * 0.3f, p);
            }
        }
    }

    // ================================================================== LIGHT METER

    static final class Light extends SensorWidget {
        private final TextView lux;
        private final TextView desc;
        private final WidgetBar bar;

        Light(NovaActivity host) {
            super(host, Sensor.TYPE_LIGHT);
            setGravity(Gravity.CENTER);
            addView(text("LIGHT AROUND YOU", 9f, Theme.DIM), wide());
            lux = text(sensor == null ? "--" : "...", 28f, Theme.TEXT);
            addView(lux, wide());
            desc = text(sensor == null ? "no light sensor on this phone" : "", 10f, Theme.ACCENT);
            addView(desc, wide());
            bar = new WidgetBar(host);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(6));
            blp.setMargins(dp(16), dp(10), dp(16), 0);
            addView(bar, blp);
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            float v = e.values[0];
            lux.setText(Math.round(v) + " lx");
            desc.setText(v < 10 ? "dark" : v < 50 ? "dim" : v < 200 ? "living room" : v < 500 ? "office light"
                    : v < 1000 ? "bright room" : v < 10000 ? "overcast daylight" : v < 30000 ? "daylight"
                    : "direct sun");
            bar.set((float) (Math.log10(v + 1) / 5.0));
        }
    }

    // ================================================================== BAROMETER

    static final class Baro extends SensorWidget {
        private final TextView hpa;
        private final TextView alt;
        private final TextView range;
        private float min = Float.MAX_VALUE;
        private float max = 0f;

        Baro(NovaActivity host) {
            super(host, Sensor.TYPE_PRESSURE);
            setGravity(Gravity.CENTER);
            addView(text("AIR PRESSURE", 9f, Theme.DIM), wide());
            hpa = text(sensor == null ? "--" : "...", 26f, Theme.TEXT);
            addView(hpa, wide());
            alt = text(sensor == null ? "this phone has no barometer" : "", 10f, Theme.ACCENT);
            addView(alt, wide());
            range = text("", 9f, Theme.DIM);
            addView(range, wide());
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            float p = e.values[0];
            min = Math.min(min, p);
            max = Math.max(max, p);
            hpa.setText(String.format(Locale.ROOT, "%.1f hPa", p));
            float m = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, p);
            alt.setText("about " + Math.round(m) + " m up  ·  " + (p > 1022 ? "high, settled" : p < 1000
                    ? "low, unsettled" : "normal"));
            range.setText(String.format(Locale.ROOT, "low %.1f  ·  high %.1f  (while watching)", min, max));
        }
    }
}
