package app.novaos;

import java.util.ArrayList;
import java.util.List;

/**
 * Friend profiles for the friends table. Up to 20 guests, each with their own coins that carry over between games
 * and between app restarts. A new guest starts with 1000 coins.
 */
final class Guests {
    static final int MAX = 20;
    static final int START = 1000;
    private static final String KEY = "table_guests";

    private Guests() {}

    static final class Guest {
        String name;
        int coins;

        Guest(String name, int coins) {
            this.name = name;
            this.coins = coins;
        }
    }

    static List<Guest> all() {
        List<Guest> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw == null || raw.isEmpty()) {
            return out;
        }
        for (String line : raw.split("\n")) {
            int tab = line.lastIndexOf('\t');
            if (tab <= 0) {
                continue;
            }
            int coins;
            try {
                coins = Integer.parseInt(line.substring(tab + 1));
            } catch (NumberFormatException e) {
                coins = START;
            }
            out.add(new Guest(line.substring(0, tab), coins));
        }
        return out;
    }

    static void save(List<Guest> list) {
        StringBuilder sb = new StringBuilder();
        for (Guest g : list) {
            sb.append(g.name).append('\t').append(g.coins).append('\n');
        }
        Prefs.putString(KEY, sb.toString());
    }

    static String clean(String s) {
        return s.replace('\t', ' ').replace('\n', ' ').trim();
    }
}
