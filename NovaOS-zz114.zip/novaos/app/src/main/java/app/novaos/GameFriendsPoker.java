package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;

/**
 * Texas Hold'em for the friends table: 2 to 4 players on one phone. Blinds 10 / 20, the dealer button moves every
 * hand. Before each turn the phone is passed and only the player whose turn it is sees their two cards. Side pots
 * work, so going all-in against a bigger stack is fair. The hand evaluator is the one from the dealer poker game.
 */
final class GameFriendsPoker extends FriendsGame {
    private static final int SB = 10;
    private static final int BB = 20;
    private static final int[] RAISES = {20, 50, 100, 500, 2000};
    private static final String[] HANDS = {"HIGH CARD", "PAIR", "TWO PAIR", "THREE OF A KIND", "STRAIGHT", "FLUSH",
        "FULL HOUSE", "FOUR OF A KIND", "STRAIGHT FLUSH"};
    private static final String[] STREETS = {"PRE-FLOP", "FLOP", "TURN", "RIVER"};
    private static final int SCALE = 10000000;
    private static final String RULES = "Everyone gets 2 secret cards. 5 shared cards come out in the middle: "
            + "3 (the flop), then 1 (the turn), then 1 (the river).\n\n"
            + "On your turn: FOLD gives up the hand. CHECK passes if nobody bet. CALL matches the bet. "
            + "RAISE bets more. ALL IN bets everything.\n\n"
            + "Best 5 cards out of your 2 + the 5 in the middle win the pot.\n\n"
            + "Only look at the phone when it is your turn!";

    private final Random rnd = new Random();
    private final int n;
    private final boolean[] inHand;
    private final boolean[] folded;
    private final boolean[] allIn;
    private final boolean[] acted;
    private final int[] streetBet;
    private final int[] contrib;
    private final int[][] hole;
    private final int[] board = new int[5];
    private int revealed;
    private int street;
    private int dealer = -1;
    private int toAct = -1;
    private int currentBet;
    private int minRaise;
    private int handNo;
    private int raiseIdx = 1;
    private boolean showing;

    private final TextView header;
    private final LinearLayout boardRow;
    private final LinearLayout table;
    private final TextView youLabel;
    private final LinearLayout youRow;
    private final LinearLayout raiseRow;
    private final LinearLayout actions;

    GameFriendsPoker(NovaActivity host, FriendsSeats seats) {
        super(host, seats);
        n = seats.size();
        inHand = new boolean[n];
        folded = new boolean[n];
        allIn = new boolean[n];
        acted = new boolean[n];
        streetBet = new int[n];
        contrib = new int[n];
        hole = new int[n][2];

        header = label("", 12f, Theme.ACCENT);
        header.setLetterSpacing(0.08f);
        col.addView(header, wide());
        boardRow = row();
        LinearLayout.LayoutParams bl = wide();
        bl.topMargin = dp(12);
        col.addView(boardRow, bl);
        table = new LinearLayout(host);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        table.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams tl = wide();
        tl.topMargin = dp(14);
        col.addView(table, tl);
        youLabel = label("", 12f, Theme.TEXT);
        LinearLayout.LayoutParams yl = wide();
        yl.topMargin = dp(14);
        col.addView(youLabel, yl);
        youRow = row();
        col.addView(youRow, wide());
        raiseRow = row();
        LinearLayout.LayoutParams rl = wide();
        rl.topMargin = dp(12);
        col.addView(raiseRow, rl);
        actions = row();
        col.addView(actions, wide());

        render();
        showChoice("TEXAS HOLD'EM", RULES + "\n\nblinds " + SB + " / " + BB, new String[] {"DEAL"},
                new Runnable[] {this::startHand});
    }

    @Override
    String title() {
        return "FRIENDS POKER";
    }

    // ------------------------------------------------------------------ helpers

    private int[] stack() {
        return seats.stack;
    }

    private boolean canAct(int i) {
        return inHand[i] && !folded[i] && !allIn[i];
    }

    private int contenders() {
        int c = 0;
        for (int i = 0; i < n; i++) {
            if (inHand[i] && !folded[i]) {
                c++;
            }
        }
        return c;
    }

    private int canActCount() {
        int c = 0;
        for (int i = 0; i < n; i++) {
            if (canAct(i)) {
                c++;
            }
        }
        return c;
    }

    private int pot() {
        int p = 0;
        for (int c : contrib) {
            p += c;
        }
        return p;
    }

    /** The next seat after 'from' that is in this hand. */
    private int nextIn(int from) {
        for (int k = 1; k <= n; k++) {
            int i = ((from + k) % n + n) % n;
            if (inHand[i]) {
                return i;
            }
        }
        return -1;
    }

    /** The next seat after 'from' that still has to act this betting round. */
    private int nextActor(int from) {
        for (int k = 1; k <= n; k++) {
            int i = ((from + k) % n + n) % n;
            if (canAct(i) && (!acted[i] || streetBet[i] < currentBet)) {
                return i;
            }
        }
        return -1;
    }

    private boolean roundComplete() {
        for (int i = 0; i < n; i++) {
            if (canAct(i) && (!acted[i] || streetBet[i] != currentBet)) {
                return false;
            }
        }
        return true;
    }

    private void post(int i, int amount) {
        int a = Math.max(0, Math.min(amount, stack()[i]));
        stack()[i] -= a;
        streetBet[i] += a;
        contrib[i] += a;
        if (stack()[i] == 0) {
            allIn[i] = true;
        }
    }

    private static int[] withBoard(int[] two, int[] board, int count) {
        int[] out = new int[2 + count];
        out[0] = two[0];
        out[1] = two[1];
        System.arraycopy(board, 0, out, 2, count);
        return out;
    }

    private String boardText() {
        if (revealed == 0) {
            return "no cards in the middle yet";
        }
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < revealed; i++) {
            b.append(cardText(board[i])).append("  ");
        }
        return b.toString().trim();
    }

    // ------------------------------------------------------------------ a hand

    private void startHand() {
        hideCover();
        showing = false;
        int alive = 0;
        for (int s : stack()) {
            if (s > 0) {
                alive++;
            }
        }
        if (alive < 2) {
            gameOver("only one player has chips left");
            return;
        }
        handNo++;
        for (int i = 0; i < n; i++) {
            inHand[i] = stack()[i] > 0;
            folded[i] = false;
            allIn[i] = false;
            acted[i] = false;
            streetBet[i] = 0;
            contrib[i] = 0;
        }
        List<Integer> deck = shoe(1, rnd);
        for (int i = 0; i < n; i++) {
            if (inHand[i]) {
                hole[i][0] = deck.remove(deck.size() - 1);
                hole[i][1] = deck.remove(deck.size() - 1);
            }
        }
        for (int k = 0; k < 5; k++) {
            board[k] = deck.remove(deck.size() - 1);
        }
        revealed = 0;
        street = 0;
        dealer = nextIn(dealer);
        int sb;
        int bb;
        if (alive == 2) {
            sb = dealer;
            bb = nextIn(dealer);
        } else {
            sb = nextIn(dealer);
            bb = nextIn(sb);
        }
        post(sb, SB);
        post(bb, BB);
        currentBet = Math.max(streetBet[sb], streetBet[bb]);
        minRaise = BB;
        Sfx.play(Sfx.CARD);
        proceed(bb);
    }

    /** After an action (or the blinds): who is next, or is the round, or the hand, over? */
    private void proceed(int from) {
        if (contenders() == 1) {
            winUncontested();
            return;
        }
        if (roundComplete()) {
            nextStreet();
            return;
        }
        int nx = nextActor(from);
        if (nx < 0) {
            nextStreet();
            return;
        }
        beginTurn(nx);
    }

    private void nextStreet() {
        for (int i = 0; i < n; i++) {
            streetBet[i] = 0;
            acted[i] = false;
        }
        currentBet = 0;
        minRaise = BB;
        if (street == 3) {
            showdown();
            return;
        }
        street++;
        revealed = street == 1 ? 3 : street == 2 ? 4 : 5;
        Sfx.play(Sfx.CARD);
        if (canActCount() <= 1) {
            // nobody can bet any more: deal the rest out for everyone to watch
            toAct = -1;
            showing = false;
            hideCover();
            render();
            h.postDelayed(this::nextStreet, 1100);
            return;
        }
        proceed(dealer);
    }

    private void beginTurn(int i) {
        toAct = i;
        showing = false;
        render();
        int toCall = currentBet - streetBet[i];
        showPass("PASS THE PHONE", "to " + seats.names[i] + "\n\n" + STREETS[street] + "   ·   pot " + pot()
                        + "\n" + boardText() + "\n\n" + (toCall > 0 ? "to call: " + toCall : "nothing to call"),
                "NEXT PLAYER", () -> {
                    hideCover();
                    showing = true;
                    render();
                });
    }

    // ------------------------------------------------------------------ actions

    private boolean myTurn() {
        return showing && toAct >= 0 && canAct(toAct);
    }

    private void fold() {
        if (!myTurn()) {
            return;
        }
        folded[toAct] = true;
        acted[toAct] = true;
        Sfx.play(Sfx.LOSE);
        done();
    }

    private void call() {
        if (!myTurn()) {
            return;
        }
        int need = currentBet - streetBet[toAct];
        post(toAct, need);
        acted[toAct] = true;
        Sfx.play(need > 0 ? Sfx.CHIP : Sfx.CLICK);
        done();
    }

    private void raise() {
        if (!myTurn()) {
            return;
        }
        int i = toAct;
        int by = Math.max(RAISES[raiseIdx], minRaise);
        int target = currentBet + by;
        int need = target - streetBet[i];
        if (need >= stack()[i]) {
            allInNow();
            return;
        }
        post(i, need);
        minRaise = by;
        currentBet = target;
        reopen(i);
        Sfx.play(Sfx.CHIP);
        done();
    }

    private void allInNow() {
        if (!myTurn()) {
            return;
        }
        int i = toAct;
        post(i, stack()[i]);
        if (streetBet[i] > currentBet) {
            int inc = streetBet[i] - currentBet;
            if (inc >= minRaise) {
                minRaise = inc;
            }
            currentBet = streetBet[i];
            reopen(i);
        }
        acted[i] = true;
        Sfx.play(Sfx.JACKPOT);
        host.buzz(60);
        done();
    }

    /** After a raise everyone else has to act again. */
    private void reopen(int raiser) {
        for (int j = 0; j < n; j++) {
            if (j != raiser && canAct(j)) {
                acted[j] = false;
            }
        }
        acted[raiser] = true;
    }

    private void done() {
        showing = false;
        int from = toAct;
        render();
        proceed(from);
    }

    // ------------------------------------------------------------------ the end of a hand

    private void winUncontested() {
        int w = -1;
        for (int i = 0; i < n; i++) {
            if (inHand[i] && !folded[i]) {
                w = i;
            }
        }
        int p = pot();
        stack()[w] += p;
        endHand(seats.names[w] + " wins " + p + "\neveryone else folded");
    }

    private void showdown() {
        revealed = 5;
        toAct = -1;
        showing = false;
        int[] score = new int[n];
        for (int i = 0; i < n; i++) {
            if (inHand[i] && !folded[i]) {
                score[i] = GamePoker.best(withBoard(hole[i], board, 5));
            }
        }
        int[] won = new int[n];
        TreeSet<Integer> levels = new TreeSet<>();
        for (int c : contrib) {
            if (c > 0) {
                levels.add(c);
            }
        }
        int prev = 0;
        for (int level : levels) {
            int part = 0;
            for (int c : contrib) {
                part += Math.min(c, level) - Math.min(c, prev);
            }
            List<Integer> elig = new ArrayList<>();
            int top = -1;
            for (int k = 1; k <= n; k++) {
                int i = (dealer + k) % n;
                if (inHand[i] && !folded[i] && contrib[i] >= level) {
                    if (score[i] > top) {
                        top = score[i];
                        elig.clear();
                    }
                    if (score[i] == top) {
                        elig.add(i);
                    }
                }
            }
            if (elig.isEmpty()) {
                // nobody still in the hand put this much in: it goes back to whoever did
                for (int i = 0; i < n; i++) {
                    if (contrib[i] >= level) {
                        elig.add(i);
                    }
                }
            }
            int share = part / elig.size();
            int rest = part - share * elig.size();
            for (int e : elig) {
                won[e] += share;
            }
            won[elig.get(0)] += rest;
            prev = level;
        }
        StringBuilder sb = new StringBuilder(boardText()).append("\n\n");
        for (int i = 0; i < n; i++) {
            stack()[i] += won[i];
            if (!inHand[i]) {
                continue;
            }
            sb.append(seats.names[i]).append("   ");
            if (folded[i]) {
                sb.append("folded");
            } else {
                sb.append(cardText(hole[i][0])).append(' ').append(cardText(hole[i][1])).append("   ")
                        .append(HANDS[score[i] / SCALE]);
            }
            int net = won[i] - contrib[i];
            sb.append("   ").append(net >= 0 ? "+" : "").append(net).append('\n');
        }
        endHand(sb.toString().trim());
    }

    private void endHand(String body) {
        seats.save();
        render();
        Sfx.play(Sfx.WIN);
        int alive = 0;
        for (int s : stack()) {
            if (s > 0) {
                alive++;
            }
        }
        if (alive < 2) {
            gameOver(body);
            return;
        }
        showChoice("HAND " + handNo, body, new String[] {"NEXT HAND", "END GAME"},
                new Runnable[] {this::startHand, () -> gameOver("")});
    }

    // ------------------------------------------------------------------ drawing

    private void render() {
        header.setText("HAND " + Math.max(1, handNo) + "  ·  " + STREETS[street] + "  ·  POT " + pot());
        boardRow.removeAllViews();
        for (int i = 0; i < 5; i++) {
            boardRow.addView(i < revealed ? card(board[i], 46) : back(46));
        }
        table.removeAllViews();
        for (int i = 0; i < n; i++) {
            StringBuilder s = new StringBuilder();
            s.append(i == toAct ? "▶ " : "  ").append(seats.names[i]).append("   ").append(stack()[i]);
            if (streetBet[i] > 0) {
                s.append("   bet ").append(streetBet[i]);
            }
            if (i == dealer) {
                s.append("   (D)");
            }
            if (!inHand[i] && handNo > 0) {
                s.append("   out");
            } else if (folded[i]) {
                s.append("   folded");
            } else if (allIn[i]) {
                s.append("   ALL IN");
            }
            TextView t = label(s.toString(), 11f, i == toAct ? Theme.TEXT : Theme.DIM);
            t.setGravity(Gravity.START);
            t.setPadding(0, dp(3), 0, dp(3));
            table.addView(t, wide());
        }
        youRow.removeAllViews();
        raiseRow.removeAllViews();
        actions.removeAllViews();
        if (!myTurn()) {
            youLabel.setText(toAct >= 0 ? seats.names[toAct] + "'S TURN" : "");
            return;
        }
        int i = toAct;
        youRow.addView(card(hole[i][0], 60));
        youRow.addView(card(hole[i][1], 60));
        String hand = revealed >= 3 ? "   ·   " + HANDS[GamePoker.best(withBoard(hole[i], board, revealed)) / SCALE] : "";
        youLabel.setText(seats.names[i] + "'S CARDS" + hand);
        int toCall = currentBet - streetBet[i];
        for (int k = 0; k < RAISES.length; k++) {
            final int idx = k;
            TextView c = button("+" + Upgrades.chipName(RAISES[k]), () -> {
                raiseIdx = idx;
                render();
            });
            c.setTextSize(10f);
            c.setPadding(dp(2), dp(8), dp(2), dp(8));
            if (k == raiseIdx) {
                c.setTextColor(Theme.BG);
                c.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
            }
            raiseRow.addView(c, weight());
        }
        actions.addView(button("FOLD", this::fold), weight());
        actions.addView(button(toCall > 0 ? "CALL " + Math.min(toCall, stack()[i]) : "CHECK", this::call), weight());
        if (stack()[i] > toCall) {
            actions.addView(button("RAISE", this::raise), weight());
        }
        TextView all = button("ALL IN", this::allInNow);
        all.setTextColor(0xFFFF6B7F);
        actions.addView(all, weight());
    }
}
