package app.novaos;

import android.widget.LinearLayout;

import java.util.List;

/** SCENES: one tap chips to switch scene. */
final class ScenesWidget extends NovaWidget {
    ScenesWidget(NovaActivity host) {
        super(host);
    }

    @Override
    void refresh() {
        removeAllViews();
        addView(text("SCENES  " + Scenes.status(), 9f, Theme.DIM), wide());
        List<Scenes.Scene> all = Scenes.all();
        LinearLayout r = null;
        for (int i = 0; i < all.size(); i++) {
            if (i % 3 == 0) {
                r = row();
                addView(r, wide());
            }
            final int idx = i;
            android.widget.TextView c = chip(all.get(i).emoji + " " + all.get(i).name, () -> {
                Scenes.apply(host, idx);
                refresh();
            });
            pick(c, Scenes.activeIndex() == i);
            r.addView(c, weight(1f));
        }
        addView(chip("EDIT SCENES", () -> host.showOverlay(new ScenesScreen(host))), wide());
    }
}
