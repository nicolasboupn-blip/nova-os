package app.novaos;

import android.os.SystemClock;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/**
 * Pass-the-phone duel for 2 to 4 players, best of three rounds. Every round each player takes a turn with the phone.
 * REACTION: tap the moment the screen turns green, quickest wins the round. Tapping early costs that turn.
 * TAP RACE: after a countdown, tap as fast as you can for five seconds, most taps wins the round.
 */
final class GameDuel extends Game {
    private static final int ROUNDS = 3;
    private static final int REACTION = 0, TAP_RACE = 1;
    private static final int SETUP = 0, HANDOFF = 1, WAIT = 2, GO = 3, BUSY = 4, TAPPING = 5, DONE = 6;
    private static final int EARLY_MS = 999;

    private final Random rnd = new Random();
    private final TextView info;
    private final TextView stage;
    private final LinearLayout setupBox;
    private final TextView[] countBtns = new TextView[3];
    private final TextView[] modeBtns = new TextView[2];
    private final TextView startBtn;
    private int players = 2;
    private int mode = REACTION;
    private int phase = SETUP;
    private int round;
    private int turn;
    private int[][] res;
    private int taps;
    private long goAt;

    private final Runnable turnGreen;

    GameDuel(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(60), dp(20), dp(24));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        info = label("PASS THE PHONE", 12f, Theme.DIM);
        col.addView(info, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        stage = label("", 22f, Theme.TEXT);
        stage.setLetterSpacing(0.08f);
        stage.setClickable(true);
        stage.setOnClickListener(v -> stageTap());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = dp(16);
        col.addView(stage, sp);

        setupBox = new LinearLayout(host);
        setupBox.setOrientation(LinearLayout.VERTICAL);
        setupBox.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout counts = new LinearLayout(host);
        counts.setGravity(Gravity.CENTER);
        String[] countLabels = {"2 PLAYERS", "3 PLAYERS", "4 PLAYERS"};
        for (int i = 0; i < 3; i++) {
            final int n = i + 2;
            countBtns[i] = button(countLabels[i], () -> {
                players = n;
                refreshSetup();
            });
            counts.addView(countBtns[i], weight());
        }
        setupBox.addView(counts, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout modes = new LinearLayout(host);
        modes.setGravity(Gravity.CENTER);
        modeBtns[REACTION] = button("REACTION", () -> {
            mode = REACTION;
            refreshSetup();
        });
        modeBtns[TAP_RACE] = button("TAP RACE", () -> {
            mode = TAP_RACE;
            refreshSetup();
        });
        modes.addView(modeBtns[REACTION], weight());
        modes.addView(modeBtns[TAP_RACE], weight());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mp.topMargin = dp(10);
        setupBox.addView(modes, mp);
        startBtn = button("START", this::start);
        startBtn.setTextColor(Theme.BG);
        startBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(12);
        setupBox.addView(startBtn, stp);
        col.addView(setupBox, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        turnGreen = () -> {
            phase = GO;
            goAt = SystemClock.elapsedRealtime();
            stage.setText("TAP!");
            stage.setBackground(Theme.rounded(0xFF1E7A4A, 28f, host));
            Sfx.play(Sfx.BLIP);
            host.buzz(20);
        };
        stage.setText("CHOOSE HOW MANY PLAY\nAND HOW TO PLAY");
        refreshSetup();
    }

    @Override
    String title() {
        return "DUEL";
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private void refreshSetup() {
        for (int i = 0; i < 3; i++) {
            boolean on = i + 2 == players;
            countBtns[i].setBackground(Theme.rounded(on ? Theme.ACCENT : Theme.PANEL, 16f, host));
            countBtns[i].setTextColor(on ? Theme.BG : Theme.ACCENT);
        }
        for (int i = 0; i < 2; i++) {
            boolean on = i == mode;
            modeBtns[i].setBackground(Theme.rounded(on ? Theme.ACCENT : Theme.PANEL, 16f, host));
            modeBtns[i].setTextColor(on ? Theme.BG : Theme.ACCENT);
        }
    }

    private void start() {
        res = new int[ROUNDS][players];
        round = 0;
        turn = 0;
        setupBox.setVisibility(GONE);
        nextHandoff();
    }

    private void nextHandoff() {
        phase = HANDOFF;
        info.setText("ROUND " + (round + 1) + " OF " + ROUNDS + "  ·  PLAYER " + (turn + 1) + " OF " + players);
        stage.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
        stage.setText("PASS THE PHONE\nTO PLAYER " + (turn + 1) + "\n\ntap when ready");
    }

    private void stageTap() {
        switch (phase) {
            case HANDOFF:
                if (mode == REACTION) {
                    phase = WAIT;
                    stage.setText("WAIT FOR GREEN...");
                    stage.setBackground(Theme.rounded(0xFF5A1A2A, 28f, host));
                    h.postDelayed(turnGreen, 1200 + rnd.nextInt(2600));
                } else {
                    phase = BUSY;
                    taps = 0;
                    countdown(3);
                }
                break;
            case WAIT:
                h.removeCallbacks(turnGreen);
                res[round][turn] = EARLY_MS;
                phase = BUSY;
                stage.setText("TOO SOON\n" + EARLY_MS + " ms");
                Sfx.play(Sfx.LOSE);
                host.buzz(40);
                h.postDelayed(this::advance, 1000);
                break;
            case GO:
                int ms = (int) (SystemClock.elapsedRealtime() - goAt);
                res[round][turn] = ms;
                phase = BUSY;
                stage.setText(ms + " ms");
                Sfx.play(Sfx.CLICK);
                h.postDelayed(this::advance, 1100);
                break;
            case TAPPING:
                taps++;
                stage.setText(String.valueOf(taps));
                Sfx.play(Sfx.CLICK);
                break;
            default:
                break;
        }
    }

    private void countdown(final int n) {
        if (n == 0) {
            stage.setText("GO!");
            Sfx.play(Sfx.WIN);
            phase = TAPPING;
            taps = 0;
            h.postDelayed(this::endTapping, 5000);
            return;
        }
        stage.setText(String.valueOf(n));
        Sfx.play(Sfx.BLIP);
        h.postDelayed(() -> countdown(n - 1), 800);
    }

    private void endTapping() {
        phase = BUSY;
        res[round][turn] = taps;
        stage.setText(taps + " taps");
        h.postDelayed(this::advance, 1100);
    }

    private void advance() {
        turn++;
        if (turn >= players) {
            turn = 0;
            round++;
        }
        if (round >= ROUNDS) {
            finish();
        } else {
            nextHandoff();
        }
    }

    private void finish() {
        phase = DONE;
        int[] wins = new int[players];
        for (int r = 0; r < ROUNDS; r++) {
            int best = 0;
            for (int p = 1; p < players; p++) {
                boolean better = mode == REACTION ? res[r][p] < res[r][best] : res[r][p] > res[r][best];
                if (better) {
                    best = p;
                }
            }
            wins[best]++;
        }
        int top = 0;
        for (int p = 1; p < players; p++) {
            if (wins[p] > wins[top]) {
                top = p;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("PLAYER ").append(top + 1).append(" WINS!\n\n");
        for (int p = 0; p < players; p++) {
            sb.append("PLAYER ").append(p + 1).append("   ").append(wins[p]).append(" round")
                    .append(wins[p] == 1 ? "" : "s");
            if (p < players) {
                sb.append("   ");
                int sum = 0;
                for (int r = 0; r < ROUNDS; r++) {
                    sum += mode == REACTION ? res[r][p] : res[r][p];
                }
                sb.append(mode == REACTION ? "avg " + (sum / ROUNDS) + " ms" : sum + " taps");
            }
            sb.append('\n');
        }
        stage.setText(sb.toString().trim());
        stage.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
        info.setText("DUEL OVER");
        setupBox.setVisibility(VISIBLE);
        startBtn.setText("PLAY AGAIN");
        Sfx.play(Sfx.WIN);
        host.buzz(60);
        int[] at = new int[2];
        getLocationOnScreen(at);
        host.confetti(at[0] + getWidth() / 2f, at[1] + getHeight() * 0.4f);
    }
}
