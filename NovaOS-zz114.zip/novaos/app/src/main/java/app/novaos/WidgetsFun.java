package app.novaos;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Everyday and fun widgets: counter, habits, water, breathe, metronome, 8 ball, decider, tic-tac-toe, math,
 *  morse, sketch and a quote of the day. */
final class WidgetsFun {
    private WidgetsFun() {
    }

    /** Days since 1970 in local time, so "today" changes at local midnight. */
    static long today() {
        long now = System.currentTimeMillis();
        return (now + java.util.TimeZone.getDefault().getOffset(now)) / 86400000L;
    }

    static void rename(NovaActivity host, String title, String current, java.util.function.Consumer<String> done) {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setText(current);
        e.setFilters(new InputFilter[] {new InputFilter.LengthFilter(18)});
        new AlertDialog.Builder(host).setTitle(title).setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) {
                        done.accept(s.toUpperCase(Locale.ROOT));
                    }
                })
                .setNegativeButton("CANCEL", null).show();
    }

    // ================================================================== COUNTER

    static final class Counter extends NovaWidget {
        private final TextView name;
        private final TextView value;

        Counter(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            name = text("", 10f, Theme.DIM);
            name.setClickable(true);
            name.setOnClickListener(v -> rename(host, "Counter name", Prefs.getString("w_count_name", "COUNTER"),
                    s -> {
                        Prefs.putString("w_count_name", s);
                        refresh();
                    }));
            addView(name, wide());
            value = text("", 38f, Theme.TEXT);
            addView(value, fill());
            LinearLayout r = row();
            r.addView(chip("−", () -> add(-1)), weight(1f));
            TextView plus = chip("+1", () -> add(1));
            plus.setTextSize(14f);
            r.addView(plus, weight(2f));
            r.addView(chip("RESET", () -> new AlertDialog.Builder(host).setTitle("Reset the counter?")
                    .setPositiveButton("RESET", (d, w) -> {
                        Prefs.putInt("w_count", 0);
                        refresh();
                    }).setNegativeButton("CANCEL", null).show()), weight(1f));
            addView(r, wide());
        }

        private void add(int d) {
            Prefs.putInt("w_count", Prefs.getInt("w_count", 0) + d);
            Sfx.play(Sfx.CLICK);
            refresh();
            ObjectAnimator.ofFloat(value, View.SCALE_X, 1.15f, 1f).setDuration(160).start();
            ObjectAnimator.ofFloat(value, View.SCALE_Y, 1.15f, 1f).setDuration(160).start();
        }

        @Override
        void refresh() {
            name.setText(Prefs.getString("w_count_name", "COUNTER") + "  ✎");
            value.setText(String.valueOf(Prefs.getInt("w_count", 0)));
        }
    }

    // ================================================================== HABITS

    static final class Habits extends NovaWidget {
        private static final String[] DEFAULTS = {"WORKOUT", "READ", "LEARN"};
        private final TextView[] names = new TextView[3];
        private final Week[] weeks = new Week[3];
        private final TextView[] streaks = new TextView[3];

        Habits(NovaActivity host) {
            super(host);
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                LinearLayout r = row();
                r.setPadding(dp(6), 0, dp(6), 0);
                r.setClickable(true);
                Theme.ripple(r);
                r.setOnClickListener(v -> toggle(idx));
                r.setOnLongClickListener(v -> {
                    rename(host, "Habit name", name(idx), s -> {
                        Prefs.putString("habit_n" + idx, s);
                        refresh();
                    });
                    return true;
                });
                names[i] = text("", 10f, Theme.TEXT);
                names[i].setGravity(Gravity.START);
                names[i].setSingleLine(true);
                r.addView(names[i], new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
                weeks[i] = new Week(host);
                r.addView(weeks[i], new LinearLayout.LayoutParams(dp(84), dp(14)));
                streaks[i] = text("", 10f, Theme.ACCENT);
                r.addView(streaks[i], new LinearLayout.LayoutParams(dp(34), LayoutParams.WRAP_CONTENT));
                addView(r, fill());
            }
            addView(text("tap = done today · hold = rename", 8f, Theme.DIM), wide());
        }

        private String name(int i) {
            return Prefs.getString("habit_n" + i, DEFAULTS[i]);
        }

        private List<Long> days(int i) {
            List<Long> out = new ArrayList<>();
            String raw = Prefs.getString("habit_d" + i, "");
            if (raw != null && !raw.isEmpty()) {
                for (String s : raw.split(",")) {
                    try {
                        out.add(Long.parseLong(s));
                    } catch (NumberFormatException ignored) {
                        // skip
                    }
                }
            }
            return out;
        }

        private void toggle(int i) {
            List<Long> d = days(i);
            long t = today();
            if (d.contains(t)) {
                d.remove(t);
            } else {
                d.add(t);
                Sfx.play(Sfx.COIN);
            }
            StringBuilder b = new StringBuilder();
            for (long x : d) {
                if (x > t - 120) {
                    b.append(b.length() == 0 ? "" : ",").append(x);
                }
            }
            Prefs.putString("habit_d" + i, b.toString());
            refresh();
        }

        @Override
        void refresh() {
            long t = today();
            for (int i = 0; i < 3; i++) {
                List<Long> d = days(i);
                names[i].setText(name(i));
                boolean[] last = new boolean[7];
                for (int k = 0; k < 7; k++) {
                    last[k] = d.contains(t - 6 + k);
                }
                weeks[i].set(last);
                long day = d.contains(t) ? t : t - 1;
                int streak = 0;
                while (d.contains(day)) {
                    streak++;
                    day--;
                }
                streaks[i].setText(streak > 0 ? streak + "🔥" : "");
            }
        }

        private static final class Week extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private boolean[] done = new boolean[7];

            Week(Context c) {
                super(c);
            }

            void set(boolean[] d) {
                done = d;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float step = getWidth() / 7f;
                float r = Math.min(step, getHeight()) * 0.36f;
                for (int k = 0; k < 7; k++) {
                    p.setColor(done[k] ? Theme.ACCENT : 0x26FFFFFF);
                    c.drawCircle(step * k + step / 2f, getHeight() / 2f, k == 6 ? r * 1.2f : r, p);
                }
            }
        }
    }

    // ================================================================== WATER

    static final class Water extends NovaWidget {
        private static final int GOAL = 8;
        private final Glasses glasses;
        private final TextView label;

        Water(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            glasses = new Glasses(host);
            addView(glasses, fill());
            label = text("", 12f, Theme.TEXT);
            addView(label, wide());
            LinearLayout r = row();
            r.addView(chip("+ GLASS", () -> add(1)), weight(2f));
            r.addView(chip("UNDO", () -> add(-1)), weight(1f));
            addView(r, wide());
        }

        private int count() {
            return Prefs.getInt("water_day", 0) == (int) today() ? Prefs.getInt("water_n", 0) : 0;
        }

        private void add(int d) {
            int n = Math.max(0, Math.min(20, count() + d));
            Prefs.putInt("water_day", (int) today());
            Prefs.putInt("water_n", n);
            if (d > 0) {
                Sfx.play(n == GOAL ? Sfx.WIN : Sfx.BLIP);
            }
            refresh();
        }

        @Override
        void refresh() {
            int n = count();
            glasses.set(n);
            label.setText(n + " / " + GOAL + " glasses today" + (n >= GOAL ? "  ✓" : ""));
        }

        private static final class Glasses extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF r = new RectF();
            private int n;

            Glasses(Context c) {
                super(c);
            }

            void set(int count) {
                n = count;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float gap = getWidth() * 0.02f;
                float w = (getWidth() - gap * (GOAL + 1)) / GOAL;
                float h = Math.min(getHeight() * 0.8f, w * 1.6f);
                float top = (getHeight() - h) / 2f;
                for (int i = 0; i < GOAL; i++) {
                    float x = gap + i * (w + gap);
                    r.set(x, top, x + w, top + h);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0x1AFFFFFF);
                    c.drawRoundRect(r, w * 0.2f, w * 0.2f, p);
                    if (i < n) {
                        r.set(x, top + h * 0.25f, x + w, top + h);
                        p.setColor(0xFF4FB3FF);
                        c.drawRoundRect(r, w * 0.2f, w * 0.2f, p);
                    }
                }
            }
        }
    }

    // ================================================================== BREATHE

    static final class Breathe extends NovaWidget {
        private final Orb orb;
        private final TextView label;

        Breathe(NovaActivity host) {
            super(host);
            orb = new Orb(host);
            label = text("tap the circle to start · box breathing 4-4-4-4", 9f, Theme.DIM);
            orb.setClickable(true);
            orb.setOnClickListener(v -> {
                orb.toggle();
                label.setText(orb.running ? "" : "tap the circle to start");
            });
            addView(orb, fill());
            addView(label, wide());
        }

        @Override
        void onLive(boolean on) {
            if (!on && orb.running) {
                orb.toggle();
                label.setText("tap the circle to start");
            }
        }

        private static final class Orb extends View {
            private static final String[] STEP = {"BREATHE IN", "HOLD", "BREATHE OUT", "HOLD"};
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            boolean running;
            private long start;

            Orb(Context c) {
                super(c);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Theme.MONO);
            }

            void toggle() {
                running = !running;
                start = SystemClock.uptimeMillis();
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float max = Math.min(cx, cy) * 0.92f;
                float size;
                String word;
                int left;
                if (running) {
                    long t = (SystemClock.uptimeMillis() - start) % 16000;
                    int step = (int) (t / 4000);
                    float f = (t % 4000) / 4000f;
                    float ease = (float) (0.5 - 0.5 * Math.cos(Math.PI * f));
                    size = step == 0 ? ease : step == 1 ? 1f : step == 2 ? 1f - ease : 0f;
                    word = STEP[step];
                    left = 4 - (int) ((t % 4000) / 1000);
                    postInvalidateOnAnimation();
                } else {
                    size = 0.4f;
                    word = "BREATHE";
                    left = 0;
                }
                float r = max * (0.35f + 0.65f * size);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x33000000);
                c.drawCircle(cx, cy, r, p);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x88000000);
                c.drawCircle(cx, cy, r * 0.7f, p);
                p.setColor(Theme.TEXT);
                p.setTextSize(max * 0.16f);
                c.drawText(word, cx, cy, p);
                if (left > 0) {
                    p.setTextSize(max * 0.2f);
                    c.drawText(String.valueOf(left), cx, cy + max * 0.26f, p);
                }
            }
        }
    }

    // ================================================================== METRONOME

    static final class Metronome extends NovaWidget {
        private final TextView bpmText;
        private final TextView startBtn;
        private final Dots dots;
        private final List<Long> taps = new ArrayList<>();
        private boolean running;
        private int beat;
        private long next;
        private final Runnable click = new Runnable() {
            @Override
            public void run() {
                if (!running) {
                    return;
                }
                Sfx.play(beat % 4 == 0 ? Sfx.BLIP : Sfx.CLICK);
                dots.set(beat % 4);
                beat++;
                next += 60000L / bpm();
                ui.postAtTime(this, next);
            }
        };

        Metronome(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            bpmText = text("", 26f, Theme.TEXT);
            addView(bpmText, wide());
            dots = new Dots(host);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(120), dp(16));
            dlp.gravity = Gravity.CENTER_HORIZONTAL;
            dlp.topMargin = dp(4);
            addView(dots, dlp);
            LinearLayout r1 = row();
            r1.addView(chip("−5", () -> change(-5)), weight(1f));
            r1.addView(chip("−1", () -> change(-1)), weight(1f));
            r1.addView(chip("+1", () -> change(1)), weight(1f));
            r1.addView(chip("+5", () -> change(5)), weight(1f));
            LinearLayout.LayoutParams lp1 = wide();
            lp1.topMargin = dp(6);
            addView(r1, lp1);
            LinearLayout r2 = row();
            r2.addView(chip("TAP", this::tap), weight(1f));
            startBtn = chip("START", this::toggle);
            r2.addView(startBtn, weight(1f));
            addView(r2, wide());
            show();
        }

        private int bpm() {
            return Math.max(30, Math.min(240, Prefs.getInt("metro_bpm", 100)));
        }

        private void change(int d) {
            Prefs.putInt("metro_bpm", bpm() + d);
            show();
        }

        private void tap() {
            long now = SystemClock.uptimeMillis();
            if (!taps.isEmpty() && now - taps.get(taps.size() - 1) > 2000) {
                taps.clear();
            }
            taps.add(now);
            if (taps.size() > 5) {
                taps.remove(0);
            }
            if (taps.size() >= 2) {
                long span = taps.get(taps.size() - 1) - taps.get(0);
                Prefs.putInt("metro_bpm", Math.round(60000f * (taps.size() - 1) / span));
            }
            Sfx.play(Sfx.CLICK);
            show();
        }

        private void toggle() {
            running = !running;
            ui.removeCallbacks(click);
            if (running) {
                beat = 0;
                next = SystemClock.uptimeMillis();
                ui.post(click);
            } else {
                dots.set(-1);
            }
            show();
        }

        private void show() {
            bpmText.setText(bpm() + " BPM");
            startBtn.setText(running ? "STOP" : "START");
            pick(startBtn, running);
        }

        @Override
        void onLive(boolean on) {
            if (!on && running) {
                toggle();
            }
        }

        private static final class Dots extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private int on = -1;

            Dots(Context c) {
                super(c);
            }

            void set(int i) {
                on = i;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float step = getWidth() / 4f;
                float r = Math.min(step, getHeight()) * 0.35f;
                for (int i = 0; i < 4; i++) {
                    p.setColor(i == on ? (i == 0 ? Theme.ACCENT : Theme.TEXT) : 0x26FFFFFF);
                    c.drawCircle(step * i + step / 2f, getHeight() / 2f, i == 0 ? r * 1.2f : r, p);
                }
            }
        }
    }

    // ================================================================== MAGIC 8 BALL

    static final class EightBall extends NovaWidget {
        private static final String[] ANSWERS = {"It is certain.", "It is decidedly so.", "Without a doubt.",
            "Yes, definitely.", "You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.", "Yes.",
            "Signs point to yes.", "Reply hazy, try again.", "Ask again later.", "Better not tell you now.",
            "Cannot predict now.", "Concentrate and ask again.", "Don't count on it.", "My reply is no.",
            "My sources say no.", "Outlook not so good.", "Very doubtful."};
        private final Random rnd = new Random();
        private final Ball ball;
        private final TextView hint;

        EightBall(NovaActivity host) {
            super(host);
            ball = new Ball(host);
            ball.setClickable(true);
            ball.setOnClickListener(v -> shake());
            addView(ball, fill());
            hint = text("ask a yes/no question, then tap the ball", 9f, Theme.DIM);
            addView(hint, wide());
        }

        private void shake() {
            ball.set("");
            ObjectAnimator a = ObjectAnimator.ofFloat(ball, View.TRANSLATION_X, 0, -18, 18, -12, 12, -6, 6, 0);
            a.setDuration(600);
            a.start();
            host.buzz(40);
            ui.postDelayed(() -> {
                ball.set(ANSWERS[rnd.nextInt(ANSWERS.length)]);
                Sfx.play(Sfx.BLIP);
            }, 650);
        }

        private static final class Ball extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Path tri = new Path();
            private String answer = "";

            Ball(Context c) {
                super(c);
                p.setTextAlign(Paint.Align.CENTER);
            }

            void set(String a) {
                answer = a;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) * 0.94f;
                if (r <= 0) {
                    return;
                }
                p.setColor(0xFF0B0B10);
                c.drawCircle(cx, cy, r, p);
                p.setColor(0x22FFFFFF);
                c.drawCircle(cx - r * 0.35f, cy - r * 0.4f, r * 0.25f, p);
                float wr = r * 0.52f;
                p.setColor(0xFF15153A);
                c.drawCircle(cx, cy, wr, p);
                if (answer.isEmpty()) {
                    p.setColor(0xFFFFFFFF);
                    p.setTextSize(r * 0.5f);
                    c.drawText("8", cx, cy + p.getTextSize() * 0.35f, p);
                    return;
                }
                tri.reset();
                tri.moveTo(cx, cy + wr * 0.85f);
                tri.lineTo(cx - wr * 0.8f, cy - wr * 0.5f);
                tri.lineTo(cx + wr * 0.8f, cy - wr * 0.5f);
                tri.close();
                p.setColor(0xFF2E5BFF);
                c.drawPath(tri, p);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(wr * 0.16f);
                String[] words = answer.split(" ");
                List<String> lines = new ArrayList<>();
                StringBuilder line = new StringBuilder();
                for (String w : words) {
                    if (line.length() + w.length() > 10 && line.length() > 0) {
                        lines.add(line.toString());
                        line.setLength(0);
                    }
                    line.append(line.length() == 0 ? "" : " ").append(w);
                }
                lines.add(line.toString());
                float lh = p.getTextSize() * 1.15f;
                float y = cy - wr * 0.15f - (lines.size() - 1) * lh / 2f + p.getTextSize() * 0.35f;
                for (String l : lines) {
                    c.drawText(l, cx, y, p);
                    y += lh;
                }
            }
        }
    }

    // ================================================================== DECIDER

    static final class Decider extends NovaWidget {
        private static final String[] MODES = {"YES/NO", "COIN", "DICE", "1-100"};
        private final Random rnd = new Random();
        private final TextView result;
        private final TextView[] chips = new TextView[MODES.length];
        private int mode;
        private boolean rolling;

        Decider(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            mode = Math.max(0, Math.min(3, Prefs.getInt("decider_mode", 0)));
            result = text("?", 32f, Theme.TEXT);
            result.setClickable(true);
            result.setOnClickListener(v -> roll());
            addView(result, fill());
            LinearLayout r = row();
            for (int i = 0; i < MODES.length; i++) {
                final int m = i;
                chips[i] = chip(MODES[i], () -> {
                    mode = m;
                    Prefs.putInt("decider_mode", m);
                    styleChips();
                    roll();
                });
                r.addView(chips[i], weight(1f));
            }
            addView(r, wide());
            addView(chip("DECIDE", this::roll), wide());
            styleChips();
        }

        private void styleChips() {
            for (int i = 0; i < MODES.length; i++) {
                pick(chips[i], i == mode);
            }
        }

        private String value() {
            switch (mode) {
                case 0:
                    return rnd.nextBoolean() ? "YES" : "NO";
                case 1:
                    return rnd.nextBoolean() ? "HEADS" : "TAILS";
                case 2:
                    return "⚀⚁⚂⚃⚄⚅".substring(0, 6).charAt(rnd.nextInt(6)) + "";
                default:
                    return String.valueOf(1 + rnd.nextInt(100));
            }
        }

        private void roll() {
            if (rolling) {
                return;
            }
            rolling = true;
            for (int i = 0; i < 9; i++) {
                final boolean last = i == 8;
                ui.postDelayed(() -> {
                    result.setText(value());
                    Sfx.play(last ? Sfx.COIN : Sfx.CLICK);
                    if (last) {
                        rolling = false;
                        ObjectAnimator.ofFloat(result, View.SCALE_X, 1.3f, 1f).setDuration(220).start();
                        ObjectAnimator.ofFloat(result, View.SCALE_Y, 1.3f, 1f).setDuration(220).start();
                    }
                }, 60L * i + i * i * 6L);
            }
        }
    }

    // ================================================================== TIC-TAC-TOE

    static final class TicTacToe extends NovaWidget {
        private final Random rnd = new Random();
        private final Board board;
        private final TextView status;
        private final int[] cells = new int[9]; // 0 empty, 1 you (X), 2 cpu (O)
        private boolean over;

        TicTacToe(NovaActivity host) {
            super(host);
            board = new Board(host);
            addView(board, fill());
            status = text("", 10f, Theme.DIM);
            addView(status, wide());
            show("your move (X)");
        }

        private void show(String s) {
            status.setText(s + "   ·   you " + Prefs.getInt("ttt_w", 0) + "  cpu " + Prefs.getInt("ttt_l", 0)
                    + "  draw " + Prefs.getInt("ttt_d", 0));
            board.invalidate();
        }

        void tapCell(int i) {
            if (over) {
                java.util.Arrays.fill(cells, 0);
                over = false;
                show("your move (X)");
                return;
            }
            if (cells[i] != 0) {
                return;
            }
            cells[i] = 1;
            Sfx.play(Sfx.CLICK);
            if (end()) {
                return;
            }
            int m = rnd.nextInt(100) < 25 ? randomMove() : bestMove();
            cells[m] = 2;
            if (!end()) {
                show("your move (X)");
            }
        }

        private boolean end() {
            int w = winner(cells);
            boolean full = true;
            for (int c : cells) {
                if (c == 0) {
                    full = false;
                }
            }
            if (w == 0 && !full) {
                return false;
            }
            over = true;
            if (w == 1) {
                Prefs.putInt("ttt_w", Prefs.getInt("ttt_w", 0) + 1);
                Sfx.play(Sfx.WIN);
                show("you win! tap to play again");
            } else if (w == 2) {
                Prefs.putInt("ttt_l", Prefs.getInt("ttt_l", 0) + 1);
                Sfx.play(Sfx.LOSE);
                show("cpu wins. tap to play again");
            } else {
                Prefs.putInt("ttt_d", Prefs.getInt("ttt_d", 0) + 1);
                show("draw. tap to play again");
            }
            return true;
        }

        private static final int[][] LINES = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
            {0, 4, 8}, {2, 4, 6}};

        private static int winner(int[] b) {
            for (int[] l : LINES) {
                if (b[l[0]] != 0 && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) {
                    return b[l[0]];
                }
            }
            return 0;
        }

        private int randomMove() {
            List<Integer> free = new ArrayList<>();
            for (int i = 0; i < 9; i++) {
                if (cells[i] == 0) {
                    free.add(i);
                }
            }
            return free.get(rnd.nextInt(free.size()));
        }

        private int bestMove() {
            int best = -1;
            int bestScore = Integer.MIN_VALUE;
            for (int i = 0; i < 9; i++) {
                if (cells[i] == 0) {
                    cells[i] = 2;
                    int s = minimax(false, 0);
                    cells[i] = 0;
                    if (s > bestScore) {
                        bestScore = s;
                        best = i;
                    }
                }
            }
            return best;
        }

        private int minimax(boolean cpuTurn, int depth) {
            int w = winner(cells);
            if (w == 2) {
                return 10 - depth;
            }
            if (w == 1) {
                return depth - 10;
            }
            boolean any = false;
            int best = cpuTurn ? Integer.MIN_VALUE : Integer.MAX_VALUE;
            for (int i = 0; i < 9; i++) {
                if (cells[i] == 0) {
                    any = true;
                    cells[i] = cpuTurn ? 2 : 1;
                    int s = minimax(!cpuTurn, depth + 1);
                    cells[i] = 0;
                    best = cpuTurn ? Math.max(best, s) : Math.min(best, s);
                }
            }
            return any ? best : 0;
        }

        private final class Board extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Board(Context c) {
                super(c);
                p.setStrokeCap(Paint.Cap.ROUND);
            }

            private float side() {
                return Math.min(getWidth(), getHeight()) * 0.96f;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    float s = side();
                    float x0 = (getWidth() - s) / 2f;
                    float y0 = (getHeight() - s) / 2f;
                    int cx = (int) ((e.getX() - x0) / (s / 3f));
                    int cy = (int) ((e.getY() - y0) / (s / 3f));
                    if (cx >= 0 && cx < 3 && cy >= 0 && cy < 3) {
                        tapCell(cy * 3 + cx);
                    } else if (over) {
                        tapCell(0);
                    }
                    return true;
                }
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                float s = side();
                float x0 = (getWidth() - s) / 2f;
                float y0 = (getHeight() - s) / 2f;
                float cell = s / 3f;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s * 0.015f);
                p.setColor(0x44FFFFFF);
                for (int i = 1; i < 3; i++) {
                    c.drawLine(x0 + cell * i, y0 + cell * 0.1f, x0 + cell * i, y0 + s - cell * 0.1f, p);
                    c.drawLine(x0 + cell * 0.1f, y0 + cell * i, x0 + s - cell * 0.1f, y0 + cell * i, p);
                }
                p.setStrokeWidth(s * 0.03f);
                for (int i = 0; i < 9; i++) {
                    float cx = x0 + (i % 3) * cell + cell / 2f;
                    float cy = y0 + (i / 3) * cell + cell / 2f;
                    float r = cell * 0.27f;
                    if (cells[i] == 1) {
                        p.setColor(Theme.ACCENT);
                        c.drawLine(cx - r, cy - r, cx + r, cy + r, p);
                        c.drawLine(cx + r, cy - r, cx - r, cy + r, p);
                    } else if (cells[i] == 2) {
                        p.setColor(Theme.TEXT);
                        c.drawCircle(cx, cy, r, p);
                    }
                }
            }
        }
    }

    // ================================================================== MATH QUIZ

    static final class MathQuiz extends NovaWidget {
        private final Random rnd = new Random();
        private final TextView question;
        private final TextView score;
        private final TextView[] options = new TextView[4];
        private int answer;
        private int streak;
        private boolean waiting;

        MathQuiz(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            question = text("", 22f, Theme.TEXT);
            addView(question, fill());
            for (int r = 0; r < 2; r++) {
                LinearLayout line = row();
                for (int c = 0; c < 2; c++) {
                    final int idx = r * 2 + c;
                    options[idx] = chip("", () -> answer(idx));
                    options[idx].setTextSize(13f);
                    line.addView(options[idx], weight(1f));
                }
                addView(line, wide());
            }
            score = text("", 9f, Theme.DIM);
            addView(score, wide());
            next();
        }

        private void next() {
            waiting = false;
            int level = 1 + streak / 4;
            int max = 10 + level * 8;
            int op = rnd.nextInt(level >= 3 ? 4 : 3);
            int a = 2 + rnd.nextInt(max);
            int b = 2 + rnd.nextInt(max);
            String sign;
            switch (op) {
                case 0:
                    answer = a + b;
                    sign = "+";
                    break;
                case 1:
                    if (b > a) {
                        int t = a;
                        a = b;
                        b = t;
                    }
                    answer = a - b;
                    sign = "−";
                    break;
                case 2:
                    a = 2 + rnd.nextInt(Math.min(12, 4 + level * 2));
                    b = 2 + rnd.nextInt(Math.min(12, 4 + level * 2));
                    answer = a * b;
                    sign = "×";
                    break;
                default:
                    b = 2 + rnd.nextInt(10);
                    answer = 2 + rnd.nextInt(12);
                    a = answer * b;
                    sign = "÷";
                    break;
            }
            question.setText(a + " " + sign + " " + b);
            question.setTextColor(Theme.TEXT);
            int right = rnd.nextInt(4);
            List<Integer> used = new ArrayList<>();
            used.add(answer);
            for (int i = 0; i < 4; i++) {
                int v;
                if (i == right) {
                    v = answer;
                } else {
                    do {
                        v = answer + (rnd.nextInt(11) - 5) * (rnd.nextBoolean() ? 1 : Math.max(1, answer / 10));
                    } while (used.contains(v) || v < 0);
                    used.add(v);
                }
                options[i].setText(String.valueOf(v));
                options[i].setTag(v);
                pick(options[i], false);
            }
            score.setText("streak " + streak + "  ·  best " + Prefs.getInt("math_best", 0));
        }

        private void answer(int idx) {
            if (waiting) {
                return;
            }
            waiting = true;
            boolean ok = ((Integer) options[idx].getTag()) == answer;
            if (ok) {
                streak++;
                if (streak > Prefs.getInt("math_best", 0)) {
                    Prefs.putInt("math_best", streak);
                }
                Sfx.play(Sfx.COIN);
                question.setTextColor(Theme.ACCENT);
                ui.postDelayed(this::next, 350);
            } else {
                streak = 0;
                Sfx.play(Sfx.LOSE);
                question.setText(question.getText() + " = " + answer);
                question.setTextColor(0xFFFF6B7F);
                ui.postDelayed(this::next, 1300);
            }
            for (TextView o : options) {
                pick(o, ((Integer) o.getTag()) == answer);
            }
        }
    }

    // ================================================================== MORSE

    static final class Morse extends NovaWidget {
        private static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        private static final String[] CODES = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---",
            "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-",
            "-.--", "--..", "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..",
            "----."};
        private static final int UNIT = 90;
        private final EditText input;
        private final TextView code;
        private boolean playing;

        Morse(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            input = new EditText(host);
            input.setSingleLine(true);
            input.setHint("type a message");
            input.setText("SOS");
            input.setTypeface(Theme.MONO);
            input.setTextSize(13f);
            input.setTextColor(Theme.TEXT);
            input.setHintTextColor(Theme.DIM);
            input.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
            input.setPadding(dp(12), dp(8), dp(12), dp(8));
            input.setFilters(new InputFilter[] {new InputFilter.LengthFilter(24)});
            input.addTextChangedListener(new android.text.TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(android.text.Editable s) {
                    code.setText(encode(s.toString()));
                }
            });
            addView(input, wide());
            code = text("", 14f, Theme.ACCENT);
            code.setMaxLines(3);
            LinearLayout.LayoutParams clp = fill();
            clp.topMargin = dp(4);
            addView(code, clp);
            LinearLayout r = row();
            r.addView(chip("PLAY (BUZZ + FLASH)", this::play), weight(1f));
            addView(r, wide());
            code.setText(encode("SOS"));
        }

        private static String encode(String s) {
            StringBuilder b = new StringBuilder();
            for (char ch : s.toUpperCase(Locale.ROOT).toCharArray()) {
                if (ch == ' ') {
                    b.append(" / ");
                    continue;
                }
                int i = LETTERS.indexOf(ch);
                if (i >= 0) {
                    b.append(CODES[i]).append(' ');
                }
            }
            return b.toString().trim();
        }

        private void play() {
            if (playing) {
                return;
            }
            String c = encode(input.getText().toString());
            if (c.isEmpty()) {
                return;
            }
            playing = true;
            List<Long> timings = new ArrayList<>();
            timings.add(0L);
            long t = 0;
            for (int i = 0; i < c.length(); i++) {
                char ch = c.charAt(i);
                long on = ch == '.' ? UNIT : ch == '-' ? UNIT * 3L : 0;
                if (on > 0) {
                    final long at = t;
                    final long len = on;
                    ui.postDelayed(() -> flash(true), at);
                    ui.postDelayed(() -> flash(false), at + len);
                    timings.add(on);
                    timings.add((long) UNIT);
                    t += on + UNIT;
                } else if (ch == ' ') {
                    timings.set(timings.size() - 1, timings.get(timings.size() - 1) + UNIT * 2L);
                    t += UNIT * 2L;
                } else if (ch == '/') {
                    timings.set(timings.size() - 1, timings.get(timings.size() - 1) + UNIT * 2L);
                    t += UNIT * 2L;
                }
            }
            long[] pattern = new long[timings.size()];
            for (int i = 0; i < pattern.length; i++) {
                pattern[i] = timings.get(i);
            }
            try {
                Vibrator v = (Vibrator) host.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                }
            } catch (Exception ignored) {
                // no vibration, the flash still plays
            }
            ui.postDelayed(() -> playing = false, t + 100);
        }

        private void flash(boolean on) {
            code.setBackground(on ? Theme.rounded(Theme.ACCENT, 12f, host) : null);
            code.setTextColor(on ? Theme.BG : Theme.ACCENT);
        }

        @Override
        void onLive(boolean on) {
            if (!on) {
                ui.removeCallbacksAndMessages(null);
                playing = false;
                flash(false);
            }
        }
    }

    // ================================================================== SKETCH

    static final class Sketch extends NovaWidget {
        private static final int[] COLORS = {0, 0xFFFFFFFF, 0xFFFF5A6E, 0xFF4FB3FF, 0xFFFFD34F};
        /** Strokes in 0..1 coordinates, shared so the panel and home screen show the same doodle. */
        private static final List<float[]> STROKES = new ArrayList<>();
        private static final List<Integer> STROKE_COLORS = new ArrayList<>();
        private static int color;
        private final Pad pad;
        private final TextView colorChip;

        Sketch(NovaActivity host) {
            super(host);
            pad = new Pad(host);
            pad.setBackground(Theme.rounded(0x14FFFFFF, 12f, host));
            addView(pad, fill());
            LinearLayout r = row();
            colorChip = chip("●", this::nextColor);
            r.addView(colorChip, weight(1f));
            r.addView(chip("UNDO", () -> {
                if (!STROKES.isEmpty()) {
                    STROKES.remove(STROKES.size() - 1);
                    STROKE_COLORS.remove(STROKE_COLORS.size() - 1);
                    pad.invalidate();
                }
            }), weight(1f));
            r.addView(chip("CLEAR", () -> {
                STROKES.clear();
                STROKE_COLORS.clear();
                pad.invalidate();
            }), weight(1f));
            LinearLayout.LayoutParams lp = wide();
            lp.topMargin = dp(4);
            addView(r, lp);
            showColor();
        }

        private int current() {
            return COLORS[color] == 0 ? Theme.ACCENT : COLORS[color];
        }

        private void nextColor() {
            color = (color + 1) % COLORS.length;
            showColor();
        }

        private void showColor() {
            colorChip.setTextColor(current());
        }

        private final class Pad extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Path path = new Path();
            private List<Float> live;

            Pad(Context c) {
                super(c);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float x = e.getX() / Math.max(1, getWidth());
                float y = e.getY() / Math.max(1, getHeight());
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        getParent().requestDisallowInterceptTouchEvent(true);
                        live = new ArrayList<>();
                        live.add(x);
                        live.add(y);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (live != null) {
                            live.add(x);
                            live.add(y);
                            invalidate();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (live != null) {
                            if (live.size() == 2) {
                                live.add(x + 0.001f);
                                live.add(y);
                            }
                            float[] arr = new float[live.size()];
                            for (int i = 0; i < arr.length; i++) {
                                arr[i] = live.get(i);
                            }
                            STROKES.add(arr);
                            STROKE_COLORS.add(current());
                            live = null;
                            invalidate();
                        }
                        return true;
                    default:
                        return true;
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStrokeWidth(Theme.dp(getContext(), 3));
                for (int s = 0; s < STROKES.size(); s++) {
                    p.setColor(STROKE_COLORS.get(s));
                    draw(c, STROKES.get(s), w, h);
                }
                if (live != null && live.size() >= 4) {
                    float[] arr = new float[live.size()];
                    for (int i = 0; i < arr.length; i++) {
                        arr[i] = live.get(i);
                    }
                    p.setColor(current());
                    draw(c, arr, w, h);
                }
            }

            private void draw(Canvas c, float[] pts, float w, float h) {
                path.reset();
                path.moveTo(pts[0] * w, pts[1] * h);
                for (int i = 2; i + 1 < pts.length; i += 2) {
                    path.lineTo(pts[i] * w, pts[i + 1] * h);
                }
                c.drawPath(path, p);
            }
        }
    }

    // ================================================================== QUOTE

    static final class Quote extends NovaWidget {
        private static final String[][] QUOTES = {
            {"The journey of a thousand miles begins with one step.", "Lao Tzu"},
            {"We suffer more often in imagination than in reality.", "Seneca"},
            {"Waste no more time arguing about what a good man should be. Be one.", "Marcus Aurelius"},
            {"The impediment to action advances action. What stands in the way becomes the way.",
                "Marcus Aurelius"},
            {"The unexamined life is not worth living.", "Socrates"},
            {"He who has a why to live can bear almost any how.", "Friedrich Nietzsche"},
            {"Imagination is more important than knowledge.", "Albert Einstein"},
            {"Well done is better than well said.", "Benjamin Franklin"},
            {"The perfect is the enemy of the good.", "Voltaire"},
            {"Fortune favours the bold.", "Virgil"},
            {"I came, I saw, I conquered.", "Julius Caesar"},
            {"Victorious warriors win first and then go to war.", "Sun Tzu"},
            {"No plan survives first contact with the enemy.", "after Helmuth von Moltke"},
            {"Slow is smooth, smooth is fast.", "military saying"},
            {"Discipline equals freedom.", "Jocko Willink"},
            {"Hard choices, easy life. Easy choices, hard life.", "Jerzy Gregorek"},
            {"Stay hungry. Stay foolish.", "Whole Earth Catalog, quoted by Steve Jobs"},
            {"The only way to do great work is to love what you do.", "Steve Jobs"},
            {"The best way to predict the future is to invent it.", "Alan Kay"},
            {"Any sufficiently advanced technology is indistinguishable from magic.", "Arthur C. Clarke"},
            {"Talk is cheap. Show me the code.", "Linus Torvalds"},
            {"Premature optimization is the root of all evil.", "Donald Knuth"},
            {"Simplicity is prerequisite for reliability.", "Edsger W. Dijkstra"},
            {"Programs must be written for people to read, and only incidentally for machines to execute.",
                "Abelson & Sussman"},
            {"Make it work, make it right, make it fast.", "Kent Beck"},
            {"There are only two hard things in computer science: cache invalidation and naming things.",
                "Phil Karlton"},
            {"Code is like humor. When you have to explain it, it's bad.", "Cory House"},
            {"Done is better than perfect.", "Facebook office poster"},
            {"Move fast and break things.", "Mark Zuckerberg"},
            {"That which does not kill us makes us stronger.", "Friedrich Nietzsche"}};
        private final TextView quote;
        private final TextView author;
        private int offset;

        Quote(NovaActivity host) {
            super(host);
            setGravity(Gravity.CENTER);
            setClickable(true);
            setOnClickListener(v -> {
                offset++;
                refresh();
            });
            quote = new TextView(host);
            quote.setTextSize(14f);
            quote.setTextColor(Theme.TEXT);
            quote.setGravity(Gravity.CENTER);
            quote.setTypeface(android.graphics.Typeface.create("serif", android.graphics.Typeface.ITALIC));
            quote.setPadding(dp(8), 0, dp(8), 0);
            addView(quote, wide());
            author = text("", 10f, Theme.ACCENT);
            LinearLayout.LayoutParams alp = wide();
            alp.topMargin = dp(8);
            addView(author, alp);
            addView(text("tap for another", 8f, Theme.DIM), wide());
        }

        @Override
        void refresh() {
            int day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
            String[] q = QUOTES[(day + offset) % QUOTES.length];
            quote.setText("“" + q[0] + "”");
            author.setText("— " + q[1]);
        }
    }
}
