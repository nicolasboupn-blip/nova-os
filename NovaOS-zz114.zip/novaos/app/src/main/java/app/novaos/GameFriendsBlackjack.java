package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Blackjack for the friends table: 1 to 4 players against the dealer on one phone. Everyone bets in turn, then
 * plays their hand in turn (HIT, STAND, DOUBLE), then the dealer draws to 17. Blackjack pays 3 to 2, a win 1 to 1,
 * a tie gives the bet back. Coins are saved after every round.
 */
final class GameFriendsBlackjack extends FriendsGame {
    private static final int[] CHIPS = {10, 50, 100, 500, 1000, 10000};
    private static final int MIN = 10;
    private static final int BET = 0, PLAY = 1, DEALER = 2, OVER = 3;

    private final Random rnd = new Random();
    private final int n;
    private final int[] bet;
    private final boolean[] done;
    private final String[] result;
    private final List<List<Integer>> hands = new ArrayList<>();
    private final List<Integer> dealer = new ArrayList<>();
    private List<Integer> shoe;
    private boolean hole = true;
    private int phase = BET;
    private int turn;
    private int round = 1;

    private final TextView header;
    private final TextView dealerLabel;
    private final LinearLayout dealerRow;
    private final TextView handLabel;
    private final LinearLayout handRow;
    private final LinearLayout table;
    private final LinearLayout actions;
    private final LinearLayout actions2;

    GameFriendsBlackjack(NovaActivity host, FriendsSeats seats) {
        super(host, seats);
        n = seats.size();
        bet = new int[n];
        done = new boolean[n];
        result = new String[n];
        for (int i = 0; i < n; i++) {
            hands.add(new ArrayList<Integer>());
        }
        shoe = shoe(4, rnd);

        header = label("", 13f, Theme.ACCENT);
        header.setLetterSpacing(0.08f);
        col.addView(header, wide());
        dealerLabel = label("DEALER", 11f, Theme.DIM);
        LinearLayout.LayoutParams dl = wide();
        dl.topMargin = dp(12);
        col.addView(dealerLabel, dl);
        dealerRow = row();
        col.addView(dealerRow, wide());
        handLabel = label("", 12f, Theme.TEXT);
        LinearLayout.LayoutParams hl = wide();
        hl.topMargin = dp(16);
        col.addView(handLabel, hl);
        handRow = row();
        col.addView(handRow, wide());
        table = new LinearLayout(host);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        table.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams tl = wide();
        tl.topMargin = dp(16);
        col.addView(table, tl);
        actions = row();
        LinearLayout.LayoutParams al = wide();
        al.topMargin = dp(14);
        col.addView(actions, al);
        actions2 = row();
        col.addView(actions2, wide());

        startRound();
    }

    @Override
    String title() {
        return "FRIENDS BLACKJACK";
    }

    // ------------------------------------------------------------------ rules

    private static int value(int code) {
        int r = code / 4;
        return r == 12 ? 11 : r >= 8 ? 10 : r + 2;
    }

    private static int total(List<Integer> hand) {
        int sum = 0;
        int aces = 0;
        for (int c : hand) {
            sum += value(c);
            if (c / 4 == 12) {
                aces++;
            }
        }
        while (sum > 21 && aces > 0) {
            sum -= 10;
            aces--;
        }
        return sum;
    }

    private static boolean natural(List<Integer> hand) {
        return hand.size() == 2 && total(hand) == 21;
    }

    private int draw() {
        if (shoe.size() < 15) {
            shoe = shoe(4, rnd);
        }
        return shoe.remove(shoe.size() - 1);
    }

    // ------------------------------------------------------------------ betting

    private void startRound() {
        hideCover();
        for (int i = 0; i < n; i++) {
            bet[i] = 0;
            done[i] = false;
            result[i] = "";
            hands.get(i).clear();
        }
        dealer.clear();
        hole = true;
        if (seats.withAtLeast(MIN) == 0) {
            gameOver("everyone is out of coins");
            return;
        }
        phase = BET;
        turn = -1;
        nextBettor();
    }

    private void nextBettor() {
        turn++;
        while (turn < n && seats.stack[turn] < MIN) {
            turn++;
        }
        if (turn >= n) {
            boolean any = false;
            for (int b : bet) {
                if (b > 0) {
                    any = true;
                }
            }
            if (!any) {
                host.toast("Nobody bet");
                startRound();
                return;
            }
            deal();
            return;
        }
        render();
    }

    private void addBet(int c) {
        if (bet[turn] + c > seats.stack[turn]) {
            host.toast("Not enough coins");
            return;
        }
        bet[turn] += c;
        Sfx.play(Sfx.CHIP);
        render();
    }

    // ------------------------------------------------------------------ playing

    private void deal() {
        for (int k = 0; k < 2; k++) {
            for (int i = 0; i < n; i++) {
                if (bet[i] > 0) {
                    hands.get(i).add(draw());
                }
            }
            dealer.add(draw());
        }
        for (int i = 0; i < n; i++) {
            seats.stack[i] -= bet[i];
            done[i] = bet[i] == 0 || natural(hands.get(i));
        }
        Sfx.play(Sfx.CARD);
        if (natural(dealer)) {
            for (int i = 0; i < n; i++) {
                done[i] = true;
            }
            dealerTurn();
            return;
        }
        phase = PLAY;
        turn = -1;
        nextPlayer();
    }

    private void nextPlayer() {
        turn++;
        while (turn < n && done[turn]) {
            turn++;
        }
        if (turn >= n) {
            dealerTurn();
            return;
        }
        render();
    }

    private boolean canAct() {
        return phase == PLAY && turn >= 0 && turn < n && !done[turn];
    }

    private void hit() {
        if (!canAct()) {
            return;
        }
        List<Integer> hand = hands.get(turn);
        hand.add(draw());
        Sfx.play(Sfx.CARD);
        int t = total(hand);
        if (t >= 21) {
            done[turn] = true;
            if (t > 21) {
                Sfx.play(Sfx.BUST);
                host.buzz(40);
            }
            render();
            h.postDelayed(this::nextPlayer, 800);
            return;
        }
        render();
    }

    private void stand() {
        if (!canAct()) {
            return;
        }
        done[turn] = true;
        nextPlayer();
    }

    private void doubleDown() {
        if (!canAct() || hands.get(turn).size() != 2 || seats.stack[turn] < bet[turn]) {
            return;
        }
        seats.stack[turn] -= bet[turn];
        bet[turn] *= 2;
        hands.get(turn).add(draw());
        Sfx.play(Sfx.CHIP);
        done[turn] = true;
        render();
        h.postDelayed(this::nextPlayer, 800);
    }

    private void dealerTurn() {
        phase = DEALER;
        hole = false;
        render();
        boolean anyAlive = false;
        for (int i = 0; i < n; i++) {
            if (bet[i] > 0 && total(hands.get(i)) <= 21 && !natural(hands.get(i))) {
                anyAlive = true;
            }
        }
        dealerStep(anyAlive);
    }

    /** The dealer draws one card at a time, so everyone can watch. Stands on 17. */
    private void dealerStep(boolean needed) {
        if (needed && total(dealer) < 17) {
            h.postDelayed(() -> {
                dealer.add(draw());
                Sfx.play(Sfx.CARD);
                render();
                dealerStep(true);
            }, 700);
            return;
        }
        h.postDelayed(this::settle, 600);
    }

    private void settle() {
        int dt = total(dealer);
        boolean dn = natural(dealer);
        StringBuilder sb = new StringBuilder("dealer " + (dt > 21 ? "busts with " + dt : dn ? "has BLACKJACK" : dt))
                .append("\n\n");
        boolean anyWin = false;
        for (int i = 0; i < n; i++) {
            if (bet[i] == 0) {
                continue;
            }
            List<Integer> hand = hands.get(i);
            int pt = total(hand);
            int back;
            if (pt > 21) {
                back = 0;
                result[i] = "bust";
            } else if (natural(hand) && !dn) {
                back = bet[i] + bet[i] * 3 / 2;
                result[i] = "BLACKJACK";
            } else if (dn && !natural(hand)) {
                back = 0;
                result[i] = "lose";
            } else if (dt > 21 || pt > dt) {
                back = bet[i] * 2;
                result[i] = "win";
            } else if (pt == dt) {
                back = bet[i];
                result[i] = "push";
            } else {
                back = 0;
                result[i] = "lose";
            }
            seats.stack[i] += back;
            int net = back - bet[i];
            if (net > 0) {
                anyWin = true;
            }
            sb.append(seats.names[i]).append("   ").append(result[i]).append("   ")
                    .append(net >= 0 ? "+" : "").append(net).append("   ·   ").append(seats.stack[i]).append('\n');
        }
        seats.save();
        phase = OVER;
        render();
        Sfx.play(anyWin ? Sfx.WIN : Sfx.LOSE);
        if (seats.withAtLeast(MIN) == 0) {
            gameOver(sb.toString().trim());
            return;
        }
        showChoice("ROUND " + round, sb.toString().trim(), new String[] {"NEXT ROUND", "END GAME"},
                new Runnable[] {() -> {
                    round++;
                    startRound();
                }, () -> gameOver("")});
    }

    // ------------------------------------------------------------------ drawing

    private void render() {
        // header
        if (phase == BET) {
            header.setText("ROUND " + round + "  ·  " + seats.names[turn] + ", PLACE YOUR BET");
        } else if (phase == PLAY) {
            header.setText("ROUND " + round + "  ·  " + seats.names[turn] + "'S TURN");
        } else {
            header.setText("ROUND " + round + "  ·  DEALER");
        }
        // dealer
        dealerRow.removeAllViews();
        for (int i = 0; i < dealer.size(); i++) {
            dealerRow.addView(i == 1 && hole ? back(46) : card(dealer.get(i), 46));
        }
        dealerLabel.setText(dealer.isEmpty() ? "DEALER" : hole ? "DEALER  ·  shows " + value(dealer.get(0))
                : "DEALER  ·  " + total(dealer));
        // the hand being played
        handRow.removeAllViews();
        if (phase == PLAY) {
            List<Integer> hand = hands.get(turn);
            for (int c : hand) {
                handRow.addView(card(c, 56));
            }
            int t = total(hand);
            handLabel.setText(seats.names[turn] + "  ·  " + t + (t > 21 ? "  BUST" : "") + "  ·  bet " + bet[turn]);
        } else if (phase == BET) {
            handLabel.setText(seats.names[turn] + "  ·  coins " + (seats.stack[turn] - bet[turn])
                    + "  ·  bet " + bet[turn]);
        } else {
            handLabel.setText("");
        }
        // everyone at the table
        table.removeAllViews();
        for (int i = 0; i < n; i++) {
            StringBuilder s = new StringBuilder();
            s.append(i == turn && phase != DEALER && phase != OVER ? "▶ " : "  ").append(seats.names[i]);
            s.append("   ").append(seats.stack[i]);
            if (bet[i] > 0) {
                s.append("   bet ").append(bet[i]);
            }
            List<Integer> hand = hands.get(i);
            if (!hand.isEmpty()) {
                s.append("\n     ");
                for (int c : hand) {
                    s.append(cardText(c)).append(' ');
                }
                s.append("= ").append(total(hand));
            }
            if (!result[i].isEmpty()) {
                s.append("   ").append(result[i]);
            } else if (seats.stack[i] < MIN && bet[i] == 0) {
                s.append("   (out)");
            }
            TextView t = label(s.toString(), 11f, i == turn && phase <= PLAY ? Theme.TEXT : Theme.DIM);
            t.setGravity(Gravity.START);
            t.setPadding(0, dp(3), 0, dp(3));
            table.addView(t, wide());
        }
        // buttons
        actions.removeAllViews();
        actions2.removeAllViews();
        if (phase == BET) {
            for (int c : CHIPS) {
                if (c <= seats.stack[turn]) {
                    final int amount = c;
                    TextView chip = button(Upgrades.chipName(c), () -> addBet(amount));
                    chip.setTextSize(11f);
                    chip.setPadding(dp(4), dp(10), dp(4), dp(10));
                    actions.addView(chip, weight());
                }
            }
            actions2.addView(button("CLEAR", () -> {
                bet[turn] = 0;
                render();
            }), weight());
            actions2.addView(button(bet[turn] == 0 ? "SKIP" : "DONE", this::nextBettor), weight());
        } else if (phase == PLAY && !done[turn]) {
            actions.addView(button("HIT", this::hit), weight());
            actions.addView(button("STAND", this::stand), weight());
            if (hands.get(turn).size() == 2 && seats.stack[turn] >= bet[turn]) {
                actions.addView(button("DOUBLE", this::doubleDown), weight());
            }
        }
    }
}
