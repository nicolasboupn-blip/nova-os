package app.novaos;

import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Data for the Zürich bus map: your routes (stops in order, where you get on, which days you rode it, how late the bus
 * usually is at each stop) and the calls to the free Swiss timetable (transport.opendata.ch).
 * Every method that talks to the internet blocks, so call those from a background thread.
 */
final class BusData {
    private BusData() {
    }

    /** A route is drawn blue and solid once you rode it on this many different days. */
    static final int CONFIRM_DAYS = 3;
    static final int BLUE = 0xFF3B82F6;
    private static final String API = "https://transport.opendata.ch/v1/";
    private static final String KEY = "bus_routes";
    private static final String PENDING = "bus_pending";
    /** The timetable is shared and asks apps to be gentle, so NOVA stops well below any limit. */
    private static final int DAILY_LIMIT = 700;

    /** The reason the last call failed, for a toast. */
    static volatile String lastError = "";

    static final class Stop {
        String id = "";
        String name = "";
        double lat;
        double lon;
        double dist; // metres, only filled by a search around a point

        /** "Zürich, Bahnhofplatz" shows as "Bahnhofplatz". */
        String shortName() {
            String n = name;
            if (n.startsWith("Zürich, ")) {
                n = n.substring(8);
            }
            return n;
        }
    }

    static final class Route {
        String id = "";
        String name = "";
        final List<Stop> stops = new ArrayList<>();
        /** Ids of the stops where you usually get in. */
        final List<String> boardIds = new CopyOnWriteArrayList<>();
        /** Days (yyyyMMdd) you rode it. */
        final List<String> days = new CopyOnWriteArrayList<>();
        /** Stop id -> how many minutes late the bus was there, one entry per look. */
        final Map<String, List<Integer>> obs = new ConcurrentHashMap<>();
        volatile long fetched;
        /** Shown on the departure board (the yellow stop sign). */
        volatile boolean show = true;

        boolean confirmed() {
            return days.size() >= CONFIRM_DAYS;
        }

        boolean boards(int i) {
            return i >= 0 && i < stops.size() && boardIds.contains(stops.get(i).id);
        }

        Stop first() {
            return stops.get(0);
        }

        Stop last() {
            return stops.get(stops.size() - 1);
        }

        int firstBoard() {
            for (int i = 0; i < stops.size(); i++) {
                if (boards(i)) {
                    return i;
                }
            }
            return 0;
        }

        /** Average minutes late at stop i, or NaN when the bus was never looked at there. */
        double avg(int i) {
            if (i < 0 || i >= stops.size()) {
                return Double.NaN;
            }
            List<Integer> l = obs.get(stops.get(i).id);
            if (l == null || l.isEmpty()) {
                return Double.NaN;
            }
            double s = 0;
            int n = 0;
            for (int v : l) {
                s += v;
                n++;
            }
            return n == 0 ? Double.NaN : s / n;
        }

        /** The stop where the bus is latest on average, or -1. */
        int worstIndex() {
            int best = -1;
            double bd = 0.5;
            for (int i = 0; i < stops.size(); i++) {
                double a = avg(i);
                if (!Double.isNaN(a) && a >= bd) {
                    bd = a;
                    best = i;
                }
            }
            return best;
        }
    }

    /** A ride the phone noticed (moved like a vehicle for a few minutes), waiting for you to say yes or no. */
    static final class Trip {
        double slat;
        double slon;
        double elat;
        double elon;
        long start;
        long end;
        int meters;
    }

    // ------------------------------------------------------------------ colours

    /** Blue when the bus is on time, then green to yellow to red up to 8 minutes late. */
    static int delayColor(double minutes) {
        if (Double.isNaN(minutes) || minutes < 0.5) {
            return BLUE;
        }
        float t = (float) Math.min(1.0, minutes / 8.0);
        return Color.HSVToColor(new float[] {120f * (1f - t), 0.85f, 0.95f});
    }

    // ------------------------------------------------------------------ the saved routes

    private static List<Route> loaded;

    static synchronized List<Route> routes() {
        if (loaded == null) {
            loaded = new ArrayList<>();
            try {
                JSONArray arr = new JSONArray(Prefs.getString(KEY, "[]"));
                for (int i = 0; i < arr.length(); i++) {
                    Route r = fromJson(arr.getJSONObject(i));
                    if (r != null && r.stops.size() >= 2) {
                        loaded.add(r);
                    }
                }
            } catch (JSONException ignored) {
                // a broken save starts empty rather than crashing
            }
        }
        return new ArrayList<>(loaded);
    }

    static synchronized void save() {
        if (loaded == null) {
            return;
        }
        JSONArray arr = new JSONArray();
        for (Route r : loaded) {
            arr.put(toJson(r));
        }
        Prefs.putString(KEY, arr.toString());
    }

    /** Adds the route, or returns the one you already have between the same two stops. */
    static synchronized Route addRoute(Route r) {
        routes();
        for (Route o : loaded) {
            if (o.first().id.equals(r.first().id) && o.last().id.equals(r.last().id)) {
                return o;
            }
        }
        loaded.add(r);
        save();
        return r;
    }

    static synchronized void deleteRoute(Route r) {
        routes();
        loaded.remove(r);
        save();
    }

    static synchronized void markDay(Route r, String day) {
        if (!r.days.contains(day)) {
            r.days.add(day);
            List<String> sorted = new ArrayList<>(r.days);
            Collections.sort(sorted);
            r.days.clear();
            r.days.addAll(sorted);
        }
        save();
    }

    static synchronized void setBoarding(Route r, Stop s, boolean on) {
        if (on && !r.boardIds.contains(s.id)) {
            r.boardIds.add(s.id);
        } else if (!on) {
            r.boardIds.remove(s.id);
        }
        save();
    }

    /** Takes a stop out of a route. Routes keep at least two stops. */
    static synchronized boolean removeStop(Route r, int idx) {
        if (r.stops.size() <= 2 || idx < 0 || idx >= r.stops.size()) {
            return false;
        }
        Stop s = r.stops.remove(idx);
        r.boardIds.remove(s.id);
        save();
        return true;
    }

    private static JSONObject toJson(Route r) {
        JSONObject o = new JSONObject();
        try {
            o.put("id", r.id);
            o.put("name", r.name);
            JSONArray st = new JSONArray();
            for (Stop s : r.stops) {
                JSONObject j = new JSONObject();
                j.put("id", s.id);
                j.put("name", s.name);
                j.put("lat", s.lat);
                j.put("lon", s.lon);
                st.put(j);
            }
            o.put("stops", st);
            o.put("board", new JSONArray(new ArrayList<>(r.boardIds)));
            o.put("show", r.show);
            o.put("days", new JSONArray(new ArrayList<>(r.days)));
            JSONObject ob = new JSONObject();
            for (Map.Entry<String, List<Integer>> e : r.obs.entrySet()) {
                ob.put(e.getKey(), new JSONArray(new ArrayList<>(e.getValue())));
            }
            o.put("obs", ob);
        } catch (JSONException ignored) {
            // nothing to do: the field is just left out
        }
        return o;
    }

    private static Route fromJson(JSONObject o) {
        Route r = new Route();
        r.id = o.optString("id", "r" + System.nanoTime());
        r.name = o.optString("name", "Route");
        r.show = o.optBoolean("show", true);
        JSONArray st = o.optJSONArray("stops");
        if (st == null) {
            return null;
        }
        for (int i = 0; i < st.length(); i++) {
            JSONObject j = st.optJSONObject(i);
            if (j == null) {
                continue;
            }
            Stop s = new Stop();
            s.id = j.optString("id", "");
            s.name = j.optString("name", "");
            s.lat = j.optDouble("lat", 0);
            s.lon = j.optDouble("lon", 0);
            if (!s.id.isEmpty()) {
                r.stops.add(s);
            }
        }
        JSONArray b = o.optJSONArray("board");
        for (int i = 0; b != null && i < b.length(); i++) {
            r.boardIds.add(b.optString(i, ""));
        }
        JSONArray d = o.optJSONArray("days");
        for (int i = 0; d != null && i < d.length(); i++) {
            r.days.add(d.optString(i, ""));
        }
        JSONObject ob = o.optJSONObject("obs");
        if (ob != null) {
            java.util.Iterator<String> it = ob.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONArray a = ob.optJSONArray(k);
                List<Integer> l = new CopyOnWriteArrayList<>();
                for (int i = 0; a != null && i < a.length(); i++) {
                    l.add(a.optInt(i, 0));
                }
                r.obs.put(k, l);
            }
        }
        if (r.boardIds.isEmpty() && !r.stops.isEmpty()) {
            r.boardIds.add(r.stops.get(0).id);
        }
        return r;
    }

    // ------------------------------------------------------------------ days

    static String today() {
        return dayOf(System.currentTimeMillis());
    }

    static String dayOf(long ms) {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date(ms));
    }

    static String daysAgo(int n) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -n);
        return dayOf(c.getTimeInMillis());
    }

    // ------------------------------------------------------------------ the timetable

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            return s;
        }
    }

    private static synchronized boolean budget() {
        String d = today();
        if (!d.equals(Prefs.getString("bus_day", ""))) {
            Prefs.putString("bus_day", d);
            Prefs.putInt("bus_calls", 0);
        }
        int n = Prefs.getInt("bus_calls", 0);
        if (n >= DAILY_LIMIT) {
            return false;
        }
        Prefs.putInt("bus_calls", n + 1);
        return true;
    }

    private static JSONObject api(String path) {
        if (!budget()) {
            lastError = "Daily limit for the bus timetable reached. Try again tomorrow";
            return null;
        }
        String s = Http.get(API + path);
        if (s == null) {
            lastError = Http.lastCode == -1 ? "No internet, or the timetable is not answering"
                    : "The timetable said no (code " + Http.lastCode + ")";
            return null;
        }
        try {
            return new JSONObject(s);
        } catch (JSONException e) {
            lastError = "The timetable answered something unreadable";
            return null;
        }
    }

    private static String str(JSONObject o, String k) {
        if (o == null || o.isNull(k)) {
            return "";
        }
        return o.optString(k, "");
    }

    /** Reads a timetable station. x is the latitude and y the longitude in this API. */
    private static Stop stopOf(JSONObject s) {
        if (s == null) {
            return null;
        }
        JSONObject c = s.optJSONObject("coordinate");
        if (c == null) {
            c = s.optJSONObject("coordinates");
        }
        String id = str(s, "id");
        if (id.isEmpty() || c == null) {
            return null;
        }
        Stop st = new Stop();
        st.id = id;
        st.name = str(s, "name");
        st.lat = c.optDouble("x", 0);
        st.lon = c.optDouble("y", 0);
        st.dist = s.optDouble("distance", 0);
        if (st.lat == 0 && st.lon == 0) {
            return null;
        }
        return st;
    }

    static List<Stop> searchStops(String query) {
        List<Stop> out = new ArrayList<>();
        JSONObject j = api("locations?type=station&query=" + enc(query));
        JSONArray a = j == null ? null : j.optJSONArray("stations");
        for (int i = 0; a != null && i < a.length(); i++) {
            Stop s = stopOf(a.optJSONObject(i));
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    /** Stops around a point, nearest first. */
    static List<Stop> nearbyStops(double lat, double lon) {
        List<Stop> out = new ArrayList<>();
        JSONObject j = api("locations?type=station&x=" + lat + "&y=" + lon);
        JSONArray a = j == null ? null : j.optJSONArray("stations");
        for (int i = 0; a != null && i < a.length(); i++) {
            Stop s = stopOf(a.optJSONObject(i));
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    private static void addStop(List<Stop> list, Stop s) {
        if (s == null) {
            return;
        }
        if (!list.isEmpty() && list.get(list.size() - 1).id.equals(s.id)) {
            return;
        }
        list.add(s);
    }

    /**
     * Finds the bus line between two stops and returns its stops in order. Only one bus ride is used (no changes).
     * timeMs is when the ride started, or 0 for "now". Returns null when there is no direct bus.
     */
    static Route buildRoute(Stop from, Stop to, long timeMs) {
        String q = "connections?from=" + enc(from.id) + "&to=" + enc(to.id) + "&transportations%5B%5D=bus&limit=4";
        if (timeMs > 0) {
            q += "&date=" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date())
                    + "&time=" + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(timeMs));
        }
        JSONObject j = api(q);
        if (j == null) {
            return null;
        }
        JSONArray cs = j.optJSONArray("connections");
        for (int c = 0; cs != null && c < cs.length(); c++) {
            JSONArray secs = cs.optJSONObject(c).optJSONArray("sections");
            for (int k = 0; secs != null && k < secs.length(); k++) {
                JSONObject sec = secs.optJSONObject(k);
                JSONObject journey = sec.optJSONObject("journey");
                if (journey == null) {
                    continue;
                }
                List<Stop> list = new ArrayList<>();
                JSONObject dep = sec.optJSONObject("departure");
                addStop(list, stopOf(dep == null ? null : dep.optJSONObject("station")));
                JSONArray pl = journey.optJSONArray("passList");
                for (int i = 0; pl != null && i < pl.length(); i++) {
                    JSONObject p = pl.optJSONObject(i);
                    addStop(list, stopOf(p == null ? null : p.optJSONObject("station")));
                }
                JSONObject arr = sec.optJSONObject("arrival");
                addStop(list, stopOf(arr == null ? null : arr.optJSONObject("station")));
                if (list.size() < 2) {
                    continue;
                }
                Route r = new Route();
                r.id = "r" + System.currentTimeMillis();
                r.stops.addAll(list);
                r.boardIds.add(list.get(0).id);
                r.name = list.get(0).shortName() + " → " + list.get(list.size() - 1).shortName();
                return r;
            }
        }
        lastError = "No direct bus between those two stops. Pick two stops on the same bus line";
        return null;
    }

    // ------------------------------------------------------------------ how late is the bus

    private static Integer minutesBetween(String sched, String prog) {
        if (sched.isEmpty() || prog.isEmpty()) {
            return null;
        }
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
            long a = f.parse(sched).getTime();
            long b = f.parse(prog).getTime();
            return Math.round((b - a) / 60000f);
        } catch (ParseException | NullPointerException e) {
            return null;
        }
    }

    private static Integer delayOf(JSONObject p) {
        if (p.has("delay") && !p.isNull("delay")) {
            return Math.max(0, p.optInt("delay", 0));
        }
        JSONObject pr = p.optJSONObject("prognosis");
        if (pr == null) {
            return null;
        }
        Integer m = minutesBetween(str(p, "departure"), str(pr, "departure"));
        if (m == null) {
            m = minutesBetween(str(p, "arrival"), str(pr, "arrival"));
        }
        return m == null ? null : Math.max(0, m);
    }

    private static void collect(Map<String, int[]> sum, Route r, JSONObject p) {
        if (p == null) {
            return;
        }
        JSONObject st = p.optJSONObject("station");
        if (st == null) {
            return;
        }
        String id = str(st, "id");
        boolean mine = false;
        for (Stop s : r.stops) {
            if (s.id.equals(id)) {
                mine = true;
                break;
            }
        }
        Integer d = mine ? delayOf(p) : null;
        if (d == null) {
            return;
        }
        int[] a = sum.get(id);
        if (a == null) {
            a = new int[2];
            sum.put(id, a);
        }
        a[0] += d;
        a[1]++;
    }

    /**
     * Looks at the next buses leaving your boarding stop that reach the end of the route and notes how late they are at
     * each stop. Returns true when new numbers were saved. At most once every 3 minutes per route.
     */
    static boolean refreshDelays(Route r) {
        long now = System.currentTimeMillis();
        if (now - r.fetched < 180000 || r.stops.size() < 2) {
            return false;
        }
        r.fetched = now;
        Stop board = r.stops.get(r.firstBoard());
        Stop last = r.last();
        JSONObject j = api("stationboard?id=" + enc(board.id) + "&limit=12&transportations%5B%5D=bus");
        JSONArray sb = j == null ? null : j.optJSONArray("stationboard");
        if (sb == null) {
            return false;
        }
        Map<String, int[]> sum = new HashMap<>();
        int used = 0;
        for (int i = 0; i < sb.length() && used < 4; i++) {
            JSONObject jr = sb.optJSONObject(i);
            JSONArray pl = jr == null ? null : jr.optJSONArray("passList");
            if (pl == null) {
                continue;
            }
            boolean reaches = false;
            for (int k = 0; k < pl.length(); k++) {
                JSONObject p = pl.optJSONObject(k);
                JSONObject st = p == null ? null : p.optJSONObject("station");
                if (st != null && last.id.equals(str(st, "id"))) {
                    reaches = true;
                    break;
                }
            }
            if (!reaches) {
                continue;
            }
            used++;
            collect(sum, r, jr.optJSONObject("stop"));
            for (int k = 0; k < pl.length(); k++) {
                collect(sum, r, pl.optJSONObject(k));
            }
        }
        if (used == 0) {
            return false;
        }
        synchronized (BusData.class) {
            boolean any = false;
            for (Stop s : r.stops) {
                int[] a = sum.get(s.id);
                if (a == null || a[1] == 0) {
                    continue;
                }
                List<Integer> l = r.obs.get(s.id);
                if (l == null) {
                    l = new CopyOnWriteArrayList<>();
                    r.obs.put(s.id, l);
                }
                l.add(Math.round(a[0] / (float) a[1]));
                while (l.size() > 30) {
                    l.remove(0);
                }
                any = true;
            }
            if (any) {
                save();
            }
            return any;
        }
    }

    // ------------------------------------------------------------------ the departure board

    /** One bus that is about to leave: its line, where it goes and when (real time, in ms). */
    static final class Dep {
        String line = "";
        String to = "";
        long at;
    }

    private static final Map<String, Object[]> BOARDS = new HashMap<>();

    private static long parseIso(String s) {
        if (s == null || s.isEmpty()) {
            return 0;
        }
        try {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).parse(s).getTime();
        } catch (ParseException | NullPointerException e) {
            return 0;
        }
    }

    /** When the bus really leaves: the live time if there is one, else the timetable time plus the delay. */
    private static long depTime(JSONObject stop) {
        if (stop == null) {
            return 0;
        }
        long ms = parseIso(str(stop.optJSONObject("prognosis"), "departure"));
        if (ms > 0) {
            return ms;
        }
        long ts = stop.optLong("departureTimestamp", 0);
        if (ts > 0) {
            ms = ts * 1000L;
            if (stop.has("delay") && !stop.isNull("delay")) {
                ms += stop.optInt("delay", 0) * 60000L;
            }
            return ms;
        }
        return parseIso(str(stop, "departure"));
    }

    /**
     * The next buses at a stop. With routes given, only buses that go on to the end of one of them are listed (your
     * buses). Answers are kept for 75 seconds so the widget and the window do not ask twice. Returns null on error.
     */
    @SuppressWarnings("unchecked")
    static List<Dep> board(Stop stop, List<Route> routes) {
        StringBuilder key = new StringBuilder(stop.id);
        for (Route r : routes) {
            key.append('|').append(r.last().id);
        }
        long now = System.currentTimeMillis();
        synchronized (BOARDS) {
            Object[] c = BOARDS.get(key.toString());
            if (c != null && now - (Long) c[0] < 75000) {
                return (List<Dep>) c[1];
            }
        }
        JSONObject j = api("stationboard?id=" + enc(stop.id) + "&limit=16&transportations%5B%5D=bus");
        JSONArray sb = j == null ? null : j.optJSONArray("stationboard");
        if (sb == null) {
            return null;
        }
        List<Dep> out = new ArrayList<>();
        for (int i = 0; i < sb.length(); i++) {
            JSONObject jr = sb.optJSONObject(i);
            if (jr == null) {
                continue;
            }
            if (!routes.isEmpty()) {
                JSONArray pl = jr.optJSONArray("passList");
                boolean mine = false;
                for (int k = 0; pl != null && k < pl.length() && !mine; k++) {
                    JSONObject p = pl.optJSONObject(k);
                    JSONObject st = p == null ? null : p.optJSONObject("station");
                    String id = st == null ? "" : str(st, "id");
                    for (Route r : routes) {
                        if (r.last().id.equals(id)) {
                            mine = true;
                            break;
                        }
                    }
                }
                if (!mine) {
                    continue;
                }
            }
            long at = depTime(jr.optJSONObject("stop"));
            if (at == 0 || at < now - 60000) {
                continue;
            }
            Dep d = new Dep();
            d.line = str(jr, "number");
            if (d.line.isEmpty()) {
                d.line = str(jr, "name").replace("BUS", "").replace("Bus", "").trim();
            }
            String to = str(jr, "to");
            d.to = to.startsWith("Zürich, ") ? to.substring(8) : to;
            d.at = at;
            out.add(d);
        }
        Collections.sort(out, (a, b) -> Long.compare(a.at, b.at));
        synchronized (BOARDS) {
            BOARDS.put(key.toString(), new Object[] {now, out});
        }
        return out;
    }

    // ------------------------------------------------------------------ rides the phone noticed

    static synchronized List<Trip> pending() {
        List<Trip> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getString(PENDING, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Trip t = new Trip();
                t.slat = o.optDouble("slat");
                t.slon = o.optDouble("slon");
                t.elat = o.optDouble("elat");
                t.elon = o.optDouble("elon");
                t.start = o.optLong("start");
                t.end = o.optLong("end");
                t.meters = o.optInt("meters");
                out.add(t);
            }
        } catch (JSONException ignored) {
            // start empty
        }
        return out;
    }

    private static void writePending(List<Trip> list) {
        JSONArray a = new JSONArray();
        for (Trip t : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("slat", t.slat);
                o.put("slon", t.slon);
                o.put("elat", t.elat);
                o.put("elon", t.elon);
                o.put("start", t.start);
                o.put("end", t.end);
                o.put("meters", t.meters);
            } catch (JSONException ignored) {
                continue;
            }
            a.put(o);
        }
        Prefs.putString(PENDING, a.toString());
    }

    static synchronized void addPending(Trip t) {
        List<Trip> l = pending();
        l.add(t);
        while (l.size() > 5) {
            l.remove(0);
        }
        writePending(l);
    }

    /** Forgets the oldest waiting ride (after you answered it). */
    static synchronized void dropOldestPending() {
        List<Trip> l = pending();
        if (!l.isEmpty()) {
            l.remove(0);
            writePending(l);
        }
    }
}
