package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

/**
 * Two cards for the other home screens (Feed, Console, Wallet, Bento, Fan).
 * hero(): your own MY WIDGET 1 when you built one, otherwise a big clock with the day's info.
 * Mix: one card you page through: PROFILE, SCENES, WEATHER, TO-DO, CALENDAR, CASINO, SLOTS, BADGES, GAMES.
 */
final class HomeMix {
    private HomeMix() {
    }

    static View hero(NovaActivity host) {
        if (!CustomWidget.load(1).isEmpty()) {
            return new CustomWidget(host, 1);
        }
        return new BigClock(host);
    }

    /** The time, big, with the date and what is left of the day. */
    static final class BigClock extends NovaWidget {
        private final TextView time;
        private final TextView date;
        private final TextView bar;
        private final TextView info;

        BigClock(NovaActivity host) {
            super(host);
            setPadding(0, dp(4), 0, dp(4));
            time = text("", 64f, Theme.TEXT);
            time.setTypeface(Typeface.create(Theme.MONO, Typeface.BOLD));
            addView(time, wide());
            date = text("", 14f, Theme.ACCENT);
            addView(date, wide());
            bar = text("", 11f, Theme.ACCENT);
            bar.setPadding(0, dp(10), 0, 0);
            addView(bar, wide());
            info = text("", 10f, Theme.DIM);
            info.setPadding(0, dp(4), 0, 0);
            addView(info, wide());
            tick();
        }

        @Override
        long tickMs() {
            return 1000;
        }

        @Override
        void refresh() {
            tick();
        }

        @Override
        void tick() {
            Calendar c = Calendar.getInstance();
            boolean h24 = DateFormat.is24HourFormat(host);
            int h = c.get(Calendar.HOUR_OF_DAY);
            String hm = h24 ? String.format(Locale.US, "%02d:%02d", h, c.get(Calendar.MINUTE))
                    : String.format(Locale.US, "%d:%02d", h % 12 == 0 ? 12 : h % 12, c.get(Calendar.MINUTE));
            String sec = String.format(Locale.US, ":%02d", c.get(Calendar.SECOND));
            SpannableString s = new SpannableString(hm + sec);
            s.setSpan(new RelativeSizeSpan(0.4f), hm.length(), s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            time.setText(s);
            date.setText(new java.text.SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(c.getTime()));
            int secs = h * 3600 + c.get(Calendar.MINUTE) * 60 + c.get(Calendar.SECOND);
            int pct = Math.round(secs * 100f / 86400f);
            int filled = Math.round(pct / 5f);
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 20; i++) {
                b.append(i < filled ? '▰' : '▱');
            }
            bar.setText(b + "  DAY " + pct + "%");
            int left = 86400 - secs;
            Intent bi = host.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            String batt = "";
            if (bi != null) {
                int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
                if (lvl >= 0) {
                    batt = "  ·  battery " + Math.round(lvl * 100f / scale) + "%" + (chg ? " charging" : "");
                }
            }
            info.setText((left / 3600) + "h " + ((left % 3600) / 60) + "m left today  ·  week "
                    + c.get(Calendar.WEEK_OF_YEAR) + "  ·  day " + c.get(Calendar.DAY_OF_YEAR) + batt);
        }
    }

    /** One card, nine pages, arrows to flip and a tap on the name to jump. */
    static final class Mix extends LinearLayout {
        private static final String[] IDS = {"profile", "scenes", "weather", "todo", "calendar", "casino", "slots",
            "badges", "games"};
        private static final String[] NAMES = {"PROFILE", "SCENES", "WEATHER", "TO-DO", "CALENDAR", "CASINO", "SLOTS",
            "BADGES", "GAMES"};
        /** Page height in dp, 0 = as tall as it is. */
        private static final int[] H = {0, 0, 0, 240, 200, 280, 280, 280, 280};
        private static int last = 0;

        private final NovaActivity host;
        private final int maxDp;
        private final View[] views = new View[IDS.length];
        private final TextView title;
        private final TextView count;
        private final FrameLayout body;
        private int idx;

        Mix(NovaActivity host, int maxDp) {
            super(host);
            this.host = host;
            this.maxDp = maxDp;
            setOrientation(VERTICAL);
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(arrow("◀", -1));
            title = label("", 11f, Theme.TEXT);
            title.setLetterSpacing(0.12f);
            title.setClickable(true);
            title.setOnClickListener(v -> new AlertDialog.Builder(host).setTitle("Jump to")
                    .setItems(NAMES, (d, w) -> show(w)).show());
            head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
            count = label("", 9f, Theme.DIM);
            head.addView(count);
            head.addView(arrow("▶", 1));
            addView(head, new LayoutParams(-1, -2));
            body = new FrameLayout(host);
            LayoutParams bp = new LayoutParams(-1, -2);
            bp.topMargin = Theme.dp(host, 6);
            addView(body, bp);
            idx = Math.max(0, Math.min(last, IDS.length - 1));
            show(idx);
        }

        private TextView label(String s, float sp, int color) {
            TextView t = new TextView(host);
            t.setText(s);
            t.setTypeface(Theme.MONO);
            t.setTextSize(sp);
            t.setTextColor(color);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Theme.dp(host, 6), Theme.dp(host, 6), Theme.dp(host, 6), Theme.dp(host, 6));
            return t;
        }

        private TextView arrow(String g, final int dir) {
            TextView t = label(g, 14f, Theme.ACCENT);
            t.setPadding(Theme.dp(host, 12), Theme.dp(host, 6), Theme.dp(host, 12), Theme.dp(host, 6));
            t.setClickable(true);
            Theme.ripple(t);
            t.setOnClickListener(v -> show((idx + dir + IDS.length) % IDS.length));
            return t;
        }

        private void show(int i) {
            idx = i;
            last = i;
            body.removeAllViews();
            if (views[i] == null) {
                views[i] = Widgets.create(host, IDS[i]);
            }
            View v = views[i];
            if (v.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) v.getParent()).removeView(v);
            }
            int h = H[i] == 0 ? FrameLayout.LayoutParams.WRAP_CONTENT : Theme.dp(host, Math.min(H[i], maxDp));
            body.addView(v, new FrameLayout.LayoutParams(-1, h));
            title.setText(NAMES[i]);
            count.setText((i + 1) + " / " + IDS.length);
            v.setAlpha(0f);
            v.animate().alpha(1f).setDuration(160).start();
            post(() -> Widgets.refresh(v));
        }
    }
}
