package app.novaos;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** A tiny GET helper. Call it from a background thread. Returns null if anything goes wrong. */
final class Http {
    private Http() {
    }

    /** The status code of the last get(), or -1 when the request never got an answer. */
    static volatile int lastCode;

    static String get(String address) {
        return get(address, null);
    }

    /** Same, with an optional bearer token for APIs that want one. */
    static String get(String address, String bearer) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "NOVA/" + Theme.OS_VERSION);
            c.setRequestProperty("Accept", "application/json");
            if (bearer != null) {
                c.setRequestProperty("Authorization", "Bearer " + bearer);
            }
            int code = c.getResponseCode();
            lastCode = code;
            if (code != 200) {
                return null;
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            lastCode = -1;
            return null;
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    /** Fetches raw bytes (map tiles). Call from a background thread. Returns null on any failure. */
    static byte[] bytes(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "NOVA-launcher/" + Theme.OS_VERSION + " (personal use)");
            if (c.getResponseCode() != 200) {
                return null;
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            in.close();
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }
}
