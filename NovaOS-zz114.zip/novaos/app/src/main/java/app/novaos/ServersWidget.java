package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The SERVERS page on the quick panel: live player counts for four favourite Arma Reforger servers.
 * One request per refresh to the ReforgerMods server list (a free JSON feed, no key or account), then each row picks
 * the server whose name best matches the row's words. If a row picks the wrong one, tap it and paste that server's
 * gamemonitoring.net page link to lock it to one exact server (read from that site's key-free API).
 * Refreshes by itself every minute while the page is on screen.
 */
final class ServersWidget extends LinearLayout {
    private static final int FAVS = 3;
    private static final String[] LISTS = {"https://reforgermods.net/v2/servers?sort=players",
        "https://api.reforgermods.net/v2/servers?sort=players"};
    private static final String API = "https://api.gamemonitoring.net/servers/";
    private static final String SITE = "https://gamemonitoring.net/arma-reforger";
    /** What each row is called, and the words it looks for in server names (extra words like eu or na only break ties). */
    private static final String[] LABELS = {"WCS Serhiivka East West (EU)", "Spearhead Yunakivka (US)", "NEXTGEN France"};
    private static final String[] PHRASES = {"wcs serhiivka east west eu", "spearhead yunakivka na", "nextgen france"};
    private static final String[] PLAYER_KEYS = {"players", "player_count", "playerCount", "numplayers",
        "num_players", "current_players", "currentPlayers", "online_players", "playersOnline"};
    private static final String[] MAX_KEYS = {"max_players", "maxPlayers", "maxplayers", "player_max",
        "capacity", "slots", "max"};
    private static final long REFRESH_MS = 60_000L;

    private static final class Entry {
        String name = "";
        String norm = "";
        int players;
        int max;
        boolean online = true;
    }

    private static final class Result {
        String name = "";
        int players;
        int max;
        boolean online;
        String err = "";
        boolean ok;
    }

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView[] labels = new TextView[FAVS];
    private final TextView[] subs = new TextView[FAVS];
    private final TextView[] counts = new TextView[FAVS];
    private final Result[] results = new Result[FAVS];
    private final TextView status;
    private String statusText = "loading...";
    private boolean loading;
    private long lastLoad;

    private final Runnable auto = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                load(false);
            }
            ui.postDelayed(this, REFRESH_MS);
        }
    };

    ServersWidget(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        for (int i = 0; i < FAVS; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
            row.setClickable(true);
            Theme.ripple(row);
            row.setOnClickListener(v -> edit(idx));
            LinearLayout left = new LinearLayout(host);
            left.setOrientation(VERTICAL);
            labels[i] = mono(LABELS[i].toUpperCase(Locale.ROOT), 11f, Theme.TEXT);
            labels[i].setSingleLine(true);
            labels[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i] = mono("", 8f, Theme.DIM);
            subs[i].setSingleLine(true);
            subs[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i].setVisibility(GONE);
            left.addView(labels[i]);
            left.addView(subs[i]);
            row.addView(left, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            counts[i] = mono("--", 13f, Theme.DIM);
            counts[i].setPadding(dp(8), 0, 0, 0);
            row.addView(counts[i]);
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(3);
            addView(row, lp);
        }
        LinearLayout bottom = new LinearLayout(host);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        status = mono(statusText, 9f, Theme.DIM);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.END);
        bottom.addView(status, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        bottom.addView(button("REFRESH", () -> load(true)));
        LayoutParams bp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(4);
        addView(bottom, bp);
        render();
    }

    /** Called when the page is shown. */
    void refresh() {
        render();
        load(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.postDelayed(auto, REFRESH_MS);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ settings

    /** A gamemonitoring.net server number if this row was locked to one, else empty. */
    private static String serverId(int i) {
        String id = Prefs.getString("srv_gm" + i, "");
        return id == null ? "" : id.trim();
    }

    /** Pulls the server number out of a gamemonitoring.net link, or accepts a bare number. */
    private static String parseId(String s) {
        String t = s.trim();
        Matcher m = Pattern.compile("servers/(\\d+)").matcher(t);
        if (m.find()) {
            return m.group(1);
        }
        return t.matches("\\d+") ? t : "";
    }

    // ------------------------------------------------------------------ loading

    private void load(boolean force) {
        long now = System.currentTimeMillis();
        if (loading || (!force && now - lastLoad < 40_000L)) {
            return;
        }
        loading = true;
        lastLoad = now;
        statusText = "updating...";
        status.setText(statusText);
        new Thread(() -> {
            final Result[] res = new Result[FAVS];
            final String[] failure = {""};
            boolean needList = false;
            for (int i = 0; i < FAVS; i++) {
                if (serverId(i).isEmpty()) {
                    needList = true;
                }
            }
            List<Entry> list = needList ? fetchList(failure) : new ArrayList<Entry>();
            List<String> used = new ArrayList<>();
            for (int i = 0; i < FAVS; i++) {
                if (!serverId(i).isEmpty()) {
                    res[i] = fetchGm(i);
                } else if (list == null) {
                    res[i] = new Result();
                    res[i].err = "no data";
                } else {
                    res[i] = match(list, PHRASES[i], used);
                }
            }
            final String fail = failure[0];
            final boolean noList = list == null;
            ui.post(() -> {
                loading = false;
                int bad = 0;
                for (int i = 0; i < FAVS; i++) {
                    results[i] = res[i];
                    if (!res[i].ok) {
                        bad++;
                    }
                }
                String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                if (noList) {
                    statusText = fail + " · " + time;
                } else if (bad == FAVS) {
                    statusText = "no server matched · " + time;
                } else {
                    statusText = "updated " + time;
                }
                render();
            });
        }).start();
    }

    /** Fetches the whole server list once. Returns null and fills failure[0] if it could not be read. */
    private static List<Entry> fetchList(String[] failure) {
        for (String url : LISTS) {
            String body = Http.get(url);
            if (body == null) {
                if (failure[0].isEmpty()) {
                    failure[0] = errFor(Http.lastCode);
                }
                continue;
            }
            List<Entry> list = parseList(body);
            if (!list.isEmpty()) {
                return list;
            }
            failure[0] = "unknown format: " + snippet(body);
        }
        return null;
    }

    private static String snippet(String body) {
        String t = body.replaceAll("\\s+", " ").trim();
        return t.length() > 70 ? t.substring(0, 70) : t;
    }

    private static List<Entry> parseList(String body) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray arr = findArray(new JSONTokener(body).nextValue(), 0);
            if (arr == null) {
                return out;
            }
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                Entry e = o == null ? null : entry(o);
                if (e != null) {
                    out.add(e);
                }
            }
        } catch (Exception ignored) {
            // anything unreadable just gives an empty list
        }
        return out;
    }

    private static JSONArray findArray(Object root, int depth) {
        if (root instanceof JSONArray) {
            return (JSONArray) root;
        }
        if (!(root instanceof JSONObject) || depth > 2) {
            return null;
        }
        JSONObject o = (JSONObject) root;
        for (String k : new String[] {"servers", "data", "items", "results", "rows", "list"}) {
            Object v = o.opt(k);
            JSONArray a = v == null ? null : findArray(v, depth + 1);
            if (a != null) {
                return a;
            }
        }
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            Object v = o.opt(it.next());
            if (v instanceof JSONArray && ((JSONArray) v).length() > 0 && ((JSONArray) v).opt(0) instanceof JSONObject) {
                return (JSONArray) v;
            }
        }
        return null;
    }

    private static Entry entry(JSONObject o) {
        JSONObject src = o.optJSONObject("attributes") != null ? o.optJSONObject("attributes") : o;
        Entry e = new Entry();
        e.name = str(src, "name", "server_name", "serverName", "title", "hostname");
        if (e.name.isEmpty()) {
            e.name = str(o, "name", "server_name", "serverName", "title", "hostname");
        }
        if (e.name.isEmpty()) {
            return null;
        }
        e.norm = normalize(e.name);
        Object pv = src.opt("players");
        if (pv instanceof JSONObject) {
            JSONObject po = (JSONObject) pv;
            e.players = num(po, "current", "online", "count", "now", "value");
            e.max = num(po, "max", "maximum", "capacity");
        } else {
            e.players = num(src, PLAYER_KEYS);
            e.max = num(src, MAX_KEYS);
        }
        Object st = src.opt("status");
        if (st instanceof String) {
            e.online = !"offline".equalsIgnoreCase((String) st);
        } else if (st instanceof Boolean) {
            e.online = (Boolean) st;
        } else if (src.has("online")) {
            e.online = src.optBoolean("online", true);
        }
        return e;
    }

    private static String str(JSONObject o, String... keys) {
        for (String k : keys) {
            String v = o.optString(k, "");
            if (!v.isEmpty() && !"null".equals(v)) {
                return v;
            }
        }
        return "";
    }

    private static int num(JSONObject o, String... keys) {
        for (String k : keys) {
            Object v = o.opt(k);
            if (v instanceof Number) {
                return ((Number) v).intValue();
            }
            if (v instanceof JSONArray) {
                return ((JSONArray) v).length();
            }
            if (v instanceof String) {
                Matcher m = Pattern.compile("^(\\d+)").matcher(((String) v).trim());
                if (m.find()) {
                    return Integer.parseInt(m.group(1));
                }
            }
        }
        return 0;
    }

    /** Lower case, punctuation removed: "[NA1] W.C.S. Realism" becomes "na1 wcs realism". */
    private static String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", "").replaceAll("\\s+", " ").trim();
    }

    /**
     * Picks the server whose name has the most words of the phrase. Two words are needed (the first two, which are
     * the real name), the rest only raise the score, and the busiest wins a tie. Short words like eu or na must be
     * the start of a whole word in the name, so "na" does not match inside "yunakivka". A server another row
     * already took is skipped when there is a choice.
     */
    private static Result match(List<Entry> list, String phrase, List<String> used) {
        String[] words = normalize(phrase).split(" ");
        int need = Math.min(words.length, 2);
        Entry top = null;
        int topScore = 0;
        boolean topUsed = true;
        for (Entry e : list) {
            String[] tokens = e.norm.split(" ");
            int score = 0;
            int core = 0;
            for (int k = 0; k < words.length; k++) {
                if (hasWord(e.norm, tokens, words[k])) {
                    score++;
                    if (k < need) {
                        core++;
                    }
                }
            }
            if (core < need) {
                continue;
            }
            boolean u = used.contains(e.name);
            boolean better = top == null
                    || (topUsed && !u)
                    || (topUsed == u && (score > topScore || (score == topScore && e.players > top.players)));
            if (better) {
                top = e;
                topScore = score;
                topUsed = u;
            }
        }
        Result r = new Result();
        if (top == null) {
            r.err = "not found";
            return r;
        }
        used.add(top.name);
        r.name = top.name;
        r.players = top.players;
        r.max = top.max;
        r.online = top.online;
        r.ok = true;
        return r;
    }

    private static boolean hasWord(String norm, String[] tokens, String w) {
        if (w.length() > 3) {
            return norm.contains(w);
        }
        for (String t : tokens) {
            if (t.startsWith(w)) {
                return true;
            }
        }
        return false;
    }

    private Result fetchGm(int i) {
        Result r = new Result();
        String body = Http.get(API + serverId(i));
        if (body == null) {
            r.err = errFor(Http.lastCode);
            return r;
        }
        try {
            JSONObject o = new JSONObject(body).optJSONObject("response");
            if (o == null) {
                r.err = "not found";
                return r;
            }
            r.name = o.optString("name");
            r.players = o.optInt("numplayers", 0);
            r.max = o.optInt("maxplayers", 0);
            r.online = o.optBoolean("status", false);
            r.ok = true;
        } catch (Exception e) {
            r.err = "bad reply";
        }
        return r;
    }

    private static String errFor(int code) {
        if (code == 401 || code == 403) {
            return "blocked";
        }
        if (code == 404) {
            return "not found";
        }
        if (code == 429) {
            return "rate limit";
        }
        return code <= 0 ? "no network" : "error " + code;
    }

    // ------------------------------------------------------------------ drawing

    private void render() {
        for (int i = 0; i < FAVS; i++) {
            Result r = results[i];
            if (r == null) {
                counts[i].setTextSize(13f);
                counts[i].setText(loading ? "..." : "--");
                counts[i].setTextColor(Theme.DIM);
                subs[i].setVisibility(GONE);
                continue;
            }
            if (!r.ok) {
                counts[i].setTextSize(10f);
                counts[i].setText(r.err);
                counts[i].setTextColor(0xFFFF6B7F);
                subs[i].setVisibility(GONE);
                continue;
            }
            counts[i].setTextSize(13f);
            counts[i].setText(r.online ? r.players + "/" + r.max : "offline");
            counts[i].setTextColor(r.online ? Theme.ACCENT : Theme.DIM);
            subs[i].setText(r.name);
            subs[i].setVisibility(r.name.isEmpty() || r.name.equalsIgnoreCase(LABELS[i]) ? GONE : VISIBLE);
        }
        status.setText(statusText);
    }

    // ------------------------------------------------------------------ dialogs

    /** Tap a row: paste a gamemonitoring.net link (or number) to lock it to one exact server, or clear it. */
    private void edit(final int i) {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setHint("gamemonitoring.net link or number");
        String clip = clipboard();
        e.setText(clip.contains("gamemonitoring") ? clip : serverId(i));
        new AlertDialog.Builder(host)
                .setTitle(LABELS[i])
                .setMessage("Optional. Rows find their server by name by themselves. If this row shows the wrong "
                        + "server, find the right one on gamemonitoring.net (game: Arma Reforger), open its page "
                        + "and paste the link here. Leave empty to go back to automatic.")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    String text = e.getText().toString().trim();
                    String id = text.isEmpty() ? "" : parseId(text);
                    if (!text.isEmpty() && id.isEmpty()) {
                        statusText = "that is not a gamemonitoring link";
                        status.setText(statusText);
                        return;
                    }
                    Prefs.putString("srv_gm" + i, id);
                    results[i] = null;
                    load(true);
                    render();
                })
                .setNeutralButton("FIND ON SITE", (d, w) -> {
                    try {
                        host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SITE)));
                    } catch (Exception ignored) {
                        // no browser, nothing to open
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private String clipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm == null ? null : cm.getPrimaryClip();
            if (d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null) {
                return d.getItemAt(0).getText().toString().trim();
            }
        } catch (Exception ignored) {
            // clipboard not readable right now
        }
        return "";
    }

    // ------------------------------------------------------------------ small helpers

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView mono(String text, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String text, Runnable action) {
        TextView b = mono(text, 9f, Theme.TEXT);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }
}
