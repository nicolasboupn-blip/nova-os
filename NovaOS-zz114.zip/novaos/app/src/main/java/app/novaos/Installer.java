package app.novaos;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Installs an APK through Android's PackageInstaller. Unlike opening the file with a "view" intent, Android tells us
 * exactly why an install failed (different signing key, older version, not allowed to install apps, broken file), and
 * that reason is shown on screen.
 */
final class Installer {
    private Installer() {}

    private static final String ACTION = "app.novaos.INSTALL_RESULT";

    static void install(final NovaActivity host, InputStream apk) {
        final Context app = host.getApplicationContext();
        try {
            if (Build.VERSION.SDK_INT >= 26 && !host.getPackageManager().canRequestPackageInstalls()) {
                host.toast("Allow NOVA to install apps, then pick the file again");
                try {
                    host.startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            android.net.Uri.parse("package:" + host.getPackageName())));
                } catch (Exception ignored) {
                    // the settings page is not there on this phone
                }
                apk.close();
                return;
            }
            PackageInstaller pi = host.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(
                    PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            sp.setAppPackageName(host.getPackageName());
            int id = pi.createSession(sp);
            PackageInstaller.Session session = pi.openSession(id);
            try (InputStream in = apk; OutputStream out = session.openWrite("nova.apk", 0, -1)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                session.fsync(out);
            }
            BroadcastReceiver r = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                    String msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                    if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                        Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                        if (confirm != null) {
                            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            try {
                                c.startActivity(confirm);
                            } catch (Exception e) {
                                host.toast("Could not open the install screen");
                            }
                        }
                        return; // wait for the real result
                    }
                    try {
                        app.unregisterReceiver(this);
                    } catch (Exception ignored) {
                        // already gone
                    }
                    if (status == PackageInstaller.STATUS_SUCCESS) {
                        host.toast("Updated");
                    } else {
                        host.toast("Install failed: " + reason(status, msg));
                    }
                }
            };
            IntentFilter f = new IntentFilter(ACTION);
            if (Build.VERSION.SDK_INT >= 33) {
                app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                app.registerReceiver(r, f);
            }
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pend = PendingIntent.getBroadcast(app, id,
                    new Intent(ACTION).setPackage(app.getPackageName()), flags);
            session.commit(pend.getIntentSender());
            session.close();
        } catch (Exception e) {
            host.toast("Could not start the install: " + e.getMessage());
        }
    }

    private static String reason(int status, String msg) {
        String m = msg == null ? "" : msg;
        if (m.contains("INCOMPATIBLE") || m.contains("signatures") || m.contains("signature")) {
            return "this file is signed with a different key than the NOVA on your phone. Updates only work when every "
                    + "build uses the same signing key (nova.jks). (" + m + ")";
        }
        if (m.contains("DOWNGRADE")) {
            return "this build is older than the one installed (the build number must go up). (" + m + ")";
        }
        if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            return "cancelled";
        }
        if (status == PackageInstaller.STATUS_FAILURE_BLOCKED) {
            return "blocked by the phone. " + m;
        }
        if (status == PackageInstaller.STATUS_FAILURE_INVALID) {
            return "the file is not a valid NOVA app (broken download?). " + m;
        }
        return m.isEmpty() ? "status " + status : m;
    }
}
