package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** PEAKFINDER: a normal map with the peaks marked (about 40 km around you), and a STICKS horizon around you. */
final class PeakFinder extends FrameLayout implements BackAware {
    static final int MAP = 0;
    static final int STICKS = 1;
    static final int CAM = 2;
    private static final String FINE = android.Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COARSE = android.Manifest.permission.ACCESS_COARSE_LOCATION;

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final FrameLayout body;
    private final TextView status;
    private final TextView info;
    private final TextView tabMap;
    private final TextView tabCam;
    private final TextView tab3d;
    private final TextView headChip;
    private final TextView zoomIn;
    private final TextView zoomOut;
    private final TextView darkChip;
    private int tab;
    private PeakTileMap map;
    private PeakSticks sticks;
    private PeakCam cam;
    private boolean busy;
    private PeakData.Peak picked;

    PeakFinder(NovaActivity host, int startTab) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(48), dp(12), dp(10));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("PEAKFINDER", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("RANGE", () -> {
            int[] steps = {10, 20, 40, 60, 80};
            int next = steps[0];
            for (int i = 0; i < steps.length; i++) {
                if (steps[i] == PeakData.km) {
                    next = steps[(i + 1) % steps.length];
                }
            }
            PeakData.setKm(next);
            host.toast("Range " + next + " km");
            if (map != null) {
                map.fitRange();
            }
            reload();
        }));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout tabs = new LinearLayout(host);
        tabs.setPadding(0, dp(8), 0, dp(6));
        tabMap = chip("MAP", () -> show(MAP));
        tab3d = chip("3D", () -> show(CAM));
        tabCam = chip("STICKS", () -> show(STICKS));
        headChip = chip("ME", () -> {
            if (map != null) {
                map.fitRange();
            }
        });
        tabs.addView(tabMap);
        tabs.addView(tab3d);
        tabs.addView(tabCam);
        zoomIn = chip("+", () -> {
            if (map != null) {
                map.zoomBy(1);
            }
        });
        zoomOut = chip("\u2212", () -> {
            if (map != null) {
                map.zoomBy(-1);
            }
        });
        darkChip = chip("DARK", () -> {
            if (map != null) {
                map.dark = !map.dark;
                Prefs.putBool("pk_darkmap", map.dark);
                map.invalidate();
            }
        });
        tabs.addView(zoomIn);
        tabs.addView(zoomOut);
        tabs.addView(headChip);
        tabs.addView(darkChip);
        android.widget.HorizontalScrollView tabScroll = new android.widget.HorizontalScrollView(host);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.addView(tabs);
        col.addView(tabScroll);

        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START);
        status.setPadding(dp(4), 0, dp(4), dp(6));
        status.setOnClickListener(v -> askAltitude());
        col.addView(status);

        body = new FrameLayout(host);
        col.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));

        info = text("Tap a peak", 12f, Theme.TEXT);
        info.setGravity(Gravity.START);
        info.setPadding(dp(8), dp(8), dp(8), dp(4));
        info.setOnClickListener(v -> openInMaps());
        col.addView(info);
        addView(col, new FrameLayout.LayoutParams(-1, -1));

        PeakData.restore();
        show(startTab);
        if (PeakData.have) {
            reload(); // the last known position is good enough to show something right away
        }
        locate();
    }

    private void show(int which) {
        tab = which;
        body.removeAllViews();
        map = null;
        sticks = null;
        cam = null;
        PeakMapView.Pick pick = p -> {
            picked = p;
            info.setText(p == null ? "Tap a peak" : p.name + "  ·  " + p.ele + " m  ·  "
                + p.distText() + " " + p.compass() + "  ·  " + (p.up >= 0 ? "+" : "") + String.format(java.util.Locale.ROOT,
                "%.1f", p.up) + "° above you" + (p.hidden ? "  ·  maybe hidden behind a nearer peak" : "")
                    + (p == null ? "" : "\n\u25B6 tap here to open it in Google Maps"));
        };
        if (which == CAM) {
            cam = new PeakCam(host);
            cam.listener = pick;
            body.addView(cam, new FrameLayout.LayoutParams(-1, -1));
        } else if (which == STICKS) {
            sticks = new PeakSticks(host);
            sticks.listener = pick;
            body.addView(sticks, new FrameLayout.LayoutParams(-1, -1));
        } else {
            map = new PeakTileMap(host);
            map.dark = Prefs.getBool("pk_darkmap", false);
            map.listener = pick;
            body.addView(map, new FrameLayout.LayoutParams(-1, -1));
        }
        pickChip(tabMap, which == MAP);
        pickChip(tabCam, which == STICKS);
        pickChip(tab3d, which == CAM);
        int vis = which == MAP ? VISIBLE : GONE;
        headChip.setVisibility(vis);
        zoomIn.setVisibility(vis);
        zoomOut.setVisibility(vis);
        darkChip.setVisibility(vis);
        updateStatus();
    }

    /** Opens the chosen peak in Google Maps (or any maps app) with the phone's own map link. */
    private void openInMaps() {
        if (picked == null) {
            return;
        }
        try {
            android.net.Uri u = android.net.Uri.parse("geo:" + picked.lat + "," + picked.lon + "?q=" + picked.lat + ","
                    + picked.lon + "(" + android.net.Uri.encode(picked.name) + ")");
            host.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, u)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            host.toast("No maps app found");
        }
    }

    private void pickChip(TextView t, boolean on) {
        t.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
        t.setTextColor(on ? Theme.BG : Theme.ACCENT);
    }

    private void updateStatus() {
        if (!PeakData.have) {
            status.setText("Finding your position...");
            return;
        }
        status.setText(String.format(java.util.Locale.ROOT, "%.3f, %.3f  ·  %d m  ·  %d peaks within %d km  (tap to set your height)",
                PeakData.myLat, PeakData.myLon, Math.round(PeakData.myAlt()), PeakData.peaks.size(), PeakData.km));
    }

    private void askAltitude() {
        final EditText e = new EditText(host);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setHint("your height above sea level in metres");
        e.setText(Prefs.getString("pk_alt_manual", ""));
        new AlertDialog.Builder(host).setTitle("Your height")
                .setMessage("GPS height can be off by tens of metres. If you know it (a map, a sign on the mountain), "
                        + "type it. Empty uses the GPS.")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    Prefs.putString("pk_alt_manual", e.getText().toString().trim());
                    PeakData.compute(PeakData.peaks);
                    updateStatus();
                    if (map != null) {
                        map.invalidate();
                    }
                    if (sticks != null) {
                        sticks.invalidate();
                    }
                    if (cam != null) {
                        cam.invalidate();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ position and data

    private void locate() {
        if (busy) {
            return;
        }
        // "approximate location" is enough: a partial grant must not count as a refusal
        host.ask(new String[] {FINE, COARSE}, this::readLocation, () -> {
            if (host.checkSelfPermission(FINE) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    || host.checkSelfPermission(COARSE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                readLocation();
            } else {
                status.setText("Location is off for NOVA. Allow it in Android settings > Apps > NOVA.");
            }
        });
    }

    private void readLocation() {
        final LocationManager lm = (LocationManager) host.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isLocationEnabled()) {
            status.setText("Switch on Location in the quick settings first.");
            return;
        }
        busy = true;
        Location best = null;
        try {
            for (String prov : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(prov);
                if (l != null && (best == null || l.getTime() > best.getTime())) {
                    best = l;
                }
            }
        } catch (SecurityException e) {
            busy = false;
            return;
        }
        if (best != null && System.currentTimeMillis() - best.getTime() < 20 * 60 * 1000L) {
            got(best);
            return;
        }
        final Location stale = best;
        final LocationListener ll = new LocationListener() {
            @Override
            public void onLocationChanged(Location l) {
                lm.removeUpdates(this);
                got(l);
            }
        };
        try {
            String prov = lm.getProviders(true).contains(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER
                    : LocationManager.NETWORK_PROVIDER;
            lm.requestSingleUpdate(prov, ll, Looper.getMainLooper());
        } catch (RuntimeException e) {
            busy = false;
            if (stale != null) {
                got(stale);
            }
            return;
        }
        ui.postDelayed(() -> {
            if (busy) {
                lm.removeUpdates(ll);
                if (stale != null) {
                    got(stale);
                } else {
                    busy = false;
                    status.setText("No position yet. Try outside or near a window.");
                }
            }
        }, 20000);
    }

    private void got(Location l) {
        busy = false;
        PeakData.setPosition(l.getLatitude(), l.getLongitude(), l.getAltitude(), l.hasAltitude());
        reload();
    }

    private void reload() {
        if (!PeakData.have) {
            return;
        }
        status.setText("Loading peaks...");
        PeakData.load(host.getApplicationContext(), PeakData.myLat, PeakData.myLon, PeakData.km, (list, err) -> {
            if (err != null) {
                status.setText(err + "  (tap RANGE to try a smaller area)");
            } else {
                updateStatus();
            }
            if (map != null) {
                map.invalidate();
            }
            if (sticks != null) {
                sticks.invalidate();
            }
            if (cam != null) {
                cam.invalidate();
            }
        });
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener((View v) -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
