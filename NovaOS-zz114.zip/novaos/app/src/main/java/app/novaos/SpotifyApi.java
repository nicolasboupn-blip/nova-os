package app.novaos;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * Plays Spotify songs from the deck without opening the Spotify app. NOVA asks Spotify's own Web API to start the song on
 * this phone's Spotify (which only has to be running in the background). It uses the person's own Spotify developer app
 * (Client ID) and the PKCE login, so no password or secret is stored, only a refresh token on this phone. Needs Spotify
 * Premium. Without a connection the deck falls back to opening the song in the Spotify app, as before.
 */
final class SpotifyApi {
    private SpotifyApi() {}

    static final String K_ID = "sp_client_id";
    static final String K_REFRESH = "sp_refresh";
    private static final String K_ACCESS = "sp_access";
    private static final String K_EXPIRES = "sp_expires";
    static final String PORT_NOTE = "8888";
    static final String REDIRECT = "http://127.0.0.1:" + PORT_NOTE + "/callback";
    private static final String SCOPE = "user-modify-playback-state user-read-playback-state";
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private static volatile ServerSocket waiting;

    static String clientId() {
        return Prefs.getString(K_ID, "").trim();
    }

    static boolean connected() {
        return !clientId().isEmpty() && !Prefs.getString(K_REFRESH, "").isEmpty();
    }

    static void disconnect() {
        Prefs.putString(K_REFRESH, "");
        Prefs.putString(K_ACCESS, "");
        Prefs.putString(K_EXPIRES, "0");
    }

    // ------------------------------------------------------------------ login (PKCE, answer caught on this phone)

    /** Opens the Spotify login in the browser and waits for the answer on 127.0.0.1. */
    static void connect(final NovaActivity host) {
        final String id = clientId();
        if (id.isEmpty()) {
            host.toast("Enter your Spotify Client ID first");
            return;
        }
        try {
            final String verifier = randomUrlSafe(64);
            final String challenge = Base64.encodeToString(
                    MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)),
                    Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
            final String state = randomUrlSafe(16);
            closeWaiting();
            final ServerSocket ss = new ServerSocket(Integer.parseInt(PORT_NOTE), 1,
                    InetAddress.getByName("127.0.0.1"));
            ss.setSoTimeout(180000);
            waiting = ss;
            new Thread(() -> catchRedirect(host, ss, id, verifier, state), "nova-spotify-login").start();
            String url = "https://accounts.spotify.com/authorize?response_type=code"
                    + "&client_id=" + enc(id)
                    + "&scope=" + enc(SCOPE)
                    + "&redirect_uri=" + enc(REDIRECT)
                    + "&state=" + enc(state)
                    + "&code_challenge_method=S256&code_challenge=" + enc(challenge);
            host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            closeWaiting();
            host.toast("Could not start the Spotify login: " + e.getMessage());
        }
    }

    private static void closeWaiting() {
        ServerSocket s = waiting;
        waiting = null;
        if (s != null) {
            try {
                s.close();
            } catch (Exception ignored) {
                // already closed
            }
        }
    }

    private static void catchRedirect(final NovaActivity host, ServerSocket ss, String id, String verifier,
            String state) {
        String code = null;
        String error = null;
        try (Socket s = ss.accept()) {
            s.setSoTimeout(5000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII));
            String line = in.readLine(); // GET /callback?code=...&state=... HTTP/1.1
            String page = "<html><body style='font-family:sans-serif;background:#080614;color:#fff;padding:40px'>"
                    + "<h2>NOVA is connected to Spotify</h2><p>You can close this tab and go back to NOVA.</p>"
                    + "</body></html>";
            if (line != null) {
                String[] p = line.split(" ");
                if (p.length > 1) {
                    Uri u = Uri.parse("http://127.0.0.1" + p[1]);
                    if (state.equals(u.getQueryParameter("state"))) {
                        code = u.getQueryParameter("code");
                        error = u.getQueryParameter("error");
                    } else {
                        error = "wrong answer, try again";
                    }
                }
            }
            if (code == null) {
                page = "<html><body style='font-family:sans-serif;padding:40px'><h2>Spotify said no</h2><p>"
                        + (error == null ? "no code" : error.replace("<", "")) + "</p></body></html>";
            }
            OutputStream out = s.getOutputStream();
            byte[] body = page.getBytes(StandardCharsets.UTF_8);
            out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + body.length
                    + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            out.write(body);
            out.flush();
        } catch (Exception e) {
            error = "timed out or cancelled";
        } finally {
            // close only this login's socket, a newer login may already be waiting on its own
            try {
                ss.close();
            } catch (Exception ignored) {
                // already closed
            }
            if (waiting == ss) {
                waiting = null;
            }
        }
        if (code == null) {
            final String why = error == null ? "no answer" : error;
            ui.post(() -> host.toast("Spotify login failed: " + why));
            return;
        }
        try {
            String form = "grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT)
                    + "&client_id=" + enc(id) + "&code_verifier=" + enc(verifier);
            String[] r = http("POST", "https://accounts.spotify.com/api/token", form,
                    "application/x-www-form-urlencoded", null);
            JSONObject j = new JSONObject(r[1]);
            if (!r[0].startsWith("2") || !j.has("access_token")) {
                final String why = j.optString("error_description", j.optString("error", "code " + r[0]));
                ui.post(() -> host.toast("Spotify login failed: " + why));
                return;
            }
            save(j);
            ui.post(() -> host.toast("Spotify connected. Song pads now play without opening Spotify"));
        } catch (Exception e) {
            ui.post(() -> host.toast("Spotify login failed: " + e.getMessage()));
        }
    }

    private static void save(JSONObject j) {
        Prefs.putString(K_ACCESS, j.optString("access_token", ""));
        Prefs.putString(K_EXPIRES, String.valueOf(System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L));
        String rt = j.optString("refresh_token", "");
        if (!rt.isEmpty()) {
            Prefs.putString(K_REFRESH, rt);
        }
    }

    /** A valid access token, refreshed when it is about to run out. Blocks, so call it on a background thread. */
    private static String token(boolean forceRefresh) {
        long exp = 0;
        try {
            exp = Long.parseLong(Prefs.getString(K_EXPIRES, "0"));
        } catch (NumberFormatException ignored) {
            // treated as expired
        }
        String at = Prefs.getString(K_ACCESS, "");
        if (!forceRefresh && !at.isEmpty() && System.currentTimeMillis() < exp - 30000) {
            return at;
        }
        String rt = Prefs.getString(K_REFRESH, "");
        if (rt.isEmpty()) {
            return null;
        }
        try {
            String form = "grant_type=refresh_token&refresh_token=" + enc(rt) + "&client_id=" + enc(clientId());
            String[] r = http("POST", "https://accounts.spotify.com/api/token", form,
                    "application/x-www-form-urlencoded", null);
            JSONObject j = new JSONObject(r[1]);
            if (r[0].startsWith("2") && j.has("access_token")) {
                save(j);
                return j.getString("access_token");
            }
            if (r[0].equals("400") || r[0].equals("401")) {
                disconnect(); // the login was taken back, ask the person to connect again
            }
        } catch (Exception ignored) {
            // offline: try again next time
        }
        return null;
    }

    // ------------------------------------------------------------------ playing

    /**
     * Starts the Spotify link (a spotify: uri) on this phone. If Spotify is not running on the phone, openSpotify runs
     * (it opens the Spotify app), and a few seconds later the play request is sent again.
     */
    static void play(final NovaActivity host, final String uri, final Runnable openSpotify) {
        final android.content.Context app = host.getApplicationContext();
        new Thread(() -> {
            String result = attempt(uri, null);
            if (result.equals("ok")) {
                return;
            }
            if (result.equals("nodevice")) {
                if (openSpotify != null) {
                    ui.post(openSpotify);
                    try {
                        Thread.sleep(3500);
                    } catch (InterruptedException ignored) {
                        return;
                    }
                    String second = attempt(uri, null);
                    if (second.equals("ok")) {
                        ui.post(() -> backToNova(app));
                        return;
                    }
                    result = second;
                }
                if (result.equals("nodevice")) {
                    final String m = "Spotify is not running on this phone. Open it once, then try again";
                    ui.post(() -> host.toast(m));
                    return;
                }
            }
            final String msg = result;
            ui.post(() -> host.toast(msg));
        }, "nova-spotify-play").start();
    }

    /** Finds a song by its name through Spotify search, then plays it like play(). openSpotify runs if anything fails. */
    static void playSearch(final NovaActivity host, final String query, final Runnable openSpotify) {
        new Thread(() -> {
            String uri = null;
            try {
                String tk = token(false);
                if (tk != null) {
                    String[] r = http("GET", "https://api.spotify.com/v1/search?type=track&limit=1&q=" + enc(query),
                            null, null, tk);
                    if (r[0].startsWith("2")) {
                        JSONArray a = new JSONObject(r[1]).getJSONObject("tracks").getJSONArray("items");
                        if (a.length() > 0) {
                            uri = a.getJSONObject(0).optString("uri", "");
                        }
                    }
                }
            } catch (Exception ignored) {
                // falls back to opening a search
            }
            if (uri == null || uri.isEmpty()) {
                ui.post(openSpotify);
            } else {
                play(host, uri, openSpotify);
            }
        }, "nova-spotify-search").start();
    }

    private static void backToNova(android.content.Context app) {
        try {
            app.startActivity(new Intent(app, NovaActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
        } catch (Exception ignored) {
            // Android did not allow it, the person can press home
        }
    }

    /** "ok", "nodevice", or a short text to show the person. */
    private static String attempt(String uri, String deviceId) {
        String tk = token(false);
        if (tk == null) {
            return "Spotify login ran out. Connect again in Settings > SPOTIFY";
        }
        try {
            String type = uri.split(":").length > 1 ? uri.split(":")[1] : "track";
            boolean single = type.equals("track") || type.equals("episode");
            JSONObject body = new JSONObject();
            if (single) {
                body.put("uris", new JSONArray().put(uri));
            } else {
                body.put("context_uri", uri);
            }
            String url = "https://api.spotify.com/v1/me/player/play"
                    + (deviceId == null ? "" : "?device_id=" + enc(deviceId));
            String[] r = http("PUT", url, body.toString(), "application/json", tk);
            if (r[0].equals("401")) {
                tk = token(true);
                if (tk == null) {
                    return "Spotify login ran out. Connect again in Settings > SPOTIFY";
                }
                r = http("PUT", url, body.toString(), "application/json", tk);
            }
            switch (r[0]) {
                case "200":
                case "202":
                case "204":
                    return "ok";
                case "404": {
                    if (deviceId != null) {
                        return "nodevice";
                    }
                    String dev = pickDevice(tk);
                    return dev == null ? "nodevice" : attempt(uri, dev);
                }
                case "403":
                    return "Spotify refused: " + reason(r[1], "Premium is needed to control playback");
                case "429":
                    return "Spotify says slow down, try again in a moment";
                default:
                    return "Spotify error " + r[0] + ": " + reason(r[1], "unknown");
            }
        } catch (Exception e) {
            return "Could not reach Spotify (" + e.getClass().getSimpleName() + ")";
        }
    }

    /** The phone's own Spotify first, then any other device that is awake. */
    private static String pickDevice(String tk) {
        try {
            String[] r = http("GET", "https://api.spotify.com/v1/me/player/devices", null, null, tk);
            if (!r[0].startsWith("2")) {
                return null;
            }
            JSONArray a = new JSONObject(r[1]).optJSONArray("devices");
            if (a == null || a.length() == 0) {
                return null;
            }
            String phone = null;
            String active = null;
            String any = null;
            for (int i = 0; i < a.length(); i++) {
                JSONObject d = a.getJSONObject(i);
                String id = d.optString("id", "");
                if (id.isEmpty() || d.optBoolean("is_restricted", false)) {
                    continue;
                }
                any = any == null ? id : any;
                if (d.optBoolean("is_active", false)) {
                    active = id;
                }
                if ("Smartphone".equalsIgnoreCase(d.optString("type", ""))) {
                    phone = phone == null ? id : phone;
                }
            }
            return phone != null ? phone : active != null ? active : any;
        } catch (Exception e) {
            return null;
        }
    }

    private static String reason(String body, String def) {
        try {
            JSONObject e = new JSONObject(body).optJSONObject("error");
            if (e != null) {
                String m = e.optString("message", "");
                if (!m.isEmpty()) {
                    return m;
                }
            }
        } catch (Exception ignored) {
            // not JSON
        }
        return def;
    }

    // ------------------------------------------------------------------ small helpers

    private static String randomUrlSafe(int n) {
        byte[] b = new byte[n];
        new SecureRandom().nextBytes(b);
        String s = Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
        return s.substring(0, Math.min(n, s.length()));
    }

    private static String enc(String s) throws java.io.UnsupportedEncodingException {
        return URLEncoder.encode(s, "UTF-8");
    }

    /** Returns {status code, body}. */
    private static String[] http(String method, String url, String body, String type, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestMethod(method);
        if (bearer != null) {
            c.setRequestProperty("Authorization", "Bearer " + bearer);
        }
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", type);
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            try (OutputStream o = c.getOutputStream()) {
                o.write(b);
            }
        } else if (method.equals("PUT")) {
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(0);
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = "";
        if (in != null) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            in.close();
            text = bo.toString("UTF-8");
        }
        c.disconnect();
        return new String[] {String.valueOf(code), text};
    }
}
