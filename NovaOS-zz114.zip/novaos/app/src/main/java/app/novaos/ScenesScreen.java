package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Your scenes. Tap one to switch to it, EDIT to change it, NEW to make another. */
final class ScenesScreen extends FrameLayout implements BackAware {
    private static final int[] VOLUMES = {-1, 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    private static final int[] BRIGHTS = {-1, 1, 5, 10, 25, 40, 60, 80, 100};

    private final NovaActivity host;
    private final LinearLayout list;

    ScenesScreen(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("SCENES", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.15f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(chip("NEW", () -> {
            Scenes.all().add(new Scenes.Scene());
            Scenes.save();
            build();
            edit(Scenes.all().size() - 1);
        }));
        head.addView(chip("RESET", () -> new AlertDialog.Builder(host).setTitle("Back to the 5 starting scenes?")
                .setPositiveButton("RESET", (d, w) -> {
                    Scenes.resetAll();
                    build();
                }).setNegativeButton("Cancel", null).show()));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView hint = text("tap a scene to switch  ·  your active scene is your status on the profile", 9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(6);
        hlp.bottomMargin = dp(10);
        col.addView(hint, hlp);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, dp(30));
        sv.addView(list);
        col.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        addView(col, new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        build();
    }

    private void build() {
        list.removeAllViews();
        List<Scenes.Scene> all = Scenes.all();
        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            Scenes.Scene s = all.get(i);
            boolean on = Scenes.activeIndex() == i;
            LinearLayout card = new LinearLayout(host);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackground(Theme.rounded(on ? Theme.ACCENT & 0x00FFFFFF | 0x33000000 : Theme.PANEL, 14f, host));
            card.setClickable(true);
            card.setOnClickListener(v -> {
                Scenes.apply(host, idx);
                build();
            });
            TextView name = text(s.emoji + "  " + s.name + (on ? "   (ON)" : ""), 15f, on ? Theme.ACCENT : Theme.TEXT);
            name.setGravity(Gravity.START);
            card.addView(name);
            TextView sub = text(Scenes.describe(s), 10f, Theme.DIM);
            sub.setGravity(Gravity.START);
            sub.setPadding(0, dp(4), 0, 0);
            card.addView(sub);
            LinearLayout acts = new LinearLayout(host);
            acts.addView(chip("EDIT", () -> edit(idx)));
            acts.addView(chip("DELETE", () -> {
                if (Scenes.all().size() > 1) {
                    Scenes.all().remove(idx);
                    if (Scenes.activeIndex() == idx) {
                        Prefs.putInt("scene_active", -1);
                    }
                    Scenes.save();
                    build();
                } else {
                    host.toast("Keep at least one scene");
                }
            }));
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            alp.topMargin = dp(8);
            card.addView(acts, alp);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            clp.bottomMargin = dp(10);
            list.addView(card, clp);
        }
    }

    // ------------------------------------------------------------------ the editor

    private void edit(final int idx) {
        final Scenes.Scene s = Scenes.all().get(idx);
        final EditText name = new EditText(host);
        name.setSingleLine(true);
        name.setText(s.name);
        name.setHint("name");
        final EditText emoji = new EditText(host);
        emoji.setSingleLine(true);
        emoji.setText(s.emoji);
        emoji.setHint("emoji");
        emoji.setFilters(new android.text.InputFilter[] {new android.text.InputFilter.LengthFilter(4)});
        final EditText link = new EditText(host);
        link.setSingleLine(true);
        link.setText(s.link);
        link.setHint("song or web link to open (optional)");

        final int[] vol = {indexOf(VOLUMES, s.volume)};
        final int[] brt = {indexOf(BRIGHTS, s.brightness)};
        final int[] ring = {s.ringer};
        final int[] look = {s.look};
        final int[] acc = {s.accent};
        final int[] from = {s.from < 0 ? 0 : 1 + s.from / 30};
        final int[] days = {s.days};

        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(name);
        box.addView(emoji);
        box.addView(cycler("Volume", () -> VOLUMES[vol[0]] < 0 ? "no change" : VOLUMES[vol[0]] + " %",
                () -> vol[0] = (vol[0] + 1) % VOLUMES.length));
        box.addView(cycler("Brightness", () -> BRIGHTS[brt[0]] < 0 ? "no change" : BRIGHTS[brt[0]] + " %",
                () -> brt[0] = (brt[0] + 1) % BRIGHTS.length));
        box.addView(cycler("Ringer", () -> Scenes.RINGER[ring[0]], () -> ring[0] = (ring[0] + 1) % 3));
        box.addView(cycler("Look of NOVA", () -> Scenes.LOOKS[look[0]], () -> look[0] = (look[0] + 1) % Scenes.LOOKS.length));
        box.addView(cycler("Accent colour", () -> acc[0] < 0 ? "no change" : Theme.PRESET_NAMES[acc[0]],
                () -> acc[0] = acc[0] + 1 >= Theme.PRESET_NAMES.length ? -1 : acc[0] + 1));
        box.addView(cycler("Starts at", () -> from[0] == 0 ? "never (manual)" : Scenes.time((from[0] - 1) * 30),
                () -> from[0] = (from[0] + 1) % 49));
        box.addView(cycler("On days", () -> days[0] == 0 ? "every day" : days[0] == 1 ? "weekdays" : "weekends",
                () -> days[0] = (days[0] + 1) % 3));
        box.addView(link);
        ScrollView sv = new ScrollView(host);
        sv.addView(box);
        new AlertDialog.Builder(host).setTitle("Edit scene").setView(sv)
                .setPositiveButton("SAVE", (d, w) -> {
                    s.name = name.getText().toString().trim().isEmpty() ? "Scene" : name.getText().toString().trim();
                    s.emoji = emoji.getText().toString().trim().isEmpty() ? "✨" : emoji.getText().toString().trim();
                    s.volume = VOLUMES[vol[0]];
                    s.brightness = BRIGHTS[brt[0]];
                    s.ringer = ring[0];
                    s.look = look[0];
                    s.accent = acc[0];
                    s.from = from[0] == 0 ? -1 : (from[0] - 1) * 30;
                    s.days = days[0];
                    s.link = link.getText().toString().trim();
                    Scenes.save();
                    build();
                }).setNegativeButton("Cancel", null).show();
    }

    private int indexOf(int[] a, int v) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] == v) {
                return i;
            }
        }
        return 0;
    }

    /** A row that cycles through its choices on every tap. */
    private View cycler(String label, final java.util.function.Supplier<String> value, final Runnable next) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        TextView l = new TextView(host);
        l.setText(label);
        l.setTextSize(14f);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView v = new TextView(host);
        v.setText(value.get() + "  ›");
        v.setTextSize(14f);
        v.setTextColor(0xFF6A4CFF);
        v.setClickable(true);
        v.setPadding(dp(10), dp(4), 0, dp(4));
        v.setOnClickListener(x -> {
            next.run();
            v.setText(value.get() + "  ›");
        });
        r.addView(v);
        return r;
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
