package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Peak map: you in the middle, distance rings, the peaks around you with name and height. The wedge shows where the
 * camera looks. HEADING UP turns the map the way you face. Pinch to zoom, tap a peak for details.
 */
final class PeakMapView extends View implements SensorEventListener {
    interface Pick {
        void picked(PeakData.Peak p);
    }

    private final boolean interactive;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final SensorManager sm;
    private final float[] rot = new float[9];
    private final ScaleGestureDetector scale;
    private float zoom = 1f;
    private float heading = Float.NaN;
    private float camHeading = Float.NaN;
    boolean headingUp;
    PeakData.Peak selected;
    Pick listener;
    private final List<PeakData.Peak> labelled = new ArrayList<>();
    private final List<float[]> pos = new ArrayList<>();
    private float downX;
    private float downY;

    PeakMapView(Context c, boolean interactive) {
        super(c);
        this.interactive = interactive;
        d = c.getResources().getDisplayMetrics().density;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector g) {
                zoom = Math.max(0.5f, Math.min(6f, zoom * g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (interactive && sm != null) {
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (s != null) {
                sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sm != null) {
            sm.unregisterListener(this);
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(rot, e.values);
        // the camera looks along -Z of the phone; flat on a table the top edge is used instead
        double ce = -rot[2];
        double cn = -rot[5];
        double up = -rot[8];
        double te = rot[1];
        double tn = rot[4];
        float h = (float) Math.toDegrees(Math.atan2(Math.abs(up) < 0.7 ? ce : te, Math.abs(up) < 0.7 ? cn : tn));
        float nh = (h + 360f) % 360f;
        if (Float.isNaN(heading)) {
            heading = nh;
        } else {
            float diff = ((nh - heading + 540f) % 360f) - 180f;
            heading = (heading + diff * 0.2f + 360f) % 360f;
        }
        camHeading = heading;
        invalidate();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    float heading() {
        return heading;
    }

    private float ppk() {
        return (Math.min(getWidth(), getHeight()) / 2f - 26 * d) / PeakData.km * zoom;
    }

    private float[] toScreen(double eastM, double northM) {
        double e = eastM / 1000.0;
        double n = northM / 1000.0;
        if (headingUp && !Float.isNaN(heading)) {
            double h = Math.toRadians(heading);
            double e2 = e * Math.cos(h) - n * Math.sin(h);
            double n2 = e * Math.sin(h) + n * Math.cos(h);
            e = e2;
            n = n2;
        }
        float k = ppk();
        return new float[] {getWidth() / 2f + (float) e * k, getHeight() / 2f - (float) n * k};
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33000000);
        cv.drawRoundRect(new RectF(0, 0, w, h), 14 * d, 14 * d, p);

        // distance rings
        float k = ppk();
        double ringKm = PeakData.km <= 15 ? 5 : PeakData.km <= 40 ? 10 : 20;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(d);
        p.setTextSize(9 * d);
        for (double r = ringKm; r <= PeakData.km * 1.5; r += ringKm) {
            p.setColor(0x22FFFFFF);
            p.setStyle(Paint.Style.STROKE);
            cv.drawCircle(cx, cy, (float) r * k, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x66FFFFFF);
            cv.drawText((int) r + " km", cx + 3 * d, cy - (float) r * k - 2 * d, p);
        }

        // where the camera looks
        if (!Float.isNaN(camHeading)) {
            Path wedge = new Path();
            wedge.moveTo(cx, cy);
            for (int s = -1; s <= 1; s += 2) {
                double a = Math.toRadians(camHeading + s * 28);
                float[] q = toScreen(Math.sin(a) * PeakData.km * 1000.0, Math.cos(a) * PeakData.km * 1000.0);
                wedge.lineTo(q[0], q[1]);
            }
            wedge.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x28000000);
            cv.drawPath(wedge, p);
        }

        // north mark
        float[] nn = toScreen(0, 1000.0 * PeakData.km * 0.98);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF6B6B);
        p.setTextSize(12 * d);
        p.setTextAlign(Paint.Align.CENTER);
        cv.drawText("N", nn[0], nn[1], p);
        p.setTextAlign(Paint.Align.LEFT);

        // peaks: the high ones get names first, names never overlap
        labelled.clear();
        pos.clear();
        List<PeakData.Peak> list;
        synchronized (PeakData.peaks) {
            list = new ArrayList<>(PeakData.peaks);
        }
        list.sort((a, b) -> b.ele - a.ele);
        List<RectF> used = new ArrayList<>();
        int named = 0;
        p.setTextSize(10 * d);
        double limitM = PeakData.km * 1000.0 * 1.5 / zoom;
        for (PeakData.Peak pk : list) {
            if (pk.dist > PeakData.km * 1000.0) {
                continue;
            }
            float[] q = toScreen(pk.east, pk.north);
            if (q[0] < -10 || q[1] < -10 || q[0] > w + 10 || q[1] > h + 10) {
                continue;
            }
            float size = (pk.ele > 3500 ? 7 : pk.ele > 2500 ? 6 : 4.5f) * d;
            boolean sel = pk == selected;
            p.setStyle(Paint.Style.FILL);
            p.setColor(sel ? 0xFFFFFFFF : pk.ele > 3000 ? Theme.ACCENT : pk.hidden ? 0x66FFFFFF : 0xFFCFD6EA);
            Path tri = new Path();
            tri.moveTo(q[0], q[1] - size);
            tri.lineTo(q[0] - size, q[1] + size * 0.7f);
            tri.lineTo(q[0] + size, q[1] + size * 0.7f);
            tri.close();
            cv.drawPath(tri, p);
            labelled.add(pk);
            pos.add(q);
            if (named < 45 || sel) {
                String t = pk.name + " " + pk.ele;
                float tw = p.measureText(t);
                RectF r = new RectF(q[0] + size + 2 * d, q[1] - 7 * d, q[0] + size + 4 * d + tw, q[1] + 5 * d);
                boolean free = true;
                for (RectF u : used) {
                    if (RectF.intersects(u, r)) {
                        free = false;
                        break;
                    }
                }
                if (free || sel) {
                    used.add(r);
                    named++;
                    p.setColor(sel ? 0xFFFFFFFF : pk.hidden ? 0x88FFFFFF : 0xFFEAF0FF);
                    cv.drawText(t, r.left + d, q[1] + 3 * d, p);
                }
            }
        }

        // you
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF3DDC97);
        cv.drawCircle(cx, cy, 5 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0x883DDC97);
        cv.drawCircle(cx, cy, 9 * d, p);
        p.setStyle(Paint.Style.FILL);
        if (!PeakData.have) {
            p.setColor(0xCCFFFFFF);
            p.setTextSize(12 * d);
            p.setTextAlign(Paint.Align.CENTER);
            cv.drawText("waiting for your position", cx, cy + 40 * d, p);
            p.setTextAlign(Paint.Align.LEFT);
        } else if (labelled.isEmpty()) {
            p.setColor(0xCCFFFFFF);
            p.setTextSize(11 * d);
            p.setTextAlign(Paint.Align.CENTER);
            cv.drawText("no peaks loaded yet", cx, cy + 40 * d, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!interactive) {
            return false;
        }
        scale.onTouchEvent(e);
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            getParent().requestDisallowInterceptTouchEvent(true);
        } else if (e.getAction() == MotionEvent.ACTION_UP && !scale.isInProgress()
                && Math.abs(e.getX() - downX) < 12 * d && Math.abs(e.getY() - downY) < 12 * d) {
            PeakData.Peak best = null;
            float bd = 30 * d;
            for (int i = 0; i < labelled.size(); i++) {
                float[] q = pos.get(i);
                float dd = (float) Math.hypot(q[0] - e.getX(), q[1] - e.getY());
                if (dd < bd) {
                    bd = dd;
                    best = labelled.get(i);
                }
            }
            selected = best;
            if (listener != null) {
                listener.picked(best);
            }
            invalidate();
        }
        return true;
    }
}
