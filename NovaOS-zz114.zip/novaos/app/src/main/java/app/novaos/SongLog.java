package app.novaos;

import android.content.ComponentName;
import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Remembers which songs you play, from the music notification (title and artist only, kept on this phone), and holds
 * your pinned songs. The SONGS widget shows both. Plays are counted when a new song starts.
 */
final class SongLog {
    private SongLog() {}

    static final String K_ON = "songlog_on";
    private static final String K_LOG = "songlog_v1";
    private static final String K_PINS = "songpins_v1";
    private static final int MAX_LINES = 1200;
    private static final long KEEP_MS = 14L * 24 * 3600 * 1000;

    static final class Song {
        String title;
        String artist;
        String link = "";
        int plays;
        long last;
    }

    private static long lastAt;
    private static String lastKey = "";

    static boolean on() {
        return Prefs.getBool(K_ON, true);
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    /** Is this notification from a music player? */
    static boolean isMusic(String pkg) {
        if (pkg == null) {
            return false;
        }
        String p = pkg.toLowerCase(java.util.Locale.ROOT);
        return p.contains("spotify") || p.contains("music") || p.contains("deezer") || p.contains("tidal")
                || p.contains("soundcloud") || p.contains("pandora") || p.contains("vlc") || p.contains("poweramp");
    }

    /** Called from the notification service when a music notification shows a song. */
    static synchronized void record(String title, String artist, String pkg) {
        if (!on() || !isMusic(pkg)) {
            return;
        }
        String t = clean(title);
        String a = clean(artist);
        if (t.isEmpty() || t.equalsIgnoreCase("spotify") || t.equalsIgnoreCase("advertisement")) {
            return;
        }
        long now = System.currentTimeMillis();
        String key = (t + "\u0001" + a).toLowerCase(java.util.Locale.ROOT);
        // the same notification updates when you pause or press play: count one play per song start
        if (key.equals(lastKey) && now - lastAt < 4 * 60 * 1000L) {
            lastAt = now;
            return;
        }
        lastKey = key;
        lastAt = now;
        String log = Prefs.getString(K_LOG, "");
        String line = now + "\t" + t + "\t" + a;
        log = log.isEmpty() ? line : log + "\n" + line;
        // keep the file small: drop old lines and cap the count
        String[] lines = log.split("\n");
        if (lines.length > MAX_LINES) {
            lines = java.util.Arrays.copyOfRange(lines, lines.length - MAX_LINES, lines.length);
        }
        List<String> keep = new ArrayList<>();
        for (String l : lines) {
            int tab = l.indexOf('\t');
            try {
                if (tab > 0 && now - Long.parseLong(l.substring(0, tab)) <= KEEP_MS) {
                    keep.add(l);
                }
            } catch (NumberFormatException ignored) {
                // skip a broken line
            }
        }
        Prefs.putString(K_LOG, TextUtils.join("\n", keep));
    }

    static void clear() {
        Prefs.putString(K_LOG, "");
        lastKey = "";
    }

    /** The songs played in the last days, the most played first. */
    static List<Song> top(int days, int max) {
        long since = System.currentTimeMillis() - days * 24L * 3600 * 1000;
        Map<String, Song> map = new HashMap<>();
        String log = Prefs.getString(K_LOG, "");
        if (!log.isEmpty()) {
            for (String l : log.split("\n")) {
                String[] p = l.split("\t", -1);
                if (p.length < 3) {
                    continue;
                }
                try {
                    long ts = Long.parseLong(p[0]);
                    if (ts < since) {
                        continue;
                    }
                    String key = (p[1] + "\u0001" + p[2]).toLowerCase(java.util.Locale.ROOT);
                    Song s = map.get(key);
                    if (s == null) {
                        s = new Song();
                        s.title = p[1];
                        s.artist = p[2];
                        map.put(key, s);
                    }
                    s.plays++;
                    s.last = Math.max(s.last, ts);
                } catch (NumberFormatException ignored) {
                    // skip a broken line
                }
            }
        }
        List<Song> out = new ArrayList<>(map.values());
        Collections.sort(out, (x, y) -> x.plays != y.plays ? y.plays - x.plays : Long.compare(y.last, x.last));
        return out.size() > max ? new ArrayList<>(out.subList(0, max)) : out;
    }

    // ------------------------------------------------------------------ pins

    static List<Song> pins() {
        List<Song> out = new ArrayList<>();
        String raw = Prefs.getString(K_PINS, "");
        if (!raw.isEmpty()) {
            for (String l : raw.split("\n")) {
                String[] p = l.split("\t", -1);
                if (p.length >= 3) {
                    Song s = new Song();
                    s.title = p[0];
                    s.artist = p[1];
                    s.link = p[2];
                    out.add(s);
                }
            }
        }
        return out;
    }

    private static void savePins(List<Song> pins) {
        List<String> lines = new ArrayList<>();
        for (Song s : pins) {
            lines.add(clean(s.title) + "\t" + clean(s.artist) + "\t" + clean(s.link));
        }
        Prefs.putString(K_PINS, TextUtils.join("\n", lines));
    }

    static boolean isPinned(String title, String artist) {
        for (Song s : pins()) {
            if (s.title.equalsIgnoreCase(title) && s.artist.equalsIgnoreCase(artist)) {
                return true;
            }
        }
        return false;
    }

    static void pin(String title, String artist, String link) {
        if (isPinned(title, artist)) {
            return;
        }
        List<Song> p = pins();
        Song s = new Song();
        s.title = clean(title);
        s.artist = clean(artist);
        s.link = clean(link);
        p.add(s);
        savePins(p);
    }

    static void unpin(String title, String artist) {
        List<Song> p = pins();
        p.removeIf(s -> s.title.equalsIgnoreCase(title) && s.artist.equalsIgnoreCase(artist));
        savePins(p);
    }

    // ------------------------------------------------------------------ playing a song from the list

    /**
     * Plays a song. With a link it uses the deck's link player. Without one it searches: through your connected Spotify
     * if there is one, otherwise by asking the running music player, otherwise by opening a Spotify search.
     */
    static void play(final NovaActivity host, Song s) {
        if (s.link != null && !s.link.isEmpty()) {
            DeckBinds.playLink(host, s.link);
            return;
        }
        final String query = (s.title + " " + s.artist).trim();
        if (SpotifyApi.connected()) {
            SpotifyApi.playSearch(host, query, () -> openSearch(host, query));
            return;
        }
        Context c = host.getApplicationContext();
        if (NovaNotificationService.hasAccess(c)) {
            try {
                MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
                for (MediaController mc : m.getActiveSessions(new ComponentName(c, NovaNotificationService.class))) {
                    if (isMusic(mc.getPackageName())) {
                        mc.getTransportControls().playFromSearch(query, null);
                        return;
                    }
                }
            } catch (Exception ignored) {
                // no player to ask, open the search instead
            }
        }
        openSearch(host, query);
    }

    private static void openSearch(NovaActivity host, String query) {
        try {
            host.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,
                    Uri.parse("spotify:search:" + Uri.encode(query)))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                host.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("https://open.spotify.com/search/" + Uri.encode(query)))
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
                host.toast("Could not open a music app");
            }
        }
    }
}
