package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.GeomagneticField;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Size;
import android.util.SizeF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 3D view: your live camera with the mountains drawn where they really are. The phone's rotation sensor gives the exact
 * direction the camera looks (left/right, up/down and tilt), every peak is projected onto the screen from its compass
 * direction and its angle above the horizon, so names stick to the real peaks as you turn. Pinch to match the zoom of
 * the camera if the labels sit a little off. Without camera permission the same view is drawn on a dark background.
 */
final class PeakCam extends FrameLayout implements SensorEventListener {
    private final NovaActivity host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final TextureView tv;
    private final Overlay overlay;
    private final SensorManager sm;
    private final float[] rot = new float[9];
    private final float[] tmp = new float[9];
    private boolean haveRot;
    private HandlerThread thread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private Size previewSize;
    private int sensorOrientation = 90;
    private boolean wanted;
    private boolean opening;
    private String camNote = "";
    // half-angle tangents of the camera: along the long side and the short side of the sensor
    private double halfLong = Math.tan(Math.toRadians(36));
    private double halfShort = Math.tan(Math.toRadians(28));
    private float calib = 1f;
    private double decl;
    PeakData.Peak selected;
    PeakMapView.Pick listener;

    PeakCam(NovaActivity host) {
        super(host);
        this.host = host;
        sm = (SensorManager) host.getSystemService(Context.SENSOR_SERVICE);
        setBackgroundColor(0xFF05060C);
        setClipChildren(true);
        tv = new TextureView(host);
        addView(tv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        overlay = new Overlay(host);
        addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        try {
            calib = Math.max(0.5f, Math.min(2f, Float.parseFloat(Prefs.getString("pk_arcal", "1"))));
        } catch (NumberFormatException e) {
            calib = 1f;
        }
    }

    // ------------------------------------------------------------------ life

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (sm != null) {
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (s != null) {
                sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
            }
        }
        if (PeakData.have) {
            try {
                decl = new GeomagneticField((float) PeakData.myLat, (float) PeakData.myLon, (float) PeakData.myAlt(),
                        System.currentTimeMillis()).getDeclination();
            } catch (RuntimeException e) {
                decl = 0;
            }
        }
        host.ask(new String[] {android.Manifest.permission.CAMERA}, () -> {
            wanted = true;
            startWhenReady();
        }, () -> {
            camNote = "No camera permission: drawing on a dark background";
            overlay.invalidate();
        });
    }

    @Override
    protected void onDetachedFromWindow() {
        wanted = false;
        if (sm != null) {
            sm.unregisterListener(this);
        }
        closeCamera();
        if (thread != null) {
            thread.quitSafely();
            thread = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(tmp, e.values);
        if (!haveRot) {
            System.arraycopy(tmp, 0, rot, 0, 9);
            haveRot = true;
        } else {
            for (int i = 0; i < 9; i++) {
                rot[i] += (tmp[i] - rot[i]) * 0.35f;
            }
        }
        overlay.invalidate();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    // ------------------------------------------------------------------ camera (preview only)

    private void startWhenReady() {
        if (tv.isAvailable()) {
            openCamera();
            return;
        }
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                if (wanted) {
                    openCamera();
                }
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture st) {
            }
        });
    }

    private void fail(String why) {
        opening = false;
        camNote = why + ": drawing on a dark background";
        main.post(overlay::invalidate);
    }

    private void openCamera() {
        if (opening || device != null || !wanted) {
            return;
        }
        opening = true;
        try {
            CameraManager cm = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            CameraCharacteristics chars = null;
            for (String cid : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(cid);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = cid;
                    chars = c;
                    break;
                }
            }
            if (id == null) {
                fail("No back camera");
                return;
            }
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Integer so = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOrientation = so == null ? 90 : so;
            previewSize = choose(map.getOutputSizes(SurfaceTexture.class));
            SizeF phys = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
            float[] focal = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            if (phys != null && focal != null && focal.length > 0 && focal[0] > 0) {
                halfLong = Math.max(phys.getWidth(), phys.getHeight()) / (2.0 * focal[0]);
                halfShort = Math.min(phys.getWidth(), phys.getHeight()) / (2.0 * focal[0]);
            }
            fit();
            if (thread == null) {
                thread = new HandlerThread("nova-peakcam");
                thread.start();
                bg = new Handler(thread.getLooper());
            }
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    device = camera;
                    opening = false;
                    startPreview();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    device = null;
                    opening = false;
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    device = null;
                    fail("Camera error " + error);
                }
            }, bg);
        } catch (SecurityException e) {
            fail("No camera permission");
        } catch (Throwable t) {
            fail("Camera problem");
        }
    }

    private static Size choose(Size[] sizes) {
        Size best = null;
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            double ratio = s.getWidth() / (double) s.getHeight();
            if (area <= 1920L * 1440L && Math.abs(ratio - 4.0 / 3.0) < 0.03
                    && (best == null || area > (long) best.getWidth() * best.getHeight())) {
                best = s;
            }
        }
        if (best == null) {
            for (Size s : sizes) {
                long area = (long) s.getWidth() * s.getHeight();
                if (area <= 1920L * 1440L && (best == null || area > (long) best.getWidth() * best.getHeight())) {
                    best = s;
                }
            }
        }
        return best == null ? sizes[sizes.length - 1] : best;
    }

    /** Fills the whole view with the picture (cropping the edges) and keeps the real shape. */
    private void fit() {
        main.post(() -> {
            int hw = getWidth();
            int hh = getHeight();
            if (hw == 0 || hh == 0 || previewSize == null) {
                main.postDelayed(this::fit, 200);
                return;
            }
            boolean turned = sensorOrientation % 180 == 90;
            double ratio = turned ? previewSize.getHeight() / (double) previewSize.getWidth()
                    : previewSize.getWidth() / (double) previewSize.getHeight();
            int h = Math.max(hh, (int) Math.ceil(hw / ratio));
            int w = (int) Math.ceil(h * ratio);
            tv.setLayoutParams(new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
            // what part of the camera picture is really on screen
            overlay.tanV = halfLong * hh / h * calib;
            overlay.tanH = halfShort * hw / w * calib;
            if (!turned) {
                overlay.tanV = halfShort * hh / h * calib;
                overlay.tanH = halfLong * hw / w * calib;
            }
            overlay.base = new double[] {overlay.tanV / calib, overlay.tanH / calib};
            overlay.invalidate();
        });
    }

    private void startPreview() {
        try {
            SurfaceTexture st = tv.getSurfaceTexture();
            if (st == null || device == null) {
                return;
            }
            st.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            final Surface ps = new Surface(st);
            final CaptureRequest.Builder req = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            req.addTarget(ps);
            req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            device.createCaptureSession(Arrays.asList(ps), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession s) {
                    if (device == null) {
                        return;
                    }
                    session = s;
                    try {
                        s.setRepeatingRequest(req.build(), null, bg);
                    } catch (Throwable t) {
                        fail("Preview problem");
                    }
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession s) {
                    fail("Camera would not start");
                }
            }, bg);
        } catch (Throwable t) {
            fail("Camera problem");
        }
    }

    private void closeCamera() {
        try {
            if (session != null) {
                session.close();
            }
        } catch (Throwable ignored) {
            // closing
        }
        session = null;
        try {
            if (device != null) {
                device.close();
            }
        } catch (Throwable ignored) {
            // closing
        }
        device = null;
        opening = false;
    }

    // ------------------------------------------------------------------ the mountains drawn on top

    private final class Overlay extends View {
        private final float d = getResources().getDisplayMetrics().density;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ScaleGestureDetector pinch;
        private final List<PeakData.Peak> hit = new ArrayList<>();
        private final List<float[]> hitPos = new ArrayList<>();
        double tanV = halfLong;
        double tanH = halfShort;
        double[] base = {halfLong, halfShort};

        Overlay(Context c) {
            super(c);
            pinch = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector g) {
                    // spreading the fingers narrows the view (the labels move apart), like zooming the camera in
                    calib = Math.max(0.5f, Math.min(2f, calib / g.getScaleFactor()));
                    tanV = base[0] * calib;
                    tanH = base[1] * calib;
                    invalidate();
                    return true;
                }

                @Override
                public void onScaleEnd(ScaleGestureDetector g) {
                    Prefs.putString("pk_arcal", String.valueOf(calib));
                }
            });
        }

        /** x, y on screen for a compass direction and a height angle, or null when it is behind the camera. */
        private float[] project(double bearing, double el, int w, int h) {
            double b = Math.toRadians(bearing - decl);
            double e = Math.toRadians(el);
            double dE = Math.sin(b) * Math.cos(e);
            double dN = Math.cos(b) * Math.cos(e);
            double dU = Math.sin(e);
            double zc = dE * -rot[2] + dN * -rot[5] + dU * -rot[8];
            if (zc < 0.04) {
                return null;
            }
            double xc = dE * rot[0] + dN * rot[3] + dU * rot[6];
            double yc = dE * rot[1] + dN * rot[4] + dU * rot[7];
            return new float[] {(float) (w / 2.0 + xc / zc / tanH * w / 2.0), (float) (h / 2.0 - yc / zc / tanV * h / 2.0)};
        }

        @Override
        protected void onDraw(Canvas cv) {
            try {
                paint(cv);
            } catch (RuntimeException e) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(12 * d);
                cv.drawText("Could not draw: " + e.getClass().getSimpleName(), 12 * d, 40 * d, p);
            }
        }

        private void paint(Canvas cv) {
            int w = getWidth();
            int h = getHeight();
            hit.clear();
            hitPos.clear();
            p.setTextAlign(Paint.Align.CENTER);
            if (!haveRot) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(13 * d);
                cv.drawText(sm == null || sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) == null
                        ? "This phone has no rotation sensor, so 3D cannot work. Use STICKS."
                        : "waiting for the compass...", w / 2f, h / 2f, p);
                return;
            }
            // horizon line and compass marks
            Path hz = new Path();
            boolean pen = false;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * d);
            p.setColor(0x88FFFFFF);
            String[] n8 = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            float lastX = 0;
            for (int a = 0; a <= 360; a += 3) {
                float[] q = project(a, 0, w, h);
                if (q == null || (pen && Math.abs(q[0] - lastX) > w)) {
                    pen = false;
                    continue;
                }
                if (!pen) {
                    hz.moveTo(q[0], q[1]);
                    pen = true;
                } else {
                    hz.lineTo(q[0], q[1]);
                }
                lastX = q[0];
            }
            cv.drawPath(hz, p);
            p.setStyle(Paint.Style.FILL);
            for (int a = 0; a < 360; a += 15) {
                float[] q = project(a, 0, w, h);
                if (q == null || q[0] < -30 || q[0] > w + 30) {
                    continue;
                }
                boolean main = a % 45 == 0;
                p.setColor(a == 0 ? 0xFFFF6B6B : 0xDDFFFFFF);
                p.setTextSize((main ? 14 : 9) * d);
                cv.drawText(main ? n8[a / 45] : String.valueOf(a), q[0], q[1] + (main ? 22 : 16) * d, p);
                p.setStrokeWidth(d);
                p.setStyle(Paint.Style.STROKE);
                cv.drawLine(q[0], q[1] - 4 * d, q[0], q[1] + 4 * d, p);
                p.setStyle(Paint.Style.FILL);
            }

            // peaks
            List<PeakData.Peak> list;
            synchronized (PeakData.peaks) {
                list = new ArrayList<>(PeakData.peaks);
            }
            list.sort((a, b) -> Double.compare(b.up + b.ele / 2000.0, a.up + a.ele / 2000.0));
            List<RectF> used = new ArrayList<>();
            int named = 0;
            for (PeakData.Peak pk : list) {
                if (pk.dist > PeakData.km * 1000.0) {
                    continue;
                }
                float[] q = project(pk.bearing, pk.up, w, h);
                if (q == null || q[0] < -40 || q[0] > w + 40 || q[1] < -40 || q[1] > h + 40) {
                    continue;
                }
                boolean sel = pk == selected;
                float size = (pk.ele > 3500 ? 8 : 6) * d;
                Path tri = new Path();
                tri.moveTo(q[0], q[1] - size);
                tri.lineTo(q[0] - size, q[1] + size * 0.8f);
                tri.lineTo(q[0] + size, q[1] + size * 0.8f);
                tri.close();
                p.setStyle(Paint.Style.FILL);
                p.setColor(sel ? 0xFFFFFFFF : pk.hidden ? 0x889AA3BD : (Theme.ACCENT & 0xFFFFFF) | 0xEE000000);
                cv.drawPath(tri, p);
                hit.add(pk);
                hitPos.add(q);
                if (named >= 28 && !sel) {
                    continue;
                }
                String l1 = pk.name;
                String l2 = pk.ele + " m · " + pk.distText();
                p.setTextSize(11.5f * d);
                float tw = Math.max(p.measureText(l1), p.measureText(l2)) + 10 * d;
                RectF r = null;
                for (int step = 0; step < 4; step++) {
                    float yb = q[1] - size - 6 * d - step * 34 * d;
                    RectF t = new RectF(q[0] - tw / 2f, yb - 30 * d, q[0] + tw / 2f, yb);
                    boolean free = t.top > 2 * d;
                    for (RectF u : used) {
                        if (free && RectF.intersects(u, t)) {
                            free = false;
                        }
                    }
                    if (free) {
                        r = t;
                        break;
                    }
                }
                if (r == null) {
                    continue;
                }
                used.add(r);
                named++;
                p.setStrokeWidth(d);
                p.setColor(0x99FFFFFF);
                cv.drawLine(q[0], r.bottom, q[0], q[1] - size, p);
                p.setColor(pk.hidden && !sel ? 0x99000000 : 0xCC000000);
                cv.drawRoundRect(r, 7 * d, 7 * d, p);
                p.setTextAlign(Paint.Align.LEFT);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(11.5f * d);
                cv.drawText(l1, r.left + 5 * d, r.top + 13 * d, p);
                p.setColor(0xFFB9C2DC);
                p.setTextSize(9.5f * d);
                cv.drawText(l2, r.left + 5 * d, r.top + 25 * d, p);
                p.setTextAlign(Paint.Align.CENTER);
            }

            // centre mark and where the camera looks
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(0x88FFFFFF);
            cv.drawCircle(w / 2f, h / 2f, 10 * d, p);
            double fe = -rot[2];
            double fn = -rot[5];
            double fu = -rot[8];
            double head = (Math.toDegrees(Math.atan2(fe, fn)) + decl + 720.0) % 360.0;
            double pitch = Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, fu))));
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(12 * d);
            p.setColor(0xFFFFFFFF);
            cv.drawText(Math.round(head) % 360 + "° " + n8[(int) Math.round(head / 45.0) % 8] + "   tilt "
                    + (pitch >= 0 ? "+" : "") + Math.round(pitch) + "°", w / 2f, h - 30 * d, p);
            p.setTextSize(9.5f * d);
            p.setColor(0xAAFFFFFF);
            String note = !camNote.isEmpty() ? camNote : PeakData.peaks.isEmpty()
                    ? (PeakData.have ? "loading peaks..." : "finding your position...")
                    : "pinch if the names sit off the real peaks";
            cv.drawText(note, w / 2f, h - 14 * d, p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            pinch.onTouchEvent(e);
            if (!pinch.isInProgress() && e.getAction() == MotionEvent.ACTION_UP) {
                PeakData.Peak best = null;
                float bd = 34 * d;
                for (int i = 0; i < hit.size(); i++) {
                    float[] q = hitPos.get(i);
                    float dd = (float) Math.hypot(q[0] - e.getX(), q[1] - e.getY());
                    if (dd < bd) {
                        bd = dd;
                        best = hit.get(i);
                    }
                }
                selected = best;
                if (listener != null) {
                    listener.picked(best);
                }
                invalidate();
            }
            return true;
        }
    }
}
