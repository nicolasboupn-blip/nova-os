package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;
import java.util.function.IntConsumer;

/** All 88 keys of a piano, A0 to C8. Tap a key to choose that note. Drag sideways to scroll along the keyboard. */
final class PianoView extends View {
    interface Pick {
        void onPick(int note);
    }

    private final float keyW;
    private final float whiteH;
    private final float blackW;
    private final float blackH;
    private final int slop;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final int[] whiteNotes = new int[60];
    private int whiteCount;
    private int selected = 60;
    private Pick cb;
    private float downX;
    private float downY;

    PianoView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        keyW = 34 * d;
        whiteH = 130 * d;
        blackW = 21 * d;
        blackH = 80 * d;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        for (int n = DeckSound.NOTE_MIN; n <= DeckSound.NOTE_MAX; n++) {
            if (!DeckSound.isBlack(n)) {
                whiteNotes[whiteCount++] = n;
            }
        }
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(9 * d);
    }

    void setOnPick(Pick p) {
        cb = p;
    }

    void select(int note) {
        selected = note;
        invalidate();
    }

    private int whiteIndexBelow(int note) {
        int count = 0;
        for (int n = DeckSound.NOTE_MIN; n < note; n++) {
            if (!DeckSound.isBlack(n)) {
                count++;
            }
        }
        return count;
    }

    /** Where the middle of a key is, so the keyboard can be scrolled to it. */
    int centerX(int note) {
        if (DeckSound.isBlack(note)) {
            return (int) (whiteIndexBelow(note) * keyW);
        }
        return (int) (whiteIndexBelow(note) * keyW + keyW / 2f);
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) (whiteCount * keyW), (int) whiteH);
    }

    @Override
    protected void onDraw(Canvas c) {
        int accent = Theme.ACCENT;
        for (int i = 0; i < whiteCount; i++) {
            int n = whiteNotes[i];
            rect.set(i * keyW + 1, 0, (i + 1) * keyW - 1, whiteH);
            paint.setColor(n == selected ? accent : 0xFFEDEDED);
            c.drawRoundRect(rect, 5, 5, paint);
            if (n % 12 == 0 || n == DeckSound.NOTE_MIN || n == selected) {
                paint.setColor(n == selected ? Theme.BG : 0xFF555566);
                c.drawText(DeckSound.noteName(n), i * keyW + keyW / 2f, whiteH - 8, paint);
            }
        }
        for (int n = DeckSound.NOTE_MIN; n <= DeckSound.NOTE_MAX; n++) {
            if (DeckSound.isBlack(n)) {
                float x = whiteIndexBelow(n) * keyW;
                rect.set(x - blackW / 2f, 0, x + blackW / 2f, blackH);
                paint.setColor(n == selected ? accent : 0xFF1A1A22);
                c.drawRoundRect(rect, 4, 4, paint);
            }
        }
    }

    private int keyAt(float x, float y) {
        if (y < blackH) {
            for (int n = DeckSound.NOTE_MIN; n <= DeckSound.NOTE_MAX; n++) {
                if (DeckSound.isBlack(n) && Math.abs(x - whiteIndexBelow(n) * keyW) <= blackW / 2f) {
                    return n;
                }
            }
        }
        int i = (int) (x / keyW);
        return i >= 0 && i < whiteCount ? whiteNotes[i] : -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                return true;
            case MotionEvent.ACTION_UP:
                // a tap picks the key, a drag is left to the scrolling around this view
                if (Math.abs(e.getX() - downX) < slop && Math.abs(e.getY() - downY) < slop) {
                    int n = keyAt(e.getX(), e.getY());
                    if (n > 0) {
                        selected = n;
                        invalidate();
                        if (cb != null) {
                            cb.onPick(n);
                        }
                    }
                }
                return true;
            default:
                return true;
        }
    }
}

/** A colour chooser: sliders for colour, richness and brightness, a #RRGGBB box and a quick row of the usual colours. */
final class ColorPicker {
    private ColorPicker() {}

    static void show(final NovaActivity host, String title, int initial, final IntConsumer done) {
        final float[] hsv = new float[3];
        if ((initial & 0xFFFFFF) == 0) {
            hsv[0] = 200f;
            hsv[1] = 0.8f;
            hsv[2] = 1f;
        } else {
            Color.colorToHSV(initial | 0xFF000000, hsv);
        }
        final boolean[] busy = {false};
        final int pad = Theme.dp(host, 20);

        final View preview = new View(host);
        final EditText hex = new EditText(host);
        hex.setSingleLine(true);
        hex.setFilters(new InputFilter[] {new InputFilter.LengthFilter(7)});
        hex.setHint("#RRGGBB");
        final SeekBar[] bars = new SeekBar[3];
        final int[] max = {359, 100, 100};
        final String[] names = {"Colour", "Richness", "Brightness"};

        final Runnable refresh = () -> {
            int c = Color.HSVToColor(hsv) | 0xFF000000;
            preview.setBackground(Theme.rounded(c, 12f, host));
            if (!busy[0]) {
                busy[0] = true;
                hex.setText(String.format(Locale.ROOT, "#%06X", c & 0xFFFFFF));
                busy[0] = false;
            }
        };
        final Runnable syncBars = () -> {
            busy[0] = true;
            bars[0].setProgress(Math.round(hsv[0]) % 360);
            bars[1].setProgress(Math.round(hsv[1] * 100));
            bars[2].setProgress(Math.round(hsv[2] * 100));
            busy[0] = false;
        };

        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, Theme.dp(host, 8), pad, 0);
        box.addView(preview, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                Theme.dp(host, 56)));

        for (int i = 0; i < 3; i++) {
            final int k = i;
            TextView l = new TextView(host);
            l.setText(names[i]);
            l.setTextSize(12f);
            l.setPadding(0, Theme.dp(host, 10), 0, 0);
            box.addView(l);
            SeekBar b = new SeekBar(host);
            b.setMax(max[i]);
            if (i == 0) {
                // the colour slider shows the whole rainbow
                android.graphics.drawable.GradientDrawable rb = new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[] {0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF,
                            0xFFFF0000});
                rb.setCornerRadius(Theme.dp(host, 6));
                rb.setSize(1, Theme.dp(host, 10));
                b.setProgressDrawable(rb);
            }
            b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int p, boolean user) {
                    if (busy[0]) {
                        return;
                    }
                    hsv[k] = k == 0 ? p : p / 100f;
                    refresh.run();
                }

                @Override
                public void onStartTrackingTouch(SeekBar sb) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar sb) {
                }
            });
            bars[i] = b;
            box.addView(b);
        }

        hex.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                if (busy[0]) {
                    return;
                }
                String t = e.toString().trim();
                if (t.startsWith("#")) {
                    t = t.substring(1);
                }
                if (t.length() == 6) {
                    try {
                        Color.colorToHSV(0xFF000000 | Integer.parseInt(t, 16), hsv);
                        busy[0] = true;
                        syncBars.run();
                        busy[0] = false;
                        int c = Color.HSVToColor(hsv) | 0xFF000000;
                        preview.setBackground(Theme.rounded(c, 12f, host));
                    } catch (NumberFormatException ignored) {
                        // not a colour yet
                    }
                }
            }
        });
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = Theme.dp(host, 8);
        box.addView(hex, hlp);

        LinearLayout quick = new LinearLayout(host);
        int[] pal = {DeckBinds.GREEN, DeckBinds.RED, DeckBinds.AMBER, DeckBinds.BLUE, DeckBinds.PURPLE,
            DeckBinds.PINK, DeckBinds.CYAN, DeckBinds.WHITE};
        for (final int pc : pal) {
            View v = new View(host);
            v.setBackground(Theme.rounded(pc, 8f, host));
            v.setOnClickListener(x -> {
                Color.colorToHSV(pc, hsv);
                syncBars.run();
                refresh.run();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Theme.dp(host, 30), 1f);
            lp.setMargins(Theme.dp(host, 2), Theme.dp(host, 12), Theme.dp(host, 2), 0);
            quick.addView(v, lp);
        }
        box.addView(quick);

        syncBars.run();
        refresh.run();
        new AlertDialog.Builder(host).setTitle(title).setView(box)
                .setPositiveButton("SAVE", (d, w) -> done.accept(Color.HSVToColor(hsv) | 0xFF000000))
                .setNegativeButton("Cancel", null).show();
    }
}
