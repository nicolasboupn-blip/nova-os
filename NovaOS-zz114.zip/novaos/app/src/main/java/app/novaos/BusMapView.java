package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The map of the Zürich bus map: normal street map tiles with your routes on top.
 * A route you rode on 3 different days is a solid blue line; the parts where the bus is late go green, yellow, red.
 * Routes still being learned are dashed. A blue bus symbol marks where you get in, a small blue dot the stops you pass.
 */
final class BusMapView extends View {
    interface Pick {
        void picked(BusData.Route r, int idx);
    }

    private static final LruCache<String, Bitmap> CACHE = new LruCache<>(140);
    private static final Set<String> LOADING = new HashSet<>();
    private static ExecutorService pool;
    private static final double ZURICH_LAT = 47.3769;
    private static final double ZURICH_LON = 8.5417;

    private final float d;
    private final float scale;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tileP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DashPathEffect dash;
    private final GestureDetector gestures;
    private final ScaleGestureDetector pinch;
    private final List<Object[]> hits = new ArrayList<>();
    private double cx;
    private double cy;
    private double zf = 12;
    private boolean placed;
    private List<BusData.Stop> wantFit;

    boolean interactive = true;
    boolean dark = Prefs.getBool("pk_darkmap", false);
    BusData.Route focus;
    BusData.Route selRoute;
    int selIdx = -1;
    Pick listener;
    private double meLat;
    private double meLon;
    private boolean haveMe;

    BusMapView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        scale = Math.max(1f, d / 1.5f);
        dash = new DashPathEffect(new float[] {9 * d, 6 * d}, 0);
        textP.setTypeface(Theme.MONO);
        textP.setTextSize(10f * d);
        textP.setTextAlign(Paint.Align.CENTER);
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                cx += dx;
                cy += dy;
                invalidate();
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                tap(e.getX(), e.getY());
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                zoomBy(1, e.getX(), e.getY());
                return true;
            }
        });
        pinch = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector g) {
                zoomBy(Math.log(g.getScaleFactor()) / Math.log(2), g.getFocusX(), g.getFocusY());
                return true;
            }
        });
    }

    // ------------------------------------------------------------------ coordinates

    private double world(double zoom) {
        return 256.0 * scale * Math.pow(2, zoom);
    }

    private static double unitX(double lon) {
        return (lon + 180.0) / 360.0;
    }

    private static double unitY(double lat) {
        double r = Math.toRadians(lat);
        return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0;
    }

    private float sx(double lon) {
        return (float) (unitX(lon) * world(zf) - cx + getWidth() / 2.0);
    }

    private float sy(double lat) {
        return (float) (unitY(lat) * world(zf) - cy + getHeight() / 2.0);
    }

    void setMe(double lat, double lon) {
        meLat = lat;
        meLon = lon;
        haveMe = true;
        invalidate();
    }

    void centerOn(double lat, double lon, double zoom) {
        zf = Math.max(8, Math.min(19.5, zoom));
        cx = unitX(lon) * world(zf);
        cy = unitY(lat) * world(zf);
        placed = true;
        invalidate();
    }

    void zoomBy(double dz, float fx, float fy) {
        double nz = Math.max(8.0, Math.min(19.5, zf + dz));
        if (Math.abs(nz - zf) < 1e-6) {
            return;
        }
        double k = Math.pow(2, nz - zf);
        double ox = fx - getWidth() / 2.0;
        double oy = fy - getHeight() / 2.0;
        cx = (cx + ox) * k - ox;
        cy = (cy + oy) * k - oy;
        zf = nz;
        invalidate();
    }

    void zoomBy(double dz) {
        zoomBy(dz, getWidth() / 2f, getHeight() / 2f);
    }

    /** Shows every stop of every route. */
    void fitAll() {
        List<BusData.Stop> all = new ArrayList<>();
        for (BusData.Route r : BusData.routes()) {
            all.addAll(r.stops);
        }
        fit(all);
    }

    void fitRoute(BusData.Route r) {
        fit(new ArrayList<>(r.stops));
    }

    private void fit(List<BusData.Stop> stops) {
        wantFit = stops;
        if (getWidth() > 0 && getHeight() > 0) {
            doFit();
        }
    }

    private void doFit() {
        List<BusData.Stop> s = wantFit;
        wantFit = null;
        if (s == null) {
            return;
        }
        if (s.isEmpty()) {
            centerOn(ZURICH_LAT, ZURICH_LON, 12.5);
            return;
        }
        double minLat = 90;
        double maxLat = -90;
        double minLon = 180;
        double maxLon = -180;
        for (BusData.Stop st : s) {
            minLat = Math.min(minLat, st.lat);
            maxLat = Math.max(maxLat, st.lat);
            minLon = Math.min(minLon, st.lon);
            maxLon = Math.max(maxLon, st.lon);
        }
        double spanX = unitX(maxLon) - unitX(minLon);
        double spanY = unitY(minLat) - unitY(maxLat);
        double z = 17;
        for (double t = 18; t >= 8; t -= 0.25) {
            double w = world(t);
            if (spanX * w <= getWidth() * 0.78 && spanY * w <= getHeight() * 0.7) {
                z = t;
                break;
            }
            z = t;
        }
        centerOn((minLat + maxLat) / 2, (minLon + maxLon) / 2, Math.min(z, 17));
    }

    // ------------------------------------------------------------------ tiles

    private void tile(final int tz, final int tx, final int ty, Canvas cv, float left, float top, float size) {
        int max = 1 << tz;
        if (ty < 0 || ty >= max) {
            return;
        }
        final int txw = ((tx % max) + max) % max;
        final String key = tz + "/" + txw + "/" + ty;
        Bitmap b = CACHE.get(key);
        if (b != null) {
            cv.drawBitmap(b, null, new RectF(left, top, left + size, top + size), tileP);
            return;
        }
        if (tz > 5) {
            Bitmap parent = CACHE.get((tz - 1) + "/" + (txw / 2) + "/" + (ty / 2));
            if (parent != null) {
                int hx = (txw % 2) * 128;
                int hy = (ty % 2) * 128;
                cv.drawBitmap(parent, new android.graphics.Rect(hx, hy, hx + 128, hy + 128),
                        new RectF(left, top, left + size, top + size), tileP);
            }
        }
        synchronized (LOADING) {
            if (!LOADING.add(key)) {
                return;
            }
        }
        if (pool == null) {
            pool = Executors.newFixedThreadPool(4, r -> {
                Thread t = new Thread(r);
                t.setDaemon(true);
                return t;
            });
        }
        try {
            pool.execute(() -> {
                byte[] data = Http.bytes("https://tile.openstreetmap.org/" + key + ".png");
                Bitmap bm = data == null ? null : BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bm != null) {
                    CACHE.put(key, bm);
                }
                synchronized (LOADING) {
                    LOADING.remove(key);
                }
                postInvalidate();
            });
        } catch (RuntimeException e) {
            synchronized (LOADING) {
                LOADING.remove(key);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (wantFit != null) {
            doFit();
        } else if (!placed) {
            fitAll();
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth();
        int h = getHeight();
        cv.drawColor(dark ? 0xFF1B1B22 : 0xFFE8E4DC);
        if (dark) {
            ColorMatrix m = new ColorMatrix(new float[] {
                -1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0});
            tileP.setColorFilter(new ColorMatrixColorFilter(m));
        } else {
            tileP.setColorFilter(null);
        }
        int tz = (int) Math.max(1, Math.min(19, Math.floor(zf)));
        float size = (float) (256.0 * scale * Math.pow(2, zf - tz));
        double left = cx - w / 2.0;
        double top = cy - h / 2.0;
        int x0 = (int) Math.floor(left / size);
        int x1 = (int) Math.floor((left + w) / size);
        int y0 = (int) Math.floor(top / size);
        int y1 = (int) Math.floor((top + h) / size);
        for (int ty = y0; ty <= y1; ty++) {
            for (int tx = x0; tx <= x1; tx++) {
                tile(tz, tx, ty, cv, (float) (tx * size - left), (float) (ty * size - top), size);
            }
        }
        List<BusData.Route> routes = BusData.routes();
        hits.clear();
        // learning routes first so the finished ones sit on top
        for (int pass = 0; pass < 2; pass++) {
            for (BusData.Route r : routes) {
                if ((pass == 1) == r.confirmed()) {
                    lines(cv, r, w, h);
                }
            }
        }
        for (BusData.Route r : routes) {
            markers(cv, r, w, h);
        }
        if (haveMe) {
            float x = sx(meLon);
            float y = sy(meLat);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x55FFFFFF);
            cv.drawCircle(x, y, 14 * d, p);
            p.setColor(0xFFFFFFFF);
            cv.drawCircle(x, y, 7 * d, p);
            p.setColor(Theme.ACCENT);
            cv.drawCircle(x, y, 5 * d, p);
        }
    }

    private void lines(Canvas cv, BusData.Route r, int w, int h) {
        boolean big = focus == null || focus == r;
        boolean done = r.confirmed();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        int n = r.stops.size();
        for (int i = 0; i + 1 < n; i++) {
            BusData.Stop a = r.stops.get(i);
            BusData.Stop b = r.stops.get(i + 1);
            float x1 = sx(a.lon);
            float y1 = sy(a.lat);
            float x2 = sx(b.lon);
            float y2 = sy(b.lat);
            if ((x1 < -60 && x2 < -60) || (x1 > w + 60 && x2 > w + 60) || (y1 < -60 && y2 < -60)
                    || (y1 > h + 60 && y2 > h + 60)) {
                continue;
            }
            if (done) {
                p.setPathEffect(null);
                p.setColor(0xCCFFFFFF);
                p.setStrokeWidth((big ? 8 : 6) * d);
                cv.drawLine(x1, y1, x2, y2, p);
                p.setColor(BusData.delayColor(r.avg(i + 1)));
                p.setStrokeWidth((big ? 5 : 3.5f) * d);
                cv.drawLine(x1, y1, x2, y2, p);
            } else {
                p.setPathEffect(dash);
                p.setColor(0xCC3B82F6);
                p.setStrokeWidth(3 * d);
                cv.drawLine(x1, y1, x2, y2, p);
            }
        }
        p.setPathEffect(null);
    }

    private void markers(Canvas cv, BusData.Route r, int w, int h) {
        int n = r.stops.size();
        for (int i = 0; i < n; i++) {
            BusData.Stop s = r.stops.get(i);
            float x = sx(s.lon);
            float y = sy(s.lat);
            if (x < -40 || x > w + 40 || y < -40 || y > h + 40) {
                continue;
            }
            boolean board = r.boards(i);
            if (board) {
                bus(cv, x, y);
            } else if (zf >= 12.5) {
                dot(cv, x, y);
            } else {
                continue;
            }
            hits.add(new Object[] {r, i, x, y});
            if (r == selRoute && i == selIdx) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.5f * d);
                p.setColor(Theme.ACCENT);
                cv.drawCircle(x, y, 16 * d, p);
            }
            if ((board && zf >= 11) || zf >= 15 || (r == selRoute && i == selIdx)) {
                label(cv, s.shortName(), x, y + 25 * d);
            }
        }
    }

    private void label(Canvas cv, String s, float x, float y) {
        textP.setStyle(Paint.Style.STROKE);
        textP.setStrokeWidth(3 * d);
        textP.setColor(0xFF10101A);
        cv.drawText(s, x, y, textP);
        textP.setStyle(Paint.Style.FILL);
        textP.setColor(0xFFFFFFFF);
        cv.drawText(s, x, y, textP);
    }

    private void dot(Canvas cv, float x, float y) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(x, y, 5.5f * d, p);
        p.setColor(BusData.BLUE);
        cv.drawCircle(x, y, 3.8f * d, p);
    }

    /** The blue bus symbol: where you get in. */
    private void bus(Canvas cv, float x, float y) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(x, y, 13 * d, p);
        p.setColor(BusData.BLUE);
        cv.drawCircle(x, y, 11 * d, p);
        p.setColor(0xFFFFFFFF);
        cv.drawRoundRect(new RectF(x - 6 * d, y - 6 * d, x + 6 * d, y + 4 * d), 2 * d, 2 * d, p);
        p.setColor(BusData.BLUE);
        cv.drawRect(x - 4.5f * d, y - 4 * d, x + 4.5f * d, y - 0.5f * d, p);
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(x - 3.5f * d, y + 5 * d, 1.6f * d, p);
        cv.drawCircle(x + 3.5f * d, y + 5 * d, 1.6f * d, p);
    }

    // ------------------------------------------------------------------ touch

    private void tap(float x, float y) {
        BusData.Route best = null;
        int bi = -1;
        float bd = 28 * d;
        for (Object[] h : hits) {
            float dd = (float) Math.hypot((Float) h[2] - x, (Float) h[3] - y);
            if (dd < bd) {
                bd = dd;
                best = (BusData.Route) h[0];
                bi = (Integer) h[1];
            }
        }
        selRoute = best;
        selIdx = bi;
        if (listener != null) {
            listener.picked(best, bi);
        }
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!interactive) {
            return super.onTouchEvent(e);
        }
        if (e.getAction() == MotionEvent.ACTION_DOWN && getParent() != null) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        pinch.onTouchEvent(e);
        if (!pinch.isInProgress()) {
            gestures.onTouchEvent(e);
        }
        return true;
    }
}
