package app.novaos;

import android.app.AlertDialog;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * SONGS: the songs you played the most in the last 3 days, and your pinned songs. Tap a song to play it, tap the star
 * to pin or unpin it. Songs are learned from the music notification while "Remember what I listen to" is on.
 */
final class SongsWidget extends NovaWidget {
    private static final int DAYS = 3;
    private static final int MAX = 8;

    private final LinearLayout list;
    private final TextView tabTop;
    private final TextView tabPins;
    private final TextView add;
    private boolean pinsTab;

    SongsWidget(NovaActivity host) {
        super(host);
        setGravity(Gravity.CENTER_HORIZONTAL);
        pinsTab = Prefs.getBool("songs_pins_tab", false);
        addView(text("SONGS", 9f, Theme.DIM), wide());

        LinearLayout tabs = row();
        tabTop = chip("MOST PLAYED · " + DAYS + " DAYS", () -> {
            pinsTab = false;
            Prefs.putBool("songs_pins_tab", false);
            refresh();
        });
        tabPins = chip("PINNED", () -> {
            pinsTab = true;
            Prefs.putBool("songs_pins_tab", true);
            refresh();
        });
        add = chip("+", this::askPin);
        tabs.addView(tabTop, weight(2f));
        tabs.addView(tabPins, weight(1f));
        tabs.addView(add, weight(0.5f));
        addView(tabs, wide());

        list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        LinearLayout.LayoutParams lp = wide();
        lp.topMargin = dp(6);
        addView(list, lp);
    }

    @Override
    long tickMs() {
        return 20000;
    }

    @Override
    void tick() {
        if (!pinsTab) {
            refresh();
        }
    }

    @Override
    void refresh() {
        pick(tabTop, !pinsTab);
        pick(tabPins, pinsTab);
        add.setVisibility(pinsTab ? VISIBLE : GONE);
        list.removeAllViews();
        if (pinsTab) {
            List<SongLog.Song> pins = SongLog.pins();
            if (pins.isEmpty()) {
                list.addView(note("No pinned songs yet. Tap the star on a song in MOST PLAYED, or + to add one."));
            }
            for (SongLog.Song s : pins) {
                list.addView(rowFor(0, s, true));
            }
        } else {
            if (!SongLog.on()) {
                list.addView(note("Switch on Settings > PROFILE & SCENES > Remember what I listen to."));
                return;
            }
            List<SongLog.Song> top = SongLog.top(DAYS, MAX);
            if (top.isEmpty()) {
                list.addView(note(NovaNotificationService.hasAccess(host)
                        ? "Nothing yet. Play a song and it shows up here."
                        : "NOVA needs notification access to see what you play (Settings)."));
            }
            for (int i = 0; i < top.size(); i++) {
                list.addView(rowFor(i + 1, top.get(i), false));
            }
        }
    }

    private TextView note(String s) {
        TextView t = text(s, 10f, Theme.DIM);
        t.setPadding(dp(6), dp(8), dp(6), dp(8));
        return t;
    }

    private LinearLayout rowFor(int rank, final SongLog.Song s, final boolean pinned) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(6), dp(7), dp(6), dp(7));
        r.setClickable(true);
        Theme.ripple(r);
        r.setOnClickListener(v -> SongLog.play(host, s));

        if (rank > 0) {
            TextView n = text(String.valueOf(rank), 11f, rank <= 3 ? Theme.ACCENT : Theme.DIM);
            r.addView(n, new LinearLayout.LayoutParams(dp(22), LayoutParams.WRAP_CONTENT));
        }
        LinearLayout names = new LinearLayout(host);
        names.setOrientation(VERTICAL);
        TextView t = text(s.title, 12f, Theme.TEXT);
        t.setGravity(Gravity.START);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(t);
        if (!s.artist.isEmpty()) {
            TextView a = text(s.artist, 9f, Theme.DIM);
            a.setGravity(Gravity.START);
            a.setSingleLine(true);
            a.setEllipsize(TextUtils.TruncateAt.END);
            names.addView(a);
        }
        r.addView(names, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        if (!pinned) {
            TextView c = text("x" + s.plays, 10f, Theme.DIM);
            c.setPadding(dp(6), 0, dp(6), 0);
            r.addView(c);
        }
        final boolean isPin = pinned || SongLog.isPinned(s.title, s.artist);
        TextView star = text(isPin ? "★" : "☆", 17f, isPin ? Theme.ACCENT : Theme.DIM);
        star.setPadding(dp(8), dp(2), dp(4), dp(2));
        star.setClickable(true);
        star.setOnClickListener(v -> {
            if (SongLog.isPinned(s.title, s.artist)) {
                SongLog.unpin(s.title, s.artist);
            } else {
                SongLog.pin(s.title, s.artist, s.link == null ? "" : s.link);
            }
            refresh();
        });
        r.addView(star);
        return r;
    }

    private void askPin() {
        final EditText title = new EditText(host);
        title.setSingleLine(true);
        title.setHint("song name");
        final EditText artist = new EditText(host);
        artist.setSingleLine(true);
        artist.setHint("artist");
        final EditText link = new EditText(host);
        link.setSingleLine(true);
        link.setHint("Spotify link (optional, plays exactly this song)");
        link.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(title);
        box.addView(artist);
        box.addView(link);
        new AlertDialog.Builder(host).setTitle("Pin a song").setView(box)
                .setPositiveButton("PIN", (d, w) -> {
                    String t = title.getText().toString().trim();
                    if (t.isEmpty()) {
                        host.toast("Enter a song name");
                        return;
                    }
                    SongLog.pin(t, artist.getText().toString().trim(), link.getText().toString().trim());
                    refresh();
                }).setNegativeButton("Cancel", null).show();
    }
}
