package app.novaos;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The next buses of your routes on a sign that looks like the yellow dot-matrix ones at the Zürich stops. It shows the
 * stop where you get in and only the buses that go along your route. With more than one stop it flips between them
 * every 8 seconds (or tap the sign). Routes can be left off the sign in the BUS window. It always comes together with the
 * ZURICH BUS map widget, and can also be placed alone.
 */
final class BusBoardWidget extends NovaWidget {
    private final BusBoardView board;
    private final List<BusData.Stop> stops = new ArrayList<>();
    private final Map<String, List<BusData.Route>> byStop = new LinkedHashMap<>();
    private final Map<String, List<BusData.Dep>> data = new HashMap<>();
    private final Map<String, Long> asked = new HashMap<>();
    private volatile boolean busy;
    private String error = "";
    private int idx;
    private int sec;

    BusBoardWidget(NovaActivity host) {
        super(host);
        board = new BusBoardView(host);
        board.setOnClickListener(v -> {
            if (stops.size() > 1) {
                idx = (idx + 1) % stops.size();
                sec = 0;
            }
            fetch(true);
            show();
        });
        addView(board, new LayoutParams(-1, -2));
    }

    @Override
    long tickMs() {
        return 1000;
    }

    @Override
    void refresh() {
        collect();
        fetch(false);
        show();
    }

    @Override
    void tick() {
        sec++;
        if (stops.size() > 1 && sec % 8 == 0) {
            idx = (idx + 1) % stops.size();
            fetch(false);
        } else if (sec % 30 == 0) {
            fetch(false);
        }
        show();
    }

    private void collect() {
        stops.clear();
        byStop.clear();
        for (BusData.Route r : BusData.routes()) {
            if (!r.show) {
                continue;
            }
            for (BusData.Stop s : r.stops) {
                if (r.boardIds.contains(s.id)) {
                    List<BusData.Route> l = byStop.get(s.id);
                    if (l == null) {
                        l = new ArrayList<>();
                        byStop.put(s.id, l);
                        stops.add(s);
                    }
                    l.add(r);
                }
            }
        }
        if (idx >= stops.size()) {
            idx = 0;
        }
    }

    /** Asks the timetable for the stop on the sign, at most every 90 seconds per stop. */
    private void fetch(boolean force) {
        if (stops.isEmpty() || busy) {
            return;
        }
        final BusData.Stop s = stops.get(idx);
        Long last = asked.get(s.id);
        long now = System.currentTimeMillis();
        if (!force && last != null && now - last < 90000) {
            return;
        }
        if (force && last != null && now - last < 15000) {
            return;
        }
        asked.put(s.id, now);
        busy = true;
        final List<BusData.Route> routes = new ArrayList<>(byStop.get(s.id));
        new Thread(() -> {
            List<BusData.Dep> got = null;
            try {
                got = BusData.board(s, routes);
            } catch (RuntimeException ignored) {
                // a route changed while we looked
            }
            final List<BusData.Dep> res = got;
            busy = false;
            ui.post(() -> {
                if (res == null) {
                    error = BusData.lastError;
                } else {
                    error = "";
                    data.put(s.id, res);
                }
                show();
            });
        }).start();
    }

    private void show() {
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        if (stops.isEmpty()) {
            board.set("ZURICH BUS", time, null, "No bus chosen yet\nOpen BUS, then + ROUTE\nor switch on AUTO");
            return;
        }
        BusData.Stop s = stops.get(Math.min(idx, stops.size() - 1));
        String head = s.shortName() + (stops.size() > 1 ? "  " + (idx + 1) + "/" + stops.size() : "");
        List<BusData.Dep> l = data.get(s.id);
        if (l == null) {
            board.set(head, time, null, error.isEmpty() ? "loading..." : error);
            return;
        }
        List<BusData.Dep> live = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (BusData.Dep dep : l) {
            if (dep.at > now - 30000) {
                live.add(dep);
            }
        }
        board.set(head, time, live, live.isEmpty() ? "No bus soon on your\nroute" : "");
    }
}
