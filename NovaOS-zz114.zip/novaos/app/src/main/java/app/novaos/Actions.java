package app.novaos;

/** Things NOVA can do on request. Drawn shapes and voice commands both run these. */
final class Actions {
    private Actions() {
    }

    static final String PREFIX = "act:";
    static final String[] IDS = {"spin", "coin", "roulette", "poker", "music", "lock", "terminal", "settings",
        "phone", "camera", "gallery", "deck"};
    static final String[] LABELS = {
        "⚡ Spin the party wheel", "⚡ Flip a coin", "⚡ Open the roulette table", "⚡ Open poker",
        "⚡ Play / pause music", "⚡ Lock NOVA", "⚡ Open the terminal", "⚡ Open settings",
        "⚡ Open NOVA phone", "⚡ Open NOVA camera", "⚡ Open NOVA gallery", "⚡ Open the launch deck"
    };

    // IDS and LABELS must line up, so the order of the two arrays above is fixed
    static String label(String id) {
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(id)) {
                return LABELS[i];
            }
        }
        return id;
    }

    /** Runs an action by id. Returns false if the id is unknown. */
    static boolean run(NovaActivity host, String id) {
        switch (id) {
            case "spin":
                host.openGame(new GamePartyWheel(host, true));
                return true;
            case "coin":
                host.coinFlip(null);
                return true;
            case "roulette":
                host.openGame(new GameRoulette(host));
                return true;
            case "poker":
                host.openGame(new GamePoker(host));
                return true;
            case "music":
                MusicHelper.toggle(host);
                return true;
            case "lock":
                host.forceLock();
                return true;
            case "terminal":
                host.showTerminal();
                return true;
            case "settings":
                host.showSettings();
                return true;
            case "phone":
                host.openGame(new PhoneApp(host));
                return true;
            case "camera":
                host.openGame(new CameraApp(host));
                return true;
            case "gallery":
                host.openGame(new GalleryApp(host));
                return true;
            case "deck":
                host.showOverlay(new LaunchDeck(host));
                return true;
            default:
                return false;
        }
    }
}
