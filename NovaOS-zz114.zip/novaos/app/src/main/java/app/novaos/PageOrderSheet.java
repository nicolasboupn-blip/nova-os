package app.novaos;

import android.content.ClipData;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/**
 * Sets the order of the pages in the main box (the one with the arrows at the top of the home screen). Hold a page and
 * drag it, or use the arrows. Pages you switched off with CHOOSE PAGES are dimmed and still keep their place.
 */
final class PageOrderSheet extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout list;
    private final ScrollView sv;
    private final View line;
    private List<Integer> order = StatusPanel.loadOrderList();

    PageOrderSheet(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("PAGE ORDER", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("RESET", () -> {
            order = new java.util.ArrayList<>();
            for (int i = 0; i < StatusPanel.titles().length; i++) {
                order.add(i);
            }
            StatusPanel.saveOrder(order);
            rebuild();
        }));
        head.addView(chip("DONE", this::done));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));
        TextView hint = text("This is the order the arrows on the main box go through. Hold a page and drag it, or use "
                + "▲ ▼ and TOP. Dimmed pages are switched off (tap the page name on the home screen > CHOOSE PAGES).",
                9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        hint.setPadding(0, dp(6), 0, dp(8));
        col.addView(hint);

        sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        FrameLayout box = new FrameLayout(host);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, dp(30));
        box.addView(list, new FrameLayout.LayoutParams(-1, -2));
        line = new View(host);
        line.setBackgroundColor(Theme.ACCENT);
        line.setVisibility(GONE);
        box.addView(line, new FrameLayout.LayoutParams(-1, dp(3)));
        box.setOnDragListener((v, e) -> {
            switch (e.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return "pg".equals(String.valueOf(e.getClipDescription().getLabel()));
                case DragEvent.ACTION_DRAG_ENTERED:
                case DragEvent.ACTION_DRAG_LOCATION: {
                    int idx = insertAt(e.getY());
                    float ly = idx < list.getChildCount() ? list.getChildAt(idx).getTop() - dp(2)
                            : list.getChildCount() == 0 ? 0 : list.getChildAt(list.getChildCount() - 1).getBottom();
                    line.setTranslationY(ly);
                    line.setVisibility(VISIBLE);
                    float vy = e.getY() - sv.getScrollY();
                    if (vy < dp(40)) {
                        sv.scrollBy(0, -dp(12));
                    } else if (vy > sv.getHeight() - dp(40)) {
                        sv.scrollBy(0, dp(12));
                    }
                    return true;
                }
                case DragEvent.ACTION_DRAG_EXITED:
                    line.setVisibility(GONE);
                    return true;
                case DragEvent.ACTION_DROP: {
                    line.setVisibility(GONE);
                    int from;
                    try {
                        from = Integer.parseInt(String.valueOf(e.getClipData().getItemAt(0).getText()).trim());
                    } catch (RuntimeException ex) {
                        return true;
                    }
                    int idx = insertAt(e.getY());
                    move(from, idx > from ? idx - 1 : idx);
                    return true;
                }
                case DragEvent.ACTION_DRAG_ENDED:
                    line.setVisibility(GONE);
                    for (int i = 0; i < list.getChildCount(); i++) {
                        list.getChildAt(i).setAlpha(1f);
                    }
                    return true;
                default:
                    return true;
            }
        });
        sv.addView(box);
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        addView(col, new FrameLayout.LayoutParams(-1, -1));
        rebuild();
    }

    private int insertAt(float y) {
        int idx = 0;
        for (int i = 0; i < list.getChildCount(); i++) {
            View c = list.getChildAt(i);
            if (y > c.getTop() + c.getHeight() / 2f) {
                idx = i + 1;
            }
        }
        return idx;
    }

    private void move(int from, int to) {
        if (from < 0 || from >= order.size()) {
            return;
        }
        to = Math.max(0, Math.min(order.size() - 1, to));
        if (to == from) {
            return;
        }
        Integer v = order.remove(from);
        order.add(to, v);
        StatusPanel.saveOrder(order);
        rebuild();
    }

    private void rebuild() {
        list.removeAllViews();
        String[] titles = StatusPanel.titles();
        for (int pos = 0; pos < order.size(); pos++) {
            final int p = pos;
            int page = order.get(pos);
            boolean on = StatusPanel.pageShown(page);
            LinearLayout r = new LinearLayout(host);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(10), dp(8), dp(6), dp(8));
            r.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
            r.setAlpha(on ? 1f : 0.45f);
            TextView n = text(String.valueOf(pos + 1), 9f, Theme.DIM);
            r.addView(n, new LinearLayout.LayoutParams(dp(26), -2));
            TextView t = text(titles[page], 11f, Theme.TEXT);
            t.setGravity(Gravity.START);
            t.setSingleLine(true);
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(chip("TOP", () -> move(p, 0)));
            r.addView(chip("▲", () -> move(p, p - 1)));
            r.addView(chip("▼", () -> move(p, p + 1)));
            r.setOnLongClickListener(v -> {
                ClipData cd = ClipData.newPlainText("pg", String.valueOf(p));
                boolean ok = v.startDragAndDrop(cd, new View.DragShadowBuilder(v), null, 0);
                if (ok) {
                    v.setAlpha(0.3f);
                }
                return ok;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(5);
            list.addView(r, lp);
        }
    }

    private void done() {
        host.hideOverlay();
        host.showHome();
    }

    @Override
    public boolean onBack() {
        done();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }
}
