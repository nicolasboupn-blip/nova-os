package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Vehicle quiz page: a silhouette of one of 100 military vehicles, seen from the side. Four names, one right.
 * Right answer +200 coins, wrong answer -1000 coins. The silhouettes are simple shapes drawn in code.
 */
final class VehicleQuiz {
    static final int REWARD = 200;
    static final int PENALTY = 1000;

    /** name|shape|variant. Shapes: 0 tank, 1 tracked IFV, 2 wheeled APC, 3 truck, 4 jeep, 5 howitzer, 6 rocket launcher, 7 air defence. */
    static final String[] VEHICLES = {
        "M1 Abrams|0|2",
        "Leopard 2|0|1",
        "Leopard 1|0|0",
        "Challenger 2|0|3",
        "Challenger 1|0|0",
        "T-72|0|1",
        "T-90|0|2",
        "T-80|0|3",
        "T-64|0|0",
        "T-62|0|1",
        "T-55|0|2",
        "T-54|0|0",
        "T-34|0|1",
        "T-14 Armata|0|3",
        "Type 99|0|2",
        "Type 96|0|1",
        "Merkava Mk4|0|3",
        "Ariete|0|1",
        "K2 Black Panther|0|2",
        "Altay|0|0",
        "M60 Patton|0|1",
        "M48 Patton|0|0",
        "Tiger I|0|2",
        "Leclerc|0|3",
        "BMP-1|1|0",
        "BMP-2|1|1",
        "BMP-3|1|2",
        "Bradley M2|1|3",
        "Marder|1|1",
        "CV90|1|2",
        "Warrior|1|0",
        "ASCOD|1|3",
        "Spartan|1|1",
        "M113|1|0",
        "MT-LB|1|3",
        "PT-76|1|0",
        "BTR-80|2|1",
        "BTR-70|2|0",
        "BTR-60|2|2",
        "Stryker|2|3",
        "Piranha|2|1",
        "Patria AMV|2|0",
        "Fuchs|2|2",
        "Lynx|2|0",
        "Saxon|2|2",
        "Ratel|2|1",
        "Pandur II|2|1",
        "Ural-4320|3|0",
        "KamAZ-43101|3|1",
        "MAN SX|3|2",
        "Tatra 813|3|3",
        "Unimog U5000|3|0",
        "Oshkosh M1070|3|1",
        "M35 Deuce and a Half|3|2",
        "Renault TRM|3|0",
        "Mercedes Zetros|3|1",
        "Tatra Force|3|2",
        "Ural-375|3|0",
        "GAZ-66|3|1",
        "Willys MB|4|0",
        "Land Rover Defender|4|1",
        "Humvee M998|4|2",
        "Iltis|4|3",
        "Mercedes G-Class|4|0",
        "Polaris MRZR|4|1",
        "Jackal|4|2",
        "Panhard VBL|4|3",
        "Mowag Eagle|4|0",
        "GAZ Tigr|4|1",
        "UAZ-469|4|2",
        "Wolf|4|0",
        "Iveco LMV|4|2",
        "2S1 Gvozdika|5|0",
        "2S19 Msta|5|1",
        "PzH 2000|5|2",
        "M109|5|3",
        "K9 Thunder|5|0",
        "Caesar|5|1",
        "2S3 Akatsiya|5|2",
        "M777|5|3",
        "D-30|5|0",
        "FH70|5|1",
        "Type 99 SPH|5|3",
        "Archer|5|1",
        "BM-21 Grad|6|0",
        "BM-30 Smerch|6|1",
        "M270 MLRS|6|2",
        "HIMARS|6|3",
        "Type 90 MLRS|6|0",
        "PHL-03|6|1",
        "Tornado-S|6|2",
        "Lynx MLRS|6|3",
        "Gepard|7|0",
        "Tunguska|7|1",
        "Strela-10|7|2",
        "Roland|7|3",
        "Avenger|7|0",
        "Shilka|7|3",
        "Sa-8 Gecko|7|2",
        "Pantsir-S1|7|2"
    };

    private VehicleQuiz() {}

    static String name(int i) {
        return VEHICLES[i].split("\\|")[0];
    }

    static int shape(int i) {
        return Integer.parseInt(VEHICLES[i].split("\\|")[1]);
    }

    static int variant(int i) {
        return Integer.parseInt(VEHICLES[i].split("\\|")[2]);
    }

    /** Draws the silhouette in a 200 x 100 space, centred and scaled to fit the view. */
    static final class Silhouette extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private int idx = -1;

        Silhouette(Context c) {
            super(c);
            p.setColor(Theme.TEXT);
        }

        void show(int vehicle) {
            idx = vehicle;
            invalidate();
        }

        private void rr(Canvas c, float x, float y, float w, float h, float rad) {
            r.set(x, y, x + w, y + h);
            c.drawRoundRect(r, rad, rad, p);
        }

        private void wheel(Canvas c, float x, float y, float rad) {
            c.drawCircle(x, y, rad, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            if (idx < 0) {
                return;
            }
            float s = Math.min(getWidth() / 200f, getHeight() / 100f);
            c.save();
            c.translate((getWidth() - 200 * s) / 2f, (getHeight() - 100 * s) / 2f);
            c.scale(s, s);
            int v = variant(idx);
            switch (shape(idx)) {
                case 0: tank(c, v); break;
                case 1: ifv(c, v); break;
                case 2: apc(c, v); break;
                case 3: truck(c, v); break;
                case 4: jeep(c, v); break;
                case 5: howitzer(c, v); break;
                case 6: launcher(c, v); break;
                default: airDefence(c, v); break;
            }
            c.restore();
        }

        private void tank(Canvas c, int v) {
            rr(c, 10, 70, 180, 20, 10);
            rr(c, 18, 50, 164, 24, 4);
            rr(c, 70 - v, 30, 52 + 4 * v, 22 + v, 10);
            rr(c, 116, 38, 40 + 10 * v, 4, 1);
        }

        private void ifv(Canvas c, int v) {
            rr(c, 14, 70, 172, 18, 9);
            rr(c, 14, 50, 172, 22, 6);
            rr(c, 74, 36, 36, 16, 8);
            rr(c, 104, 41, 30 + 6 * v, 4, 1);
        }

        private void apc(Canvas c, int v) {
            rr(c, 16, 36, 168, 44, 8);
            if (v == 3) {
                rr(c, 90, 22, 34, 16, 6);
            }
            float[] xs = v % 2 == 0 ? new float[] {42, 150} : new float[] {38, 96, 154};
            for (float x : xs) {
                wheel(c, x, 80, 13);
            }
        }

        private void truck(Canvas c, int v) {
            rr(c, 20, 34, 104, 46, 3);
            rr(c, 128, 28, 52, 52, 8);
            rr(c, 136, 36, 20, 12, 3);
            float[] xs = v == 2 ? new float[] {42, 70, 150} : new float[] {42, 150};
            for (float x : xs) {
                wheel(c, x, 80, 12);
            }
        }

        private void jeep(Canvas c, int v) {
            rr(c, 40, 52, 120, 22, 6);
            rr(c, 62, 34, 64, 20, 6);
            if (v == 3) {
                wheel(c, 176, 62, 10);
            }
            wheel(c, 56, 78, 13);
            wheel(c, 144, 78, 13);
        }

        private void howitzer(Canvas c, int v) {
            if (v % 2 == 0) {
                rr(c, 26, 70, 150, 20, 10);
            } else {
                wheel(c, 60, 74, 14);
                wheel(c, 140, 74, 14);
            }
            rr(c, 38, 56, 110, 18, 4);
            rr(c, 118, 44, 28, 30, 4);
            rr(c, 120, 48, 80 + 5 * v, 5, 1);
            rr(c, 196, 45, 4, 11, 1);
        }

        private void launcher(Canvas c, int v) {
            rr(c, 20, 60, 130, 20, 3);
            rr(c, 26, 22, 116, 40, 2);
            rr(c, 150, 46, 30, 16, 4);
            if (v == 2) {
                rr(c, 22, 76, 150, 14, 7);
            } else {
                wheel(c, 44, 82, 12);
                wheel(c, 156, 82, 12);
            }
        }

        private void airDefence(Canvas c, int v) {
            rr(c, 20, 58, 160, 18, 5);
            rr(c, 74, 44, 44, 18, 6);
            rr(c, 116, 40, 46 + 4 * v, 3, 1);
            rr(c, 116, 48, 46 + 4 * v, 3, 1);
            if (v % 2 == 0) {
                rr(c, 84, 22, 20, 22, 3);
            }
        }
    }

    /** The quiz itself, one vehicle at a time. */
    static final class Page extends LinearLayout {
        private final NovaActivity host;
        private final Silhouette picture;
        private final TextView coins;
        private final TextView feedback;
        private final TextView[] options = new TextView[4];
        private final TextView next;
        private final Random rnd = new Random();
        private final List<String> order = new ArrayList<>();
        private int last = -1;
        private int correct;
        private boolean answered;

        Page(NovaActivity host) {
            super(host);
            this.host = host;
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER_HORIZONTAL);
            int pad = Theme.dp(host, 4);
            setPadding(pad, 0, pad, pad);

            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.addView(label("WHICH VEHICLE?", 11f, Theme.ACCENT), new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            coins = label("", 11f, Theme.DIM);
            top.addView(coins);
            addView(top, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

            picture = new Silhouette(host);
            addView(picture, new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 64)));

            for (int row = 0; row < 2; row++) {
                LinearLayout line = new LinearLayout(host);
                line.setGravity(Gravity.CENTER);
                for (int col = 0; col < 2; col++) {
                    final int i = row * 2 + col;
                    TextView b = label("", 11f, Theme.TEXT);
                    b.setSingleLine(true);
                    b.setEllipsize(TextUtils.TruncateAt.END);
                    b.setGravity(Gravity.CENTER);
                    b.setPadding(Theme.dp(host, 6), Theme.dp(host, 6), Theme.dp(host, 6), Theme.dp(host, 6));
                    b.setClickable(true);
                    b.setOnClickListener(v -> answer(i));
                    options[i] = b;
                    LayoutParams lp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
                    lp.setMargins(Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3), Theme.dp(host, 3));
                    line.addView(b, lp);
                }
                addView(line, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            }

            LinearLayout bottom = new LinearLayout(host);
            bottom.setGravity(Gravity.CENTER_VERTICAL);
            feedback = label("", 11f, Theme.TEXT);
            bottom.addView(feedback, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            next = label("NEXT", 12f, Theme.ACCENT);
            next.setPadding(Theme.dp(host, 10), Theme.dp(host, 4), Theme.dp(host, 4), Theme.dp(host, 4));
            next.setClickable(true);
            next.setOnClickListener(v -> ask());
            bottom.addView(next);
            addView(bottom, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

            ask();
        }

        private TextView label(String s, float sp, int color) {
            TextView t = new TextView(getContext());
            t.setText(s);
            t.setTypeface(Theme.MONO);
            t.setTextSize(sp);
            t.setTextColor(color);
            return t;
        }

        private void showCoins() {
            coins.setText("Coins " + Coins.get());
        }

        /** A new vehicle with four names, one of them right. */
        private void ask() {
            int i;
            do {
                i = rnd.nextInt(VEHICLES.length);
            } while (i == last);
            last = i;
            List<String> pool = new ArrayList<>();
            for (int k = 0; k < VEHICLES.length; k++) {
                if (k != i) {
                    pool.add(name(k));
                }
            }
            Collections.shuffle(pool, rnd);
            order.clear();
            order.add(name(i));
            order.addAll(pool.subList(0, 3));
            Collections.shuffle(order, rnd);
            correct = order.indexOf(name(i));
            answered = false;
            picture.show(i);
            for (int k = 0; k < 4; k++) {
                options[k].setText(order.get(k));
                options[k].setTextColor(Theme.TEXT);
                options[k].setBackground(Theme.rounded(0x26FFFFFF, 10f, host));
            }
            feedback.setText("Tap the right name");
            feedback.setTextColor(Theme.DIM);
            showCoins();
        }

        private void answer(int k) {
            if (answered) {
                return;
            }
            answered = true;
            int before = Coins.get();
            if (k == correct) {
                Coins.add(REWARD);
                feedback.setText("Correct! +" + REWARD + " coins");
                feedback.setTextColor(0xFF4DFF9A);
                options[k].setBackground(Theme.rounded(0x665DFF9A, 10f, host));
                Sfx.play(Sfx.WIN);
            } else {
                Coins.add(-PENALTY);
                int lost = before - Coins.get();
                feedback.setText("Wrong! It was " + order.get(correct) + ". -" + lost + " coins");
                feedback.setTextColor(0xFFFF6B7F);
                options[k].setBackground(Theme.rounded(0x66FF6B7F, 10f, host));
                options[correct].setBackground(Theme.rounded(0x665DFF9A, 10f, host));
                Sfx.play(Sfx.LOSE);
            }
            host.buzz(k == correct ? 25 : 60);
            showCoins();
        }
    }
}
