package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * PEAKFINDER on the home screen: the real map of your surroundings in the middle, the range and the highest peaks on the
 * left (km), and one big button on the right that opens the full Peakfinder with its MAP, 3D and STICKS views.
 */
final class PeakWidget extends NovaWidget {
    private final PeakTileMap map;
    private final TextView km;
    private final TextView count;
    private final TextView top;
    private boolean loading;
    private long lastTry;

    PeakWidget(NovaActivity host) {
        super(host);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER_VERTICAL);

        // left: the km side
        LinearLayout left = new LinearLayout(host);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER_HORIZONTAL);
        left.setPadding(0, 0, dp(6), 0);
        km = text(PeakData.km + " km", 20f, Theme.ACCENT);
        km.setGravity(Gravity.CENTER);
        left.addView(km, wide());
        left.addView(text("range", 9f, Theme.DIM), wide());
        LinearLayout steps = new LinearLayout(host);
        steps.setGravity(Gravity.CENTER);
        steps.addView(chip("−", () -> step(-1)), weight(1f));
        steps.addView(chip("+", () -> step(1)), weight(1f));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(6);
        left.addView(steps, sp);
        count = text("", 10f, Theme.TEXT);
        count.setGravity(Gravity.CENTER);
        count.setPadding(0, dp(10), 0, 0);
        left.addView(count, wide());
        top = text("", 9f, Theme.DIM);
        top.setGravity(Gravity.CENTER);
        top.setPadding(0, dp(4), 0, 0);
        left.addView(top, wide());
        row.addView(left, new LinearLayout.LayoutParams(dp(88), -2));

        // middle: the map
        map = new PeakTileMap(host);
        map.interactive = false;
        map.compact = true;
        map.dark = Prefs.getBool("pk_darkmap", false);
        map.setOnClickListener(v -> open());
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(200), 1f);
        row.addView(map, mp);

        // right: the button that opens everything
        TextView open = text("O\nP\nE\nN\n›", 13f, Theme.BG);
        open.setGravity(Gravity.CENTER);
        open.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
        open.setClickable(true);
        open.setOnClickListener(v -> open());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(40), dp(200));
        op.leftMargin = dp(6);
        row.addView(open, op);

        addView(row, wide());
    }

    private void open() {
        host.showOverlay(new PeakFinder(host, PeakFinder.MAP));
    }

    private void step(int dir) {
        int[] steps = {10, 20, 40, 60, 80};
        int idx = 0;
        for (int i = 0; i < steps.length; i++) {
            if (steps[i] == PeakData.km) {
                idx = i;
            }
        }
        PeakData.setKm(steps[Math.max(0, Math.min(steps.length - 1, idx + dir))]);
        km.setText(PeakData.km + " km");
        map.fitRange();
        lastTry = 0;
        loadOnline();
    }

    @Override
    long tickMs() {
        return 0;
    }

    @Override
    void refresh() {
        PeakData.restore();
        km.setText(PeakData.km + " km");
        if (!PeakData.have && !PeakData.useLastKnown(host.getApplicationContext())) {
            count.setText("");
            top.setText("Tap OPEN once and allow location");
            return;
        }
        map.fitRange();
        PeakData.loadCached(host.getApplicationContext(), (peaks, err) -> {
            if (peaks == null) {
                loadOnline();
                return;
            }
            show(peaks);
        });
    }

    private void loadOnline() {
        long now = System.currentTimeMillis();
        if (loading || !PeakData.have || now - lastTry < 30000) {
            return;
        }
        loading = true;
        lastTry = now;
        top.setText("loading...");
        PeakData.load(host.getApplicationContext(), PeakData.myLat, PeakData.myLon, PeakData.km, (peaks, err) -> {
            loading = false;
            if (peaks == null) {
                top.setText(err == null ? "No peaks found" : err);
                return;
            }
            show(peaks);
        });
    }

    private void show(List<PeakData.Peak> peaks) {
        map.invalidate();
        int inRange = 0;
        PeakData.Peak best = null;
        for (PeakData.Peak p : new ArrayList<>(peaks)) {
            if (p.dist <= PeakData.km * 1000.0) {
                inRange++;
                if (best == null || p.ele > best.ele) {
                    best = p;
                }
            }
        }
        count.setText(inRange + " peaks");
        top.setText(best == null ? "" : "highest\n" + best.name + "\n" + best.ele + " m\n" + best.distText() + " "
                + best.compass());
    }
}
