package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Texas Hold'em against the dealer. Two cards each. The flop, turn and river come out one card at a time. At each step
 * you KEEP GOING (put in another bet) or FOLD. Folding reveals the rest of the board and you lose what you put in.
 * At the end the best five of your seven cards are compared with the dealer's. Win pays back twice what you put in,
 * a tie gives it back, a loss keeps it.
 */
final class GamePoker extends Game {
    static final String HELP =
            "TEXAS HOLD'EM VS THE DEALER\n\n"
            + "1. Pick a bet and press DEAL. You get two cards. The dealer gets two cards you cannot see.\n\n"
            + "2. PRE-FLOP: KEEP GOING puts in the same bet again. FOLD gives up.\n\n"
            + "3. The FLOP comes out: three cards in the middle, one at a time. Then choose again.\n\n"
            + "4. The TURN (one more card) and the RIVER (the last card) come out the same way. Each time you choose.\n\n"
            + "5. If you keep going to the end, both sides make their best five cards out of their two plus the five in the middle.\n\n"
            + "6. Win: you get back twice what you put in. Tie: you get it back. Lose or fold: you lose what you put in.\n\n"
            + "Hand order, best first: straight flush, four of a kind, full house, flush, straight, three of a kind, two pair, pair, high card.";

    private static final int[] CHIPS = {5, 10, 25, 50, 100, 1000, 10000, 100000, 1000000};
    private static final String[] SUITS = {"♠", "♥", "♦", "♣"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    private static final String[] HANDS = {"HIGH CARD", "PAIR", "TWO PAIR", "THREE OF A KIND", "STRAIGHT", "FLUSH",
        "FULL HOUSE", "FOUR OF A KIND", "STRAIGHT FLUSH"};
    private static final String[] STREET = {"PRE-FLOP", "FLOP", "TURN", "RIVER"};
    /** How many board cards are out at each street: pre-flop 0, flop 3, turn 4, river 5. */
    private static final int[] REVEAL_AT = {0, 3, 4, 5};
    private static final int IDLE = 0, DECIDE = 1, BUSY = 2;
    private static final int SCALE = 10000000;

    private final Random rnd = new Random();
    private final int[] player = new int[2];
    private final int[] dealer = new int[2];
    private final int[] board = new int[5];
    private final LinearLayout dealerRow;
    private final LinearLayout boardRow;
    private final LinearLayout playerRow;
    private final TextView dealerLabel;
    private final TextView boardLabel;
    private final TextView playerLabel;
    private final TextView message;
    private final TextView coinsText;
    private final TextView betText;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView dealBtn;
    private final TextView keepBtn;
    private final TextView foldBtn;
    private final TextView helpBtn;
    private final ScrollView helpPanel;
    private int chip = 1;
    private int stake;
    private int invested;
    private int stage;
    private int revealed;
    private int revealTarget;
    private boolean showDealer;
    private int phase = IDLE;
    private Runnable afterReveal;

    GamePoker(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(56), dp(16), dp(20));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        coinsText = label("", 13f, Theme.TEXT);
        betText = label("", 13f, Theme.ACCENT);
        LinearLayout top = new LinearLayout(host);
        coinsText.setGravity(Gravity.START);
        betText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(betText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dealerLabel = label("DEALER", 12f, Theme.DIM);
        col.addView(dealerLabel, wrapTop(dp(14)));
        dealerRow = handRow();
        col.addView(dealerRow);

        boardLabel = label("BOARD", 12f, Theme.DIM);
        col.addView(boardLabel, wrapTop(dp(14)));
        boardRow = handRow();
        col.addView(boardRow);

        message = label("PICK A BET AND DEAL", 13f, Theme.DIM);
        message.setLetterSpacing(0.06f);
        col.addView(message, wrapTop(dp(12)));

        playerRow = handRow();
        col.addView(playerRow);
        playerLabel = label("YOU", 12f, Theme.DIM);
        col.addView(playerLabel);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(Upgrades.chipName(CHIPS[i]), 9f, Theme.TEXT);
            c.setSingleLine(true);
            c.setPadding(0, 0, 0, 0);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (phase == IDLE) {
                    chip = idx;
                    styleChips();
                    refresh();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            cp.setMargins(dp(1), 0, dp(1), 0);
            chips.addView(c, cp);
        }
        col.addView(chips, wrapTop(dp(16)));

        LinearLayout actions = new LinearLayout(host);
        actions.setGravity(Gravity.CENTER);
        dealBtn = actionButton("DEAL", Theme.ACCENT, this::deal);
        keepBtn = actionButton("KEEP GOING", Theme.ACCENT, this::keepGoing);
        foldBtn = actionButton("FOLD", Theme.PANEL, this::fold);
        for (TextView b : new TextView[] {dealBtn, keepBtn, foldBtn}) {
            b.setSingleLine(true);
            b.setPadding(dp(4), dp(12), dp(4), dp(12));
        }
        actions.addView(dealBtn, actionParams());
        actions.addView(keepBtn, actionParams());
        actions.addView(foldBtn, actionParams());
        col.addView(actions, wrapTop(dp(14)));

        helpBtn = actionButton("HOW TO PLAY", Theme.PANEL, this::toggleHelp);
        LinearLayout.LayoutParams hbp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hbp.topMargin = dp(12);
        col.addView(helpBtn, hbp);

        helpPanel = new ScrollView(host);
        helpPanel.setBackground(Theme.rounded(0xFF1A1230, 14f, host));
        helpPanel.setPadding(dp(14), dp(12), dp(14), dp(12));
        TextView helpText = label(HELP, 11f, Theme.TEXT);
        helpText.setGravity(Gravity.START);
        helpText.setLineSpacing(dp(3), 1f);
        helpPanel.addView(helpText);
        helpPanel.setVisibility(GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(240));
        hp.topMargin = dp(10);
        col.addView(helpPanel, hp);

        styleChips();
        showCards();
        refresh();
    }

    @Override
    String title() {
        return "TEXAS HOLD'EM";
    }

    private void toggleHelp() {
        boolean open = helpPanel.getVisibility() != VISIBLE;
        helpPanel.setVisibility(open ? VISIBLE : GONE);
        helpBtn.setText(open ? "CLOSE HELP" : "HOW TO PLAY");
    }

    private LinearLayout.LayoutParams wrapTop(int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = top;
        return lp;
    }

    private LinearLayout.LayoutParams actionParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private TextView actionButton(String text, int color, Runnable action) {
        TextView b = button(text, action);
        b.setTextColor(color == Theme.ACCENT ? Theme.BG : Theme.TEXT);
        b.setBackground(Theme.rounded(color, 16f, host));
        return b;
    }

    private LinearLayout handRow() {
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.setMinimumHeight(dp(74));
        return row;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private void refresh() {
        coinsText.setText("COINS " + coins());
        betText.setText(phase == IDLE ? "BET " + Upgrades.chipName(CHIPS[chip]) : "IN " + Upgrades.chipName(invested));
        dealBtn.setVisibility(phase == IDLE ? VISIBLE : GONE);
        keepBtn.setVisibility(phase == DECIDE ? VISIBLE : GONE);
        foldBtn.setVisibility(phase == DECIDE ? VISIBLE : GONE);
        keepBtn.setText("KEEP +" + Upgrades.chipName(stake));
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(on ? Theme.ACCENT : 0x33FFFFFF);
            chipViews[i].setBackground(g);
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    // ------------------------------------------------------------------ cards

    /** A card code is rank * 4 + suit, rank 0 = two ... 12 = ace. */
    private TextView card(int code) {
        int rank = code / 4;
        int suit = code % 4;
        TextView t = label(RANKS[rank] + SUITS[suit], 14f, 0);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFFF4F0FF, 8f, host));
        t.setTextColor(suit % 2 == 0 ? 0xFF1C1626 : 0xFFB3243A);
        t.setPadding(dp(4), dp(10), dp(4), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(50), dp(66));
        lp.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView cardBack() {
        TextView t = label("?", 16f, Theme.ACCENT);
        t.setTypeface(Theme.MONO);
        t.setBackground(Theme.rounded(0xFF3B2B66, 8f, host));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(50), dp(66));
        lp.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(lp);
        return t;
    }

    /** Draws every row from the current state: your two cards, the dealer's (hidden until the end), and the board. */
    private void showCards() {
        playerRow.removeAllViews();
        dealerRow.removeAllViews();
        boardRow.removeAllViews();
        boolean any = phase != IDLE;
        for (int i = 0; i < 2; i++) {
            playerRow.addView(any ? card(player[i]) : cardBack());
            dealerRow.addView(any && showDealer ? card(dealer[i]) : cardBack());
        }
        for (int i = 0; i < 5; i++) {
            boardRow.addView(any && i < revealed ? card(board[i]) : cardBack());
        }
        int known = 2 + (any ? revealed : 0);
        int[] mine = new int[known];
        mine[0] = player[0];
        mine[1] = player[1];
        for (int i = 0; i < known - 2; i++) {
            mine[2 + i] = board[i];
        }
        playerLabel.setText(any && known >= 5 ? "YOU  ·  " + HANDS[best(mine) / SCALE] : "YOU");
        if (any && showDealer) {
            dealerLabel.setText("DEALER  ·  " + HANDS[best(concat(dealer, board)) / SCALE]);
        } else {
            dealerLabel.setText("DEALER");
        }
    }

    // ------------------------------------------------------------------ rules

    private static int[] concat(int[] a, int[] b) {
        int[] out = new int[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    /** The best five-card hand out of the cards given (5 to 7). Higher is better. */
    static int best(int[] cards) {
        int n = cards.length;
        int bestScore = -1;
        for (int mask = 0; mask < (1 << n); mask++) {
            if (Integer.bitCount(mask) != 5) {
                continue;
            }
            int[] five = new int[5];
            int k = 0;
            for (int i = 0; i < n; i++) {
                if ((mask & (1 << i)) != 0) {
                    five[k++] = cards[i];
                }
            }
            bestScore = Math.max(bestScore, score5(five));
        }
        return bestScore;
    }

    /** Score of exactly five cards: hand rank times ten million, then a tie breaker read as base 15 digits. */
    static int score5(int[] cards) {
        int[] r = new int[5];
        boolean flush = true;
        int[] count = new int[15];
        for (int i = 0; i < 5; i++) {
            r[i] = cards[i] / 4 + 2;
            count[r[i]]++;
            if (cards[i] % 4 != cards[0] % 4) {
                flush = false;
            }
        }
        List<int[]> groups = new ArrayList<>();
        for (int v = 14; v >= 2; v--) {
            if (count[v] > 0) {
                groups.add(new int[] {count[v], v});
            }
        }
        groups.sort((a, b) -> a[0] != b[0] ? b[0] - a[0] : b[1] - a[1]);
        int c0 = groups.get(0)[0];
        int c1 = groups.size() > 1 ? groups.get(1)[0] : 0;
        boolean distinct = groups.size() == 5;
        int top = 0;
        int bottom = 15;
        for (int v : r) {
            top = Math.max(top, v);
            bottom = Math.min(bottom, v);
        }
        boolean wheel = distinct && count[14] == 1 && count[5] == 1 && count[4] == 1 && count[3] == 1 && count[2] == 1;
        boolean straight = distinct && (top - bottom == 4 || wheel);
        int high = wheel ? 5 : top;
        int rank;
        if (straight && flush) {
            rank = 8;
        } else if (c0 == 4) {
            rank = 7;
        } else if (c0 == 3 && c1 == 2) {
            rank = 6;
        } else if (flush) {
            rank = 5;
        } else if (straight) {
            rank = 4;
        } else if (c0 == 3) {
            rank = 3;
        } else if (c0 == 2 && c1 == 2) {
            rank = 2;
        } else if (c0 == 2) {
            rank = 1;
        } else {
            rank = 0;
        }
        int tie = 0;
        if (rank == 8 || rank == 4) {
            tie = high;
        } else {
            for (int[] g : groups) {
                tie = tie * 15 + g[1];
            }
        }
        return rank * SCALE + tie;
    }

    // ------------------------------------------------------------------ flow

    private void deal() {
        if (phase != IDLE) {
            return;
        }
        int s = CHIPS[chip];
        if (coins() < s) {
            message.setText("NOT ENOUGH COINS");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - s);
        stake = s;
        Sfx.play(Sfx.CARD);
        invested = s;
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < 52; i++) {
            deck.add(i);
        }
        Collections.shuffle(deck, rnd);
        player[0] = deck.get(0);
        player[1] = deck.get(1);
        dealer[0] = deck.get(2);
        dealer[1] = deck.get(3);
        for (int i = 0; i < 5; i++) {
            board[i] = deck.get(4 + i);
        }
        stage = 0;
        revealed = 0;
        showDealer = false;
        phase = DECIDE;
        message.setText("PRE-FLOP. KEEP GOING OR FOLD.");
        message.setTextColor(Theme.DIM);
        showCards();
        refresh();
    }

    private void keepGoing() {
        if (phase != DECIDE) {
            return;
        }
        if (coins() < stake) {
            message.setText("NOT ENOUGH COINS TO KEEP GOING. FOLD INSTEAD.");
            message.setTextColor(0xFFFF6B7F);
            return;
        }
        Prefs.putInt("slot_coins", coins() - stake);
        invested += stake;
        if (stage == 3) {
            showdown();
            return;
        }
        stage++;
        startReveal(REVEAL_AT[stage], () -> {
            phase = DECIDE;
            message.setText(STREET[stage] + " IS OUT. KEEP GOING OR FOLD.");
            message.setTextColor(Theme.DIM);
            refresh();
        });
    }

    private void fold() {
        if (phase != DECIDE) {
            return;
        }
        startReveal(5, () -> endHand(false));
    }

    private void showdown() {
        showDealer = true;
        endHand(true);
    }

    /** Cards come out one at a time, with a short pause between them, then the callback runs. */
    private void startReveal(int target, Runnable after) {
        phase = BUSY;
        revealTarget = target;
        afterReveal = after;
        message.setText("DEALING...");
        message.setTextColor(Theme.DIM);
        revealStep();
    }

    private void revealStep() {
        if (revealed < revealTarget) {
            revealed++;
            Sfx.play(Sfx.CARD);
            showCards();
            host.buzz(8);
            h.postDelayed(this::revealStep, 700);
        } else {
            afterReveal.run();
        }
    }

    private void endHand(boolean showdownMode) {
        phase = BUSY;
        revealed = 5;
        if (!showdownMode) {
            // folded: the rest of the board is out, the dealer's cards are shown, and the bet is gone
            showDealer = true;
            showCards();
            Sfx.play(Sfx.LOSE);
            message.setText("FOLDED  -" + Upgrades.chipName(invested));
            message.setTextColor(0xFFFF6B7F);
            host.buzz(30);
            phase = IDLE;
            invested = 0;
            refresh();
            return;
        }
        int ps = best(concat(player, board));
        int ds = best(concat(dealer, board));
        int back;
        String result;
        if (ps > ds) {
            back = 2 * invested;
            result = "YOU WIN WITH " + HANDS[ps / SCALE];
        } else if (ps == ds) {
            back = invested;
            result = "PUSH";
        } else {
            back = 0;
            result = "DEALER WINS WITH " + HANDS[ds / SCALE];
        }
        Prefs.putInt("slot_coins", coins() + back);
        int net = back - invested;
        Sfx.play(net > 0 ? Sfx.WIN : net == 0 ? Sfx.CLICK : Sfx.LOSE);
        showCards();
        if (net > 0) {
            message.setText(result + "  +" + net);
            message.setTextColor(Theme.ACCENT);
            host.buzz(50);
            host.confetti(getWidth() / 2f, getHeight() * 0.45f);
        } else if (net == 0) {
            message.setText(result + "  PUSH");
            message.setTextColor(Theme.TEXT);
        } else {
            message.setText(result + "  " + net);
            message.setTextColor(0xFFFF6B7F);
            host.buzz(30);
        }
        if (ps / SCALE >= 3) {
            Badges.unlock(host, "dice");
        }
        phase = IDLE;
        invested = 0;
        refresh();
    }
}
