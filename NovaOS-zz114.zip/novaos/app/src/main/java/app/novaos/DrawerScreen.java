package app.novaos;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * All installed apps with search. Tap to open, long-press for pin / info / uninstall. Six looks (Settings > UI STYLE or the
 * look picker): GRID, LIST, LETTERS (a list with an A to Z rail), CARDS, DENSE (many small icons) and WIDE (two big tiles).
 */
final class DrawerScreen extends LinearLayout {
    private static final class Holder {
        ImageView icon;
        TextView label;
    }

    static final String K_DRAWER = "ui_drawer";
    static final String[] NAMES = {"Grid", "List", "Letters", "Cards", "Dense", "Wide"};

    static int mode() {
        return Math.max(0, Math.min(NAMES.length - 1, Prefs.getInt(K_DRAWER, 0)));
    }

    private final int mode = mode();
    private final NovaActivity host;
    private final List<AppEntry> shown = new ArrayList<>();
    private final BaseAdapter adapter;

    DrawerScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 16);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 8));

        host.repo.ensureFresh();
        shown.addAll(host.repo.all);

        TextView title = new TextView(host);
        title.setText("APPS · " + host.repo.all.size());
        title.setTypeface(Theme.MONO);
        title.setTextSize(12f);
        title.setLetterSpacing(0.3f);
        title.setTextColor(Theme.ACCENT);
        title.setPadding(Theme.dp(host, 8), 0, 0, 0);
        addView(title);

        final EditText search = new EditText(host);
        search.setHint("search apps");
        search.setHintTextColor(Theme.DIM);
        search.setTextColor(Theme.TEXT);
        search.setTextSize(15f);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setImeOptions(EditorInfo.IME_ACTION_GO);
        search.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
        search.setPadding(Theme.dp(host, 16), Theme.dp(host, 12), Theme.dp(host, 16), Theme.dp(host, 12));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Theme.dp(host, 12);
        addView(search, slp);

        final GridView grid = new GridView(host);
        final int cols = mode == 1 || mode == 2 ? 1 : mode == 3 ? 3 : mode == 4 ? 6 : mode == 5 ? 2 : Upgrades.gridCols();
        grid.setNumColumns(cols);
        grid.setVerticalScrollBarEnabled(false);
        grid.setVerticalSpacing(Theme.dp(host, 8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setClipChildren(false);
        grid.setPadding(0, 0, 0, Theme.dp(host, 24));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        glp.topMargin = Theme.dp(host, 12);
        if (mode == 2) {
            // an A to Z rail on the right: drag along it to jump
            LinearLayout both = new LinearLayout(host);
            both.addView(grid, new LinearLayout.LayoutParams(0, -1, 1f));
            final String letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            LinearLayout rail = new LinearLayout(host);
            rail.setOrientation(VERTICAL);
            rail.setPadding(Theme.dp(host, 2), Theme.dp(host, 6), 0, Theme.dp(host, 6));
            for (int i = 0; i < letters.length(); i++) {
                TextView l = new TextView(host);
                l.setText(String.valueOf(letters.charAt(i)));
                l.setTypeface(Theme.MONO);
                l.setTextSize(9f);
                l.setTextColor(Theme.DIM);
                l.setGravity(Gravity.CENTER);
                rail.addView(l, new LinearLayout.LayoutParams(Theme.dp(host, 20), 0, 1f));
            }
            rail.setOnTouchListener((v, ev) -> {
                float f = Math.max(0f, Math.min(0.999f, ev.getY() / Math.max(1f, v.getHeight())));
                char c = letters.charAt((int) (f * letters.length()));
                for (int k = 0; k < shown.size(); k++) {
                    String lb = shown.get(k).label;
                    char ch = lb.isEmpty() ? '#' : Character.toUpperCase(lb.charAt(0));
                    if (!Character.isLetter(ch)) {
                        ch = '#';
                    }
                    if (c == '#' ? ch == '#' : ch >= c && Character.isLetter(ch)) {
                        grid.setSelection(k);
                        break;
                    }
                }
                return true;
            });
            both.addView(rail, new LinearLayout.LayoutParams(-2, -1));
            addView(both, glp);
            java.util.Collections.sort(shown, (a, b) -> a.label.compareToIgnoreCase(b.label));
        } else {
            addView(grid, glp);
        }

        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int i) {
                return shown.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                Holder h;
                View v = convert;
                if (v == null) {
                    LinearLayout c = new LinearLayout(host);
                    boolean row = mode == 1 || mode == 2;
                    c.setOrientation(row ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
                    c.setGravity(row ? Gravity.CENTER_VERTICAL : Gravity.CENTER_HORIZONTAL);
                    c.setClipChildren(false);
                    c.setPadding(Theme.dp(host, row ? 6 : 2), Theme.dp(host, row ? 6 : 8), Theme.dp(host, row ? 6 : 2),
                            Theme.dp(host, row ? 6 : 8));
                    if (mode == 3 || mode == 5) {
                        c.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
                        c.setPadding(Theme.dp(host, 4), Theme.dp(host, 14), Theme.dp(host, 4), Theme.dp(host, 12));
                    }
                    h = new Holder();
                    h.icon = Prefs.holo() && !Saver.on() ? new HoloIcon(host) : new ImageView(host);
                    final ImageView touched = h.icon;
                    // a touch makes the icon's particles burst outward
                    c.setOnTouchListener((tv, ev) -> {
                        if (ev.getActionMasked() == android.view.MotionEvent.ACTION_DOWN && Prefs.touchGlow()) {
                            android.graphics.drawable.Drawable d = touched.getDrawable();
                            if (d instanceof ParticleGlow) {
                                ((ParticleGlow) d).burst();
                            }
                        }
                        return false;
                    });
                    Upgrades.shapeIcon(h.icon);
                    int dsz = mode == 4 ? 38 : mode == 5 ? 64 : mode == 3 ? 56 : mode == 1 || mode == 2 ? 40
                            : Upgrades.gridCols() >= 5 ? 44 : 52;
                    c.addView(h.icon, new LinearLayout.LayoutParams(Theme.dp(host, dsz), Theme.dp(host, dsz)));
                    h.label = new TextView(host);
                    h.label.setTextSize(row ? 17f : mode == 4 ? 9f : 11f);
                    h.label.setTextColor(Theme.TEXT);
                    h.label.setSingleLine(true);
                    h.label.setEllipsize(TextUtils.TruncateAt.END);
                    h.label.setGravity(row ? Gravity.START | Gravity.CENTER_VERTICAL : Gravity.CENTER);
                    LinearLayout.LayoutParams tlp = row
                            ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                            : new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT);
                    if (row) {
                        tlp.leftMargin = Theme.dp(host, 16);
                    } else {
                        tlp.topMargin = Theme.dp(host, 6);
                    }
                    c.addView(h.label, tlp);
                    c.setTag(h);
                    v = c;
                } else {
                    h = (Holder) v.getTag();
                }
                AppEntry e = shown.get(i);
                h.icon.setImageDrawable(Theme.tint(h.icon.getContext(), e.icon));
                h.label.setText(e.label);
                return v;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> host.launch(shown.get(pos)));
        grid.setOnItemLongClickListener((p, v, pos, id) -> {
            host.appMenu(shown.get(pos));
            return true;
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        search.setOnEditorActionListener((v, actionId, ev) -> {
            if (!shown.isEmpty()) {
                host.launch(shown.get(0));
            }
            return true;
        });
    }

    private void filter(String q) {
        shown.clear();
        shown.addAll(host.repo.search(q));
        if (mode == 2) {
            java.util.Collections.sort(shown, (a, b) -> a.label.compareToIgnoreCase(b.label));
        }
        adapter.notifyDataSetChanged();
    }
}
