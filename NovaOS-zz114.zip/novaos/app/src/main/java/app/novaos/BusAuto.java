package app.novaos;

import android.app.AlertDialog;

import java.util.List;

/** Asks you about the rides AUTO-DETECT noticed: "Did you ride a bus from A to B?" */
final class BusAuto {
    private BusAuto() {
    }

    private static boolean asking;

    /** Call when the home screen is showing. Looks at the oldest waiting ride and, if it fits two stops, asks. */
    static void check(final NovaActivity host) {
        if (asking || BusData.pending().isEmpty() || host.screen != NovaActivity.HOME) {
            return;
        }
        asking = true;
        final BusData.Trip t = BusData.pending().get(0);
        new Thread(() -> {
            BusData.Stop a = nearest(t.slat, t.slon);
            BusData.Stop b = a == null ? null : nearest(t.elat, t.elon);
            if (a == null || b == null || a.id.equals(b.id)) {
                // not between two stops (a walk, a car, a train): forget it quietly
                BusData.dropOldestPending();
                asking = false;
                return;
            }
            host.runOnUiThread(() -> ask(host, t, a, b));
        }).start();
    }

    private static BusData.Stop nearest(double lat, double lon) {
        List<BusData.Stop> l = BusData.nearbyStops(lat, lon);
        if (!l.isEmpty() && l.get(0).dist <= 350) {
            return l.get(0);
        }
        return null;
    }

    private static void ask(final NovaActivity host, final BusData.Trip t, final BusData.Stop a, final BusData.Stop b) {
        int mins = Math.max(1, (int) ((t.end - t.start) / 60000));
        new AlertDialog.Builder(host).setTitle("Did you ride a bus?")
                .setMessage("It looks like you went from " + a.shortName() + " to " + b.shortName() + " (" + mins
                        + " min). Save it as a bus route?")
                .setPositiveButton("YES, SAVE", (d, w) -> {
                    BusData.dropOldestPending();
                    save(host, t, a, b);
                })
                .setNegativeButton("NO", (d, w) -> {
                    BusData.dropOldestPending();
                    asking = false;
                })
                .setNeutralButton("LATER", (d, w) -> asking = false)
                .setOnCancelListener(d -> asking = false)
                .show();
    }

    private static void save(final NovaActivity host, final BusData.Trip t, final BusData.Stop a, final BusData.Stop b) {
        new Thread(() -> {
            BusData.Route r = BusData.buildRoute(a, b, t.start);
            host.runOnUiThread(() -> {
                asking = false;
                if (r == null) {
                    host.toast("No direct bus line found between those stops");
                    return;
                }
                BusData.Route mine = BusData.addRoute(r);
                BusData.markDay(mine, BusData.dayOf(t.start));
                int n = Math.min(mine.days.size(), BusData.CONFIRM_DAYS);
                host.toast(mine.name + ": day " + n + " of " + BusData.CONFIRM_DAYS
                        + (mine.confirmed() ? " (blue line now)" : ""));
            });
        }).start();
    }
}
