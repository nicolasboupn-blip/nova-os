package app.novaos;

/** PROFILE: a small version of your profile card for a page. Tap it to open the full profile. */
final class ProfileWidget extends NovaWidget {
    private ProfileCard card;

    ProfileWidget(NovaActivity host) {
        super(host);
    }

    @Override
    void refresh() {
        removeAllViews();
        card = new ProfileCard(host, true);
        card.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
        card.setClipToOutline(true);
        card.setClickable(true);
        card.setOnClickListener(v -> host.showOverlay(new ProfileScreen(host)));
        addView(card, wide());
    }

    @Override
    long tickMs() {
        return 60000;
    }

    @Override
    void tick() {
        refresh();
    }
}
