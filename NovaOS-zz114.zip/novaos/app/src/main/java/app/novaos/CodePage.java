package app.novaos;

import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The CODE page that takes the second home page. Projects hold files. Each file is saved on the phone as you type,
 * and colours Java, JavaScript, Python and HTML. HTML and JavaScript run in the preview below with a console.
 * Java and Python are saved and coloured, but the phone has no way to run them yet.
 */
final class CodePage extends LinearLayout {
    private static final String[] LANGS = {".js", ".html", ".java", ".py", ".txt"};
    private static final String[] JS_WORDS = {"var", "let", "const", "function", "return", "if", "else", "for", "while",
        "switch", "case", "break", "continue", "try", "catch", "throw", "new", "class", "import", "export", "from",
        "null", "true", "false", "this", "async", "await", "console", "undefined"};
    private static final String[] JAVA_WORDS = {"public", "private", "protected", "class", "interface", "static", "final",
        "void", "int", "long", "double", "float", "boolean", "char", "String", "new", "return", "if", "else", "for",
        "while", "switch", "case", "break", "continue", "try", "catch", "throw", "import", "package", "extends",
        "implements", "null", "true", "false", "this", "super"};
    private static final String[] PY_WORDS = {"def", "class", "return", "if", "elif", "else", "for", "while", "in",
        "import", "from", "as", "try", "except", "with", "lambda", "None", "True", "False", "pass", "print"};
    private static final Pattern NUMBER = Pattern.compile("\\b\\d+(\\.\\d+)?\\b");
    private static final Pattern STRING = Pattern.compile("\"(\\\\.|[^\"\\\\\\n])*\"|'(\\\\.|[^'\\\\\\n])*'");
    private static final Pattern COMMENT_SLASH = Pattern.compile("//[^\\n]*");
    private static final Pattern COMMENT_HASH = Pattern.compile("#[^\\n]*");
    private static final Pattern COMMENT_HTML = Pattern.compile("<!--[\\s\\S]*?-->");
    private static final Pattern TAG = Pattern.compile("</?[a-zA-Z][^>]*>");
    private static final int KW = 0xFFB39DFF, STR = 0xFF2EB872, NUM = 0xFFF2B33D, COMMENT = 0xFF8E84B3, TAGC = 0xFF3FA7D6;
    private static final String CONSOLE = "<script>(function(){var o=document.createElement('pre');"
            + "o.style.cssText='margin:0;padding:8px;color:#F2EEFF;font:12px monospace;white-space:pre-wrap';"
            + "document.addEventListener('DOMContentLoaded',function(){document.body.appendChild(o)});"
            + "function p(a){var s=Array.prototype.map.call(a,function(x){return typeof x==='object'?JSON.stringify(x):String(x)}).join(' ');"
            + "o.textContent+=s+'\\n';}"
            + "console.log=p;console.error=function(){p(arguments)};window.onerror=function(m){p('ERROR: '+m)};})();</script>";

    private final NovaActivity host;
    private final File root;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable saver = this::saveNow;
    private final TextView title;
    private final TextView status;
    private final LinearLayout projectsView;
    private final LinearLayout editorView;
    private final LinearLayout tabs;
    private final EditText editor;
    private final LinearLayout outputBox;
    private final WebView output;
    private String project;
    private String file;
    private boolean loading;

    CodePage(NovaActivity host, String initial) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        root = rootDir(host);

        LinearLayout header = new LinearLayout(host);
        header.setGravity(Gravity.CENTER_VERTICAL);
        title = mono("CODE", 12f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        status = mono("", 10f, Theme.DIM);
        status.setGravity(Gravity.END);
        header.addView(title, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        header.addView(status, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        header.addView(button("CLOSE", Theme.PANEL, () -> {
            saveNow();
            host.hideOverlay();
        }), new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        addView(header, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        projectsView = new LinearLayout(host);
        projectsView.setOrientation(VERTICAL);
        ScrollView sv = new ScrollView(host);
        sv.addView(projectsView);
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));

        editorView = new LinearLayout(host);
        editorView.setOrientation(VERTICAL);
        editorView.setVisibility(GONE);
        tabs = new LinearLayout(host);
        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.addView(tabs);
        editorView.addView(hs, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        editor = new EditText(host);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setTextSize(12f);
        editor.setTextColor(Theme.TEXT);
        editor.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setPadding(dp(10), dp(10), dp(10), dp(10));
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                if (!loading) {
                    status.setText("SAVING...");
                    h.removeCallbacks(saver);
                    h.postDelayed(saver, 700);
                }
            }

            @Override
            public void afterTextChanged(Editable e) {
                if (!loading) {
                    highlight(e);
                }
            }
        });
        LayoutParams ep = new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
        ep.topMargin = dp(8);
        editorView.addView(editor, ep);

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.addView(button("NEW FILE", Theme.PANEL, this::pickNewFile), buttonParams());
        row.addView(button("RUN", Theme.ACCENT, this::run), buttonParams());
        row.addView(button("SAVE", Theme.ACCENT, this::manualSave), buttonParams());
        row.addView(button("PROJECTS", Theme.PANEL, this::showProjects), buttonParams());
        editorView.addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        output = new WebView(host);
        output.getSettings().setJavaScriptEnabled(true);
        output.setBackgroundColor(0xFF0C0917);
        outputBox = new LinearLayout(host);
        outputBox.setVisibility(GONE);
        outputBox.addView(output, new LayoutParams(LayoutParams.MATCH_PARENT, dp(170)));
        editorView.addView(outputBox, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        addView(editorView, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        setBackgroundColor(Theme.BG);
        setPadding(dp(16), dp(44), dp(16), dp(16));
        if (initial != null) {
            openProject(initial);
        } else {
            showProjects();
        }
    }

    static File rootDir(NovaActivity host) {
        File r = new File(host.getFilesDir(), "code");
        r.mkdirs();
        return r;
    }

    static List<String> projects(NovaActivity host) {
        List<String> out = new ArrayList<>();
        File[] list = rootDir(host).listFiles();
        if (list != null) {
            for (File f : list) {
                if (f.isDirectory()) {
                    out.add(f.getName());
                }
            }
        }
        java.util.Collections.sort(out);
        return out;
    }

    /** Makes project1, project2 ... with a starter file, and returns its name. */
    static String newProject(NovaActivity host) {
        File base = rootDir(host);
        String name;
        for (int n = 1; ; n++) {
            name = "project" + n;
            if (!new File(base, name).exists()) {
                break;
            }
        }
        File dir = new File(base, name);
        dir.mkdirs();
        write(new File(dir, "main.js"), "console.log('hello from NOVA');\n");
        return name;
    }

    private void manualSave() {
        saveNow();
        status.setText("SAVED");
    }

    @Override
    protected void onDetachedFromWindow() {
        saveNow();
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ helpers

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView mono(String text, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String text, int color, Runnable action) {
        TextView b = mono(text, 11f, color == Theme.ACCENT ? Theme.BG : Theme.TEXT);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(Theme.rounded(color, 14f, host));
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(8), dp(3), 0);
        return lp;
    }

    private List<String> dirs() {
        List<String> out = new ArrayList<>();
        File[] list = root.listFiles();
        if (list != null) {
            for (File f : list) {
                if (f.isDirectory()) {
                    out.add(f.getName());
                }
            }
        }
        java.util.Collections.sort(out);
        return out;
    }

    private List<String> filesIn(String dir) {
        List<String> out = new ArrayList<>();
        File[] list = new File(root, dir).listFiles();
        if (list != null) {
            for (File f : list) {
                if (f.isFile()) {
                    out.add(f.getName());
                }
            }
        }
        java.util.Collections.sort(out);
        return out;
    }

    private String uniqueName(String base, String ext, String dir) {
        for (int n = 1; ; n++) {
            String name = base + n + ext;
            if (!new File(dir == null ? root : new File(root, dir), name).exists()) {
                return name;
            }
        }
    }

    private String ext() {
        if (file == null) {
            return "";
        }
        int dot = file.lastIndexOf('.');
        return dot < 0 ? "" : file.substring(dot);
    }

    // ------------------------------------------------------------------ projects

    private void showProjects() {
        saveNow();
        project = null;
        file = null;
        title.setText("CODE");
        status.setText("");
        editorView.setVisibility(GONE);
        projectsView.setVisibility(VISIBLE);
        projectsView.removeAllViews();
        for (String name : dirs()) {
            TextView row = mono(name + "   ·   " + filesIn(name).size() + " files", 13f, Theme.TEXT);
            row.setPadding(dp(14), dp(14), dp(14), dp(14));
            row.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
            row.setClickable(true);
            Theme.ripple(row);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, dp(6), 0, 0);
            row.setOnClickListener(v -> openProject(name));
            row.setOnLongClickListener(v -> {
                confirm("Delete project " + name + " and all its files?", () -> deleteProject(name));
                return true;
            });
            projectsView.addView(row, lp);
        }
        if (dirs().isEmpty()) {
            TextView none = mono("No projects yet. Make one, then add files to it.", 12f, Theme.DIM);
            none.setPadding(dp(4), dp(10), dp(4), dp(10));
            projectsView.addView(none);
        }
        TextView add = button("NEW PROJECT", Theme.ACCENT, this::createProject);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        ap.setMargins(0, dp(12), 0, 0);
        projectsView.addView(add, ap);
    }

    private void createProject() {
        String name = uniqueName("project", "", null);
        File dir = new File(root, name);
        dir.mkdirs();
        write(new File(dir, "main.js"), "console.log('hello from NOVA');\n");
        openProject(name);
    }

    private void openProject(String name) {
        project = name;
        title.setText("CODE  ·  " + name);
        projectsView.setVisibility(GONE);
        editorView.setVisibility(VISIBLE);
        List<String> files = filesIn(name);
        if (files.isEmpty()) {
            write(new File(new File(root, name), "main.js"), "");
            files = filesIn(name);
        }
        rebuildTabs();
        openFile(files.get(0));
    }

    private void deleteProject(String name) {
        File dir = new File(root, name);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                f.delete();
            }
        }
        dir.delete();
        showProjects();
    }

    // ------------------------------------------------------------------ files

    private void rebuildTabs() {
        tabs.removeAllViews();
        if (project == null) {
            return;
        }
        for (String name : filesIn(project)) {
            boolean on = name.equals(file);
            TextView t = mono(name, 11f, on ? Theme.BG : Theme.TEXT);
            t.setPadding(dp(12), dp(8), dp(12), dp(8));
            t.setBackground(Theme.rounded(on ? Theme.ACCENT : Theme.PANEL, 12f, host));
            t.setClickable(true);
            Theme.ripple(t);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(3), dp(4), dp(3), dp(4));
            t.setOnClickListener(v -> openFile(name));
            t.setOnLongClickListener(v -> {
                confirm("Delete " + name + "?", () -> deleteFile(name));
                return true;
            });
            tabs.addView(t, lp);
        }
    }

    private void openFile(String name) {
        saveNow();
        file = name;
        loading = true;
        String text = read(new File(new File(root, project), name));
        editor.setText(text);
        loading = false;
        highlight(editor.getText());
        rebuildTabs();
        status.setText("SAVED");
    }

    private void pickNewFile() {
        if (project == null) {
            return;
        }
        new AlertDialog.Builder(host).setTitle("New file type").setItems(LANGS, (d, which) -> createFile(LANGS[which]))
                .show();
    }

    private void createFile(String ext) {
        String name = uniqueName("file", ext, project);
        write(new File(new File(root, project), name), "");
        openFile(name);
    }

    private void deleteFile(String name) {
        new File(new File(root, project), name).delete();
        if (name.equals(file)) {
            file = null;
            loading = true;
            editor.setText("");
            loading = false;
        }
        List<String> left = filesIn(project);
        if (left.isEmpty()) {
            write(new File(new File(root, project), "main.js"), "");
            left = filesIn(project);
        }
        rebuildTabs();
        openFile(left.get(0));
    }

    private void confirm(String question, Runnable yes) {
        new AlertDialog.Builder(host).setMessage(question)
                .setPositiveButton("DELETE", (d, w) -> yes.run())
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void saveNow() {
        h.removeCallbacks(saver);
        if (project == null || file == null) {
            return;
        }
        boolean ok = write(new File(new File(root, project), file), editor.getText().toString());
        status.setText(ok ? "SAVED" : "SAVE FAILED");
    }

    private static String read(File f) {
        try {
            return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private static boolean write(File f, String text) {
        try {
            Files.write(f.toPath(), text.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ colours

    private void highlight(Editable e) {
        for (Object s : e.getSpans(0, e.length(), ForegroundColorSpan.class)) {
            e.removeSpan(s);
        }
        String x = ext();
        if (x.equals(".html")) {
            color(e, TAG, TAGC);
            color(e, COMMENT_HTML, COMMENT);
            return;
        }
        String[] words = x.equals(".js") ? JS_WORDS : x.equals(".java") ? JAVA_WORDS : x.equals(".py") ? PY_WORDS : null;
        if (words == null) {
            return;
        }
        String alt = String.join("|", Arrays.asList(words));
        color(e, Pattern.compile("\\b(" + alt + ")\\b"), KW);
        color(e, NUMBER, NUM);
        color(e, STRING, STR);
        color(e, x.equals(".py") ? COMMENT_HASH : COMMENT_SLASH, COMMENT);
    }

    private static void color(Editable e, Pattern p, int c) {
        Matcher m = p.matcher(e);
        while (m.find()) {
            e.setSpan(new ForegroundColorSpan(c), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    // ------------------------------------------------------------------ run

    private void run() {
        saveNow();
        if (project == null || file == null) {
            return;
        }
        String x = ext();
        String text = editor.getText().toString();
        String page;
        if (x.equals(".html")) {
            page = CONSOLE + text;
        } else if (x.equals(".js")) {
            page = "<html><head><meta name='viewport' content='width=device-width'></head><body style='background:#0C0917'>"
                    + CONSOLE + "<script>" + text.replace("</script", "<\\/script") + "</script></body></html>";
        } else {
            status.setText("CAN'T RUN " + x + " ON THE PHONE YET");
            return;
        }
        outputBox.setVisibility(VISIBLE);
        output.loadDataWithBaseURL(null, page, "text/html", "utf-8", null);
        status.setText("RAN");
    }
}
