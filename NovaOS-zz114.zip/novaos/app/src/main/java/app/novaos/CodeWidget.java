package app.novaos;

import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** The CODE page on the quick panel. Tap a project, NEW PROJECT or OPEN to get the full editor. */
final class CodeWidget extends LinearLayout {
    private static final int SHOWN = 2;
    private final NovaActivity host;
    private final LinearLayout list;

    CodeWidget(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        addView(list, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        row.addView(button("NEW PROJECT", Theme.ACCENT, () -> open(CodePage.newProject(host))), weight());
        row.addView(button("OPEN", Theme.PANEL, () -> open(null)), weight());
        LayoutParams rp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        rp.topMargin = Theme.dp(host, 8);
        addView(row, rp);
        refresh();
    }

    private void open(String name) {
        host.showOverlay(new CodePage(host, name));
    }

    /** Lists the newest projects again, e.g. after one was made or deleted. */
    void refresh() {
        list.removeAllViews();
        List<String> names = CodePage.projects(host);
        if (names.isEmpty()) {
            list.addView(mono("No projects yet. Make one below.", 11f, Theme.DIM));
            return;
        }
        for (int i = 0; i < names.size() && i < SHOWN; i++) {
            final String name = names.get(i);
            TextView t = mono(name, 12f, Theme.TEXT);
            t.setPadding(Theme.dp(host, 10), Theme.dp(host, 8), Theme.dp(host, 10), Theme.dp(host, 8));
            t.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
            t.setClickable(true);
            Theme.ripple(t);
            t.setOnClickListener(v -> open(name));
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.topMargin = Theme.dp(host, 4);
            list.addView(t, lp);
        }
        if (names.size() > SHOWN) {
            list.addView(mono("+" + (names.size() - SHOWN) + " more: tap OPEN", 10f, Theme.DIM));
        }
    }

    private TextView mono(String text, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String text, int color, Runnable action) {
        TextView b = mono(text, 11f, color == Theme.ACCENT ? Theme.BG : Theme.TEXT);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(Theme.rounded(color, 14f, host));
        b.setPadding(Theme.dp(host, 8), Theme.dp(host, 9), Theme.dp(host, 8), Theme.dp(host, 9));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LayoutParams weight() {
        LayoutParams lp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
        return lp;
    }
}
