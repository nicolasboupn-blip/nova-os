package app.novaos;

import android.app.ActivityManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.StatFs;
import android.os.SystemClock;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;

/**
 * Extra home screens, part two: TIMELINE (your day as a line of the apps you opened), SHELF (apps as books on a
 * wooden shelf), COLUMNS (pinned, recent and A to Z side by side), TUI (a text dashboard like a terminal program),
 * SPOTLIGHT (one search box for apps, maths and the web), DRIVE (a car dashboard with big buttons and music keys) and
 * CORKBOARD (polaroids and sticky notes pinned to cork).
 */
final class HomesB {
    private HomesB() {
    }

    // ================================================================== TIMELINE

    /** Today as a line from the morning to now. Every app you opened sits at its time. */
    static final class Timeline extends AltHome {
        private final TextView time;
        private final TextView stats;

        Timeline(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(20), dp(46), dp(20), 0);
            time = text(clock(), 44f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            time.setGravity(Gravity.START);
            col.addView(time);
            TextView d = text(date(), 13f, Theme.DIM);
            d.setGravity(Gravity.START);
            col.addView(d);
            stats = text("", 11f, Theme.ACCENT);
            stats.setGravity(Gravity.START);
            stats.setPadding(0, dp(6), 0, dp(10));
            col.addView(stats);

            final ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            LinearLayout line = new LinearLayout(host);
            line.setOrientation(LinearLayout.VERTICAL);
            sv.addView(line);
            col.addView(sv, lp(-1, 0, 1f));
            build(line);
            sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));

            LinearLayout quick = new LinearLayout(host);
            quick.setPadding(0, dp(8), 0, 0);
            List<AppEntry> pins = pinned();
            for (int i = 0; i < 5; i++) {
                if (i < pins.size()) {
                    quick.addView(appTile(pins.get(i), 40, false), lp(0, -2, 1f));
                } else {
                    quick.addView(new View(host), lp(0, 1, 1f));
                }
            }
            col.addView(quick, lp(-1, -2));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        private void build(LinearLayout line) {
            List<Object[]> today = HomeKit.today();
            java.util.Collections.reverse(today);
            int nowH = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int firstH = Math.min(nowH, 7);
            Calendar c = Calendar.getInstance();
            java.util.Map<String, Integer> counts = new java.util.HashMap<>();
            for (Object[] o : today) {
                c.setTimeInMillis((long) o[1]);
                firstH = Math.min(firstH, c.get(Calendar.HOUR_OF_DAY));
                String pkg = (String) o[0];
                counts.put(pkg, counts.containsKey(pkg) ? counts.get(pkg) + 1 : 1);
            }
            String top = null;
            int best = 0;
            for (java.util.Map.Entry<String, Integer> en : counts.entrySet()) {
                if (en.getValue() > best) {
                    best = en.getValue();
                    top = en.getKey();
                }
            }
            AppEntry topApp = top == null ? null : host.repo.find(top);
            stats.setText(today.isEmpty() ? "Nothing opened yet today. Apps you open show up on this line."
                    : today.size() + " opens today" + (topApp != null ? "  ·  most: " + topApp.label : ""));
            SimpleDateFormat hm = new SimpleDateFormat("HH:mm", Locale.getDefault());
            int k = 0;
            for (int h = firstH; h <= nowH; h++) {
                List<Object[]> in = new ArrayList<>();
                while (k < today.size()) {
                    c.setTimeInMillis((long) today.get(k)[1]);
                    if (c.get(Calendar.HOUR_OF_DAY) != h) {
                        break;
                    }
                    in.add(today.get(k));
                    k++;
                }
                line.addView(hourRow(String.format(Locale.US, "%02d", h), in, hm), lp(-1, -2));
            }
            // the "now" mark at the end of the line
            LinearLayout now = new LinearLayout(host);
            now.setGravity(Gravity.CENTER_VERTICAL);
            TextView nl = text("now", 11f, Theme.ACCENT);
            nl.setGravity(Gravity.START);
            now.addView(nl, lp(dp(44), -2));
            View dot = new View(host);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Theme.ACCENT);
            dot.setBackground(g);
            LinearLayout.LayoutParams dp1 = lp(dp(12), dp(12));
            dp1.leftMargin = -dp(5);
            now.addView(dot, dp1);
            View rule = new View(host);
            rule.setBackgroundColor(Theme.ACCENT);
            LinearLayout.LayoutParams rp = lp(0, dp(2), 1f);
            rp.leftMargin = dp(6);
            now.addView(rule, rp);
            now.setPadding(0, dp(4), 0, dp(16));
            line.addView(now, lp(-1, -2));
        }

        private View hourRow(String hour, List<Object[]> in, SimpleDateFormat hm) {
            LinearLayout row = new LinearLayout(host);
            TextView h = text(hour, 11f, in.isEmpty() ? Theme.DIM : Theme.TEXT);
            h.setGravity(Gravity.START);
            h.setPadding(0, dp(2), 0, 0);
            row.addView(h, lp(dp(44), -2));
            View rail = new View(host);
            rail.setBackgroundColor(Theme.PANEL);
            row.addView(rail, lp(dp(2), -1));
            LinearLayout list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(12), 0, 0, dp(in.isEmpty() ? 14 : 8));
            String last = "";
            TextView lastCount = null;
            int same = 1;
            for (Object[] o : in) {
                final AppEntry e = host.repo.find((String) o[0]);
                if (e == null) {
                    continue;
                }
                if (e.pkg.equals(last) && lastCount != null) {
                    same++;
                    lastCount.setText("×" + same);
                    continue;
                }
                last = e.pkg;
                same = 1;
                LinearLayout it = new LinearLayout(host);
                it.setGravity(Gravity.CENTER_VERTICAL);
                it.setPadding(dp(10), dp(6), dp(10), dp(6));
                it.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
                ImageView iv = new ImageView(host);
                iv.setImageDrawable(Theme.tint(host, e.icon));
                it.addView(iv, lp(dp(26), dp(26)));
                TextView n = text(e.label, 13f, Theme.TEXT);
                n.setGravity(Gravity.START);
                n.setSingleLine(true);
                n.setPadding(dp(10), 0, 0, 0);
                it.addView(n, lp(0, -2, 1f));
                lastCount = text("", 11f, Theme.ACCENT);
                lastCount.setPadding(dp(6), 0, dp(6), 0);
                it.addView(lastCount);
                it.addView(text(hm.format(new Date((long) o[1])), 10f, Theme.DIM));
                it.setOnClickListener(v -> host.launch(e));
                it.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                LinearLayout.LayoutParams ip = lp(-1, -2);
                ip.bottomMargin = dp(5);
                list.addView(it, ip);
            }
            row.addView(list, lp(0, -2, 1f));
            return row;
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== SHELF

    /** Your apps as books on wooden shelves. Each spine has the app's colour, name and icon. */
    static final class Shelf extends AltHome {
        private final TextView time;

        Shelf(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF2A1A10);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), dp(44), dp(14), 0);
            LinearLayout sign = new LinearLayout(host);
            sign.setOrientation(LinearLayout.VERTICAL);
            sign.setGravity(Gravity.CENTER);
            sign.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[] {0xFFE9D9B4, 0xFFD6C29A});
            sg.setCornerRadius(dp(6));
            sg.setStroke(dp(3), 0xFF6B4423);
            sign.setBackground(sg);
            time = text(clock(), 34f, 0xFF3B2414);
            time.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            sign.addView(time);
            TextView d = text(date(), 12f, 0xFF6B4423);
            d.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
            sign.addView(d);
            LinearLayout.LayoutParams sp = lp(-2, -2);
            sp.gravity = Gravity.CENTER_HORIZONTAL;
            sp.bottomMargin = dp(14);
            col.addView(sign, sp);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(new Books(host, appsFor(48)));
            col.addView(sv, lp(-1, 0, 1f));
            LinearLayout links = new LinearLayout(host);
            links.setGravity(Gravity.CENTER);
            links.setPadding(0, dp(8), 0, dp(14));
            String[] n = {"catalogue", "widgets", "settings"};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 14f, 0xFFE9D9B4);
                t.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
                t.setPadding(dp(14), dp(8), dp(14), dp(8));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                links.addView(t);
            }
            col.addView(links, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        final class Books extends View {
            private final List<AppEntry> apps;
            private final List<RectF> spots = new ArrayList<>();
            private final List<Float> planks = new ArrayList<>();
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final GestureDetector gd;
            private final float d;

            Books(Context c, List<AppEntry> apps) {
                super(c);
                this.apps = apps;
                d = getResources().getDisplayMetrics().density;
                gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        int i = hit(e);
                        if (i >= 0) {
                            host.launch(Books.this.apps.get(i));
                        }
                        return true;
                    }

                    @Override
                    public void onLongPress(MotionEvent e) {
                        int i = hit(e);
                        if (i >= 0) {
                            host.appMenu(Books.this.apps.get(i));
                        }
                    }
                });
            }

            private int hit(MotionEvent e) {
                for (int i = 0; i < spots.size(); i++) {
                    if (spots.get(i).contains(e.getX(), e.getY())) {
                        return i;
                    }
                }
                return -1;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                return gd.onTouchEvent(e);
            }

            @Override
            protected void onMeasure(int ws, int hs) {
                int w = MeasureSpec.getSize(ws);
                spots.clear();
                planks.clear();
                float shelfH = 170 * d;
                float plank = 14 * d;
                float x = 10 * d;
                float y = 0;
                for (AppEntry e : apps) {
                    int hsh = Math.abs(e.pkg.hashCode());
                    float bw = (30 + hsh % 14) * d;
                    float bh = (118 + (hsh / 14) % 42) * d;
                    if (x + bw > w - 10 * d) {
                        planks.add(y + shelfH);
                        y += shelfH + plank + 8 * d;
                        x = 10 * d;
                    }
                    spots.add(new RectF(x, y + shelfH - bh, x + bw, y + shelfH));
                    x += bw + 3 * d;
                }
                planks.add(y + shelfH);
                setMeasuredDimension(w, Math.round(y + shelfH + plank + 10 * d));
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth();
                float plank = 14 * d;
                // the back wall of each shelf, then the plank
                for (float py : planks) {
                    p.setShader(new LinearGradient(0, py - 170 * d, 0, py, 0xFF20130A, 0xFF3A2414, Shader.TileMode.CLAMP));
                    c.drawRect(0, py - 170 * d, w, py, p);
                    p.setShader(new LinearGradient(0, py, 0, py + plank, 0xFFA0703F, 0xFF6B4423, Shader.TileMode.CLAMP));
                    c.drawRect(0, py, w, py + plank, p);
                    p.setShader(null);
                    p.setColor(0x40000000);
                    c.drawRect(0, py + plank, w, py + plank + 6 * d, p);
                }
                p.setShader(null);
                p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                p.setTextSize(11 * d);
                for (int i = 0; i < spots.size(); i++) {
                    RectF r = spots.get(i);
                    AppEntry e = apps.get(i);
                    int col = HomeKit.color(host, e);
                    p.setColor(col);
                    c.drawRoundRect(r, 3 * d, 3 * d, p);
                    p.setColor(HomeKit.darker(col, 0.6f));
                    c.drawRect(r.left, r.top + 8 * d, r.right, r.top + 12 * d, p);
                    c.drawRect(r.left, r.bottom - 34 * d, r.right, r.bottom - 31 * d, p);
                    p.setColor(0x22FFFFFF);
                    c.drawRect(r.left + 2 * d, r.top, r.left + 5 * d, r.bottom, p);
                    // title along the spine
                    c.save();
                    c.rotate(90f, r.centerX(), r.centerY());
                    float len = r.height() - 52 * d;
                    String t = e.label;
                    int n = p.breakText(t, true, len, null);
                    if (n < t.length()) {
                        t = t.substring(0, Math.max(1, n - 1)) + "…";
                    }
                    p.setColor(HomeKit.onColor(col));
                    p.setTextAlign(Paint.Align.CENTER);
                    c.drawText(t, r.centerX() - 12 * d, r.centerY() + 4 * d, p);
                    c.restore();
                    Bitmap b = HomeKit.icon(host, e, Math.round(20 * d));
                    float ix = r.centerX() - 10 * d;
                    c.drawBitmap(b, ix, r.bottom - 27 * d, null);
                }
            }
        }
    }

    // ================================================================== COLUMNS

    /** Three columns side by side: your pinned apps, the ones you opened last, and every app from A to Z. */
    static final class Columns extends AltHome {
        private final TextView time;

        Columns(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), dp(44), dp(12), 0);
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.BOTTOM);
            head.setPadding(dp(4), 0, dp(4), dp(12));
            time = text(clock(), 34f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            head.addView(time);
            TextView d = text(date(), 12f, Theme.DIM);
            d.setPadding(dp(12), 0, 0, dp(6));
            head.addView(d);
            col.addView(head, lp(-1, -2));

            LinearLayout three = new LinearLayout(host);
            three.addView(column("PINNED", pinned(), true), weight(1f));
            List<AppEntry> rec = HomeKit.recent(host, 14);
            three.addView(column("RECENT", rec, true), weight(1f));
            three.addView(column("A → Z", new ArrayList<>(host.repo.all), false), weight(1.15f));
            col.addView(three, lp(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        private LinearLayout.LayoutParams weight(float w) {
            LinearLayout.LayoutParams p = lp(0, -1, w);
            p.setMargins(dp(3), 0, dp(3), 0);
            return p;
        }

        private View column(String title, List<AppEntry> apps, boolean icons) {
            LinearLayout box = new LinearLayout(host);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
            box.setPadding(dp(6), dp(10), dp(6), dp(6));
            TextView t = text(title, 9f, Theme.ACCENT);
            t.setLetterSpacing(0.15f);
            t.setPadding(0, 0, 0, dp(8));
            box.addView(t);
            LinearLayout list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            if (apps.isEmpty()) {
                TextView e = text(icons && title.equals("RECENT") ? "open some apps\nand they land here"
                        : "pin apps from\nthe drawer", 10f, Theme.DIM);
                e.setPadding(0, dp(20), 0, 0);
                list.addView(e);
            }
            char lastLetter = 0;
            for (final AppEntry e : apps) {
                if (icons) {
                    list.addView(appTile(e, 38, true), lp(-1, -2));
                } else {
                    char f = e.label.isEmpty() ? '#' : Character.toUpperCase(e.label.charAt(0));
                    if (f != lastLetter) {
                        lastLetter = f;
                        TextView h = text(String.valueOf(f), 10f, Theme.ACCENT);
                        h.setGravity(Gravity.START);
                        h.setPadding(dp(4), dp(8), 0, dp(2));
                        list.addView(h);
                    }
                    TextView n = text(e.label, 11.5f, Theme.TEXT);
                    n.setGravity(Gravity.START);
                    n.setSingleLine(true);
                    n.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    n.setPadding(dp(4), dp(6), dp(2), dp(6));
                    n.setOnClickListener(v -> host.launch(e));
                    n.setOnLongClickListener(v -> {
                        host.appMenu(e);
                        return true;
                    });
                    list.addView(n, lp(-1, -2));
                }
            }
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(list);
            box.addView(sv, lp(-1, 0, 1f));
            return box;
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== TUI

    /** A text dashboard like a terminal program: boxes with bars for battery, memory and storage, a numbered app list
     *  and a command line. Type to filter, press enter to open. */
    static final class Tui extends AltHome {
        static final int BG = 0xFF0A0A0A;
        static final int FG = 0xFFD0D0D0;
        static final int GREEN = 0xFF4EE04E;
        static final int CYAN = 0xFF4FC1E9;
        static final int YELLOW = 0xFFE9D44F;
        static final int RED = 0xFFE9574F;
        private final TextView top;
        private final TextView sys;
        private final LinearLayout list;
        private final List<AppEntry> all;
        private final List<AppEntry> shown = new ArrayList<>();
        private final EditText cmd;

        Tui(NovaActivity host) {
            super(host);
            setBackgroundColor(BG);
            all = new ArrayList<>(pinned());
            for (AppEntry e : host.repo.all) {
                if (!all.contains(e)) {
                    all.add(e);
                }
            }
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(8), dp(40), dp(8), dp(6));
            top = mono("", CYAN);
            col.addView(top, lp(-1, -2));
            sys = mono("", FG);
            col.addView(box(" SYSTEM ", sys), boxLp());
            list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(list);
            LinearLayout.LayoutParams ap = boxLp();
            ap.height = 0;
            ap.weight = 1f;
            col.addView(box(" APPS ", sv), ap);

            LinearLayout line = new LinearLayout(host);
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(4), dp(6), dp(4), dp(6));
            line.addView(mono("nova@phone:~$ ", GREEN));
            cmd = new EditText(host);
            cmd.setBackground(null);
            cmd.setTypeface(Typeface.MONOSPACE);
            cmd.setTextSize(12f);
            cmd.setTextColor(FG);
            cmd.setHint("type an app or a number");
            cmd.setHintTextColor(0xFF555555);
            cmd.setPadding(0, 0, 0, 0);
            cmd.setSingleLine(true);
            cmd.setImeOptions(EditorInfo.IME_ACTION_GO);
            cmd.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    fill(s.toString());
                }
            });
            cmd.setOnEditorActionListener((v, id, ev) -> {
                run(cmd.getText().toString().trim());
                return true;
            });
            line.addView(cmd, lp(0, -2, 1f));
            col.addView(line, lp(-1, -2));

            LinearLayout keys = new LinearLayout(host);
            String[][] f = {{"F1", "Apps"}, {"F2", "Wdgt"}, {"F3", "Term"}, {"F4", "Note"}, {"F10", "Setup"}};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showTerminal(),
                () -> host.showNotes(), () -> host.showSettings()};
            for (int i = 0; i < f.length; i++) {
                SpannableStringBuilder sb = new SpannableStringBuilder();
                sb.append(f[i][0]);
                sb.setSpan(new ForegroundColorSpan(FG), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                int st = sb.length();
                sb.append(f[i][1]);
                sb.setSpan(new android.text.style.BackgroundColorSpan(CYAN), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new ForegroundColorSpan(0xFF000000), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                TextView t = mono("", FG);
                t.setText(sb);
                t.setPadding(0, dp(8), dp(4), dp(10));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                keys.addView(t, lp(0, -2, 1f));
            }
            col.addView(keys, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            fill("");
            tick();
        }

        private TextView mono(String s, int c) {
            TextView t = text(s, 12f, c);
            t.setTypeface(Typeface.MONOSPACE);
            t.setGravity(Gravity.START);
            return t;
        }

        private LinearLayout.LayoutParams boxLp() {
            LinearLayout.LayoutParams p = lp(-1, -2);
            p.topMargin = dp(8);
            return p;
        }

        private View box(String title, View content) {
            FrameLayout f = new FrameLayout(host);
            LinearLayout b = new LinearLayout(host);
            b.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable g = new GradientDrawable();
            g.setStroke(dp(1), CYAN);
            b.setBackground(g);
            b.setPadding(dp(8), dp(12), dp(8), dp(8));
            b.addView(content, lp(-1, content instanceof ScrollView ? -1 : -2));
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -1);
            bp.topMargin = dp(7);
            f.addView(b, bp);
            TextView t = mono(title, YELLOW);
            t.setBackgroundColor(BG);
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2);
            tp.leftMargin = dp(10);
            f.addView(t, tp);
            return f;
        }

        private void fill(String q) {
            list.removeAllViews();
            shown.clear();
            String ql = q.toLowerCase(Locale.getDefault());
            for (AppEntry e : all) {
                if (ql.isEmpty() || e.label.toLowerCase(Locale.getDefault()).contains(ql)) {
                    shown.add(e);
                }
            }
            for (int i = 0; i < shown.size() && i < 120; i++) {
                final AppEntry e = shown.get(i);
                SpannableStringBuilder sb = new SpannableStringBuilder();
                sb.append(String.format(Locale.US, "%02d ", i + 1));
                sb.setSpan(new ForegroundColorSpan(GREEN), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.append(e.label);
                int st = sb.length();
                sb.append("  ").append(e.pkg);
                sb.setSpan(new ForegroundColorSpan(0xFF5A5A5A), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                TextView t = mono("", FG);
                t.setText(sb);
                t.setSingleLine(true);
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.setPadding(0, dp(3), 0, dp(3));
                t.setOnClickListener(v -> host.launch(e));
                t.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                list.addView(t, lp(-1, -2));
            }
            if (shown.isEmpty()) {
                list.addView(mono("no match. enter searches the drawer", RED));
            }
        }

        private void run(String s) {
            if (s.isEmpty()) {
                return;
            }
            try {
                int n = Integer.parseInt(s);
                if (n >= 1 && n <= shown.size()) {
                    host.launch(shown.get(n - 1));
                    return;
                }
            } catch (NumberFormatException ignored) {
                // not a number: open the first match
            }
            if (!shown.isEmpty()) {
                host.launch(shown.get(0));
            } else {
                host.showDrawer();
            }
        }

        private CharSequence bar(String name, int pct, String right) {
            int n = 20;
            int lit = Math.max(0, Math.min(n, Math.round(pct * n / 100f)));
            SpannableStringBuilder sb = new SpannableStringBuilder();
            sb.append(name);
            sb.setSpan(new ForegroundColorSpan(CYAN), 0, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append(" [");
            int st = sb.length();
            for (int i = 0; i < lit; i++) {
                sb.append('|');
            }
            int color = pct < 60 ? GREEN : pct < 85 ? YELLOW : RED;
            sb.setSpan(new ForegroundColorSpan(color), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            for (int i = lit; i < n; i++) {
                sb.append(' ');
            }
            sb.append("] ").append(right).append('\n');
            return sb;
        }

        @Override
        void tick() {
            long up = SystemClock.elapsedRealtime() / 1000;
            top.setText(String.format(Locale.US, "NOVA  %s  up %dd %02d:%02d  apps %d",
                    new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()),
                    up / 86400, (up / 3600) % 24, (up / 60) % 60, all.size()));
            SpannableStringBuilder sb = new SpannableStringBuilder();
            int b = battery();
            sb.append(bar("BAT", b, b + "%"));
            try {
                ActivityManager am = (ActivityManager) host.getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                long used = mi.totalMem - mi.availMem;
                sb.append(bar("MEM", (int) (used * 100 / Math.max(1, mi.totalMem)),
                        String.format(Locale.US, "%.1fG/%.1fG", used / 1e9, mi.totalMem / 1e9)));
            } catch (RuntimeException ignored) {
                // no memory info
            }
            try {
                StatFs fs = new StatFs(android.os.Environment.getDataDirectory().getPath());
                long total = fs.getTotalBytes();
                long free = fs.getAvailableBytes();
                sb.append(bar("DSK", (int) ((total - free) * 100 / Math.max(1, total)),
                        String.format(Locale.US, "%.0fG free", free / 1e9)));
            } catch (RuntimeException ignored) {
                // no storage info
            }
            Calendar c = Calendar.getInstance();
            int day = (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)) * 100 / 1440;
            CharSequence last = bar("DAY", day, day + "%");
            sb.append(last.subSequence(0, last.length() - 1));
            sys.setText(sb);
        }
    }

    // ================================================================== SPOTLIGHT

    /** One big search box: apps, a quick calculator and a web search, with suggestions while it is empty. */
    static final class Spotlight extends AltHome {
        private final TextView time;
        private final LinearLayout results;
        private final EditText box;

        Spotlight(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(18), dp(60), dp(18), 0);
            time = text(clock(), 56f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            col.addView(time);
            TextView d = text(date(), 13f, Theme.DIM);
            d.setPadding(0, 0, 0, dp(24));
            col.addView(d);
            LinearLayout bar = new LinearLayout(host);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setBackground(Theme.rounded(Theme.PANEL, 26f, host));
            bar.setPadding(dp(18), dp(4), dp(10), dp(4));
            bar.addView(text("⌕", 20f, Theme.DIM));
            box = new EditText(host);
            box.setBackground(null);
            box.setTextSize(16f);
            box.setTextColor(Theme.TEXT);
            box.setHint("Search apps, the web, or 3*7");
            box.setHintTextColor(Theme.DIM);
            box.setSingleLine(true);
            box.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            box.setPadding(dp(10), dp(12), dp(4), dp(12));
            bar.addView(box, lp(0, -2, 1f));
            TextView clear = text("✕", 14f, Theme.DIM);
            clear.setPadding(dp(8), dp(8), dp(8), dp(8));
            clear.setOnClickListener(v -> box.setText(""));
            bar.addView(clear);
            col.addView(bar, lp(-1, -2));
            results = new LinearLayout(host);
            results.setOrientation(LinearLayout.VERTICAL);
            results.setPadding(0, dp(14), 0, dp(10));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(results);
            col.addView(sv, lp(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            box.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    show(s.toString().trim());
                }
            });
            box.setOnEditorActionListener((v, id, ev) -> {
                go(box.getText().toString().trim());
                return true;
            });
            show("");
        }

        private TextView head(String s) {
            TextView t = text(s, 10f, Theme.DIM);
            t.setLetterSpacing(0.15f);
            t.setGravity(Gravity.START);
            t.setPadding(dp(4), dp(10), 0, dp(6));
            return t;
        }

        private View grid(List<AppEntry> apps) {
            LinearLayout g = new LinearLayout(host);
            g.setOrientation(LinearLayout.VERTICAL);
            LinearLayout row = null;
            for (int i = 0; i < apps.size(); i++) {
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    g.addView(row, lp(-1, -2));
                }
                row.addView(appTile(apps.get(i), 46, true), lp(0, -2, 1f));
            }
            if (row != null) {
                for (int k = apps.size() % 4; k != 0 && k < 4; k++) {
                    row.addView(new View(host), lp(0, 1, 1f));
                }
            }
            return g;
        }

        private View action(String icon, String title, String sub, final Runnable r) {
            LinearLayout it = new LinearLayout(host);
            it.setGravity(Gravity.CENTER_VERTICAL);
            it.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
            it.setPadding(dp(14), dp(12), dp(14), dp(12));
            TextView i = text(icon, 18f, Theme.ACCENT);
            it.addView(i, lp(dp(34), -2));
            LinearLayout tx = new LinearLayout(host);
            tx.setOrientation(LinearLayout.VERTICAL);
            TextView t = text(title, 14f, Theme.TEXT);
            t.setGravity(Gravity.START);
            tx.addView(t);
            if (sub != null) {
                TextView s = text(sub, 10f, Theme.DIM);
                s.setGravity(Gravity.START);
                tx.addView(s);
            }
            it.addView(tx, lp(0, -2, 1f));
            it.setOnClickListener(v -> r.run());
            LinearLayout.LayoutParams p = lp(-1, -2);
            p.bottomMargin = dp(6);
            it.setLayoutParams(p);
            return it;
        }

        private void show(final String q) {
            results.removeAllViews();
            if (q.isEmpty()) {
                List<AppEntry> rec = HomeKit.recent(host, 4);
                if (!rec.isEmpty()) {
                    results.addView(head("SUGGESTIONS"));
                    results.addView(grid(rec));
                }
                List<AppEntry> pins = pinned();
                if (pins.size() > 8) {
                    pins = new ArrayList<>(pins.subList(0, 8));
                }
                results.addView(head("PINNED"));
                if (pins.isEmpty()) {
                    TextView e = text("Pin apps from the drawer and they show up here.", 12f, Theme.DIM);
                    e.setGravity(Gravity.START);
                    results.addView(e);
                } else {
                    results.addView(grid(pins));
                }
                return;
            }
            final Double math = Calc.eval(q);
            if (math != null) {
                final String val = Calc.format(math);
                results.addView(action("=", val, q + "   ·  tap to copy", () -> {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("result", val));
                    host.toast("Copied " + val);
                }));
            }
            List<AppEntry> found = host.repo.search(q);
            if (!found.isEmpty()) {
                final AppEntry topHit = found.get(0);
                results.addView(head("TOP HIT"));
                results.addView(action("★", topHit.label, "open", () -> host.launch(topHit)));
                if (found.size() > 1) {
                    results.addView(head("APPS"));
                    results.addView(grid(found.subList(1, Math.min(found.size(), 13))));
                }
            }
            results.addView(head("WEB"));
            results.addView(action("↗", "Search the web for “" + q + "”", null, () -> web(q)));
        }

        private void go(String q) {
            if (q.isEmpty()) {
                return;
            }
            List<AppEntry> found = host.repo.search(q);
            if (!found.isEmpty()) {
                host.launch(found.get(0));
            } else if (Calc.eval(q) == null) {
                web(q);
            }
        }

        private void web(String q) {
            host.hideKeyboard();
            try {
                Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
                i.putExtra(SearchManager.QUERY, q);
                host.startActivity(i);
            } catch (RuntimeException e) {
                try {
                    host.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(
                            "https://duckduckgo.com/?q=" + android.net.Uri.encode(q))));
                } catch (RuntimeException e2) {
                    host.toast("No browser found");
                }
            }
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    /** A tiny calculator for SPOTLIGHT: + - * / ^ %, brackets and decimals. Returns null if it is not maths. */
    static final class Calc {
        private final String s;
        private int i;

        private Calc(String s) {
            this.s = s.replace(" ", "").replace(',', '.').replace('x', '*').replace('×', '*').replace('÷', '/');
        }

        static Double eval(String q) {
            if (q == null || !q.matches(".*[0-9].*") || !q.matches("[0-9 .,+\\-*/^%()x×÷]+")
                    || !q.matches(".*[+\\-*/^%x×÷].*")) {
                return null;
            }
            try {
                Calc c = new Calc(q);
                double v = c.sum();
                if (c.i != c.s.length() || Double.isNaN(v) || Double.isInfinite(v)) {
                    return null;
                }
                return v;
            } catch (RuntimeException e) {
                return null;
            }
        }

        static String format(double v) {
            if (v == Math.rint(v) && Math.abs(v) < 1e15) {
                return String.valueOf((long) v);
            }
            return String.valueOf(Math.round(v * 1e8) / 1e8);
        }

        private double sum() {
            double v = prod();
            while (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
                char op = s.charAt(i++);
                double r = prod();
                v = op == '+' ? v + r : v - r;
            }
            return v;
        }

        private double prod() {
            double v = pow();
            while (i < s.length() && (s.charAt(i) == '*' || s.charAt(i) == '/' || s.charAt(i) == '%')) {
                char op = s.charAt(i++);
                if (op == '%' && (i >= s.length() || "+-*/)".indexOf(s.charAt(i)) >= 0)) {
                    v = v / 100.0;
                    continue;
                }
                double r = pow();
                v = op == '*' ? v * r : op == '/' ? v / r : v % r;
            }
            return v;
        }

        private double pow() {
            double v = unary();
            if (i < s.length() && s.charAt(i) == '^') {
                i++;
                v = Math.pow(v, pow());
            }
            return v;
        }

        private double unary() {
            if (i < s.length() && s.charAt(i) == '-') {
                i++;
                return -unary();
            }
            if (i < s.length() && s.charAt(i) == '(') {
                i++;
                double v = sum();
                if (i < s.length() && s.charAt(i) == ')') {
                    i++;
                }
                return v;
            }
            int st = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) {
                i++;
            }
            return Double.parseDouble(s.substring(st, i));
        }
    }

    // ================================================================== DRIVE

    /** A car dashboard: a fuel gauge for the battery, a clock gauge, six big buttons and music keys. */
    static final class Drive extends AltHome {
        private final Gauge fuel;
        private final Gauge clockG;
        private final TextView time;
        private final TextView sub;

        Drive(NovaActivity host) {
            super(host);
            setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xFF15181E, 0xFF07080B}));
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), dp(42), dp(14), dp(14));
            LinearLayout gauges = new LinearLayout(host);
            gauges.setGravity(Gravity.CENTER_VERTICAL);
            fuel = new Gauge(host, true);
            clockG = new Gauge(host, false);
            gauges.addView(fuel, lp(0, dp(150), 1f));
            LinearLayout mid = new LinearLayout(host);
            mid.setOrientation(LinearLayout.VERTICAL);
            mid.setGravity(Gravity.CENTER);
            time = text(clock(), 30f, 0xFFFFFFFF);
            time.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            mid.addView(time);
            sub = text("", 10f, 0xFF8A93A6);
            mid.addView(sub);
            gauges.addView(mid, lp(dp(96), -2));
            gauges.addView(clockG, lp(0, dp(150), 1f));
            col.addView(gauges, lp(-1, -2));

            List<AppEntry> apps = appsFor(6);
            LinearLayout grid = new LinearLayout(host);
            grid.setOrientation(LinearLayout.VERTICAL);
            grid.setPadding(0, dp(14), 0, dp(10));
            for (int r = 0; r < 2; r++) {
                LinearLayout row = new LinearLayout(host);
                for (int c = 0; c < 3; c++) {
                    int i = r * 3 + c;
                    LinearLayout.LayoutParams p = lp(0, -1, 1f);
                    p.setMargins(dp(5), dp(5), dp(5), dp(5));
                    row.addView(i < apps.size() ? bigButton(apps.get(i)) : new View(host), p);
                }
                grid.addView(row, lp(-1, 0, 1f));
            }
            col.addView(grid, lp(-1, 0, 1f));

            LinearLayout media = new LinearLayout(host);
            media.setGravity(Gravity.CENTER_VERTICAL);
            media.setBackground(Theme.rounded(0xFF1C2028, 24f, host));
            media.setPadding(dp(8), dp(6), dp(8), dp(6));
            media.addView(key("APPS", 12f, () -> host.showDrawer()), lp(0, dp(56), 1f));
            media.addView(key("⏮", 20f, () -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PREVIOUS)), lp(0, dp(56), 1f));
            media.addView(key("⏯", 24f, () -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)), lp(0, dp(56), 1f));
            media.addView(key("⏭", 20f, () -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_NEXT)), lp(0, dp(56), 1f));
            media.addView(key("BUS", 12f, () -> BusScreen.open(host)), lp(0, dp(56), 1f));
            media.addView(key("⚙", 18f, () -> host.showSettings()), lp(0, dp(56), 1f));
            col.addView(media, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private View bigButton(final AppEntry e) {
            LinearLayout b = new LinearLayout(host);
            b.setOrientation(LinearLayout.VERTICAL);
            b.setGravity(Gravity.CENTER);
            b.setBackground(Theme.rounded(0xFF1C2028, 22f, host));
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            b.addView(iv, lp(dp(54), dp(54)));
            TextView t = text(e.label, 12f, 0xFFE6E9F0);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setPadding(dp(6), dp(8), dp(6), 0);
            b.addView(t);
            b.setOnClickListener(v -> host.launch(e));
            b.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            press(b);
            return b;
        }

        private View key(String s, float sp, final Runnable r) {
            TextView t = text(s, sp, 0xFFE6E9F0);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                host.buzz(8);
                r.run();
            });
            press(t);
            return t;
        }

        @Override
        void tick() {
            time.setText(clock());
            sub.setText(new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()));
            fuel.setValue(battery() / 100f);
            Calendar c = Calendar.getInstance();
            clockG.setValue(((c.get(Calendar.HOUR) * 60 + c.get(Calendar.MINUTE)) % 720) / 720f);
            clockG.setMinute(c.get(Calendar.MINUTE) / 60f);
        }

        /** A round dashboard dial. Fuel shows E to F, the clock dial 12 to 12 with a long minute needle. */
        static final class Gauge extends View {
            private final boolean isFuel;
            private float value;
            private float minute;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF arc = new RectF();

            Gauge(Context c, boolean fuel) {
                super(c);
                isFuel = fuel;
                p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            }

            void setValue(float v) {
                value = v;
                invalidate();
            }

            void setMinute(float m) {
                minute = m;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f + 6 * d;
                float r = Math.min(getWidth(), getHeight()) / 2f - 8 * d;
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF0B0D12);
                c.drawCircle(cx, cy, r + 4 * d, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2 * d);
                p.setColor(0xFF2C3240);
                c.drawCircle(cx, cy, r + 4 * d, p);
                float start = 135f;
                float sweep = 270f;
                arc.set(cx - r + 8 * d, cy - r + 8 * d, cx + r - 8 * d, cy + r - 8 * d);
                p.setStrokeWidth(5 * d);
                p.setColor(0xFF232838);
                c.drawArc(arc, start, sweep, false, p);
                boolean low = isFuel && value < 0.2f;
                p.setColor(low ? 0xFFE9574F : Theme.ACCENT);
                c.drawArc(arc, start, sweep * Math.max(0f, Math.min(1f, value)), false, p);
                // ticks
                p.setStrokeWidth(1.5f * d);
                int ticks = isFuel ? 8 : 12;
                for (int i = 0; i <= ticks; i++) {
                    double a = Math.toRadians(start + sweep * i / ticks);
                    float r1 = r - 16 * d;
                    float r2 = r - (i % (isFuel ? 4 : 3) == 0 ? 26 : 21) * d;
                    p.setColor(0xFF9AA3B5);
                    c.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                            cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, p);
                }
                p.setStyle(Paint.Style.FILL);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(11 * d);
                p.setColor(0xFF9AA3B5);
                if (isFuel) {
                    drawAt(c, "E", cx, cy, r - 38 * d, start);
                    drawAt(c, "½", cx, cy, r - 38 * d, start + sweep / 2);
                    drawAt(c, "F", cx, cy, r - 38 * d, start + sweep);
                    p.setColor(low ? 0xFFE9574F : 0xFF6E778A);
                    c.drawText("⛽ " + Math.round(value * 100) + "%", cx, cy + r * 0.55f, p);
                } else {
                    drawAt(c, "12", cx, cy, r - 38 * d, start);
                    drawAt(c, "6", cx, cy, r - 38 * d, start + sweep / 2);
                    drawAt(c, "12", cx, cy, r - 38 * d, start + sweep);
                    p.setColor(0xFF6E778A);
                    c.drawText("TIME", cx, cy + r * 0.55f, p);
                }
                // needles
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                if (!isFuel) {
                    double am = Math.toRadians(-90 + 360 * minute);
                    p.setStrokeWidth(2 * d);
                    p.setColor(0xFF9AA3B5);
                    c.drawLine(cx, cy, cx + (float) Math.cos(am) * (r - 30 * d), cy + (float) Math.sin(am) * (r - 30 * d), p);
                }
                double a = Math.toRadians(start + sweep * Math.max(0f, Math.min(1f, value)));
                p.setStrokeWidth(3.5f * d);
                p.setColor(0xFFFF4A3D);
                c.drawLine(cx, cy, cx + (float) Math.cos(a) * (r - 18 * d), cy + (float) Math.sin(a) * (r - 18 * d), p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF2C3240);
                c.drawCircle(cx, cy, 7 * d, p);
            }

            private void drawAt(Canvas c, String s, float cx, float cy, float r, float deg) {
                double a = Math.toRadians(deg);
                c.drawText(s, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r + 4 * p.getTextSize() / 11f, p);
            }
        }
    }

    // ================================================================== CORKBOARD

    /** A cork board: sticky notes with the time and your notes, and your apps as polaroids held by pins. */
    static final class Corkboard extends AltHome {
        private final TextView time;
        private static final int[] PINS = {0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFFDD835, 0xFF8E24AA};

        Corkboard(NovaActivity host) {
            super(host);
            setBackground(new Cork());
            Typeface hand = Typeface.create("casual", Typeface.NORMAL);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(46), dp(16), dp(20));
            LinearLayout notes = new LinearLayout(host);
            notes.setClipChildren(false);
            LinearLayout sticky = note(0xFFFFF176, -3f);
            time = text(clock(), 40f, 0xFF3A3A3A);
            time.setTypeface(Typeface.create("casual", Typeface.BOLD));
            sticky.addView(time);
            TextView d = text(date(), 12f, 0xFF4A4A4A);
            d.setTypeface(hand);
            sticky.addView(d);
            sticky.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            notes.addView(pin(sticky, 0), lp(0, -2, 1.2f));
            LinearLayout memo = note(0xFFFFAFCC, 4f);
            TextView mt = text("notes ✎", 18f, 0xFF3A3A3A);
            mt.setTypeface(Typeface.create("casual", Typeface.BOLD));
            memo.addView(mt);
            TextView ms = text(greeting() + " :)", 11f, 0xFF4A4A4A);
            ms.setTypeface(hand);
            memo.addView(ms);
            memo.setOnClickListener(v -> host.showNotes());
            LinearLayout.LayoutParams mp = lp(0, -2, 1f);
            mp.leftMargin = dp(14);
            notes.addView(pin(memo, 1), mp);
            col.addView(notes, lp(-1, -2));

            LinearLayout two = new LinearLayout(host);
            two.setClipChildren(false);
            two.setPadding(0, dp(18), 0, 0);
            LinearLayout left = new LinearLayout(host);
            left.setOrientation(LinearLayout.VERTICAL);
            left.setClipChildren(false);
            LinearLayout right = new LinearLayout(host);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setClipChildren(false);
            right.setPadding(0, dp(46), 0, 0);
            List<AppEntry> apps = appsFor(14);
            for (int i = 0; i < apps.size(); i++) {
                LinearLayout.LayoutParams pp = lp(-1, -2);
                pp.setMargins(dp(8), dp(4), dp(8), dp(18));
                (i % 2 == 0 ? left : right).addView(polaroid(apps.get(i), i, hand), pp);
            }
            two.addView(left, lp(0, -2, 1f));
            two.addView(right, lp(0, -2, 1f));
            col.addView(two, lp(-1, -2));

            LinearLayout card = new LinearLayout(host);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(0xFFFDFDF6);
            card.setPadding(dp(14), dp(10), dp(14), dp(12));
            card.setRotation(-1.5f);
            card.setElevation(dp(4));
            View red = new View(host);
            red.setBackgroundColor(0xFFE57373);
            card.addView(red, lp(-1, dp(1)));
            LinearLayout links = new LinearLayout(host);
            String[] n = {"all apps", "widgets", "terminal", "settings"};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showTerminal(),
                () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 14f, 0xFF2B4C9A);
                t.setTypeface(hand);
                t.setPadding(0, dp(10), 0, dp(4));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                links.addView(t, lp(0, -2, 1f));
            }
            card.addView(links, lp(-1, -2));
            LinearLayout.LayoutParams cp = lp(-1, -2);
            cp.topMargin = dp(6);
            col.addView(card, cp);

            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.setClipChildren(false);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
        }

        private LinearLayout note(int color, float rot) {
            LinearLayout n = new LinearLayout(host);
            n.setOrientation(LinearLayout.VERTICAL);
            n.setBackgroundColor(color);
            n.setPadding(dp(14), dp(18), dp(14), dp(16));
            n.setRotation(rot);
            n.setElevation(dp(5));
            return n;
        }

        /** Puts a coloured push pin on top of a view. */
        private View pin(View v, int k) {
            FrameLayout f = new FrameLayout(host);
            f.setClipChildren(false);
            FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-1, -2);
            vp.topMargin = dp(8);
            f.addView(v, vp);
            View pin = new View(host);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[] {HomeKit.darker(PINS[k % PINS.length], 1.0f) | 0xFF000000, HomeKit.darker(PINS[k % PINS.length], 0.6f)});
            g.setShape(GradientDrawable.OVAL);
            pin.setBackground(g);
            pin.setElevation(dp(9));
            f.addView(pin, new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP | Gravity.CENTER_HORIZONTAL));
            return f;
        }

        private View polaroid(final AppEntry e, int i, Typeface hand) {
            LinearLayout p = new LinearLayout(host);
            p.setOrientation(LinearLayout.VERTICAL);
            p.setBackgroundColor(0xFFFBFBF8);
            p.setPadding(dp(8), dp(8), dp(8), dp(4));
            p.setElevation(dp(4));
            int h = Math.abs(e.pkg.hashCode());
            p.setRotation((h % 15) - 7);
            FrameLayout photo = new FrameLayout(host);
            int c = HomeKit.color(host, e);
            photo.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[] {c, HomeKit.darker(c, 0.55f)}));
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            photo.addView(iv, new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER));
            p.addView(photo, lp(-1, dp(110)));
            TextView t = text(e.label, 13f, 0xFF333333);
            t.setTypeface(hand);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setPadding(0, dp(6), 0, dp(6));
            p.addView(t, lp(-1, -2));
            p.setOnClickListener(v -> host.launch(e));
            p.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            press(p);
            return pin(p, i);
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        /** Cork: a warm brown with lots of small light and dark specks. */
        static final class Cork extends Drawable {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private Bitmap cache;

            @Override
            public void draw(Canvas c) {
                android.graphics.Rect b = getBounds();
                if (b.width() <= 0 || b.height() <= 0) {
                    return;
                }
                if (cache == null || cache.getWidth() != b.width() || cache.getHeight() != b.height()) {
                    cache = Bitmap.createBitmap(b.width(), b.height(), Bitmap.Config.RGB_565);
                    Canvas k = new Canvas(cache);
                    k.drawColor(0xFFB98A5A);
                    Random r = new Random(7);
                    int n = b.width() * b.height() / 220;
                    for (int i = 0; i < n; i++) {
                        p.setColor(r.nextBoolean() ? 0x30000000 : 0x26FFE0B0);
                        k.drawCircle(r.nextFloat() * b.width(), r.nextFloat() * b.height(), 0.8f + r.nextFloat() * 2.2f, p);
                    }
                }
                c.drawBitmap(cache, b.left, b.top, null);
            }

            @Override
            public void setAlpha(int a) {
            }

            @Override
            public void setColorFilter(ColorFilter cf) {
            }

            @Override
            public int getOpacity() {
                return PixelFormat.OPAQUE;
            }
        }
    }
}
