package app.novaos;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Extra home screens, part one. Each one is a real layout of its own, not a colour theme:
 * METRO (live tiles), GLYPH (dot-matrix clock, black and white), DESKTOP (an old PC desktop with a Start menu),
 * POCKET (a handheld game console with a D-pad), KEYPAD (an old mobile phone with number keys),
 * HONEYCOMB (a watch-style honeycomb of round apps) and STACK (a pile of cards you swipe through).
 */
final class HomesA {
    private HomesA() {
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static ColorFilter grey() {
        ColorMatrix m = new ColorMatrix();
        m.setSaturation(0f);
        return new ColorMatrixColorFilter(m);
    }

    /** Lays children out on a grid of square cells; each child takes w by h cells and fills the first free spot. */
    static final class CellGrid extends ViewGroup {
        private final int cols;
        private final int gap;
        private final List<int[]> sizes = new ArrayList<>();
        private final List<int[]> spots = new ArrayList<>();
        private int cell;

        CellGrid(android.content.Context c, int cols, int gap) {
            super(c);
            this.cols = cols;
            this.gap = gap;
            setClipChildren(false);
        }

        void put(View v, int w, int h) {
            sizes.add(new int[] {Math.min(cols, w), h});
            addView(v);
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int width = MeasureSpec.getSize(ws);
            cell = (width - gap * (cols - 1)) / cols;
            spots.clear();
            List<boolean[]> used = new ArrayList<>();
            int rows = 0;
            for (int i = 0; i < getChildCount(); i++) {
                int[] s = sizes.get(i);
                int fr = -1;
                int fc = -1;
                for (int r = 0; fr < 0; r++) {
                    for (int c = 0; c + s[0] <= cols && fr < 0; c++) {
                        boolean free = true;
                        for (int y = r; y < r + s[1] && free; y++) {
                            while (used.size() <= y) {
                                used.add(new boolean[cols]);
                            }
                            for (int x = c; x < c + s[0]; x++) {
                                if (used.get(y)[x]) {
                                    free = false;
                                    break;
                                }
                            }
                        }
                        if (free) {
                            fr = r;
                            fc = c;
                        }
                    }
                }
                for (int y = fr; y < fr + s[1]; y++) {
                    for (int x = fc; x < fc + s[0]; x++) {
                        used.get(y)[x] = true;
                    }
                }
                spots.add(new int[] {fc, fr});
                rows = Math.max(rows, fr + s[1]);
                View v = getChildAt(i);
                v.measure(MeasureSpec.makeMeasureSpec(s[0] * cell + (s[0] - 1) * gap, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(s[1] * cell + (s[1] - 1) * gap, MeasureSpec.EXACTLY));
            }
            setMeasuredDimension(width, rows == 0 ? 0 : rows * cell + (rows - 1) * gap);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            for (int i = 0; i < getChildCount() && i < spots.size(); i++) {
                View v = getChildAt(i);
                int x = spots.get(i)[0] * (cell + gap);
                int y = spots.get(i)[1] * (cell + gap);
                v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
            }
        }
    }

    /** A little press effect: the view tilts down a bit while you hold it. */
    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start();
            } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                x.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            }
            return false;
        });
    }

    // ================================================================== METRO

    /** Flat square live tiles in a grid: some big, some small. The clock tile flips, the recent tile cycles. */
    static final class Metro extends AltHome {
        private final TextView time;
        private final TextView dateL;
        private final TextView greet;
        private final TextView batt;
        private final View faceA;
        private final View faceB;
        private final FrameLayout clockTile;
        private final ImageView recentIcon;
        private final TextView recentName;
        private final List<AppEntry> recent;
        private int beat;
        private int recentIdx;

        Metro(NovaActivity host) {
            super(host);
            final int tileC = Theme.ACCENT;
            final int liveC = HomeKit.darker(Theme.ACCENT, 0.72f);
            final int fg = HomeKit.onColor(tileC);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12), dp(44), dp(12), dp(16));
            TextView head = text("start", 34f, Theme.TEXT);
            head.setTypeface(Theme.LIGHT);
            head.setGravity(Gravity.START);
            head.setPadding(dp(2), 0, 0, dp(12));
            col.addView(head);

            CellGrid grid = new CellGrid(host, 4, dp(6));
            // the clock: a wide live tile that flips between two faces
            clockTile = new FrameLayout(host);
            clockTile.setBackgroundColor(liveC);
            LinearLayout a = new LinearLayout(host);
            a.setOrientation(LinearLayout.VERTICAL);
            a.setPadding(dp(12), dp(8), dp(12), dp(10));
            time = text(clock(), 46f, HomeKit.onColor(liveC));
            time.setTypeface(Theme.LIGHT);
            time.setGravity(Gravity.START);
            a.addView(time);
            dateL = text(date().toLowerCase(Locale.getDefault()), 13f, HomeKit.onColor(liveC));
            dateL.setGravity(Gravity.START);
            a.addView(dateL);
            faceA = a;
            LinearLayout b = new LinearLayout(host);
            b.setOrientation(LinearLayout.VERTICAL);
            b.setGravity(Gravity.CENTER_VERTICAL);
            b.setPadding(dp(12), dp(8), dp(12), dp(10));
            greet = text(greeting(), 20f, HomeKit.onColor(liveC));
            greet.setTypeface(Theme.LIGHT);
            greet.setGravity(Gravity.START);
            b.addView(greet);
            TextView sub = text("swipe down for the control panel", 11f, HomeKit.onColor(liveC));
            sub.setGravity(Gravity.START);
            sub.setAlpha(0.8f);
            b.addView(sub);
            faceB = b;
            faceB.setVisibility(INVISIBLE);
            clockTile.addView(faceA, new FrameLayout.LayoutParams(-1, -1));
            clockTile.addView(faceB, new FrameLayout.LayoutParams(-1, -1));
            clockTile.addView(label("clock", HomeKit.onColor(liveC)), labelLp());
            clockTile.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            press(clockTile);
            grid.put(clockTile, 4, 2);

            // battery: a medium live tile
            FrameLayout bt = new FrameLayout(host);
            bt.setBackgroundColor(liveC);
            batt = text(battery() + "", 40f, HomeKit.onColor(liveC));
            batt.setTypeface(Theme.LIGHT);
            bt.addView(batt, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            bt.addView(label("battery %", HomeKit.onColor(liveC)), labelLp());
            bt.setOnClickListener(v -> host.showShade());
            press(bt);

            // recent: cycles through the apps you opened last
            recent = HomeKit.recent(host, 6);
            FrameLayout rt = new FrameLayout(host);
            rt.setBackgroundColor(liveC);
            recentIcon = new ImageView(host);
            rt.addView(recentIcon, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER));
            recentName = label("recent", HomeKit.onColor(liveC));
            rt.addView(recentName, labelLp());
            rt.setOnClickListener(v -> {
                if (!recent.isEmpty()) {
                    host.launch(recent.get(recentIdx % recent.size()));
                } else {
                    host.showDrawer();
                }
            });
            press(rt);
            showRecent();

            List<AppEntry> apps = appsFor(18);
            for (int i = 0; i < apps.size(); i++) {
                if (i == 2) {
                    grid.put(bt, 2, 2);
                }
                if (i == 7) {
                    grid.put(rt, 2, 2);
                }
                boolean big = i % 6 == 0;
                grid.put(appSquare(apps.get(i), tileC, fg, big), big ? 2 : 1, big ? 2 : 1);
            }
            if (apps.size() <= 2) {
                grid.put(bt, 2, 2);
            }
            if (apps.size() <= 7) {
                grid.put(rt, 2, 2);
            }
            col.addView(grid, lp(-1, -2));

            LinearLayout links = new LinearLayout(host);
            links.setGravity(Gravity.CENTER_VERTICAL);
            links.setPadding(0, dp(18), 0, 0);
            String[] n = {"widgets", "profile", "terminal", "settings"};
            Runnable[] r = {() -> host.showOverlay(new WidgetsSheet(host)), () -> host.showOverlay(new ProfileScreen(host)),
                () -> host.showTerminal(), () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 13f, Theme.DIM);
                t.setPadding(dp(4), dp(10), dp(12), dp(10));
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                links.addView(t);
            }
            links.addView(new View(host), lp(0, 1, 1f));
            TextView arrow = text("\u2192", 22f, Theme.TEXT);
            arrow.setGravity(Gravity.CENTER);
            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setStroke(dp(2), Theme.TEXT);
            arrow.setBackground(ring);
            arrow.setOnClickListener(v -> host.showDrawer());
            links.addView(arrow, lp(dp(46), dp(46)));
            col.addView(links, lp(-1, -2));

            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
        }

        private TextView label(String s, int color) {
            TextView t = new TextView(host);
            t.setText(s);
            t.setTextSize(11f);
            t.setTextColor(color);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            return t;
        }

        private FrameLayout.LayoutParams labelLp() {
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM | Gravity.START);
            p.setMargins(dp(8), 0, dp(8), dp(6));
            return p;
        }

        private View appSquare(final AppEntry e, int bg, int fg, boolean big) {
            FrameLayout f = new FrameLayout(host);
            f.setBackgroundColor(bg);
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            int s = big ? dp(54) : dp(30);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(s, s, Gravity.CENTER);
            if (!big) {
                ip.bottomMargin = dp(6);
            }
            f.addView(iv, ip);
            if (big) {
                f.addView(label(e.label.toLowerCase(Locale.getDefault()), fg), labelLp());
            }
            f.setOnClickListener(v -> host.launch(e));
            f.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            press(f);
            return f;
        }

        private void showRecent() {
            if (recent.isEmpty()) {
                recentName.setText("recent \u00B7 open something");
                recentIcon.setImageDrawable(null);
                return;
            }
            AppEntry e = recent.get(recentIdx % recent.size());
            recentIcon.setImageDrawable(Theme.tint(host, e.icon));
            recentName.setText("recent \u00B7 " + e.label.toLowerCase(Locale.getDefault()));
        }

        private void flip() {
            clockTile.animate().rotationX(90f).setDuration(220).withEndAction(() -> {
                boolean a = faceA.getVisibility() == VISIBLE;
                faceA.setVisibility(a ? INVISIBLE : VISIBLE);
                faceB.setVisibility(a ? VISIBLE : INVISIBLE);
                greet.setText(greeting());
                clockTile.setRotationX(-90f);
                clockTile.animate().rotationX(0f).setDuration(220).start();
            }).start();
        }

        @Override
        void tick() {
            time.setText(clock());
            dateL.setText(date().toLowerCase(Locale.getDefault()));
            batt.setText(battery() + "");
            beat++;
            if (beat % 7 == 0) {
                flip();
            }
            if (beat % 4 == 0 && recent.size() > 1) {
                recentIdx++;
                recentIcon.animate().translationY(-dp(40)).alpha(0f).setDuration(200).withEndAction(() -> {
                    showRecent();
                    recentIcon.setTranslationY(dp(40));
                    recentIcon.animate().translationY(0f).alpha(1f).setDuration(240).start();
                }).start();
            }
        }
    }

    // ================================================================== GLYPH

    /** Black and white, a big dot-matrix clock, round dot widgets, grey round icons and one red dot. */
    static final class Glyph extends AltHome {
        static final int RED = 0xFFD71921;
        private final DotClock dots;
        private final TextView day;
        private final DotRing battRing;
        private final DotRing dayRing;

        Glyph(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF000000);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(22), dp(56), dp(22), dp(16));
            dots = new DotClock(host);
            col.addView(dots, lp(-1, -2));
            day = text("", 12f, 0xFFBDBDBD);
            day.setLetterSpacing(0.35f);
            day.setGravity(Gravity.START);
            day.setPadding(0, dp(14), 0, dp(22));
            col.addView(day);

            LinearLayout rings = new LinearLayout(host);
            battRing = new DotRing(host, 40, "BATTERY");
            dayRing = new DotRing(host, 24, "DAY");
            LinearLayout.LayoutParams r1 = lp(0, dp(150), 1f);
            r1.rightMargin = dp(8);
            rings.addView(battRing, r1);
            LinearLayout.LayoutParams r2 = lp(0, dp(150), 1f);
            r2.leftMargin = dp(8);
            rings.addView(dayRing, r2);
            battRing.setOnClickListener(v -> host.showShade());
            dayRing.setOnClickListener(v -> host.showOverlay(new WidgetsSheet(host)));
            col.addView(rings, lp(-1, -2));

            LinearLayout grid = new LinearLayout(host);
            grid.setOrientation(LinearLayout.VERTICAL);
            grid.setPadding(0, dp(22), 0, 0);
            List<AppEntry> apps = appsFor(12);
            LinearLayout row = null;
            for (int i = 0; i < apps.size(); i++) {
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    grid.addView(row, lp(-1, -2));
                }
                row.addView(app(apps.get(i)), lp(0, -2, 1f));
            }
            if (row != null) {
                for (int k = apps.size() % 4; k != 0 && k < 4; k++) {
                    row.addView(new View(host), lp(0, 1, 1f));
                }
            }
            col.addView(grid, lp(-1, -2));

            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(sv, lp(-1, 0, 1f));
            LinearLayout pills = new LinearLayout(host);
            pills.setPadding(dp(16), dp(6), dp(16), dp(18));
            String[] n = {"APPS", "WIDGETS", "SETTINGS"};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                TextView t = text(n[i], 11f, 0xFFFFFFFF);
                t.setLetterSpacing(0.2f);
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, dp(12), 0, dp(12));
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(dp(24));
                g.setStroke(dp(1), i == 0 ? RED : 0xFF5A5A5A);
                t.setBackground(g);
                final Runnable go = r[i];
                t.setOnClickListener(v -> go.run());
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(4), 0, dp(4), 0);
                pills.addView(t, p);
            }
            all.addView(pills, lp(-1, -2));
            addView(all, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private View app(final AppEntry e) {
            LinearLayout c = new LinearLayout(host);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setPadding(0, dp(8), 0, dp(8));
            FrameLayout disc = new FrameLayout(host);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xFF1C1C1C);
            disc.setBackground(g);
            ImageView iv = new ImageView(host);
            // a private copy, so the grey filter never leaks into the icon other screens use
            Drawable.ConstantState cs = e.icon == null ? null : e.icon.getConstantState();
            iv.setImageDrawable(cs != null ? cs.newDrawable().mutate() : Theme.tint(host, e.icon));
            iv.setColorFilter(grey());
            disc.addView(iv, new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
            c.addView(disc, lp(dp(58), dp(58)));
            TextView t = text(e.label.toUpperCase(Locale.getDefault()), 8.5f, 0xFFBDBDBD);
            t.setLetterSpacing(0.12f);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setPadding(dp(2), dp(6), dp(2), 0);
            c.addView(t, lp(-1, -2));
            c.setOnClickListener(v -> host.launch(e));
            c.setOnLongClickListener(v -> {
                host.appMenu(e);
                return true;
            });
            press(c);
            return c;
        }

        @Override
        void tick() {
            dots.invalidate();
            day.setText(new java.text.SimpleDateFormat("EEE  d  MMM", Locale.ENGLISH).format(new java.util.Date())
                    .toUpperCase(Locale.ENGLISH));
            int b = battery();
            battRing.set(Math.round(b * 40 / 100f), b + "%");
            Calendar c = Calendar.getInstance();
            int h = c.get(Calendar.HOUR_OF_DAY);
            dayRing.set(h, Math.round((h * 60 + c.get(Calendar.MINUTE)) / 14.4f) + "%");
        }

        /** HH:MM in big 5 by 7 dots. Unlit dots stay faintly visible, the colon is red and blinks. */
        static final class DotClock extends View {
            private static final String[][] DIGITS = {
                {"01110", "10001", "10011", "10101", "11001", "10001", "01110"},
                {"00100", "01100", "00100", "00100", "00100", "00100", "01110"},
                {"01110", "10001", "00001", "00010", "00100", "01000", "11111"},
                {"11110", "00001", "00001", "01110", "00001", "00001", "11110"},
                {"00010", "00110", "01010", "10010", "11111", "00010", "00010"},
                {"11111", "10000", "11110", "00001", "00001", "10001", "01110"},
                {"00110", "01000", "10000", "11110", "10001", "10001", "01110"},
                {"11111", "00001", "00010", "00100", "01000", "01000", "01000"},
                {"01110", "10001", "10001", "01110", "10001", "10001", "01110"},
                {"01110", "10001", "10001", "01111", "00001", "00010", "01100"}};
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            DotClock(android.content.Context c) {
                super(c);
            }

            @Override
            protected void onMeasure(int ws, int hs) {
                int w = MeasureSpec.getSize(ws);
                setMeasuredDimension(w, Math.round(w / 27f * 7));
            }

            @Override
            protected void onDraw(Canvas c) {
                float pitch = getWidth() / 27f;
                float r = pitch * 0.36f;
                Calendar now = Calendar.getInstance();
                int h = now.get(Calendar.HOUR_OF_DAY);
                if (Prefs.getBool("clock_12h", false)) {
                    h = h % 12 == 0 ? 12 : h % 12;
                }
                int m = now.get(Calendar.MINUTE);
                int[] ds = {h / 10, h % 10, m / 10, m % 10};
                float x0 = 0;
                for (int i = 0; i < 4; i++) {
                    if (i == 2) {
                        boolean on = now.get(Calendar.SECOND) % 2 == 0;
                        p.setColor(on ? RED : 0xFF1A1A1A);
                        c.drawCircle(x0 + pitch * 0.5f, pitch * 2.5f, r, p);
                        c.drawCircle(x0 + pitch * 0.5f, pitch * 4.5f, r, p);
                        x0 += pitch * 2;
                    }
                    String[] g = DIGITS[ds[i]];
                    for (int y = 0; y < 7; y++) {
                        for (int x = 0; x < 5; x++) {
                            boolean on = g[y].charAt(x) == '1';
                            p.setColor(on ? 0xFFFFFFFF : 0xFF161616);
                            c.drawCircle(x0 + pitch * (x + 0.5f), pitch * (y + 0.5f), r, p);
                        }
                    }
                    x0 += pitch * 6;
                }
            }
        }

        /** A ring of dots in a dark round tile, n of them lit, a value in the middle. */
        static final class DotRing extends View {
            private final int total;
            private final String name;
            private int lit;
            private String value = "";
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF box = new RectF();

            DotRing(android.content.Context c, int total, String name) {
                super(c);
                this.total = total;
                this.name = name;
                p.setTypeface(Theme.MONO);
                setClickable(true);
            }

            void set(int lit, String value) {
                this.lit = lit;
                this.value = value;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float w = getWidth();
                float h = getHeight();
                p.setColor(0xFF111111);
                box.set(0, 0, w, h);
                c.drawRoundRect(box, 26 * d, 26 * d, p);
                float cx = w / 2;
                float cy = h / 2 - 4 * d;
                float rr = Math.min(w, h) / 2 - 22 * d;
                for (int i = 0; i < total; i++) {
                    double a = -Math.PI / 2 + i * 2 * Math.PI / total;
                    boolean last = i == lit - 1;
                    p.setColor(i < lit ? (last ? RED : 0xFFFFFFFF) : 0xFF2A2A2A);
                    c.drawCircle(cx + (float) Math.cos(a) * rr, cy + (float) Math.sin(a) * rr, 2.6f * d, p);
                }
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(22 * d);
                c.drawText(value, cx, cy + 8 * d, p);
                p.setColor(0xFF8A8A8A);
                p.setTextSize(9 * d);
                c.drawText(name, cx, h - 10 * d, p);
            }
        }
    }

    // ================================================================== DESKTOP

    /** An old PC desktop: icons on teal, a draggable welcome window and a taskbar with a Start menu and a clock. */
    static final class Desktop extends AltHome {
        static final int GREY = 0xFFC0C0C0;
        static final int NAVY = 0xFF000080;
        private final TextView tray;
        private FrameLayout startMenu;
        private View selected;
        private int tip;
        private static final String[] TIPS = {
            "To open an app, tap its icon on the desktop.",
            "Hold an icon to pin, hide or uninstall it.",
            "The Start button holds all your apps and settings.",
            "Swipe down from the top for the control panel.",
            "Change the home screen any time in Settings > UI STYLE."};

        Desktop(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF008080);
            FrameLayout desk = new FrameLayout(host);
            int perCol = Math.max(3, (int) ((getResources().getDisplayMetrics().heightPixels - dp(130)) / dp(84)));
            LinearLayout cols = new LinearLayout(host);
            cols.setPadding(dp(6), dp(40), dp(6), 0);
            List<Object[]> icons = new ArrayList<>();
            icons.add(new Object[] {"My Computer", (Runnable) () -> host.showSettings(), null});
            icons.add(new Object[] {"Notepad", (Runnable) () -> host.showNotes(), null});
            icons.add(new Object[] {"MS-NOVA Prompt", (Runnable) () -> host.showTerminal(), null});
            for (AppEntry e : appsFor(Math.max(8, perCol * 4 - 3))) {
                icons.add(new Object[] {e.label, null, e});
            }
            LinearLayout c = null;
            for (int i = 0; i < icons.size(); i++) {
                if (i % perCol == 0) {
                    c = new LinearLayout(host);
                    c.setOrientation(LinearLayout.VERTICAL);
                    cols.addView(c, lp(dp(84), -2));
                }
                c.addView(icon(icons.get(i)), lp(-1, dp(84)));
            }
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(host);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(cols);
            desk.addView(hs, new FrameLayout.LayoutParams(-1, -1));
            desk.addView(window(), new FrameLayout.LayoutParams(dp(270), -2, Gravity.CENTER));

            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(desk, lp(-1, 0, 1f));
            LinearLayout bar = new LinearLayout(host);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setBackground(new Bevel(GREY, true, true));
            bar.setPadding(dp(4), dp(5), dp(4), dp(5));
            LinearLayout start = new LinearLayout(host);
            start.setGravity(Gravity.CENTER_VERTICAL);
            start.setBackground(new Bevel(GREY, true, false));
            start.setPadding(dp(6), dp(4), dp(10), dp(4));
            start.addView(new Flag(host), lp(dp(20), dp(18)));
            TextView st = text("Start", 14f, 0xFF000000);
            st.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            st.setPadding(dp(6), 0, 0, 0);
            start.addView(st);
            start.setOnClickListener(v -> toggleStart());
            bar.addView(start, lp(-2, dp(40)));
            bar.addView(new View(host), lp(0, 1, 1f));
            tray = text("", 12f, 0xFF000000);
            tray.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            tray.setBackground(new Bevel(GREY, false, false));
            tray.setPadding(dp(10), dp(8), dp(10), dp(8));
            tray.setOnClickListener(v -> host.showShade());
            bar.addView(tray, lp(-2, dp(40)));
            all.addView(bar, lp(-1, -2));
            addView(all, new FrameLayout.LayoutParams(-1, -1));
            desk.setOnClickListener(v -> closeStart());
            tick();
        }

        private View icon(Object[] o) {
            final AppEntry e = (AppEntry) o[2];
            final Runnable r = (Runnable) o[1];
            LinearLayout c = new LinearLayout(host);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setPadding(dp(2), dp(6), dp(2), 0);
            View img;
            if (e != null) {
                ImageView iv = new ImageView(host);
                iv.setImageDrawable(Theme.tint(host, e.icon));
                img = iv;
            } else {
                img = new SysIcon(host, (String) o[0]);
            }
            c.addView(img, lp(dp(38), dp(38)));
            final TextView t = text((String) o[0], 11f, 0xFFFFFFFF);
            t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            t.setMaxLines(2);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            t.setShadowLayer(1f, 1f, 1f, 0xFF000000);
            t.setPadding(dp(2), dp(1), dp(2), dp(1));
            LinearLayout.LayoutParams tp = lp(-2, -2);
            tp.topMargin = dp(4);
            c.addView(t, tp);
            c.setOnClickListener(v -> {
                if (selected != null) {
                    selected.setBackgroundColor(0);
                }
                t.setBackgroundColor(NAVY);
                selected = t;
                closeStart();
                v.postDelayed(() -> {
                    if (e != null) {
                        host.launch(e);
                    } else {
                        r.run();
                    }
                }, 120);
            });
            if (e != null) {
                c.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
            }
            return c;
        }

        private View window() {
            final LinearLayout w = new LinearLayout(host);
            w.setOrientation(LinearLayout.VERTICAL);
            w.setBackground(new Bevel(GREY, true, false));
            w.setPadding(dp(3), dp(3), dp(3), dp(3));
            LinearLayout title = new LinearLayout(host);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[] {NAVY, 0xFF1084D0}));
            title.setPadding(dp(6), dp(3), dp(3), dp(3));
            TextView tt = text("Welcome to NOVA", 12f, 0xFFFFFFFF);
            tt.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            title.addView(tt, lp(0, -2, 1f));
            TextView x = text("\u2715", 11f, 0xFF000000);
            x.setGravity(Gravity.CENTER);
            x.setBackground(new Bevel(GREY, true, false));
            x.setOnClickListener(v -> w.setVisibility(GONE));
            title.addView(x, lp(dp(22), dp(20)));
            w.addView(title, lp(-1, -2));
            final TextView body = text("", 12f, 0xFF000000);
            body.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            body.setGravity(Gravity.START);
            body.setPadding(dp(10), dp(12), dp(10), dp(12));
            body.setText(greeting() + "!\n\nDid you know...\n" + TIPS[0]);
            w.addView(body, lp(-1, -2));
            LinearLayout btns = new LinearLayout(host);
            btns.setGravity(Gravity.END);
            btns.setPadding(0, 0, dp(6), dp(6));
            TextView next = button("Next Tip");
            next.setOnClickListener(v -> {
                tip = (tip + 1) % TIPS.length;
                body.setText(greeting() + "!\n\nDid you know...\n" + TIPS[tip]);
            });
            TextView close = button("Close");
            close.setOnClickListener(v -> w.setVisibility(GONE));
            btns.addView(next);
            LinearLayout.LayoutParams cp = lp(-2, -2);
            cp.leftMargin = dp(6);
            btns.addView(close, cp);
            w.addView(btns, lp(-1, -2));
            // drag the window by its title bar
            final float[] start = new float[4];
            title.setOnTouchListener((v, ev) -> {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        start[0] = ev.getRawX();
                        start[1] = ev.getRawY();
                        start[2] = w.getTranslationX();
                        start[3] = w.getTranslationY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        w.setTranslationX(start[2] + ev.getRawX() - start[0]);
                        w.setTranslationY(start[3] + ev.getRawY() - start[1]);
                        return true;
                    default:
                        return true;
                }
            });
            return w;
        }

        private TextView button(String s) {
            TextView t = text(s, 12f, 0xFF000000);
            t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            t.setGravity(Gravity.CENTER);
            t.setBackground(new Bevel(GREY, true, false));
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            return t;
        }

        private void toggleStart() {
            if (startMenu != null) {
                closeStart();
                return;
            }
            startMenu = new FrameLayout(host);
            LinearLayout box = new LinearLayout(host);
            box.setBackground(new Bevel(GREY, true, false));
            box.setPadding(dp(3), dp(3), dp(3), dp(3));
            TextView band = new TextView(host) {
                @Override
                protected void onDraw(Canvas c) {
                    c.save();
                    c.rotate(-90f);
                    c.translate(-getHeight(), 0);
                    Paint p = getPaint();
                    p.setColor(0xFFFFFFFF);
                    p.setTextSize(20 * getResources().getDisplayMetrics().density);
                    p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                    c.drawText("NOVA", 12 * getResources().getDisplayMetrics().density,
                            getWidth() * 0.72f, p);
                    c.restore();
                }
            };
            band.setBackgroundColor(0xFF808080);
            box.addView(band, lp(dp(28), -1));
            LinearLayout items = new LinearLayout(host);
            items.setOrientation(LinearLayout.VERTICAL);
            String[] n = {"Programs  \u25B8", "Documents", "Widgets", "Profile", "Settings", "Run...", "-",
                "Shut Down..."};
            Runnable[] r = {() -> host.showDrawer(), () -> host.showNotes(),
                () -> host.showOverlay(new WidgetsSheet(host)), () -> host.showOverlay(new ProfileScreen(host)),
                () -> host.showSettings(), () -> host.showTerminal(), null, () -> host.forceLock()};
            for (int i = 0; i < n.length; i++) {
                if (r[i] == null) {
                    View sep = new View(host);
                    sep.setBackground(new Bevel(GREY, false, false));
                    LinearLayout.LayoutParams sp = lp(-1, dp(3));
                    sp.setMargins(dp(4), dp(3), dp(4), dp(3));
                    items.addView(sep, sp);
                    continue;
                }
                final TextView t = text(n[i], 14f, 0xFF000000);
                t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                t.setPadding(dp(14), dp(11), dp(30), dp(11));
                final Runnable go = r[i];
                t.setOnTouchListener((v, ev) -> {
                    if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        t.setBackgroundColor(NAVY);
                        t.setTextColor(0xFFFFFFFF);
                    } else if (ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                        t.setBackgroundColor(0);
                        t.setTextColor(0xFF000000);
                    }
                    return false;
                });
                t.setOnClickListener(v -> {
                    closeStart();
                    go.run();
                });
                items.addView(t, lp(-1, -2));
            }
            box.addView(items, lp(-2, -2));
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
            bp.setMargins(dp(2), 0, 0, dp(52));
            startMenu.addView(box, bp);
            startMenu.setOnClickListener(v -> closeStart());
            addView(startMenu, new FrameLayout.LayoutParams(-1, -1));
        }

        private void closeStart() {
            if (startMenu != null) {
                removeView(startMenu);
                startMenu = null;
            }
        }

        @Override
        void tick() {
            tray.setText("\u25AE " + battery() + "%    " + clock());
        }

        /** The raised or sunken grey edge of old PC buttons and windows. */
        static final class Bevel extends Drawable {
            private final int face;
            private final boolean raised;
            private final boolean topOnly;
            private final Paint p = new Paint();

            Bevel(int face, boolean raised, boolean topOnly) {
                this.face = face;
                this.raised = raised;
                this.topOnly = topOnly;
            }

            @Override
            public void draw(Canvas c) {
                android.graphics.Rect b = getBounds();
                float d = Math.max(1f, Prefs.appContext().getResources().getDisplayMetrics().density);
                p.setColor(face);
                c.drawRect(b, p);
                int light = raised ? 0xFFFFFFFF : 0xFF000000;
                int dark = raised ? 0xFF000000 : 0xFFFFFFFF;
                int mid = 0xFF808080;
                if (topOnly) {
                    p.setColor(0xFFFFFFFF);
                    c.drawRect(b.left, b.top, b.right, b.top + d, p);
                    return;
                }
                p.setColor(light);
                c.drawRect(b.left, b.top, b.right, b.top + d, p);
                c.drawRect(b.left, b.top, b.left + d, b.bottom, p);
                p.setColor(dark);
                c.drawRect(b.left, b.bottom - d, b.right, b.bottom, p);
                c.drawRect(b.right - d, b.top, b.right, b.bottom, p);
                p.setColor(mid);
                if (raised) {
                    c.drawRect(b.left + d, b.bottom - 2 * d, b.right - d, b.bottom - d, p);
                    c.drawRect(b.right - 2 * d, b.top + d, b.right - d, b.bottom - d, p);
                } else {
                    c.drawRect(b.left + d, b.top + d, b.right - d, b.top + 2 * d, p);
                    c.drawRect(b.left + d, b.top + d, b.left + 2 * d, b.bottom - d, p);
                }
            }

            @Override
            public void setAlpha(int a) {
            }

            @Override
            public void setColorFilter(ColorFilter cf) {
            }

            @Override
            public int getOpacity() {
                return PixelFormat.OPAQUE;
            }
        }

        /** A small waving four-colour flag for the Start button. */
        static final class Flag extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Flag(android.content.Context c) {
                super(c);
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth() / 2f - 1;
                float h = getHeight() / 2f - 1;
                int[] col = {0xFFE8392B, 0xFF3BB34A, 0xFF2E6FD8, 0xFFF4C21B};
                for (int i = 0; i < 4; i++) {
                    float x = (i % 2) * (w + 2);
                    float y = (i / 2) * (h + 2);
                    p.setColor(col[i]);
                    Path path = new Path();
                    path.moveTo(x, y + 2);
                    path.quadTo(x + w / 2, y - 1, x + w, y + 2);
                    path.lineTo(x + w, y + h);
                    path.quadTo(x + w / 2, y + h - 3, x, y + h);
                    path.close();
                    c.drawPath(path, p);
                }
            }
        }

        /** Simple pictures for the built-in desktop icons. */
        static final class SysIcon extends View {
            private final String kind;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            SysIcon(android.content.Context c, String kind) {
                super(c);
                this.kind = kind;
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                if (kind.startsWith("My")) {
                    p.setColor(0xFFC0C0C0);
                    c.drawRect(w * 0.1f, h * 0.05f, w * 0.9f, h * 0.65f, p);
                    p.setColor(0xFF000080);
                    c.drawRect(w * 0.18f, h * 0.12f, w * 0.82f, h * 0.55f, p);
                    p.setColor(0xFF00A0A0);
                    c.drawRect(w * 0.22f, h * 0.16f, w * 0.78f, h * 0.51f, p);
                    p.setColor(0xFFC0C0C0);
                    c.drawRect(w * 0.05f, h * 0.72f, w * 0.95f, h * 0.95f, p);
                    p.setColor(0xFF808080);
                    c.drawRect(w * 0.6f, h * 0.8f, w * 0.85f, h * 0.86f, p);
                } else if (kind.startsWith("Note")) {
                    p.setColor(0xFFFFFFFF);
                    c.drawRect(w * 0.18f, h * 0.06f, w * 0.82f, h * 0.94f, p);
                    p.setColor(0xFF2E6FD8);
                    for (int i = 1; i < 6; i++) {
                        c.drawRect(w * 0.26f, h * (0.12f + i * 0.13f), w * 0.74f, h * (0.12f + i * 0.13f) + 2, p);
                    }
                    p.setColor(0xFF808080);
                    c.drawRect(w * 0.18f, h * 0.06f, w * 0.82f, h * 0.14f, p);
                } else {
                    p.setColor(0xFF000000);
                    c.drawRect(w * 0.06f, h * 0.14f, w * 0.94f, h * 0.86f, p);
                    p.setColor(0xFFC0C0C0);
                    c.drawRect(w * 0.06f, h * 0.14f, w * 0.94f, h * 0.26f, p);
                    p.setColor(0xFFFFFFFF);
                    p.setTextSize(h * 0.3f);
                    p.setTypeface(Typeface.MONOSPACE);
                    c.drawText("C:\\>", w * 0.12f, h * 0.62f, p);
                }
            }
        }
    }

    // ================================================================== POCKET

    /** A handheld game console: green screen with a list of apps, D-pad to choose, A to open, B for all apps. */
    static final class Pocket extends AltHome {
        static final int G0 = 0xFF0F380F;
        static final int G1 = 0xFF306230;
        static final int G3 = 0xFF9BBC0F;
        private final List<AppEntry> apps;
        private final LinearLayout list;
        private final TextView head;
        private int sel;
        private static final int ROWS = 7;

        Pocket(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFFC9C6BD);
            apps = appsFor(40);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(18), dp(44), dp(18), dp(18));

            LinearLayout bezel = new LinearLayout(host);
            bezel.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable bz = new GradientDrawable();
            bz.setColor(0xFF6B6A80);
            float s = dp(10);
            float big = dp(46);
            bz.setCornerRadii(new float[] {s, s, s, s, big, big, s, s});
            bezel.setBackground(bz);
            bezel.setPadding(dp(16), dp(8), dp(16), dp(22));
            TextView top = text("\u2014\u2014  DOT MATRIX WITH STEREO SOUND  \u2014\u2014", 7.5f, 0xFFD8D6E8);
            top.setLetterSpacing(0.05f);
            bezel.addView(top, lp(-1, -2));
            LinearLayout inner = new LinearLayout(host);
            inner.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout led = new LinearLayout(host);
            led.setOrientation(LinearLayout.VERTICAL);
            led.setGravity(Gravity.CENTER_HORIZONTAL);
            View dot = new View(host);
            GradientDrawable lg = new GradientDrawable();
            lg.setShape(GradientDrawable.OVAL);
            lg.setColor(0xFFFF2A2A);
            dot.setBackground(lg);
            led.addView(dot, lp(dp(8), dp(8)));
            TextView bl = text("BATTERY", 6f, 0xFFD8D6E8);
            bl.setPadding(0, dp(3), 0, 0);
            led.addView(bl);
            inner.addView(led, lp(dp(40), -2));
            LinearLayout screen = new LinearLayout(host);
            screen.setOrientation(LinearLayout.VERTICAL);
            screen.setBackgroundColor(G3);
            screen.setPadding(dp(8), dp(8), dp(8), dp(8));
            head = mono("", G0);
            head.setGravity(Gravity.START);
            screen.addView(head, lp(-1, -2));
            View rule = new View(host);
            rule.setBackgroundColor(G0);
            LinearLayout.LayoutParams rp = lp(-1, dp(2));
            rp.setMargins(0, dp(4), 0, dp(4));
            screen.addView(rule, rp);
            list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            screen.addView(list, lp(-1, -2));
            TextView foot = mono("A:OPEN  B:ALL  START:SETUP", G1);
            foot.setTextSize(9f);
            foot.setPadding(0, dp(6), 0, 0);
            screen.addView(foot, lp(-1, -2));
            inner.addView(screen, lp(0, -2, 1f));
            inner.addView(new View(host), lp(dp(24), 1));
            bezel.addView(inner, lp(-1, -2));
            col.addView(bezel, lp(-1, -2));

            TextView brand = text("NOVA BOY", 20f, 0xFF2B2A7E);
            brand.setTypeface(Typeface.create("sans-serif", Typeface.BOLD_ITALIC));
            brand.setGravity(Gravity.START);
            brand.setPadding(dp(4), dp(10), 0, 0);
            col.addView(brand);

            col.addView(new View(host), lp(-1, 0, 1f));
            LinearLayout controls = new LinearLayout(host);
            controls.setGravity(Gravity.CENTER_VERTICAL);
            DPad pad = new DPad(host, dir -> {
                host.buzz(6);
                if (dir == 0) {
                    move(-1);
                } else if (dir == 2) {
                    move(1);
                } else if (dir == 1) {
                    move(ROWS);
                } else {
                    move(-ROWS);
                }
            });
            controls.addView(pad, lp(dp(130), dp(130)));
            controls.addView(new View(host), lp(0, 1, 1f));
            FrameLayout ab = new FrameLayout(host);
            View b = round("B", () -> host.showDrawer());
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM | Gravity.START);
            ab.addView(b, bp);
            View a = round("A", this::open);
            a.setOnLongClickListener(v -> {
                if (!apps.isEmpty()) {
                    host.appMenu(apps.get(sel));
                }
                return true;
            });
            FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP | Gravity.END);
            ab.addView(a, ap);
            ab.setRotation(-22f);
            controls.addView(ab, lp(dp(140), dp(110)));
            col.addView(controls, lp(-1, -2));

            LinearLayout ss = new LinearLayout(host);
            ss.setGravity(Gravity.CENTER);
            ss.setPadding(0, dp(18), 0, dp(10));
            ss.addView(pill("SELECT", () -> host.showOverlay(new WidgetsSheet(host))));
            LinearLayout.LayoutParams sp = lp(-2, -2);
            sp.leftMargin = dp(22);
            ss.addView(pill("START", () -> host.showSettings()), sp);
            col.addView(ss, lp(-1, -2));
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            render();
        }

        private TextView mono(String s, int c) {
            TextView t = text(s, 13f, c);
            t.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            return t;
        }

        private View round(String s, final Runnable r) {
            LinearLayout c = new LinearLayout(host);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xFF9A2257);
            c.setBackground(g);
            c.setElevation(dp(4));
            TextView t = text(s, 15f, 0xFFF3D6E2);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            c.addView(t);
            c.setOnClickListener(v -> {
                host.buzz(10);
                r.run();
            });
            press(c);
            return c;
        }

        private View pill(String s, final Runnable r) {
            LinearLayout c = new LinearLayout(host);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            View p = new View(host);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(0xFF8C8A93);
            p.setBackground(g);
            p.setRotation(-22f);
            c.addView(p, lp(dp(46), dp(12)));
            TextView t = text(s, 9f, 0xFF2B2A7E);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            t.setPadding(0, dp(6), 0, 0);
            c.addView(t);
            c.setOnClickListener(v -> {
                host.buzz(8);
                r.run();
            });
            return c;
        }

        private void move(int d) {
            if (apps.isEmpty()) {
                return;
            }
            sel = Math.max(0, Math.min(apps.size() - 1, sel + d));
            render();
        }

        private void open() {
            if (!apps.isEmpty()) {
                host.launch(apps.get(sel));
            }
        }

        private void render() {
            list.removeAllViews();
            if (apps.isEmpty()) {
                list.addView(mono("NO APPS. PRESS B.", G0));
                return;
            }
            int first = Math.max(0, Math.min(sel - ROWS / 2, apps.size() - ROWS));
            for (int i = first; i < Math.min(apps.size(), first + ROWS); i++) {
                final int idx = i;
                boolean on = i == sel;
                TextView t = mono((on ? "\u25B6 " : "  ") + apps.get(i).label.toUpperCase(Locale.getDefault()), on ? G3 : G0);
                t.setBackgroundColor(on ? G0 : 0);
                t.setPadding(dp(2), dp(3), dp(2), dp(3));
                t.setOnClickListener(v -> {
                    if (idx == sel) {
                        open();
                    } else {
                        sel = idx;
                        render();
                    }
                });
                list.addView(t, lp(-1, -2));
            }
        }

        @Override
        void tick() {
            head.setText("NOVA   " + clock() + "   \u2665" + battery());
        }

        /** A cross-shaped direction pad. Hold a direction to repeat. Directions: 0 up, 1 right, 2 down, 3 left. */
        static final class DPad extends View {
            private final java.util.function.IntConsumer out;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private int dir = -1;
            private final Runnable repeat = new Runnable() {
                @Override
                public void run() {
                    if (dir >= 0) {
                        out.accept(dir);
                        postDelayed(this, 110);
                    }
                }
            };

            DPad(android.content.Context c, java.util.function.IntConsumer out) {
                super(c);
                this.out = out;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: {
                        float dx = e.getX() - getWidth() / 2f;
                        float dy = e.getY() - getHeight() / 2f;
                        dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
                        out.accept(dir);
                        postDelayed(repeat, 380);
                        invalidate();
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dir = -1;
                        removeCallbacks(repeat);
                        invalidate();
                        return true;
                    default:
                        return true;
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                float t = w / 3f;
                p.setColor(0xFF222222);
                RectF r = new RectF(t, 0, 2 * t, h);
                c.drawRoundRect(r, t * 0.15f, t * 0.15f, p);
                r.set(0, t, w, 2 * t);
                c.drawRoundRect(r, t * 0.15f, t * 0.15f, p);
                p.setColor(0xFF3A3A3A);
                c.drawCircle(w / 2, h / 2, t * 0.32f, p);
                p.setColor(0xFF555555);
                float a = t * 0.2f;
                float[][] tri = {{w / 2, t * 0.3f, 0}, {w - t * 0.3f, h / 2, 1}, {w / 2, h - t * 0.3f, 2},
                    {t * 0.3f, h / 2, 3}};
                for (float[] k : tri) {
                    p.setColor((int) k[2] == dir ? 0xFF8A8A8A : 0xFF4A4A4A);
                    Path path = new Path();
                    switch ((int) k[2]) {
                        case 0:
                            path.moveTo(k[0], k[1]);
                            path.lineTo(k[0] - a, k[1] + a);
                            path.lineTo(k[0] + a, k[1] + a);
                            break;
                        case 1:
                            path.moveTo(k[0], k[1]);
                            path.lineTo(k[0] - a, k[1] - a);
                            path.lineTo(k[0] - a, k[1] + a);
                            break;
                        case 2:
                            path.moveTo(k[0], k[1]);
                            path.lineTo(k[0] - a, k[1] - a);
                            path.lineTo(k[0] + a, k[1] - a);
                            break;
                        default:
                            path.moveTo(k[0], k[1]);
                            path.lineTo(k[0] + a, k[1] - a);
                            path.lineTo(k[0] + a, k[1] + a);
                            break;
                    }
                    path.close();
                    c.drawPath(path, p);
                }
            }
        }
    }

    // ================================================================== KEYPAD

    /** An old mobile phone: a small green screen with the time and bars, and number keys that open your apps. */
    static final class Keypad extends AltHome {
        static final int LCD = 0xFF9DC08B;
        static final int INK = 0xFF1E2A1A;
        private final LcdView lcd;
        private final List<AppEntry> apps;
        private int sel = -1;

        Keypad(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF1B2638);
            apps = appsFor(10);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.setPadding(dp(22), dp(42), dp(22), dp(16));
            View ear = new View(host);
            GradientDrawable eg = new GradientDrawable();
            eg.setCornerRadius(dp(4));
            eg.setColor(0xFF0E1522);
            ear.setBackground(eg);
            col.addView(ear, lp(dp(70), dp(7)));
            TextView brand = text("N O V A", 13f, 0xFFB8C4D6);
            brand.setPadding(0, dp(8), 0, dp(8));
            col.addView(brand);
            FrameLayout frame = new FrameLayout(host);
            GradientDrawable fg = new GradientDrawable();
            fg.setCornerRadius(dp(18));
            fg.setColor(0xFF0E1522);
            frame.setBackground(fg);
            frame.setPadding(dp(10), dp(10), dp(10), dp(10));
            lcd = new LcdView(host);
            frame.addView(lcd, new FrameLayout.LayoutParams(-1, dp(190)));
            col.addView(frame, lp(-1, -2));

            LinearLayout nav = new LinearLayout(host);
            nav.setGravity(Gravity.CENTER_VERTICAL);
            nav.setPadding(0, dp(14), 0, dp(10));
            TextView c = key("C", 0xFF3B4A63, 0xFFE8EDF5);
            c.setOnClickListener(v -> {
                host.buzz(8);
                if (sel >= 0) {
                    sel = -1;
                    lcd.invalidate();
                } else {
                    host.showSettings();
                }
            });
            nav.addView(c, lp(dp(56), dp(44)));
            nav.addView(new View(host), lp(0, 1, 1f));
            TextView menu = key("Menu", 0xFFD7DEE8, 0xFF1B2638);
            menu.setTextSize(15f);
            menu.setOnClickListener(v -> {
                host.buzz(8);
                if (sel >= 0 && sel < apps.size()) {
                    host.launch(apps.get(sel));
                } else {
                    host.showDrawer();
                }
            });
            nav.addView(menu, lp(dp(120), dp(52)));
            nav.addView(new View(host), lp(0, 1, 1f));
            LinearLayout rocker = new LinearLayout(host);
            rocker.setOrientation(LinearLayout.VERTICAL);
            TextView up = key("\u25B2", 0xFF3B4A63, 0xFFE8EDF5);
            up.setOnClickListener(v -> step(-1));
            TextView dn = key("\u25BC", 0xFF3B4A63, 0xFFE8EDF5);
            dn.setOnClickListener(v -> step(1));
            rocker.addView(up, lp(dp(56), dp(30)));
            LinearLayout.LayoutParams dp2 = lp(dp(56), dp(30));
            dp2.topMargin = dp(4);
            rocker.addView(dn, dp2);
            nav.addView(rocker);
            col.addView(nav, lp(-1, -2));

            String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
            String[] sub = {"\u221E", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz", "apps", "\u2423", "setup"};
            LinearLayout pad = new LinearLayout(host);
            pad.setOrientation(LinearLayout.VERTICAL);
            for (int r = 0; r < 4; r++) {
                LinearLayout row = new LinearLayout(host);
                for (int k = 0; k < 3; k++) {
                    int i = r * 3 + k;
                    int slot = i < 9 ? i : (i == 10 ? 9 : -1);
                    LinearLayout.LayoutParams p = lp(0, dp(58), 1f);
                    p.setMargins(dp(5), dp(4), dp(5), dp(4));
                    row.addView(numKey(keys[i], sub[i], slot, i), p);
                }
                pad.addView(row, lp(-1, -2));
            }
            col.addView(pad, lp(-1, -2));
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.setFillViewport(true);
            sv.addView(col);
            addView(sv, new FrameLayout.LayoutParams(-1, -1));
        }

        private TextView key(String s, int bg, int fg) {
            TextView t = text(s, 13f, fg);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            t.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(22));
            g.setColor(bg);
            t.setBackground(g);
            press(t);
            return t;
        }

        private View numKey(String k, String sub, final int slot, final int index) {
            LinearLayout c = new LinearLayout(host);
            c.setGravity(Gravity.CENTER_VERTICAL);
            c.setPadding(dp(10), 0, dp(6), 0);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadii(new float[] {dp(26), dp(26), dp(26), dp(26), dp(10), dp(10), dp(10), dp(10)});
            g.setColor(0xFFD7DEE8);
            c.setBackground(g);
            LinearLayout txt = new LinearLayout(host);
            txt.setOrientation(LinearLayout.VERTICAL);
            TextView n = text(k, 20f, 0xFF1B2638);
            n.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            n.setGravity(Gravity.START);
            txt.addView(n);
            final AppEntry e = slot >= 0 && slot < apps.size() ? apps.get(slot) : null;
            TextView s = text(e != null ? e.label : sub, 8f, 0xFF4A5870);
            s.setSingleLine(true);
            s.setEllipsize(android.text.TextUtils.TruncateAt.END);
            s.setGravity(Gravity.START);
            txt.addView(s);
            c.addView(txt, lp(0, -2, 1f));
            if (e != null) {
                ImageView iv = new ImageView(host);
                iv.setImageDrawable(Theme.tint(host, e.icon));
                c.addView(iv, lp(dp(24), dp(24)));
            }
            c.setOnClickListener(v -> {
                host.buzz(8);
                if (e != null) {
                    host.launch(e);
                } else if (index == 9) {
                    host.showDrawer();
                } else if (index == 11) {
                    host.showSettings();
                }
            });
            if (e != null) {
                c.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
            }
            press(c);
            return c;
        }

        private void step(int d) {
            host.buzz(6);
            if (apps.isEmpty()) {
                return;
            }
            sel = sel < 0 ? (d > 0 ? 0 : apps.size() - 1) : (sel + d + apps.size()) % apps.size();
            lcd.invalidate();
        }

        @Override
        void tick() {
            lcd.invalidate();
        }

        /** The little screen: signal and battery bars, NOVA, the time, and the soft key. */
        final class LcdView extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final RectF r = new RectF();

            LcdView(android.content.Context c) {
                super(c);
                p.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float w = getWidth();
                float h = getHeight();
                p.setColor(LCD);
                r.set(0, 0, w, h);
                c.drawRoundRect(r, 8 * d, 8 * d, p);
                p.setColor(INK);
                // signal bars on the left, battery bars on the right
                for (int i = 0; i < 4; i++) {
                    float bw = (4 + i * 3) * d;
                    float y = h - 30 * d - i * 12 * d;
                    c.drawRect(8 * d, y, 8 * d + bw, y + 8 * d, p);
                    int lit = Math.round(battery() / 25f);
                    if (i < Math.max(1, lit)) {
                        c.drawRect(w - 8 * d - bw, y, w - 8 * d, y + 8 * d, p);
                    }
                }
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(13 * d);
                c.drawText("NOVA", w / 2, 22 * d, p);
                if (sel >= 0 && sel < apps.size()) {
                    p.setTextSize(11 * d);
                    c.drawText((sel + 1 > 9 ? 0 : sel + 1) + "  " + cut(apps.get(sel).label, 16), w / 2, h / 2 - 6 * d, p);
                    p.setTextSize(30 * d);
                    c.drawText(clock(), w / 2, h / 2 + 30 * d, p);
                    p.setTextSize(13 * d);
                    c.drawText("Open", w / 2, h - 10 * d, p);
                } else {
                    p.setTextSize(44 * d);
                    c.drawText(clock(), w / 2, h / 2 + 14 * d, p);
                    p.setTextSize(11 * d);
                    c.drawText(new java.text.SimpleDateFormat("EEE d.MM.yyyy", Locale.getDefault())
                            .format(new java.util.Date()), w / 2, h / 2 + 36 * d, p);
                    p.setTextSize(13 * d);
                    c.drawText("Menu", w / 2, h - 10 * d, p);
                }
            }

            private String cut(String s, int n) {
                return s.length() > n ? s.substring(0, n) : s;
            }
        }
    }

    // ================================================================== HONEYCOMB

    /** A watch-style honeycomb of round apps. Drag it around; apps near the edge shrink. Your pinned apps sit in the middle. */
    static final class Honeycomb extends AltHome {
        private final TextView time;

        Honeycomb(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF000000);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(new Hive(host, appsFor(61)), lp(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            time = text(clock(), 15f, 0xFFFF9F0A);
            time.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
            tp.setMargins(0, dp(40), dp(24), 0);
            addView(time, tp);
        }

        @Override
        void tick() {
            time.setText(clock());
        }

        final class Hive extends View {
            private final List<AppEntry> apps;
            private final List<float[]> pos = new ArrayList<>();
            private final OverScroller scroller;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Path clip = new Path();
            private final RectF dst = new RectF();
            private VelocityTracker vt;
            private float ox;
            private float oy;
            private float lx;
            private float ly;
            private float downX;
            private float downY;
            private boolean moved;
            private final float radius;
            private float extent;
            private final int slop;

            Hive(android.content.Context c, List<AppEntry> apps) {
                super(c);
                this.apps = apps;
                scroller = new OverScroller(c);
                radius = dp(31);
                slop = ViewConfiguration.get(c).getScaledTouchSlop();
                // hexagon rings, spiralling out from the middle
                float step = radius * 2.25f;
                int[][] dirs = {{1, 0}, {1, -1}, {0, -1}, {-1, 0}, {-1, 1}, {0, 1}};
                pos.add(new float[] {0, 0});
                for (int ring = 1; pos.size() < apps.size(); ring++) {
                    int q = -ring;
                    int r = ring;
                    for (int side = 0; side < 6 && pos.size() < apps.size(); side++) {
                        for (int k = 0; k < ring && pos.size() < apps.size(); k++) {
                            float x = step * (q + r / 2f);
                            float y = step * 0.866f * r;
                            pos.add(new float[] {x, y});
                            extent = Math.max(extent, (float) Math.hypot(x, y));
                            q += dirs[side][0];
                            r += dirs[side][1];
                        }
                    }
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (vt == null) {
                    vt = VelocityTracker.obtain();
                }
                vt.addMovement(e);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        scroller.forceFinished(true);
                        lx = downX = e.getX();
                        ly = downY = e.getY();
                        moved = false;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.hypot(e.getX() - downX, e.getY() - downY) > slop) {
                            moved = true;
                        }
                        if (moved) {
                            ox += e.getX() - lx;
                            oy += e.getY() - ly;
                            clamp();
                            invalidate();
                        }
                        lx = e.getX();
                        ly = e.getY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            tap(e.getX(), e.getY(), false);
                        } else {
                            vt.computeCurrentVelocity(1000);
                            int lim = Math.round(extent);
                            scroller.fling(Math.round(ox), Math.round(oy), Math.round(vt.getXVelocity()),
                                    Math.round(vt.getYVelocity()), -lim, lim, -lim, lim);
                            postInvalidateOnAnimation();
                        }
                        vt.recycle();
                        vt = null;
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        if (vt != null) {
                            vt.recycle();
                            vt = null;
                        }
                        return true;
                    default:
                        return true;
                }
            }

            private void clamp() {
                ox = Math.max(-extent, Math.min(extent, ox));
                oy = Math.max(-extent, Math.min(extent, oy));
            }

            private void tap(float x, float y, boolean longPress) {
                float cx = getWidth() / 2f + ox;
                float cy = getHeight() / 2f + oy;
                for (int i = 0; i < apps.size(); i++) {
                    float px = cx + pos.get(i)[0];
                    float py = cy + pos.get(i)[1];
                    float s = scaleAt(px, py);
                    if (Math.hypot(x - px, y - py) < radius * s) {
                        host.launch(apps.get(i));
                        return;
                    }
                }
            }

            private float scaleAt(float px, float py) {
                float edge = Math.min(Math.min(px, getWidth() - px), Math.min(py, getHeight() - py));
                return Math.max(0.15f, Math.min(1f, (edge + radius * 0.2f) / (radius * 2.6f)));
            }

            @Override
            public void computeScroll() {
                if (scroller.computeScrollOffset()) {
                    ox = scroller.getCurrX();
                    oy = scroller.getCurrY();
                    invalidate();
                }
            }

            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f + ox;
                float cy = getHeight() / 2f + oy;
                for (int i = 0; i < apps.size(); i++) {
                    float px = cx + pos.get(i)[0];
                    float py = cy + pos.get(i)[1];
                    if (px < -radius || py < -radius || px > getWidth() + radius || py > getHeight() + radius) {
                        continue;
                    }
                    float s = scaleAt(px, py);
                    float r = radius * s;
                    AppEntry e = apps.get(i);
                    p.setColor(HomeKit.color(host, e));
                    c.drawCircle(px, py, r, p);
                    Bitmap b = HomeKit.icon(host, e, Math.round(radius * 1.3f));
                    c.save();
                    clip.reset();
                    clip.addCircle(px, py, r, Path.Direction.CW);
                    c.clipPath(clip);
                    float ir = r * 0.72f;
                    dst.set(px - ir, py - ir, px + ir, py + ir);
                    c.drawBitmap(b, null, dst, p);
                    c.restore();
                }
            }
        }
    }

    // ================================================================== STACK

    /** One big card per app on a pile. Swipe it left for the next one, right for the one before, tap to open. */
    static final class Stack extends AltHome {
        private final List<AppEntry> apps;
        private final FrameLayout[] cards = new FrameLayout[3];
        private final FrameLayout pile;
        private final TextView time;
        private final TextView count;
        private int idx;

        Stack(NovaActivity host) {
            super(host);
            apps = appsFor(30);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(20), dp(46), dp(20), 0);
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.BOTTOM);
            time = text(clock(), 40f, Theme.TEXT);
            time.setTypeface(Theme.LIGHT);
            head.addView(time);
            head.addView(new View(host), lp(0, 1, 1f));
            count = text("", 12f, Theme.DIM);
            count.setPadding(0, 0, 0, dp(8));
            head.addView(count);
            col.addView(head, lp(-1, -2));
            TextView d = text(date(), 13f, Theme.DIM);
            d.setGravity(Gravity.START);
            col.addView(d);

            pile = new FrameLayout(host);
            pile.setClipChildren(false);
            for (int i = 2; i >= 0; i--) {
                cards[i] = new FrameLayout(host);
                cards[i].setElevation(dp(6 - i * 2));
                FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, -1);
                p.setMargins(dp(6), dp(24), dp(6), dp(36));
                pile.addView(cards[i], p);
            }
            col.addView(pile, lp(-1, 0, 1f));

            LinearLayout btns = new LinearLayout(host);
            btns.setGravity(Gravity.CENTER);
            btns.setPadding(0, 0, 0, dp(6));
            btns.addView(roundBtn("\u21BA", () -> fly(1)));
            btns.addView(roundBtn("\u2715", () -> fly(-1)));
            btns.addView(roundBtn("\u2665", () -> {
                if (!apps.isEmpty()) {
                    host.launch(apps.get(idx));
                }
            }));
            col.addView(btns, lp(-1, -2));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
            setupTouch();
            bindAll();
        }

        private View roundBtn(String s, final Runnable r) {
            TextView t = text(s, 20f, Theme.ACCENT);
            t.setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Theme.PANEL);
            t.setBackground(g);
            t.setElevation(dp(3));
            t.setOnClickListener(v -> r.run());
            press(t);
            LinearLayout.LayoutParams p = lp(dp(56), dp(56));
            p.setMargins(dp(12), 0, dp(12), 0);
            t.setLayoutParams(p);
            return t;
        }

        private void bind(FrameLayout card, int i) {
            card.removeAllViews();
            if (apps.isEmpty()) {
                card.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
                return;
            }
            final AppEntry e = apps.get(((i % apps.size()) + apps.size()) % apps.size());
            int c = HomeKit.color(host, e);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[] {c, HomeKit.darker(c, 0.45f)});
            g.setCornerRadius(dp(28));
            card.setBackground(g);
            LinearLayout in = new LinearLayout(host);
            in.setOrientation(LinearLayout.VERTICAL);
            in.setGravity(Gravity.CENTER);
            ImageView iv = new ImageView(host);
            iv.setImageDrawable(Theme.tint(host, e.icon));
            in.addView(iv, lp(dp(110), dp(110)));
            TextView n = text(e.label, 28f, 0xFFFFFFFF);
            n.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            n.setPadding(dp(16), dp(18), dp(16), 0);
            n.setGravity(Gravity.CENTER);
            in.addView(n);
            TextView h = text("tap to open  \u00B7  swipe for the next", 11f, 0xCCFFFFFF);
            h.setPadding(0, dp(8), 0, 0);
            in.addView(h);
            card.addView(in, new FrameLayout.LayoutParams(-1, -1));
        }

        private void bindAll() {
            for (int k = 0; k < 3; k++) {
                bind(cards[k], idx + k);
                place(cards[k], k);
            }
            count.setText(apps.isEmpty() ? "" : (idx + 1) + " / " + apps.size());
        }

        private void place(View v, int depth) {
            v.setTranslationX(0f);
            v.setRotation(0f);
            v.setTranslationY(dp(14) * depth);
            v.setScaleX(1f - depth * 0.05f);
            v.setScaleY(1f - depth * 0.05f);
            v.setAlpha(depth == 2 ? 0.6f : 1f);
        }

        /** Throws the top card out (dir -1 left = next, 1 right = back). */
        private void fly(final int dir) {
            if (apps.size() < 2) {
                return;
            }
            final FrameLayout top = cards[0];
            float w = getWidth() * 1.3f;
            top.animate().translationX(dir * w).rotation(dir * 20f).setDuration(240).withEndAction(() -> {
                idx = ((idx - dir) % apps.size() + apps.size()) % apps.size();
                bindAll();
                // the new top card rises from the second spot
                cards[0].setTranslationY(dp(14));
                cards[0].setScaleX(0.95f);
                cards[0].setScaleY(0.95f);
                cards[0].animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(200).start();
            }).start();
            host.buzz(6);
        }

        private void setupTouch() {
            final float[] st = new float[2];
            final boolean[] drag = {false};
            final boolean[] held = {false};
            final int slop = ViewConfiguration.get(host).getScaledTouchSlop();
            final Runnable hold = () -> {
                held[0] = true;
                host.buzz(20);
                if (!apps.isEmpty()) {
                    host.appMenu(apps.get(idx));
                }
            };
            cards[0].setOnTouchListener((v, e) -> {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        st[0] = e.getRawX();
                        st[1] = e.getRawY();
                        drag[0] = false;
                        held[0] = false;
                        v.postDelayed(hold, 550);
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - st[0];
                        if (!drag[0] && (Math.abs(dx) > slop || Math.abs(e.getRawY() - st[1]) > slop)) {
                            drag[0] = true;
                            v.removeCallbacks(hold);
                        }
                        if (drag[0] && !held[0]) {
                            v.setTranslationX(dx);
                            v.setRotation(dx / Math.max(1, getWidth()) * 18f);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        v.removeCallbacks(hold);
                        float dx = e.getRawX() - st[0];
                        if (held[0]) {
                            return true;
                        }
                        if (!drag[0]) {
                            if (!apps.isEmpty()) {
                                host.launch(apps.get(idx));
                            }
                        } else if (Math.abs(dx) > getWidth() * 0.25f) {
                            fly(dx < 0 ? -1 : 1);
                        } else {
                            v.animate().translationX(0f).rotation(0f).setDuration(180).start();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        v.removeCallbacks(hold);
                        v.animate().translationX(0f).rotation(0f).setDuration(180).start();
                        return true;
                    default:
                        return true;
                }
            });
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }
}
