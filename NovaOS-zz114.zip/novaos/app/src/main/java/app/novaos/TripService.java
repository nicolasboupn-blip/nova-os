package app.novaos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;

/**
 * AUTO-DETECT for the bus map. While it is on, a small notification shows and the phone's position is checked about every
 * 15 seconds (every minute when you have not moved for a while). When you move like a vehicle for a few minutes, the ride
 * is saved and NOVA asks you next time you open it: "Did you ride a bus from A to B?". Nothing leaves the phone except
 * the stop lookups on the public timetable after you say yes. Switch it off in the BUS window or with STOP.
 */
public class TripService extends Service {
    private static final String CHANNEL = "nova_trips";
    private static final String ACTION_STOP = "app.novaos.TRIP_STOP";
    private static volatile boolean running;

    private LocationManager lm;
    private final Detector detector = new Detector();
    private boolean slow;
    private final LocationListener listener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            try {
                BusData.Trip t = detector.feed(l.getLatitude(), l.getLongitude(), l.getTime(), l.getSpeed(), l.hasSpeed());
                if (t != null) {
                    BusData.addPending(t);
                }
                boolean wantSlow = !detector.moving && System.currentTimeMillis() - detector.restSince > 600000;
                if (wantSlow != slow) {
                    request(wantSlow);
                }
            } catch (RuntimeException ignored) {
                // a bad fix is skipped
            }
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, android.os.Bundle extras) {
        }
    };

    static boolean running() {
        return running;
    }

    /** Starts the service (call it while NOVA is on screen). Returns false when it could not start. */
    static boolean start(Context c) {
        try {
            if (c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
            c.startForegroundService(new Intent(c, TripService.class));
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    static void stop(Context c) {
        try {
            c.startService(new Intent(c, TripService.class).setAction(ACTION_STOP));
        } catch (RuntimeException ignored) {
            // not running anyway
        }
    }

    /** Called when NOVA opens: brings the service back if you left AUTO-DETECT on. */
    static void ensure(Context c) {
        if (Prefs.getBool("bus_auto", false) && !running) {
            start(c);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.init(getApplicationContext());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Prefs.putBool("bus_auto", false);
            finish();
            return START_NOT_STICKY;
        }
        try {
            startForegroundNow();
        } catch (RuntimeException e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            request(false);
        }
        return START_STICKY;
    }

    private void request(boolean slowMode) {
        slow = slowMode;
        if (lm == null) {
            return;
        }
        try {
            lm.removeUpdates(listener);
            String prov = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER
                    : LocationManager.NETWORK_PROVIDER;
            lm.requestLocationUpdates(prov, slowMode ? 60000L : 15000L, slowMode ? 60f : 10f, listener,
                    Looper.getMainLooper());
        } catch (SecurityException | IllegalArgumentException e) {
            finish();
        }
    }

    private void finish() {
        running = false;
        try {
            if (lm != null) {
                lm.removeUpdates(listener);
            }
        } catch (RuntimeException ignored) {
            // already gone
        }
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (lm != null) {
                lm.removeUpdates(listener);
            }
        } catch (RuntimeException ignored) {
            // already gone
        }
        super.onDestroy();
    }

    private void startForegroundNow() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Bus auto-detect",
                NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, TripService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_directions)
                .setContentTitle("NOVA bus auto-detect is on")
                .setContentText("Notices bus rides and asks you later. Tap STOP to switch off")
                .addAction(new Notification.Action.Builder(null, "STOP", stop).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } else {
            startForeground(42, n);
        }
    }

    /**
     * Turns a stream of positions into rides. A ride starts when the speed is above 3 m/s (about 11 km/h) twice in a row
     * and ends when it stays under that for 2 minutes. Short, slow or walking-speed movement is thrown away.
     */
    static final class Detector {
        private static final double FAST = 3.0;

        boolean moving;
        long restSince = System.currentTimeMillis();
        private int fast;
        private double alat;
        private double alon;
        private long atime;
        private boolean haveAnchor;
        private double slat;
        private double slon;
        private long stime;
        private double plat;
        private double plon;
        private long ptime;
        private boolean havePrev;
        private double meters;
        private double fastMeters;
        private double flat;
        private double flon;
        private long ftime;

        private static double dist(double la1, double lo1, double la2, double lo2) {
            float[] r = new float[1];
            Location.distanceBetween(la1, lo1, la2, lo2, r);
            return r[0];
        }

        BusData.Trip feed(double lat, double lon, long t, float speed, boolean hasSpeed) {
            double v;
            if (hasSpeed) {
                v = speed;
            } else if (havePrev && t > ptime) {
                v = dist(plat, plon, lat, lon) / ((t - ptime) / 1000.0);
            } else {
                v = 0;
            }
            BusData.Trip done = null;
            if (moving && havePrev && t - ptime > 600000) {
                done = finish(); // the phone slept for 10 minutes: close the ride where it last moved fast
            }
            if (!moving) {
                if (v >= FAST) {
                    fast++;
                } else {
                    fast = 0;
                    alat = lat;
                    alon = lon;
                    atime = t;
                    haveAnchor = true;
                    if (v >= 1.0) {
                        restSince = System.currentTimeMillis();
                    }
                }
                if (fast >= 2 && haveAnchor) {
                    moving = true;
                    slat = alat;
                    slon = alon;
                    stime = atime;
                    meters = 0;
                    fastMeters = 0;
                    flat = lat;
                    flon = lon;
                    ftime = t;
                }
            } else {
                meters += dist(plat, plon, lat, lon);
                if (v >= FAST) {
                    fastMeters = meters;
                    flat = lat;
                    flon = lon;
                    ftime = t;
                } else if (t - ftime >= 120000) {
                    done = finish();
                }
            }
            if (moving) {
                restSince = System.currentTimeMillis();
            }
            plat = lat;
            plon = lon;
            ptime = t;
            havePrev = true;
            return done;
        }

        private BusData.Trip finish() {
            moving = false;
            fast = 0;
            restSince = System.currentTimeMillis();
            long dur = ftime - stime;
            double avg = dur > 0 ? fastMeters / (dur / 1000.0) : 0;
            if (fastMeters < 600 || dur < 240000 || avg < 2.5 || avg > 16) {
                return null;
            }
            BusData.Trip t = new BusData.Trip();
            t.slat = slat;
            t.slon = slon;
            t.elat = flat;
            t.elon = flon;
            t.start = stime;
            t.end = ftime;
            t.meters = (int) fastMeters;
            return t;
        }
    }
}
