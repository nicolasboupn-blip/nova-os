package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.util.Random;

/** Your profile card: name, about text, banner colours or picture, a moving effect, avatar ring and name style. */
final class Profile {
    private Profile() {}

    static final String[] EFFECTS = {"None", "Aurora waves", "Stars", "Rain", "Glitter", "Embers", "Matrix", "Bubbles",
        "Snow"};
    static final String[] RINGS = {"None", "Solid", "Spinning colours", "Glow pulse", "Dashed spin"};
    static final String[] NAME_FX = {"Plain", "Gradient", "Shimmer", "Rainbow"};
    static final String[] BANNER_MODES = {"Gradient", "One colour", "My picture"};

    static final String K_NAME = "pf_name", K_ABOUT = "pf_about", K_C1 = "pf_c1", K_C2 = "pf_c2", K_C3 = "pf_c3",
        K_MODE = "pf_bmode", K_FX = "pf_fx", K_RING = "pf_ring", K_NAMEFX = "pf_namefx", K_ACCENT = "pf_accent",
        K_TAG = "pf_tag", K_SINCE = "pf_since", K_PRON = "pf_pron", K_STEXT = "pf_stext", K_SHOW = "pf_show";

    static String name() {
        String n = Prefs.getString(K_NAME, "").trim();
        if (n.isEmpty()) {
            n = Prefs.userName();
        }
        return n.isEmpty() ? "NOVA user" : n;
    }

    static String pronouns() {
        return Prefs.getString(K_PRON, "");
    }

    /** A status you write yourself. Empty means the active scene is the status. */
    static String statusText() {
        return Prefs.getString(K_STEXT, "");
    }

    /** Badge ids you picked to show, in order. Empty means the best ones. */
    static java.util.List<String> showcase() {
        java.util.List<String> out = new java.util.ArrayList<>();
        String raw = Prefs.getString(K_SHOW, "");
        if (!raw.isEmpty()) {
            for (String id : raw.split(",")) {
                if (!id.isEmpty()) {
                    out.add(id);
                }
            }
        }
        return out;
    }

    static String about() {
        return Prefs.getString(K_ABOUT, "");
    }

    /** A 4 digit number after the name, made once. */
    static String tag() {
        String t = Prefs.getString(K_TAG, "");
        if (t.isEmpty()) {
            t = String.format(java.util.Locale.ROOT, "%04d", new Random().nextInt(10000));
            Prefs.putString(K_TAG, t);
        }
        return "#" + t;
    }

    static int c1() {
        return Prefs.getInt(K_C1, 0xFF6A4CFF);
    }

    static int c2() {
        return Prefs.getInt(K_C2, 0xFFFF5FA2);
    }

    static int c3() {
        return Prefs.getInt(K_C3, 0xFF1ABC9C);
    }

    static int accent() {
        return Prefs.getInt(K_ACCENT, 0) == 0 ? Theme.ACCENT : Prefs.getInt(K_ACCENT, 0);
    }

    static int mode() {
        return Math.max(0, Math.min(2, Prefs.getInt(K_MODE, 0)));
    }

    static int fx() {
        return Math.max(0, Math.min(EFFECTS.length - 1, Prefs.getInt(K_FX, 2)));
    }

    static int ring() {
        return Math.max(0, Math.min(RINGS.length - 1, Prefs.getInt(K_RING, 2)));
    }

    static int nameFx() {
        return Math.max(0, Math.min(NAME_FX.length - 1, Prefs.getInt(K_NAMEFX, 1)));
    }

    /** Whole days since the profile was first opened. */
    static int days() {
        long since = 0;
        try {
            since = Long.parseLong(Prefs.getString(K_SINCE, "0"));
        } catch (NumberFormatException ignored) {
            // treated as new
        }
        if (since == 0) {
            since = System.currentTimeMillis();
            Prefs.putString(K_SINCE, String.valueOf(since));
        }
        return (int) ((System.currentTimeMillis() - since) / 86400000L);
    }

    // ------------------------------------------------------------------ the banner picture

    private static Bitmap image;
    private static boolean imageLoaded;

    static File imageFile(Context c) {
        return new File(c.getFilesDir(), "profile_banner.jpg");
    }

    static Bitmap bannerImage(Context c) {
        if (!imageLoaded) {
            imageLoaded = true;
            try {
                File f = imageFile(c);
                if (f.exists()) {
                    image = BitmapFactory.decodeFile(f.getAbsolutePath());
                }
            } catch (Exception | OutOfMemoryError e) {
                image = null;
            }
        }
        return image;
    }

    static void imageChanged() {
        imageLoaded = false;
        image = null;
    }

    static void resetLook() {
        String[] keys = {K_C1, K_C2, K_C3, K_MODE, K_FX, K_RING, K_NAMEFX, K_ACCENT};
        for (String k : keys) {
            Prefs.putInt(k, k.equals(K_FX) ? 2 : k.equals(K_RING) ? 2 : k.equals(K_NAMEFX) ? 1 : 0);
        }
        Prefs.putInt(K_C1, 0xFF6A4CFF);
        Prefs.putInt(K_C2, 0xFFFF5FA2);
        Prefs.putInt(K_C3, 0xFF1ABC9C);
    }
}
