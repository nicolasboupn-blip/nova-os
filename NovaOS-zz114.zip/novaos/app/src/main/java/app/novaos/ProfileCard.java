package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The profile card: moving banner, avatar with a ring, name with an effect, status, about me, badges, stats. */
final class ProfileCard extends LinearLayout {
    private final NovaActivity host;
    private final boolean compact;
    /** When set, the matching part of the card can be tapped to edit it. */
    Runnable onBanner, onAvatar, onName, onStatus, onAbout, onBadges;

    ProfileCard(NovaActivity host, boolean compact) {
        super(host);
        this.host = host;
        this.compact = compact;
        setOrientation(VERTICAL);
        build();
    }

    void build() {
        removeAllViews();
        int bannerH = dp(compact ? 70 : 110);
        int av = dp(compact ? 56 : 78);
        FrameLayout top = new FrameLayout(host);
        BannerView banner = new BannerView(host);
        top.addView(banner, new FrameLayout.LayoutParams(-1, bannerH));
        if (onBanner != null) {
            banner.setOnClickListener(v -> onBanner.run());
            TextView pen = tv("\u270E EDIT BANNER", 9f, 0xFFFFFFFF);
            pen.setBackground(Theme.rounded(0x88000000, 10f, host));
            pen.setPadding(dp(8), dp(4), dp(8), dp(4));
            FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.TOP);
            plp.setMargins(0, dp(8), dp(8), 0);
            top.addView(pen, plp);
        }
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(av, av);
        alp.leftMargin = dp(14);
        alp.topMargin = bannerH - av / 2;
        AvatarRing ring = new AvatarRing(host);
        if (onAvatar != null) {
            ring.setOnClickListener(v -> onAvatar.run());
        }
        top.addView(ring, alp);
        addView(top, new LinearLayout.LayoutParams(-1, bannerH + av / 2));

        LinearLayout body = new LinearLayout(host);
        body.setOrientation(VERTICAL);
        body.setPadding(dp(14), dp(6), dp(14), dp(12));
        body.setBackground(Theme.rounded(0x33000000, 0f, host));

        LinearLayout nameRow = new LinearLayout(host);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        NameView nm = new NameView(host, Profile.name());
        nameRow.addView(nm);
        if (onName != null) {
            nameRow.setOnClickListener(v -> onName.run());
        }
        TextView tag = tv(Profile.tag(), 11f, Theme.DIM);
        tag.setPadding(dp(6), 0, 0, 0);
        nameRow.addView(tag);
        body.addView(nameRow);
        if (!Profile.pronouns().isEmpty()) {
            TextView pr = tv(Profile.pronouns(), 10f, Theme.DIM);
            pr.setGravity(Gravity.START);
            body.addView(pr);
        }

        String st = !Profile.statusText().isEmpty() ? Profile.statusText() : Scenes.status();
        TextView status = tv(st.isEmpty() ? "● set a status" : "● " + st, 11f, Profile.accent());
        if (onStatus != null) {
            status.setOnClickListener(v -> onStatus.run());
        }
        status.setGravity(Gravity.START);
        status.setPadding(0, dp(3), 0, 0);
        body.addView(status);

        String about = Profile.about();
        if ((!about.isEmpty() || onAbout != null) && !compact) {
            TextView ab = tv(about.isEmpty() ? "\u270E tap to write about yourself" : about, 12f,
                    about.isEmpty() ? Theme.DIM : Theme.TEXT);
            if (onAbout != null) {
                ab.setOnClickListener(v -> onAbout.run());
            }
            ab.setGravity(Gravity.START);
            ab.setPadding(dp(10), dp(8), dp(10), dp(8));
            ab.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(8);
            body.addView(ab, p);
        }

        if (!compact) {
            body.addView(tv("ACHIEVEMENTS  " + Badges.count() + "/" + Badges.ALL.length, 9f, Theme.DIM),
                    new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
            hp.topMargin = dp(10);
            body.getChildAt(body.getChildCount() - 1).setLayoutParams(hp);
            View strip = badgeStrip();
            if (onBadges != null) {
                strip.setOnClickListener(v -> onBadges.run());
            }
            body.addView(strip);
        }

        LinearLayout stats = new LinearLayout(host);
        stats.setPadding(0, dp(10), 0, 0);
        stats.addView(stat(String.valueOf(Coins.get()), "COINS"), new LinearLayout.LayoutParams(0, -2, 1f));
        stats.addView(stat(Badges.count() + "", "BADGES"), new LinearLayout.LayoutParams(0, -2, 1f));
        stats.addView(stat(String.valueOf(Profile.days()), "DAYS"), new LinearLayout.LayoutParams(0, -2, 1f));
        body.addView(stats);
        addView(body, new LinearLayout.LayoutParams(-1, -2));
    }

    private View badgeStrip() {
        LinearLayout row = new LinearLayout(host);
        row.setPadding(0, dp(6), 0, 0);
        int shown = 0;
        java.util.List<String> chosen = Profile.showcase();
        for (String id : chosen) {
            Badges.Badge b = Badges.find(id);
            if (b != null && Badges.has(id) && shown < 8) {
                TextView t = tv(b.icon, 20f, Badges.TIER_COLOR[b.tier]);
                t.setPadding(dp(6), dp(4), dp(6), dp(4));
                t.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
                p.rightMargin = dp(5);
                row.addView(t, p);
                shown++;
            }
        }
        for (int tier = chosen.isEmpty() ? Badges.GOLD : -1; tier >= Badges.BRONZE && shown < 8; tier--) {
            for (Badges.Badge b : Badges.ALL) {
                if (b.tier == tier && Badges.has(b.id) && shown < 8) {
                    TextView t = tv(b.icon, 20f, Badges.TIER_COLOR[tier]);
                    t.setPadding(dp(6), dp(4), dp(6), dp(4));
                    t.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
                    p.rightMargin = dp(5);
                    row.addView(t, p);
                    shown++;
                }
            }
        }
        if (shown == 0) {
            row.addView(tv("none yet, keep playing", 10f, Theme.DIM));
        }
        return row;
    }

    private View stat(String value, String label) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(tv(value, compact ? 14f : 17f, Theme.TEXT));
        c.addView(tv(label, 8f, Theme.DIM));
        return c;
    }

    private TextView tv(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private static float rnd(int i, int k) {
        double x = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453;
        return (float) (x - Math.floor(x));
    }

    // ------------------------------------------------------------------ banner

    static final class BannerView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rf = new RectF();

        BannerView(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas cv) {
            int w = getWidth();
            int h = getHeight();
            float t = (System.currentTimeMillis() % 100000L) / 1000f;
            int c1 = Profile.c1();
            int c2 = Profile.c2();
            int c3 = Profile.c3();
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            int mode = Profile.mode();
            Bitmap img = mode == 2 ? Profile.bannerImage(getContext()) : null;
            if (img != null) {
                float s = Math.max(w / (float) img.getWidth(), h / (float) img.getHeight());
                Matrix m = new Matrix();
                m.postScale(s, s);
                m.postTranslate((w - img.getWidth() * s) / 2f, (h - img.getHeight() * s) / 2f);
                cv.drawBitmap(img, m, p);
            } else if (mode == 1) {
                cv.drawColor(c1);
            } else {
                p.setShader(new LinearGradient(0, 0, w, h, new int[] {c1, c2, c3}, null, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, w, h, p);
                p.setShader(null);
            }
            effect(cv, w, h, t, c1, c2, c3);
            // soft fade into the card
            p.setShader(new LinearGradient(0, h * 0.6f, 0, h, 0x00000000, 0x55000000, Shader.TileMode.CLAMP));
            cv.drawRect(0, 0, w, h, p);
            p.setShader(null);
            if (Profile.fx() != 0) {
                postInvalidateOnAnimation();
            }
        }

        private void effect(Canvas cv, int w, int h, float t, int c1, int c2, int c3) {
            int fx = Profile.fx();
            switch (fx) {
                case 1:
                    int[] cols = {c3, c2, c1};
                    for (int k = 0; k < 3; k++) {
                        path.reset();
                        path.moveTo(0, h);
                        for (int x = 0; x <= w; x += 12) {
                            float y = h * (0.45f + 0.12f * k) + (float) Math.sin(x / (w / 4f) + t * (0.8f + k * 0.3f) + k)
                                    * h * 0.14f;
                            path.lineTo(x, y);
                        }
                        path.lineTo(w, h);
                        path.close();
                        p.setColor((cols[k] & 0x00FFFFFF) | 0x55000000);
                        cv.drawPath(path, p);
                    }
                    break;
                case 2:
                    for (int i = 0; i < 40; i++) {
                        float a = 0.3f + 0.7f * (0.5f + 0.5f * (float) Math.sin(t * (1f + rnd(i, 3) * 2f) + i));
                        p.setColor(Color.argb((int) (a * 255), 255, 255, 255));
                        cv.drawCircle(rnd(i, 1) * w, rnd(i, 2) * h, (0.6f + rnd(i, 4) * 1.4f) * getResources()
                                .getDisplayMetrics().density, p);
                    }
                    break;
                case 3:
                    p.setStrokeWidth(getResources().getDisplayMetrics().density);
                    for (int i = 0; i < 50; i++) {
                        float sp = 0.5f + rnd(i, 5);
                        float y = ((t * sp * 0.9f + rnd(i, 2)) % 1f) * (h + 20) - 10;
                        float x = rnd(i, 1) * w;
                        p.setColor(0x88CCE8FF);
                        cv.drawLine(x, y, x - 3, y + h * 0.12f, p);
                    }
                    break;
                case 4:
                    for (int i = 0; i < 28; i++) {
                        float ph = (t * (0.6f + rnd(i, 3)) + rnd(i, 4) * 6f) % 2f;
                        float a = ph < 1f ? ph : 2f - ph;
                        float r = a * (2f + rnd(i, 6) * 4f) * getResources().getDisplayMetrics().density;
                        float x = rnd(i, 1) * w;
                        float y = rnd(i, 2) * h;
                        p.setColor(Color.argb((int) (a * 230), 255, 245, 200));
                        cv.drawRect(x - r, y - 0.5f, x + r, y + 0.5f, p);
                        cv.drawRect(x - 0.5f, y - r, x + 0.5f, y + r, p);
                    }
                    break;
                case 5:
                    for (int i = 0; i < 36; i++) {
                        float sp = 0.15f + rnd(i, 5) * 0.3f;
                        float f = (t * sp + rnd(i, 2)) % 1f;
                        float x = rnd(i, 1) * w + (float) Math.sin(t + i) * 8f;
                        p.setColor(Color.argb((int) ((1f - f) * 230), 255, 140 + (int) (rnd(i, 7) * 80), 40));
                        cv.drawCircle(x, h - f * h, (1f + rnd(i, 4) * 2f) * getResources().getDisplayMetrics().density, p);
                    }
                    break;
                case 6:
                    p.setTypeface(Typeface.MONOSPACE);
                    p.setTextSize(11f * getResources().getDisplayMetrics().scaledDensity);
                    int cols2 = Math.max(6, w / 28);
                    for (int i = 0; i < cols2; i++) {
                        float x = (i + 0.5f) * w / cols2;
                        float head = ((t * (0.25f + rnd(i, 3) * 0.4f) + rnd(i, 1)) % 1.4f) * h * 1.3f;
                        for (int k = 0; k < 6; k++) {
                            float y = head - k * p.getTextSize();
                            if (y < 0 || y > h + 12) {
                                continue;
                            }
                            p.setColor(Color.argb(255 - k * 40, 60, 255, 120));
                            cv.drawText(String.valueOf((char) ('0' + (int) (rnd(i * 7 + k, (int) (t * 3)) * 2))), x, y, p);
                        }
                    }
                    break;
                case 7:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(getResources().getDisplayMetrics().density);
                    for (int i = 0; i < 16; i++) {
                        float f = (t * (0.08f + rnd(i, 3) * 0.12f) + rnd(i, 2)) % 1f;
                        float r = (3f + rnd(i, 4) * 9f) * getResources().getDisplayMetrics().density;
                        p.setColor(Color.argb((int) ((1f - f) * 200), 255, 255, 255));
                        cv.drawCircle(rnd(i, 1) * w + (float) Math.sin(t + i) * 6f, h - f * (h + r), r, p);
                    }
                    p.setStyle(Paint.Style.FILL);
                    break;
                case 8:
                    for (int i = 0; i < 45; i++) {
                        float f = (t * (0.06f + rnd(i, 3) * 0.1f) + rnd(i, 2)) % 1f;
                        p.setColor(0xCCFFFFFF);
                        cv.drawCircle(rnd(i, 1) * w + (float) Math.sin(t * 0.8f + i) * 10f, f * h,
                                (1f + rnd(i, 4) * 2f) * getResources().getDisplayMetrics().density, p);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    // ------------------------------------------------------------------ avatar with ring

    static final class AvatarRing extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Bitmap bmp;

        AvatarRing(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas cv) {
            int w = getWidth();
            float d = getResources().getDisplayMetrics().density;
            float cx = w / 2f;
            float ring = 4f * d;
            float t = (System.currentTimeMillis() % 100000L) / 1000f;
            int style = Profile.ring();
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF0B0A14);
            cv.drawCircle(cx, cx, cx, p);
            p.setColor(Theme.PANEL | 0xFF000000);
            cv.drawCircle(cx, cx, cx - ring, p);
            try {
                if (bmp == null) {
                    bmp = AvatarEditor.bitmap(3);
                }
                float s = (w - ring * 2f) / (float) bmp.getHeight() * 0.95f;
                cv.save();
                Path clip = new Path();
                clip.addCircle(cx, cx, cx - ring, Path.Direction.CW);
                cv.clipPath(clip);
                Matrix m = new Matrix();
                m.postScale(s, s);
                m.postTranslate(cx - bmp.getWidth() * s / 2f, cx - bmp.getHeight() * s / 2f + 2f * d);
                p.setFilterBitmap(false);
                cv.drawBitmap(bmp, m, p);
                cv.restore();
            } catch (RuntimeException ignored) {
                // no figure yet
            }
            if (style != 0) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(ring);
                float r = cx - ring / 2f;
                if (style == 1) {
                    p.setColor(Profile.accent());
                    cv.drawCircle(cx, cx, r, p);
                } else if (style == 2) {
                    SweepGradient sg = new SweepGradient(cx, cx, new int[] {Profile.c1(), Profile.c2(), Profile.c3(),
                        Profile.c1()}, null);
                    Matrix m = new Matrix();
                    m.setRotate(t * 90f, cx, cx);
                    sg.setLocalMatrix(m);
                    p.setShader(sg);
                    cv.drawCircle(cx, cx, r, p);
                    p.setShader(null);
                } else if (style == 3) {
                    float a = 0.5f + 0.5f * (float) Math.sin(t * 2.4f);
                    p.setColor(Profile.accent());
                    cv.drawCircle(cx, cx, r, p);
                    p.setStrokeWidth(ring * (1f + a * 1.2f));
                    p.setColor((Profile.accent() & 0x00FFFFFF) | ((int) (90 * (1f - a)) << 24));
                    cv.drawCircle(cx, cx, r + ring * a, p);
                } else {
                    rf();
                    p.setColor(Profile.accent());
                    float start = t * 60f;
                    for (int k = 0; k < 12; k++) {
                        cv.drawArc(new RectF(ring / 2f, ring / 2f, w - ring / 2f, w - ring / 2f), start + k * 30f, 17f,
                                false, p);
                    }
                }
            }
            p.setStyle(Paint.Style.FILL);
            if (style >= 2) {
                postInvalidateOnAnimation();
            }
        }

        private void rf() {
            // placeholder to keep the dashed branch tidy
        }
    }

    // ------------------------------------------------------------------ name with an effect

    static final class NameView extends TextView {
        private final Paint tmp = new Paint();

        NameView(Context c, String name) {
            super(c);
            setText(name);
            setTextSize(20f);
            setTypeface(Typeface.create(Theme.MONO, Typeface.BOLD));
            setTextColor(Theme.TEXT);
            setSingleLine(true);
        }

        @Override
        protected void onDraw(Canvas cv) {
            int fx = Profile.nameFx();
            float w = Math.max(1f, getPaint().measureText(getText().toString()));
            if (fx == 0) {
                getPaint().setShader(null);
            } else {
                float t = (System.currentTimeMillis() % 100000L) / 1000f;
                int[] cols;
                if (fx == 3) {
                    cols = new int[7];
                    for (int i = 0; i < 7; i++) {
                        cols[i] = Color.HSVToColor(new float[] {(i * 60f + t * 60f) % 360f, 0.7f, 1f});
                    }
                } else if (fx == 2) {
                    cols = new int[] {Profile.c1(), 0xFFFFFFFF, Profile.c2()};
                } else {
                    cols = new int[] {Profile.c1(), Profile.c2(), Profile.c3()};
                }
                LinearGradient lg = new LinearGradient(0, 0, w, 0, cols, null, Shader.TileMode.MIRROR);
                if (fx >= 2) {
                    Matrix m = new Matrix();
                    m.setTranslate((t * w * 0.5f) % (w * 2f), 0);
                    lg.setLocalMatrix(m);
                    postInvalidateOnAnimation();
                }
                getPaint().setShader(lg);
            }
            super.onDraw(cv);
        }
    }
}
