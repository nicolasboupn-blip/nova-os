package app.novaos;

import java.util.Random;

/**
 * Short conversations between the travelling merchant and Margon the wizard, played as speech bubbles while the
 * merchant waits at the gate. Each line already carries its speaker.
 */
final class MerchantTalk {
    private MerchantTalk() {}

    private static final String[][] SCRIPTS = {
        {
            "Merchant: Greetings, Margon! Finest wares in three kingdoms, I swear it.",
            "Margon: Last time your finest ware was a teapot that haunted my bedroom.",
            "Merchant: That teapot was a misunderstanding. It only haunts on Tuesdays.",
            "Margon: Today is Tuesday.",
            "Merchant: ...Then let us talk about something else. Shields? Potions?",
            "Margon: Show me. And no teapots.",
        },
        {
            "Margon: Your prices went up again, merchant.",
            "Merchant: Inflation, friend. The dragon eats gold faster than I can mint it.",
            "Margon: The dragon eats what I feed him. Be fair.",
            "Merchant: Fair? I have a wife, six mules and a lantern that never goes out.",
            "Margon: Fine. Let me see what you have today.",
        },
        {
            "Merchant: Three days on the road, Margon. Bandits, rain, and a goat.",
            "Margon: A goat? Did you feed it?",
            "Merchant: I fed it my hat. It did not like the hat.",
            "Margon: Keep the hat away from my castle. What is on sale?",
            "Merchant: Today only, a real bargain. Look, look!",
        },
        {
            "Margon: Why does your lantern hum?",
            "Merchant: It is full of stars. Good for reading, bad for sleeping.",
            "Margon: Sounds dangerous. Do you sell sleep?",
            "Merchant: I sell everything that fits in a backpack. Sleep too, if you insist.",
            "Margon: I will look, but I promise nothing.",
        },
        {
            "Merchant: Ah, my favourite wizard! You look rested.",
            "Margon: I am always rested. The castle does the work.",
            "Merchant: Then the castle deserves a discount.",
            "Margon: The castle deserves a new roof. Show me your deals.",
            "Merchant: Look how they shine! Only for loyal customers... and anyone with coins.",
        },
    };

    /** A random script. */
    static String[] pick(Random rnd) {
        return SCRIPTS[rnd.nextInt(SCRIPTS.length)];
    }
}
