package app.novaos;

import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * POCKET MONEY: type what you spent, like "-15 kebab" or just "15 kebab", or money you got, like "+20 birthday".
 * It sorts it, shows what is left of your week (in CHF, weeks start on Monday) and warns you before you run out.
 * Tap the budget to change it.
 */
final class MoneyWidget extends NovaWidget {
    private static final String KEY = "money_log";
    private static final String K_BUDGET = "money_budget";
    private static final String[][] CATS = {
        {"Food", "kebab", "döner", "doner", "pizza", "burger", "mc", "coop", "migros", "denner", "lidl", "aldi", "snack",
            "coffee", "kaffee", "starbucks", "sushi", "lunch", "zmittag", "essen", "food", "drink", "redbull", "eis",
            "glace", "bäck", "baeck", "sandwich", "kiosk", "k kiosk", "subway", "kfc", "dürüm", "durum"},
        {"Travel", "bus", "tram", "zvv", "sbb", "train", "zug", "ticket", "billett", "taxi", "uber", "velo", "scooter"},
        {"Fun", "game", "steam", "psn", "playstation", "xbox", "nintendo", "skin", "vbucks", "v-bucks", "robux", "kino",
            "cinema", "movie", "concert", "bowling", "minigolf", "party", "club"},
        {"Clothes", "shoes", "schuhe", "hoodie", "shirt", "jacket", "jacke", "zalando", "nike", "adidas", "h&m", "zara",
            "pants", "hose", "cap"},
        {"Phone", "abo", "data", "swisscom", "salt", "sunrise", "spotify", "netflix", "youtube", "app", "case"},
        {"Gifts", "gift", "geschenk", "present", "birthday"}};
    private final TextView left;
    private final TextView budgetL;
    private final WidgetBar bar;
    private final TextView warn;
    private final LinearLayout cats;
    private final LinearLayout list;
    private final EditText input;

    MoneyWidget(NovaActivity host) {
        super(host);
        setOrientation(VERTICAL);
        LinearLayout top = row();
        top.setGravity(Gravity.BOTTOM);
        left = text("", 26f, Theme.TEXT);
        left.setGravity(Gravity.START);
        top.addView(left, weight(1f));
        budgetL = text("", 11f, Theme.ACCENT);
        budgetL.setPadding(dp(8), 0, 0, dp(6));
        budgetL.setOnClickListener(v -> askBudget());
        top.addView(budgetL);
        addView(top, wide());
        bar = new WidgetBar(host);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(8));
        bp.topMargin = dp(4);
        addView(bar, bp);
        warn = text("", 10.5f, Theme.DIM);
        warn.setGravity(Gravity.START);
        warn.setPadding(0, dp(5), 0, dp(4));
        addView(warn, wide());

        LinearLayout in = row();
        in.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(host);
        input.setHint("-15 kebab   or   +20 birthday");
        input.setHintTextColor(Theme.DIM);
        input.setTextColor(Theme.TEXT);
        input.setTextSize(13f);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setBackground(Theme.rounded(Theme.BG2, 12f, host));
        input.setPadding(dp(12), dp(9), dp(12), dp(9));
        input.setOnEditorActionListener((v, id, ev) -> {
            add(input.getText().toString());
            return true;
        });
        in.addView(input, weight(1f));
        TextView ok = chip("ADD", () -> add(input.getText().toString()));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-2, -2);
        op.leftMargin = dp(6);
        in.addView(ok, op);
        addView(in, wide());

        LinearLayout quick = row();
        quick.setPadding(0, dp(6), 0, 0);
        String[][] q = {{"kebab", "-15 kebab"}, {"Migros", "-8 Migros"}, {"drink", "-4 drink"}, {"kino", "-19 kino"}};
        for (String[] k : q) {
            final String s = k[1];
            TextView c = chip(k[0], () -> add(s));
            c.setTextSize(10f);
            LinearLayout.LayoutParams cp = weight(1f);
            cp.setMargins(dp(2), 0, dp(2), 0);
            quick.addView(c, cp);
        }
        addView(quick, wide());

        cats = new LinearLayout(host);
        cats.setOrientation(VERTICAL);
        cats.setPadding(0, dp(8), 0, 0);
        addView(cats, wide());
        list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        list.setPadding(0, dp(6), 0, 0);
        addView(list, wide());
    }

    static float budget() {
        try {
            return Float.parseFloat(Prefs.getString(K_BUDGET, "30"));
        } catch (NumberFormatException e) {
            return 30f;
        }
    }

    /** {time, cents (negative = spent), text} of every entry, newest first. */
    static List<Object[]> entries() {
        List<Object[]> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String p : raw.split("\n")) {
            String[] f = p.split("\\|", 3);
            if (f.length < 3) {
                continue;
            }
            try {
                out.add(0, new Object[] {Long.parseLong(f[0]), Long.parseLong(f[1]), f[2]});
            } catch (NumberFormatException ignored) {
                // broken entry
            }
        }
        return out;
    }

    private static void save(List<Object[]> newestFirst) {
        StringBuilder b = new StringBuilder();
        for (int i = Math.min(newestFirst.size(), 600) - 1; i >= 0; i--) {
            Object[] o = newestFirst.get(i);
            b.append(o[0]).append('|').append(o[1]).append('|').append(((String) o[2]).replace("\n", " ")).append('\n');
        }
        Prefs.putString(KEY, b.toString());
    }

    static long weekStart() {
        Calendar c = Calendar.getInstance();
        c.setFirstDayOfWeek(Calendar.MONDAY);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        int dow = c.get(Calendar.DAY_OF_WEEK);
        int back = (dow + 5) % 7; // Monday = 0
        c.add(Calendar.DAY_OF_MONTH, -back);
        return c.getTimeInMillis();
    }

    static String category(String text, long cents) {
        if (cents > 0) {
            return "Income";
        }
        String t = text.toLowerCase(Locale.ROOT);
        for (String[] c : CATS) {
            for (int i = 1; i < c.length; i++) {
                if (t.contains(c[i])) {
                    return c[0];
                }
            }
        }
        return "Other";
    }

    static String chf(long cents) {
        long a = Math.abs(cents);
        return (cents < 0 ? "-" : "") + "CHF " + (a / 100) + "." + String.format(Locale.ROOT, "%02d", a % 100);
    }

    private void add(String raw) {
        String s = raw.trim();
        if (s.isEmpty()) {
            return;
        }
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^([+-]?)\\s*(\\d+(?:[.,]\\d{1,2})?)\\s*(?:chf|fr\\.?|\\.-)?\\s*(.*)$",
                java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);
        if (!m.find()) {
            host.toast("Start with an amount, like -15 kebab");
            return;
        }
        double amount = Double.parseDouble(m.group(2).replace(',', '.'));
        long cents = Math.round(amount * 100);
        if (!"+".equals(m.group(1))) {
            cents = -cents;
        }
        String what = m.group(3).trim();
        if (what.isEmpty()) {
            what = cents > 0 ? "money in" : "something";
        }
        List<Object[]> all = entries();
        all.add(0, new Object[] {System.currentTimeMillis(), cents, what});
        save(all);
        input.setText("");
        host.hideKeyboard();
        host.buzz(10);
        refresh();
        float l = leftCents() / 100f;
        if (cents < 0 && l < 0) {
            host.toast("Over budget by CHF " + String.format(Locale.ROOT, "%.2f", -l) + " this week 😬");
        } else if (cents < 0 && l < budget() * 0.2f) {
            host.toast("Careful: only CHF " + String.format(Locale.ROOT, "%.2f", l) + " left until Monday");
        }
    }

    private long leftCents() {
        long start = weekStart();
        long sum = Math.round(budget() * 100);
        for (Object[] o : entries()) {
            if ((long) o[0] >= start) {
                sum += (long) o[1];
            }
        }
        return sum;
    }

    private void askBudget() {
        final EditText e = new EditText(host);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(String.format(Locale.ROOT, "%.0f", budget()));
        new android.app.AlertDialog.Builder(host)
                .setTitle("Weekly budget (CHF)")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    try {
                        float v = Float.parseFloat(e.getText().toString().replace(',', '.'));
                        if (v > 0) {
                            Prefs.putString(K_BUDGET, String.valueOf(v));
                        }
                    } catch (NumberFormatException ignored) {
                        // keep the old one
                    }
                    refresh();
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    @Override
    long tickMs() {
        return 0;
    }

    @Override
    void refresh() {
        long start = weekStart();
        float budget = budget();
        long l = leftCents();
        left.setText(chf(l) + " left");
        left.setTextColor(l < 0 ? 0xFFFF5A4E : l < budget * 20 ? 0xFFFFB347 : Theme.TEXT);
        budgetL.setText("of " + String.format(Locale.ROOT, "%.0f", budget) + " / week ✎");
        bar.set(Math.max(0f, Math.min(1f, l / (budget * 100f))));
        bar.color(l < 0 ? 0xFFFF5A4E : l < budget * 20 ? 0xFFFFB347 : 0xFF4CD964);
        Calendar c = Calendar.getInstance();
        int daysLeft = 7 - ((c.get(Calendar.DAY_OF_WEEK) + 5) % 7);
        if (l < 0) {
            warn.setText("Over budget. Money is back on Monday.");
        } else {
            warn.setText(daysLeft + (daysLeft == 1 ? " day" : " days") + " to go  ·  about " + chf(l / daysLeft)
                    + " a day");
        }

        // where it went this week
        cats.removeAllViews();
        java.util.Map<String, Long> per = new java.util.LinkedHashMap<>();
        long spent = 0;
        List<Object[]> all = entries();
        for (Object[] o : all) {
            if ((long) o[0] >= start && (long) o[1] < 0) {
                String k = category((String) o[2], (long) o[1]);
                per.put(k, (per.containsKey(k) ? per.get(k) : 0L) - (long) o[1]);
                spent -= (long) o[1];
            }
        }
        List<java.util.Map.Entry<String, Long>> sorted = new ArrayList<>(per.entrySet());
        sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        for (java.util.Map.Entry<String, Long> en : sorted) {
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            TextView n = text(en.getKey(), 10f, Theme.TEXT);
            n.setGravity(Gravity.START);
            r.addView(n, new LinearLayout.LayoutParams(dp(56), -2));
            WidgetBar wb = new WidgetBar(host);
            wb.set(spent == 0 ? 0 : en.getValue() / (float) spent);
            r.addView(wb, new LinearLayout.LayoutParams(0, dp(6), 1f));
            TextView v = text(chf(en.getValue()), 10f, Theme.DIM);
            v.setPadding(dp(6), 0, 0, 0);
            r.addView(v);
            r.setPadding(0, dp(2), 0, dp(2));
            cats.addView(r, wide());
        }

        // the last few entries, with a cross to remove a mistake
        list.removeAllViews();
        SimpleDateFormat f = new SimpleDateFormat("EEE HH:mm", Locale.getDefault());
        for (int i = 0; i < Math.min(5, all.size()); i++) {
            final Object[] o = all.get(i);
            LinearLayout r = row();
            r.setGravity(Gravity.CENTER_VERTICAL);
            long cents = (long) o[1];
            TextView a = text((cents > 0 ? "+" : "") + chf(cents).replace("CHF ", ""), 11f,
                    cents > 0 ? 0xFF4CD964 : Theme.TEXT);
            a.setGravity(Gravity.START);
            r.addView(a, new LinearLayout.LayoutParams(dp(60), -2));
            TextView n = text((String) o[2], 11f, Theme.TEXT);
            n.setGravity(Gravity.START);
            n.setSingleLine(true);
            n.setEllipsize(android.text.TextUtils.TruncateAt.END);
            r.addView(n, weight(1f));
            TextView t = text(f.format(new Date((long) o[0])), 9f, Theme.DIM);
            t.setPadding(dp(6), 0, dp(6), 0);
            r.addView(t);
            TextView x = text("✕", 11f, Theme.DIM);
            x.setPadding(dp(6), dp(4), dp(4), dp(4));
            x.setOnClickListener(v -> {
                List<Object[]> now = entries();
                for (int k = 0; k < now.size(); k++) {
                    if (now.get(k)[0].equals(o[0]) && now.get(k)[1].equals(o[1])) {
                        now.remove(k);
                        break;
                    }
                }
                save(now);
                refresh();
            });
            r.addView(x);
            list.addView(r, wide());
        }
        if (all.isEmpty()) {
            TextView e = text("Nothing yet. Type what you spent above.", 10f, Theme.DIM);
            e.setGravity(Gravity.START);
            list.addView(e, wide());
        }
    }
}
