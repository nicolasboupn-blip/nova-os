package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.provider.AlarmClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;

/**
 * Ten home screens with a job to do: MORNING (leave countdown, next bus, weather, checklist), SCHOOL (timetable with
 * the lesson now, homework, tests), NIGHT (sleep times, alarm, tomorrow), COMMUTE (bus map and sign, music), FOCUS
 * (a focus timer, today's top 3, only work apps), MONEY (pocket money, a savings goal, the month), HEALTH (water,
 * workouts, habits), PLANNER (your week), JOURNAL (a line a day, on this day) and STATS (what you did today).
 */
final class HomesF {
    private HomesF() {
    }

    // ------------------------------------------------------------------ shared

    /** Every pinned app in a grid, or null when nothing is pinned. */
    static View pinnedApps(AltHome a) {
        List<AppEntry> pins = a.pinned();
        if (pins.isEmpty()) {
            return null;
        }
        return HomesD.grid(a, pins, 4, 46, true);
    }

    static void ask(NovaActivity host, String title, String hint, String init, boolean multi,
            java.util.function.Consumer<String> ok) {
        final EditText e = new EditText(host);
        e.setHint(hint);
        e.setText(init);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        if (multi) {
            e.setMinLines(5);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        new AlertDialog.Builder(host).setTitle(title).setView(e)
                .setPositiveButton("SAVE", (d, w) -> ok.accept(e.getText().toString()))
                .setNegativeButton("CANCEL", null).show();
    }

    static void pickTime(NovaActivity host, int min, java.util.function.IntConsumer ok) {
        new android.app.TimePickerDialog(host, (v, h, m) -> ok.accept(h * 60 + m), min / 60, min % 60, true).show();
    }

    static void pickDay(NovaActivity host, java.util.function.Consumer<String> ok) {
        Calendar c = Calendar.getInstance();
        new android.app.DatePickerDialog(host, (v, y, mo, dd) -> {
            Calendar k = Calendar.getInstance();
            k.set(y, mo, dd);
            ok.accept(Life.day(k));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    static TextView line(AltHome a, String s, float sp, int color) {
        TextView t = a.text(s, sp, color);
        t.setGravity(Gravity.START);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return t;
    }

    static TextView small(AltHome a, String s, Runnable r) {
        TextView t = a.chip(s, r);
        t.setTextSize(10f);
        t.setPadding(a.dp(12), a.dp(7), a.dp(12), a.dp(7));
        return t;
    }

    /** Panel widgets expect the box height they get in the main box. */
    static View sized(View w) {
        FrameLayout f = new FrameLayout(w.getContext());
        f.addView(w, new FrameLayout.LayoutParams(-1, Theme.dp(w.getContext(), 168)));
        return f;
    }

    static LinearLayout col(AltHome a) {
        LinearLayout c = new LinearLayout(a.host);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    static LinearLayout.LayoutParams gap(AltHome a) {
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = a.dp(10);
        return p;
    }

    /** A scrolling page with a header, then the cards, then a row of apps and the bar. */
    static LinearLayout page(AltHome a, String title, TextView[] clockOut) {
        LinearLayout outer = col(a);
        LinearLayout body = col(a);
        body.setPadding(a.dp(14), a.dp(44), a.dp(14), a.dp(12));
        LinearLayout head = new LinearLayout(a.host);
        head.setGravity(Gravity.BOTTOM);
        TextView t = a.text(title, 12f, Theme.ACCENT);
        t.setLetterSpacing(0.25f);
        head.addView(t, lp(0, -2, 1f));
        TextView clock = a.text(a.clock(), 28f, Theme.TEXT);
        clock.setTypeface(Theme.LIGHT);
        head.addView(clock);
        clockOut[0] = clock;
        body.addView(head, lp(-1, -2));
        ScrollView sv = new ScrollView(a.host);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(body);
        outer.addView(sv, lp(-1, 0, 1f));
        // after the screen's own cards: all your pinned apps at the bottom of the scroll
        body.post(() -> {
            View all = pinnedApps(a);
            if (all != null) {
                body.addView(a.card("YOUR APPS", all), gap(a));
            }
        });
        LinearLayout apps = new LinearLayout(a.host);
        apps.setPadding(a.dp(8), a.dp(4), a.dp(8), 0);
        for (AppEntry e : a.appsFor(5)) {
            apps.addView(a.appTile(e, 40, false), lp(0, -2, 1f));
        }
        outer.addView(apps, lp(-1, -2));
        outer.addView(a.bar());
        a.addView(outer, new FrameLayout.LayoutParams(-1, -1));
        return body;
    }

    static View moodRow(AltHome a) {
        LinearLayout r = new LinearLayout(a.host);
        final List<TextView> all = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            final int f = i;
            TextView c = a.text(MoodLog.FACES[i], 24f, Theme.TEXT);
            c.setGravity(Gravity.CENTER);
            c.setPadding(0, a.dp(6), 0, a.dp(6));
            c.setBackground(Theme.rounded(MoodLog.current() == i ? Theme.ACCENT : Theme.BG2, 14f, a.host));
            c.setOnClickListener(v -> {
                MoodLog.log(f);
                a.host.buzz(10);
                for (int k = 0; k < all.size(); k++) {
                    all.get(k).setBackground(Theme.rounded(k == f ? Theme.ACCENT : Theme.BG2, 14f, a.host));
                }
            });
            all.add(c);
            LinearLayout.LayoutParams p = lp(0, -2, 1f);
            p.setMargins(a.dp(3), a.dp(4), a.dp(3), 0);
            r.addView(c, p);
        }
        return r;
    }

    /** A thin progress bar. */
    static final class Bar extends View {
        float v;
        int color = Theme.ACCENT;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Bar(android.content.Context c) {
            super(c);
        }

        void set(float f, int col) {
            v = Math.max(0, Math.min(1, f));
            color = col;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float h = getHeight();
            p.setColor((Theme.TEXT & 0xFFFFFF) | 0x22000000);
            c.drawRoundRect(new RectF(0, 0, getWidth(), h), h / 2, h / 2, p);
            p.setColor(color);
            c.drawRoundRect(new RectF(0, 0, Math.max(h, getWidth() * v), h), h / 2, h / 2, p);
        }
    }

    // ================================================================== MORNING

    /** Everything for getting out of the door: a leave countdown, the next bus, the weather, a checklist and how
     *  you woke up. */
    static final class Morning extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView greet;
        private final TextView leave;
        private final TextView leaveSub;
        private final Bar leaveBar;
        private final LinearLayout checks;
        private final TextView checkHead;

        Morning(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "MORNING", clock);
            greet = line(this, greeting(), 22f, Theme.TEXT);
            greet.setPadding(0, dp(6), 0, dp(2));
            b.addView(greet);
            b.addView(line(this, date(), 12f, Theme.DIM));

            LinearLayout lv = col(this);
            leave = line(this, "", 26f, Theme.TEXT);
            lv.addView(leave);
            leaveSub = line(this, "", 11f, Theme.DIM);
            lv.addView(leaveSub);
            leaveBar = new Bar(host);
            LinearLayout.LayoutParams bp = lp(-1, dp(6));
            bp.topMargin = dp(8);
            lv.addView(leaveBar, bp);
            lv.setOnClickListener(v -> pickTime(host, Life.leaveMin(), m -> {
                Prefs.putInt("leave_min", m);
                tick();
            }));
            b.addView(card("LEAVE  ·  tap to set the time", lv), gap(this));
            b.addView(card("NEXT BUS", Widgets.create(host, "busboard")), gap(this));
            b.addView(card("WEATHER", Widgets.create(host, "weather")), gap(this));

            LinearLayout ch = col(this);
            checkHead = line(this, "", 11f, Theme.ACCENT);
            ch.addView(checkHead);
            checks = col(this);
            ch.addView(checks);
            LinearLayout.LayoutParams ap = lp(-2, -2);
            ap.topMargin = dp(6);
            ch.addView(small(this, "+ ADD", () -> ask(host, "Add to the morning list", "e.g. Take vitamins", "", false, s -> {
                if (!s.trim().isEmpty()) {
                    List<String> l = Life.morningItems();
                    l.add(s.trim());
                    Life.saveMorningItems(l);
                    fillChecks();
                }
            })), ap);
            b.addView(card("CHECKLIST  ·  hold an item to remove it", ch), gap(this));
            b.addView(card("HOW DID YOU WAKE UP?", moodRow(this)), gap(this));
            fillChecks();
            tick();
        }

        private void fillChecks() {
            checks.removeAllViews();
            List<String> items = Life.morningItems();
            for (int i = 0; i < items.size(); i++) {
                final int idx = i;
                boolean on = Life.morningDone(i);
                TextView t = line(this, (on ? "☑  " : "☐  ") + items.get(i), 15f, on ? Theme.DIM : Theme.TEXT);
                t.setPaintFlags(on ? t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG : t.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                t.setPadding(0, dp(7), 0, dp(7));
                t.setOnClickListener(v -> {
                    Life.toggleMorning(idx);
                    host.buzz(8);
                    fillChecks();
                    if (Life.morningCount() == Life.morningItems().size()) {
                        host.toast("All done. Have a great day!");
                        host.confetti(getWidth() / 2f, getHeight() / 3f);
                    }
                });
                t.setOnLongClickListener(v -> {
                    List<String> l = Life.morningItems();
                    l.remove(idx);
                    Life.saveMorningItems(l);
                    fillChecks();
                    return true;
                });
                checks.addView(t, lp(-1, -2));
            }
            checkHead.setText(Life.morningCount() + " / " + items.size() + " done");
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            greet.setText(greeting());
            Calendar c = Calendar.getInstance();
            int now = Life.nowMin();
            int at = Life.leaveMin();
            int left = at - now;
            if (Life.weekend(c)) {
                leave.setText("Weekend — no rush 😴");
                leave.setTextColor(Theme.TEXT);
                leaveSub.setText("on school days: leave at " + Life.hm(at));
                leaveBar.set(0, Theme.ACCENT);
            } else if (left > 0 && left <= 180) {
                leave.setText("Leave in " + Life.dur(left));
                int col = left <= 3 ? 0xFFFF5A4E : left <= 10 ? 0xFFFFB347 : Theme.TEXT;
                leave.setTextColor(col);
                leaveSub.setText("at " + Life.hm(at) + "   ·   " + Life.morningCount() + "/" + Life.morningItems().size()
                        + " of your list done");
                leaveBar.set(1f - left / 60f, col == Theme.TEXT ? Theme.ACCENT : col);
            } else if (left <= 0 && left > -120) {
                leave.setText("Time to go! 🏃");
                leave.setTextColor(0xFFFF5A4E);
                leaveSub.setText("you wanted to leave at " + Life.hm(at));
                leaveBar.set(1f, 0xFFFF5A4E);
            } else {
                leave.setText("Leave at " + Life.hm(at));
                leave.setTextColor(Theme.TEXT);
                leaveSub.setText(left > 0 ? "in " + Life.dur(left) : "tomorrow");
                leaveBar.set(0, Theme.ACCENT);
            }
        }
    }

    // ================================================================== SCHOOL

    /** Your school day: the lesson now and next, today's timetable, homework with due days and test countdowns. */
    static final class School extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView nowName;
        private final TextView nowSub;
        private final Bar nowBar;
        private final LinearLayout today;
        private final LinearLayout hw;
        private final LinearLayout tests;
        private static final String[] DAYS = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        private static final int[] DOW = {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
            Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};

        School(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "SCHOOL", clock);
            LinearLayout now = col(this);
            nowName = line(this, "", 24f, Theme.TEXT);
            now.addView(nowName);
            nowSub = line(this, "", 11f, Theme.DIM);
            now.addView(nowSub);
            nowBar = new Bar(host);
            LinearLayout.LayoutParams bp = lp(-1, dp(6));
            bp.topMargin = dp(8);
            now.addView(nowBar, bp);
            b.addView(card("RIGHT NOW", now), gap(this));

            LinearLayout td = col(this);
            today = col(this);
            td.addView(today);
            LinearLayout edit = new LinearLayout(host);
            edit.setPadding(0, dp(8), 0, 0);
            edit.addView(line(this, "edit:", 10f, Theme.DIM));
            for (int i = 0; i < 5; i++) {
                final int k = i;
                LinearLayout.LayoutParams ep = lp(0, -2, 1f);
                ep.leftMargin = dp(4);
                edit.addView(small(this, DAYS[i], () -> editDay(k)), ep);
            }
            td.addView(edit);
            b.addView(card("TODAY'S TIMETABLE", td), gap(this));

            LinearLayout h = col(this);
            hw = col(this);
            h.addView(hw);
            LinearLayout.LayoutParams ap = lp(-2, -2);
            ap.topMargin = dp(6);
            h.addView(small(this, "+ HOMEWORK", this::addHomework), ap);
            b.addView(card("HOMEWORK  ·  tap to tick, hold to delete", h), gap(this));

            LinearLayout t = col(this);
            tests = col(this);
            t.addView(tests);
            t.addView(small(this, "+ TEST", () -> ask(host, "Which test?", "e.g. Maths test", "", false, s -> {
                if (s.trim().isEmpty()) {
                    return;
                }
                pickDay(host, day -> {
                    List<String[]> l = Life.tests();
                    l.add(new String[] {day, s.trim()});
                    Life.saveTests(l);
                    fill();
                });
            })), ap);
            b.addView(card("TESTS", t), gap(this));
            LinearLayout q = new LinearLayout(host);
            q.addView(small(this, "NOTES", () -> host.showNotes()), lp(0, -2, 1f));
            LinearLayout.LayoutParams qp = lp(0, -2, 1f);
            qp.leftMargin = dp(6);
            q.addView(small(this, "PLANNER", () -> {
                Prefs.putInt(K_LAYOUT, 58);
                host.showHome();
            }), qp);
            b.addView(q, gap(this));
            fill();
            tick();
        }

        private void editDay(int k) {
            String cur = Prefs.getString("tt_" + DOW[k], "");
            ask(host, "Timetable for " + DAYS[k], "One lesson per line, like:\n08:00 Maths R12\n08:50 German\n10:00 Sport",
                    cur, true, s -> {
                        Prefs.putString("tt_" + DOW[k], s);
                        fill();
                        tick();
                    });
        }

        private void addHomework() {
            ask(host, "What homework?", "e.g. Maths p.42 1-10", "", false, s -> {
                if (s.trim().isEmpty()) {
                    return;
                }
                final String[] when = {"Today", "Tomorrow", "In 2 days", "In 3 days", "Next week", "Pick a day..."};
                new AlertDialog.Builder(host).setTitle("Due when?").setItems(when, (d, w) -> {
                    if (w == 5) {
                        pickDay(host, day -> saveHw(day, s.trim()));
                        return;
                    }
                    saveHw(Life.dayPlus(new int[] {0, 1, 2, 3, 7}[w]), s.trim());
                }).show();
            });
        }

        private void saveHw(String day, String text) {
            List<String[]> l = Life.homework();
            l.add(new String[] {day, "0", text});
            Life.saveHomework(l);
            fill();
        }

        private void fill() {
            today.removeAllViews();
            List<Object[]> ls = Life.lessons(Calendar.getInstance().get(Calendar.DAY_OF_WEEK));
            if (ls.isEmpty()) {
                today.addView(line(this, "No lessons saved for today. Tap a day below to add your timetable.", 12f, Theme.DIM));
            }
            int now = Life.nowMin();
            for (int i = 0; i < ls.size(); i++) {
                int st = (int) ls.get(i)[0];
                int en = i + 1 < ls.size() ? (int) ls.get(i + 1)[0] : st + 45;
                boolean on = now >= st && now < en;
                boolean past = now >= en;
                TextView t = line(this, Life.hm(st) + "   " + ls.get(i)[1], 14f, on ? Theme.ACCENT : past ? Theme.DIM : Theme.TEXT);
                t.setPadding(dp(on ? 8 : 0), dp(5), 0, dp(5));
                if (on) {
                    t.setBackground(Theme.rounded(Theme.BG2, 10f, host));
                }
                today.addView(t, lp(-1, -2));
            }
            hw.removeAllViews();
            List<String[]> all = Life.homework();
            int shown = 0;
            for (final String[] f : all) {
                boolean done = "1".equals(f[1]);
                if (done && Life.daysUntil(f[0]) < -1) {
                    continue;
                }
                int dl = Life.daysUntil(f[0]);
                String due = dl < 0 && !done ? "LATE" : Life.nice(f[0]);
                int col = done ? Theme.DIM : dl < 0 ? 0xFFFF5A4E : dl <= 1 ? 0xFFFFB347 : Theme.TEXT;
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                TextView t = line(this, (done ? "☑  " : "☐  ") + f[2], 14f, col);
                if (done) {
                    t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
                r.addView(t, lp(0, -2, 1f));
                r.addView(line(this, due, 10f, col));
                r.setPadding(0, dp(6), 0, dp(6));
                r.setOnClickListener(v -> {
                    f[1] = "1".equals(f[1]) ? "0" : "1";
                    Life.saveHomework(all);
                    host.buzz(8);
                    fill();
                });
                r.setOnLongClickListener(v -> {
                    all.remove(f);
                    Life.saveHomework(all);
                    fill();
                    return true;
                });
                hw.addView(r, lp(-1, -2));
                shown++;
            }
            if (shown == 0) {
                hw.addView(line(this, "No homework. Nice. 😎", 12f, Theme.DIM));
            }
            tests.removeAllViews();
            final List<String[]> ts = Life.tests();
            for (final String[] f : ts) {
                int dl = Life.daysUntil(f[0]);
                int col = dl <= 1 ? 0xFFFF5A4E : dl <= 4 ? 0xFFFFB347 : Theme.TEXT;
                TextView t = line(this, f[1] + "   ·   " + (dl == 0 ? "TODAY" : dl == 1 ? "tomorrow" : "in " + dl + " days"),
                        14f, col);
                t.setPadding(0, dp(5), 0, dp(5));
                t.setOnLongClickListener(v -> {
                    ts.remove(f);
                    Life.saveTests(ts);
                    fill();
                    return true;
                });
                tests.addView(t, lp(-1, -2));
            }
            if (ts.isEmpty()) {
                tests.addView(line(this, "No tests coming up.", 12f, Theme.DIM));
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            List<Object[]> ls = Life.lessons(Calendar.getInstance().get(Calendar.DAY_OF_WEEK));
            int now = Life.nowMin();
            for (int i = 0; i < ls.size(); i++) {
                int st = (int) ls.get(i)[0];
                int en = i + 1 < ls.size() ? (int) ls.get(i + 1)[0] : st + 45;
                if (now >= st && now < en) {
                    nowName.setText((String) ls.get(i)[1]);
                    String next = i + 1 < ls.size() ? "next: " + ls.get(i + 1)[1] + " at " + Life.hm(en) : "last lesson";
                    nowSub.setText(Life.dur(en - now) + " left   ·   " + next);
                    nowBar.set((now - st) / (float) Math.max(1, en - st), Theme.ACCENT);
                    return;
                }
                if (now < st) {
                    nowName.setText(i == 0 ? "School starts soon" : "Break");
                    nowSub.setText(ls.get(i)[1] + " at " + Life.hm(st) + " (in " + Life.dur(st - now) + ")");
                    nowBar.set(0, Theme.ACCENT);
                    return;
                }
            }
            nowName.setText(ls.isEmpty() ? "No school today" : "School's out 🎉");
            int open = 0;
            for (String[] f : Life.homework()) {
                if (!"1".equals(f[1])) {
                    open++;
                }
            }
            nowSub.setText(open == 0 ? "no homework left" : open + " homework to do");
            nowBar.set(1, Theme.ACCENT);
        }
    }

    // ================================================================== NIGHT

    /** Calm red night screen: when to sleep for your wake-up time, an alarm button, what's on tomorrow, how today was. */
    static final class Night extends AltHome {
        static final int RED = 0xFFFF6B5E;
        static final int DIMRED = 0xFF8A3A33;
        private final TextView time;
        private final TextView sleep;
        private final TextView cycles;
        private final TextView wake;

        Night(NovaActivity host) {
            super(host);
            setBackgroundColor(0xFF000000);
            LinearLayout outer = col(this);
            LinearLayout b = col(this);
            b.setPadding(dp(20), dp(54), dp(20), dp(16));
            time = text(clock(), 72f, RED);
            time.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            b.addView(time);
            TextView d = text(date(), 12f, DIMRED);
            b.addView(d);

            LinearLayout w = box();
            wake = line(this, "", 16f, RED);
            w.addView(wake);
            sleep = line(this, "", 22f, RED);
            sleep.setPadding(0, dp(6), 0, dp(2));
            w.addView(sleep);
            cycles = line(this, "", 11f, DIMRED);
            w.addView(cycles);
            LinearLayout btns = new LinearLayout(host);
            btns.setPadding(0, dp(10), 0, 0);
            btns.addView(redChip("CHANGE WAKE TIME", () -> pickTime(host, Life.wakeMin(), m -> {
                Prefs.putInt("wake_min", m);
                tick();
            })), lp(0, -2, 1f));
            LinearLayout.LayoutParams ap = lp(0, -2, 1f);
            ap.leftMargin = dp(8);
            btns.addView(redChip("SET ALARM", this::alarm), ap);
            w.addView(btns);
            b.addView(w, gap(this));

            LinearLayout tm = box();
            tm.addView(line(this, "TOMORROW", 10f, DIMRED));
            for (String s : tomorrow()) {
                TextView t = line(this, s, 14f, RED);
                t.setPadding(0, dp(4), 0, dp(2));
                tm.addView(t);
            }
            b.addView(tm, gap(this));

            LinearLayout md = box();
            md.addView(line(this, "HOW WAS TODAY?", 10f, DIMRED));
            md.addView(moodRow(this));
            b.addView(md, gap(this));
            LinearLayout br = box();
            br.addView(line(this, "BREATHE BEFORE SLEEP", 10f, DIMRED));
            br.addView(Widgets.create(host, "breathe"), lp(-1, dp(170)));
            b.addView(br, gap(this));
            View all = pinnedApps(this);
            if (all != null) {
                LinearLayout appsBox = box();
                appsBox.addView(line(this, "YOUR APPS", 10f, DIMRED));
                appsBox.addView(all);
                b.addView(appsBox, gap(this));
            }
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(b);
            outer.addView(sv, lp(-1, 0, 1f));
            LinearLayout nav = new LinearLayout(host);
            nav.setPadding(dp(14), dp(4), dp(14), dp(16));
            String[] n = {"APPS", "MUSIC ⏯", "SETTINGS"};
            Runnable[] r = {() -> host.showDrawer(), () -> HomeKit.media(host, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE),
                () -> host.showSettings()};
            for (int i = 0; i < n.length; i++) {
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(3), 0, dp(3), 0);
                nav.addView(redChip(n[i], r[i]), p);
            }
            outer.addView(nav);
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            tick();
        }

        private LinearLayout box() {
            LinearLayout l = col(this);
            l.setPadding(dp(16), dp(14), dp(16), dp(14));
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setColor(0xFF120605);
            g.setCornerRadius(dp(20));
            g.setStroke(dp(1), 0xFF3A1512);
            l.setBackground(g);
            return l;
        }

        private TextView redChip(String s, Runnable r) {
            TextView t = text(s, 10f, RED);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(16));
            g.setStroke(dp(1), DIMRED);
            t.setBackground(g);
            t.setOnClickListener(v -> r.run());
            return t;
        }

        private void alarm() {
            int m = Life.wakeMin();
            try {
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                i.putExtra(AlarmClock.EXTRA_HOUR, m / 60);
                i.putExtra(AlarmClock.EXTRA_MINUTES, m % 60);
                i.putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA wake up");
                host.startActivity(i);
            } catch (RuntimeException e) {
                host.toast("No alarm app found");
            }
        }

        private List<String> tomorrow() {
            List<String> out = new ArrayList<>();
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, 1);
            out.add(Life.format(c.getTime(), "EEEE d MMMM"));
            List<Object[]> ls = Life.lessons(c.get(Calendar.DAY_OF_WEEK));
            if (!ls.isEmpty()) {
                out.add("First lesson: " + ls.get(0)[1] + " at " + Life.hm((int) ls.get(0)[0]));
            }
            if (!Life.weekend(c)) {
                out.add("Leave at " + Life.hm(Life.leaveMin()));
            }
            String tm = Life.day(c);
            for (String[] f : Life.homework()) {
                if (f[0].compareTo(tm) <= 0 && !"1".equals(f[1])) {
                    out.add("Homework: " + f[2]);
                }
            }
            for (String[] f : Life.tests()) {
                if (f[0].equals(tm)) {
                    out.add("TEST: " + f[1] + " — good luck!");
                }
            }
            for (String[] e : Life.events(tm)) {
                out.add((Integer.parseInt(e[1]) >= 0 ? Life.hm(Integer.parseInt(e[1])) + " " : "") + e[2]);
            }
            if (out.size() == 1) {
                out.add("Nothing planned. Sleep well.");
            }
            return out;
        }

        @Override
        void tick() {
            time.setText(clock());
            int now = Life.nowMin();
            int w = Life.wakeMin();
            int until = ((w - now) % 1440 + 1440) % 1440;
            wake.setText("Wake up at " + Life.hm(w));
            sleep.setText("Sleep now: " + Life.dur(Math.max(0, until - 15)) + " of sleep");
            // full sleep cycles of 90 minutes, plus 15 to fall asleep
            StringBuilder b = new StringBuilder("Best bedtimes: ");
            int[] cy = {6, 5, 4};
            for (int i = 0; i < cy.length; i++) {
                if (i > 0) {
                    b.append("  ·  ");
                }
                b.append(Life.hm(w - cy[i] * 90 - 15)).append(" (").append(cy[i] * 1.5f).append("h)");
            }
            cycles.setText(b.toString().replace(".0h", "h"));
        }
    }

    // ================================================================== COMMUTE

    /** On the way: the bus map with the yellow sign, a leave countdown, music keys and your travel apps. */
    static final class Commute extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView leave;

        Commute(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "COMMUTE", clock);
            leave = line(this, "", 18f, Theme.TEXT);
            leave.setPadding(0, dp(6), 0, 0);
            b.addView(leave);
            b.addView(card(null, Widgets.create(host, "bus")), gap(this));
            LinearLayout media = new LinearLayout(host);
            media.setGravity(Gravity.CENTER);
            String[] k = {"⏮", "⏯", "⏭"};
            int[] code = {KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_NEXT};
            for (int i = 0; i < 3; i++) {
                final int c = code[i];
                TextView t = text(k[i], 24f, Theme.TEXT);
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, dp(10), 0, dp(10));
                t.setOnClickListener(v -> {
                    host.buzz(8);
                    HomeKit.media(host, c);
                });
                press(t);
                media.addView(t, lp(0, -2, 1f));
            }
            b.addView(card("MUSIC", media), gap(this));
            b.addView(card("SONGS", new SongsWidget(host)), gap(this));
            List<AppEntry> travel = HomesD.Folders.sort(host).get("Travel");
            if (travel != null && !travel.isEmpty()) {
                b.addView(card("TRAVEL APPS", HomesD.grid(this, HomesD.slice(travel, 0, 8), 4, 44, true)), gap(this));
            }
            tick();
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            int left = Life.leaveMin() - Life.nowMin();
            leave.setText(!Life.weekend(Calendar.getInstance()) && left > 0 && left < 120 ? "Leave in " + Life.dur(left)
                    : date());
            leave.setTextColor(left > 0 && left <= 5 ? 0xFFFF5A4E : Theme.TEXT);
        }
    }

    // ================================================================== FOCUS

    /** A focus timer (25 minutes work, 5 break), your three most important things today and only your work apps. */
    static final class Focus extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final Ring ring;
        private final TextView startBtn;
        private final TextView done;

        Focus(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "FOCUS", clock);
            LinearLayout t = col(this);
            t.setGravity(Gravity.CENTER_HORIZONTAL);
            ring = new Ring(host);
            ring.setOnClickListener(v -> toggle());
            t.addView(ring, lp(dp(220), dp(220)));
            LinearLayout btns = new LinearLayout(host);
            btns.setPadding(0, dp(10), 0, 0);
            startBtn = small(this, "START", this::toggle);
            btns.addView(startBtn, lp(0, -2, 1f));
            LinearLayout.LayoutParams p2 = lp(0, -2, 1f);
            p2.leftMargin = dp(6);
            btns.addView(small(this, "RESET", () -> {
                Prefs.putString("focus_end", "0");
                Prefs.putString("focus_left", "0");
                Prefs.putInt("focus_mode", 0);
                tick();
            }), p2);
            LinearLayout.LayoutParams p3 = lp(0, -2, 1f);
            p3.leftMargin = dp(6);
            btns.addView(small(this, "25 / 50", () -> {
                Prefs.putInt("focus_len", Prefs.getInt("focus_len", 25) == 25 ? 50 : 25);
                host.toast("Focus: " + Prefs.getInt("focus_len", 25) + " minutes");
                tick();
            }), p3);
            t.addView(btns, lp(-1, -2));
            done = line(this, "", 12f, Theme.ACCENT);
            done.setGravity(Gravity.CENTER);
            done.setPadding(0, dp(8), 0, 0);
            t.addView(done, lp(-1, -2));
            b.addView(card(null, t), gap(this));

            LinearLayout top = col(this);
            for (int i = 0; i < 3; i++) {
                top.addView(topThing(i));
            }
            b.addView(card("TODAY'S TOP 3", top), gap(this));
            List<AppEntry> work = new ArrayList<>();
            Map<String, List<AppEntry>> f = HomesD.Folders.sort(host);
            for (String k : new String[] {"Work", "Tools", "Web"}) {
                if (f.containsKey(k)) {
                    work.addAll(f.get(k));
                }
            }
            b.addView(card("WORK APPS ONLY", HomesD.grid(this, HomesD.slice(work, 0, 12), 4, 44, true)), gap(this));
            tick();
        }

        private View topThing(final int i) {
            LinearLayout r = new LinearLayout(host);
            r.setGravity(Gravity.CENTER_VERTICAL);
            final String key = "top3_" + i;
            String raw = Prefs.getString(key, "");
            boolean fresh = raw.startsWith(Life.today() + "|");
            final boolean[] on = {fresh && raw.length() > 9 && raw.charAt(9) == '1'};
            final TextView box = text(on[0] ? "☑" : "☐", 20f, Theme.ACCENT);
            box.setPadding(0, 0, dp(10), 0);
            r.addView(box);
            final EditText e = new EditText(host);
            e.setHint((i + 1) + ". something important");
            e.setHintTextColor(Theme.DIM);
            e.setTextColor(Theme.TEXT);
            e.setTextSize(14f);
            e.setSingleLine(true);
            e.setBackground(null);
            e.setText(fresh && raw.length() > 11 ? raw.substring(11) : "");
            Runnable save = () -> Prefs.putString(key, Life.today() + "|" + (on[0] ? "1" : "0") + "|" + e.getText());
            e.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    save.run();
                }
            });
            box.setOnClickListener(v -> {
                on[0] = !on[0];
                box.setText(on[0] ? "☑" : "☐");
                save.run();
                host.buzz(8);
            });
            r.addView(e, lp(0, -2, 1f));
            return r;
        }

        private long endAt() {
            try {
                return Long.parseLong(Prefs.getString("focus_end", "0"));
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        private long pausedLeft() {
            try {
                return Long.parseLong(Prefs.getString("focus_left", "0"));
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        private long length() {
            return (Prefs.getInt("focus_mode", 0) == 0 ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
        }

        private void toggle() {
            long end = endAt();
            long now = System.currentTimeMillis();
            if (end > now) {
                Prefs.putString("focus_left", String.valueOf(end - now));
                Prefs.putString("focus_end", "0");
            } else {
                long left = pausedLeft() > 0 ? pausedLeft() : length();
                Prefs.putString("focus_end", String.valueOf(now + left));
                Prefs.putString("focus_left", "0");
            }
            host.buzz(10);
            tick();
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            long now = System.currentTimeMillis();
            long end = endAt();
            boolean work = Prefs.getInt("focus_mode", 0) == 0;
            long len = length();
            long left;
            if (end > 0 && end <= now) {
                // a round finished
                Prefs.putString("focus_end", "0");
                Prefs.putString("focus_left", "0");
                if (work) {
                    Life.addFocus();
                    host.toast("Focus done! Take 5 minutes ☕");
                    host.confetti(getWidth() / 2f, getHeight() / 3f);
                } else {
                    host.toast("Break over. Ready for the next one?");
                }
                Sfx.play(Sfx.WIN);
                host.buzz(60);
                Prefs.putInt("focus_mode", work ? 1 : 0);
                work = !work;
                len = length();
                left = len;
                end = 0;
            } else if (end > now) {
                left = end - now;
            } else {
                left = pausedLeft() > 0 ? pausedLeft() : len;
            }
            ring.set(1f - left / (float) len, String.format(Locale.ROOT, "%02d:%02d", left / 60000, (left / 1000) % 60),
                    work ? "FOCUS" : "BREAK", work ? Theme.ACCENT : 0xFF4CD964);
            startBtn.setText(end > now ? "PAUSE" : pausedLeft() > 0 ? "GO ON" : "START");
            int n = Life.focusDone(Life.today());
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < Math.min(n, 12); i++) {
                s.append("🍅");
            }
            done.setText(n == 0 ? "no focus rounds yet today" : s + "  " + n + " today");
        }

        static final class Ring extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float v;
            private String big = "";
            private String mode = "";
            private int color = Theme.ACCENT;

            Ring(android.content.Context c) {
                super(c);
            }

            void set(float v, String big, String mode, int color) {
                this.v = v;
                this.big = big;
                this.mode = mode;
                this.color = color;
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - 10 * d;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(12 * d);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setColor((Theme.TEXT & 0xFFFFFF) | 0x1A000000);
                c.drawCircle(cx, cy, r, p);
                p.setColor(color);
                c.drawArc(cx - r, cy - r, cx + r, cy + r, -90, 360 * Math.max(0.002f, v), false, p);
                p.setStyle(Paint.Style.FILL);
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(Theme.TEXT);
                p.setTypeface(Theme.LIGHT);
                p.setTextSize(48 * d);
                c.drawText(big, cx, cy + 14 * d, p);
                p.setTextSize(12 * d);
                p.setColor(color);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                c.drawText(mode, cx, cy - 34 * d, p);
                p.setColor(Theme.DIM);
                p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                p.setTextSize(10 * d);
                c.drawText("tap to start / pause", cx, cy + 40 * d, p);
            }
        }
    }

    // ================================================================== MONEY

    /** Pocket money on the home screen, a savings goal you fill up and how the month went. */
    static final class Money extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView goalName;
        private final TextView goalAmt;
        private final Bar goalBar;
        private final LinearLayout month;

        Money(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "MONEY", clock);
            b.addView(card(null, new MoneyWidget(host)), gap(this));
            LinearLayout g = col(this);
            goalName = line(this, "", 18f, Theme.TEXT);
            g.addView(goalName);
            goalAmt = line(this, "", 12f, Theme.DIM);
            g.addView(goalAmt);
            goalBar = new Bar(host);
            LinearLayout.LayoutParams bp = lp(-1, dp(8));
            bp.setMargins(0, dp(8), 0, dp(8));
            g.addView(goalBar, bp);
            LinearLayout r = new LinearLayout(host);
            int[] steps = {5, 10, 20, -5};
            for (int s : steps) {
                final int k = s;
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                r.addView(small(this, (k > 0 ? "+" : "") + k, () -> {
                    float saved = Prefs.getInt("goal_saved", 0) + k;
                    Prefs.putInt("goal_saved", Math.max(0, (int) saved));
                    host.buzz(8);
                    fillGoal();
                }), p);
            }
            r.addView(small(this, "EDIT", () -> ask(host, "Saving for what?", "e.g. New shoes", Prefs.getString("goal_name", ""),
                    false, n -> ask(host, "How much (CHF)?", "120", String.valueOf(Prefs.getInt("goal_target", 120)), false, t -> {
                        Prefs.putString("goal_name", n.trim());
                        try {
                            Prefs.putInt("goal_target", Math.max(1, Integer.parseInt(t.trim())));
                        } catch (NumberFormatException ignored) {
                            // keep the old one
                        }
                        fillGoal();
                    }))), lp(0, -2, 1.2f));
            g.addView(r);
            b.addView(card("SAVING GOAL", g), gap(this));
            month = col(this);
            b.addView(card("THIS MONTH", month), gap(this));
            fillGoal();
            fillMonth();
            tick();
        }

        private void fillGoal() {
            String n = Prefs.getString("goal_name", "");
            int target = Prefs.getInt("goal_target", 120);
            int saved = Prefs.getInt("goal_saved", 0);
            goalName.setText(n.isEmpty() ? "Tap EDIT to set a goal" : n);
            goalAmt.setText("CHF " + saved + " of " + target + (saved >= target ? "   🎉 you made it!" : "   ·   "
                    + (target - saved) + " to go"));
            goalBar.set(saved / (float) target, saved >= target ? 0xFF4CD964 : Theme.ACCENT);
        }

        private void fillMonth() {
            month.removeAllViews();
            Calendar c = Calendar.getInstance();
            c.set(Calendar.DAY_OF_MONTH, 1);
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            long start = c.getTimeInMillis();
            long[] weeks = new long[6];
            long in = 0;
            long out = 0;
            for (Object[] o : MoneyWidget.entries()) {
                long t = (long) o[0];
                long cents = (long) o[1];
                if (t < start) {
                    continue;
                }
                Calendar k = Calendar.getInstance();
                k.setTimeInMillis(t);
                int w = Math.min(5, (k.get(Calendar.DAY_OF_MONTH) - 1) / 7);
                if (cents < 0) {
                    weeks[w] -= cents;
                    out -= cents;
                } else {
                    in += cents;
                }
            }
            month.addView(line(this, "spent " + MoneyWidget.chf(out) + "   ·   got " + MoneyWidget.chf(in), 13f, Theme.TEXT));
            long max = 1;
            for (long w : weeks) {
                max = Math.max(max, w);
            }
            for (int i = 0; i < 5; i++) {
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, dp(4), 0, dp(4));
                r.addView(line(this, "week " + (i + 1), 10f, Theme.DIM), lp(dp(54), -2));
                Bar bar = new Bar(host);
                bar.set(weeks[i] / (float) max, weeks[i] > MoneyWidget.budget() * 100 ? 0xFFFF5A4E : Theme.ACCENT);
                r.addView(bar, lp(0, dp(8), 1f));
                TextView v = line(this, MoneyWidget.chf(weeks[i]).replace("CHF ", ""), 10f, Theme.DIM);
                v.setPadding(dp(8), 0, 0, 0);
                r.addView(v, lp(dp(60), -2));
                month.addView(r);
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
        }
    }

    // ================================================================== HEALTH

    /** Water, quick workout counters with your week, habits and the mood calendar. */
    static final class Health extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final LinearLayout work;

        Health(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "HEALTH", clock);
            b.addView(card("WATER", sized(Widgets.create(host, "water"))), gap(this));
            work = col(this);
            b.addView(card("WORKOUT  ·  tap + after you did it", work), gap(this));
            b.addView(card("HABITS", sized(Widgets.create(host, "habits"))), gap(this));
            b.addView(card("MOOD", new MoodCalendar(host)), gap(this));
            fillWork();
            tick();
        }

        private void fillWork() {
            work.removeAllViews();
            for (int i = 0; i < Life.WORKOUTS.length; i++) {
                final int k = i;
                int todayN = Life.workout(Life.today(), i);
                int week = 0;
                for (int dd = 0; dd < 7; dd++) {
                    week += Life.workout(Life.dayPlus(-dd), i);
                }
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, dp(4), 0, dp(4));
                LinearLayout txt = col(this);
                txt.addView(line(this, Life.WORKOUTS[i], 14f, Theme.TEXT));
                txt.addView(line(this, "today " + todayN + "   ·   7 days " + week, 10f, Theme.DIM));
                r.addView(txt, lp(0, -2, 1f));
                r.addView(small(this, "+" + Life.STEPS[i], () -> {
                    Life.addWorkout(k, Life.STEPS[k]);
                    host.buzz(10);
                    fillWork();
                }));
                work.addView(r, lp(-1, -2));
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
        }
    }

    // ================================================================== PLANNER

    /** Your week, day by day: events you add, homework due and tests. Tap a day to add something. */
    static final class Planner extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final LinearLayout days;
        private final TextView title;
        private int week;

        Planner(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "PLANNER", clock);
            LinearLayout nav = new LinearLayout(host);
            nav.setGravity(Gravity.CENTER_VERTICAL);
            nav.setPadding(0, dp(8), 0, 0);
            nav.addView(small(this, "‹", () -> {
                week--;
                fill();
            }));
            title = text("", 13f, Theme.TEXT);
            title.setGravity(Gravity.CENTER);
            nav.addView(title, lp(0, -2, 1f));
            nav.addView(small(this, "›", () -> {
                week++;
                fill();
            }));
            b.addView(nav, lp(-1, -2));
            days = col(this);
            b.addView(days, lp(-1, -2));
            fill();
            tick();
        }

        private void fill() {
            days.removeAllViews();
            Calendar c = Calendar.getInstance();
            int back = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7;
            c.add(Calendar.DAY_OF_MONTH, -back + week * 7);
            title.setText(week == 0 ? "THIS WEEK" : Life.format(c.getTime(), "d MMM") + " – "
                    + Life.format(new Date(c.getTimeInMillis() + 6 * 86400000L), "d MMM"));
            String today = Life.today();
            for (int i = 0; i < 7; i++) {
                final String day = Life.day(c);
                boolean isToday = day.equals(today);
                LinearLayout box = col(this);
                box.setPadding(dp(14), dp(10), dp(14), dp(10));
                box.setBackground(Theme.rounded(isToday ? Theme.BG2 : Theme.PANEL, 16f, host));
                LinearLayout head = new LinearLayout(host);
                TextView dn = line(this, Life.format(c.getTime(), "EEEE d"), 14f, isToday ? Theme.ACCENT : Theme.TEXT);
                dn.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                head.addView(dn, lp(0, -2, 1f));
                head.addView(line(this, "+", 18f, Theme.ACCENT));
                box.addView(head);
                int n = 0;
                for (final String[] e : Life.events(day)) {
                    int m = Integer.parseInt(e[1]);
                    TextView t = line(this, (m >= 0 ? Life.hm(m) + "  " : "•  ") + e[2], 13f, Theme.TEXT);
                    t.setPadding(0, dp(3), 0, dp(3));
                    t.setOnLongClickListener(v -> {
                        Life.removeEvent(e);
                        fill();
                        return true;
                    });
                    box.addView(t);
                    n++;
                }
                for (String[] f : Life.homework()) {
                    if (f[0].equals(day) && !"1".equals(f[1])) {
                        box.addView(line(this, "📚  " + f[2], 12f, 0xFFFFB347));
                        n++;
                    }
                }
                for (String[] f : Life.tests()) {
                    if (f[0].equals(day)) {
                        box.addView(line(this, "❗  TEST: " + f[1], 12f, 0xFFFF5A4E));
                        n++;
                    }
                }
                List<Object[]> ls = Life.lessons(c.get(Calendar.DAY_OF_WEEK));
                if (!ls.isEmpty()) {
                    box.addView(line(this, "school " + Life.hm((int) ls.get(0)[0]) + "  ·  " + ls.size() + " lessons", 10f,
                            Theme.DIM));
                    n++;
                }
                if (n == 0) {
                    box.addView(line(this, "free", 11f, Theme.DIM));
                }
                box.setOnClickListener(v -> ask(host, "Add to " + Life.nice(day), "e.g. Football training", "", false, s -> {
                    if (s.trim().isEmpty()) {
                        return;
                    }
                    new AlertDialog.Builder(host).setTitle("At a time?").setItems(new String[] {"Pick a time", "All day"},
                            (d, w) -> {
                                if (w == 0) {
                                    pickTime(host, 18 * 60, m -> {
                                        Life.addEvent(day, m, s.trim());
                                        fill();
                                    });
                                } else {
                                    Life.addEvent(day, -1, s.trim());
                                    fill();
                                }
                            }).show();
                }));
                LinearLayout.LayoutParams p = lp(-1, -2);
                p.topMargin = dp(8);
                days.addView(box, p);
                c.add(Calendar.DAY_OF_MONTH, 1);
            }
            days.addView(line(this, "Tap a day to add something, hold an entry to delete it.", 10f, Theme.DIM), gap(this));
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
        }
    }

    // ================================================================== JOURNAL

    /** One short entry a day with your mood, a streak, and what you wrote a week, a month and a year ago. */
    static final class Journal extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView streak;

        Journal(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "JOURNAL", clock);
            b.addView(line(this, Life.format(new Date(), "EEEE, d MMMM yyyy"), 18f, Theme.TEXT), gap(this));
            streak = line(this, "", 11f, Theme.ACCENT);
            b.addView(streak);
            final EditText e = new EditText(host);
            e.setHint("How was your day? One line is enough.");
            e.setHintTextColor(Theme.DIM);
            e.setTextColor(Theme.TEXT);
            e.setTextSize(15f);
            e.setMinLines(4);
            e.setGravity(Gravity.TOP | Gravity.START);
            e.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
            e.setPadding(dp(16), dp(14), dp(16), dp(14));
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setText(Life.journal(Life.today()));
            e.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b2, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b2, int c) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    Life.setJournal(Life.today(), s.toString());
                    tick();
                }
            });
            b.addView(e, gap(this));
            b.addView(card("MOOD", moodRow(this)), gap(this));
            LinearLayout otd = col(this);
            int[] back = {7, 30, 365};
            String[] names = {"A week ago", "A month ago", "A year ago"};
            boolean any = false;
            for (int i = 0; i < back.length; i++) {
                String t = Life.journal(Life.dayPlus(-back[i]));
                if (!t.trim().isEmpty()) {
                    otd.addView(line(this, names[i], 10f, Theme.ACCENT));
                    TextView x = line(this, t, 13f, Theme.TEXT);
                    x.setPadding(0, dp(2), 0, dp(8));
                    otd.addView(x);
                    any = true;
                }
            }
            if (!any) {
                otd.addView(line(this, "Keep writing: in a week you'll see what you wrote today.", 12f, Theme.DIM));
            }
            b.addView(card("ON THIS DAY", otd), gap(this));
            LinearLayout past = col(this);
            List<String> days = Life.lines("journal_days");
            int shown = 0;
            for (int i = days.size() - 1; i >= 0 && shown < 15; i--) {
                final String day = days.get(i);
                if (day.equals(Life.today())) {
                    continue;
                }
                final String t = Life.journal(day);
                if (t.trim().isEmpty()) {
                    continue;
                }
                TextView x = line(this, Life.nice(day) + ":  " + t.replace('\n', ' '), 12f, Theme.TEXT);
                x.setSingleLine(true);
                x.setEllipsize(android.text.TextUtils.TruncateAt.END);
                x.setPadding(0, dp(5), 0, dp(5));
                x.setOnClickListener(v -> new AlertDialog.Builder(host).setTitle(Life.nice(day)).setMessage(t)
                        .setPositiveButton("OK", null).show());
                past.addView(x);
                shown++;
            }
            if (shown > 0) {
                b.addView(card("EARLIER", past), gap(this));
            }
            tick();
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            int s = Life.journalStreak();
            streak.setText(s == 0 ? "write something to start a streak" : "🔥 " + s + (s == 1 ? " day" : " days")
                    + " in a row");
        }
    }

    // ================================================================== STATS

    /** What you did with your phone today: how many apps you opened, your top apps, when, your mood this week and
     *  more. */
    static final class Stats extends AltHome {
        private final TextView[] clock = new TextView[1];

        Stats(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "STATS", clock);
            List<Object[]> today = HomeKit.today();
            Map<String, Integer> count = new HashMap<>();
            int[] hours = new int[24];
            Calendar c = Calendar.getInstance();
            for (Object[] o : today) {
                String p = (String) o[0];
                count.put(p, (count.containsKey(p) ? count.get(p) : 0) + 1);
                c.setTimeInMillis((long) o[1]);
                hours[c.get(Calendar.HOUR_OF_DAY)]++;
            }
            LinearLayout big = new LinearLayout(host);
            big.addView(stat(today.size() + "", "apps opened"), lp(0, -2, 1f));
            big.addView(stat(count.size() + "", "different apps"), lp(0, -2, 1f));
            big.addView(stat(Life.focusDone(Life.today()) + "", "focus rounds"), lp(0, -2, 1f));
            b.addView(big, gap(this));

            LinearLayout top = col(this);
            List<String> keys = new ArrayList<>(count.keySet());
            keys.sort((x, y) -> count.get(y) - count.get(x));
            int max = keys.isEmpty() ? 1 : count.get(keys.get(0));
            for (int i = 0; i < Math.min(6, keys.size()); i++) {
                AppEntry e = host.repo.find(keys.get(i));
                if (e == null) {
                    continue;
                }
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, dp(4), 0, dp(4));
                r.addView(line(this, e.label, 12f, Theme.TEXT), lp(dp(96), -2));
                Bar bar = new Bar(host);
                bar.set(count.get(keys.get(i)) / (float) max, HomeKit.color(host, e));
                r.addView(bar, lp(0, dp(10), 1f));
                TextView v = line(this, count.get(keys.get(i)) + "×", 11f, Theme.DIM);
                v.setPadding(dp(8), 0, 0, 0);
                r.addView(v);
                top.addView(r);
            }
            if (keys.isEmpty()) {
                top.addView(line(this, "Open some apps and they show up here.", 12f, Theme.DIM));
            }
            b.addView(card("TOP APPS TODAY", top), gap(this));
            b.addView(card("WHEN  ·  apps opened per hour", new Hours(host, hours)), gap(this));

            LinearLayout mood = new LinearLayout(host);
            for (int i = 6; i >= 0; i--) {
                String day = Life.dayPlus(-i);
                float s = MoodLog.score(day);
                LinearLayout cell = col(this);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                TextView f = text(s < 0 ? "·" : MoodLog.FACES[MoodLog.faceOf(s)], 22f, Theme.DIM);
                cell.addView(f);
                cell.addView(text(Life.format(Life.parse(day).getTime(), "EEE"), 9f, Theme.DIM));
                mood.addView(cell, lp(0, -2, 1f));
            }
            b.addView(card("MOOD THIS WEEK", mood), gap(this));
            long spent = 0;
            long start = MoneyWidget.weekStart();
            for (Object[] o : MoneyWidget.entries()) {
                if ((long) o[0] >= start && (long) o[1] < 0) {
                    spent -= (long) o[1];
                }
            }
            LinearLayout misc = col(this);
            misc.addView(line(this, "Spent this week: " + MoneyWidget.chf(spent), 13f, Theme.TEXT));
            misc.addView(line(this, "Battery: " + battery() + "%", 13f, Theme.TEXT));
            misc.addView(line(this, "Journal streak: " + Life.journalStreak() + " days", 13f, Theme.TEXT));
            int w = 0;
            for (int dd = 0; dd < 7; dd++) {
                w += Life.workout(Life.dayPlus(-dd), 0);
            }
            misc.addView(line(this, "Push-ups in 7 days: " + w, 13f, Theme.TEXT));
            b.addView(card("MORE", misc), gap(this));
            tick();
        }

        private View stat(String big, String small) {
            LinearLayout c = col(this);
            c.setGravity(Gravity.CENTER);
            c.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
            c.setPadding(0, dp(12), 0, dp(12));
            TextView t = text(big, 28f, Theme.TEXT);
            t.setTypeface(Theme.LIGHT);
            c.addView(t);
            c.addView(text(small, 9f, Theme.DIM));
            LinearLayout.LayoutParams p = lp(0, -2, 1f);
            p.setMargins(dp(3), 0, dp(3), 0);
            c.setLayoutParams(p);
            return c;
        }

        static final class Hours extends View {
            private final int[] h;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Hours(android.content.Context c, int[] h) {
                super(c);
                this.h = h;
            }

            @Override
            protected void onMeasure(int ws, int hs) {
                setMeasuredDimension(MeasureSpec.getSize(ws), Math.round(110 * getResources().getDisplayMetrics().density));
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                int max = 1;
                for (int v : h) {
                    max = Math.max(max, v);
                }
                float bw = getWidth() / 24f;
                float base = getHeight() - 16 * d;
                int now = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                for (int i = 0; i < 24; i++) {
                    float bh = (base - 4 * d) * h[i] / max;
                    p.setColor(i == now ? Theme.ACCENT : (Theme.ACCENT & 0xFFFFFF) | 0x77000000);
                    c.drawRoundRect(new RectF(i * bw + 1.5f * d, base - Math.max(2 * d, bh), (i + 1) * bw - 1.5f * d, base),
                            2 * d, 2 * d, p);
                    if (i % 6 == 0) {
                        p.setColor(Theme.DIM);
                        p.setTextSize(9 * d);
                        c.drawText(String.valueOf(i), i * bw, getHeight() - 2 * d, p);
                    }
                }
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
        }
    }
}
