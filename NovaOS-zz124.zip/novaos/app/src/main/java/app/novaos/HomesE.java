package app.novaos;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;

/**
 * Ten fun home screens that move: AQUARIUM (apps are fish, tap the water to feed them), CLAW (grab an app with the
 * claw machine), JACKPOT (spin the slot machine), SKYLINE (apps are buildings in a city that follows the real time
 * of day), MAGNETS (drag app magnets around a fridge), BALLOONS (pop a balloon to open its app), RAIN (apps are rain
 * drops on a window, with a wiper), LAVA (a lava lamp), GARDEN (flowers that grow the more you use the app) and
 * BOARD GAME (roll the dice and move around a board of apps).
 */
final class HomesE {
    private HomesE() {
    }

    // ------------------------------------------------------------------ shared

    /** A view that animates itself while it is on screen. Tap an app to open it, hold it for the app menu. */
    abstract static class Scene extends View {
        final NovaActivity host;
        final float d;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Random rnd = new Random();
        final RectF r = new RectF();
        private final GestureDetector gd;
        private long last;
        float t;

        Scene(NovaActivity h) {
            super(h);
            host = h;
            d = getResources().getDisplayMetrics().density;
            gd = new GestureDetector(h, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    tap(e.getX(), e.getY());
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    AppEntry a = hit(e.getX(), e.getY());
                    if (a != null) {
                        host.appMenu(a);
                    }
                }
            });
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            gd.onTouchEvent(e);
            return true;
        }

        void tap(float x, float y) {
            AppEntry a = hit(x, y);
            if (a != null) {
                host.launch(a);
            }
        }

        AppEntry hit(float x, float y) {
            return null;
        }

        abstract void step(float dt);

        abstract void paint(Canvas c);

        @Override
        protected void onDraw(Canvas c) {
            long now = SystemClock.uptimeMillis();
            float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1000f);
            last = now;
            t += dt;
            if (getWidth() > 0) {
                step(dt);
                paint(c);
            }
            postInvalidateOnAnimation();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            last = 0;
        }

        void icon(Canvas c, AppEntry e, float cx, float cy, float size) {
            Bitmap b = HomeKit.icon(host, e, Math.round(28 * d));
            r.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);
            c.drawBitmap(b, null, r, null);
        }

        void label(Canvas c, String s, float x, float y, float sp, int color) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(sp * d);
            p.setColor(color);
            if (s.length() > 12) {
                s = s.substring(0, 11) + "…";
            }
            c.drawText(s, x, y, p);
        }

        String clock() {
            return new java.text.SimpleDateFormat(Prefs.getBool("clock_12h", false) ? "h:mm" : "HH:mm",
                    java.util.Locale.getDefault()).format(new java.util.Date());
        }
    }

    /** The scene filling the screen, with optional controls under it and the usual bar at the bottom. */
    static void frame(AltHome h, Scene s, View controls) {
        LinearLayout col = new LinearLayout(h.host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(s, lp(-1, 0, 1f));
        if (controls != null) {
            col.addView(controls, lp(-1, -2));
        }
        col.addView(h.bar());
        h.addView(col, new FrameLayout.LayoutParams(-1, -1));
    }

    static TextView button(AltHome h, String s, int bg, int fg) {
        TextView t = h.text(s, 14f, fg);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(bg, 18f, h.host));
        t.setPadding(0, h.dp(14), 0, h.dp(14));
        press(t);
        return t;
    }

    // ================================================================== AQUARIUM

    /** Your apps swim around as fish. Tap a fish to open it, tap the water to drop food and watch them come. */
    static final class Aquarium extends AltHome {
        Aquarium(NovaActivity host) {
            super(host);
            frame(this, new Tank(host, appsFor(12)), null);
        }

        static final class Tank extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> fish = new ArrayList<>(); // x, y base, vx, phase, y now, happy
            private final List<float[]> food = new ArrayList<>();
            private final List<float[]> bubbles = new ArrayList<>();
            private boolean placed;

            Tank(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
            }

            private void place() {
                float top = 110 * d;
                float bottom = getHeight() - 90 * d;
                for (int i = 0; i < apps.size(); i++) {
                    float y = top + (bottom - top) * (i + 0.5f) / apps.size();
                    float speed = (25 + rnd.nextInt(30)) * d * (rnd.nextBoolean() ? 1 : -1);
                    fish.add(new float[] {rnd.nextFloat() * getWidth(), y, speed, rnd.nextFloat() * 6f, y, 0});
                }
                placed = true;
            }

            @Override
            void step(float dt) {
                if (!placed) {
                    place();
                }
                float w = getWidth();
                for (float[] f : fish) {
                    float[] near = null;
                    float best = 220 * d;
                    for (float[] fd : food) {
                        float dist = (float) Math.hypot(fd[0] - f[0], fd[1] - f[4]);
                        if (dist < best) {
                            best = dist;
                            near = fd;
                        }
                    }
                    if (near != null) {
                        float sp = Math.abs(f[2]) * 1.8f;
                        f[2] = Math.signum(near[0] - f[0]) * Math.max(Math.abs(f[2]), 30 * d);
                        f[0] += Math.signum(near[0] - f[0]) * sp * dt;
                        f[1] += (near[1] - f[1]) * Math.min(1f, dt * 1.5f);
                        if (best < 18 * d) {
                            food.remove(near);
                            f[5] = 1f;
                            host.buzz(3);
                        }
                    } else {
                        f[0] += f[2] * dt;
                    }
                    if (f[0] < 30 * d && f[2] < 0 || f[0] > w - 30 * d && f[2] > 0) {
                        f[2] = -f[2];
                    }
                    f[4] = f[1] + (float) Math.sin(t * 1.6f + f[3]) * 6 * d;
                    f[5] = Math.max(0f, f[5] - dt);
                }
                for (int i = food.size() - 1; i >= 0; i--) {
                    float[] fd = food.get(i);
                    fd[1] += 22 * d * dt;
                    if (fd[1] > getHeight() - 70 * d) {
                        food.remove(i);
                    }
                }
                if (rnd.nextFloat() < dt * 3) {
                    bubbles.add(new float[] {40 * d + rnd.nextFloat() * 14 * d, getHeight() - 60 * d, 2 + rnd.nextFloat() * 4});
                }
                for (int i = bubbles.size() - 1; i >= 0; i--) {
                    float[] b = bubbles.get(i);
                    b[1] -= 60 * d * dt;
                    b[0] += (float) Math.sin(t * 3 + b[2]) * 0.4f * d;
                    if (b[1] < 0) {
                        bubbles.remove(i);
                    }
                }
            }

            @Override
            void tap(float x, float y) {
                AppEntry a = hit(x, y);
                if (a != null) {
                    host.launch(a);
                    return;
                }
                for (int i = 0; i < 5; i++) {
                    food.add(new float[] {x + (rnd.nextFloat() - 0.5f) * 40 * d, y + rnd.nextFloat() * 10 * d});
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = fish.size() - 1; i >= 0; i--) {
                    float[] f = fish.get(i);
                    if (Math.abs(x - f[0]) < 40 * d && Math.abs(y - f[4]) < 28 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, 0xFF2F8FCF, 0xFF0A2340, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                // light rays
                p.setColor(0x14FFFFFF);
                for (int i = 0; i < 4; i++) {
                    float x = w * (0.15f + i * 0.25f) + (float) Math.sin(t * 0.4f + i) * 30 * d;
                    Path ray = new Path();
                    ray.moveTo(x, 0);
                    ray.lineTo(x + 40 * d, 0);
                    ray.lineTo(x + 120 * d, h * 0.8f);
                    ray.lineTo(x + 40 * d, h * 0.8f);
                    ray.close();
                    c.drawPath(ray, p);
                }
                // sand
                Path sand = new Path();
                sand.moveTo(0, h);
                sand.lineTo(0, h - 50 * d);
                for (float x = 0; x <= w; x += 20 * d) {
                    sand.lineTo(x, h - 50 * d - (float) Math.sin(x / (60 * d)) * 8 * d);
                }
                sand.lineTo(w, h);
                sand.close();
                p.setColor(0xFFD9B97A);
                c.drawPath(sand, p);
                // seaweed
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(7 * d);
                for (int k = 0; k < 5; k++) {
                    float bx = w * (0.1f + k * 0.21f);
                    p.setColor(k % 2 == 0 ? 0xFF2E8B57 : 0xFF3CB371);
                    Path s = new Path();
                    s.moveTo(bx, h - 45 * d);
                    float sw = (float) Math.sin(t * 1.2f + k) * 16 * d;
                    s.cubicTo(bx + sw, h - 100 * d, bx - sw, h - 140 * d, bx + sw * 0.6f, h - (170 + k * 12) * d);
                    c.drawPath(s, p);
                }
                p.setStyle(Paint.Style.FILL);
                // bubbles
                p.setColor(0x66FFFFFF);
                for (float[] b : bubbles) {
                    c.drawCircle(b[0], b[1], b[2] * d, p);
                }
                // food
                p.setColor(0xFFE8A33D);
                for (float[] fd : food) {
                    c.drawCircle(fd[0], fd[1], 3 * d, p);
                }
                // fish
                for (int i = 0; i < fish.size(); i++) {
                    float[] f = fish.get(i);
                    AppEntry e = apps.get(i);
                    int col = HomeKit.color(host, e);
                    c.save();
                    c.translate(f[0], f[4]);
                    if (f[2] < 0) {
                        c.scale(-1, 1);
                    }
                    float wag = (float) Math.sin(t * 10 + f[3]) * 5 * d;
                    p.setColor(HomeKit.darker(col, 0.75f));
                    Path tail = new Path();
                    tail.moveTo(-26 * d, 0);
                    tail.lineTo(-46 * d, -16 * d + wag);
                    tail.lineTo(-46 * d, 16 * d + wag);
                    tail.close();
                    c.drawPath(tail, p);
                    p.setColor(col);
                    r.set(-34 * d, -22 * d, 34 * d, 22 * d);
                    c.drawOval(r, p);
                    p.setColor(0xFFFFFFFF);
                    c.drawCircle(22 * d, -6 * d, 4.5f * d, p);
                    p.setColor(0xFF111111);
                    c.drawCircle(23 * d, -6 * d, 2.2f * d, p);
                    c.restore();
                    icon(c, e, f[0] + (f[2] < 0 ? 4 : -4) * d, f[4], 24 * d);
                    label(c, e.label, f[0], f[4] + 36 * d, 10f, 0xDDFFFFFF);
                    if (f[5] > 0) {
                        label(c, "♥", f[0], f[4] - 28 * d - (1 - f[5]) * 20 * d, 14f, 0xFFFF6B8A);
                    }
                }
                label(c, clock(), w / 2, 70 * d, 40f, 0xCCFFFFFF);
                label(c, "tap the water to feed them", w / 2, 92 * d, 10f, 0x88FFFFFF);
            }
        }
    }

    // ================================================================== CLAW

    /** A claw machine full of app prizes. Move the claw with the arrows, press DROP, and the app you grab opens. */
    static final class Claw extends AltHome {
        private final Machine m;

        Claw(NovaActivity host) {
            super(host);
            m = new Machine(host, appsFor(14));
            LinearLayout ctl = new LinearLayout(host);
            ctl.setPadding(dp(14), dp(10), dp(14), dp(4));
            ctl.setBackgroundColor(0xFF2A0F3D);
            TextView left = button(this, "◀", 0xFF5B2A86, 0xFFFFFFFF);
            TextView drop = button(this, "DROP", 0xFFFF3D7F, 0xFFFFFFFF);
            TextView right = button(this, "▶", 0xFF5B2A86, 0xFFFFFFFF);
            hold(left, -1);
            hold(right, 1);
            drop.setOnClickListener(v -> m.drop());
            ctl.addView(left, lp(0, -2, 1f));
            LinearLayout.LayoutParams dp1 = lp(0, -2, 1.4f);
            dp1.setMargins(dp(10), 0, dp(10), 0);
            ctl.addView(drop, dp1);
            ctl.addView(right, lp(0, -2, 1f));
            frame(this, m, ctl);
        }

        private void hold(View v, final int dir) {
            v.setOnTouchListener((x, e) -> {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    m.move = dir;
                    x.setScaleX(0.94f);
                    x.setScaleY(0.94f);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    m.move = 0;
                    x.setScaleX(1f);
                    x.setScaleY(1f);
                }
                return true;
            });
        }

        static final class Machine extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> prizes = new ArrayList<>(); // x, y, app index, visible
            int move;
            private float clawX = -1;
            private float clawY;
            private float open = 1f;
            private int state; // 0 idle, 1 down, 2 grab, 3 up, 4 to chute, 5 drop, 6 back
            private float timer;
            private float[] held;
            private float fallY = -1;

            Machine(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
            }

            private float rail() {
                return 90 * d;
            }

            private float chuteX() {
                return 52 * d;
            }

            private void layoutPrizes() {
                float rad = 26 * d;
                float floor = getHeight() - 24 * d;
                float left = 110 * d;
                float right = getWidth() - 20 * d;
                int perRow = Math.max(2, (int) ((right - left) / (rad * 2.1f)));
                for (int i = 0; i < apps.size(); i++) {
                    int row = i / perRow;
                    int k = i % perRow;
                    float x = left + rad + k * rad * 2.1f + (row % 2) * rad;
                    float y = floor - rad - row * rad * 1.75f;
                    prizes.add(new float[] {Math.min(x, right - rad), y, i, 1});
                }
                clawX = getWidth() / 2f;
                clawY = rail() + 30 * d;
            }

            void drop() {
                if (state == 0) {
                    state = 1;
                    host.buzz(10);
                }
            }

            @Override
            void step(float dt) {
                if (clawX < 0) {
                    layoutPrizes();
                }
                float top = rail() + 30 * d;
                float speed = 170 * d;
                switch (state) {
                    case 0:
                        clawX = Math.max(70 * d, Math.min(getWidth() - 40 * d, clawX + move * speed * dt));
                        break;
                    case 1: {
                        clawY += 220 * d * dt;
                        float stop = getHeight() - 40 * d;
                        for (float[] pr : prizes) {
                            if (pr[3] > 0 && Math.abs(pr[0] - clawX) < 24 * d) {
                                stop = Math.min(stop, pr[1] - 30 * d);
                            }
                        }
                        if (clawY >= stop) {
                            clawY = stop;
                            state = 2;
                            timer = 0;
                        }
                        break;
                    }
                    case 2:
                        timer += dt;
                        open = Math.max(0f, 1f - timer * 2.5f);
                        if (timer > 0.45f) {
                            float best = 30 * d;
                            for (float[] pr : prizes) {
                                float dd = (float) Math.hypot(pr[0] - clawX, pr[1] - (clawY + 30 * d));
                                if (pr[3] > 0 && dd < best) {
                                    best = dd;
                                    held = pr;
                                }
                            }
                            if (held != null) {
                                held[3] = 0;
                                host.buzz(15);
                            }
                            state = 3;
                        }
                        break;
                    case 3:
                        clawY -= 170 * d * dt;
                        if (clawY <= top) {
                            clawY = top;
                            state = held != null ? 4 : 6;
                        }
                        break;
                    case 4:
                        clawX -= speed * dt;
                        if (clawX <= chuteX()) {
                            clawX = chuteX();
                            state = 5;
                            timer = 0;
                        }
                        break;
                    case 5:
                        timer += dt;
                        open = Math.min(1f, timer * 3f);
                        if (held != null && fallY < 0) {
                            fallY = clawY + 30 * d;
                        }
                        if (fallY >= 0) {
                            fallY += 600 * d * dt;
                            if (fallY > getHeight()) {
                                final AppEntry won = apps.get((int) held[2]);
                                final float[] back = held;
                                held = null;
                                fallY = -1;
                                host.confetti(chuteX(), getHeight() * 0.8f);
                                postDelayed(() -> host.launch(won), 350);
                                postDelayed(() -> back[3] = 1, 1500);
                                state = 6;
                            }
                        } else if (timer > 0.6f) {
                            state = 6;
                        }
                        break;
                    default: {
                        open = 1f;
                        float home = getWidth() / 2f;
                        float stepX = Math.signum(home - clawX) * speed * dt;
                        if (Math.abs(home - clawX) <= Math.abs(stepX)) {
                            clawX = home;
                            state = 0;
                        } else {
                            clawX += stepX;
                        }
                        break;
                    }
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (float[] pr : prizes) {
                    if (pr[3] > 0 && Math.hypot(pr[0] - x, pr[1] - y) < 26 * d) {
                        return apps.get((int) pr[2]);
                    }
                }
                return null;
            }

            private void prize(Canvas c, float[] pr, float x, float y) {
                AppEntry e = apps.get((int) pr[2]);
                int col = HomeKit.color(host, e);
                float rad = 25 * d;
                r.set(x - rad, y - rad, x + rad, y + rad);
                p.setColor(0xFFF5F5F5);
                c.drawOval(r, p);
                p.setColor(col);
                c.drawArc(r, 180, 180, true, p);
                p.setColor(0x55FFFFFF);
                c.drawCircle(x - rad * 0.4f, y - rad * 0.45f, rad * 0.22f, p);
                icon(c, e, x, y - 2 * d, 26 * d);
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, 0xFF3B1356, 0xFF16051F, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                // marquee
                p.setColor(0xFFFF3D7F);
                c.drawRect(0, 40 * d, w, 72 * d, p);
                label(c, "NOVA CLAW  ·  " + clock(), w / 2, 62 * d, 15f, 0xFFFFFFFF);
                for (int i = 0; i < 14; i++) {
                    boolean on = ((int) (t * 4) + i) % 2 == 0;
                    p.setColor(on ? 0xFFFFE066 : 0xFF6E4A00);
                    c.drawCircle(w * (i + 0.5f) / 14, 40 * d, 3 * d, p);
                    c.drawCircle(w * (i + 0.5f) / 14, 72 * d, 3 * d, p);
                }
                // rail
                p.setColor(0xFF9AA0A6);
                c.drawRect(10 * d, rail() - 4 * d, w - 10 * d, rail() + 4 * d, p);
                // chute
                p.setColor(0xFF0B0210);
                c.drawRect(14 * d, h - 120 * d, 92 * d, h, p);
                p.setColor(0xFFFF3D7F);
                c.drawRect(14 * d, h - 124 * d, 92 * d, h - 118 * d, p);
                label(c, "PRIZE", 53 * d, h - 100 * d, 9f, 0xFFFF9AC0);
                for (float[] pr : prizes) {
                    if (pr[3] > 0) {
                        prize(c, pr, pr[0], pr[1]);
                    }
                }
                // rope and claw
                p.setColor(0xFFCCCCCC);
                c.drawRect(clawX - 1.5f * d, rail(), clawX + 1.5f * d, clawY, p);
                if (held != null && fallY < 0) {
                    prize(c, held, clawX, clawY + 32 * d);
                }
                if (held != null && fallY >= 0) {
                    prize(c, held, clawX, fallY);
                }
                p.setColor(0xFFB8BEC6);
                r.set(clawX - 16 * d, clawY - 8 * d, clawX + 16 * d, clawY + 10 * d);
                c.drawRoundRect(r, 5 * d, 5 * d, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(4 * d);
                p.setStrokeCap(Paint.Cap.ROUND);
                float spread = 10 * d + open * 14 * d;
                Path l = new Path();
                l.moveTo(clawX - 10 * d, clawY + 8 * d);
                l.quadTo(clawX - spread - 6 * d, clawY + 26 * d, clawX - spread * 0.4f, clawY + 44 * d);
                c.drawPath(l, p);
                Path rr = new Path();
                rr.moveTo(clawX + 10 * d, clawY + 8 * d);
                rr.quadTo(clawX + spread + 6 * d, clawY + 26 * d, clawX + spread * 0.4f, clawY + 44 * d);
                c.drawPath(rr, p);
                p.setStyle(Paint.Style.FILL);
                // glass shine
                p.setColor(0x10FFFFFF);
                Path g = new Path();
                g.moveTo(w * 0.6f, 80 * d);
                g.lineTo(w * 0.7f, 80 * d);
                g.lineTo(w * 0.45f, h);
                g.lineTo(w * 0.35f, h);
                g.close();
                c.drawPath(g, p);
            }
        }
    }

    // ================================================================== JACKPOT

    /** A slot machine with your apps on the reels. Pull the lever or press SPIN, then tap any app you see. Three in
     *  the middle row is a jackpot. */
    static final class Jackpot extends AltHome {
        Jackpot(NovaActivity host) {
            super(host);
            final Slots s = new Slots(host, appsFor(7));
            LinearLayout ctl = new LinearLayout(host);
            ctl.setPadding(dp(16), dp(10), dp(16), dp(4));
            ctl.setBackgroundColor(0xFF4A0A0A);
            TextView spin = button(this, "SPIN", 0xFFFFC83D, 0xFF4A0A0A);
            spin.setOnClickListener(v -> s.spin());
            ctl.addView(spin, lp(-1, -2));
            frame(this, s, ctl);
        }

        static final class Slots extends Scene {
            private final List<List<AppEntry>> reels = new ArrayList<>();
            private final float[] pos = new float[3];
            private final float[] speed = new float[3];
            private final float[] stopAt = new float[3];
            private boolean spinning;
            private float spinT;
            private String banner = "";
            private float bannerT;
            private float lever;

            Slots(NovaActivity h, List<AppEntry> apps) {
                super(h);
                for (int i = 0; i < 3; i++) {
                    List<AppEntry> l = new ArrayList<>(apps);
                    Collections.shuffle(l, new Random(i * 31 + 7));
                    if (l.isEmpty()) {
                        l.add(null);
                    }
                    reels.add(l);
                    pos[i] = rnd.nextInt(l.size());
                }
            }

            void spin() {
                if (spinning) {
                    return;
                }
                spinning = true;
                spinT = 0;
                banner = "";
                lever = 1f;
                for (int i = 0; i < 3; i++) {
                    speed[i] = 14 + i * 2;
                    stopAt[i] = 0.9f + i * 0.45f;
                }
                host.buzz(20);
            }

            private RectF window(int i) {
                float w = getWidth() - 70 * d;
                float cw = (w - 40 * d) / 3f;
                float top = 150 * d;
                float x = 20 * d + i * (cw + 0 * d) + i * 0;
                return new RectF(x + i * 0, top, x + cw - 6 * d, top + cw * 3f);
            }

            @Override
            void step(float dt) {
                lever = Math.max(0f, lever - dt * 2.5f);
                bannerT += dt;
                if (!spinning) {
                    return;
                }
                spinT += dt;
                boolean any = false;
                for (int i = 0; i < 3; i++) {
                    int n = reels.get(i).size();
                    if (speed[i] > 0) {
                        if (spinT >= stopAt[i]) {
                            // land on a whole cell
                            pos[i] = (float) Math.ceil(pos[i]) % n;
                            speed[i] = 0;
                            host.buzz(8);
                        } else {
                            pos[i] = (pos[i] + speed[i] * dt) % n;
                            any = true;
                        }
                    }
                }
                if (!any) {
                    spinning = false;
                    AppEntry a = at(0, 1);
                    AppEntry b = at(1, 1);
                    AppEntry c = at(2, 1);
                    if (a != null && a == b && b == c) {
                        banner = "JACKPOT!";
                        host.confetti(getWidth() / 2f, getHeight() / 2f);
                        host.buzz(60);
                    } else if (a != null && (a == b || b == c)) {
                        banner = "NICE PAIR";
                    } else {
                        banner = "tap an app to open it";
                    }
                    bannerT = 0;
                }
            }

            /** The app shown in reel i, row 0..2. */
            private AppEntry at(int i, int row) {
                List<AppEntry> l = reels.get(i);
                int n = l.size();
                int k = ((int) Math.floor(pos[i]) + row) % n;
                return l.get((k + n) % n);
            }

            @Override
            AppEntry hit(float x, float y) {
                if (spinning) {
                    return null;
                }
                for (int i = 0; i < 3; i++) {
                    RectF wr = window(i);
                    if (wr.contains(x, y)) {
                        int row = (int) ((y - wr.top) / (wr.height() / 3f));
                        return at(i, Math.max(0, Math.min(2, row)));
                    }
                }
                return null;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN && e.getX() > getWidth() - 60 * d && e.getY() > 120 * d) {
                    spin();
                    return true;
                }
                return super.onTouchEvent(e);
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, 0xFF8E1010, 0xFF3A0505, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                label(c, "★ NOVA JACKPOT ★", (w - 50 * d) / 2, 82 * d, 22f, 0xFFFFD84D);
                label(c, clock(), (w - 50 * d) / 2, 112 * d, 16f, 0xFFFFE9B0);
                // blinking bulbs round the reels
                RectF a = window(0);
                RectF z = window(2);
                RectF box = new RectF(a.left - 12 * d, a.top - 14 * d, z.right + 12 * d, a.bottom + 14 * d);
                p.setColor(0xFFFFC83D);
                c.drawRoundRect(box, 16 * d, 16 * d, p);
                p.setColor(0xFF1A0303);
                RectF inner = new RectF(box.left + 6 * d, box.top + 6 * d, box.right - 6 * d, box.bottom - 6 * d);
                c.drawRoundRect(inner, 12 * d, 12 * d, p);
                int bulbs = 16;
                for (int i = 0; i < bulbs; i++) {
                    boolean on = ((int) (t * (spinning ? 12 : 3)) + i) % 3 == 0;
                    p.setColor(on ? 0xFFFFFFFF : 0xFFB8860B);
                    c.drawCircle(box.left + box.width() * (i + 0.5f) / bulbs, box.top, 3.5f * d, p);
                    c.drawCircle(box.left + box.width() * (i + 0.5f) / bulbs, box.bottom, 3.5f * d, p);
                }
                for (int i = 0; i < 3; i++) {
                    RectF wr = window(i);
                    p.setShader(new LinearGradient(0, wr.top, 0, wr.bottom, new int[] {0xFFBDBDBD, 0xFFFFFFFF, 0xFFBDBDBD},
                            null, Shader.TileMode.CLAMP));
                    c.drawRect(wr, p);
                    p.setShader(null);
                    c.save();
                    c.clipRect(wr);
                    float cell = wr.height() / 3f;
                    float frac = pos[i] - (float) Math.floor(pos[i]);
                    List<AppEntry> l = reels.get(i);
                    int n = l.size();
                    for (int row = -1; row <= 3; row++) {
                        int k = (((int) Math.floor(pos[i]) + row) % n + n) % n;
                        AppEntry e = l.get(k);
                        float cy = wr.top + cell * (row + 0.5f) - frac * cell;
                        if (e != null) {
                            icon(c, e, wr.centerX(), cy - 6 * d, cell * 0.55f);
                            label(c, e.label, wr.centerX(), cy + cell * 0.38f, 9f, 0xFF333333);
                        }
                    }
                    c.restore();
                }
                // the win line
                p.setColor(0x99FF2D2D);
                float mid = a.top + a.height() / 2f;
                c.drawRect(box.left + 6 * d, mid - 1.5f * d, box.right - 6 * d, mid + 1.5f * d, p);
                // lever
                float lx = w - 30 * d;
                float lTop = 150 * d + lever * 120 * d;
                p.setColor(0xFF9AA0A6);
                c.drawRect(lx - 4 * d, lTop, lx + 4 * d, 330 * d, p);
                p.setColor(0xFFE53935);
                c.drawCircle(lx, lTop, 16 * d, p);
                p.setColor(0x66FFFFFF);
                c.drawCircle(lx - 5 * d, lTop - 5 * d, 5 * d, p);
                p.setColor(0xFF555555);
                c.drawRoundRect(new RectF(lx - 12 * d, 320 * d, lx + 12 * d, 350 * d), 4 * d, 4 * d, p);
                if (!banner.isEmpty()) {
                    float s = banner.startsWith("JACK") ? 30f + (float) Math.sin(bannerT * 8) * 3f : 15f;
                    label(c, banner, (w - 50 * d) / 2, box.bottom + 46 * d, s, 0xFFFFD84D);
                }
            }
        }
    }

    // ================================================================== SKYLINE

    /** A city where every building is an app. The sky follows the real time: sun by day, stars and lit windows at
     *  night. Drag sideways to see more of the city. */
    static final class Skyline extends AltHome {
        Skyline(NovaActivity host) {
            super(host);
            frame(this, new City(host, appsFor(16)), null);
        }

        static final class City extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> b = new ArrayList<>(); // x, width, height
            private final List<float[]> stars = new ArrayList<>();
            private final List<float[]> cars = new ArrayList<>();
            private float scroll;
            private float total;
            private float lastX;
            private float downX;
            private boolean dragging;

            City(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
            }

            private void build() {
                float x = 12 * d;
                for (AppEntry e : apps) {
                    int hs = Math.abs(e.pkg.hashCode());
                    float bw = (70 + hs % 30) * d;
                    float bh = (170 + (hs / 7) % 200) * d;
                    b.add(new float[] {x, bw, Math.min(bh, getHeight() * 0.62f)});
                    x += bw + 8 * d;
                }
                total = x;
                for (int i = 0; i < 70; i++) {
                    stars.add(new float[] {rnd.nextFloat(), rnd.nextFloat() * 0.5f, rnd.nextFloat()});
                }
                for (int i = 0; i < 4; i++) {
                    cars.add(new float[] {rnd.nextFloat() * getWidth(), (40 + rnd.nextInt(60)) * d * (i % 2 == 0 ? 1 : -1)});
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = downX = e.getX();
                        dragging = false;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getX() - downX) > ViewConfiguration.get(getContext()).getScaledTouchSlop()) {
                            dragging = true;
                            getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (dragging) {
                            scroll = Math.max(0, Math.min(Math.max(0, total - getWidth()), scroll - (e.getX() - lastX)));
                        }
                        lastX = e.getX();
                        break;
                    default:
                        break;
                }
                if (!dragging) {
                    super.onTouchEvent(e);
                }
                return true;
            }

            private float hour() {
                Calendar c = Calendar.getInstance();
                return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f;
            }

            @Override
            void step(float dt) {
                if (b.isEmpty() && !apps.isEmpty()) {
                    build();
                }
                for (float[] car : cars) {
                    car[0] += car[1] * dt;
                    if (car[0] > getWidth() + 30 * d) {
                        car[0] = -30 * d;
                    } else if (car[0] < -30 * d) {
                        car[0] = getWidth() + 30 * d;
                    }
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                float ground = getHeight() - 46 * d;
                for (int i = 0; i < b.size(); i++) {
                    float[] k = b.get(i);
                    float bx = k[0] - scroll;
                    if (x >= bx && x <= bx + k[1] && y >= ground - k[2] - 30 * d && y <= ground) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                float hr = hour();
                boolean night = hr < 6.5f || hr > 20f;
                boolean dusk = (hr >= 6.5f && hr < 8f) || (hr >= 18f && hr <= 20f);
                int top = night ? 0xFF070B1E : dusk ? 0xFF3B2F6B : 0xFF3D8BD9;
                int bottom = night ? 0xFF1C2546 : dusk ? 0xFFFF8E53 : 0xFFA7D3F5;
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                if (night || dusk) {
                    for (float[] s : stars) {
                        float tw = 0.5f + 0.5f * (float) Math.sin(t * 2 + s[2] * 10);
                        p.setColor((((int) (tw * (night ? 200 : 90))) << 24) | 0xFFFFFF);
                        c.drawCircle(s[0] * w, s[1] * h, 1.3f * d, p);
                    }
                }
                // sun or moon along an arc through the day
                float k = night ? ((hr + 24 - 20f) % 24) / 10.5f : (hr - 6.5f) / 13.5f;
                float sx = w * (0.1f + 0.8f * k);
                float sy = h * 0.42f - (float) Math.sin(Math.PI * k) * h * 0.3f;
                p.setColor(night ? 0xFFF4F1DE : 0xFFFFD34D);
                c.drawCircle(sx, sy, (night ? 20 : 26) * d, p);
                if (night) {
                    p.setColor(top);
                    c.drawCircle(sx + 9 * d, sy - 5 * d, 18 * d, p);
                }
                label(c, clock(), w / 2, 90 * d, 44f, 0xEEFFFFFF);
                float ground = h - 46 * d;
                for (int i = 0; i < b.size(); i++) {
                    float[] k2 = b.get(i);
                    float bx = k2[0] - scroll;
                    if (bx > w || bx + k2[1] < 0) {
                        continue;
                    }
                    AppEntry e = apps.get(i);
                    int col = HomeKit.darker(HomeKit.color(host, e), night ? 0.35f : 0.7f);
                    p.setColor(col);
                    c.drawRect(bx, ground - k2[2], bx + k2[1], ground, p);
                    // windows
                    float ww = 9 * d;
                    int seed = Math.abs(e.pkg.hashCode());
                    int n = 0;
                    for (float y = ground - k2[2] + 34 * d; y < ground - 14 * d; y += 17 * d) {
                        for (float x = bx + 8 * d; x < bx + k2[1] - 12 * d; x += 15 * d) {
                            n++;
                            boolean lit = night || dusk ? ((seed >> (n % 24)) & 1) == 1
                                    || (n * 7 + (int) (t / 4)) % 11 == 0 : false;
                            p.setColor(lit ? 0xFFFFE08A : (night ? 0xFF1A2236 : 0x5FFFFFFF));
                            c.drawRect(x, y, x + ww, y + 10 * d, p);
                        }
                    }
                    // rooftop sign
                    p.setColor(0xEE111111);
                    r.set(bx + k2[1] / 2 - 22 * d, ground - k2[2] - 30 * d, bx + k2[1] / 2 + 22 * d, ground - k2[2] - 2 * d);
                    c.drawRoundRect(r, 6 * d, 6 * d, p);
                    icon(c, e, bx + k2[1] / 2, ground - k2[2] - 16 * d, 22 * d);
                    label(c, e.label, bx + k2[1] / 2, ground - 4 * d, 9f, 0xDDFFFFFF);
                }
                // street and cars
                p.setColor(0xFF2B2B2B);
                c.drawRect(0, ground, w, h, p);
                p.setColor(0xFFFFE08A);
                for (float x = (-t * 40 * d) % (40 * d); x < w; x += 40 * d) {
                    c.drawRect(x, ground + 22 * d, x + 20 * d, ground + 25 * d, p);
                }
                for (float[] car : cars) {
                    float cy = car[1] > 0 ? ground + 14 * d : ground + 34 * d;
                    p.setColor(car[1] > 0 ? 0xFFE53935 : 0xFF1E88E5);
                    r.set(car[0] - 16 * d, cy - 6 * d, car[0] + 16 * d, cy + 6 * d);
                    c.drawRoundRect(r, 4 * d, 4 * d, p);
                    if (night) {
                        p.setColor(0x88FFF3B0);
                        float hx = car[1] > 0 ? car[0] + 16 * d : car[0] - 16 * d;
                        c.drawCircle(hx, cy, 5 * d, p);
                    }
                }
            }
        }
    }

    // ================================================================== MAGNETS

    /** A fridge door with your apps as magnets. Drag them where you like (they stay there), tap one to open it. */
    static final class Magnets extends AltHome {
        Magnets(NovaActivity host) {
            super(host);
            frame(this, new Fridge(host, appsFor(14)), null);
        }

        static final class Fridge extends Scene {
            private static final String KEY = "magnet_pos";
            private final List<AppEntry> apps;
            private final Map<String, float[]> pos = new HashMap<>();
            private AppEntry drag;
            private float offX;
            private float offY;
            private float downX;
            private float downY;
            private boolean moved;
            private final Runnable hold = () -> {
                if (drag != null && !moved) {
                    host.appMenu(drag);
                    drag = null;
                }
            };
            private static final int[] LETTERS = {0xFFE53935, 0xFF1E88E5, 0xFFFDD835, 0xFF43A047, 0xFF8E24AA};

            Fridge(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
                for (String s : Prefs.getString(KEY, "").split(";")) {
                    String[] f = s.split(",");
                    if (f.length == 3) {
                        try {
                            pos.put(f[0], new float[] {Float.parseFloat(f[1]), Float.parseFloat(f[2])});
                        } catch (NumberFormatException ignored) {
                            // broken
                        }
                    }
                }
                for (int i = 0; i < apps.size(); i++) {
                    if (!pos.containsKey(apps.get(i).pkg)) {
                        pos.put(apps.get(i).pkg, new float[] {0.15f + (i % 4) * 0.23f, 0.38f + (i / 4) * 0.14f});
                    }
                }
            }

            private void save() {
                StringBuilder b = new StringBuilder();
                for (Map.Entry<String, float[]> en : pos.entrySet()) {
                    b.append(en.getKey()).append(',').append(en.getValue()[0]).append(',').append(en.getValue()[1]).append(';');
                }
                Prefs.putString(KEY, b.toString());
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = apps.size() - 1; i >= 0; i--) {
                    float[] q = pos.get(apps.get(i).pkg);
                    if (Math.hypot(q[0] * getWidth() - x, q[1] * getHeight() - y) < 32 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        drag = hit(e.getX(), e.getY());
                        moved = false;
                        downX = e.getX();
                        downY = e.getY();
                        if (drag != null) {
                            float[] q = pos.get(drag.pkg);
                            offX = q[0] * getWidth() - e.getX();
                            offY = q[1] * getHeight() - e.getY();
                            apps.remove(drag);
                            apps.add(drag);
                            getParent().requestDisallowInterceptTouchEvent(true);
                            postDelayed(hold, 550);
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (drag != null) {
                            if (Math.hypot(e.getX() - downX, e.getY() - downY) > 10 * d) {
                                moved = true;
                                removeCallbacks(hold);
                            }
                            if (moved) {
                                float[] q = pos.get(drag.pkg);
                                q[0] = Math.max(0.06f, Math.min(0.94f, (e.getX() + offX) / getWidth()));
                                q[1] = Math.max(0.2f, Math.min(0.95f, (e.getY() + offY) / getHeight()));
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        removeCallbacks(hold);
                        if (drag != null) {
                            if (moved) {
                                save();
                                host.buzz(8);
                            } else {
                                host.launch(drag);
                            }
                        }
                        drag = null;
                        return true;
                    default:
                        removeCallbacks(hold);
                        drag = null;
                        return true;
                }
            }

            @Override
            void step(float dt) {
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, w, h, 0xFFF4F6F8, 0xFFD5DCE2, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                p.setColor(0xFFB9C2CA);
                c.drawRect(0, h * 0.3f, w, h * 0.3f + 3 * d, p);
                p.setColor(0xFF9AA4AD);
                r.set(w - 26 * d, h * 0.08f, w - 14 * d, h * 0.24f);
                c.drawRoundRect(r, 6 * d, 6 * d, p);
                r.set(w - 26 * d, h * 0.36f, w - 14 * d, h * 0.6f);
                c.drawRoundRect(r, 6 * d, 6 * d, p);
                // the time in letter magnets
                String s = clock();
                p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
                p.setTextSize(58 * d);
                p.setTextAlign(Paint.Align.CENTER);
                float cw = 42 * d;
                float x0 = w / 2 - (s.length() - 1) * cw / 2;
                for (int i = 0; i < s.length(); i++) {
                    c.save();
                    c.rotate((i % 2 == 0 ? -6 : 5), x0 + i * cw, h * 0.2f);
                    p.setColor(0x33000000);
                    c.drawText(String.valueOf(s.charAt(i)), x0 + i * cw + 2 * d, h * 0.2f + 3 * d, p);
                    p.setColor(LETTERS[i % LETTERS.length]);
                    c.drawText(String.valueOf(s.charAt(i)), x0 + i * cw, h * 0.2f, p);
                    c.restore();
                }
                // a note held by a magnet
                c.save();
                c.rotate(-3, w * 0.22f, h * 0.27f);
                p.setColor(0xFFFFF59D);
                r.set(w * 0.06f, h * 0.24f - 4 * d, w * 0.42f, h * 0.24f + 22 * d);
                c.drawRect(r, p);
                label(c, new java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault()).format(new java.util.Date()),
                        w * 0.24f, h * 0.24f + 13 * d, 11f, 0xFF444444);
                c.restore();
                for (AppEntry e : apps) {
                    float[] q = pos.get(e.pkg);
                    float x = q[0] * w;
                    float y = q[1] * h;
                    boolean up = e == drag && moved;
                    float rad = (up ? 34 : 30) * d;
                    p.setColor(up ? 0x44000000 : 0x33000000);
                    c.drawCircle(x + (up ? 6 : 2) * d, y + (up ? 8 : 3) * d, rad, p);
                    int col = HomeKit.color(host, e);
                    p.setShader(new RadialGradient(x - rad * 0.3f, y - rad * 0.3f, rad * 1.4f, 0xFFFFFFFF, col,
                            Shader.TileMode.CLAMP));
                    c.drawCircle(x, y, rad, p);
                    p.setShader(null);
                    p.setColor(col);
                    c.drawCircle(x, y, rad * 0.82f, p);
                    icon(c, e, x, y, rad * 1.05f);
                }
            }
        }
    }

    // ================================================================== BALLOONS

    /** Your apps float up as balloons. Tap one to pop it and open the app; it floats up again later. */
    static final class Balloons extends AltHome {
        Balloons(NovaActivity host) {
            super(host);
            frame(this, new Sky(host, appsFor(10)), null);
        }

        static final class Sky extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> bl = new ArrayList<>(); // x, y, vy, phase, popped timer
            private final List<float[]> bits = new ArrayList<>(); // x, y, vx, vy, life, color
            private final float[] clouds = {0.1f, 0.6f, 1.1f};

            Sky(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
            }

            @Override
            void step(float dt) {
                if (bl.isEmpty()) {
                    for (int i = 0; i < apps.size(); i++) {
                        bl.add(new float[] {getWidth() * (0.12f + 0.76f * rnd.nextFloat()),
                            getHeight() * (0.25f + 0.85f * rnd.nextFloat()), -(22 + rnd.nextInt(26)) * d,
                            rnd.nextFloat() * 6, 0});
                    }
                }
                for (float[] b : bl) {
                    if (b[4] > 0) {
                        b[4] -= dt;
                        if (b[4] <= 0) {
                            b[1] = getHeight() + 80 * d;
                            b[0] = getWidth() * (0.12f + 0.76f * rnd.nextFloat());
                        }
                        continue;
                    }
                    b[1] += b[2] * dt;
                    if (b[1] < -90 * d) {
                        b[1] = getHeight() + 80 * d;
                        b[0] = getWidth() * (0.12f + 0.76f * rnd.nextFloat());
                    }
                }
                for (int i = bits.size() - 1; i >= 0; i--) {
                    float[] q = bits.get(i);
                    q[0] += q[2] * dt;
                    q[1] += q[3] * dt;
                    q[3] += 400 * d * dt;
                    q[4] -= dt;
                    if (q[4] <= 0) {
                        bits.remove(i);
                    }
                }
                for (int i = 0; i < clouds.length; i++) {
                    clouds[i] += dt * 0.012f * (i + 1);
                    if (clouds[i] > 1.3f) {
                        clouds[i] = -0.3f;
                    }
                }
            }

            private float bx(float[] b) {
                return b[0] + (float) Math.sin(t * 1.3f + b[3]) * 12 * d;
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = bl.size() - 1; i >= 0; i--) {
                    float[] b = bl.get(i);
                    if (b[4] <= 0 && Math.abs(x - bx(b)) < 34 * d && Math.abs(y - b[1]) < 42 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void tap(float x, float y) {
                for (int i = bl.size() - 1; i >= 0; i--) {
                    float[] b = bl.get(i);
                    if (b[4] <= 0 && Math.abs(x - bx(b)) < 34 * d && Math.abs(y - b[1]) < 42 * d) {
                        final AppEntry e = apps.get(i);
                        int col = HomeKit.color(host, e);
                        for (int k = 0; k < 18; k++) {
                            double a = rnd.nextFloat() * Math.PI * 2;
                            float sp = (80 + rnd.nextInt(160)) * d;
                            bits.add(new float[] {bx(b), b[1], (float) Math.cos(a) * sp, (float) Math.sin(a) * sp - 100 * d,
                                0.7f, col});
                        }
                        b[4] = 4f;
                        host.buzz(25);
                        postDelayed(() -> host.launch(e), 320);
                        return;
                    }
                }
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, 0xFF5BB8F5, 0xFFDDF1FF, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                p.setColor(0xEEFFFFFF);
                for (int i = 0; i < clouds.length; i++) {
                    float cx = clouds[i] * w;
                    float cy = h * (0.18f + i * 0.22f);
                    c.drawCircle(cx, cy, 26 * d, p);
                    c.drawCircle(cx + 28 * d, cy - 10 * d, 32 * d, p);
                    c.drawCircle(cx + 60 * d, cy, 24 * d, p);
                    r.set(cx - 10 * d, cy, cx + 76 * d, cy + 22 * d);
                    c.drawRoundRect(r, 11 * d, 11 * d, p);
                }
                label(c, clock(), w / 2, 84 * d, 44f, 0xFFFFFFFF);
                for (int i = 0; i < bl.size(); i++) {
                    float[] b = bl.get(i);
                    if (b[4] > 0) {
                        continue;
                    }
                    AppEntry e = apps.get(i);
                    int col = HomeKit.color(host, e);
                    float x = bx(b);
                    float y = b[1];
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.2f * d);
                    p.setColor(0x99555555);
                    Path s = new Path();
                    s.moveTo(x, y + 40 * d);
                    s.cubicTo(x + 10 * d, y + 60 * d, x - 10 * d, y + 75 * d, x + 4 * d, y + 95 * d);
                    c.drawPath(s, p);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(HomeKit.darker(col, 0.8f));
                    Path knot = new Path();
                    knot.moveTo(x, y + 34 * d);
                    knot.lineTo(x - 5 * d, y + 42 * d);
                    knot.lineTo(x + 5 * d, y + 42 * d);
                    knot.close();
                    c.drawPath(knot, p);
                    p.setShader(new RadialGradient(x - 10 * d, y - 14 * d, 50 * d, 0xFFFFFFFF, col, Shader.TileMode.CLAMP));
                    r.set(x - 30 * d, y - 38 * d, x + 30 * d, y + 36 * d);
                    c.drawOval(r, p);
                    p.setShader(null);
                    p.setColor(col);
                    r.set(x - 26 * d, y - 30 * d, x + 26 * d, y + 34 * d);
                    c.drawOval(r, p);
                    p.setColor(0x66FFFFFF);
                    r.set(x - 18 * d, y - 30 * d, x - 8 * d, y - 12 * d);
                    c.drawOval(r, p);
                    icon(c, e, x, y, 28 * d);
                    label(c, e.label, x, y + 110 * d, 10f, 0xFF345B78);
                }
                for (float[] q : bits) {
                    p.setColor(((int) (Math.max(0, q[4]) / 0.7f * 255) << 24) | ((int) q[5] & 0xFFFFFF));
                    c.drawCircle(q[0], q[1], 4 * d, p);
                }
            }
        }
    }

    // ================================================================== RAIN

    /** A rainy window at night. Your apps are the big drops sliding down the glass. Tap one to open it, press the
     *  wiper to clear the glass. */
    static final class Rain extends AltHome {
        Rain(NovaActivity host) {
            super(host);
            final Window win = new Window(host, appsFor(10));
            LinearLayout ctl = new LinearLayout(host);
            ctl.setPadding(dp(16), dp(8), dp(16), dp(4));
            ctl.setBackgroundColor(0xFF0B1220);
            TextView wipe = button(this, "WIPE THE GLASS", 0xFF1E2A44, 0xFFBFD4FF);
            wipe.setOnClickListener(v -> win.wipe());
            ctl.addView(wipe, lp(-1, -2));
            frame(this, win, ctl);
        }

        static final class Window extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> drops = new ArrayList<>(); // x, y, vy, pause
            private final List<float[]> trail = new ArrayList<>();
            private Bitmap back;
            private float wiper = -1;

            Window(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
            }

            void wipe() {
                if (wiper < 0) {
                    wiper = 0;
                    host.buzz(10);
                }
            }

            private void scatter() {
                drops.clear();
                for (int i = 0; i < apps.size(); i++) {
                    drops.add(new float[] {getWidth() * (0.1f + 0.8f * ((i * 0.37f) % 1f)),
                        getHeight() * (0.15f + 0.6f * rnd.nextFloat()), 0, rnd.nextFloat() * 3});
                }
            }

            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                if (w <= 0 || h <= 0) {
                    return;
                }
                back = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
                Canvas k = new Canvas(back);
                Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
                q.setShader(new LinearGradient(0, 0, 0, h, 0xFF0C1426, 0xFF1A2440, Shader.TileMode.CLAMP));
                k.drawRect(0, 0, w, h, q);
                Random rr = new Random(3);
                int[] cols = {0xFFFFB74D, 0xFFFF7043, 0xFF4FC3F7, 0xFFFFF176, 0xFFE57373, 0xFFBA68C8};
                for (int i = 0; i < 60; i++) {
                    float x = rr.nextFloat() * w;
                    float y = h * (0.35f + rr.nextFloat() * 0.65f);
                    float rad = (8 + rr.nextInt(30)) * d;
                    int col = cols[rr.nextInt(cols.length)];
                    q.setShader(new RadialGradient(x, y, rad, (col & 0xFFFFFF) | 0x77000000, col & 0xFFFFFF,
                            Shader.TileMode.CLAMP));
                    k.drawCircle(x, y, rad, q);
                }
                q.setShader(null);
                for (int i = 0; i < 900; i++) {
                    q.setColor(rr.nextBoolean() ? 0x30FFFFFF : 0x22000000);
                    k.drawCircle(rr.nextFloat() * w, rr.nextFloat() * h, (0.6f + rr.nextFloat() * 1.6f) * d, q);
                }
                scatter();
            }

            @Override
            void step(float dt) {
                if (drops.isEmpty() && !apps.isEmpty()) {
                    scatter();
                }
                for (float[] q : drops) {
                    if (q[3] > 0) {
                        q[3] -= dt;
                        continue;
                    }
                    q[2] = Math.min(60 * d, q[2] + 40 * d * dt);
                    q[1] += q[2] * dt;
                    if (rnd.nextFloat() < dt * 0.8f) {
                        q[3] = 0.5f + rnd.nextFloat() * 2.5f;
                        q[2] = 0;
                    }
                    if (rnd.nextFloat() < dt * 8) {
                        trail.add(new float[] {q[0] + (rnd.nextFloat() - 0.5f) * 6 * d, q[1] - 20 * d, 6f});
                    }
                    if (q[1] > getHeight() + 40 * d) {
                        q[1] = -40 * d;
                        q[0] = getWidth() * (0.1f + 0.8f * rnd.nextFloat());
                    }
                }
                for (int i = trail.size() - 1; i >= 0; i--) {
                    trail.get(i)[2] -= dt;
                    if (trail.get(i)[2] <= 0) {
                        trail.remove(i);
                    }
                }
                if (wiper >= 0) {
                    wiper += dt / 1.1f;
                    if (wiper >= 0.5f && !drops.isEmpty() && drops.get(0)[1] > -50 * d) {
                        trail.clear();
                        for (float[] q : drops) {
                            q[1] = -40 * d - rnd.nextFloat() * 200 * d;
                        }
                    }
                    if (wiper >= 1f) {
                        wiper = -1;
                    }
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = 0; i < drops.size(); i++) {
                    float[] q = drops.get(i);
                    if (Math.hypot(x - q[0], y - q[1]) < 32 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                if (back != null) {
                    c.drawBitmap(back, 0, 0, null);
                }
                label(c, clock(), w / 2, 110 * d, 64f, 0x55FFFFFF);
                p.setColor(0x33FFFFFF);
                for (float[] q : trail) {
                    c.drawCircle(q[0], q[1], 2.2f * d, p);
                }
                for (int i = 0; i < drops.size(); i++) {
                    float[] q = drops.get(i);
                    AppEntry e = apps.get(i);
                    float x = q[0];
                    float y = q[1];
                    Path dp = new Path();
                    dp.moveTo(x, y - 36 * d);
                    dp.cubicTo(x + 8 * d, y - 22 * d, x + 26 * d, y - 6 * d, x + 26 * d, y + 8 * d);
                    dp.cubicTo(x + 26 * d, y + 24 * d, x + 14 * d, y + 32 * d, x, y + 32 * d);
                    dp.cubicTo(x - 14 * d, y + 32 * d, x - 26 * d, y + 24 * d, x - 26 * d, y + 8 * d);
                    dp.cubicTo(x - 26 * d, y - 6 * d, x - 8 * d, y - 22 * d, x, y - 36 * d);
                    p.setShader(new RadialGradient(x - 8 * d, y, 34 * d, 0x55BFE4FF, 0x22FFFFFF, Shader.TileMode.CLAMP));
                    c.drawPath(dp, p);
                    p.setShader(null);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.5f * d);
                    p.setColor(0x66FFFFFF);
                    c.drawPath(dp, p);
                    p.setStyle(Paint.Style.FILL);
                    icon(c, e, x, y + 6 * d, 26 * d);
                    p.setColor(0xAAFFFFFF);
                    c.drawCircle(x - 10 * d, y - 4 * d, 3 * d, p);
                    label(c, e.label, x, y + 48 * d, 10f, 0xAADDE8FF);
                }
                if (wiper >= 0) {
                    float ang = -80 + 160 * (float) Math.sin(Math.PI * wiper);
                    c.save();
                    c.rotate(ang, w / 2, h + 20 * d);
                    p.setColor(0xFF111111);
                    c.drawRect(w / 2 - 3 * d, h + 20 * d - h * 0.95f, w / 2 + 3 * d, h + 20 * d, p);
                    p.setColor(0xFF2A2A2A);
                    c.drawRect(w / 2 - 6 * d, h + 20 * d - h * 0.95f, w / 2 + 6 * d, h + 20 * d - h * 0.15f, p);
                    c.restore();
                }
            }
        }
    }

    // ================================================================== LAVA

    /** A lava lamp: your apps are the warm blobs that rise and sink. Tap a blob to open it. */
    static final class Lava extends AltHome {
        Lava(NovaActivity host) {
            super(host);
            frame(this, new Lamp(host, appsFor(8)), null);
        }

        static final class Lamp extends Scene {
            private final List<AppEntry> apps;
            private final List<float[]> blobs = new ArrayList<>(); // x frac, y frac, speed, radius, phase

            Lamp(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
                for (int i = 0; i < apps.size(); i++) {
                    blobs.add(new float[] {0.3f + rnd.nextFloat() * 0.4f, rnd.nextFloat(), 0.03f + rnd.nextFloat() * 0.04f,
                        28 + rnd.nextInt(14), rnd.nextFloat() * 6});
                }
            }

            private RectF glass() {
                float w = getWidth();
                float h = getHeight();
                return new RectF(w * 0.2f, h * 0.2f, w * 0.8f, h * 0.84f);
            }

            private Path glassPath() {
                RectF g = glass();
                Path path = new Path();
                float topIn = g.width() * 0.22f;
                path.moveTo(g.left + topIn, g.top);
                path.lineTo(g.right - topIn, g.top);
                path.quadTo(g.right + 10 * d, g.centerY(), g.right - g.width() * 0.08f, g.bottom);
                path.lineTo(g.left + g.width() * 0.08f, g.bottom);
                path.quadTo(g.left - 10 * d, g.centerY(), g.left + topIn, g.top);
                path.close();
                return path;
            }

            private float[] where(int i) {
                RectF g = glass();
                float[] b = blobs.get(i);
                float y = g.top + 30 * d + (g.height() - 60 * d) * (0.5f + 0.5f * (float) Math.sin(b[1] * Math.PI * 2));
                float x = g.left + g.width() * (b[0] + 0.06f * (float) Math.sin(t * 0.5f + b[4]));
                return new float[] {x, y};
            }

            @Override
            void step(float dt) {
                for (float[] b : blobs) {
                    b[1] = (b[1] + b[2] * dt) % 1f;
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = 0; i < blobs.size(); i++) {
                    float[] q = where(i);
                    if (Math.hypot(x - q[0], y - q[1]) < blobs.get(i)[3] * d + 6 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                c.drawColor(0xFF0E0712);
                RectF g = glass();
                int warm = Theme.ACCENT;
                p.setShader(new RadialGradient(g.centerX(), g.centerY(), g.height() * 0.7f, (warm & 0xFFFFFF) | 0x55000000,
                        0x00000000, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                label(c, clock(), w / 2, 90 * d, 48f, 0xFFFFE0F0);
                // cap and base
                p.setShader(new LinearGradient(g.left, 0, g.right, 0, new int[] {0xFF6E6E78, 0xFFE0E0E8, 0xFF6E6E78}, null,
                        Shader.TileMode.CLAMP));
                Path cap = new Path();
                cap.moveTo(g.left + g.width() * 0.22f, g.top);
                cap.lineTo(g.centerX() - 12 * d, g.top - 50 * d);
                cap.lineTo(g.centerX() + 12 * d, g.top - 50 * d);
                cap.lineTo(g.right - g.width() * 0.22f, g.top);
                cap.close();
                c.drawPath(cap, p);
                Path base = new Path();
                base.moveTo(g.left + g.width() * 0.08f, g.bottom);
                base.lineTo(g.right - g.width() * 0.08f, g.bottom);
                base.lineTo(g.right + 14 * d, h - 10 * d);
                base.lineTo(g.left - 14 * d, h - 10 * d);
                base.close();
                c.drawPath(base, p);
                p.setShader(null);
                // liquid
                c.save();
                c.clipPath(glassPath());
                p.setShader(new LinearGradient(0, g.top, 0, g.bottom, 0xFF3A0F4A, HomeKit.darker(warm, 0.55f),
                        Shader.TileMode.CLAMP));
                c.drawRect(g, p);
                p.setShader(null);
                for (int i = 0; i < blobs.size(); i++) {
                    float[] q = where(i);
                    float rad = blobs.get(i)[3] * d;
                    float wob = (float) Math.sin(t * 2 + blobs.get(i)[4]) * 4 * d;
                    p.setShader(new RadialGradient(q[0], q[1], rad * 1.4f, 0xFFFFB04D, 0x00FF4D6D, Shader.TileMode.CLAMP));
                    c.drawCircle(q[0], q[1], rad * 1.4f, p);
                    p.setShader(new RadialGradient(q[0] - rad * 0.3f, q[1] - rad * 0.3f, rad * 1.2f, 0xFFFFD27A, 0xFFFF4D6D,
                            Shader.TileMode.CLAMP));
                    r.set(q[0] - rad - wob, q[1] - rad + wob, q[0] + rad + wob, q[1] + rad - wob);
                    c.drawOval(r, p);
                    p.setShader(null);
                    icon(c, apps.get(i), q[0], q[1], rad * 0.95f);
                }
                c.restore();
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2 * d);
                p.setColor(0x55FFFFFF);
                c.drawPath(glassPath(), p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x18FFFFFF);
                r.set(g.left + g.width() * 0.18f, g.top + 30 * d, g.left + g.width() * 0.26f, g.bottom - 40 * d);
                c.drawRoundRect(r, 10 * d, 10 * d, p);
            }
        }
    }

    // ================================================================== GARDEN

    /** A garden where every app is a flower. The more you open an app, the taller its flower grows. Water them! */
    static final class Garden extends AltHome {
        Garden(NovaActivity host) {
            super(host);
            final Meadow m = new Meadow(host, appsFor(10));
            LinearLayout ctl = new LinearLayout(host);
            ctl.setPadding(dp(16), dp(8), dp(16), dp(4));
            ctl.setBackgroundColor(0xFF3C7A2E);
            TextView water = button(this, "💧  WATER THE GARDEN", 0xFF2E5E22, 0xFFE8FFD8);
            water.setOnClickListener(v -> m.water());
            ctl.addView(water, lp(-1, -2));
            frame(this, m, ctl);
        }

        static final class Meadow extends Scene {
            private final List<AppEntry> apps;
            private final float[] grow;
            private final List<float[]> drops = new ArrayList<>();
            private float rain;
            private float bounce;

            Meadow(NovaActivity h, List<AppEntry> apps) {
                super(h);
                this.apps = apps;
                grow = new float[apps.size()];
                Map<String, Integer> count = new HashMap<>();
                for (Object[] o : HomeKit.history()) {
                    String k = (String) o[0];
                    count.put(k, (count.containsKey(k) ? count.get(k) : 0) + 1);
                }
                for (int i = 0; i < apps.size(); i++) {
                    Integer n = count.get(apps.get(i).pkg);
                    grow[i] = Math.min(1f, (n == null ? 0 : n) / 12f);
                }
            }

            void water() {
                rain = 2.2f;
                host.buzz(10);
            }

            private float[] head(int i) {
                float w = getWidth();
                float ground = getHeight() - 70 * d;
                boolean back = i % 2 == 1;
                int n = apps.size();
                float x = w * (0.08f + 0.84f * (i + 0.5f) / Math.max(1, n));
                float hgt = (back ? 150 : 90) * d + grow[i] * 170 * d + bounce * 12 * d * (float) Math.sin(t * 12 + i);
                float sway = (float) Math.sin(t * 1.4f + i) * 8 * d;
                return new float[] {x + sway, ground - hgt - (back ? 20 * d : 0), x, ground - (back ? 20 * d : 0)};
            }

            @Override
            void step(float dt) {
                bounce = Math.max(0f, bounce - dt * 0.8f);
                if (rain > 0) {
                    rain -= dt;
                    bounce = 1f;
                    for (int k = 0; k < 4; k++) {
                        drops.add(new float[] {rnd.nextFloat() * getWidth(), 120 * d});
                    }
                }
                for (int i = drops.size() - 1; i >= 0; i--) {
                    drops.get(i)[1] += 700 * d * dt;
                    if (drops.get(i)[1] > getHeight()) {
                        drops.remove(i);
                    }
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = 0; i < apps.size(); i++) {
                    float[] q = head(i);
                    if (Math.hypot(x - q[0], y - q[1]) < 36 * d) {
                        return apps.get(i);
                    }
                }
                return null;
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                float h = getHeight();
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(0, 0, 0, h, rain > 0 ? 0xFF7C93A8 : 0xFF7EC8F5, 0xFFE8F7FF, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, p);
                p.setShader(null);
                // the sun carries the time
                float sx = w - 80 * d;
                float sy = 110 * d;
                p.setColor(0x55FFE066);
                c.drawCircle(sx, sy, 58 * d + (float) Math.sin(t * 2) * 4 * d, p);
                p.setColor(0xFFFFD43B);
                c.drawCircle(sx, sy, 48 * d, p);
                label(c, clock(), sx, sy + 9 * d, 22f, 0xFF7A4A00);
                if (rain > 0) {
                    p.setColor(0xFFB0BEC5);
                    for (int k = 0; k < 4; k++) {
                        c.drawCircle(w * (0.2f + k * 0.2f), 110 * d, 40 * d, p);
                    }
                }
                // hills
                p.setColor(0xFF8BC34A);
                c.drawCircle(w * 0.2f, h + 120 * d, h * 0.35f, p);
                p.setColor(0xFF7CB342);
                c.drawCircle(w * 0.85f, h + 160 * d, h * 0.38f, p);
                p.setColor(0xFF558B2F);
                c.drawRect(0, h - 60 * d, w, h, p);
                // flowers: the back row first
                for (int pass = 1; pass >= 0; pass--) {
                    for (int i = 0; i < apps.size(); i++) {
                        if (i % 2 != pass) {
                            continue;
                        }
                        float[] q = head(i);
                        AppEntry e = apps.get(i);
                        int col = HomeKit.color(host, e);
                        p.setStyle(Paint.Style.STROKE);
                        p.setStrokeWidth(5 * d);
                        p.setColor(0xFF2E7D32);
                        Path stem = new Path();
                        stem.moveTo(q[2], q[3]);
                        stem.quadTo(q[2], (q[1] + q[3]) / 2, q[0], q[1]);
                        c.drawPath(stem, p);
                        p.setStyle(Paint.Style.FILL);
                        p.setColor(0xFF43A047);
                        r.set(q[2], (q[1] + q[3]) / 2, q[2] + 26 * d, (q[1] + q[3]) / 2 + 12 * d);
                        c.drawOval(r, p);
                        int petals = 7;
                        p.setColor(col);
                        for (int k = 0; k < petals; k++) {
                            c.save();
                            c.rotate(k * 360f / petals + t * 10, q[0], q[1]);
                            r.set(q[0] - 11 * d, q[1] - 40 * d, q[0] + 11 * d, q[1] - 8 * d);
                            c.drawOval(r, p);
                            c.restore();
                        }
                        p.setColor(0xFFFFF3C4);
                        c.drawCircle(q[0], q[1], 18 * d, p);
                        icon(c, e, q[0], q[1], 24 * d);
                        label(c, e.label, q[2], h - 18 * d - (i % 2) * 14 * d, 9f, 0xFFFFFFFF);
                    }
                }
                // butterflies
                for (int k = 0; k < 2; k++) {
                    float bx = w * (0.5f + 0.4f * (float) Math.sin(t * 0.3f + k * 2));
                    float by = h * (0.35f + 0.1f * (float) Math.sin(t * 0.7f + k));
                    float flap = Math.abs((float) Math.sin(t * 14 + k)) * 9 * d + 2 * d;
                    p.setColor(k == 0 ? 0xFFFF7043 : 0xFFAB47BC);
                    r.set(bx - flap, by - 7 * d, bx, by + 3 * d);
                    c.drawOval(r, p);
                    r.set(bx, by - 7 * d, bx + flap, by + 3 * d);
                    c.drawOval(r, p);
                }
                p.setColor(0xAA4FC3F7);
                for (float[] q : drops) {
                    c.drawRect(q[0], q[1], q[0] + 2 * d, q[1] + 12 * d, p);
                }
                label(c, "the more you use an app, the taller it grows", w / 2, h - 66 * d, 9f, 0xCCFFFFFF);
            }
        }
    }

    // ================================================================== BOARD GAME

    /** A board game made of your apps. Tap the dice to roll and your token hops around the board; tap the field it
     *  lands on (or any field) to open that app. */
    static final class BoardGame extends AltHome {
        BoardGame(NovaActivity host) {
            super(host);
            frame(this, new Board(host, appsFor(12)), null);
        }

        static final class Board extends Scene {
            private static final String KEY = "board_token";
            private final List<Object> fields = new ArrayList<>(); // AppEntry or String for corners
            private int token;
            private float hopT = -1;
            private int stepsLeft;
            private int[] dice = {3, 4};
            private float rollT = -1;
            private String landed = "";

            Board(NovaActivity h, List<AppEntry> apps) {
                super(h);
                String[] corners = {"START", "WIDGETS", "TERMINAL", "SETTINGS"};
                int k = 0;
                for (int i = 0; i < 16; i++) {
                    if (i % 4 == 0) {
                        fields.add(corners[i / 4]);
                    } else {
                        fields.add(k < apps.size() ? apps.get(k++) : "FREE");
                    }
                }
                token = Math.max(0, Math.min(15, Prefs.getInt(KEY, 0)));
            }

            private RectF boardRect() {
                float w = getWidth();
                float size = Math.min(w - 20 * d, getHeight() - 150 * d);
                float left = (w - size) / 2;
                float top = 120 * d;
                return new RectF(left, top, left + size, top + size);
            }

            /** The square of field i, going clockwise from the bottom right corner. */
            private RectF field(int i) {
                RectF b = boardRect();
                float c = b.width() / 5f;
                int col;
                int row;
                if (i <= 4) {
                    col = 4 - i;
                    row = 4;
                } else if (i <= 8) {
                    col = 0;
                    row = 4 - (i - 4);
                } else if (i <= 12) {
                    col = i - 8;
                    row = 0;
                } else {
                    col = 4;
                    row = i - 12;
                }
                return new RectF(b.left + col * c, b.top + row * c, b.left + (col + 1) * c, b.top + (row + 1) * c);
            }

            private void roll() {
                if (rollT >= 0 || stepsLeft > 0) {
                    return;
                }
                rollT = 0;
                landed = "";
                host.buzz(15);
            }

            @Override
            void step(float dt) {
                if (rollT >= 0) {
                    rollT += dt;
                    dice[0] = 1 + rnd.nextInt(6);
                    dice[1] = 1 + rnd.nextInt(6);
                    if (rollT > 0.8f) {
                        rollT = -1;
                        stepsLeft = dice[0] + dice[1];
                        hopT = 0;
                    }
                }
                if (stepsLeft > 0) {
                    hopT += dt;
                    if (hopT >= 0.2f) {
                        hopT = 0;
                        token = (token + 1) % 16;
                        stepsLeft--;
                        host.buzz(4);
                        if (stepsLeft == 0) {
                            Prefs.putInt(KEY, token);
                            Object f = fields.get(token);
                            landed = f instanceof AppEntry ? ((AppEntry) f).label : (String) f;
                        }
                    }
                }
            }

            private void open(Object f) {
                if (f instanceof AppEntry) {
                    host.launch((AppEntry) f);
                } else if ("START".equals(f)) {
                    host.showDrawer();
                } else if ("WIDGETS".equals(f)) {
                    host.showOverlay(new WidgetsSheet(host));
                } else if ("TERMINAL".equals(f)) {
                    host.showTerminal();
                } else if ("SETTINGS".equals(f)) {
                    host.showSettings();
                }
            }

            @Override
            void tap(float x, float y) {
                RectF b = boardRect();
                float c = b.width() / 5f;
                RectF centre = new RectF(b.left + c, b.top + c, b.right - c, b.bottom - c);
                if (centre.contains(x, y)) {
                    if (!landed.isEmpty() && y > centre.bottom - c * 0.9f) {
                        open(fields.get(token));
                    } else {
                        roll();
                    }
                    return;
                }
                for (int i = 0; i < 16; i++) {
                    if (field(i).contains(x, y)) {
                        open(fields.get(i));
                        return;
                    }
                }
            }

            @Override
            AppEntry hit(float x, float y) {
                for (int i = 0; i < 16; i++) {
                    if (field(i).contains(x, y) && fields.get(i) instanceof AppEntry) {
                        return (AppEntry) fields.get(i);
                    }
                }
                return null;
            }

            private void die(Canvas c, float cx, float cy, float s, int v) {
                p.setColor(0xFFFFFFFF);
                r.set(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2);
                c.drawRoundRect(r, s * 0.18f, s * 0.18f, p);
                p.setColor(0xFF222222);
                float o = s * 0.27f;
                float pr = s * 0.09f;
                boolean[][] pip = {
                    {false, false, false, false, true, false, false, false, false},
                    {true, false, false, false, false, false, false, false, true},
                    {true, false, false, false, true, false, false, false, true},
                    {true, false, true, false, false, false, true, false, true},
                    {true, false, true, false, true, false, true, false, true},
                    {true, false, true, true, false, true, true, false, true}};
                for (int k = 0; k < 9; k++) {
                    if (pip[v - 1][k]) {
                        c.drawCircle(cx + (k % 3 - 1) * o, cy + (k / 3 - 1) * o, pr, p);
                    }
                }
            }

            @Override
            void paint(Canvas c) {
                float w = getWidth();
                p.setStyle(Paint.Style.FILL);
                c.drawColor(0xFF1B4332);
                label(c, "NOVA BOARD  ·  " + clock(), w / 2, 90 * d, 22f, 0xFFFFF3C4);
                RectF b = boardRect();
                p.setColor(0xFFDDF0D8);
                c.drawRect(b, p);
                float cs = b.width() / 5f;
                for (int i = 0; i < 16; i++) {
                    RectF f = field(i);
                    Object o = fields.get(i);
                    p.setColor(0xFFF7F3E3);
                    c.drawRect(f.left + 1.5f * d, f.top + 1.5f * d, f.right - 1.5f * d, f.bottom - 1.5f * d, p);
                    if (o instanceof AppEntry) {
                        AppEntry e = (AppEntry) o;
                        p.setColor(HomeKit.color(host, e));
                        c.drawRect(f.left + 1.5f * d, f.top + 1.5f * d, f.right - 1.5f * d, f.top + cs * 0.2f, p);
                        icon(c, e, f.centerX(), f.centerY() + 2 * d, cs * 0.42f);
                        label(c, e.label, f.centerX(), f.bottom - 5 * d, 7.5f, 0xFF333333);
                    } else {
                        label(c, (String) o, f.centerX(), f.centerY() + 4 * d, 8.5f, 0xFF1B4332);
                    }
                }
                // the middle: dice and what you landed on
                RectF mid = new RectF(b.left + cs, b.top + cs, b.right - cs, b.bottom - cs);
                p.setColor(0xFF2D6A4F);
                c.drawRect(mid, p);
                float spin = rollT >= 0 ? (float) Math.sin(rollT * 30) * 12 : 0;
                c.save();
                c.rotate(spin, mid.centerX() - cs * 0.45f, mid.centerY() - cs * 0.3f);
                die(c, mid.centerX() - cs * 0.45f, mid.centerY() - cs * 0.3f, cs * 0.6f, dice[0]);
                c.restore();
                c.save();
                c.rotate(-spin, mid.centerX() + cs * 0.45f, mid.centerY() - cs * 0.3f);
                die(c, mid.centerX() + cs * 0.45f, mid.centerY() - cs * 0.3f, cs * 0.6f, dice[1]);
                c.restore();
                if (landed.isEmpty()) {
                    label(c, stepsLeft > 0 ? "hop hop..." : "tap to roll", mid.centerX(), mid.bottom - cs * 0.45f, 12f, 0xFFFFF3C4);
                } else {
                    p.setColor(0xFFFFC83D);
                    r.set(mid.left + 10 * d, mid.bottom - cs * 0.85f, mid.right - 10 * d, mid.bottom - 10 * d);
                    c.drawRoundRect(r, 10 * d, 10 * d, p);
                    label(c, "OPEN " + landed.toUpperCase(java.util.Locale.getDefault()), mid.centerX(),
                            r.centerY() + 4 * d, 11f, 0xFF1B4332);
                }
                // the token
                RectF tf = field(token);
                float hop = stepsLeft > 0 ? (float) Math.sin(Math.min(1f, hopT / 0.2f) * Math.PI) * 14 * d : 0;
                p.setColor(0x55000000);
                c.drawCircle(tf.centerX() + 2 * d, tf.centerY() - cs * 0.18f + 3 * d, 9 * d, p);
                p.setColor(0xFFE63946);
                c.drawCircle(tf.centerX(), tf.centerY() - cs * 0.18f - hop, 9 * d, p);
                p.setColor(0x88FFFFFF);
                c.drawCircle(tf.centerX() - 3 * d, tf.centerY() - cs * 0.18f - hop - 3 * d, 3 * d, p);
            }
        }
    }
}
