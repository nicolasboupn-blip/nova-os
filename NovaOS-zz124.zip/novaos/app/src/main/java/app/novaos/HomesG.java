package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import static app.novaos.HomesA.lp;
import static app.novaos.HomesA.press;
import static app.novaos.HomesF.ask;
import static app.novaos.HomesF.col;
import static app.novaos.HomesF.gap;
import static app.novaos.HomesF.line;
import static app.novaos.HomesF.page;
import static app.novaos.HomesF.small;

/**
 * Ten home screens to play with that also do something: QUEST (your real day as an RPG with XP and levels),
 * GATE (solve a sum before scroll apps open), PIANO (play, record, learn songs), DOODLE (a drawing wall that is kept),
 * PARTY (wheel, dice, coin, teams), SCORE (a scoreboard with a round timer), FIVE (a daily five-letter word),
 * ARCADE (reaction, tap race, memory), PIXEL (16x16 pixel art) and SOUNDBOARD (pads and a beat maker).
 */
final class HomesG {
    private HomesG() {
    }

    // ================================================================== QUEST

    /** Your day as a role-playing game: real things you do (mood, checklist, focus, journal, workout ...) give XP,
     *  XP gives levels, and your apps are your items, rarer the more you use them. */
    static final class Quest extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView level;
        private final HomesF.Bar xpBar;
        private final TextView xpText;
        private final LinearLayout quests;

        Quest(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "QUEST", clock);
            LinearLayout hero = new LinearLayout(host);
            hero.setGravity(Gravity.CENTER_VERTICAL);
            TextView av = text(Profile.name().isEmpty() ? "?" : Profile.name().substring(0, 1).toUpperCase(Locale.ROOT), 28f,
                    HomeKit.onColor(Theme.ACCENT));
            av.setGravity(Gravity.CENTER);
            av.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(Theme.ACCENT);
            g.setStroke(dp(3), 0xFFFFC83D);
            av.setBackground(g);
            hero.addView(av, lp(dp(64), dp(64)));
            LinearLayout info = col(this);
            info.setPadding(dp(14), 0, 0, 0);
            info.addView(line(this, Profile.name(), 18f, Theme.TEXT));
            level = line(this, "", 13f, 0xFFFFC83D);
            info.addView(level);
            xpBar = new HomesF.Bar(host);
            LinearLayout.LayoutParams xp = lp(-1, dp(8));
            xp.topMargin = dp(6);
            info.addView(xpBar, xp);
            xpText = line(this, "", 10f, Theme.DIM);
            info.addView(xpText);
            hero.addView(info, lp(0, -2, 1f));
            b.addView(card(null, hero), gap(this));
            quests = col(this);
            b.addView(card("TODAY'S QUESTS  ·  tap one to go do it", quests), gap(this));
            b.addView(card("INVENTORY  ·  your apps, rarer the more you use them", inventory()), gap(this));
            tick();
        }

        /** {name, xp, done, layout to open or -1} */
        private List<Object[]> list() {
            List<Object[]> q = new ArrayList<>();
            q.add(new Object[] {"Tell NOVA your mood", 10, MoodLog.current() >= 0, -2});
            q.add(new Object[] {"Finish your morning checklist", 20,
                Life.morningCount() >= Life.morningItems().size() && !Life.morningItems().isEmpty(), 51});
            q.add(new Object[] {"Do one focus round", 25, Life.focusDone(Life.today()) > 0, 55});
            boolean moved = false;
            for (int i = 0; i < Life.WORKOUTS.length; i++) {
                moved |= Life.workout(Life.today(), i) > 0;
            }
            q.add(new Object[] {"Move your body (any workout)", 20, moved, 57});
            q.add(new Object[] {"Write a line in your journal", 15, !Life.journal(Life.today()).trim().isEmpty(), 59});
            long left = Math.round(MoneyWidget.budget() * 100);
            long start = MoneyWidget.weekStart();
            for (Object[] o : MoneyWidget.entries()) {
                if ((long) o[0] >= start) {
                    left += (long) o[1];
                }
            }
            q.add(new Object[] {"Stay inside your money budget", 15, left >= 0, 56});
            q.add(new Object[] {"Open fewer than 40 apps today", 10, HomeKit.today().size() < 40, -1});
            return q;
        }

        private static int levelOf(int xp) {
            return (int) Math.floor(Math.sqrt(xp / 50.0)) + 1;
        }

        private static int xpFor(int level) {
            return (level - 1) * (level - 1) * 50;
        }

        private void fillQuests(List<Object[]> q) {
            quests.removeAllViews();
            for (final Object[] o : q) {
                boolean done = (boolean) o[2];
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, dp(7), 0, dp(7));
                r.addView(text(done ? "✅" : "⬜", 16f, Theme.TEXT));
                TextView n = line(this, "  " + o[0], 14f, done ? Theme.DIM : Theme.TEXT);
                r.addView(n, lp(0, -2, 1f));
                r.addView(line(this, "+" + o[1] + " XP", 11f, done ? 0xFF4CD964 : 0xFFFFC83D));
                final int target = (int) o[3];
                r.setOnClickListener(v -> {
                    if (target == -2) {
                        new AlertDialog.Builder(host).setTitle("How are you right now?")
                                .setItems(MoodLog.FACES, (d, w) -> {
                                    MoodLog.log(w);
                                    tick();
                                }).show();
                    } else if (target > 0) {
                        Prefs.putInt(K_LAYOUT, target);
                        host.toast("Switched to " + NAMES[target].toUpperCase(Locale.ROOT) + ". Change back in the look picker.");
                        host.showHome();
                    }
                });
                quests.addView(r, lp(-1, -2));
            }
        }

        private View inventory() {
            Map<String, Integer> n = new HashMap<>();
            for (Object[] o : HomeKit.history()) {
                String k = (String) o[0];
                n.put(k, (n.containsKey(k) ? n.get(k) : 0) + 1);
            }
            LinearLayout g = col(this);
            LinearLayout row = null;
            List<AppEntry> apps = appsFor(16);
            for (int i = 0; i < apps.size(); i++) {
                final AppEntry e = apps.get(i);
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    g.addView(row, lp(-1, -2));
                }
                int c = n.containsKey(e.pkg) ? n.get(e.pkg) : 0;
                int rar = c >= 25 ? 0xFFFF9800 : c >= 10 ? 0xFFAB47BC : c >= 3 ? 0xFF42A5F5 : 0xFF8A8A8A;
                String rn = c >= 25 ? "LEGEND" : c >= 10 ? "EPIC" : c >= 3 ? "RARE" : "COMMON";
                LinearLayout cell = col(this);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
                gd.setCornerRadius(dp(14));
                gd.setColor(Theme.BG2);
                gd.setStroke(dp(2), rar);
                cell.setBackground(gd);
                cell.setPadding(0, dp(8), 0, dp(6));
                android.widget.ImageView iv = new android.widget.ImageView(host);
                iv.setImageDrawable(Theme.tint(host, e.icon));
                cell.addView(iv, lp(dp(36), dp(36)));
                cell.addView(text(rn, 7.5f, rar));
                cell.setOnClickListener(v -> host.launch(e));
                cell.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(3), dp(3), dp(3), dp(3));
                row.addView(cell, p);
            }
            while (row != null && row.getChildCount() < 4) {
                row.addView(new View(host), lp(0, 1, 1f));
            }
            return g;
        }

        @Override
        long tickMs() {
            return 5000;
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            List<Object[]> q = list();
            int today = 0;
            for (Object[] o : q) {
                if ((boolean) o[2]) {
                    today += (int) o[1];
                }
            }
            // bank yesterday's best when the day changes
            String day = Life.today();
            if (!day.equals(Prefs.getString("xp_day", ""))) {
                Prefs.putInt("xp_bank", Prefs.getInt("xp_bank", 0) + Prefs.getInt("xp_today", 0));
                Prefs.putString("xp_day", day);
                Prefs.putInt("xp_today", 0);
            }
            int best = Math.max(today, Prefs.getInt("xp_today", 0));
            Prefs.putInt("xp_today", best);
            int total = Prefs.getInt("xp_bank", 0) + best;
            int lv = levelOf(total);
            if (lv > Prefs.getInt("xp_level", 1)) {
                Prefs.putInt("xp_level", lv);
                host.toast("LEVEL UP! You are level " + lv + " 🎉");
                host.confetti(getWidth() / 2f, getHeight() / 4f);
            }
            level.setText("Level " + lv + "   ·   " + best + " XP today");
            int a = xpFor(lv);
            int z = xpFor(lv + 1);
            xpBar.set((total - a) / (float) (z - a), 0xFFFFC83D);
            xpText.setText(total + " XP  ·  " + (z - total) + " to level " + (lv + 1));
            fillQuests(q);
        }
    }

    // ================================================================== GATE

    /** Apps that eat your time (social, video, games) are locked behind a quick sum. Everything else opens normally. */
    static final class Gate extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final TextView stats;
        private long lockedUntil;
        private final Random rnd = new Random();

        Gate(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "BRAIN GATE", clock);
            stats = line(this, "", 12f, Theme.ACCENT);
            stats.setPadding(0, dp(6), 0, 0);
            b.addView(stats);
            LinearLayout lvl = new LinearLayout(host);
            String[] n = {"EASY", "MEDIUM", "HARD"};
            for (int i = 0; i < 3; i++) {
                final int k = i;
                TextView t = small(this, n[i], () -> {
                    Prefs.putInt("gate_level", k);
                    host.toast("Gate: " + n[k].toLowerCase(Locale.ROOT));
                    host.showHome();
                });
                if (Prefs.getInt("gate_level", 0) == i) {
                    t.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
                    t.setTextColor(HomeKit.onColor(Theme.ACCENT));
                }
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                lvl.addView(t, p);
            }
            b.addView(lvl, gap(this));
            Map<String, List<AppEntry>> f = HomesD.Folders.sort(host);
            List<AppEntry> locked = new ArrayList<>();
            for (String k : new String[] {"Social", "Video", "Games"}) {
                if (f.containsKey(k)) {
                    locked.addAll(f.get(k));
                }
            }
            LinearLayout lg = col(this);
            LinearLayout row = null;
            for (int i = 0; i < locked.size(); i++) {
                final AppEntry e = locked.get(i);
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    lg.addView(row, lp(-1, -2));
                }
                FrameLayout cell = new FrameLayout(host);
                View tile = appTile(e, 44, true);
                tile.setOnClickListener(v -> challenge(e));
                tile.setAlpha(0.55f);
                cell.addView(tile);
                TextView lock = text("🔒", 14f, Theme.TEXT);
                cell.addView(lock, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
                row.addView(cell, lp(0, -2, 1f));
            }
            while (row != null && row.getChildCount() < 4) {
                row.addView(new View(host), lp(0, 1, 1f));
            }
            if (locked.isEmpty()) {
                lg.addView(line(this, "No social, video or game apps found. Lucky you.", 12f, Theme.DIM));
            }
            b.addView(card("LOCKED  ·  solve to open", lg), gap(this));
            List<AppEntry> free = new ArrayList<>();
            for (AppEntry e : appsFor(40)) {
                if (!locked.contains(e) && free.size() < 12) {
                    free.add(e);
                }
            }
            b.addView(card("OPEN", HomesD.grid(this, free, 4, 44, true)), gap(this));
            tick();
        }

        private void challenge(final AppEntry e) {
            long now = System.currentTimeMillis();
            if (now < lockedUntil) {
                host.toast("Wait " + ((lockedUntil - now) / 1000 + 1) + " s, then try again");
                return;
            }
            int lv = Prefs.getInt("gate_level", 0);
            int a;
            int bb;
            int c;
            String q;
            final int ans;
            if (lv == 0) {
                a = 10 + rnd.nextInt(60);
                bb = 10 + rnd.nextInt(40);
                q = a + " + " + bb;
                ans = a + bb;
            } else if (lv == 1) {
                a = 3 + rnd.nextInt(10);
                bb = 6 + rnd.nextInt(14);
                q = a + " × " + bb;
                ans = a * bb;
            } else {
                a = 6 + rnd.nextInt(14);
                bb = 6 + rnd.nextInt(10);
                c = 10 + rnd.nextInt(90);
                q = a + " × " + bb + " − " + c;
                ans = a * bb - c;
            }
            final EditText in = new EditText(host);
            in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
            in.setHint("answer");
            new AlertDialog.Builder(host).setTitle("Open " + e.label + "?").setMessage(q + " = ?").setView(in)
                    .setPositiveButton("OPEN", (d, w) -> {
                        Prefs.putInt("gate_tries", Prefs.getInt("gate_tries", 0) + 1);
                        int got;
                        try {
                            got = Integer.parseInt(in.getText().toString().trim());
                        } catch (NumberFormatException ex) {
                            got = Integer.MIN_VALUE;
                        }
                        if (got == ans) {
                            Prefs.putInt("gate_ok", Prefs.getInt("gate_ok", 0) + 1);
                            host.launch(e);
                        } else {
                            lockedUntil = System.currentTimeMillis() + 10000;
                            host.toast("Nope, it was " + ans + ". Wait 10 s.");
                            host.buzz(80);
                        }
                        tick();
                    })
                    .setNegativeButton("NOT NOW", (d, w) -> {
                        Prefs.putInt("gate_skipped", Prefs.getInt("gate_skipped", 0) + 1);
                        tick();
                    }).show();
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            int ok = Prefs.getInt("gate_ok", 0);
            int tries = Prefs.getInt("gate_tries", 0);
            int skipped = Prefs.getInt("gate_skipped", 0);
            stats.setText("solved " + ok + " of " + tries + "   ·   changed your mind " + skipped + "× 👏");
        }
    }

    // ================================================================== PIANO

    /** Two octaves you can play with several fingers, three sounds, record and play back, and a learn mode that shows
     *  you which key comes next. */
    static final class Piano extends AltHome {
        static final String[] SONGS = {"Twinkle Twinkle", "Ode to Joy", "Happy Birthday"};
        static final int[][] MELODY = {
            {60, 60, 67, 67, 69, 69, 67, 65, 65, 64, 64, 62, 62, 60},
            {64, 64, 65, 67, 67, 65, 64, 62, 60, 60, 62, 64, 64, 62, 62},
            {67, 67, 69, 67, 72, 71, 67, 67, 69, 67, 74, 72}};
        private final Keys low;
        private final Keys high;
        private final TextView status;
        private int voice;
        private final List<long[]> rec = new ArrayList<>();
        private long recStart = -1;
        private int song = -1;
        private int songPos;
        private final Handler h = new Handler(Looper.getMainLooper());

        Piano(NovaActivity host) {
            super(host);
            LinearLayout outer = col(this);
            outer.setPadding(dp(10), dp(44), dp(10), 0);
            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = text("PIANO", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.25f);
            top.addView(t, lp(0, -2, 1f));
            for (int i = 0; i < Synth.VOICES.length; i++) {
                final int k = i;
                LinearLayout.LayoutParams p = lp(-2, -2);
                p.leftMargin = dp(4);
                top.addView(small(this, Synth.VOICES[i], () -> setVoice(k)), p);
            }
            outer.addView(top, lp(-1, -2));
            LinearLayout ctl = new LinearLayout(host);
            ctl.setPadding(0, dp(8), 0, dp(8));
            ctl.addView(small(this, "● REC", this::record), lp(0, -2, 1f));
            LinearLayout.LayoutParams p2 = lp(0, -2, 1f);
            p2.leftMargin = dp(4);
            ctl.addView(small(this, "▶ PLAY", this::playBack), p2);
            LinearLayout.LayoutParams p3 = lp(0, -2, 1.3f);
            p3.leftMargin = dp(4);
            ctl.addView(small(this, "♫ LEARN", () -> new AlertDialog.Builder(host).setTitle("Learn a song")
                    .setItems(SONGS, (d, w) -> {
                        song = w;
                        songPos = 0;
                        hint();
                    }).show()), p3);
            outer.addView(ctl, lp(-1, -2));
            status = line(this, "two octaves  ·  use several fingers", 11f, Theme.DIM);
            status.setGravity(Gravity.CENTER);
            outer.addView(status, lp(-1, -2));
            high = new Keys(host, 72);
            low = new Keys(host, 60);
            LinearLayout.LayoutParams kp = lp(-1, 0, 1f);
            kp.topMargin = dp(10);
            outer.addView(high, kp);
            LinearLayout.LayoutParams kp2 = lp(-1, 0, 1f);
            kp2.setMargins(0, dp(10), 0, dp(10));
            outer.addView(low, kp2);
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
        }

        private void setVoice(int k) {
            voice = k;
            status.setText("sound: " + Synth.VOICES[k].toLowerCase(Locale.ROOT));
        }

        private void record() {
            if (recStart >= 0) {
                recStart = -1;
                status.setText("saved " + rec.size() + " notes. Press PLAY.");
                return;
            }
            rec.clear();
            recStart = System.currentTimeMillis();
            status.setText("● recording... press REC again to stop");
        }

        private void playBack() {
            if (rec.isEmpty()) {
                status.setText("record something first");
                return;
            }
            for (final long[] n : rec) {
                h.postDelayed(() -> {
                    Synth.note((int) n[1], (int) n[2]);
                    low.flash((int) n[1]);
                    high.flash((int) n[1]);
                }, n[0]);
            }
        }

        private void hint() {
            if (song < 0) {
                return;
            }
            if (songPos >= MELODY[song].length) {
                status.setText("🎉 You played " + SONGS[song] + "!");
                host.confetti(getWidth() / 2f, getHeight() / 3f);
                song = -1;
                low.setHint(-1);
                high.setHint(-1);
                return;
            }
            int n = MELODY[song][songPos];
            low.setHint(n);
            high.setHint(n);
            status.setText(SONGS[song] + ": " + (songPos + 1) + " / " + MELODY[song].length + "  ·  press the glowing key");
        }

        void pressed(int midi) {
            Synth.note(midi, voice);
            if (recStart >= 0) {
                rec.add(new long[] {System.currentTimeMillis() - recStart, midi, voice});
            }
            if (song >= 0 && midi == MELODY[song][songPos]) {
                songPos++;
                hint();
            }
        }

        /** One octave of keys starting at base (a C). */
        final class Keys extends View {
            private final int base;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Map<Integer, Integer> down = new HashMap<>();
            private final Map<Integer, Long> flashes = new HashMap<>();
            private int hint = -1;
            private final int[] whites = {0, 2, 4, 5, 7, 9, 11};
            private final int[] blacks = {1, 3, -1, 6, 8, 10};

            Keys(android.content.Context c, int base) {
                super(c);
                this.base = base;
            }

            void setHint(int n) {
                hint = n;
                invalidate();
            }

            void flash(int n) {
                flashes.put(n, System.currentTimeMillis() + 180);
                invalidate();
                postDelayed(this::invalidate, 200);
            }

            private int noteAt(float x, float y) {
                float ww = getWidth() / 7f;
                if (y < getHeight() * 0.6f) {
                    for (int i = 0; i < blacks.length; i++) {
                        if (blacks[i] < 0) {
                            continue;
                        }
                        float cx = (i + 1) * ww;
                        if (Math.abs(x - cx) < ww * 0.3f) {
                            return base + blacks[i];
                        }
                    }
                }
                int i = Math.max(0, Math.min(6, (int) (x / ww)));
                return base + whites[i];
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                int a = e.getActionMasked();
                int idx = e.getActionIndex();
                int id = e.getPointerId(idx);
                if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                    int n = noteAt(e.getX(idx), e.getY(idx));
                    down.put(id, n);
                    pressed(n);
                    invalidate();
                } else if (a == MotionEvent.ACTION_MOVE) {
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int pid = e.getPointerId(i);
                        int n = noteAt(e.getX(i), e.getY(i));
                        Integer was = down.get(pid);
                        if (was == null || was != n) {
                            down.put(pid, n);
                            pressed(n);
                            invalidate();
                        }
                    }
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) {
                    down.remove(id);
                    invalidate();
                } else if (a == MotionEvent.ACTION_CANCEL) {
                    down.clear();
                    invalidate();
                }
                return true;
            }

            private boolean lit(int n) {
                Long f = flashes.get(n);
                return down.containsValue(n) || (f != null && f > System.currentTimeMillis());
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float w = getWidth();
                float h = getHeight();
                float ww = w / 7f;
                for (int i = 0; i < 7; i++) {
                    int n = base + whites[i];
                    p.setColor(lit(n) ? Theme.ACCENT : n == hint ? 0xFFFFE08A : 0xFFF7F7F7);
                    c.drawRoundRect(new RectF(i * ww + 1.5f * d, 0, (i + 1) * ww - 1.5f * d, h), 6 * d, 6 * d, p);
                    if (i == 0) {
                        p.setColor(0xFF888888);
                        p.setTextSize(10 * d);
                        p.setTextAlign(Paint.Align.CENTER);
                        c.drawText("C" + (base / 12 - 1), ww / 2, h - 10 * d, p);
                    }
                }
                for (int i = 0; i < blacks.length; i++) {
                    if (blacks[i] < 0) {
                        continue;
                    }
                    int n = base + blacks[i];
                    p.setColor(lit(n) ? Theme.ACCENT : n == hint ? 0xFFFFB347 : 0xFF161616);
                    float cx = (i + 1) * ww;
                    c.drawRoundRect(new RectF(cx - ww * 0.3f, 0, cx + ww * 0.3f, h * 0.6f), 4 * d, 4 * d, p);
                }
            }
        }
    }

    // ================================================================== DOODLE

    /** A drawing wall that stays: colours, sizes, eraser, undo, and share your picture. */
    static final class Doodle extends AltHome {
        private final Pad pad;

        Doodle(NovaActivity host) {
            super(host);
            LinearLayout outer = col(this);
            outer.setPadding(dp(10), dp(44), dp(10), 0);
            pad = new Pad(host);
            LinearLayout.LayoutParams pp = lp(-1, 0, 1f);
            outer.addView(pad, pp);
            LinearLayout colors = new LinearLayout(host);
            colors.setPadding(0, dp(8), 0, dp(4));
            int[] cs = {0xFF111111, 0xFFFFFFFF, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA};
            for (final int c : cs) {
                View v = new View(host);
                android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
                g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                g.setColor(c);
                g.setStroke(dp(2), 0x55888888);
                v.setBackground(g);
                v.setOnClickListener(x -> {
                    pad.color = c;
                    pad.eraser = false;
                });
                LinearLayout.LayoutParams p = lp(0, dp(30), 1f);
                p.setMargins(dp(4), 0, dp(4), 0);
                colors.addView(v, p);
            }
            outer.addView(colors, lp(-1, -2));
            LinearLayout tools = new LinearLayout(host);
            tools.setPadding(0, dp(4), 0, dp(4));
            String[] n = {"S", "M", "L", "ERASE", "UNDO", "CLEAR", "SHARE"};
            Runnable[] r = {() -> pad.size = 4, () -> pad.size = 10, () -> pad.size = 24, () -> pad.eraser = true, pad::undo,
                () -> new AlertDialog.Builder(host).setTitle("Clear the whole wall?").setPositiveButton("CLEAR", (d, w) -> pad.clear())
                        .setNegativeButton("NO", null).show(), this::share};
            for (int i = 0; i < n.length; i++) {
                LinearLayout.LayoutParams p = lp(0, -2, i >= 3 ? 1.4f : 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                TextView t = small(this, n[i], r[i]);
                t.setPadding(0, dp(8), 0, dp(8));
                tools.addView(t, p);
            }
            outer.addView(tools, lp(-1, -2));
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
        }

        private void share() {
            try {
                File dir = new File(host.getCacheDir(), "share");
                dir.mkdirs();
                File f = new File(dir, "nova-doodle.png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    pad.render().compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                host.startActivity(Intent.createChooser(i, "Share your doodle"));
            } catch (Exception e) {
                host.toast("Could not share the picture");
            }
        }

        final class Pad extends View {
            int color = 0xFF111111;
            int size = 10;
            boolean eraser;
            private Bitmap base;
            private final List<Object[]> strokes = new ArrayList<>(); // path, color, width
            private Path cur;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final File file;

            Pad(android.content.Context c) {
                super(c);
                file = new File(c.getFilesDir(), "doodle.png");
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
            }

            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                if (w <= 0 || h <= 0) {
                    return;
                }
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);
                c.drawColor(0xFFFFFDF6);
                if (file.exists()) {
                    Bitmap old = BitmapFactory.decodeFile(file.getPath());
                    if (old != null) {
                        c.drawBitmap(old, null, new RectF(0, 0, w, h), null);
                    }
                }
                base = b;
            }

            Bitmap render() {
                Bitmap out = base.copy(Bitmap.Config.ARGB_8888, true);
                Canvas c = new Canvas(out);
                for (Object[] s : strokes) {
                    p.setColor((int) s[1]);
                    p.setStrokeWidth((float) s[2]);
                    c.drawPath((Path) s[0], p);
                }
                return out;
            }

            void undo() {
                if (!strokes.isEmpty()) {
                    strokes.remove(strokes.size() - 1);
                    invalidate();
                    save();
                }
            }

            void clear() {
                strokes.clear();
                if (base != null) {
                    base.eraseColor(0xFFFFFDF6);
                }
                invalidate();
                save();
            }

            private void save() {
                if (base == null) {
                    return;
                }
                final Bitmap snap = render();
                new Thread(() -> {
                    try (FileOutputStream o = new FileOutputStream(file)) {
                        snap.compress(Bitmap.CompressFormat.PNG, 100, o);
                    } catch (Exception ignored) {
                        // keep drawing anyway
                    }
                }).start();
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float d = getResources().getDisplayMetrics().density;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        getParent().requestDisallowInterceptTouchEvent(true);
                        cur = new Path();
                        cur.moveTo(e.getX(), e.getY());
                        cur.lineTo(e.getX() + 0.1f, e.getY());
                        strokes.add(new Object[] {cur, eraser ? 0xFFFFFDF6 : color, (eraser ? 28 : size) * d});
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (cur != null) {
                            cur.lineTo(e.getX(), e.getY());
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        cur = null;
                        save();
                        break;
                    default:
                        cur = null;
                        break;
                }
                invalidate();
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                if (base != null) {
                    c.drawBitmap(base, 0, 0, null);
                }
                for (Object[] s : strokes) {
                    p.setColor((int) s[1]);
                    p.setStrokeWidth((float) s[2]);
                    c.drawPath((Path) s[0], p);
                }
            }
        }
    }

    // ================================================================== PARTY

    /** Party tools: a wheel to spin (your own entries), dice, a coin and random teams. */
    static final class Party extends AltHome {
        private final FrameLayout area;
        private final TextView result;
        private final Random rnd = new Random();

        Party(NovaActivity host) {
            super(host);
            LinearLayout outer = col(this);
            outer.setPadding(dp(12), dp(44), dp(12), 0);
            TextView t = text("PARTY", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.25f);
            outer.addView(t);
            LinearLayout tabs = new LinearLayout(host);
            tabs.setPadding(0, dp(8), 0, dp(8));
            String[] n = {"WHEEL", "DICE", "COIN", "TEAMS"};
            for (int i = 0; i < n.length; i++) {
                final int k = i;
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                tabs.addView(small(this, n[i], () -> show(k)), p);
            }
            outer.addView(tabs, lp(-1, -2));
            area = new FrameLayout(host);
            outer.addView(area, lp(-1, 0, 1f));
            result = text("", 20f, Theme.TEXT);
            result.setGravity(Gravity.CENTER);
            result.setPadding(0, dp(8), 0, dp(8));
            outer.addView(result, lp(-1, -2));
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            show(0);
        }

        private void show(int tab) {
            area.removeAllViews();
            result.setText("");
            if (tab == 0) {
                final Wheel w = new Wheel(host, entries());
                area.addView(w, new FrameLayout.LayoutParams(-1, -1));
                LinearLayout row = new LinearLayout(host);
                row.addView(small(this, "SPIN", w::spin), lp(0, -2, 1f));
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.leftMargin = dp(6);
                row.addView(small(this, "EDIT", () -> ask(host, "What's on the wheel?", "one per line",
                        String.join("\n", entries()), true, s -> {
                            Prefs.putString("party_wheel", s);
                            show(0);
                        })), p);
                area.addView(row, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
            } else if (tab == 1) {
                final Dice dc = new Dice(host);
                area.addView(dc, new FrameLayout.LayoutParams(-1, -1));
                dc.setOnClickListener(v -> dc.roll());
                result.setText("tap to roll  ·  hold for 1, 2 or 3 dice");
                dc.setOnLongClickListener(v -> {
                    dc.count = dc.count % 3 + 1;
                    dc.invalidate();
                    return true;
                });
            } else if (tab == 2) {
                TextView c = text("🪙\nTAP TO FLIP", 26f, Theme.TEXT);
                c.setGravity(Gravity.CENTER);
                c.setOnClickListener(v -> host.coinFlip(heads -> result.setText(heads ? "HEADS" : "TAILS")));
                area.addView(c, new FrameLayout.LayoutParams(-1, -1));
            } else {
                LinearLayout l = col(this);
                l.setGravity(Gravity.CENTER_HORIZONTAL);
                final TextView out = line(this, "Add names, then make teams.", 15f, Theme.TEXT);
                out.setGravity(Gravity.CENTER);
                ScrollView sv = new ScrollView(host);
                sv.addView(out);
                l.addView(sv, lp(-1, 0, 1f));
                LinearLayout row = new LinearLayout(host);
                row.addView(small(this, "NAMES", () -> ask(host, "Who plays?", "one name per line",
                        Prefs.getString("party_names", ""), true, s -> Prefs.putString("party_names", s))), lp(0, -2, 1f));
                for (int k = 2; k <= 4; k++) {
                    final int teams = k;
                    LinearLayout.LayoutParams p = lp(0, -2, 1f);
                    p.leftMargin = dp(4);
                    row.addView(small(this, k + " TEAMS", () -> out.setText(teams(teams))), p);
                }
                l.addView(row, lp(-1, -2));
                area.addView(l, new FrameLayout.LayoutParams(-1, -1));
            }
        }

        private List<String> entries() {
            List<String> l = new ArrayList<>();
            for (String s : Prefs.getString("party_wheel", "Pizza\nKebab\nBurger\nSushi\nPasta\nTacos").split("\n")) {
                if (!s.trim().isEmpty()) {
                    l.add(s.trim());
                }
            }
            if (l.size() < 2) {
                l.add("Yes");
                l.add("No");
            }
            return l;
        }

        private String teams(int n) {
            List<String> names = new ArrayList<>();
            for (String s : Prefs.getString("party_names", "").split("\n")) {
                if (!s.trim().isEmpty()) {
                    names.add(s.trim());
                }
            }
            if (names.size() < n) {
                return "Add at least " + n + " names first (NAMES).";
            }
            Collections.shuffle(names, rnd);
            StringBuilder b = new StringBuilder();
            for (int t = 0; t < n; t++) {
                b.append("TEAM ").append(t + 1).append('\n');
                for (int i = t; i < names.size(); i += n) {
                    b.append(names.get(i)).append('\n');
                }
                b.append('\n');
            }
            host.buzz(20);
            return b.toString().trim();
        }

        final class Wheel extends View {
            private final List<String> items;
            private float angle;
            private float speed;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private long last;
            private int lastSeg = -1;
            private final int[] cols = {0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A,
                0xFF26A69A};

            Wheel(android.content.Context c, List<String> items) {
                super(c);
                this.items = items;
                angle = new Random().nextFloat() * 360;
            }

            void spin() {
                if (speed > 0) {
                    return;
                }
                speed = 900 + rnd.nextInt(700);
                last = 0;
                result.setText("");
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                long now = System.currentTimeMillis();
                if (speed > 0) {
                    float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1000f);
                    angle = (angle + speed * dt) % 360;
                    speed = Math.max(0, speed - 380 * dt);
                    int seg = segAtTop();
                    if (seg != lastSeg) {
                        lastSeg = seg;
                        Synth.tone(1400, 25);
                    }
                    if (speed == 0) {
                        result.setText("→ " + items.get(segAtTop()) + " ←");
                        host.buzz(40);
                    } else {
                        postInvalidateOnAnimation();
                    }
                }
                last = now;
                float d = getResources().getDisplayMetrics().density;
                float cx = getWidth() / 2f;
                float cy = (getHeight() - 50 * d) / 2f + 10 * d;
                float r = Math.min(cx, cy) - 12 * d;
                int n = items.size();
                float sw = 360f / n;
                RectF box = new RectF(cx - r, cy - r, cx + r, cy + r);
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTextSize(13 * d);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                for (int i = 0; i < n; i++) {
                    p.setColor(cols[i % cols.length]);
                    c.drawArc(box, angle + i * sw, sw, true, p);
                    c.save();
                    c.rotate(angle + i * sw + sw / 2, cx, cy);
                    p.setColor(0xFFFFFFFF);
                    String s = items.get(i);
                    if (s.length() > 12) {
                        s = s.substring(0, 11) + "…";
                    }
                    c.drawText(s, cx + r - 12 * d, cy + 5 * d, p);
                    c.restore();
                }
                p.setColor(0xFFFFFFFF);
                c.drawCircle(cx, cy, 16 * d, p);
                Path tri = new Path();
                tri.moveTo(cx, cy - r + 14 * d);
                tri.lineTo(cx - 12 * d, cy - r - 10 * d);
                tri.lineTo(cx + 12 * d, cy - r - 10 * d);
                tri.close();
                p.setColor(Theme.TEXT);
                c.drawPath(tri, p);
            }

            private int segAtTop() {
                int n = items.size();
                float sw = 360f / n;
                float a = ((270 - angle) % 360 + 360) % 360;
                return Math.min(n - 1, (int) (a / sw));
            }
        }

        final class Dice extends View {
            int count = 2;
            private final int[] vals = {3, 5, 1};
            private float rolling;
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Dice(android.content.Context c) {
                super(c);
            }

            void roll() {
                rolling = 0.7f;
                host.buzz(15);
                invalidate();
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                if (rolling > 0) {
                    rolling -= 0.016f;
                    for (int i = 0; i < 3; i++) {
                        vals[i] = 1 + rnd.nextInt(6);
                    }
                    if (rolling <= 0) {
                        int sum = 0;
                        for (int i = 0; i < count; i++) {
                            sum += vals[i];
                        }
                        result.setText(count > 1 ? "total " + sum : "you rolled " + vals[0]);
                        Synth.pad(9);
                    } else {
                        postInvalidateOnAnimation();
                    }
                }
                float s = Math.min(getWidth() / (count + 0.6f), 120 * d);
                float y = getHeight() / 2f;
                for (int i = 0; i < count; i++) {
                    float x = getWidth() / 2f + (i - (count - 1) / 2f) * s * 1.15f;
                    c.save();
                    c.rotate(rolling > 0 ? rnd.nextInt(30) - 15 : 0, x, y);
                    p.setColor(0xFFFFFFFF);
                    c.drawRoundRect(new RectF(x - s / 2, y - s / 2, x + s / 2, y + s / 2), s * 0.18f, s * 0.18f, p);
                    p.setColor(0xFF222222);
                    int v = vals[i];
                    float o = s * 0.26f;
                    float pr = s * 0.08f;
                    boolean[] pip = {
                        v >= 4, false, v >= 2,
                        v == 6, v % 2 == 1, v == 6,
                        v >= 2, false, v >= 4};
                    for (int k = 0; k < 9; k++) {
                        if (pip[k]) {
                            c.drawCircle(x + (k % 3 - 1) * o, y + (k / 3 - 1) * o, pr, p);
                        }
                    }
                    c.restore();
                }
            }
        }
    }

    // ================================================================== SCORE

    /** A scoreboard for game night or sports: players with big scores, plus or minus, a leader crown and a round timer. */
    static final class Score extends AltHome {
        private final TextView[] clock = new TextView[1];
        private final LinearLayout list;
        private final TextView timer;
        private long timerEnd;
        private long timerLeft = 180000;
        private boolean buzzed = true;

        Score(NovaActivity host) {
            super(host);
            LinearLayout b = page(this, "SCORE", clock);
            list = col(this);
            b.addView(list, gap(this));
            LinearLayout row = new LinearLayout(host);
            row.addView(small(this, "+ PLAYER", () -> ask(host, "Player name", "e.g. Nico", "", false, s -> {
                if (!s.trim().isEmpty()) {
                    List<String> l = Life.lines("score_players");
                    l.add(s.trim().replace("|", "") + "|0");
                    Life.saveLines("score_players", l);
                    fill();
                }
            })), lp(0, -2, 1f));
            LinearLayout.LayoutParams p = lp(0, -2, 1f);
            p.leftMargin = dp(6);
            row.addView(small(this, "ZERO ALL", () -> {
                List<String> l = Life.lines("score_players");
                for (int i = 0; i < l.size(); i++) {
                    l.set(i, l.get(i).split("\\|")[0] + "|0");
                }
                Life.saveLines("score_players", l);
                fill();
            }), p);
            LinearLayout.LayoutParams p2 = lp(0, -2, 1f);
            p2.leftMargin = dp(6);
            row.addView(small(this, "REMOVE ALL", () -> new AlertDialog.Builder(host).setTitle("Remove all players?")
                    .setPositiveButton("YES", (d, w) -> {
                        Life.saveLines("score_players", new ArrayList<>());
                        fill();
                    }).setNegativeButton("NO", null).show()), p2);
            b.addView(row, gap(this));
            LinearLayout t = col(this);
            t.setGravity(Gravity.CENTER_HORIZONTAL);
            timer = text("03:00", 48f, Theme.TEXT);
            timer.setTypeface(Theme.LIGHT);
            timer.setOnClickListener(v -> toggleTimer());
            t.addView(timer);
            LinearLayout presets = new LinearLayout(host);
            int[] mins = {1, 3, 5, 10};
            for (final int m : mins) {
                LinearLayout.LayoutParams pp = lp(0, -2, 1f);
                pp.setMargins(dp(2), dp(6), dp(2), 0);
                presets.addView(small(this, m + " MIN", () -> {
                    timerEnd = 0;
                    timerLeft = m * 60000L;
                    buzzed = true;
                    tick();
                }), pp);
            }
            t.addView(presets, lp(-1, -2));
            t.addView(line(this, "tap the time to start or pause", 10f, Theme.DIM));
            b.addView(card("ROUND TIMER", t), gap(this));
            fill();
            tick();
        }

        private void toggleTimer() {
            long now = System.currentTimeMillis();
            if (timerEnd > now) {
                timerLeft = timerEnd - now;
                timerEnd = 0;
            } else {
                timerEnd = now + Math.max(1000, timerLeft);
                buzzed = false;
            }
            host.buzz(10);
            tick();
        }

        private void fill() {
            list.removeAllViews();
            final List<String> l = Life.lines("score_players");
            int best = Integer.MIN_VALUE;
            for (String s : l) {
                try {
                    best = Math.max(best, Integer.parseInt(s.split("\\|")[1]));
                } catch (Exception ignored) {
                    // broken
                }
            }
            if (l.isEmpty()) {
                list.addView(line(this, "Add players to start keeping score.", 13f, Theme.DIM));
            }
            for (int i = 0; i < l.size(); i++) {
                final int k = i;
                String[] f = l.get(i).split("\\|");
                int pts = 0;
                try {
                    pts = Integer.parseInt(f[1]);
                } catch (Exception ignored) {
                    // broken
                }
                LinearLayout r = new LinearLayout(host);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
                r.setPadding(dp(14), dp(8), dp(8), dp(8));
                TextView n = line(this, (pts == best && l.size() > 1 && best > 0 ? "👑 " : "") + f[0], 16f, Theme.TEXT);
                r.addView(n, lp(0, -2, 1f));
                TextView v = text(String.valueOf(pts), 30f, Theme.ACCENT);
                v.setPadding(dp(8), 0, dp(8), 0);
                r.addView(v);
                int[] steps = {-1, 1, 5};
                for (final int s : steps) {
                    TextView bt = small(this, (s > 0 ? "+" : "") + s, () -> {
                        String[] g = l.get(k).split("\\|");
                        int now = 0;
                        try {
                            now = Integer.parseInt(g[1]);
                        } catch (Exception ignored) {
                            // broken
                        }
                        l.set(k, g[0] + "|" + (now + s));
                        Life.saveLines("score_players", l);
                        host.buzz(8);
                        fill();
                    });
                    LinearLayout.LayoutParams bp = lp(dp(44), -2);
                    bp.leftMargin = dp(3);
                    r.addView(bt, bp);
                }
                LinearLayout.LayoutParams rp = lp(-1, -2);
                rp.topMargin = dp(6);
                list.addView(r, rp);
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
            long now = System.currentTimeMillis();
            long left = timerEnd > now ? timerEnd - now : (timerEnd > 0 ? 0 : timerLeft);
            if (timerEnd > 0 && timerEnd <= now && !buzzed) {
                buzzed = true;
                Synth.pad(4);
                host.buzz(400);
                timerEnd = 0;
                timerLeft = 0;
                host.toast("TIME!");
            }
            timer.setText(String.format(Locale.ROOT, "%02d:%02d", left / 60000, (left / 1000) % 60));
            timer.setTextColor(timerEnd > now && left < 10000 ? 0xFFFF5A4E : Theme.TEXT);
        }

        @Override
        long tickMs() {
            return 250;
        }
    }

    // ================================================================== FIVE

    /** A new five-letter word every day: six tries, green = right place, yellow = in the word. Swiss keyboard. */
    static final class Five extends AltHome {
        static final String[] WORDS = ("APPLE BEACH BRAIN BREAD CHAIR CLOUD DANCE DREAM EARTH FLAME FRUIT GHOST GRASS HEART "
                + "HOUSE LIGHT MONEY MUSIC NIGHT OCEAN PARTY PIANO PLANT PLANE RIVER ROBOT SMILE SNAKE SPACE STORM SUGAR TABLE "
                + "TIGER TRAIN WATER WORLD YOUTH ZEBRA ANGEL BLOCK BRAVE CANDY CHESS CLOCK CRANE CROWN DRINK EAGLE FIELD FLOOR "
                + "FROST GIANT GLASS GRAPE HONEY HORSE JUICE KNIFE LEMON MAGIC MANGO METAL MOUSE NURSE OLIVE PAINT PEARL PHONE "
                + "PIZZA QUEEN RADIO SALAD SHEEP SHIRT SKATE SLEEP SNACK SPOON STONE SWEET TEETH TOAST TOWER TRUCK WHALE "
                + "WHEEL ALARM BADGE BENCH BERRY BLADE BLAST BOARD BRUSH CABIN CAMEL CANAL CARGO CHALK CHARM CHEST CIDER "
                + "CLIMB CORAL COUCH CRISP CURVE DAISY DELTA DIARY DRIFT EMBER FAIRY FEAST FERRY FLASH FLUTE FORGE GLOBE "
                + "GLOVE GUARD GUEST GUIDE HATCH HOTEL IVORY JELLY JEWEL KAYAK KOALA LASER LEAFY LEVEL LUNAR MAPLE MARCH "
                + "MEDAL MOTOR NOBLE NOVEL ORBIT OTTER PANDA PEACH PILOT PIXEL PLAZA POLAR PRISM PUPIL QUEST QUIET RAVEN "
                + "RELAY RHYME ROYAL RUGBY SCARF SCOUT SHARK SHELL SHINE SKIER SLIDE SOLAR SPARK SPICE SPINE SQUAD STAMP "
                + "STEAM STICK STRAW SUNNY SWIFT TANGO TORCH TOUCH TRAIL TREND TULIP ULTRA UNITY VAPOR VIDEO VIRUS VOCAL "
                + "WAGON WALTZ WITCH YACHT YEAST ZESTY ALPHA AMBER BACON BLAZE BLOOM BOOST CACAO CHILI COMET CREEK DOUGH "
                + "DWARF ELBOW FABLE FENCE FOCUS GECKO GUMBO HIPPO IGLOO JOKER KARMA LLAMA MOOSE NACHO OASIS PASTA PECAN "
                + "PERKY PLUMP PUNCH RANCH SALSA SAUNA SKIRT SLOTH SOUPY SUSHI SWAMP TACOS TEMPO TOKEN TOPAZ VELVET").split(" ");
        private final TextView[] clock = new TextView[1];
        private final Grid grid;
        private final TextView msg;
        private final String answer;
        private final List<String> guesses = new ArrayList<>();
        private String typing = "";
        private final Map<Character, Integer> keyState = new HashMap<>();
        private final List<TextView> keys = new ArrayList<>();

        Five(NovaActivity host) {
            super(host);
            List<String> pool = new ArrayList<>();
            for (String w : WORDS) {
                if (w.length() == 5) {
                    pool.add(w);
                }
            }
            Collections.shuffle(pool, new Random(20241018L));
            long dayNum = Calendar.getInstance().getTimeInMillis() / 86400000L;
            answer = pool.get((int) (dayNum % pool.size()));
            for (String g : Prefs.getString("five_" + Life.today(), "").split(",")) {
                if (g.length() == 5) {
                    guesses.add(g);
                }
            }
            LinearLayout outer = col(this);
            outer.setPadding(dp(14), dp(44), dp(14), 0);
            LinearLayout head = new LinearLayout(host);
            TextView t = text("FIVE  ·  word of the day", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.15f);
            head.addView(t, lp(0, -2, 1f));
            TextView c = text(clock(), 16f, Theme.TEXT);
            clock[0] = c;
            head.addView(c);
            outer.addView(head, lp(-1, -2));
            grid = new Grid(host);
            LinearLayout.LayoutParams gp = lp(-1, 0, 1f);
            gp.setMargins(dp(20), dp(10), dp(20), dp(6));
            outer.addView(grid, gp);
            msg = text("", 12f, Theme.DIM);
            msg.setGravity(Gravity.CENTER);
            outer.addView(msg, lp(-1, -2));
            String[] rows = {"QWERTZUIOP", "ASDFGHJKL", "<YXCVBNM>"};
            for (String r : rows) {
                LinearLayout kr = new LinearLayout(host);
                kr.setGravity(Gravity.CENTER);
                for (final char ch : r.toCharArray()) {
                    String label = ch == '<' ? "⌫" : ch == '>' ? "ENTER" : String.valueOf(ch);
                    TextView k = text(label, ch == '>' ? 10f : 15f, Theme.TEXT);
                    k.setGravity(Gravity.CENTER);
                    k.setTag(ch);
                    k.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                    k.setOnClickListener(v -> key(ch));
                    LinearLayout.LayoutParams kp = lp(0, dp(48), ch == '<' || ch == '>' ? 1.5f : 1f);
                    kp.setMargins(dp(2), dp(3), dp(2), dp(3));
                    kr.addView(k, kp);
                    keys.add(k);
                }
                outer.addView(kr, lp(-1, -2));
            }
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            for (String g : guesses) {
                mark(g);
            }
            paintKeys();
            status();
        }

        private boolean over() {
            return guesses.contains(answer) || guesses.size() >= 6;
        }

        private void key(char ch) {
            if (over()) {
                return;
            }
            host.buzz(5);
            if (ch == '<') {
                if (!typing.isEmpty()) {
                    typing = typing.substring(0, typing.length() - 1);
                }
            } else if (ch == '>') {
                if (typing.length() < 5) {
                    msg.setText("5 letters please");
                    return;
                }
                guesses.add(typing);
                Prefs.putString("five_" + Life.today(), String.join(",", guesses));
                mark(typing);
                typing = "";
                paintKeys();
                if (over()) {
                    boolean won = guesses.contains(answer);
                    Prefs.putInt("five_played", Prefs.getInt("five_played", 0) + 1);
                    if (won) {
                        Prefs.putInt("five_won", Prefs.getInt("five_won", 0) + 1);
                        String y = Life.dayPlus(-1);
                        int streak = y.equals(Prefs.getString("five_lastwin", "")) ? Prefs.getInt("five_streak", 0) + 1 : 1;
                        Prefs.putInt("five_streak", streak);
                        Prefs.putString("five_lastwin", Life.today());
                        host.confetti(getWidth() / 2f, getHeight() / 3f);
                    } else {
                        Prefs.putInt("five_streak", 0);
                    }
                }
            } else if (typing.length() < 5) {
                typing += ch;
            }
            status();
            grid.invalidate();
        }

        /** 2 green, 1 yellow, 0 grey for each letter. */
        private int[] score(String g) {
            int[] s = new int[5];
            int[] left = new int[26];
            for (int i = 0; i < 5; i++) {
                if (g.charAt(i) == answer.charAt(i)) {
                    s[i] = 2;
                } else {
                    left[answer.charAt(i) - 'A']++;
                }
            }
            for (int i = 0; i < 5; i++) {
                if (s[i] == 0 && left[g.charAt(i) - 'A'] > 0) {
                    s[i] = 1;
                    left[g.charAt(i) - 'A']--;
                }
            }
            return s;
        }

        private void mark(String g) {
            int[] s = score(g);
            for (int i = 0; i < 5; i++) {
                char ch = g.charAt(i);
                Integer was = keyState.get(ch);
                keyState.put(ch, Math.max(was == null ? -1 : was, s[i]));
            }
        }

        private void paintKeys() {
            for (TextView k : keys) {
                char ch = (char) k.getTag();
                Integer s = keyState.get(ch);
                int bg = s == null ? Theme.PANEL : s == 2 ? 0xFF43A047 : s == 1 ? 0xFFF9A825 : 0xFF3A3A3A;
                k.setBackground(Theme.rounded(bg, 8f, host));
            }
        }

        private void status() {
            if (guesses.contains(answer)) {
                msg.setText("🎉 Got it in " + guesses.size() + "!  streak " + Prefs.getInt("five_streak", 0)
                        + "  ·  new word tomorrow");
            } else if (guesses.size() >= 6) {
                msg.setText("The word was " + answer + ". New one tomorrow!");
            } else {
                msg.setText("won " + Prefs.getInt("five_won", 0) + " of " + Prefs.getInt("five_played", 0)
                        + "  ·  streak " + Prefs.getInt("five_streak", 0));
            }
        }

        @Override
        void tick() {
            if (clock[0] != null) {
                clock[0].setText(clock());
            }
        }

        final class Grid extends View {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

            Grid(android.content.Context c) {
                super(c);
            }

            @Override
            protected void onDraw(Canvas c) {
                float d = getResources().getDisplayMetrics().density;
                float cell = Math.min(getWidth() / 5f, getHeight() / 6f);
                float x0 = (getWidth() - cell * 5) / 2f;
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                p.setTextSize(cell * 0.5f);
                for (int r = 0; r < 6; r++) {
                    String g = r < guesses.size() ? guesses.get(r) : r == guesses.size() ? typing : "";
                    int[] s = r < guesses.size() ? score(g) : null;
                    for (int k = 0; k < 5; k++) {
                        RectF box = new RectF(x0 + k * cell + 3 * d, r * cell + 3 * d, x0 + (k + 1) * cell - 3 * d,
                                (r + 1) * cell - 3 * d);
                        if (s != null) {
                            p.setStyle(Paint.Style.FILL);
                            p.setColor(s[k] == 2 ? 0xFF43A047 : s[k] == 1 ? 0xFFF9A825 : 0xFF3A3A3A);
                            c.drawRoundRect(box, 6 * d, 6 * d, p);
                        } else {
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(2 * d);
                            p.setColor(k < g.length() ? Theme.TEXT : (Theme.TEXT & 0xFFFFFF) | 0x33000000);
                            c.drawRoundRect(box, 6 * d, 6 * d, p);
                        }
                        if (k < g.length()) {
                            p.setStyle(Paint.Style.FILL);
                            p.setColor(s != null ? 0xFFFFFFFF : Theme.TEXT);
                            c.drawText(String.valueOf(g.charAt(k)), box.centerX(), box.centerY() + cell * 0.18f, p);
                        }
                    }
                }
            }
        }
    }

    // ================================================================== ARCADE

    /** Three quick games with best scores: REACTION (tap when it turns green), TAP RACE (taps in 5 seconds) and MEMORY
     *  (repeat the colour pattern). */
    static final class Arcade extends AltHome {
        private final FrameLayout area;
        private final TextView best;

        Arcade(NovaActivity host) {
            super(host);
            LinearLayout outer = col(this);
            outer.setPadding(dp(12), dp(44), dp(12), 0);
            TextView t = text("ARCADE", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.25f);
            outer.addView(t);
            LinearLayout tabs = new LinearLayout(host);
            tabs.setPadding(0, dp(8), 0, dp(8));
            String[] n = {"REACTION", "TAP RACE", "MEMORY"};
            for (int i = 0; i < n.length; i++) {
                final int k = i;
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                tabs.addView(small(this, n[i], () -> show(k)), p);
            }
            outer.addView(tabs, lp(-1, -2));
            best = text("", 12f, Theme.DIM);
            best.setGravity(Gravity.CENTER);
            outer.addView(best, lp(-1, -2));
            area = new FrameLayout(host);
            LinearLayout.LayoutParams ap = lp(-1, 0, 1f);
            ap.setMargins(0, dp(8), 0, dp(8));
            outer.addView(area, ap);
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            show(Prefs.getInt("arcade_tab", 0));
        }

        private void show(int k) {
            Prefs.putInt("arcade_tab", k);
            area.removeAllViews();
            area.addView(k == 0 ? new Reaction(host) : k == 1 ? new TapRace(host) : new Memory(host),
                    new FrameLayout.LayoutParams(-1, -1));
            showBest();
        }

        private void showBest() {
            int r = Prefs.getInt("arc_react", 0);
            best.setText("best: reaction " + (r == 0 ? "-" : r + " ms") + "   ·   taps " + Prefs.getInt("arc_taps", 0)
                    + "   ·   memory level " + Prefs.getInt("arc_mem", 0));
        }

        abstract class Game extends View {
            final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            final float d;

            Game(android.content.Context c) {
                super(c);
                d = getResources().getDisplayMetrics().density;
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            }

            void say(Canvas c, String big, String smallT, int bg) {
                p.setColor(bg);
                c.drawRoundRect(new RectF(0, 0, getWidth(), getHeight()), 24 * d, 24 * d, p);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(34 * d);
                c.drawText(big, getWidth() / 2f, getHeight() / 2f, p);
                p.setTextSize(13 * d);
                c.drawText(smallT, getWidth() / 2f, getHeight() / 2f + 30 * d, p);
            }
        }

        final class Reaction extends Game {
            private int state; // 0 ready, 1 waiting, 2 go, 3 result, 4 too soon
            private long goAt;
            private long result;
            private final Runnable go = () -> {
                state = 2;
                goAt = System.currentTimeMillis();
                invalidate();
            };

            Reaction(android.content.Context c) {
                super(c);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() != MotionEvent.ACTION_DOWN) {
                    return true;
                }
                if (state == 0 || state == 3 || state == 4) {
                    state = 1;
                    postDelayed(go, 1500 + new Random().nextInt(2500));
                } else if (state == 1) {
                    removeCallbacks(go);
                    state = 4;
                    host.buzz(60);
                } else if (state == 2) {
                    result = System.currentTimeMillis() - goAt;
                    state = 3;
                    int b = Prefs.getInt("arc_react", 0);
                    if (b == 0 || result < b) {
                        Prefs.putInt("arc_react", (int) result);
                        showBest();
                    }
                }
                invalidate();
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                switch (state) {
                    case 1:
                        say(c, "wait...", "tap when it turns green", 0xFFC62828);
                        break;
                    case 2:
                        say(c, "TAP!", "", 0xFF2E7D32);
                        break;
                    case 3:
                        say(c, result + " ms", result < 250 ? "lightning fast ⚡ tap to go again" : "tap to go again", 0xFF1565C0);
                        break;
                    case 4:
                        say(c, "too soon!", "tap to try again", 0xFF6A1B9A);
                        break;
                    default:
                        say(c, "REACTION", "tap to start", Theme.PANEL | 0xFF000000);
                        break;
                }
            }
        }

        final class TapRace extends Game {
            private int taps;
            private long end;
            private boolean done;

            TapRace(android.content.Context c) {
                super(c);
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                int a = e.getActionMasked();
                if (a != MotionEvent.ACTION_DOWN && a != MotionEvent.ACTION_POINTER_DOWN) {
                    return true;
                }
                long now = System.currentTimeMillis();
                if (end == 0 || done) {
                    if (done && now < end + 1200) {
                        return true;
                    }
                    taps = 0;
                    done = false;
                    end = now + 5000;
                }
                taps++;
                Synth.tone(600 + taps * 15, 30);
                invalidate();
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                long now = System.currentTimeMillis();
                if (end == 0) {
                    say(c, "TAP RACE", "tap as fast as you can for 5 seconds", Theme.PANEL | 0xFF000000);
                    return;
                }
                if (now >= end && !done) {
                    done = true;
                    if (taps > Prefs.getInt("arc_taps", 0)) {
                        Prefs.putInt("arc_taps", taps);
                        showBest();
                        host.confetti(getWidth() / 2f, getHeight() / 2f);
                    }
                }
                if (done) {
                    say(c, taps + " taps", String.format(Locale.ROOT, "%.1f per second  ·  tap to go again", taps / 5f),
                            0xFF1565C0);
                } else {
                    say(c, String.valueOf(taps), String.format(Locale.ROOT, "%.1f s", (end - now) / 1000f), 0xFFEF6C00);
                    postInvalidateOnAnimation();
                }
            }
        }

        final class Memory extends Game {
            private final int[] cols = {0xFF2E7D32, 0xFFC62828, 0xFFF9A825, 0xFF1565C0};
            private final double[] tones = {392, 330, 262, 196};
            private final List<Integer> seq = new ArrayList<>();
            private int pos;
            private int lit = -1;
            private boolean showing;
            private boolean lost;
            private final Random rnd = new Random();

            Memory(android.content.Context c) {
                super(c);
            }

            private void next() {
                seq.add(rnd.nextInt(4));
                pos = 0;
                playSeq();
            }

            private void playSeq() {
                showing = true;
                for (int i = 0; i < seq.size(); i++) {
                    final int k = seq.get(i);
                    final boolean last = i == seq.size() - 1;
                    postDelayed(() -> {
                        lit = k;
                        Synth.tone(tones[k], 300);
                        invalidate();
                    }, 600L + i * 550L);
                    postDelayed(() -> {
                        lit = -1;
                        if (last) {
                            showing = false;
                        }
                        invalidate();
                    }, 600L + i * 550L + 380);
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                if (e.getActionMasked() != MotionEvent.ACTION_DOWN || showing) {
                    return true;
                }
                if (seq.isEmpty() || lost) {
                    seq.clear();
                    lost = false;
                    next();
                    invalidate();
                    return true;
                }
                int k = (e.getX() < getWidth() / 2f ? 0 : 1) + (e.getY() < getHeight() / 2f ? 0 : 2);
                lit = k;
                Synth.tone(tones[k], 250);
                postDelayed(() -> {
                    lit = -1;
                    invalidate();
                }, 200);
                if (k == seq.get(pos)) {
                    pos++;
                    if (pos == seq.size()) {
                        if (seq.size() > Prefs.getInt("arc_mem", 0)) {
                            Prefs.putInt("arc_mem", seq.size());
                            showBest();
                        }
                        postDelayed(this::next, 500);
                    }
                } else {
                    lost = true;
                    Synth.pad(5);
                    host.buzz(120);
                }
                invalidate();
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                float w = getWidth() / 2f;
                float h = getHeight() / 2f;
                for (int k = 0; k < 4; k++) {
                    float x = (k % 2) * w;
                    float y = (k / 2) * h;
                    p.setColor(lit == k ? (cols[k] | 0xFF000000) : (cols[k] & 0xFFFFFF) | 0x66000000);
                    c.drawRoundRect(new RectF(x + 5 * d, y + 5 * d, x + w - 5 * d, y + h - 5 * d), 26 * d, 26 * d, p);
                }
                p.setColor(0xFFFFFFFF);
                p.setTextSize(15 * d);
                String s = seq.isEmpty() ? "tap to start" : lost ? "level " + (seq.size() - 1) + " — tap to restart"
                        : showing ? "watch..." : "your turn  ·  level " + seq.size();
                c.drawText(s, w, h + 5 * d, p);
            }
        }
    }

    // ================================================================== PIXEL

    /** 16 by 16 pixel art: pen, fill and eraser, four save slots and share your art as a picture. */
    static final class Pixel extends AltHome {
        static final int[] PAL = {0xFF000000, 0xFF1D2B53, 0xFF7E2553, 0xFF008751, 0xFFAB5236, 0xFF5F574F, 0xFFC2C3C7,
            0xFFFFF1E8, 0xFFFF004D, 0xFFFFA300, 0xFFFFEC27, 0xFF00E436, 0xFF29ADFF, 0xFF83769C, 0xFFFF77A8, 0xFFFFCCAA};
        private final Art art;
        private int color = 8;
        private int tool;
        private int slot;

        Pixel(NovaActivity host) {
            super(host);
            slot = Prefs.getInt("pixel_slot", 0);
            LinearLayout outer = col(this);
            outer.setPadding(dp(12), dp(44), dp(12), 0);
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = text("PIXEL", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.25f);
            head.addView(t, lp(0, -2, 1f));
            for (int i = 0; i < 4; i++) {
                final int k = i;
                LinearLayout.LayoutParams p = lp(-2, -2);
                p.leftMargin = dp(4);
                TextView s = small(this, String.valueOf(i + 1), () -> {
                    Prefs.putInt("pixel_slot", k);
                    host.showHome();
                });
                if (i == slot) {
                    s.setBackground(Theme.rounded(Theme.ACCENT, 14f, host));
                    s.setTextColor(HomeKit.onColor(Theme.ACCENT));
                }
                head.addView(s, p);
            }
            outer.addView(head, lp(-1, -2));
            art = new Art(host);
            LinearLayout.LayoutParams ap = lp(-1, 0, 1f);
            ap.setMargins(0, dp(10), 0, dp(10));
            outer.addView(art, ap);
            LinearLayout pal = new LinearLayout(host);
            LinearLayout pal2 = new LinearLayout(host);
            for (int i = 0; i < PAL.length; i++) {
                final int k = i;
                View v = new View(host);
                v.setBackground(Theme.rounded(PAL[i], 6f, host));
                v.setOnClickListener(x -> {
                    color = k;
                    if (tool == 2) {
                        tool = 0;
                    }
                    host.buzz(5);
                });
                LinearLayout.LayoutParams p = lp(0, dp(30), 1f);
                p.setMargins(dp(2), dp(2), dp(2), dp(2));
                (i < 8 ? pal : pal2).addView(v, p);
            }
            outer.addView(pal, lp(-1, -2));
            outer.addView(pal2, lp(-1, -2));
            LinearLayout tools = new LinearLayout(host);
            tools.setPadding(0, dp(6), 0, dp(6));
            String[] n = {"PEN", "FILL", "ERASE", "CLEAR", "SHARE"};
            for (int i = 0; i < n.length; i++) {
                final int k = i;
                LinearLayout.LayoutParams p = lp(0, -2, 1f);
                p.setMargins(dp(2), 0, dp(2), 0);
                tools.addView(small(this, n[i], () -> {
                    if (k <= 2) {
                        tool = k;
                    } else if (k == 3) {
                        art.clear();
                    } else {
                        share();
                    }
                }), p);
            }
            outer.addView(tools, lp(-1, -2));
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
        }

        private void share() {
            try {
                Bitmap b = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b);
                Paint p = new Paint();
                for (int i = 0; i < 256; i++) {
                    int v = art.px[i];
                    p.setColor(v < 0 ? 0x00000000 : PAL[v]);
                    c.drawRect((i % 16) * 32, (i / 16) * 32, (i % 16 + 1) * 32, (i / 16 + 1) * 32, p);
                }
                File dir = new File(host.getCacheDir(), "share");
                dir.mkdirs();
                File f = new File(dir, "nova-pixel.png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    b.compress(Bitmap.CompressFormat.PNG, 100, o);
                }
                android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("image/png");
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                host.startActivity(Intent.createChooser(i, "Share your pixel art"));
            } catch (Exception e) {
                host.toast("Could not share the picture");
            }
        }

        final class Art extends View {
            final int[] px = new int[256];
            private final Paint p = new Paint();

            Art(android.content.Context c) {
                super(c);
                String s = Prefs.getString("pixel_" + slot, "");
                for (int i = 0; i < 256; i++) {
                    px[i] = i < s.length() && s.charAt(i) != '.' ? Character.digit(s.charAt(i), 16) : -1;
                }
            }

            private void save() {
                StringBuilder b = new StringBuilder();
                for (int v : px) {
                    b.append(v < 0 ? '.' : Character.forDigit(v, 16));
                }
                Prefs.putString("pixel_" + slot, b.toString());
            }

            void clear() {
                java.util.Arrays.fill(px, -1);
                save();
                invalidate();
            }

            private void fill(int at, int from, int to) {
                if (from == to) {
                    return;
                }
                java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<>();
                q.add(at);
                while (!q.isEmpty()) {
                    int i = q.poll();
                    if (i < 0 || i >= 256 || px[i] != from) {
                        continue;
                    }
                    px[i] = to;
                    if (i % 16 > 0) {
                        q.add(i - 1);
                    }
                    if (i % 16 < 15) {
                        q.add(i + 1);
                    }
                    q.add(i - 16);
                    q.add(i + 16);
                }
            }

            private float cell() {
                return Math.min(getWidth(), getHeight()) / 16f;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float cs = cell();
                float x0 = (getWidth() - cs * 16) / 2f;
                int cx = (int) ((e.getX() - x0) / cs);
                int cy = (int) (e.getY() / cs);
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (cx >= 0 && cx < 16 && cy >= 0 && cy < 16) {
                    int i = cy * 16 + cx;
                    if (tool == 1) {
                        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                            fill(i, px[i], color);
                        }
                    } else {
                        px[i] = tool == 2 ? -1 : color;
                    }
                    invalidate();
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    save();
                }
                return true;
            }

            @Override
            protected void onDraw(Canvas c) {
                float cs = cell();
                float x0 = (getWidth() - cs * 16) / 2f;
                for (int i = 0; i < 256; i++) {
                    int x = i % 16;
                    int y = i / 16;
                    int v = px[i];
                    p.setColor(v >= 0 ? PAL[v] : ((x + y) % 2 == 0 ? 0xFF2A2A33 : 0xFF22222A));
                    c.drawRect(x0 + x * cs, y * cs, x0 + (x + 1) * cs, (y + 1) * cs, p);
                }
            }
        }
    }

    // ================================================================== SOUNDBOARD

    /** Twelve sound pads and a little beat maker: four drums, eight steps, play it in a loop and change the speed. */
    static final class Soundboard extends AltHome {
        private final boolean[][] steps = new boolean[4][8];
        private final Handler h = new Handler(Looper.getMainLooper());
        private boolean playing;
        private int step;
        private int bpm;
        private final TextView bpmL;
        private final TextView playBtn;
        private final View seqView;
        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                if (!playing) {
                    return;
                }
                int[] pads = {0, 1, 2, 3};
                for (int t = 0; t < 4; t++) {
                    if (steps[t][step]) {
                        Synth.pad(pads[t]);
                    }
                }
                seqView.invalidate();
                step = (step + 1) % 8;
                h.postDelayed(this, 60000L / bpm / 2);
            }
        };

        Soundboard(NovaActivity host) {
            super(host);
            bpm = Prefs.getInt("beat_bpm", 110);
            String saved = Prefs.getString("beat_steps", "1000100000100010000000001000100010101010");
            for (int i = 0; i < 32 && i < saved.length(); i++) {
                steps[i / 8][i % 8] = saved.charAt(i) == '1';
            }
            LinearLayout outer = col(this);
            outer.setPadding(dp(12), dp(44), dp(12), 0);
            TextView t = text("SOUNDBOARD", 12f, Theme.ACCENT);
            t.setLetterSpacing(0.25f);
            outer.addView(t);
            LinearLayout grid = col(this);
            grid.setPadding(0, dp(8), 0, dp(8));
            int[] cols = {0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A, 0xFF26A69A,
                0xFF5C6BC0, 0xFF8D6E63, 0xFF546E7A, 0xFFD4E157};
            for (int r = 0; r < 3; r++) {
                LinearLayout row = new LinearLayout(host);
                for (int c = 0; c < 4; c++) {
                    final int i = r * 4 + c;
                    TextView pad = text(Synth.PADS[i], 10f, 0xFFFFFFFF);
                    pad.setGravity(Gravity.CENTER);
                    pad.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                    pad.setBackground(Theme.rounded(cols[i], 16f, host));
                    pad.setOnTouchListener((v, e) -> {
                        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                            Synth.pad(i);
                            v.setScaleX(0.9f);
                            v.setScaleY(0.9f);
                            v.setAlpha(0.7f);
                        } else if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                            v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start();
                        }
                        return true;
                    });
                    LinearLayout.LayoutParams p = lp(0, dp(70), 1f);
                    p.setMargins(dp(4), dp(4), dp(4), dp(4));
                    row.addView(pad, p);
                }
                grid.addView(row, lp(-1, -2));
            }
            outer.addView(grid, lp(-1, -2));
            TextView bt = text("BEAT MAKER  ·  tap squares, then play", 10f, Theme.DIM);
            bt.setGravity(Gravity.START);
            outer.addView(bt);
            seqView = new View(host) {
                private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

                @Override
                public boolean onTouchEvent(MotionEvent e) {
                    if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        float lw = 60 * getResources().getDisplayMetrics().density;
                        int c = (int) ((e.getX() - lw) / ((getWidth() - lw) / 8f));
                        int r = (int) (e.getY() / (getHeight() / 4f));
                        if (c >= 0 && c < 8 && r >= 0 && r < 4) {
                            steps[r][c] = !steps[r][c];
                            save();
                            invalidate();
                        }
                    }
                    return true;
                }

                @Override
                protected void onDraw(Canvas cv) {
                    float d = getResources().getDisplayMetrics().density;
                    float lw = 60 * d;
                    float cw = (getWidth() - lw) / 8f;
                    float ch = getHeight() / 4f;
                    String[] names = {"KICK", "SNARE", "HAT", "CLAP"};
                    p.setTextSize(10 * d);
                    p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                    int playingCol = playing ? (step + 7) % 8 : -1;
                    for (int r = 0; r < 4; r++) {
                        p.setColor(Theme.DIM);
                        cv.drawText(names[r], 0, r * ch + ch / 2 + 4 * d, p);
                        for (int c = 0; c < 8; c++) {
                            boolean on = steps[r][c];
                            int base = cols[r];
                            p.setColor(on ? base : c == playingCol ? (Theme.TEXT & 0xFFFFFF) | 0x44000000
                                    : (c % 2 == 0 ? Theme.PANEL : Theme.BG2) | 0xFF000000);
                            cv.drawRoundRect(new RectF(lw + c * cw + 2 * d, r * ch + 2 * d, lw + (c + 1) * cw - 2 * d,
                                    (r + 1) * ch - 2 * d), 6 * d, 6 * d, p);
                        }
                    }
                }
            };
            LinearLayout.LayoutParams sp = lp(-1, 0, 1f);
            sp.setMargins(0, dp(6), 0, dp(6));
            outer.addView(seqView, sp);
            LinearLayout ctl = new LinearLayout(host);
            ctl.setGravity(Gravity.CENTER_VERTICAL);
            ctl.setPadding(0, 0, 0, dp(6));
            playBtn = small(this, "▶ PLAY", this::togglePlay);
            ctl.addView(playBtn, lp(0, -2, 1.4f));
            LinearLayout.LayoutParams p1 = lp(0, -2, 1f);
            p1.leftMargin = dp(6);
            ctl.addView(small(this, "−", () -> setBpm(bpm - 10)), p1);
            bpmL = text("", 13f, Theme.TEXT);
            bpmL.setGravity(Gravity.CENTER);
            ctl.addView(bpmL, lp(0, -2, 1.2f));
            ctl.addView(small(this, "+", () -> setBpm(bpm + 10)), lp(0, -2, 1f));
            LinearLayout.LayoutParams p2 = lp(0, -2, 1f);
            p2.leftMargin = dp(6);
            ctl.addView(small(this, "CLEAR", () -> {
                for (boolean[] r : steps) {
                    java.util.Arrays.fill(r, false);
                }
                save();
                seqView.invalidate();
            }), p2);
            outer.addView(ctl, lp(-1, -2));
            outer.addView(bar());
            addView(outer, new FrameLayout.LayoutParams(-1, -1));
            setBpm(bpm);
        }

        private void save() {
            StringBuilder b = new StringBuilder();
            for (boolean[] r : steps) {
                for (boolean s : r) {
                    b.append(s ? '1' : '0');
                }
            }
            Prefs.putString("beat_steps", b.toString());
        }

        private void setBpm(int v) {
            bpm = Math.max(60, Math.min(200, v));
            Prefs.putInt("beat_bpm", bpm);
            bpmL.setText(bpm + " BPM");
        }

        private void togglePlay() {
            playing = !playing;
            playBtn.setText(playing ? "■ STOP" : "▶ PLAY");
            h.removeCallbacks(loop);
            if (playing) {
                step = 0;
                h.post(loop);
            }
            seqView.invalidate();
        }

        @Override
        protected void onDetachedFromWindow() {
            playing = false;
            h.removeCallbacks(loop);
            super.onDetachedFromWindow();
        }
    }
}
