package app.novaos;

import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** The players at a friends table: their names, their coins, and who to write the coins back to. */
final class FriendsSeats {
    static final int YOU = -1;
    /** For each seat: an index into Guests.all(), or YOU for the phone's owner (plays with the real coins). */
    final List<Integer> who;
    final String[] names;
    final int[] stack;

    FriendsSeats(List<Integer> who, String[] names, int[] stack) {
        this.who = who;
        this.names = names;
        this.stack = stack;
    }

    int size() {
        return names.length;
    }

    /** Writes every seat's coins back: guests to their profile, YOU to your casino coins. */
    void save() {
        List<Guests.Guest> all = Guests.all();
        for (int i = 0; i < names.length && i < who.size(); i++) {
            int g = who.get(i);
            if (g == YOU) {
                Prefs.putInt("slot_coins", stack[i]);
            } else if (g >= 0 && g < all.size()) {
                all.get(g).coins = stack[i];
            }
        }
        Guests.save(all);
    }

    int withAtLeast(int min) {
        int n = 0;
        for (int s : stack) {
            if (s >= min) {
                n++;
            }
        }
        return n;
    }

    /** Everyone, richest first. */
    String standings() {
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            order.add(i);
        }
        order.sort((a, b) -> stack[b] - stack[a]);
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < order.size(); k++) {
            int i = order.get(k);
            sb.append(k == 0 ? "WINNER   " : "").append(names[i]).append("   ").append(stack[i]).append('\n');
        }
        return sb.toString().trim();
    }
}

/**
 * Base for the pass-the-phone card games at the friends table: a scrolling table, a cover that hides it while the
 * phone changes hands (its NEXT PLAYER button sits at the top, away from where the last player tapped, and ignores
 * taps for a moment), and cards. A card code is rank * 4 + suit, rank 0 = two ... 12 = ace.
 */
abstract class FriendsGame extends Game {
    static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    static final String[] SUITS = {"♠", "♥", "♦", "♣"};

    final FriendsSeats seats;
    final LinearLayout col;
    private final LinearLayout cover;
    private final TextView coverNext;
    private final TextView coverTitle;
    private final TextView coverBody;
    private final LinearLayout coverButtons;
    private Runnable nextAction;
    private long shownAt;

    FriendsGame(NovaActivity host, FriendsSeats seats) {
        super(host);
        this.seats = seats;
        col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(58), dp(12), dp(16));
        ScrollView sv = new ScrollView(host);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        cover = new LinearLayout(host);
        cover.setOrientation(LinearLayout.VERTICAL);
        cover.setGravity(Gravity.CENTER);
        cover.setPadding(dp(24), dp(58), dp(24), dp(24));
        cover.setBackgroundColor(0xF2000000 | (Theme.BG & 0xFFFFFF));
        cover.setClickable(true);
        coverNext = button("NEXT PLAYER", this::nextTap);
        coverNext.setTextColor(Theme.BG);
        coverNext.setTextSize(15f);
        coverNext.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        coverNext.setPadding(dp(18), dp(16), dp(18), dp(16));
        cover.addView(coverNext, wide());
        coverTitle = label("", 20f, Theme.ACCENT);
        coverTitle.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams tlp = wide();
        tlp.topMargin = dp(18);
        cover.addView(coverTitle, tlp);
        coverBody = label("", 14f, Theme.TEXT);
        cover.addView(coverBody, wide());
        coverButtons = new LinearLayout(host);
        coverButtons.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams blp = wide();
        blp.topMargin = dp(16);
        cover.addView(coverButtons, blp);
        cover.setVisibility(GONE);
        addView(cover, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    LinearLayout.LayoutParams wide() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        return lp;
    }

    /** A cover with the NEXT PLAYER button on top. */
    void showPass(String title, String body, String next, Runnable onNext) {
        coverTitle.setText(title);
        coverBody.setText(body);
        coverButtons.removeAllViews();
        coverNext.setText(next);
        coverNext.setVisibility(VISIBLE);
        nextAction = onNext;
        shownAt = System.currentTimeMillis();
        cover.setVisibility(VISIBLE);
    }

    /** A cover with the NEXT button on top and some cards shown big under the text (like a new flop). */
    void showPassCards(String title, String body, int[] cards, int count, String next, Runnable onNext) {
        showPass(title, body, next, onNext);
        LinearLayout r = row();
        for (int i = 0; i < count; i++) {
            r.addView(card(cards[i], 52));
        }
        for (int i = count; i < 5 && cards.length == 5; i++) {
            r.addView(back(52));
        }
        coverButtons.addView(r, wide());
    }

    /** A cover with a choice of buttons at the bottom, for results. */
    void showChoice(String title, String body, String[] labels, Runnable[] actions) {
        coverTitle.setText(title);
        coverBody.setText(body);
        coverNext.setVisibility(GONE);
        nextAction = null;
        coverButtons.removeAllViews();
        for (int i = 0; i < labels.length; i++) {
            TextView b = button(labels[i], actions[i]);
            if (i == 0) {
                b.setTextColor(Theme.BG);
                b.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
            }
            coverButtons.addView(b, weight());
        }
        cover.setVisibility(VISIBLE);
    }

    void hideCover() {
        cover.setVisibility(GONE);
        nextAction = null;
    }

    private void nextTap() {
        if (nextAction == null || System.currentTimeMillis() - shownAt < 700) {
            return;
        }
        Runnable r = nextAction;
        nextAction = null;
        r.run();
    }

    /** Final scores, then back to the home screen. */
    void gameOver(String note) {
        seats.save();
        showChoice("GAME OVER", (note.isEmpty() ? "" : note + "\n\n") + seats.standings(),
                new String[] {"DONE"}, new Runnable[] {host::hideOverlay});
        Sfx.play(Sfx.WIN);
    }

    // ------------------------------------------------------------------ cards

    static String cardText(int code) {
        return RANKS[code / 4] + SUITS[code % 4];
    }

    TextView card(int code, int widthDp) {
        TextView t = label(cardText(code), widthDp >= 50 ? 16f : 13f, 0);
        t.setBackground(Theme.rounded(0xFFF4F0FF, 8f, host));
        int suit = code % 4;
        t.setTextColor(suit == 1 || suit == 2 ? 0xFFB3243A : 0xFF1C1626);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(widthDp * 1.35f));
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        return t;
    }

    TextView back(int widthDp) {
        TextView t = label("?", 14f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0xFF3B2B66, 8f, host));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(widthDp * 1.35f));
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        return t;
    }

    /** A freshly shuffled set of decks. */
    static List<Integer> shoe(int decks, java.util.Random rnd) {
        List<Integer> s = new ArrayList<>();
        for (int d = 0; d < decks; d++) {
            for (int c = 0; c < 52; c++) {
                s.add(c);
            }
        }
        java.util.Collections.shuffle(s, rnd);
        return s;
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER);
        return r;
    }
}
