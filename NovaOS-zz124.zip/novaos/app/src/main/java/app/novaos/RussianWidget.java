package app.novaos;

import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * RUSSIAN: learn Russian a few cards at a time. It starts with the Cyrillic alphabet, then words in small topics.
 * New cards are shown first, then asked again later: right answers come back after 1, 2, 4, 7, 15 and 30 days,
 * wrong ones the same day (a Leitner box). Tap the speaker to hear it (the phone's Russian voice).
 */
final class RussianWidget extends NovaWidget {
    // the alphabet: letter, sound, hint
    static final String[][] LETTERS = {
        {"А а", "a", "a as in father"}, {"Б б", "b", "b as in bed"}, {"В в", "v", "v as in van"},
        {"Г г", "g", "g as in go"}, {"Д д", "d", "d as in dog"}, {"Е е", "ye", "ye as in yes"},
        {"Ё ё", "yo", "yo as in yoghurt"}, {"Ж ж", "zh", "s as in pleasure"}, {"З з", "z", "z as in zoo"},
        {"И и", "i", "ee as in see"}, {"Й й", "y", "y as in boy"}, {"К к", "k", "k as in kite"},
        {"Л л", "l", "l as in lamp"}, {"М м", "m", "m as in man"}, {"Н н", "n", "n as in no"},
        {"О о", "o", "o as in more"}, {"П п", "p", "p as in pen"}, {"Р р", "r", "a rolled r"},
        {"С с", "s", "s as in sun"}, {"Т т", "t", "t as in top"}, {"У у", "u", "oo as in boot"},
        {"Ф ф", "f", "f as in fun"}, {"Х х", "kh", "ch as in Bach"}, {"Ц ц", "ts", "ts as in cats"},
        {"Ч ч", "ch", "ch as in chips"}, {"Ш ш", "sh", "sh as in shop"}, {"Щ щ", "shch", "a long soft sh"},
        {"Ъ ъ", "hard sign", "no sound, a short break"}, {"Ы ы", "y", "like i in ill, deeper"},
        {"Ь ь", "soft sign", "no sound, makes the letter before soft"}, {"Э э", "e", "e as in met"},
        {"Ю ю", "yu", "you"}, {"Я я", "ya", "ya as in yard"}};

    // words: russian, how to say it, english, topic
    static final String[][] WORDS = {
        {"привет", "privet", "hi", "Hello"}, {"пока", "poka", "bye", "Hello"}, {"спасибо", "spasibo", "thank you", "Hello"},
        {"пожалуйста", "pozhaluysta", "please / you're welcome", "Hello"}, {"да", "da", "yes", "Hello"},
        {"нет", "net", "no", "Hello"}, {"здравствуйте", "zdravstvuyte", "hello (polite)", "Hello"},
        {"до свидания", "do svidaniya", "goodbye", "Hello"}, {"извините", "izvinite", "excuse me / sorry", "Hello"},
        {"хорошо", "khorosho", "good / okay", "Hello"}, {"как дела?", "kak dela?", "how are you?", "Hello"},
        {"меня зовут ...", "menya zovut ...", "my name is ...", "Hello"}, {"доброе утро", "dobroye utro", "good morning", "Hello"},
        {"добрый вечер", "dobryy vecher", "good evening", "Hello"}, {"спокойной ночи", "spokoynoy nochi", "good night", "Hello"},
        {"один", "odin", "one", "Numbers"}, {"два", "dva", "two", "Numbers"}, {"три", "tri", "three", "Numbers"},
        {"четыре", "chetyre", "four", "Numbers"}, {"пять", "pyat'", "five", "Numbers"}, {"шесть", "shest'", "six", "Numbers"},
        {"семь", "sem'", "seven", "Numbers"}, {"восемь", "vosem'", "eight", "Numbers"}, {"девять", "devyat'", "nine", "Numbers"},
        {"десять", "desyat'", "ten", "Numbers"}, {"сто", "sto", "hundred", "Numbers"}, {"тысяча", "tysyacha", "thousand", "Numbers"},
        {"я", "ya", "I", "People"}, {"ты", "ty", "you (to a friend)", "People"}, {"он", "on", "he", "People"},
        {"она", "ona", "she", "People"}, {"мы", "my", "we", "People"}, {"вы", "vy", "you (polite / many)", "People"},
        {"они", "oni", "they", "People"}, {"мама", "mama", "mom", "People"}, {"папа", "papa", "dad", "People"},
        {"брат", "brat", "brother", "People"}, {"сестра", "sestra", "sister", "People"}, {"друг", "drug", "friend", "People"},
        {"мальчик", "mal'chik", "boy", "People"}, {"девочка", "devochka", "girl", "People"},
        {"дом", "dom", "house / home", "Everyday"}, {"школа", "shkola", "school", "Everyday"}, {"вода", "voda", "water", "Everyday"},
        {"хлеб", "khleb", "bread", "Everyday"}, {"молоко", "moloko", "milk", "Everyday"}, {"кофе", "kofe", "coffee", "Everyday"},
        {"чай", "chay", "tea", "Everyday"}, {"еда", "yeda", "food", "Everyday"}, {"машина", "mashina", "car", "Everyday"},
        {"автобус", "avtobus", "bus", "Everyday"}, {"поезд", "poyezd", "train", "Everyday"}, {"телефон", "telefon", "phone", "Everyday"},
        {"книга", "kniga", "book", "Everyday"}, {"деньги", "den'gi", "money", "Everyday"}, {"город", "gorod", "city", "Everyday"},
        {"улица", "ulitsa", "street", "Everyday"}, {"работа", "rabota", "work", "Everyday"}, {"время", "vremya", "time", "Everyday"},
        {"день", "den'", "day", "Time"}, {"ночь", "noch'", "night", "Time"}, {"утро", "utro", "morning", "Time"},
        {"сегодня", "segodnya", "today", "Time"}, {"завтра", "zavtra", "tomorrow", "Time"}, {"вчера", "vchera", "yesterday", "Time"},
        {"сейчас", "seychas", "now", "Time"},
        {"большой", "bol'shoy", "big", "Describe"}, {"маленький", "malen'kiy", "small", "Describe"},
        {"хороший", "khoroshiy", "good", "Describe"}, {"плохой", "plokhoy", "bad", "Describe"}, {"новый", "novyy", "new", "Describe"},
        {"старый", "staryy", "old", "Describe"}, {"красивый", "krasivyy", "beautiful", "Describe"},
        {"холодный", "kholodnyy", "cold", "Describe"}, {"горячий", "goryachiy", "hot", "Describe"},
        {"быстрый", "bystryy", "fast", "Describe"}, {"очень", "ochen'", "very", "Describe"},
        {"красный", "krasnyy", "red", "Colours"}, {"синий", "siniy", "blue", "Colours"}, {"зелёный", "zelyonyy", "green", "Colours"},
        {"белый", "belyy", "white", "Colours"}, {"чёрный", "chyornyy", "black", "Colours"}, {"жёлтый", "zhyoltyy", "yellow", "Colours"},
        {"быть", "byt'", "to be", "Verbs"}, {"есть", "yest'", "to eat", "Verbs"}, {"пить", "pit'", "to drink", "Verbs"},
        {"идти", "idti", "to go (walking)", "Verbs"}, {"говорить", "govorit'", "to speak", "Verbs"}, {"знать", "znat'", "to know", "Verbs"},
        {"хотеть", "khotet'", "to want", "Verbs"}, {"любить", "lyubit'", "to love", "Verbs"}, {"видеть", "videt'", "to see", "Verbs"},
        {"спать", "spat'", "to sleep", "Verbs"}, {"играть", "igrat'", "to play", "Verbs"}, {"понимать", "ponimat'", "to understand", "Verbs"},
        {"где?", "gde?", "where?", "Questions"}, {"что?", "chto?", "what?", "Questions"}, {"кто?", "kto?", "who?", "Questions"},
        {"когда?", "kogda?", "when?", "Questions"}, {"сколько стоит?", "skol'ko stoit?", "how much is it?", "Questions"},
        {"я не понимаю", "ya ne ponimayu", "I don't understand", "Questions"},
        {"я люблю тебя", "ya lyublyu tebya", "I love you", "Questions"}, {"Россия", "Rossiya", "Russia", "Questions"},
        {"Швейцария", "Shveytsariya", "Switzerland", "Questions"}};

    private static final int[] GAPS = {0, 1, 2, 4, 7, 15, 30};
    private static final int NEW_PER_DAY = 8;
    private static final int GOAL = 15;
    private static TextToSpeech tts;
    private static boolean ttsReady;

    private final Random rnd = new Random();
    private final TextView head;
    private final TextView big;
    private final TextView sub;
    private final TextView ask;
    private final LinearLayout opts;
    private final TextView next;
    private int item = -1;
    private boolean isNew;
    private boolean answered;
    private boolean reverse;

    RussianWidget(NovaActivity host) {
        super(host);
        setOrientation(VERTICAL);
        head = text("", 10f, Theme.ACCENT);
        head.setGravity(Gravity.START);
        addView(head, wide());
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(0, dp(6), 0, 0);
        big = text("", 30f, Theme.TEXT);
        big.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
        big.setGravity(Gravity.START);
        card.addView(big, weight(1f));
        TextView say = chip("🔊", () -> say(true));
        say.setTextSize(16f);
        card.addView(say);
        addView(card, wide());
        sub = text("", 12f, Theme.DIM);
        sub.setGravity(Gravity.START);
        addView(sub, wide());
        ask = text("", 11f, Theme.TEXT);
        ask.setGravity(Gravity.START);
        ask.setPadding(0, dp(6), 0, dp(4));
        addView(ask, wide());
        opts = new LinearLayout(host);
        opts.setOrientation(VERTICAL);
        addView(opts, wide());
        next = chip("NEXT ›", this::pick);
        LinearLayout.LayoutParams np = wide();
        np.topMargin = dp(6);
        addView(next, np);
        pick();
    }

    @Override
    long tickMs() {
        return 0;
    }

    @Override
    void refresh() {
        header();
    }

    // ------------------------------------------------------------------ data

    static int total() {
        return LETTERS.length + WORDS.length;
    }

    /** The front (what you read), the sound and the meaning of item i. */
    static String[] item(int i) {
        if (i < LETTERS.length) {
            return new String[] {LETTERS[i][0], LETTERS[i][1], LETTERS[i][2], "Alphabet"};
        }
        String[] w = WORDS[i - LETTERS.length];
        return new String[] {w[0], w[1], w[2], w[3]};
    }

    private static int dayNum() {
        Calendar c = Calendar.getInstance();
        return (int) ((c.getTimeInMillis() + c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET)) / 86400000L);
    }

    /** {box, due day} for every item; box 0 = never seen. */
    private static int[][] state() {
        int[][] s = new int[total()][2];
        String raw = Prefs.getString("ru_state", "");
        String[] parts = raw.isEmpty() ? new String[0] : raw.split(";");
        for (int i = 0; i < parts.length && i < s.length; i++) {
            String[] f = parts[i].split(",");
            if (f.length == 2) {
                try {
                    s[i][0] = Integer.parseInt(f[0]);
                    s[i][1] = Integer.parseInt(f[1]);
                } catch (NumberFormatException ignored) {
                    // broken
                }
            }
        }
        return s;
    }

    private static void save(int[][] s) {
        StringBuilder b = new StringBuilder();
        for (int[] x : s) {
            b.append(x[0]).append(',').append(x[1]).append(';');
        }
        Prefs.putString("ru_state", b.toString());
    }

    private static int doneToday() {
        return Prefs.getInt("ru_day", 0) == dayNum() ? Prefs.getInt("ru_done", 0) : 0;
    }

    private static int newToday() {
        return Prefs.getInt("ru_day", 0) == dayNum() ? Prefs.getInt("ru_new", 0) : 0;
    }

    private static void count(boolean fresh) {
        int day = dayNum();
        if (Prefs.getInt("ru_day", 0) != day) {
            // a new day: keep the streak if yesterday reached the goal
            int last = Prefs.getInt("ru_goal_day", 0);
            if (last < day - 1) {
                Prefs.putInt("ru_streak", 0);
            }
            Prefs.putInt("ru_day", day);
            Prefs.putInt("ru_done", 0);
            Prefs.putInt("ru_new", 0);
        }
        Prefs.putInt("ru_done", Prefs.getInt("ru_done", 0) + 1);
        if (fresh) {
            Prefs.putInt("ru_new", Prefs.getInt("ru_new", 0) + 1);
        }
        if (Prefs.getInt("ru_done", 0) == GOAL) {
            Prefs.putInt("ru_streak", Prefs.getInt("ru_streak", 0) + 1);
            Prefs.putInt("ru_goal_day", day);
        }
    }

    // ------------------------------------------------------------------ flow

    private void header() {
        int[][] s = state();
        int known = 0;
        for (int[] x : s) {
            if (x[0] >= 3) {
                known++;
            }
        }
        int streak = Prefs.getInt("ru_streak", 0);
        head.setText("RUSSIAN  ·  today " + Math.min(doneToday(), GOAL) + "/" + GOAL + "  ·  known " + known + "/" + total()
                + (streak > 0 ? "  ·  🔥" + streak : ""));
    }

    /** Due reviews first, then a new card (in course order), else a random review. */
    private void pick() {
        int[][] s = state();
        int day = dayNum();
        List<Integer> due = new ArrayList<>();
        int firstNew = -1;
        for (int i = 0; i < s.length; i++) {
            if (s[i][0] > 0 && s[i][1] <= day) {
                due.add(i);
            } else if (s[i][0] == 0 && firstNew < 0) {
                firstNew = i;
            }
        }
        due.remove((Integer) item);
        if (!due.isEmpty()) {
            item = due.get(rnd.nextInt(due.size()));
            isNew = false;
        } else if (firstNew >= 0 && newToday() < NEW_PER_DAY) {
            item = firstNew;
            isNew = true;
        } else {
            List<Integer> seen = new ArrayList<>();
            for (int i = 0; i < s.length; i++) {
                if (s[i][0] > 0 && i != item) {
                    seen.add(i);
                }
            }
            if (seen.isEmpty()) {
                item = 0;
                isNew = true;
            } else {
                item = seen.get(rnd.nextInt(seen.size()));
                isNew = false;
            }
        }
        reverse = !isNew && item >= LETTERS.length && s[item][0] >= 3 && rnd.nextBoolean();
        answered = false;
        show();
    }

    private void show() {
        header();
        String[] it = item(item);
        opts.removeAllViews();
        if (isNew) {
            big.setText(it[0]);
            sub.setText("[" + it[1] + "]   =   " + it[2]);
            ask.setText("NEW  ·  " + it[3] + "  ·  look, listen, then tap GOT IT");
            next.setText("GOT IT ›");
            next.setOnClickListener(v -> {
                int[][] s = state();
                s[item][0] = 1;
                s[item][1] = dayNum();
                save(s);
                count(true);
                pick();
            });
            say(false);
            return;
        }
        boolean letter = item < LETTERS.length;
        big.setText(reverse ? it[2] : it[0]);
        sub.setText(reverse ? "in Russian?" : "");
        ask.setText(letter ? "Which sound is this letter?" : reverse ? "Pick the Russian word" : "What does it mean?");
        next.setText("SKIP ›");
        next.setOnClickListener(v -> pick());
        // three wrong answers of the same kind
        List<Integer> pool = new ArrayList<>();
        int from = letter ? 0 : LETTERS.length;
        int to = letter ? LETTERS.length : total();
        for (int i = from; i < to; i++) {
            if (i != item && !item(i)[letter ? 1 : 2].equals(it[letter ? 1 : 2])) {
                pool.add(i);
            }
        }
        Collections.shuffle(pool, rnd);
        List<Integer> choices = new ArrayList<>(pool.subList(0, Math.min(3, pool.size())));
        choices.add(item);
        Collections.shuffle(choices, rnd);
        LinearLayout row = null;
        final List<TextView> buttons = new ArrayList<>();
        for (int k = 0; k < choices.size(); k++) {
            final int c = choices.get(k);
            String[] ci = item(c);
            String label = letter ? ci[1] : reverse ? ci[0] : ci[2];
            if (k % 2 == 0) {
                row = row();
                opts.addView(row, wide());
            }
            TextView b = chip(label, () -> { });
            b.setTextSize(letter || reverse ? 15f : 11f);
            b.setOnClickListener(v -> answer(c, b, buttons, choices));
            buttons.add(b);
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            row.addView(b, p);
        }
    }

    private void answer(int chosen, TextView b, List<TextView> buttons, List<Integer> choices) {
        if (answered) {
            return;
        }
        answered = true;
        boolean ok = chosen == item;
        String[] it = item(item);
        int[][] s = state();
        int day = dayNum();
        if (ok) {
            s[item][0] = Math.min(GAPS.length - 1, s[item][0] + 1);
            s[item][1] = day + GAPS[s[item][0]];
            host.buzz(8);
        } else {
            s[item][0] = 1;
            s[item][1] = day;
            host.buzz(60);
        }
        save(s);
        count(false);
        for (int k = 0; k < buttons.size(); k++) {
            int c = choices.get(k);
            if (c == item) {
                buttons.get(k).setBackground(Theme.rounded(0xFF2E7D32, 14f, host));
                buttons.get(k).setTextColor(0xFFFFFFFF);
            } else if (c == chosen) {
                buttons.get(k).setBackground(Theme.rounded(0xFFC62828, 14f, host));
                buttons.get(k).setTextColor(0xFFFFFFFF);
            }
        }
        big.setText(it[0]);
        sub.setText("[" + it[1] + "]   =   " + it[2]);
        ask.setText(ok ? "✔ right! back in " + GAPS[s[item][0]] + (GAPS[s[item][0]] == 1 ? " day" : " days")
                : "✘ not quite, it comes back soon");
        next.setText("NEXT ›");
        next.setOnClickListener(v -> pick());
        if (doneToday() == GOAL) {
            host.toast("Daily goal done! 🇷🇺 🔥 " + Prefs.getInt("ru_streak", 0));
            host.confetti(getWidth() / 2f, getHeight() / 2f);
        }
        say(false);
        header();
        ui.postDelayed(() -> {
            if (answered && isAttachedToWindow()) {
                pick();
            }
        }, ok ? 1600 : 3200);
    }

    /** Says the Russian with the phone's text-to-speech. Tapping the speaker without a Russian voice explains how
     *  to get one; the automatic reading just stays quiet then. */
    private void say(final boolean manual) {
        if (item < 0) {
            return;
        }
        String[] it = item(item);
        final String text = item < LETTERS.length ? it[0].substring(0, 1) : it[0].replace("...", "").replace("?", "").trim();
        if (tts == null) {
            tts = new TextToSpeech(host.getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(new Locale("ru", "RU"));
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                    if (ttsReady) {
                        tts.setSpeechRate(0.85f);
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ru");
                    } else if (manual) {
                        ui.post(() -> host.toast("No Russian voice yet: Android Settings > Text-to-speech > install Russian"));
                    }
                }
            });
            return;
        }
        if (!ttsReady) {
            if (manual) {
                host.toast("No Russian voice yet: Android Settings > Text-to-speech > install Russian");
            }
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ru");
    }
}
