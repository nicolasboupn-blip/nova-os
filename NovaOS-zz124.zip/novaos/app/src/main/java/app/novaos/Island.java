package app.novaos;

import android.animation.ValueAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.PathInterpolator;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * NOVA ISLAND: a black pill around the front camera, over every app, like the Dynamic Island. It shows what is going
 * on right now (music, a timer, a focus round, the next bus, charging, a new message) and grows out into a big card
 * with details and buttons when you tap it. Hold it (or tap it when nothing is going on) for an overview of your day.
 * It lives in NOVA's accessibility service, which is the only way an app may draw on top of the status bar.
 */
final class Island {
    static final String K_ON = "island_on";
    static final String K_NOTIF = "island_notif";

    private static IslandView view;
    private static WindowManager wm;
    private static Context ctx;
    private static BroadcastReceiver power;

    private Island() {
    }

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    /** True while NOVA's accessibility service is running, so the island can be shown. */
    static boolean serviceOn() {
        return MouseService.instance != null;
    }

    /** Called by the accessibility service when it starts. */
    static void start(Context c, WindowManager w) {
        Prefs.init(c);
        ctx = c;
        wm = w;
        sync();
    }

    /** Called when the service stops. */
    static void stop() {
        detach();
        ctx = null;
        wm = null;
    }

    /** Shows or hides the island to match the setting. */
    static void sync() {
        if (ctx == null || wm == null) {
            return;
        }
        if (enabled()) {
            attach();
        } else {
            detach();
        }
    }

    private static void attach() {
        if (view != null) {
            return;
        }
        view = new IslandView(ctx, wm);
        view.add();
        power = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (view != null) {
                    view.powerChanged(Intent.ACTION_POWER_CONNECTED.equals(intent.getAction()));
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                ctx.registerReceiver(power, f);
            }
        } catch (RuntimeException ignored) {
            power = null;
        }
        NovaNotificationService.islandListener = item -> {
            if (view != null && Prefs.getBool(K_NOTIF, true)) {
                view.post(() -> {
                    if (view != null) {
                        view.notified(item);
                    }
                });
            }
        };
    }

    private static void detach() {
        NovaNotificationService.islandListener = null;
        if (power != null && ctx != null) {
            try {
                ctx.unregisterReceiver(power);
            } catch (RuntimeException ignored) {
                // already gone
            }
        }
        power = null;
        if (view != null) {
            view.remove();
            view = null;
        }
    }

    // ================================================================== the view

    /** One thing the island can show. */
    static final class Act {
        static final int MUSIC = 0;
        static final int TIMER = 1;
        static final int FOCUS = 2;
        static final int BUS = 3;
        static final int LEAVE = 4;
        static final int CHARGE = 5;
        static final int NOTE = 6;
        static final int LOW = 7;
        final int kind;
        final int color;

        Act(int kind, int color) {
            this.kind = kind;
            this.color = color;
        }
    }

    static final class IslandView extends View {
        private static final int GREEN = 0xFF34C759;
        private static final int ORANGE = 0xFFFF9F0A;
        private static final int RED = 0xFFFF453A;
        private static final int YELLOW = 0xFFFFC21A;
        private static final int BLUE = 0xFF0A84FF;
        private static final int PINK = 0xFFFF375F;

        private final WindowManager wm;
        private final WindowManager.LayoutParams lp;
        private final float d;
        private final Handler h = new Handler(Looper.getMainLooper());
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final PathInterpolator ease = new PathInterpolator(0.32f, 0.72f, 0f, 1f);

        // where the camera is (screen pixels)
        private float camX;
        private float camY;
        private float camR;
        private int screenW;

        // current and target size of the pill
        private float curW;
        private float curH;
        private float fromW;
        private float fromH;
        private float toW;
        private float toH;
        private float morph = 1f;
        private float contentAlpha = 1f;
        private ValueAnimator anim;

        private boolean expanded;
        private boolean overview;
        private boolean added;
        private boolean hiddenLandscape;
        private final List<Act> acts = new ArrayList<>();
        private int focusKind = -1;

        // live data
        private MediaController music;
        private Bitmap art;
        private String artKey = "";
        private long timerEnd;
        private long focusEnd;
        private long focusLeft;
        private boolean focusWork = true;
        private long chargeUntil;
        private boolean charging;
        private int battery;
        private NovaNotificationService.Item note;
        private long noteUntil;
        private Drawable noteIcon;
        private List<BusData.Dep> deps;
        private String busStop = "";
        private long busFetched;
        private boolean busBusy;

        // touch
        private float downX;
        private float downY;
        private long downAt;
        private final List<Object[]> hits = new ArrayList<>(); // {RectF, Runnable}
        private final Runnable longPress = () -> {
            downAt = -1;
            vibrate();
            showOverview();
        };

        private final Runnable poll = new Runnable() {
            @Override
            public void run() {
                update();
                h.postDelayed(this, expanded || hasLive() ? 1000 : 3000);
            }
        };

        IslandView(Context c, WindowManager wm) {
            super(c);
            this.wm = wm;
            d = c.getResources().getDisplayMetrics().density;
            Prefs.init(c);
            lp = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            } else if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        }

        // ------------------------------------------------------------------ window

        void add() {
            findCamera();
            float h0 = idleH();
            curW = toW = idleW();
            curH = toH = h0;
            place();
            try {
                wm.addView(this, lp);
                added = true;
            } catch (RuntimeException e) {
                added = false;
            }
            h.post(poll);
        }

        void remove() {
            h.removeCallbacksAndMessages(null);
            if (anim != null) {
                anim.cancel();
            }
            if (added) {
                try {
                    wm.removeView(this);
                } catch (RuntimeException ignored) {
                    // already gone
                }
            }
            added = false;
        }

        private void findCamera() {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            screenW = dm.widthPixels;
            camX = screenW / 2f;
            camY = 14 * d;
            camR = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    android.view.WindowMetrics m = wm.getCurrentWindowMetrics();
                    screenW = m.getBounds().width();
                    camX = screenW / 2f;
                    DisplayCutout cut = m.getWindowInsets().getDisplayCutout();
                    if (cut != null) {
                        for (Rect b : cut.getBoundingRects()) {
                            if (b.top < 200 * d && b.width() < screenW / 3) {
                                camX = b.exactCenterX();
                                camY = b.exactCenterY();
                                camR = Math.max(b.width(), b.height()) / 2f;
                                break;
                            }
                        }
                    }
                } catch (RuntimeException ignored) {
                    // keep the middle
                }
            }
        }

        private float idleH() {
            return Math.max(camR * 2 + 10 * d, 28 * d);
        }

        private float idleW() {
            return idleH() * 1.9f;
        }

        private float compactH() {
            return Math.max(camR * 2 + 12 * d, 32 * d);
        }

        /** Puts the window exactly around the pill: centred on the camera, growing downwards from it. */
        private void place() {
            int w = Math.round(curW);
            int hh = Math.round(curH);
            float top = camY - Math.min(curH, compactH()) / 2f;
            float cx = curW > screenW * 0.6f ? screenW / 2f : camX;
            lp.width = Math.max(1, w);
            lp.height = Math.max(1, hh);
            lp.x = Math.round(cx - w / 2f);
            lp.y = Math.round(Math.max(0, top));
            if (added) {
                try {
                    wm.updateViewLayout(this, lp);
                } catch (RuntimeException ignored) {
                    // window gone
                }
            }
        }

        private void animateTo(float w, float hh) {
            if (Math.abs(w - toW) < 1 && Math.abs(hh - toH) < 1 && anim == null) {
                return;
            }
            if (anim != null) {
                anim.cancel();
            }
            fromW = curW;
            fromH = curH;
            toW = w;
            toH = hh;
            final boolean growing = hh > fromH + 1 || w > fromW + 1;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(growing ? 420 : 340);
            anim.setInterpolator(ease);
            anim.addUpdateListener(a -> {
                morph = (float) a.getAnimatedValue();
                curW = fromW + (toW - fromW) * morph;
                curH = fromH + (toH - fromH) * morph;
                // the old content fades out fast, the new one fades in at the end
                contentAlpha = morph < 0.35f ? 1f - morph / 0.35f : Math.max(0f, (morph - 0.55f) / 0.45f);
                place();
                invalidate();
            });
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator a) {
                    morph = 1f;
                    contentAlpha = 1f;
                    anim = null;
                    place();
                    invalidate();
                }
            });
            anim.start();
        }

        // ------------------------------------------------------------------ data

        private boolean hasLive() {
            return !acts.isEmpty();
        }

        private void update() {
            boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
            if (land != hiddenLandscape) {
                hiddenLandscape = land;
                setVisibility(land ? GONE : VISIBLE);
                if (!land) {
                    findCamera();
                    place();
                }
            }
            if (land) {
                // sideways (games, videos): no island, and a 1 pixel window so it never catches a touch
                if (added && lp.width != 1) {
                    lp.width = 1;
                    lp.height = 1;
                    try {
                        wm.updateViewLayout(this, lp);
                    } catch (RuntimeException ignored) {
                        // window gone
                    }
                }
                return;
            }
            long now = System.currentTimeMillis();
            acts.clear();
            // music
            music = MusicHelper.controller(getContext());
            if (music != null && MusicHelper.isPlaying(music)) {
                acts.add(new Act(Act.MUSIC, GREEN));
                loadArt();
            } else if (music != null && MusicHelper.active(music) && focusKind == Act.MUSIC && expanded) {
                acts.add(new Act(Act.MUSIC, GREEN));
            }
            // NOVA timer
            timerEnd = TimerPage.endsAt();
            if (timerEnd > now) {
                acts.add(0, new Act(Act.TIMER, ORANGE));
            }
            // focus round
            try {
                focusEnd = Long.parseLong(Prefs.getString("focus_end", "0"));
                focusLeft = Long.parseLong(Prefs.getString("focus_left", "0"));
            } catch (NumberFormatException e) {
                focusEnd = 0;
                focusLeft = 0;
            }
            focusWork = Prefs.getInt("focus_mode", 0) == 0;
            if (focusEnd > now || focusLeft > 0) {
                acts.add(new Act(Act.FOCUS, focusWork ? PINK : GREEN));
            }
            // leave countdown and the next bus, on school days in the hour before you leave
            Calendar c = Calendar.getInstance();
            int dow = c.get(Calendar.DAY_OF_WEEK);
            boolean schoolDay = dow != Calendar.SATURDAY && dow != Calendar.SUNDAY;
            int left = Life.leaveMin() - (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE));
            boolean commute = schoolDay && left > -15 && left <= 60;
            if (commute || expanded && (focusKind == Act.BUS || overview)) {
                fetchBus(false);
            }
            if (commute && deps != null && !deps.isEmpty()) {
                acts.add(new Act(Act.BUS, YELLOW));
            } else if (commute && left > 0) {
                acts.add(new Act(Act.LEAVE, YELLOW));
            }
            // battery
            battery = Theme.batteryPct(getContext());
            if (chargeUntil > now) {
                acts.add(0, new Act(Act.CHARGE, GREEN));
            } else if (battery > 0 && battery <= 15 && !charging) {
                acts.add(new Act(Act.LOW, RED));
            }
            // a new message, for a few seconds
            if (note != null && noteUntil > now) {
                acts.add(0, new Act(Act.NOTE, BLUE));
            } else if (note != null && !(expanded && focusKind == Act.NOTE)) {
                note = null;
            }
            boolean focusStill = false;
            for (Act a : acts) {
                focusStill |= a.kind == focusKind;
            }
            if (!expanded) {
                focusKind = acts.isEmpty() ? -1 : acts.get(0).kind;
                float w = acts.isEmpty() ? idleW() : compactW(acts.get(0).kind);
                float hh = acts.isEmpty() ? idleH() : compactH();
                animateTo(w, hh);
            } else if (!overview && !focusStill) {
                collapse();
            }
            invalidate();
        }

        private float compactW(int kind) {
            float gap = camR * 2 + 16 * d;
            switch (kind) {
                case Act.NOTE:
                    return Math.min(screenW - 24 * d, gap + 230 * d);
                case Act.MUSIC:
                    return gap + 120 * d;
                default:
                    return gap + 140 * d;
            }
        }

        private void loadArt() {
            try {
                MediaMetadata md = music.getMetadata();
                String key = md == null ? "" : MusicHelper.title(music) + MusicHelper.artist(music);
                if (key.equals(artKey)) {
                    return;
                }
                artKey = key;
                Bitmap b = md == null ? null : md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (b == null && md != null) {
                    b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                }
                art = b == null ? null : Bitmap.createScaledBitmap(b, Math.round(64 * d), Math.round(64 * d), true);
            } catch (RuntimeException e) {
                art = null;
            }
        }

        private void fetchBus(boolean force) {
            long now = System.currentTimeMillis();
            if (busBusy || (!force && now - busFetched < 60000)) {
                return;
            }
            final List<BusData.Route> routes = new ArrayList<>();
            BusData.Stop stop = null;
            for (BusData.Route rt : BusData.routes()) {
                if (!rt.show) {
                    continue;
                }
                for (BusData.Stop s : rt.stops) {
                    if (rt.boardIds.contains(s.id) && (stop == null || stop.id.equals(s.id))) {
                        stop = s;
                        if (!routes.contains(rt)) {
                            routes.add(rt);
                        }
                    }
                }
            }
            if (stop == null) {
                return;
            }
            busBusy = true;
            busFetched = now;
            final BusData.Stop st = stop;
            new Thread(() -> {
                List<BusData.Dep> got = null;
                try {
                    got = BusData.board(st, routes);
                } catch (RuntimeException ignored) {
                    // try again later
                }
                final List<BusData.Dep> res = got;
                h.post(() -> {
                    busBusy = false;
                    if (res != null) {
                        deps = res;
                        busStop = st.shortName();
                    }
                    invalidate();
                });
            }).start();
        }

        void powerChanged(boolean on) {
            charging = on;
            chargeUntil = System.currentTimeMillis() + 4000;
            update();
            h.postDelayed(this::update, 4100);
        }

        void notified(NovaNotificationService.Item item) {
            note = item;
            noteUntil = System.currentTimeMillis() + 4500;
            noteIcon = null;
            try {
                noteIcon = getContext().getPackageManager().getApplicationIcon(item.pkg);
            } catch (Exception ignored) {
                // no icon
            }
            update();
            h.postDelayed(this::update, 4600);
        }

        // ------------------------------------------------------------------ open and close

        private void expand(int kind) {
            focusKind = kind;
            overview = kind < 0;
            expanded = true;
            vibrate();
            if (overview) {
                fetchBus(false);
            }
            animateTo(screenW - 20 * d, expandedH());
        }

        private void showOverview() {
            expand(-1);
        }

        private void collapse() {
            expanded = false;
            overview = false;
            update();
        }

        private float expandedH() {
            if (overview) {
                return 250 * d;
            }
            switch (focusKind) {
                case Act.MUSIC:
                    return 176 * d;
                case Act.BUS:
                    return 188 * d;
                case Act.NOTE:
                    return 128 * d;
                default:
                    return 150 * d;
            }
        }

        private void vibrate() {
            try {
                performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK);
            } catch (RuntimeException ignored) {
                // no haptics
            }
        }

        // ------------------------------------------------------------------ touch

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_OUTSIDE:
                    if (expanded) {
                        collapse();
                    }
                    return true;
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    downAt = SystemClock.uptimeMillis();
                    if (!expanded) {
                        h.postDelayed(longPress, 450);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getX() - downX, e.getY() - downY) > 12 * d) {
                        h.removeCallbacks(longPress);
                    }
                    // pull the pill down to open it
                    if (!expanded && e.getY() - downY > 24 * d && downAt > 0) {
                        downAt = -1;
                        h.removeCallbacks(longPress);
                        expand(acts.isEmpty() ? -1 : acts.get(0).kind);
                    }
                    return true;
                case MotionEvent.ACTION_UP: {
                    h.removeCallbacks(longPress);
                    if (downAt < 0) {
                        return true;
                    }
                    float dy = e.getY() - downY;
                    if (expanded && dy < -30 * d) {
                        collapse();
                        return true;
                    }
                    if (Math.hypot(e.getX() - downX, dy) > 14 * d) {
                        return true;
                    }
                    if (!expanded) {
                        // a tap on the small circle on the right opens the second thing
                        if (acts.size() > 1 && e.getX() > getWidth() - curH) {
                            expand(acts.get(1).kind);
                        } else {
                            expand(acts.isEmpty() ? -1 : acts.get(0).kind);
                        }
                        return true;
                    }
                    for (Object[] hit : hits) {
                        if (((RectF) hit[0]).contains(e.getX(), e.getY())) {
                            vibrate();
                            ((Runnable) hit[1]).run();
                            update();
                            return true;
                        }
                    }
                    collapse();
                    return true;
                }
                default:
                    h.removeCallbacks(longPress);
                    return true;
            }
        }

        // ------------------------------------------------------------------ drawing

        private String mmss(long ms) {
            ms = Math.max(0, ms);
            long s = (ms + 999) / 1000;
            return s >= 3600 ? String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                    : String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
        }

        private long focusRemaining() {
            long now = System.currentTimeMillis();
            return focusEnd > now ? focusEnd - now : focusLeft;
        }

        private int busMinutes() {
            if (deps == null) {
                return -1;
            }
            long now = System.currentTimeMillis();
            for (BusData.Dep dep : deps) {
                if (dep.at > now - 20000) {
                    return (int) Math.max(0, (dep.at - now) / 60000);
                }
            }
            return -1;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float hh = getHeight();
            float rad = Math.min(hh / 2f, expanded || hh > compactH() * 1.5f ? 38 * d : hh / 2f);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF000000);
            r.set(0, 0, w, hh);
            c.drawRoundRect(r, rad, rad, p);
            hits.clear();
            if (contentAlpha <= 0.01f) {
                return;
            }
            int alpha = Math.round(255 * contentAlpha);
            if (expanded && hh > compactH() * 1.5f) {
                if (overview) {
                    drawOverview(c, w, hh, alpha);
                } else {
                    drawExpanded(c, w, hh, alpha);
                }
            } else if (!acts.isEmpty()) {
                drawCompact(c, w, hh, alpha);
            }
        }

        private void text(Canvas c, String s, float x, float y, float sp, int color, int alpha, boolean bold,
                Paint.Align al, float maxW) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
            p.setTextSize(sp * d);
            p.setTextAlign(al);
            p.setColor(color);
            p.setAlpha(Math.round(Math.min(255, ((color >>> 24) & 0xFF) * alpha / 255f)));
            if (maxW > 0) {
                int n = p.breakText(s, true, maxW, null);
                if (n < s.length()) {
                    s = s.substring(0, Math.max(1, n - 1)) + "…";
                }
            }
            c.drawText(s, x, y, p);
        }

        private void dot(Canvas c, float x, float y, float rr, int color, int alpha) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(Math.round(((color >>> 24) & 0xFF) * alpha / 255f));
            c.drawCircle(x, y, rr, p);
        }

        private void bitmapCircle(Canvas c, Bitmap b, float cx, float cy, float rr, int alpha, boolean round) {
            Matrix m = new Matrix();
            float s = rr * 2 / b.getWidth();
            m.setScale(s, s);
            m.postTranslate(cx - rr, cy - rr);
            BitmapShader sh = new BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            sh.setLocalMatrix(m);
            p.setShader(sh);
            p.setAlpha(alpha);
            if (round) {
                c.drawCircle(cx, cy, rr, p);
            } else {
                c.drawRoundRect(new RectF(cx - rr, cy - rr, cx + rr, cy + rr), rr * 0.3f, rr * 0.3f, p);
            }
            p.setShader(null);
        }

        private void icon(Canvas c, Drawable dr, float cx, float cy, float rr, int alpha) {
            if (dr == null) {
                return;
            }
            Rect old = dr.copyBounds();
            dr.setBounds(Math.round(cx - rr), Math.round(cy - rr), Math.round(cx + rr), Math.round(cy + rr));
            dr.setAlpha(alpha);
            dr.draw(c);
            dr.setBounds(old);
        }

        /** Little bars that bounce while music plays. */
        private void bars(Canvas c, float right, float cy, float hgt, int color, int alpha, boolean moving) {
            float t = SystemClock.uptimeMillis() / 1000f;
            float bw = 2.6f * d;
            for (int i = 0; i < 4; i++) {
                float v = moving ? 0.35f + 0.65f * Math.abs((float) Math.sin(t * (5.1f + i * 1.3f) + i)) : 0.3f;
                float bh = hgt * v;
                float x = right - (4 - i) * (bw + 2.2f * d);
                p.setShader(null);
                p.setColor(color);
                p.setAlpha(alpha);
                c.drawRoundRect(new RectF(x, cy - bh / 2, x + bw, cy + bh / 2), bw / 2, bw / 2, p);
            }
            if (moving) {
                postInvalidateDelayed(70);
            }
        }

        private void drawCompact(Canvas c, float w, float hh, int alpha) {
            Act a = acts.get(0);
            float cy = hh / 2f;
            float lx = hh / 2f + 2 * d;
            float rx = w - hh / 2f + 4 * d;
            float ir = hh * 0.32f;
            if (acts.size() > 1) {
                // a second thing sits in a little circle at the right end
                rx -= hh * 0.85f;
                Act b = acts.get(1);
                dot(c, w - hh / 2f, cy, ir * 0.9f, b.color, alpha);
            }
            float textSp = Math.min(14f, hh / d * 0.42f);
            long now = System.currentTimeMillis();
            switch (a.kind) {
                case Act.MUSIC:
                    if (art != null) {
                        bitmapCircle(c, art, lx, cy, ir, alpha, false);
                    } else {
                        dot(c, lx, cy, ir, GREEN, alpha);
                        text(c, "♪", lx, cy + ir * 0.5f, textSp * 0.9f, 0xFF000000, alpha, true, Paint.Align.CENTER, 0);
                    }
                    bars(c, rx, cy, hh * 0.45f, GREEN, alpha, MusicHelper.isPlaying(music));
                    break;
                case Act.TIMER:
                    dot(c, lx, cy, ir, ORANGE, alpha);
                    text(c, "⏱", lx, cy + ir * 0.45f, textSp * 0.85f, 0xFF000000, alpha, true, Paint.Align.CENTER, 0);
                    text(c, mmss(timerEnd - now), rx, cy + textSp * d * 0.36f, textSp, ORANGE, alpha, true, Paint.Align.RIGHT, 0);
                    break;
                case Act.FOCUS: {
                    long left = focusRemaining();
                    long len = (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                    ring(c, lx, cy, ir, 1f - left / (float) len, a.color, alpha);
                    text(c, mmss(left) + (focusEnd > now ? "" : " ‖"), rx, cy + textSp * d * 0.36f, textSp, a.color, alpha, true,
                            Paint.Align.RIGHT, 0);
                    break;
                }
                case Act.BUS: {
                    String line = deps != null && !deps.isEmpty() ? deps.get(0).line : "";
                    dot(c, lx, cy, ir, YELLOW, alpha);
                    text(c, line, lx, cy + textSp * d * 0.3f, textSp * 0.72f, 0xFF000000, alpha, true, Paint.Align.CENTER, 0);
                    int m = busMinutes();
                    text(c, m < 0 ? "…" : m == 0 ? "now" : m + "'", rx, cy + textSp * d * 0.36f, textSp, YELLOW, alpha, true,
                            Paint.Align.RIGHT, 0);
                    break;
                }
                case Act.LEAVE: {
                    int left = Life.leaveMin() - Life.nowMin();
                    dot(c, lx, cy, ir, YELLOW, alpha);
                    text(c, "🏃", lx, cy + ir * 0.45f, textSp * 0.8f, 0xFFFFFFFF, alpha, false, Paint.Align.CENTER, 0);
                    text(c, "leave " + left + "'", rx, cy + textSp * d * 0.36f, textSp, YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                    break;
                }
                case Act.CHARGE:
                case Act.LOW: {
                    battery(c, lx - ir * 0.2f, cy, ir, a.color, alpha);
                    text(c, battery + "%", rx, cy + textSp * d * 0.36f, textSp, a.color, alpha, true, Paint.Align.RIGHT, 0);
                    break;
                }
                case Act.NOTE: {
                    if (noteIcon != null) {
                        icon(c, noteIcon, lx, cy, ir, alpha);
                    } else {
                        dot(c, lx, cy, ir, BLUE, alpha);
                    }
                    float gapR = camX - (lp.x) + camR + 8 * d;
                    float maxW = rx - Math.max(gapR, lx + ir + 8 * d);
                    text(c, note == null ? "" : note.title, rx, cy + textSp * d * 0.36f, textSp * 0.9f, 0xFFFFFFFF, alpha, true,
                            Paint.Align.RIGHT, maxW);
                    break;
                }
                default:
                    break;
            }
        }

        private void ring(Canvas c, float cx, float cy, float rr, float v, int color, int alpha) {
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(rr * 0.32f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x44FFFFFF);
            p.setAlpha(Math.round(0x44 * alpha / 255f));
            c.drawCircle(cx, cy, rr * 0.82f, p);
            p.setColor(color);
            p.setAlpha(alpha);
            c.drawArc(new RectF(cx - rr * 0.82f, cy - rr * 0.82f, cx + rr * 0.82f, cy + rr * 0.82f), -90,
                    360 * Math.max(0.01f, Math.min(1f, v)), false, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void battery(Canvas c, float cx, float cy, float rr, int color, int alpha) {
            float bw = rr * 1.9f;
            float bh = rr * 1.05f;
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f * d);
            p.setColor(0x99FFFFFF);
            p.setAlpha(Math.round(0x99 * alpha / 255f));
            RectF b = new RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2);
            c.drawRoundRect(b, 3 * d, 3 * d, p);
            p.setStyle(Paint.Style.FILL);
            c.drawRect(b.right + 1 * d, cy - bh * 0.2f, b.right + 2.5f * d, cy + bh * 0.2f, p);
            p.setColor(color);
            p.setAlpha(alpha);
            float fill = (bw - 4 * d) * Math.max(0.05f, battery / 100f);
            c.drawRoundRect(new RectF(b.left + 2 * d, b.top + 2 * d, b.left + 2 * d + fill, b.bottom - 2 * d), 2 * d, 2 * d, p);
        }

        private RectF button(Canvas c, String label, float cx, float cy, float rr, int bg, int fg, int alpha, Runnable act) {
            dot(c, cx, cy, rr, bg, alpha);
            text(c, label, cx, cy + rr * 0.36f, rr / d * 0.95f, fg, alpha, true, Paint.Align.CENTER, 0);
            RectF hit = new RectF(cx - rr - 6 * d, cy - rr - 6 * d, cx + rr + 6 * d, cy + rr + 6 * d);
            hits.add(new Object[] {hit, act});
            return hit;
        }

        private void pill(Canvas c, String label, float x, float y, float w, float hgt, int bg, int fg, int alpha, Runnable act) {
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(bg);
            p.setAlpha(Math.round(((bg >>> 24) & 0xFF) * alpha / 255f));
            RectF rr = new RectF(x, y, x + w, y + hgt);
            c.drawRoundRect(rr, hgt / 2, hgt / 2, p);
            text(c, label, rr.centerX(), rr.centerY() + 4.2f * d, 12f, fg, alpha, true, Paint.Align.CENTER, w - 8 * d);
            hits.add(new Object[] {new RectF(rr.left, rr.top - 4 * d, rr.right, rr.bottom + 4 * d), act});
        }

        private void openNova() {
            try {
                Intent i = new Intent(getContext(), NovaActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                getContext().startActivity(i);
            } catch (RuntimeException ignored) {
                // cannot open
            }
            collapse();
        }

        private void drawExpanded(Canvas c, float w, float hh, int alpha) {
            float pad = 20 * d;
            float top = Math.max(camY - lp.y + camR + 14 * d, 18 * d);
            long now = System.currentTimeMillis();
            switch (focusKind) {
                case Act.MUSIC: {
                    float s = 58 * d;
                    float y0 = top;
                    if (art != null) {
                        bitmapCircle(c, art, pad + s / 2, y0 + s / 2, s / 2, alpha, false);
                    } else {
                        p.setColor(0xFF1C1C1E);
                        p.setAlpha(alpha);
                        c.drawRoundRect(new RectF(pad, y0, pad + s, y0 + s), 12 * d, 12 * d, p);
                        text(c, "♪", pad + s / 2, y0 + s * 0.65f, 24f, GREEN, alpha, true, Paint.Align.CENTER, 0);
                    }
                    float tx = pad + s + 14 * d;
                    float maxW = w - tx - pad - 40 * d;
                    text(c, music == null ? "" : MusicHelper.title(music), tx, y0 + 22 * d, 16f, 0xFFFFFFFF, alpha, true,
                            Paint.Align.LEFT, maxW);
                    text(c, music == null ? "" : MusicHelper.artist(music), tx, y0 + 42 * d, 13f, 0xFF98989D, alpha, false,
                            Paint.Align.LEFT, maxW);
                    bars(c, w - pad, y0 + 18 * d, 18 * d, GREEN, alpha, MusicHelper.isPlaying(music));
                    // progress
                    long pos = 0;
                    long dur = 0;
                    if (music != null) {
                        PlaybackState ps = music.getPlaybackState();
                        MediaMetadata md = music.getMetadata();
                        dur = md == null ? 0 : md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                        if (ps != null) {
                            pos = ps.getPosition();
                            if (ps.getState() == PlaybackState.STATE_PLAYING) {
                                pos += (long) ((SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime())
                                        * ps.getPlaybackSpeed());
                            }
                        }
                    }
                    float by = y0 + s + 18 * d;
                    p.setColor(0x33FFFFFF);
                    p.setAlpha(Math.round(0x33 * alpha / 255f));
                    c.drawRoundRect(new RectF(pad, by, w - pad, by + 4 * d), 2 * d, 2 * d, p);
                    if (dur > 0) {
                        p.setColor(0xFFFFFFFF);
                        p.setAlpha(alpha);
                        float f = Math.max(0, Math.min(1, pos / (float) dur));
                        c.drawRoundRect(new RectF(pad, by, pad + (w - 2 * pad) * f, by + 4 * d), 2 * d, 2 * d, p);
                        text(c, mmss(pos), pad, by + 18 * d, 10f, 0xFF98989D, alpha, false, Paint.Align.LEFT, 0);
                        text(c, "-" + mmss(dur - pos), w - pad, by + 18 * d, 10f, 0xFF98989D, alpha, false, Paint.Align.RIGHT, 0);
                    }
                    float cy = by + 44 * d;
                    button(c, "⏮", w / 2 - 70 * d, cy, 20 * d, 0xFF1C1C1E, 0xFFFFFFFF, alpha, () -> MusicHelper.previous(getContext()));
                    button(c, MusicHelper.isPlaying(music) ? "⏸" : "▶", w / 2, cy, 24 * d, 0xFFFFFFFF, 0xFF000000, alpha,
                            () -> MusicHelper.toggle(getContext()));
                    button(c, "⏭", w / 2 + 70 * d, cy, 20 * d, 0xFF1C1C1E, 0xFFFFFFFF, alpha, () -> MusicHelper.next(getContext()));
                    if (MusicHelper.isPlaying(music)) {
                        postInvalidateDelayed(500);
                    }
                    break;
                }
                case Act.TIMER: {
                    text(c, "TIMER", pad, top + 12 * d, 11f, ORANGE, alpha, true, Paint.Align.LEFT, 0);
                    text(c, mmss(timerEnd - now), pad, top + 58 * d, 44f, ORANGE, alpha, false, Paint.Align.LEFT, 0);
                    pill(c, "OPEN NOVA", w - pad - 110 * d, top + 28 * d, 110 * d, 36 * d, 0xFF2C2C2E, 0xFFFFFFFF, alpha, this::openNova);
                    postInvalidateDelayed(500);
                    break;
                }
                case Act.FOCUS: {
                    long left = focusRemaining();
                    long len = (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                    int col = focusWork ? PINK : GREEN;
                    ring(c, pad + 34 * d, top + 44 * d, 34 * d, 1f - left / (float) len, col, alpha);
                    text(c, focusWork ? "FOCUS" : "BREAK", pad + 84 * d, top + 22 * d, 11f, col, alpha, true, Paint.Align.LEFT, 0);
                    text(c, mmss(left), pad + 84 * d, top + 62 * d, 38f, 0xFFFFFFFF, alpha, false, Paint.Align.LEFT, 0);
                    boolean running = focusEnd > now;
                    pill(c, running ? "PAUSE" : "GO ON", w - pad - 96 * d, top + 18 * d, 96 * d, 34 * d, col, 0xFF000000, alpha,
                            () -> toggleFocus(running));
                    pill(c, "NOVA", w - pad - 96 * d, top + 60 * d, 96 * d, 34 * d, 0xFF2C2C2E, 0xFFFFFFFF, alpha, this::openNova);
                    postInvalidateDelayed(500);
                    break;
                }
                case Act.BUS:
                case Act.LEAVE: {
                    // a mini yellow stop sign
                    float x0 = pad;
                    float y0 = top;
                    p.setColor(0xFF0B0B0B);
                    p.setAlpha(alpha);
                    c.drawRoundRect(new RectF(x0, y0, w - pad, y0 + 120 * d), 14 * d, 14 * d, p);
                    text(c, busStop.isEmpty() ? "next bus" : busStop, x0 + 12 * d, y0 + 22 * d, 12f, YELLOW, alpha, true,
                            Paint.Align.LEFT, w - 2 * pad - 90 * d);
                    int left = Life.leaveMin() - Life.nowMin();
                    text(c, left > 0 ? "leave in " + left + "'" : "go now!", w - pad - 12 * d, y0 + 22 * d, 12f,
                            left <= 3 ? RED : YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                    if (deps == null || deps.isEmpty()) {
                        text(c, busBusy ? "loading…" : "no departures", x0 + 12 * d, y0 + 60 * d, 14f, YELLOW, alpha, false,
                                Paint.Align.LEFT, 0);
                    } else {
                        int row = 0;
                        for (BusData.Dep dep : deps) {
                            if (dep.at < now - 20000) {
                                continue;
                            }
                            float yy = y0 + 50 * d + row * 26 * d;
                            long m = Math.max(0, (dep.at - now) / 60000);
                            text(c, dep.line, x0 + 34 * d, yy, 16f, YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                            text(c, dep.to, x0 + 44 * d, yy, 15f, YELLOW, alpha, false, Paint.Align.LEFT, w - 2 * pad - 110 * d);
                            text(c, m + "'", w - pad - 12 * d, yy, 16f, YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                            if (++row >= 3) {
                                break;
                            }
                        }
                    }
                    break;
                }
                case Act.CHARGE:
                case Act.LOW: {
                    int col = focusKind == Act.LOW ? RED : GREEN;
                    battery(c, pad + 30 * d, top + 36 * d, 24 * d, col, alpha);
                    text(c, battery + "%", pad + 76 * d, top + 50 * d, 38f, col, alpha, false, Paint.Align.LEFT, 0);
                    text(c, charging ? "charging" : battery <= 15 ? "low battery — plug in soon" : "on battery",
                            pad + 76 * d, top + 72 * d, 12f, 0xFF98989D, alpha, false, Paint.Align.LEFT, 0);
                    break;
                }
                case Act.NOTE: {
                    if (note == null) {
                        break;
                    }
                    if (noteIcon != null) {
                        icon(c, noteIcon, pad + 18 * d, top + 22 * d, 18 * d, alpha);
                    }
                    text(c, note.app, pad + 46 * d, top + 14 * d, 11f, 0xFF98989D, alpha, false, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    text(c, note.title, pad + 46 * d, top + 34 * d, 15f, 0xFFFFFFFF, alpha, true, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    text(c, note.text, pad + 46 * d, top + 54 * d, 13f, 0xFFD1D1D6, alpha, false, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    final NovaNotificationService.Item it = note;
                    hits.add(new Object[] {new RectF(0, 0, w, hh), (Runnable) () -> {
                        try {
                            if (it.open != null) {
                                it.open.send();
                            }
                        } catch (Exception ignored) {
                            // gone
                        }
                        note = null;
                        collapse();
                    }});
                    break;
                }
                default:
                    break;
            }
            // other things going on, as small chips at the bottom
            if (acts.size() > 1) {
                float x = pad;
                for (final Act a : acts) {
                    if (a.kind == focusKind) {
                        continue;
                    }
                    dot(c, x + 6 * d, hh - 16 * d, 6 * d, a.color, alpha);
                    hits.add(new Object[] {new RectF(x - 6 * d, hh - 34 * d, x + 20 * d, hh), (Runnable) () -> {
                        focusKind = a.kind;
                        animateTo(screenW - 20 * d, expandedH());
                    }});
                    x += 22 * d;
                }
            }
        }

        private void toggleFocus(boolean running) {
            long now = System.currentTimeMillis();
            if (running) {
                Prefs.putString("focus_left", String.valueOf(focusEnd - now));
                Prefs.putString("focus_end", "0");
            } else {
                long left = focusLeft > 0 ? focusLeft : (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                Prefs.putString("focus_end", String.valueOf(now + left));
                Prefs.putString("focus_left", "0");
            }
        }

        /** The day at a glance: time, battery, next bus, mood, money, Russian, focus, homework. */
        private void drawOverview(Canvas c, float w, float hh, int alpha) {
            float pad = 22 * d;
            float top = Math.max(camY - lp.y + camR + 12 * d, 18 * d);
            Calendar cal = Calendar.getInstance();
            String time = String.format(Locale.ROOT, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
            text(c, time, pad, top + 40 * d, 40f, 0xFFFFFFFF, alpha, false, Paint.Align.LEFT, 0);
            text(c, new java.text.SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(cal.getTime()), pad,
                    top + 62 * d, 12f, 0xFF98989D, alpha, false, Paint.Align.LEFT, 0);
            battery(c, w - pad - 52 * d, top + 22 * d, 12 * d, battery <= 15 ? RED : charging ? GREEN : 0xFFFFFFFF, alpha);
            text(c, battery + "%", w - pad, top + 27 * d, 13f, 0xFFFFFFFF, alpha, true, Paint.Align.RIGHT, 0);
            // rows of facts
            List<String[]> rows = new ArrayList<>();
            int m = busMinutes();
            if (m >= 0 && deps != null && !deps.isEmpty()) {
                rows.add(new String[] {"🚌", "Bus " + deps.get(0).line + " in " + m + "'", "#FFC21A"});
            }
            int mood = MoodLog.current();
            rows.add(new String[] {mood >= 0 ? MoodLog.FACES[mood] : "😶", mood >= 0 ? "Mood: " + MoodLog.NAMES[mood]
                    : "No mood yet today", "#FFFFFF"});
            long leftCents = Math.round(MoneyWidget.budget() * 100);
            long start = MoneyWidget.weekStart();
            for (Object[] o : MoneyWidget.entries()) {
                if ((long) o[0] >= start) {
                    leftCents += (long) o[1];
                }
            }
            rows.add(new String[] {"💸", MoneyWidget.chf(leftCents) + " left this week", leftCents < 0 ? "#FF453A" : "#34C759"});
            int ru = Prefs.getInt("ru_day", 0) == (int) ((cal.getTimeInMillis() + cal.get(Calendar.ZONE_OFFSET)
                    + cal.get(Calendar.DST_OFFSET)) / 86400000L) ? Prefs.getInt("ru_done", 0) : 0;
            rows.add(new String[] {"🇷🇺", "Russian " + Math.min(ru, 15) + "/15 today", "#0A84FF"});
            for (String[] f : Life.homework()) {
                if (!"1".equals(f[1])) {
                    rows.add(new String[] {"📚", f[2] + " · " + Life.nice(f[0]), "#FF9F0A"});
                    break;
                }
            }
            float y = top + 96 * d;
            for (int i = 0; i < rows.size() && i < 5; i++) {
                String[] row = rows.get(i);
                text(c, row[0], pad + 10 * d, y, 15f, 0xFFFFFFFF, alpha, false, Paint.Align.CENTER, 0);
                text(c, row[1], pad + 30 * d, y, 14f, android.graphics.Color.parseColor(row[2]), alpha, false, Paint.Align.LEFT,
                        w - 2 * pad - 30 * d);
                y += 26 * d;
            }
            pill(c, "OPEN NOVA", w - pad - 104 * d, top + 46 * d, 104 * d, 30 * d, 0xFF2C2C2E, 0xFFFFFFFF, alpha, this::openNova);
        }
    }
}
