package app.novaos;

import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * NOVA Net: accounts, friends, chats (direct and group) and ranklists, all on your own server.
 * Nothing is contacted until you enter a server address and sign in.
 */
final class NetScreen extends FrameLayout implements BackAware {
    private static final String[] TABS = {"CHATS", "FRIENDS", "RANKS", "ME"};
    private static final String[] BOARD_NAMES = {"THIS WEEK", "ALL TIME", "CASTLE", "STREAK", "QUESTS", "COLLECTION"};
    private static final String[] BOARD_KEYS = {"week", "all", "stage", "streak", "quests", "collection"};
    private static final String[] BOARD_UNIT = {"coins", "coins", "stage", "days", "quests", "items"};

    private final NovaActivity host;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final LinearLayout column;
    private final LinearLayout header;
    private final LinearLayout tabRow;
    private final ScrollView scroll;
    private final LinearLayout body;
    private final LinearLayout footer;

    private int tab;
    private boolean registering;
    private boolean verified = true;
    private JSONObject me = new JSONObject();
    private String note = "";
    private int board;
    private boolean friendsOnly;
    private int unreadTotal;

    // chat state
    private int chatId;
    private String chatName = "";
    private boolean chatGroup;
    private boolean chatOwner;
    private String chatCode = "";
    private long lastMsg;
    private LinearLayout msgBox;
    private boolean polling;
    private int generation;
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm", Locale.getDefault());

    private NetScreen(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        column = new LinearLayout(host);
        column.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 16);
        column.setPadding(pad, Theme.dp(host, 36), pad, Theme.dp(host, 12));
        addView(column, new LayoutParams(-1, -1));
        header = new LinearLayout(host);
        header.setGravity(Gravity.CENTER_VERTICAL);
        column.addView(header);
        tabRow = new LinearLayout(host);
        tabRow.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        column.addView(tabRow);
        scroll = new ScrollView(host);
        scroll.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(body);
        column.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        footer = new LinearLayout(host);
        footer.setOrientation(LinearLayout.VERTICAL);
        column.addView(footer);
        setOnApplyWindowInsetsListener((v, ins) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                int b = ins.getInsets(WindowInsets.Type.ime()).bottom;
                v.setPadding(0, 0, 0, b);
            }
            return ins;
        });
        start();
    }

    static void open(NovaActivity host) {
        host.showOverlay(new NetScreen(host));
    }

    @Override
    public boolean onBack() {
        if (chatId != 0) {
            leaveChat();
            return true;
        }
        close();
        return true;
    }

    private void close() {
        stopPolling();
        host.hideOverlay();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopPolling();
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ small helpers

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(int v) {
        return Theme.dp(host, v);
    }

    private TextView chip(String s, boolean on, Runnable r) {
        TextView t = text(s, 11f, on ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, 0, 0, dp(6));
        return r;
    }

    private void addChip(LinearLayout row, String s, boolean on, Runnable r) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(6);
        row.addView(chip(s, on, r), lp);
    }

    private void head(String s) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, dp(16), 0, dp(6));
        body.addView(t);
    }

    private EditText field(String hint, boolean password) {
        EditText e = new EditText(host);
        e.setHint(hint);
        e.setHintTextColor(Theme.DIM);
        e.setTextColor(Theme.TEXT);
        e.setTextSize(14f);
        e.setSingleLine(true);
        e.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (password ? InputType.TYPE_TEXT_VARIATION_PASSWORD : 0));
        return e;
    }

    private void gap(int v) {
        body.addView(new View(host), new LinearLayout.LayoutParams(1, dp(v)));
    }

    private void err(String s) {
        note = s;
        host.toast(s);
    }

    private ImageView avatar(JSONArray look, int zoom) {
        ImageView iv = new ImageView(host);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        try {
            if (look != null && look.length() >= 11) {
                int[] lk = new int[14];
                for (int i = 0; i < 14 && i < look.length(); i++) {
                    lk[i] = look.optInt(i, 0);
                }
                Bitmap b = Bitmap.createBitmap(Avatar.render(lk, 1), Avatar.W, Avatar.H, Bitmap.Config.ARGB_8888);
                iv.setImageBitmap(Bitmap.createScaledBitmap(b, Avatar.W * zoom, Avatar.H * zoom, false));
            }
        } catch (Exception ignored) {
        }
        return iv;
    }

    private String ago(long ts) {
        if (ts <= 0) {
            return "";
        }
        long d = System.currentTimeMillis() / 1000 - ts;
        if (d < 120) {
            return "online";
        }
        if (d < 3600) {
            return (d / 60) + " min ago";
        }
        if (d < 86400) {
            return (d / 3600) + " h ago";
        }
        return (d / 86400) + " d ago";
    }

    // ------------------------------------------------------------------ flow

    private void start() {
        generation++;
        stopPolling();
        chatId = 0;
        footer.removeAllViews();
        header.removeAllViews();
        tabRow.removeAllViews();
        body.removeAllViews();
        TextView title = text("NOVA NET", 16f, Theme.TEXT);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView x = text("✕", 18f, Theme.DIM);
        x.setPadding(dp(12), dp(4), 0, dp(4));
        x.setOnClickListener(v -> close());
        header.addView(x);
        if (NovaNet.server().isEmpty()) {
            setup();
        } else if (!NovaNet.signedIn()) {
            auth();
        } else {
            enter();
        }
    }

    /** First screen: the address of your server. */
    private void setup() {
        body.removeAllViews();
        body.addView(text("Chat with friends and climb the ranklists. NOVA Net runs on a server you host yourself, "
                + "so you need its address first. The server folder in the project explains how to start it.", 12f, Theme.DIM));
        gap(14);
        final EditText url = field("https://your-server.example", false);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        body.addView(url);
        gap(10);
        LinearLayout r = row();
        addChip(r, "CONNECT", true, () -> {
            String u = url.getText().toString().trim();
            if (u.isEmpty()) {
                err("Type the server address");
                return;
            }
            NovaNet.setServer(u);
            if (NovaNet.server().startsWith("http://")) {
                host.toast("Plain http is blocked by Android. Use https.");
            }
            NovaNet.run("GET", "/", null, res -> {
                if (!res.ok()) {
                    NovaNet.setServer("");
                    err(res.error != null ? res.error : "No answer from that address");
                    return;
                }
                start();
            });
        });
        body.addView(r);
        body.addView(text("Your friends need the same address. Your messages stay on your own server.", 10f, Theme.DIM));
    }

    private void auth() {
        body.removeAllViews();
        tabRow.removeAllViews();
        LinearLayout t = row();
        addChip(t, "LOG IN", !registering, () -> {
            registering = false;
            auth();
        });
        addChip(t, "CREATE ACCOUNT", registering, () -> {
            registering = true;
            auth();
        });
        body.addView(t);
        gap(8);
        final EditText email = field("email", false);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        final EditText user = field(registering ? "username (3-16: a-z, 0-9, _)" : "username or email", false);
        final EditText pw = field(registering ? "password (8+ characters)" : "password", true);
        if (registering) {
            body.addView(email);
            gap(8);
        }
        body.addView(user);
        gap(8);
        body.addView(pw);
        gap(12);
        LinearLayout r = row();
        addChip(r, registering ? "SIGN UP" : "LOG IN", true, () -> {
            String u = user.getText().toString().trim();
            String p = pw.getText().toString();
            JSONObject b = new JSONObject();
            try {
                if (registering) {
                    b.put("email", email.getText().toString().trim());
                    b.put("username", u);
                } else {
                    b.put("login", u);
                }
                b.put("password", p);
            } catch (Exception ignored) {
            }
            NovaNet.run("POST", registering ? "/api/register" : "/api/login", b, res -> {
                if (!res.ok()) {
                    err(res.error);
                    return;
                }
                NovaNet.saveSession(res.json.optString("token"), res.json.optString("username", u));
                NovaNet.sync(true);
                start();
            });
        });
        addChip(r, "CHANGE SERVER", false, () -> {
            NovaNet.setServer("");
            start();
        });
        body.addView(r);
        body.addView(text(registering
                ? "Your email is only used to confirm your account and reset your password. Other people never see it."
                : "Forgot your password? Ask the server owner.", 10f, Theme.DIM));
        body.addView(text("Server: " + NovaNet.server(), 10f, Theme.DIM));
    }

    /** Signed in: learn who we are, then show the tabs. */
    private void enter() {
        body.removeAllViews();
        body.addView(text("Connecting...", 12f, Theme.DIM));
        final int gen = generation;
        NovaNet.run("GET", "/api/me", null, res -> {
            if (gen != generation) {
                return;
            }
            if (res.code == 401) {
                start();
                return;
            }
            if (!res.ok()) {
                body.removeAllViews();
                body.addView(text(res.error, 12f, 0xFFFF8A8A));
                LinearLayout r = row();
                addChip(r, "TRY AGAIN", true, this::start);
                addChip(r, "CHANGE SERVER", false, () -> {
                    NovaNet.setServer("");
                    start();
                });
                body.addView(r);
                return;
            }
            me = res.json;
            verified = me.optBoolean("verified", true);
            NovaNet.sync(true);
            if (!verified) {
                verify();
            } else {
                showTab(tab);
            }
        });
    }

    private void verify() {
        tabRow.removeAllViews();
        body.removeAllViews();
        body.addView(text("Check your email", 14f, Theme.TEXT));
        body.addView(text("We sent a 6 digit code to " + me.optString("email") + ". It works for one hour.", 11f, Theme.DIM));
        gap(10);
        final EditText code = field("code", false);
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        body.addView(code);
        gap(10);
        LinearLayout r = row();
        addChip(r, "CONFIRM", true, () -> NovaNet.run("POST", "/api/verify", NovaNet.obj("code",
                code.getText().toString().trim()), res -> {
            if (!res.ok()) {
                err(res.error);
                return;
            }
            enter();
        }));
        addChip(r, "SEND AGAIN", false, () -> NovaNet.run("POST", "/api/verify/resend", new JSONObject(), res ->
                host.toast(res.ok() ? "Sent" : res.error)));
        addChip(r, "LOG OUT", false, this::logout);
        body.addView(r);
    }

    private void logout() {
        NovaNet.run("POST", "/api/logout", new JSONObject(), res -> {
        });
        NovaNet.logoutLocal();
        tab = 0;
        start();
    }

    // ------------------------------------------------------------------ tabs

    private void showTab(int t) {
        generation++;
        stopPolling();
        chatId = 0;
        footer.removeAllViews();
        tab = t;
        tabRow.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            String label = TABS[i] + (i == 0 && unreadTotal > 0 ? " " + unreadTotal : "");
            addChip(tabRow, label, i == t, () -> showTab(idx));
        }
        body.removeAllViews();
        switch (t) {
            case 0:
                chats();
                break;
            case 1:
                friends();
                break;
            case 2:
                ranks();
                break;
            default:
                mine();
                break;
        }
    }

    // ------------------------------------------------------------------ chats

    private void chats() {
        final int gen = generation;
        LinearLayout r = row();
        addChip(r, "NEW GROUP", false, this::newGroup);
        addChip(r, "JOIN WITH CODE", false, this::joinGroup);
        body.addView(r);
        final LinearLayout list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);
        list.addView(text("Loading...", 11f, Theme.DIM));
        NovaNet.run("GET", "/api/chats", null, res -> {
            if (gen != generation) {
                return;
            }
            list.removeAllViews();
            if (!res.ok()) {
                list.addView(text(res.error, 12f, 0xFFFF8A8A));
                return;
            }
            JSONArray a = res.json.optJSONArray("chats");
            unreadTotal = res.json.optInt("unread", 0);
            if (a == null || a.length() == 0) {
                list.addView(text("No chats yet. Add a friend in FRIENDS and tap MESSAGE, or make a group and share its code.",
                        12f, Theme.DIM));
                return;
            }
            for (int i = 0; i < a.length(); i++) {
                final JSONObject c = a.optJSONObject(i);
                if (c != null) {
                    list.addView(chatRow(c));
                }
            }
        });
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (gen == generation && tab == 0 && chatId == 0 && isAttachedToWindow()) {
                    refreshChats(gen, list);
                    h.postDelayed(this, 15000);
                }
            }
        }, 15000);
    }

    private void refreshChats(final int gen, final LinearLayout list) {
        NovaNet.run("GET", "/api/chats", null, res -> {
            if (gen != generation || !res.ok()) {
                return;
            }
            JSONArray a = res.json.optJSONArray("chats");
            if (a == null) {
                return;
            }
            list.removeAllViews();
            for (int i = 0; i < a.length(); i++) {
                JSONObject c = a.optJSONObject(i);
                if (c != null) {
                    list.addView(chatRow(c));
                }
            }
        });
    }

    private View chatRow(final JSONObject c) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Theme.rounded(0x1AFFFFFF, 12f, host));
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        box.setLayoutParams(lp);
        LinearLayout top = new LinearLayout(host);
        boolean group = "group".equals(c.optString("kind"));
        TextView name = text((group ? "# " : "") + c.optString("name"), 13f, Theme.TEXT);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        int unread = c.optInt("unread", 0);
        if (unread > 0) {
            TextView u = text(String.valueOf(unread), 11f, Theme.BG);
            u.setBackground(Theme.rounded(Theme.ACCENT, 10f, host));
            u.setPadding(dp(8), dp(2), dp(8), dp(2));
            top.addView(u);
        }
        box.addView(top);
        JSONObject last = c.optJSONObject("last");
        String preview = last == null ? "No messages yet" : (group ? last.optString("user") + ": " : "") + last.optString("text");
        TextView p = text(preview, 11f, Theme.DIM);
        p.setSingleLine(true);
        p.setEllipsize(android.text.TextUtils.TruncateAt.END);
        box.addView(p);
        box.setClickable(true);
        box.setOnClickListener(v -> openChat(c.optInt("id"), c.optString("name"), group, c.optBoolean("owner"),
                c.isNull("code") ? "" : c.optString("code")));
        return box;
    }

    private void newGroup() {
        final EditText name = field("group name", false);
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("New group")
                .setView(name).setNegativeButton("Cancel", null).setPositiveButton("Create", (d, w) ->
                        NovaNet.run("POST", "/api/groups", NovaNet.obj("name", name.getText().toString().trim()), res -> {
                            if (!res.ok()) {
                                err(res.error);
                                return;
                            }
                            host.toast("Group code: " + res.json.optString("code"));
                            openChat(res.json.optInt("id"), name.getText().toString().trim(), true, true,
                                    res.json.optString("code"));
                        })).show();
    }

    private void joinGroup() {
        final EditText code = field("group code", false);
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Join a group")
                .setView(code).setNegativeButton("Cancel", null).setPositiveButton("Join", (d, w) ->
                        NovaNet.run("POST", "/api/groups/join", NovaNet.obj("code", code.getText().toString().trim()),
                                res -> {
                                    if (!res.ok()) {
                                        err(res.error);
                                        return;
                                    }
                                    showTab(0);
                                })).show();
    }

    // ------------------------------------------------------------------ one chat

    private void openChat(int id, String name, boolean group, boolean owner, String code) {
        generation++;
        stopPolling();
        chatId = id;
        chatName = name;
        chatGroup = group;
        chatOwner = owner;
        chatCode = code == null ? "" : code;
        lastMsg = 0;
        tabRow.removeAllViews();
        body.removeAllViews();
        footer.removeAllViews();
        LinearLayout bar = row();
        addChip(bar, "‹ BACK", false, this::leaveChat);
        TextView t = text((group ? "# " : "") + name, 13f, Theme.TEXT);
        t.setPadding(dp(8), 0, 0, 0);
        bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (group) {
            addChip(bar, "INFO", false, this::groupInfo);
        } else {
            addChip(bar, "⋮", false, () -> dmMenu(name));
        }
        tabRow.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        msgBox = new LinearLayout(host);
        msgBox.setOrientation(LinearLayout.VERTICAL);
        body.addView(msgBox);

        LinearLayout in = new LinearLayout(host);
        in.setGravity(Gravity.CENTER_VERTICAL);
        final EditText e = field("message", false);
        e.setSingleLine(false);
        e.setMaxLines(4);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        in.addView(e, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView send = chip("SEND", true, () -> {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) {
                return;
            }
            e.setText("");
            NovaNet.run("POST", "/api/chats/" + chatId + "/messages", NovaNet.obj("text", s), res -> {
                if (!res.ok()) {
                    err(res.error);
                    e.setText(s);
                    return;
                }
                Sfx.play(Sfx.COIN);
                fetchMessages();
            });
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(8);
        in.addView(send, lp);
        footer.addView(in);
        fetchMessages();
        polling = true;
        final int gen = generation;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (polling && gen == generation && chatId != 0) {
                    fetchMessages();
                    h.postDelayed(this, 3000);
                }
            }
        }, 3000);
    }

    private void leaveChat() {
        stopPolling();
        showTab(0);
    }

    private void stopPolling() {
        polling = false;
        h.removeCallbacksAndMessages(null);
    }

    private boolean fetching;

    private void fetchMessages() {
        if (fetching || chatId == 0) {
            return;
        }
        fetching = true;
        final int gen = generation;
        NovaNet.run("GET", "/api/chats/" + chatId + "/messages?after=" + lastMsg + "&limit=60", null, res -> {
            fetching = false;
            if (gen != generation || chatId == 0 || !res.ok()) {
                return;
            }
            JSONArray a = res.json.optJSONArray("messages");
            if (a == null || a.length() == 0) {
                if (lastMsg == 0 && msgBox.getChildCount() == 0) {
                    msgBox.addView(text("Say hi!", 12f, Theme.DIM));
                }
                return;
            }
            if (lastMsg == 0) {
                msgBox.removeAllViews();
            }
            for (int i = 0; i < a.length(); i++) {
                JSONObject m = a.optJSONObject(i);
                if (m != null) {
                    lastMsg = Math.max(lastMsg, m.optLong("id"));
                    msgBox.addView(bubble(m));
                }
            }
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    private View bubble(final JSONObject m) {
        final String user = m.optString("user");
        boolean mine = user.equalsIgnoreCase(NovaNet.username());
        LinearLayout wrap = new LinearLayout(host);
        wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        wrap.setLayoutParams(lp);
        wrap.setGravity(mine ? Gravity.END : Gravity.START);
        if (!mine && chatGroup) {
            wrap.addView(text(user, 10f, Theme.ACCENT));
        }
        TextView t = text(m.optString("text"), 13f, mine ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(mine ? Theme.ACCENT : 0x26FFFFFF, 14f, host));
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setMaxWidth(host.getResources().getDisplayMetrics().widthPixels * 3 / 4);
        t.setTextIsSelectable(false);
        wrap.addView(t);
        wrap.addView(text(clock.format(new Date(m.optLong("ts") * 1000L)), 9f, Theme.DIM));
        if (!mine) {
            t.setOnLongClickListener(v -> {
                messageMenu(m);
                return true;
            });
        }
        return wrap;
    }

    private void messageMenu(final JSONObject m) {
        final String user = m.optString("user");
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(user)
                .setItems(new String[] {"Report this message", "Block " + user}, (d, which) -> {
                    if (which == 0) {
                        NovaNet.run("POST", "/api/report", NovaNet.obj("message_id", String.valueOf(m.optLong("id")),
                                "reason", "reported from the app"), res -> host.toast(res.ok() ? "Reported. Thank you." : res.error));
                    } else {
                        NovaNet.run("POST", "/api/block", NovaNet.obj("username", user), res -> {
                            host.toast(res.ok() ? user + " is blocked" : res.error);
                            if (res.ok()) {
                                leaveChat();
                            }
                        });
                    }
                }).show();
    }

    private void dmMenu(final String name) {
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle(name)
                .setItems(new String[] {"Block " + name}, (d, which) ->
                        NovaNet.run("POST", "/api/block", NovaNet.obj("username", name), res -> {
                            host.toast(res.ok() ? name + " is blocked" : res.error);
                            if (res.ok()) {
                                leaveChat();
                            }
                        })).show();
    }

    private void groupInfo() {
        NovaNet.run("GET", "/api/chats/" + chatId + "/members", null, res -> {
            if (!res.ok()) {
                err(res.error);
                return;
            }
            JSONArray a = res.json.optJSONArray("members");
            final List<String> names = new ArrayList<>();
            StringBuilder sb = new StringBuilder();
            if (chatOwner && !chatCode.isEmpty()) {
                sb.append("Invite code: ").append(chatCode).append("\n\n");
            }
            for (int i = 0; a != null && i < a.length(); i++) {
                JSONObject u = a.optJSONObject(i);
                if (u == null) {
                    continue;
                }
                names.add(u.optString("username"));
                sb.append(u.optString("username")).append(u.optBoolean("owner") ? "  (owner)" : "").append("\n");
            }
            AlertDialog.Builder b = new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle(chatName).setMessage(sb.toString()).setPositiveButton("Close", null)
                    .setNegativeButton("Leave group", (d, w) -> NovaNet.run("POST", "/api/groups/leave",
                            NovaNet.obj("room_id", String.valueOf(chatId)), r2 -> {
                                if (r2.ok()) {
                                    leaveChat();
                                } else {
                                    err(r2.error);
                                }
                            }));
            if (chatOwner) {
                b.setNeutralButton("Remove someone", (d, w) -> kickPicker(names));
            }
            b.show();
        });
    }

    private void kickPicker(final List<String> names) {
        final List<String> others = new ArrayList<>();
        for (String n : names) {
            if (!n.equalsIgnoreCase(NovaNet.username())) {
                others.add(n);
            }
        }
        if (others.isEmpty()) {
            host.toast("Nobody else is in the group");
            return;
        }
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Remove")
                .setItems(others.toArray(new String[0]), (d, which) -> NovaNet.run("POST", "/api/groups/kick",
                        NovaNet.obj("room_id", String.valueOf(chatId), "username", others.get(which)),
                        res -> host.toast(res.ok() ? "Removed" : res.error))).show();
    }

    // ------------------------------------------------------------------ friends

    private void friends() {
        final int gen = generation;
        final EditText who = field("add a friend by username", false);
        body.addView(who);
        gap(6);
        LinearLayout r = row();
        addChip(r, "SEND REQUEST", true, () -> NovaNet.run("POST", "/api/friends/request",
                NovaNet.obj("username", who.getText().toString().trim()), res -> {
                    if (!res.ok()) {
                        err(res.error);
                        return;
                    }
                    host.toast("friend".equals(res.json.optString("status")) ? "You are friends now" : "Request sent");
                    showTab(1);
                }));
        body.addView(r);
        final LinearLayout list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);
        list.addView(text("Loading...", 11f, Theme.DIM));
        NovaNet.run("GET", "/api/friends", null, res -> {
            if (gen != generation) {
                return;
            }
            list.removeAllViews();
            if (!res.ok()) {
                list.addView(text(res.error, 12f, 0xFFFF8A8A));
                return;
            }
            JSONArray a = res.json.optJSONArray("friends");
            if (a == null || a.length() == 0) {
                list.addView(text("No friends yet. Ask a friend for their username and send a request.", 12f, Theme.DIM));
                return;
            }
            for (int i = 0; i < a.length(); i++) {
                JSONObject f = a.optJSONObject(i);
                if (f != null) {
                    list.addView(friendRow(f));
                }
            }
        });
    }

    private View friendRow(final JSONObject f) {
        final String name = f.optString("username");
        final String status = f.optString("status");
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(Theme.rounded(0x1AFFFFFF, 12f, host));
        box.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        box.setLayoutParams(lp);
        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(avatar(f.optJSONArray("look"), 3), new LinearLayout.LayoutParams(dp(60), dp(48)));
        LinearLayout info = new LinearLayout(host);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(text(name, 14f, Theme.TEXT));
        String title = f.optString("title");
        String sub = "incoming".equals(status) ? "wants to be your friend" : "outgoing".equals(status) ? "request sent"
                : (title.isEmpty() ? "" : title + "  ") + ago(f.optLong("last_seen"));
        info.addView(text(sub, 10f, Theme.DIM));
        top.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(top);
        LinearLayout r = row();
        if ("incoming".equals(status)) {
            addChip(r, "ACCEPT", true, () -> NovaNet.run("POST", "/api/friends/accept", NovaNet.obj("username", name),
                    res -> showTab(1)));
            addChip(r, "DECLINE", false, () -> NovaNet.run("POST", "/api/friends/remove", NovaNet.obj("username", name),
                    res -> showTab(1)));
        } else if ("outgoing".equals(status)) {
            addChip(r, "CANCEL", false, () -> NovaNet.run("POST", "/api/friends/remove", NovaNet.obj("username", name),
                    res -> showTab(1)));
        } else {
            addChip(r, "MESSAGE", true, () -> NovaNet.run("POST", "/api/chats/dm", NovaNet.obj("username", name), res -> {
                if (!res.ok()) {
                    err(res.error);
                    return;
                }
                openChat(res.json.optInt("id"), name, false, false, "");
            }));
            addChip(r, "REMOVE", false, () -> confirm("Remove " + name + " from your friends?", () ->
                    NovaNet.run("POST", "/api/friends/remove", NovaNet.obj("username", name), res -> showTab(1))));
            addChip(r, "BLOCK", false, () -> confirm("Block " + name + "? You will not see each other's messages.", () ->
                    NovaNet.run("POST", "/api/block", NovaNet.obj("username", name), res -> showTab(1))));
        }
        box.addView(r);
        return box;
    }

    private void confirm(String q, final Runnable yes) {
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setMessage(q)
                .setNegativeButton("No", null).setPositiveButton("Yes", (d, w) -> yes.run()).show();
    }

    // ------------------------------------------------------------------ ranks

    private void ranks() {
        final int gen = generation;
        LinearLayout r1 = row();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            addChip(r1, BOARD_NAMES[i], board == i, () -> {
                board = idx;
                showTab(2);
            });
        }
        body.addView(r1);
        LinearLayout r2 = row();
        for (int i = 3; i < 6; i++) {
            final int idx = i;
            addChip(r2, BOARD_NAMES[i], board == i, () -> {
                board = idx;
                showTab(2);
            });
        }
        body.addView(r2);
        LinearLayout r3 = row();
        addChip(r3, "EVERYONE", !friendsOnly, () -> {
            friendsOnly = false;
            showTab(2);
        });
        addChip(r3, "FRIENDS", friendsOnly, () -> {
            friendsOnly = true;
            showTab(2);
        });
        body.addView(r3);
        final LinearLayout list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);
        list.addView(text("Loading...", 11f, Theme.DIM));
        NovaNet.sync(true);
        h.postDelayed(() -> NovaNet.run("GET", "/api/rank?board=" + BOARD_KEYS[board] + "&scope="
                + (friendsOnly ? "friends" : "all"), null, res -> {
            if (gen != generation) {
                return;
            }
            list.removeAllViews();
            if (!res.ok()) {
                list.addView(text(res.error, 12f, 0xFFFF8A8A));
                return;
            }
            if (res.json.optBoolean("hidden")) {
                list.addView(text("You are hidden from the ranklists (ME > Show me on ranklists).", 11f, Theme.DIM));
            }
            if (res.json.optBoolean("cheat")) {
                list.addView(text("Your account is not ranked because admin mode was used on this phone.", 11f, 0xFFFFB86B));
            }
            JSONObject mine = res.json.optJSONObject("me");
            if (mine != null) {
                list.addView(text("You: #" + mine.optInt("rank") + "  " + mine.optLong("value") + " "
                        + BOARD_UNIT[board], 13f, Theme.ACCENT));
            }
            JSONArray rows = res.json.optJSONArray("rows");
            if (rows == null || rows.length() == 0) {
                list.addView(text("Nobody here yet.", 12f, Theme.DIM));
                return;
            }
            for (int i = 0; i < rows.length(); i++) {
                JSONObject u = rows.optJSONObject(i);
                if (u != null) {
                    list.addView(rankRow(u));
                }
            }
        }), 700);   // give the sync a moment to arrive first
    }

    private View rankRow(JSONObject u) {
        LinearLayout box = new LinearLayout(host);
        box.setGravity(Gravity.CENTER_VERTICAL);
        boolean me = u.optBoolean("me");
        box.setBackground(Theme.rounded(me ? 0x33B39DFF : 0x14FFFFFF, 12f, host));
        box.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(5);
        box.setLayoutParams(lp);
        int rank = u.optInt("rank");
        String medal = rank == 1 ? "🥇" : rank == 2 ? "🥈" : rank == 3 ? "🥉" : "#" + rank;
        TextView rk = text(medal, 13f, Theme.TEXT);
        box.addView(rk, new LinearLayout.LayoutParams(dp(40), -2));
        box.addView(avatar(u.optJSONArray("look"), 2), new LinearLayout.LayoutParams(dp(44), dp(36)));
        LinearLayout info = new LinearLayout(host);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(8), 0, 0, 0);
        info.addView(text(u.optString("username"), 13f, Theme.TEXT));
        String title = u.optString("title");
        if (!title.isEmpty()) {
            info.addView(text(title, 9f, Theme.DIM));
        }
        box.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
        box.addView(text(String.valueOf(u.optLong("value")), 13f, Theme.ACCENT));
        return box;
    }

    // ------------------------------------------------------------------ me

    private void mine() {
        final int gen = generation;
        body.addView(text(NovaNet.username(), 16f, Theme.TEXT));
        body.addView(text(me.optString("email") + (verified ? "" : "  (not confirmed)"), 11f, Theme.DIM));
        body.addView(text("Server: " + NovaNet.server(), 10f, Theme.DIM));
        head("MY NUMBERS");
        body.addView(text("Coins earned this week: " + Prefs.getInt("ns_week", 0) + "\nCoins earned all time: "
                + Prefs.getInt("ns_all", 0) + "\nCastle stage: " + Castle.stage() + "\nQuest streak: "
                + Prefs.getInt("q_streak", 0) + "\nQuests done: " + Prefs.getInt("ns_quests", 0) + "\nCosmetics owned: "
                + NetStats.cosmetics(), 12f, Theme.TEXT));
        body.addView(text("These go to your server so friends can see them. Casino winnings do not count.", 10f, Theme.DIM));
        head("PRIVACY");
        LinearLayout r = row();
        final boolean hidden = me.optBoolean("hidden");
        addChip(r, hidden ? "HIDDEN FROM RANKS" : "SHOWN ON RANKS", !hidden, () -> {
            JSONObject b = new JSONObject();
            try {
                b.put("hidden", !hidden);
            } catch (Exception ignored) {
            }
            NovaNet.run("POST", "/api/settings", b, res -> {
                if (!res.ok()) {
                    err(res.error);
                    return;
                }
                try {
                    me.put("hidden", !hidden);
                } catch (Exception ignored) {
                }
                showTab(3);
            });
        });
        addChip(r, "SYNC NOW", false, () -> {
            NovaNet.sync(true);
            host.toast("Sent");
        });
        body.addView(r);
        head("ACCOUNT");
        LinearLayout r2 = row();
        addChip(r2, "BLOCKED PEOPLE", false, this::blockedList);
        addChip(r2, "LOG OUT", false, this::logout);
        body.addView(r2);
        LinearLayout r3 = row();
        addChip(r3, "CHANGE PASSWORD", false, this::changePassword);
        addChip(r3, "DELETE ACCOUNT", false, this::deleteAccount);
        body.addView(r3);
        LinearLayout r4 = row();
        addChip(r4, "CHANGE SERVER", false, () -> confirm("Log out and use another server?", () -> {
            NovaNet.logoutLocal();
            NovaNet.setServer("");
            start();
        }));
        body.addView(r4);
    }

    private void blockedList() {
        NovaNet.run("GET", "/api/blocks", null, res -> {
            if (!res.ok()) {
                err(res.error);
                return;
            }
            JSONArray a = res.json.optJSONArray("blocked");
            if (a == null || a.length() == 0) {
                host.toast("You have not blocked anyone");
                return;
            }
            final String[] names = new String[a.length()];
            for (int i = 0; i < names.length; i++) {
                Object o = a.opt(i);
                names[i] = o instanceof JSONObject ? ((JSONObject) o).optString("username") : String.valueOf(o);
            }
            new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Tap to unblock")
                    .setItems(names, (d, which) -> NovaNet.run("POST", "/api/unblock", NovaNet.obj("username", names[which]),
                            r2 -> host.toast(r2.ok() ? names[which] + " is unblocked" : r2.error))).show();
        });
    }

    private void changePassword() {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), 0);
        final EditText old = field("current password", true);
        final EditText neu = field("new password (8+ characters)", true);
        box.addView(old);
        box.addView(neu);
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Change password")
                .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Change", (d, w) ->
                        NovaNet.run("POST", "/api/password", NovaNet.obj("old", old.getText().toString(), "new",
                                neu.getText().toString()), res -> host.toast(res.ok() ? "Password changed" : res.error))).show();
    }

    private void deleteAccount() {
        final EditText pw = field("your password", true);
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Delete account").setMessage("This removes your account and messages from the server for good.")
                .setView(pw).setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) ->
                        NovaNet.run("POST", "/api/me/delete", NovaNet.obj("password", pw.getText().toString()), res -> {
                            if (!res.ok()) {
                                err(res.error);
                                return;
                            }
                            NovaNet.logoutLocal();
                            host.toast("Account deleted");
                            start();
                        })).show();
    }
}
