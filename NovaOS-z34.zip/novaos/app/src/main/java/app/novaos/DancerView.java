package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Your character in the top corner of the home screen. He dances to your music and otherwise gets on with his day:
 * waving, drinking coffee, reading, texting, sleeping at night, holding an umbrella when it rains. Tap him to see
 * the next thing he does.
 */
final class DancerView extends View {
    static final String[] SCENES = {"Dancing", "Disco", "Headbanging", "Robot dance", "Waving", "Coffee break",
        "Sleeping", "Reading", "Umbrella", "Jumping jacks", "Texting", "Celebrating"};
    private static final int BOUNCE = 0, DISCO = 1, HEADBANG = 2, ROBOT = 3, WAVE = 4, COFFEE = 5, SLEEP = 6, READ = 7,
        RAIN = 8, JACKS = 9, PHONE = 10, CHEER = 11, COUNT = 12;
    private static final float BPM = 112f;

    private static WeakReference<DancerView> last = new WeakReference<>(null);

    private final NovaActivity host;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Paint p = new Paint();
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Random rnd = new Random();
    private final Map<Integer, Bitmap> cache = new HashMap<>();
    private final int s;          // screen pixels per sprite pixel
    private final long t0 = System.nanoTime();

    private int[] look = Avatar.look();
    private int scene = WAVE;
    private long sceneUntil;
    private long manualUntil;
    private long cheerUntil;
    private boolean playing;
    private boolean wasPlaying;
    private long polled;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!isAttachedToWindow()) {
                return;
            }
            if (getAlpha() > 0.02f && isShown()) {
                invalidate();
            }
            h.postDelayed(this, Saver.on() ? 450 : 66);
        }
    };

    DancerView(NovaActivity host) {
        super(host);
        this.host = host;
        float d = host.getResources().getDisplayMetrics().density;
        s = Math.max(2, Math.round(d * 1.1f));
        p.setAntiAlias(true);
        p.setFilterBitmap(false);
        setClickable(false);
        last = new WeakReference<>(this);
    }

    int width() {
        return 44 * s;
    }

    int height() {
        return 36 * s;
    }

    /** Top corner on the side away from the castle. */
    FrameLayout.LayoutParams params() {
        boolean lefty = Prefs.getBool("s_lefty", false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width(), height(),
                Gravity.TOP | (lefty ? Gravity.END : Gravity.START));
        lp.topMargin = Theme.dp(host, 2);
        lp.leftMargin = Theme.dp(host, 8);
        lp.rightMargin = Theme.dp(host, 8);
        return lp;
    }

    /** A burst of joy: called when a quest is done or a good pile of coins arrives. */
    static void cheer() {
        DancerView v = last.get();
        if (v != null) {
            v.cheerUntil = System.currentTimeMillis() + 2600;
        }
    }

    /** Tapping him jumps to the next thing he does. */
    boolean hit(float rawX, float rawY) {
        int[] a = new int[2];
        getLocationOnScreen(a);
        if (rawX < a[0] || rawY < a[1] || rawX > a[0] + getWidth() * getScaleX() || rawY > a[1] + getHeight()) {
            return false;
        }
        scene = (scene + 1) % COUNT;
        if (scene == CHEER) {
            cheerUntil = System.currentTimeMillis() + 2600;
        }
        manualUntil = System.currentTimeMillis() + 12000;
        sceneUntil = manualUntil;
        host.buzz(10);
        invalidate();
        return true;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    protected void onDetachedFromWindow() {
        h.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ choosing what he does

    private boolean raining() {
        int c = WeatherData.code;
        return WeatherData.valid && ((c >= 51 && c <= 67) || (c >= 80 && c <= 82) || c >= 95);
    }

    private void choose(long now) {
        if (now - polled > 2000) {
            polled = now;
            try {
                playing = MusicHelper.isPlaying(MusicHelper.controller(host));
            } catch (Throwable t) {
                playing = false;
            }
            int[] lk = Avatar.look();
            if (!Arrays.equals(lk, look)) {
                look = lk;
                cache.clear();
            }
            if (playing != wasPlaying) {
                wasPlaying = playing;
                if (now >= manualUntil) {
                    sceneUntil = 0;
                }
            }
        }
        if (cheerUntil > now) {
            scene = CHEER;
            return;
        }
        if (scene == CHEER && manualUntil <= now) {
            sceneUntil = 0;
        }
        if (now < sceneUntil) {
            return;
        }
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int old = scene;
        int next;
        long dur;
        if (playing) {
            next = rnd.nextInt(4);
            dur = 10000 + rnd.nextInt(5000);
        } else if (hour >= 23 || hour < 6) {
            next = SLEEP;
            dur = 40000;
        } else if (raining() && rnd.nextInt(10) < 6) {
            next = RAIN;
            dur = 20000;
        } else {
            int[] pool = hour < 10 ? new int[] {COFFEE, COFFEE, WAVE, READ, PHONE, JACKS}
                    : new int[] {WAVE, READ, JACKS, PHONE, COFFEE, WAVE};
            next = pool[rnd.nextInt(pool.length)];
            dur = 14000 + rnd.nextInt(7000);
        }
        if (next == old && playing) {
            next = (next + 1) % 4;
        }
        scene = next;
        sceneUntil = now + dur;
    }

    private Bitmap sprite(int armL, int armR, int wing) {
        int key = (armL * 8 + armR) * 4 + (Avatar.hasWings(look) ? wing & 3 : 0);
        Bitmap b = cache.get(key);
        if (b == null) {
            b = Bitmap.createBitmap(Avatar.render(look, wing & 3, armL, armR), Avatar.W, Avatar.H,
                    Bitmap.Config.ARGB_8888);
            cache.put(key, b);
        }
        return b;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas c) {
        long wall = System.currentTimeMillis();
        choose(wall);
        float t = (System.nanoTime() - t0) / 1e9f;
        float beat = t * BPM / 60f;
        float fr = beat - (float) Math.floor(beat);
        boolean evenBeat = ((int) Math.floor(beat) & 1) == 0;
        boolean quad = (((int) Math.floor(beat / 2f)) & 1) == 0;
        int aL = 0;
        int aR = 0;
        float jump = 0f;
        float rot = 0f;
        float shift = 0f;
        float squash = 1f;
        float breathe = 0.012f * (float) Math.sin(t * 2.2f);
        switch (scene) {
            case BOUNCE:
                aL = evenBeat ? Avatar.ARM_UP : Avatar.ARM_DOWN;
                aR = evenBeat ? Avatar.ARM_DOWN : Avatar.ARM_UP;
                jump = 1.6f * (float) Math.abs(Math.sin(Math.PI * beat));
                rot = (evenBeat ? -1 : 1) * 4f * (float) Math.sin(Math.PI * fr);
                break;
            case DISCO:
                aL = quad ? Avatar.ARM_HIP : Avatar.ARM_DIAG;
                aR = quad ? Avatar.ARM_DIAG : Avatar.ARM_HIP;
                jump = 0.8f * (float) Math.abs(Math.sin(Math.PI * beat));
                rot = (quad ? 1 : -1) * 7f;
                shift = (quad ? 1 : -1) * 1.4f;
                break;
            case HEADBANG:
                aL = Avatar.ARM_CHEER;
                aR = Avatar.ARM_CHEER;
                squash = 1f - 0.09f * (float) Math.abs(Math.sin(Math.PI * beat));
                rot = 9f * (float) Math.sin(Math.PI * 2 * beat);
                break;
            case ROBOT:
                aL = evenBeat ? Avatar.ARM_OUT : Avatar.ARM_CHEER;
                aR = evenBeat ? Avatar.ARM_CHEER : Avatar.ARM_OUT;
                shift = (float) Math.round(2.5f * Math.sin(Math.PI * beat / 2f));
                jump = fr < 0.2f ? 0.6f : 0f;
                break;
            case WAVE:
                aR = (int) (t * 3.4f) % 2 == 0 ? Avatar.ARM_UP : Avatar.ARM_DIAG;
                rot = 2f * (float) Math.sin(t * 3f);
                break;
            case COFFEE:
                aR = Avatar.ARM_HOLD;
                break;
            case SLEEP:
                squash = 1f + 0.02f * (float) Math.sin(t * 1.4f);
                break;
            case READ:
                aL = Avatar.ARM_HOLD;
                aR = Avatar.ARM_HOLD;
                break;
            case RAIN:
                aR = Avatar.ARM_UP;
                rot = 1.5f * (float) Math.sin(t * 1.3f);
                break;
            case JACKS: {
                boolean up = (int) (t * 2.6f) % 2 == 0;
                aL = up ? Avatar.ARM_UP : Avatar.ARM_DOWN;
                aR = aL;
                jump = up ? 1.8f : 0f;
                break;
            }
            case PHONE:
                aR = Avatar.ARM_HOLD;
                rot = 1.5f * (float) Math.sin(t * 0.9f);
                break;
            default: {   // CHEER
                boolean up = (int) (t * 5f) % 2 == 0;
                aL = up ? Avatar.ARM_UP : Avatar.ARM_CHEER;
                aR = up ? Avatar.ARM_CHEER : Avatar.ARM_UP;
                jump = 3.2f * (float) Math.abs(Math.sin(t * 7f));
                break;
            }
        }
        int wing = (int) (t * 7f) & 3;
        Bitmap sp = sprite(aL, aR, wing);
        float cx = 22f * s;
        float base = 35f * s;
        float top = 6f * s;
        float left = cx - 19f * s;

        c.save();
        if (scene == SLEEP) {
            c.rotate(-80f, cx, base - 8f * s);
            c.translate(0f, 0f);
        }
        c.translate(shift * s, -jump * s);
        c.rotate(rot, cx, base);
        c.scale(1f + breathe, squash, cx, base);
        p.setAlpha(255);
        p.setStyle(Paint.Style.FILL);
        rf.set(left, top, left + Avatar.W * s, top + Avatar.H * s);
        c.drawBitmap(sp, null, rf, p);
        props(c, t, cx, top);
        c.restore();
        effects(c, t, beat, cx, top, base);
    }

    private float X(float cx, float x) {
        return cx + (x - 8f) * s;
    }

    private float Y(float top, float y) {
        return top + y * s;
    }

    private void box(Canvas c, float cx, float top, float x, float y, float w, float hh, int color) {
        p.setColor(color);
        c.drawRect(X(cx, x), Y(top, y), X(cx, x + w), Y(top, y + hh), p);
    }

    /** Things he holds, drawn with him so they move when he does. */
    private void props(Canvas c, float t, float cx, float top) {
        switch (scene) {
            case COFFEE: {
                float ph = (t % 6f) / 6f;
                float lift = ph > 0.45f && ph < 0.75f ? 2f : 0f;
                float y = 14f - lift;
                box(c, cx, top, 8f, y, 3f, 3f, 0xFFF4F0E8);
                box(c, cx, top, 8f, y, 3f, 1f, 0xFF6A4426);
                box(c, cx, top, 11f, y + 1f, 1f, 1f, 0xFFF4F0E8);
                for (int i = 0; i < 2; i++) {
                    float q = ((t * 0.8f + i * 0.5f) % 1f);
                    p.setColor(((int) (150 * (1f - q)) << 24) | 0xFFFFFF);
                    c.drawRect(X(cx, 8.7f + i), Y(top, y - 1f - q * 4f), X(cx, 9.7f + i), Y(top, y - q * 4f), p);
                }
                break;
            }
            case PHONE: {
                box(c, cx, top, 8f, 13f, 3f, 5f, 0xFF15151C);
                box(c, cx, top, 8.5f, 13.5f, 2f, 3.5f, Theme.ACCENT);
                float sc = (t * 3f) % 3f;
                box(c, cx, top, 8.5f, 13.5f + sc, 2f, 0.5f, 0xFFFFFFFF);
                p.setColor((0x30 << 24) | (Theme.ACCENT & 0xFFFFFF));
                c.drawCircle(X(cx, 7.5f), Y(top, 9f), 6f * s, p);
                break;
            }
            case READ: {
                box(c, cx, top, 4.5f, 15f, 7f, 5f, 0xFF3A2A66);
                box(c, cx, top, 5f, 15.5f, 3f, 4f, 0xFFF4F0E8);
                box(c, cx, top, 8f, 15.5f, 3f, 4f, 0xFFE8E2D6);
                box(c, cx, top, 7.8f, 15f, 0.4f, 5f, 0xFF3A2A66);
                float flip = (t % 4f) / 4f;
                if (flip < 0.25f) {
                    float k = flip / 0.25f;
                    box(c, cx, top, 8f - 3f * k, 15.5f, 3f * k + 0.3f, 4f, 0xFFFFFFFF);
                }
                break;
            }
            case RAIN: {
                p.setColor(0xFF5E4B8B);
                c.drawRect(X(cx, 12.7f), Y(top, 1f), X(cx, 13.3f), Y(top, 9f), p);
                path.reset();
                rf.set(X(cx, 6f), Y(top, -5.5f), X(cx, 19.5f), Y(top, 7.5f));
                path.addArc(rf, 180f, 180f);
                path.close();
                p.setColor(Theme.ACCENT);
                c.drawPath(path, p);
                p.setColor(0x55000000);
                c.drawRect(X(cx, 6f), Y(top, 1f), X(cx, 19.5f), Y(top, 1.7f), p);
                break;
            }
            default:
                break;
        }
    }

    /** Things around him that do not move with his body. */
    private void effects(Canvas c, float t, float beat, float cx, float top, float base) {
        if (scene <= ROBOT || scene == CHEER) {
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            p.setTextSize(5.5f * s);
            for (int i = 0; i < 3; i++) {
                float q = (t * 0.55f + i / 3f) % 1f;
                float x = cx + (i == 0 ? -13f : i == 1 ? 12f : 15f) * s + 2f * s * (float) Math.sin(q * 6f + i);
                float y = base - 10f * s - q * 20f * s;
                p.setColor(((int) (210 * (1f - q)) << 24) | (Theme.ACCENT & 0xFFFFFF));
                c.drawText(i == 1 ? "♫" : "♪", x, y, p);
            }
        }
        if (scene == CHEER) {
            long left = cheerUntil - System.currentTimeMillis();
            float age = Math.max(0f, (2600 - left) / 1000f);
            int[] cols = {0xFFFFD35A, 0xFFFF6B9A, 0xFF6BE3FF, 0xFFA6FF6B, 0xFFB39DFF};
            for (int i = 0; i < 18; i++) {
                float ang = i * 0.7f + 0.3f;
                float v = 6f + (i % 5) * 2f;
                float x = cx + (float) Math.cos(ang) * v * age * s * 1.6f;
                float y = top + 8f * s + (float) Math.sin(ang) * v * age * s * 1.2f + 4f * age * age * s;
                p.setColor(cols[i % cols.length]);
                c.drawRect(x, y, x + s, y + s, p);
            }
        }
        if (scene == SLEEP) {
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            for (int i = 0; i < 3; i++) {
                float q = (t * 0.35f + i / 3f) % 1f;
                p.setTextSize((3.5f + 2.2f * q) * s);
                p.setColor(((int) (230 * (1f - q)) << 24) | 0xC8D0FF);
                c.drawText("z", cx - 14f * s - q * 3f * s, base - 15f * s - q * 14f * s, p);
            }
        }
        if (scene == RAIN) {
            p.setColor(0x995AA0FF);
            for (int i = 0; i < 14; i++) {
                float q = (t * 1.6f + i * 0.37f) % 1f;
                float x = (i * 3.1f % 44f) * s;
                float y = q * 36f * s;
                // not under the umbrella
                float dx = x - X(cx, 12.7f);
                float dy = y - Y(top, 1f);
                if (dy < 7f * s && Math.abs(dx) < 8f * s) {
                    continue;
                }
                c.drawRect(x, y, x + Math.max(1f, s * 0.5f), y + 2.5f * s, p);
            }
        }
        if (scene == JACKS) {
            p.setColor(0x33FFFFFF);
            c.drawRect(cx - 10f * s, base, cx + 10f * s, base + 0.6f * s, p);
        }
    }

    /** Page swipes move him together with the castle. */
    void follow(float translationX, float alpha) {
        setTranslationX(translationX);
        setAlpha(alpha);
    }
}
