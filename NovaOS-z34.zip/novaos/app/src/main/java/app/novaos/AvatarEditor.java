package app.novaos;

import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** "My character": pick how your pixel figure looks and buy cosmetics with coins. */
final class AvatarEditor extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout body;
    private final List<View> pending = new ArrayList<>();
    private String note = "";

    /** One row of choices. index into Avatar.look(), what it is called, names, prices and optional swatch colours. */
    private static final class Cat {
        final String title;
        final int slot;
        final String kind;
        final String[] names;
        final int[] cost;
        final int[] colors;

        Cat(String title, int slot, String kind, String[] names, int[] cost, int[] colors) {
            this.title = title;
            this.slot = slot;
            this.kind = kind;
            this.names = names;
            this.cost = cost;
            this.colors = colors;
        }
    }

    private static final int[] FREE6 = new int[6];
    private static final int[] FREE5 = new int[6];
    private static final String[] EDITION_NAMES = new String[Zigzag.NAMES.length + 1];
    private static final int[] SHIELD_PRICES = new int[Zigzag.NAMES.length + 1];
    private static final int[] WINGS_PRICES = new int[Zigzag.NAMES.length + 1];
    private static final int[] CAPE_PRICES = new int[Zigzag.NAMES.length + 1];

    static {
        EDITION_NAMES[0] = "None";
        for (int i = 0; i < Zigzag.NAMES.length; i++) {
            EDITION_NAMES[i + 1] = Zigzag.NAMES[i];
            SHIELD_PRICES[i + 1] = Zigzag.SHIELD_COST[i];
            WINGS_PRICES[i + 1] = Zigzag.WINGS_COST[i];
            CAPE_PRICES[i + 1] = Zigzag.CAPE_COST[i];
        }
    }

    private static final Cat[] CATS = {
        new Cat("SKIN", 0, "avskin", Avatar.SKIN_NAMES, FREE6, Avatar.SKIN),
        new Cat("EYES", 10, "aveyes", Avatar.EYE_NAMES, FREE6, Avatar.EYES),
        new Cat("HAIR STYLE", 1, "avhair", Avatar.HAIR_STYLES, Avatar.HAIR_STYLE_COST, null),
        new Cat("HAIR COLOUR", 2, "avhairc", Avatar.HAIR_COLOR_NAMES, Avatar.HAIR_COLOR_COST, Avatar.HAIR_COLOR),
        new Cat("TOP", 3, "avshirt", Avatar.SHIRTS, Avatar.SHIRT_COST, null),
        new Cat("TOP COLOUR", 4, "avshirtc", Avatar.SHIRT_COLOR_NAMES, Avatar.SHIRT_COLOR_COST, Avatar.SHIRT_COLOR),
        new Cat("BOTTOMS", 5, "avpants", Avatar.PANTS_NAMES, FREE5, null),
        new Cat("HAT", 6, "avhat", Avatar.HATS, Avatar.HAT_COST, null),
        new Cat("FACE & NECK", 7, "avface", Avatar.FACE, Avatar.FACE_COST, null),
        new Cat("BACK", 8, "avback", Avatar.BACK, Avatar.BACK_COST, null),
        new Cat("SHOES", 9, "avshoes", Avatar.SHOES, Avatar.SHOES_COST, null),
        new Cat("ZIGZAG SHIELD", 11, "zzshield", EDITION_NAMES, SHIELD_PRICES, null),
        new Cat("ZIGZAG WINGS", 12, "zzwings", EDITION_NAMES, WINGS_PRICES, null),
        new Cat("ZIGZAG CAPE", 13, "zzcape", EDITION_NAMES, CAPE_PRICES, null)};

    private AvatarEditor(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(host);
        body.setOrientation(LinearLayout.VERTICAL);
        int pad = Theme.dp(host, 18);
        body.setPadding(pad, Theme.dp(host, 40), pad, Theme.dp(host, 60));
        sv.addView(body);
        addView(sv, new LayoutParams(-1, -1));
        build();
    }

    static void open(NovaActivity host) {
        host.showOverlay(new AvatarEditor(host));
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    /** A crisp enlarged bitmap of the figure, for the home panel and the shop. */
    static Bitmap bitmap(int zoom) {
        Bitmap b = Bitmap.createBitmap(Avatar.render(), Avatar.W, Avatar.H, Bitmap.Config.ARGB_8888);
        return Bitmap.createScaledBitmap(b, Avatar.W * zoom, Avatar.H * zoom, false);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private boolean owned(Cat c, int i) {
        return c.cost[i] == 0 || Castle.owns(c.kind, i) || Castle.admin();
    }

    private void flush() {
        LinearLayout row = null;
        int used = 0;
        int max = host.getResources().getDisplayMetrics().widthPixels - Theme.dp(host, 36);
        for (View c : pending) {
            c.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
            int w = c.getMeasuredWidth() + Theme.dp(host, 8);
            if (row == null || used + w > max) {
                row = new LinearLayout(host);
                row.setPadding(0, 0, 0, Theme.dp(host, 6));
                body.addView(row);
                used = 0;
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Theme.dp(host, 6);
            row.addView(c, lp);
            used += w;
        }
        pending.clear();
    }

    private TextView button(String s, boolean main, Runnable r) {
        TextView t = text(s, 11f, main ? Theme.BG : Theme.TEXT);
        t.setBackground(Theme.rounded(main ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
        t.setPadding(Theme.dp(host, 11), Theme.dp(host, 8), Theme.dp(host, 11), Theme.dp(host, 8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void choose(Cat c, int i) {
        if (!owned(c, i)) {
            if (!Shop.pay(host, c.cost[i])) {
                return;
            }
            Prefs.putInt("own_" + c.kind + i, 1);
            Sfx.play(Sfx.COIN);
            note = "Bought: " + c.names[i] + ". Looking good!";
        } else {
            note = "";
        }
        Prefs.putInt(Avatar.KEYS[c.slot], i);
        build();
    }

    private void surprise() {
        Random r = new Random();
        for (Cat c : CATS) {
            List<Integer> ok = new ArrayList<>();
            for (int i = 0; i < c.names.length; i++) {
                if (owned(c, i)) {
                    ok.add(i);
                }
            }
            Prefs.putInt(Avatar.KEYS[c.slot], ok.get(r.nextInt(ok.size())));
        }
        note = "A fresh look, from what you own.";
        build();
    }

    private void build() {
        body.removeAllViews();
        TextView title = text("MY CHARACTER", 16f, Theme.TEXT);
        title.setLetterSpacing(0.2f);
        body.addView(title);
        body.addView(text("Coins " + Coins.get() + (Castle.admin() ? "   ADMIN: everything is free" : ""), 11f, Theme.DIM));

        AvatarView iv = new AvatarView(host, Math.max(3, Math.round(host.getResources().getDisplayMetrics().density * 2.8f)));
        iv.setBackground(Theme.rounded(0x22FFFFFF, 18f, host));
        iv.setPadding(Theme.dp(host, 24), Theme.dp(host, 14), Theme.dp(host, 24), Theme.dp(host, 14));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-2, -2);
        ip.gravity = Gravity.CENTER_HORIZONTAL;
        ip.topMargin = Theme.dp(host, 14);
        body.addView(iv, ip);

        if (!note.isEmpty()) {
            TextView n = text(note, 12f, Theme.TEXT);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, Theme.dp(host, 10), 0, 0);
            body.addView(n);
        }
        pending.add(button("SURPRISE ME", true, this::surprise));
        flush();

        for (final Cat c : CATS) {
            TextView h = text(c.title, 11f, Theme.ACCENT);
            h.setLetterSpacing(0.15f);
            h.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 6));
            body.addView(h);
            int cur = Avatar.look()[c.slot];
            for (int i = 0; i < c.names.length; i++) {
                final int idx = i;
                boolean own = owned(c, i);
                boolean sel = cur == i;
                TextView chip;
                if (c.colors != null) {
                    int rgb = 0xFF000000 | c.colors[i];
                    int lum = (((rgb >> 16) & 255) * 3 + ((rgb >> 8) & 255) * 6 + (rgb & 255)) / 10;
                    int ink = lum > 140 ? 0xFF14141C : 0xFFFFFFFF;
                    chip = text(sel ? "✓" : own ? " " : String.valueOf(c.cost[i]), 11f, ink);
                    chip.setBackground(Theme.rounded(rgb, 12f, host));
                    chip.setGravity(Gravity.CENTER);
                    chip.setMinWidth(Theme.dp(host, 40));
                    chip.setPadding(Theme.dp(host, 8), Theme.dp(host, 8), Theme.dp(host, 8), Theme.dp(host, 8));
                    if (sel) {
                        chip.setBackground(Theme.rounded(rgb, 12f, host));
                        chip.setTypeface(Theme.MONO, android.graphics.Typeface.BOLD);
                    }
                    chip.setClickable(true);
                    chip.setOnClickListener(v -> choose(c, idx));
                } else {
                    chip = button(c.names[i] + (own ? "" : " " + c.cost[i]), sel, () -> choose(c, idx));
                }
                pending.add(chip);
            }
            flush();
        }
        body.addView(text("\nTip: the mystery chest and the coin shop have more ways to spend coins.", 10f, Theme.DIM));
    }
}
