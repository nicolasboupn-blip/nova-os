package app.novaos;

import android.os.Build;
import android.os.SystemClock;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** A command line for your phone. Type an app name to open it, or try "neofetch". */
final class TerminalScreen extends LinearLayout {
    private static final String HELP =
            "help       this list\n"
            + "neofetch   system info\n"
            + "apps       list installed apps\n"
            + "open <x>   open an app (or just type its name)\n"
            + "notes      open notes\n"
            + "lock       lock screen\n"
            + "home       back to home\n"
            + "android    open Android's home app setting\n"
            + "time       current time\n"
            + "battery    battery level\n"
            + "clear      clear the screen\n";

    private final NovaActivity host;
    private final ScrollView scroll;
    private final TextView out;
    private final EditText input;

    TerminalScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 16);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        out = new TextView(host);
        out.setTypeface(Theme.MONO);
        out.setTextSize(12.5f);
        out.setTextColor(Theme.TEXT);
        out.setLineSpacing(0f, 1.15f);

        scroll = new ScrollView(host);
        scroll.addView(out);
        addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(host);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        row.setPadding(Theme.dp(host, 14), 0, Theme.dp(host, 8), 0);

        TextView prompt = new TextView(host);
        prompt.setText("$");
        prompt.setTypeface(Theme.MONO);
        prompt.setTextSize(15f);
        prompt.setTextColor(Theme.ACCENT);
        prompt.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.addView(prompt, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));

        input = new EditText(host);
        input.setTypeface(Theme.MONO);
        input.setTextSize(14f);
        input.setTextColor(Theme.TEXT);
        input.setHint("type a command");
        input.setHintTextColor(Theme.DIM);
        input.setBackground(null);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setPadding(Theme.dp(host, 10), Theme.dp(host, 14), Theme.dp(host, 10), Theme.dp(host, 14));
        row.addView(input, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Theme.dp(host, 10);
        addView(row, rlp);

        print(Theme.OS_NAME + " terminal. type 'help' for commands.\n\n");

        input.setOnEditorActionListener((v, actionId, ev) -> {
            boolean enter = ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && ev.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_DONE || enter) {
                String line = input.getText().toString();
                input.setText("");
                run(line);
                return true;
            }
            return false;
        });

        input.requestFocus();
        postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager)
                    host.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showSoftInput(input, 0);
            }
        }, 250);
    }

    private void print(String s) {
        out.append(s);
        scroll.post(() -> scroll.fullScroll(FOCUS_DOWN));
    }

    private void run(String line) {
        String cmd = line.trim();
        print("$ " + cmd + "\n");
        if (cmd.isEmpty()) {
            return;
        }
        String[] parts = cmd.split("\\s+", 2);
        String name = parts[0].toLowerCase(Locale.ROOT);
        String arg = parts.length > 1 ? parts[1] : "";

        switch (name) {
            case "help":
                print(HELP + "\n");
                break;
            case "clear":
                out.setText("");
                break;
            case "neofetch":
            case "info":
                print(fetch() + "\n");
                break;
            case "apps": {
                StringBuilder sb = new StringBuilder();
                for (AppEntry e : host.repo.all) {
                    sb.append(e.label).append("\n");
                }
                print(sb.append("\n").toString());
                break;
            }
            case "open":
                openApp(arg);
                break;
            case "notes":
                host.showNotes();
                break;
            case "lock":
                host.showLock();
                break;
            case "home":
            case "exit":
                host.showHome();
                break;
            case "android":
                print("opening Android's home app setting...\n\n");
                host.openHomeSettings();
                break;
            case "time":
                print(new SimpleDateFormat("EEEE d MMMM yyyy, HH:mm:ss", Locale.getDefault())
                        .format(new Date()) + "\n\n");
                break;
            case "battery": {
                int l = host.batteryLevel();
                print((l < 0 ? "unknown" : l + "%" + (host.charging() ? " (charging)" : "")) + "\n\n");
                break;
            }
            case "whoami":
                print("you\n\n");
                break;
            case "sudo":
                print("nice try.\n\n");
                break;
            case "echo":
                print(arg + "\n\n");
                break;
            default:
                openApp(cmd);
                break;
        }
    }

    private void openApp(String query) {
        if (query.isEmpty()) {
            print("usage: open <app name>\n\n");
            return;
        }
        List<AppEntry> r = host.repo.search(query);
        if (r.isEmpty()) {
            print("not found: " + query + "  (type help)\n\n");
            return;
        }
        print("opening " + r.get(0).label + "\n\n");
        host.launch(r.get(0));
    }

    private String fetch() {
        long sec = SystemClock.elapsedRealtime() / 1000L;
        String up = (sec / 3600) + "h " + ((sec % 3600) / 60) + "m";
        int bat = host.batteryLevel();
        android.util.DisplayMetrics dm = host.getResources().getDisplayMetrics();
        String kernel = System.getProperty("os.version");

        String[] art = {
            "    *     ",
            "  . ' .   ",
            " - NOVA - ",
            "  ' . '   ",
            "    *     ",
            "          ",
            "          ",
            "          ",
            "          "
        };
        String[] info = {
            "nova@" + Build.MODEL.toLowerCase(Locale.ROOT).replace(' ', '-'),
            "----------------",
            "OS      " + Theme.OS_NAME + " " + Theme.OS_VERSION + " on Android " + Build.VERSION.RELEASE,
            "Host    " + Build.MANUFACTURER + " " + Build.MODEL,
            "Kernel  " + (kernel == null ? "linux" : kernel),
            "Uptime  " + up,
            "Apps    " + host.repo.all.size(),
            "Screen  " + dm.widthPixels + "x" + dm.heightPixels,
            "Battery " + (bat < 0 ? "unknown" : bat + "%")
        };
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < info.length; i++) {
            sb.append(art[i]).append("  ").append(info[i]).append("\n");
        }
        return sb.toString();
    }
}
