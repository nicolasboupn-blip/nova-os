package app.novaos;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** All installed apps with search. Tap to open, long-press for pin / info / uninstall. */
final class DrawerScreen extends LinearLayout {
    private static final class Holder {
        ImageView icon;
        TextView label;
    }

    private final NovaActivity host;
    private final List<AppEntry> shown = new ArrayList<>();
    private final BaseAdapter adapter;

    DrawerScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 16);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 8));

        host.repo.ensureFresh();
        shown.addAll(host.repo.all);

        TextView title = new TextView(host);
        title.setText("APPS · " + host.repo.all.size());
        title.setTypeface(Theme.MONO);
        title.setTextSize(12f);
        title.setLetterSpacing(0.3f);
        title.setTextColor(Theme.ACCENT);
        title.setPadding(Theme.dp(host, 8), 0, 0, 0);
        addView(title);

        final EditText search = new EditText(host);
        search.setHint("search apps");
        search.setHintTextColor(Theme.DIM);
        search.setTextColor(Theme.TEXT);
        search.setTextSize(15f);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setImeOptions(EditorInfo.IME_ACTION_GO);
        search.setBackground(Theme.rounded(Theme.PANEL, 16f, host));
        search.setPadding(Theme.dp(host, 16), Theme.dp(host, 12), Theme.dp(host, 16), Theme.dp(host, 12));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Theme.dp(host, 12);
        addView(search, slp);

        GridView grid = new GridView(host);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(Theme.dp(host, 8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(0, 0, 0, Theme.dp(host, 24));
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        glp.topMargin = Theme.dp(host, 12);
        addView(grid, glp);

        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int i) {
                return shown.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                Holder h;
                View v = convert;
                if (v == null) {
                    LinearLayout c = new LinearLayout(host);
                    c.setOrientation(LinearLayout.VERTICAL);
                    c.setGravity(Gravity.CENTER_HORIZONTAL);
                    c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));
                    h = new Holder();
                    h.icon = new ImageView(host);
                    c.addView(h.icon, new LinearLayout.LayoutParams(Theme.dp(host, 52), Theme.dp(host, 52)));
                    h.label = new TextView(host);
                    h.label.setTextSize(11f);
                    h.label.setTextColor(Theme.TEXT);
                    h.label.setSingleLine(true);
                    h.label.setEllipsize(TextUtils.TruncateAt.END);
                    h.label.setGravity(Gravity.CENTER);
                    LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    tlp.topMargin = Theme.dp(host, 6);
                    c.addView(h.label, tlp);
                    c.setTag(h);
                    v = c;
                } else {
                    h = (Holder) v.getTag();
                }
                AppEntry e = shown.get(i);
                h.icon.setImageDrawable(Theme.tint(e.icon));
                h.label.setText(e.label);
                return v;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> host.launch(shown.get(pos)));
        grid.setOnItemLongClickListener((p, v, pos, id) -> {
            host.appMenu(shown.get(pos));
            return true;
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        search.setOnEditorActionListener((v, actionId, ev) -> {
            if (!shown.isEmpty()) {
                host.launch(shown.get(0));
            }
            return true;
        });
    }

    private void filter(String q) {
        shown.clear();
        shown.addAll(host.repo.search(q));
        adapter.notifyDataSetChanged();
    }
}
