package app.novaos;

import android.content.Context;
import android.content.SharedPreferences;

/** Every setting NOVA has. Read it anywhere, change it from the Settings screen. */
final class Prefs {
    static final String K_ACCENT = "s_accent";
    static final String K_GLOW_CLOCK = "s_glow_clock";
    static final String K_GLOW_EDGES = "s_glow_edges";
    static final String K_BATTERY = "s_battery";
    static final String K_CODE_WALL = "s_code_wall";
    static final String K_WALL_TEXT = "s_wall_text";
    static final String K_BOOT_UNLOCK = "s_boot_unlock";
    static final String K_BEEP = "s_beep";
    static final String K_GREETING = "s_greeting";
    static final String K_UNLOCKS = "s_unlocks";

    private static SharedPreferences sp;

    private Prefs() {}

    static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("nova", Context.MODE_PRIVATE);
        }
    }

    static int accent() {
        return sp.getInt(K_ACCENT, 0);
    }

    static boolean glowClock() {
        return sp.getBoolean(K_GLOW_CLOCK, true);
    }

    static boolean glowEdges() {
        return sp.getBoolean(K_GLOW_EDGES, true);
    }

    static boolean battery() {
        return sp.getBoolean(K_BATTERY, true);
    }

    static boolean codeWall() {
        return sp.getBoolean(K_CODE_WALL, true);
    }

    static boolean bootOnUnlock() {
        return sp.getBoolean(K_BOOT_UNLOCK, true);
    }

    static boolean beep() {
        return sp.getBoolean(K_BEEP, false);
    }

    static String wallText() {
        return sp.getString(K_WALL_TEXT, "");
    }

    static String greeting() {
        String g = sp.getString(K_GREETING, "welcome back.");
        return g.trim().isEmpty() ? "welcome back." : g.trim();
    }

    static int unlocks() {
        return sp.getInt(K_UNLOCKS, 0);
    }

    static void incUnlocks() {
        sp.edit().putInt(K_UNLOCKS, unlocks() + 1).apply();
    }

    static void putBool(String key, boolean v) {
        sp.edit().putBoolean(key, v).apply();
    }

    static void putInt(String key, int v) {
        sp.edit().putInt(key, v).apply();
    }

    static void putString(String key, String v) {
        sp.edit().putString(key, v).apply();
    }

    /** Puts every setting back to its default. The unlock counter is kept. */
    static void reset() {
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) {
            if (k.startsWith("s_") && !k.equals(K_UNLOCKS)) {
                e.remove(k);
            }
        }
        e.apply();
    }
}
