package app.novaos;

import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Startup log. Full version after a restart, a quick one every time you unlock. Tap to skip. */
final class BootScreen extends FrameLayout {
    private final NovaActivity host;
    private final boolean quick;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView log;
    private final TextView mark;
    private final android.animation.ValueAnimator markGlow;
    private String[] lines;
    private int index = 0;
    private boolean done = false;

    private final Runnable step = new Runnable() {
        @Override
        public void run() {
            if (done) {
                return;
            }
            if (index < lines.length) {
                log.append(lines[index++] + "\n");
                handler.postDelayed(this, quick ? 70 : 150);
            } else {
                complete();
            }
        }
    };

    BootScreen(NovaActivity host, boolean quick) {
        super(host);
        this.host = host;
        this.quick = quick;
        setBackgroundColor(Color.BLACK);

        log = new TextView(host);
        log.setTypeface(Theme.MONO);
        log.setTextSize(12f);
        log.setTextColor(Theme.DIM);
        log.setLineSpacing(0f, 1.2f);
        log.setPadding(Theme.dp(host, 24), Theme.dp(host, 64), Theme.dp(host, 24), 0);
        addView(log, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        mark = new TextView(host);
        mark.setText(Theme.OS_NAME);
        mark.setTextSize(40f);
        mark.setTypeface(Theme.DIGITAL);
        mark.setLetterSpacing(0.5f);
        mark.setTextColor(Theme.TEXT);
        mark.setAlpha(0f);
        markGlow = Theme.glow(mark);
        addView(mark, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        String kernel = System.getProperty("os.version");
        if (quick) {
            lines = new String[] {
                "unlocking " + Theme.OS_NAME,
                "[  ok  ] session restored",
                "[  ok  ] loading " + host.repo.all.size() + " apps",
                "[  ok  ] home ready",
                "",
                Prefs.greeting()
            };
        } else {
            lines = new String[] {
                Theme.OS_NAME + " " + Theme.OS_VERSION,
                "",
                "[  ok  ] kernel " + (kernel == null ? "linux" : kernel),
                "[  ok  ] hardware " + Build.MANUFACTURER + " " + Build.MODEL,
                "[  ok  ] android " + Build.VERSION.RELEASE + " (api " + Build.VERSION.SDK_INT + ")",
                "[  ok  ] mounting /data",
                "[  ok  ] starting display",
                "[  ok  ] indexing " + host.repo.all.size() + " apps",
                "[  ok  ] hiding stock launcher",
                "",
                "welcome."
            };
        }

        setOnClickListener(v -> complete());
        handler.postDelayed(step, quick ? 120 : 300);
    }

    private void complete() {
        if (done) {
            return;
        }
        done = true;
        handler.removeCallbacksAndMessages(null);
        mark.animate().alpha(1f).setDuration(quick ? 200 : 500).start();
        handler.postDelayed(() -> {
            if (quick) {
                host.showHome();
            } else {
                host.showLock();
            }
        }, quick ? 350 : 1000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        markGlow.cancel();
        super.onDetachedFromWindow();
    }
}
