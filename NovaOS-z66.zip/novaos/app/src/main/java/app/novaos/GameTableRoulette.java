package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Roulette for friends, pass the phone. Everyone starts the table with 1000 coins (your real coins are not touched).
 * Each turn one player places bets, locks them in and passes the phone on. When everyone has bet the wheel spins
 * once, every player is paid, then the next round starts. Same payouts as the solo roulette: straight 40 to 1,
 * dozens and columns 2 to 1, even chances 1 to 1, zero beats the outside bets. Players with no coins left sit out.
 */
final class GameTableRoulette extends Game {
    private static final int START = 1000;
    private static final int[] CHIPS = {10, 50, 100, 250};
    private static final int DOZEN = 37, COLUMN = 40, LOW = 43, EVEN = 44, RED = 45, BLACK = 46, ODD = 47, HIGH = 48;
    private static final int RED_C = 0xFFC4243F, BLACK_C = 0xFF1A1526;
    private static final Set<Integer> REDS = new HashSet<>(Arrays.asList(
            1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36));
    private static final int SETUP = 0, PLAY = 1, WAIT_SPIN = 2, ROLL = 3, RESULTS = 4, OVER = 5;

    private final Random rnd = new Random();
    private final RouletteWheel wheel;
    private final Table table;
    private final TextView header, stacks, message, lockBtn, undoBtn, clearBtn;
    private final TextView coverTitle, coverBody, nextBtn, startBtn;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final LinearLayout guestList;
    private final EditText nameField;
    private final TextView setupMsg;
    /** Indexes into Guests.all() of the players sitting at the table, in seat order. */
    private List<Integer> selected = new ArrayList<>();
    private String[] names = {"P1", "P2"};
    private final LinearLayout cover, setupGroup, resultGroup;
    private final List<Map<Integer, Integer>> locked = new ArrayList<>();
    private final List<int[]> undo = new ArrayList<>(); // {id, amount} for the current player
    private Map<Integer, Integer> cur = new LinkedHashMap<>();
    private Runnable coverAction;
    private final TextView passBtn;
    private long shownAt;
    private int players = 2;
    private int[] stack = {START, START};
    private int phase = SETUP;
    private int turn;
    private int round = 1;
    private int chip = 1;

    GameTableRoulette(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(58), dp(10), dp(12));
        ScrollView sv = new ScrollView(host);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        header = label("FRIENDS TABLE", 12f, Theme.DIM);
        header.setLetterSpacing(0.1f);
        col.addView(header, wrapMatch());
        stacks = label("", 11f, Theme.TEXT);
        stacks.setTypeface(Theme.MONO);
        col.addView(stacks, wrapMatch());

        wheel = new RouletteWheel(host);
        int side = Math.min(host.getResources().getDisplayMetrics().widthPixels - dp(20), dp(260));
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, side);
        col.addView(wheel, wp);

        message = label("", 13f, Theme.DIM);
        message.setLetterSpacing(0.08f);
        message.setGravity(Gravity.CENTER);
        col.addView(message, wrapMatch());

        table = new Table(host);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        col.addView(table, tp);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(Upgrades.chipName(CHIPS[i]), CHIPS[i] >= 1000 ? 10f : 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                chip = idx;
                styleChips();
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            cp.setMargins(dp(1), 0, dp(1), 0);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = wrapMatch();
        chp.topMargin = dp(10);
        col.addView(chips, chp);

        LinearLayout buttons = new LinearLayout(host);
        buttons.setGravity(Gravity.CENTER);
        undoBtn = button("UNDO", this::undoBet);
        clearBtn = button("CLEAR", this::clearBets);
        lockBtn = button("LOCK IN", this::lockIn);
        lockBtn.setTextColor(Theme.BG);
        lockBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        buttons.addView(smallCell(undoBtn, 1f, 0));
        buttons.addView(smallCell(clearBtn, 1f, 3));
        buttons.addView(smallCell(lockBtn, 1.4f, 3));
        LinearLayout.LayoutParams bp = wrapMatch();
        bp.topMargin = dp(10);
        col.addView(buttons, bp);

        // the cover: pass-the-phone screens, the setup and the results. Tapping it runs the cover action.
        cover = new LinearLayout(host);
        cover.setOrientation(LinearLayout.VERTICAL);
        cover.setGravity(Gravity.CENTER);
        cover.setPadding(dp(24), dp(58), dp(24), dp(24));
        cover.setBackgroundColor(0xF2000000 | (Theme.BG & 0xFFFFFF));
        cover.setClickable(true);
        // the NEXT PLAYER button sits at the top of the cover, far from LOCK IN, and ignores taps for a moment
        passBtn = button("NEXT PLAYER", this::passTap);
        passBtn.setTextColor(Theme.BG);
        passBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        passBtn.setTextSize(15f);
        passBtn.setPadding(dp(18), dp(16), dp(18), dp(16));
        cover.addView(passBtn, wrapMatch());
        coverTitle = label("", 20f, Theme.ACCENT);
        coverTitle.setLetterSpacing(0.08f);
        coverTitle.setGravity(Gravity.CENTER);
        coverBody = label("", 14f, Theme.TEXT);
        coverBody.setGravity(Gravity.CENTER);
        cover.addView(coverTitle, wrapMatch());
        cover.addView(coverBody, wrapMatch());

        setupGroup = new LinearLayout(host);
        setupGroup.setOrientation(LinearLayout.VERTICAL);
        guestList = new LinearLayout(host);
        guestList.setOrientation(LinearLayout.VERTICAL);
        android.widget.ScrollView gs = new android.widget.ScrollView(host);
        gs.setVerticalScrollBarEnabled(false);
        gs.addView(guestList, wrapMatch());
        setupGroup.addView(gs, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220)));
        LinearLayout addRow = new LinearLayout(host);
        addRow.setGravity(Gravity.CENTER_VERTICAL);
        nameField = new EditText(host);
        nameField.setHint("new guest name");
        nameField.setSingleLine(true);
        nameField.setTextColor(Theme.TEXT);
        nameField.setHintTextColor(Theme.DIM);
        nameField.setTypeface(Theme.MONO);
        nameField.setTextSize(13f);
        nameField.setFilters(new android.text.InputFilter[] {new android.text.InputFilter.LengthFilter(14)});
        addRow.addView(nameField, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        addRow.addView(button("ADD", this::addGuest), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams arp = wrapMatch();
        arp.topMargin = dp(8);
        setupGroup.addView(addRow, arp);
        setupMsg = label("", 11f, Theme.DIM);
        setupGroup.addView(setupMsg, wrapMatch());
        startBtn = button("START", this::start);
        startBtn.setTextColor(Theme.BG);
        startBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams sbp = wrapMatch();
        sbp.topMargin = dp(12);
        setupGroup.addView(startBtn, sbp);
        cover.addView(setupGroup, wrapMatch());

        resultGroup = new LinearLayout(host);
        resultGroup.setGravity(Gravity.CENTER);
        nextBtn = button("NEXT ROUND", this::nextRound);
        nextBtn.setTextColor(Theme.BG);
        nextBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        resultGroup.addView(nextBtn, weightCell());
        resultGroup.addView(button("END GAME", this::finishGame), weightCell());
        LinearLayout.LayoutParams rgp = wrapMatch();
        rgp.topMargin = dp(16);
        cover.addView(resultGroup, rgp);

        addView(cover, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        styleChips();
        rebuildGuests();
        showCover("FRIENDS TABLE",
                "pass-the-phone roulette\nevery guest keeps their coins\n\npick 2 to 4 players",
                true, false, null);
        refresh();
    }

    @Override
    String title() {
        return "FRIENDS TABLE";
    }

    private LinearLayout.LayoutParams wrapMatch() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weightCell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private View smallCell(TextView b, float weight, int leftMargin) {
        b.setTextSize(11f);
        b.setPadding(dp(6), dp(12), dp(6), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
        lp.setMargins(dp(leftMargin), 0, 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private String startLabel() {
        if (phase == OVER) {
            return "PLAY AGAIN";
        }
        return selected.size() < 2 ? "START (PICK 2 TO 4)" : "START · " + selected.size() + " PLAYERS";
    }

    private void rebuildGuests() {
        guestList.removeAllViews();
        List<Guests.Guest> all = Guests.all();
        if (all.isEmpty()) {
            guestList.addView(label("no guests yet, add one below", 12f, Theme.DIM), wrapMatch());
        }
        for (int i = 0; i < all.size(); i++) {
            final int idx = i;
            Guests.Guest g = all.get(i);
            boolean on = selected.contains(idx);
            String info = g.coins < CHIPS[0] ? "broke, refills to " + Guests.START : g.coins + " coins";
            TextView row = label(g.name + "   ·   " + info, 13f, on ? Theme.BG : Theme.TEXT);
            row.setTypeface(Theme.MONO);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
            row.setClickable(true);
            row.setOnClickListener(v -> toggle(idx));
            row.setOnLongClickListener(v -> {
                removeGuest(idx);
                return true;
            });
            LinearLayout.LayoutParams lp = wrapMatch();
            lp.bottomMargin = dp(4);
            guestList.addView(row, lp);
        }
        startBtn.setText(startLabel());
    }

    private void toggle(int idx) {
        if (selected.contains(idx)) {
            selected.remove(Integer.valueOf(idx));
        } else if (selected.size() < 4) {
            selected.add(idx);
        } else {
            setupMsg.setText("4 players max at one table");
            return;
        }
        setupMsg.setText("");
        rebuildGuests();
    }

    private void addGuest() {
        String n = Guests.clean(nameField.getText().toString());
        if (n.isEmpty()) {
            setupMsg.setText("type a name first");
            return;
        }
        List<Guests.Guest> all = Guests.all();
        if (all.size() >= Guests.MAX) {
            setupMsg.setText("guest list is full (" + Guests.MAX + ")");
            return;
        }
        all.add(new Guests.Guest(n, Guests.START));
        Guests.save(all);
        if (selected.size() < 4) {
            selected.add(all.size() - 1);
        }
        nameField.setText("");
        setupMsg.setText("added " + n);
        rebuildGuests();
    }

    /** Long-press a guest to delete them. Only changes the list, never a game in progress. */
    private void removeGuest(int idx) {
        List<Guests.Guest> all = Guests.all();
        if (idx < 0 || idx >= all.size()) {
            return;
        }
        String n = all.get(idx).name;
        all.remove(idx);
        Guests.save(all);
        List<Integer> next = new ArrayList<>();
        for (int s : selected) {
            if (s != idx) {
                next.add(s > idx ? s - 1 : s);
            }
        }
        selected = next;
        setupMsg.setText("removed " + n);
        rebuildGuests();
    }

    /** Writes every seated player's current coins back to their guest profile. */
    private void saveSeats() {
        List<Guests.Guest> all = Guests.all();
        for (int i = 0; i < players && i < selected.size(); i++) {
            int g = selected.get(i);
            if (g < all.size()) {
                all.get(g).coins = stack[i];
            }
        }
        Guests.save(all);
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            chipViews[i].setBackground(circle(on ? Theme.ACCENT : 0x33FFFFFF));
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    private GradientDrawable circle(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private void showCover(String title, String body, boolean setup, boolean results, Runnable tap) {
        coverTitle.setText(title);
        coverBody.setText(body);
        setupGroup.setVisibility(setup ? VISIBLE : GONE);
        resultGroup.setVisibility(results ? VISIBLE : GONE);
        coverAction = tap;
        passBtn.setVisibility(tap != null ? VISIBLE : GONE);
        shownAt = System.currentTimeMillis();
        cover.setVisibility(VISIBLE);
    }

    private void passTap() {
        if (coverAction == null || System.currentTimeMillis() - shownAt < 700) {
            return;
        }
        coverAction.run();
    }

    private void hideCover() {
        cover.setVisibility(GONE);
        coverAction = null;
    }

    private void say(String s, int color) {
        message.setText(s);
        message.setTextColor(color);
    }

    private int total() {
        int t = 0;
        for (int v : cur.values()) {
            t += v;
        }
        return t;
    }

    private int aliveCount() {
        int n = 0;
        for (int s : stack) {
            if (s >= CHIPS[0]) {
                n++;
            }
        }
        return n;
    }

    private void refresh() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < players; i++) {
            if (i > 0) {
                sb.append("   ");
            }
            int shown = phase == PLAY && i == turn ? stack[i] - total() : stack[i];
            sb.append(names[i]).append(" ").append(shown);
        }
        stacks.setText(sb.toString());
        float a = phase == PLAY ? 1f : 0.4f;
        undoBtn.setAlpha(a);
        clearBtn.setAlpha(a);
        lockBtn.setAlpha(a);
        table.invalidate();
    }

    // ------------------------------------------------------------------ turns

    private void start() {
        if (selected.size() < 2) {
            setupMsg.setText("pick 2 to 4 players first");
            return;
        }
        List<Guests.Guest> all = Guests.all();
        players = selected.size();
        stack = new int[players];
        names = new String[players];
        for (int i = 0; i < players; i++) {
            Guests.Guest g = all.get(selected.get(i));
            names[i] = g.name;
            stack[i] = g.coins < CHIPS[0] ? Guests.START : g.coins;
        }
        saveSeats();
        round = 1;
        beginRound();
    }

    private void beginRound() {
        if (aliveCount() < 2) {
            finishGame();
            return;
        }
        locked.clear();
        for (int i = 0; i < players; i++) {
            locked.add(new LinkedHashMap<Integer, Integer>());
        }
        turn = 0;
        seatTurn();
        showHandoff();
    }

    /** Moves the turn to the next player who still has coins. Returns false once everyone has had their turn. */
    private boolean seatTurn() {
        while (turn < players && stack[turn] < CHIPS[0]) {
            turn++;
        }
        return turn < players;
    }

    private void showHandoff() {
        phase = PLAY;
        cur = new LinkedHashMap<>();
        undo.clear();
        header.setText("ROUND " + round + "  ·  PLAYER " + (turn + 1) + " OF " + players);
        showCover("PASS THE PHONE",
                "to " + names[turn] + "\n\nyou have " + stack[turn] + " coins",
                false, false, this::hideCover);
        say("PLACE YOUR BETS", Theme.DIM);
        refresh();
    }

    private void lockIn() {
        if (phase != PLAY) {
            return;
        }
        int staked = total();
        stack[turn] -= staked;
        locked.set(turn, new LinkedHashMap<>(cur));
        Sfx.play(Sfx.CLICK);
        host.buzz(20);
        turn++;
        if (seatTurn()) {
            showHandoff();
            return;
        }
        phase = WAIT_SPIN;
        cur = new LinkedHashMap<>();
        undo.clear();
        header.setText("ROUND " + round + "  ·  ALL BETS IN");
        showCover("PASS THE PHONE", "all bets are in", false, false, this::spin);
        refresh();
    }

    private void spin() {
        if (phase != WAIT_SPIN) {
            return;
        }
        phase = ROLL;
        hideCover();
        final int n = GameRoulette.ORDER[rnd.nextInt(GameRoulette.ORDER.length)];
        table.clearWin();
        say("ROLLING", Theme.ACCENT);
        host.buzz(30);
        wheel.spin(n, () -> settle(n));
    }

    private void settle(int n) {
        Set<Integer> winners = new HashSet<>();
        StringBuilder sb = new StringBuilder();
        boolean anyWin = false;
        for (int i = 0; i < players; i++) {
            int back = 0;
            int staked = 0;
            for (Map.Entry<Integer, Integer> e : locked.get(i).entrySet()) {
                staked += e.getValue();
                int mult = GameRoulette.payout(e.getKey(), n);
                if (mult > 0) {
                    back += e.getValue() * mult;
                    winners.add(e.getKey());
                }
            }
            stack[i] += back;
            int net = back - staked;
            if (net > 0) {
                anyWin = true;
            }
            sb.append(names[i]).append("   ");
            if (staked == 0) {
                sb.append("no bets");
            } else {
                sb.append(net >= 0 ? "+" : "").append(net).append("   ·   ").append(stack[i]);
            }
            sb.append('\n');
        }
        saveSeats();
        phase = RESULTS;
        table.setWin(winners, n);
        String name = n + (n == 0 ? " GREEN" : REDS.contains(n) ? " RED" : " BLACK");
        boolean more = aliveCount() >= 2;
        String body = sb.toString().trim() + (more ? "" : "\n\nnot enough players left to keep going");
        Sfx.play(anyWin ? Sfx.WIN : Sfx.LOSE);
        host.buzz(anyWin ? 60 : 25);
        if (anyWin) {
            host.confetti(getWidth() / 2f, getHeight() * 0.35f);
        }
        header.setText("ROUND " + round + "  ·  RESULT");
        nextBtn.setVisibility(more ? VISIBLE : GONE);
        showCover(name, body, false, true, null);
        refresh();
    }

    private void nextRound() {
        if (phase != RESULTS) {
            return;
        }
        round++;
        beginRound();
    }

    private void finishGame() {
        phase = OVER;
        hideCover();
        saveSeats();
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < players; i++) {
            order.add(i);
        }
        order.sort((a, b) -> stack[b] - stack[a]);
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < order.size(); k++) {
            int i = order.get(k);
            sb.append(k == 0 ? "WINNER   " : "           ").append(names[i]).append("   ").append(stack[i]).append('\n');
        }
        header.setText("GAME OVER after " + round + " round" + (round == 1 ? "" : "s"));
        rebuildGuests();
        showCover("GAME OVER", sb.toString().trim(), true, false, null);
        refresh();
    }

    // ------------------------------------------------------------------ betting

    private void place(int id) {
        if (phase != PLAY) {
            return;
        }
        int amount = CHIPS[chip];
        if (total() + amount > stack[turn]) {
            say("NOT ENOUGH COINS", 0xFFFF6B7F);
            host.buzz(30);
            return;
        }
        Integer cur0 = cur.get(id);
        cur.put(id, (cur0 == null ? 0 : cur0) + amount);
        undo.add(new int[] {id, amount});
        host.buzz(8);
        say(describe(id) + "  " + cur.get(id), Theme.TEXT);
        table.clearWin();
        refresh();
    }

    private void undoBet() {
        if (phase != PLAY || undo.isEmpty()) {
            return;
        }
        int[] last = undo.remove(undo.size() - 1);
        Integer c = cur.get(last[0]);
        if (c != null) {
            if (c - last[1] <= 0) {
                cur.remove(last[0]);
            } else {
                cur.put(last[0], c - last[1]);
            }
        }
        refresh();
    }

    private void clearBets() {
        if (phase != PLAY) {
            return;
        }
        cur.clear();
        undo.clear();
        say("PLACE YOUR BETS", Theme.DIM);
        refresh();
    }

    private static String describe(int id) {
        if (id <= 36) {
            return "NUMBER " + id;
        }
        switch (id) {
            case 37:
                return "1ST 12";
            case 38:
                return "2ND 12";
            case 39:
                return "3RD 12";
            case 40:
            case 41:
            case 42:
                return "COLUMN " + (id - 39);
            case LOW:
                return "1-18";
            case EVEN:
                return "EVEN";
            case RED:
                return "RED";
            case BLACK:
                return "BLACK";
            case ODD:
                return "ODD";
            default:
                return "19-36";
        }
    }

    // ================================================================== the betting table

    private final class Table extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<RectF> rects = new ArrayList<>();
        private final List<Integer> ids = new ArrayList<>();
        private final List<String> labels = new ArrayList<>();
        private Set<Integer> winners = new HashSet<>();
        private int resultNumber = -1;
        private int downCell = -1;
        private float u;

        Table(android.content.Context c) {
            super(c);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
        }

        void setWin(Set<Integer> w, int n) {
            winners = w;
            resultNumber = n;
            invalidate();
        }

        void clearWin() {
            winners = new HashSet<>();
            resultNumber = -1;
            invalidate();
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            float unit = w / 14f;
            int h = (int) (unit * 1.2f * 3 + unit * 0.9f * 2 + dp(10));
            setMeasuredDimension(w, h);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            rects.clear();
            ids.clear();
            labels.clear();
            u = w / 14f;
            float rowH = u * 1.2f;
            float gap = dp(2);
            add(0, "0", 0, 0, u, rowH * 3);
            for (int r = 0; r < 3; r++) {
                for (int c = 0; c < 12; c++) {
                    int n = (c + 1) * 3 - r;
                    add(n, String.valueOf(n), u + c * u, r * rowH, u, rowH);
                }
                add(COLUMN + (2 - r), "2:1", 13 * u, r * rowH, u, rowH);
            }
            float y2 = rowH * 3 + gap;
            float oh2 = u * 0.9f;
            String[] dz = {"1st 12", "2nd 12", "3rd 12"};
            for (int d = 0; d < 3; d++) {
                add(DOZEN + d, dz[d], u + d * 4 * u, y2, 4 * u, oh2);
            }
            float y3 = y2 + oh2 + gap;
            int[] outIds = {LOW, EVEN, RED, BLACK, ODD, HIGH};
            String[] outLabels = {"1-18", "EVEN", "RED", "BLACK", "ODD", "19-36"};
            for (int i = 0; i < 6; i++) {
                add(outIds[i], outLabels[i], u + i * 2 * u, y3, 2 * u, oh2);
            }
        }

        private void add(int id, String label, float x, float y, float w, float h) {
            float g = dp(1);
            rects.add(new RectF(x + g, y + g, x + w - g, y + h - g));
            ids.add(id);
            labels.add(label);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downCell = hit(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                    if (downCell >= 0 && hit(e.getX(), e.getY()) == downCell) {
                        place(ids.get(downCell));
                    }
                    downCell = -1;
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    downCell = -1;
                    return true;
                default:
                    return true;
            }
        }

        private int hit(float x, float y) {
            for (int i = 0; i < rects.size(); i++) {
                if (rects.get(i).contains(x, y)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        protected void onDraw(Canvas c) {
            for (int i = 0; i < rects.size(); i++) {
                RectF r = rects.get(i);
                int id = ids.get(i);
                int fill;
                if (id <= 36) {
                    int base = GameRoulette.colorOf(id);
                    fill = base == BLACK_C ? 0xFF241D36 : base;
                } else if (id == RED) {
                    fill = RED_C;
                } else if (id == BLACK) {
                    fill = 0xFF241D36;
                } else {
                    fill = 0xFF2A2145;
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(fill);
                c.drawRoundRect(r, dp(4), dp(4), p);
                boolean won = winners.contains(id) || (id <= 36 && id == resultNumber);
                if (won) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(2.5f));
                    p.setColor(0xFFFFFFFF);
                    c.drawRoundRect(r, dp(4), dp(4), p);
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(id <= 36 ? u * 0.42f : u * 0.34f);
                if (id >= COLUMN && id < LOW) {
                    p.setTextSize(u * 0.3f);
                }
                c.drawText(labels.get(i), r.centerX(), r.centerY() + p.getTextSize() * 0.35f, p);
                Integer amount = cur.get(id);
                if (amount != null) {
                    float cr = Math.min(u * 0.4f, r.height() * 0.42f);
                    p.setColor(0xFF000000);
                    c.drawCircle(r.centerX(), r.centerY(), cr + dp(1.5f), p);
                    p.setColor(Theme.ACCENT);
                    c.drawCircle(r.centerX(), r.centerY(), cr, p);
                    p.setColor(Theme.BG);
                    p.setTextSize(cr * (amount >= 1000 ? 0.8f : amount >= 100 ? 0.82f : 1.0f));
                    String t = amount >= 10000 ? (amount / 1000) + "k" : String.valueOf(amount);
                    c.drawText(t, r.centerX(), r.centerY() + p.getTextSize() * 0.35f, p);
                }
            }
        }
    }
}
