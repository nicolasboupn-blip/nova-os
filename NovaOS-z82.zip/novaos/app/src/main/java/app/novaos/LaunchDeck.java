package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.provider.Settings;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** The 64 pads of the launch deck: what each one does, how it looks, and how it runs. Saved in Prefs. */
final class DeckBinds {
    private DeckBinds() {}

    static final int N = 8;
    static final int SIZE = N * N;
    private static final String KEY = "deck_binds";

    static final String[] TYPES = {"none", "prev", "pp", "next", "app", "link", "flash", "voldn", "volup", "mute",
        "timer", "coin", "dice", "camera", "notes", "term", "close",
        // the 30 added later
        "rew", "ff", "volmax", "volhalf", "ring", "wifi", "bt", "volpanel", "display", "battset", "airplane",
        "location", "sysset", "brtup", "brtdn", "brtmax", "home", "lock", "nset", "phone", "gallery", "roulette",
        "poker", "spin", "clock", "batt", "timer10", "timer25", "alarms", "web"};
    static final String[] NAMES = {"Empty pad", "Spotify: previous", "Spotify: play / pause", "Spotify: next",
        "Open an app", "Open a Spotify song (or any link)", "Flashlight", "Volume down", "Volume up", "Mute / unmute",
        "5 minute timer", "Coin flip", "Roll a dice", "Camera", "Notes", "Terminal", "Close the deck",
        "Media: rewind", "Media: fast forward", "Sound: volume max", "Sound: volume 50%", "Sound: ringer / vibrate",
        "Phone: Wi-Fi panel", "Phone: Bluetooth", "Phone: volume panel", "Phone: display settings",
        "Phone: battery usage", "Phone: airplane mode", "Phone: location settings", "Phone: Android settings",
        "Screen: brighter", "Screen: dimmer", "Screen: full brightness", "NOVA: home screen", "NOVA: lock screen",
        "NOVA: settings", "NOVA: phone", "NOVA: gallery", "Game: roulette", "Game: poker", "Game: party wheel",
        "Info: show the time", "Info: show the battery", "Timer: 10 minutes", "Timer: 25 minutes (focus)",
        "Clock: show alarms", "Open: web search"};
    static final String[] SHORT = {"", "PREV", "PLAY", "NEXT", "APP", "SONG", "LIGHT", "VOL-", "VOL+", "MUTE",
        "5 MIN", "COIN", "DICE", "CAM", "NOTES", "TERM", "CLOSE",
        "REW", "FF", "VOL MAX", "VOL 50", "RING", "WI-FI", "BT", "VOLUME", "SCREEN", "POWER", "FLIGHT",
        "GPS", "SYSTEM", "BRT+", "BRT-", "BRT MAX", "HOME", "LOCK", "SETTING", "PHONE", "GALLERY", "ROULETTE",
        "POKER", "SPIN", "TIME", "BATT", "10 MIN", "25 MIN", "ALARMS", "WEB"};

    static final int GREEN = 0xFF1DB954, RED = 0xFFE74C3C, AMBER = 0xFFF5A623, BLUE = 0xFF3498DB,
        PURPLE = 0xFF9B6BFF, PINK = 0xFFFF5FA2, CYAN = 0xFF1ABC9C, WHITE = 0xFFECECEC;
    static final int[] COLORS = {GREEN, RED, AMBER, BLUE, PURPLE, PINK, CYAN, WHITE};

    static final class Bind {
        String type;
        String arg;
        String label;
        int color;

        Bind(String type, String arg, String label, int color) {
            this.type = type;
            this.arg = arg;
            this.label = label;
            this.color = color;
        }

        boolean empty() {
            return type.equals("none") || (type.equals("link") && arg.isEmpty());
        }
    }

    private static List<Bind> cache;
    private static final Random RND = new Random();
    private static boolean torchOn;

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    static List<Bind> all() {
        if (cache != null) {
            return cache;
        }
        List<Bind> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw != null && !raw.isEmpty()) {
            for (String line : raw.split("\n", -1)) {
                String[] f = line.split("\t", -1);
                if (f.length != 4) {
                    continue;
                }
                try {
                    out.add(new Bind(f[0], f[1], f[2], Integer.parseInt(f[3])));
                } catch (NumberFormatException ignored) {
                    // a broken line is skipped and the deck is rebuilt below
                }
            }
        }
        if (out.size() != SIZE) {
            out = defaults();
        }
        forceMouse(out);
        cache = out;
        return out;
    }

    /** True for the nine bottom-right pads, which are always the mouse. */
    static boolean isMouse(int idx) {
        int r = idx / N;
        int c = idx % N;
        return r >= N - 3 && c >= N - 3;
    }

    /**
     * The bottom-right 3 x 3 is the mouse: top row click / up / tap, middle row left / down / right, bottom row
     * close / centre / open. Always set, whatever was saved before.
     */
    private static void forceMouse(List<Bind> d) {
        int r0 = (N - 3) * N + (N - 3);
        d.set(r0, new Bind("m_tap", "", "CLICK", GREEN));
        d.set(r0 + 1, new Bind("m_up", "", "UP", BLUE));
        d.set(r0 + 2, new Bind("m_tap", "", "TAP", GREEN));
        d.set(r0 + N, new Bind("m_left", "", "LEFT", BLUE));
        d.set(r0 + N + 1, new Bind("m_down", "", "DOWN", BLUE));
        d.set(r0 + N + 2, new Bind("m_right", "", "RIGHT", BLUE));
        d.set(r0 + 2 * N, new Bind("m_close", "", "CLOSE", RED));
        d.set(r0 + 2 * N + 1, new Bind("m_center", "", "CENTER", WHITE));
        d.set(r0 + 2 * N + 2, new Bind("m_open", "", "MOUSE", CYAN));
    }

    /** A mouse pad other than OPEN is shown dim while the mouse is closed. */
    static boolean dimmed(Bind b) {
        return b.type.startsWith("m_") && !b.type.equals("m_open") && !DeckMouse.on;
    }

    static Bind get(int i) {
        return all().get(i);
    }

    static void put(int i, Bind b) {
        if (isMouse(i)) {
            return; // the mouse pads cannot be changed
        }
        b.arg = clean(b.arg);
        b.label = clean(b.label);
        all().set(i, b);
        save();
    }

    static void reset() {
        cache = defaults();
        save();
    }

    private static void save() {
        List<String> lines = new ArrayList<>();
        for (Bind b : all()) {
            lines.add(b.type + "\t" + b.arg + "\t" + b.label + "\t" + b.color);
        }
        Prefs.putString(KEY, TextUtils.join("\n", lines));
        DeckMidi.lightAll();
    }

    /**
     * The starting deck. Bottom half is for Spotify: three transport pads, the rest are song pads waiting for a link.
     * Top half has 10 binds of NOVA's own plus Spotify and a close pad in the top-right corner.
     */
    static List<Bind> defaults() {
        List<Bind> d = new ArrayList<>();
        for (int i = 0; i < SIZE; i++) {
            boolean bottom = i / N >= 4;
            d.add(bottom ? new Bind("link", "", "SONG", GREEN) : new Bind("none", "", "", 0));
        }
        d.set(7 * N, new Bind("prev", "", "PREV", WHITE));
        d.set(7 * N + 1, new Bind("pp", "", "PLAY", GREEN));
        d.set(7 * N + 2, new Bind("next", "", "NEXT", WHITE));
        d.set(0, new Bind("flash", "", "LIGHT", AMBER));
        d.set(1, new Bind("voldn", "", "VOL-", BLUE));
        d.set(2, new Bind("volup", "", "VOL+", BLUE));
        d.set(3, new Bind("mute", "", "MUTE", RED));
        d.set(4, new Bind("timer", "", "5 MIN", CYAN));
        d.set(5, new Bind("coin", "", "COIN", AMBER));
        d.set(6, new Bind("dice", "", "DICE", PINK));
        d.set(7, new Bind("close", "", "CLOSE", RED));
        d.set(N, new Bind("camera", "", "CAM", WHITE));
        d.set(N + 1, new Bind("notes", "", "NOTES", PURPLE));
        d.set(N + 2, new Bind("term", "", "TERM", GREEN));
        d.set(N + 3, new Bind("app", "com.spotify.music", "SPOTIFY", GREEN));
        // 20 of the 30 later binds fill the rest of the top half; the others are in the pad editor
        d.set(N + 4, new Bind("wifi", "", "WI-FI", CYAN));
        d.set(N + 5, new Bind("bt", "", "BT", CYAN));
        d.set(N + 6, new Bind("volmax", "", "VOL MAX", BLUE));
        d.set(N + 7, new Bind("volhalf", "", "VOL 50", BLUE));
        d.set(2 * N, new Bind("brtdn", "", "BRT-", AMBER));
        d.set(2 * N + 1, new Bind("brtup", "", "BRT+", AMBER));
        d.set(2 * N + 2, new Bind("brtmax", "", "BRT MAX", AMBER));
        d.set(2 * N + 3, new Bind("rew", "", "REW", WHITE));
        d.set(2 * N + 4, new Bind("ff", "", "FF", WHITE));
        d.set(2 * N + 5, new Bind("batt", "", "BATT", GREEN));
        d.set(2 * N + 6, new Bind("clock", "", "TIME", GREEN));
        d.set(2 * N + 7, new Bind("web", "", "WEB", CYAN));
        d.set(3 * N, new Bind("timer10", "", "10 MIN", RED));
        d.set(3 * N + 1, new Bind("timer25", "", "25 MIN", RED));
        d.set(3 * N + 2, new Bind("alarms", "", "ALARMS", RED));
        d.set(3 * N + 3, new Bind("home", "", "HOME", PURPLE));
        d.set(3 * N + 4, new Bind("nset", "", "SETTING", PURPLE));
        d.set(3 * N + 5, new Bind("roulette", "", "ROULETTE", PINK));
        d.set(3 * N + 6, new Bind("poker", "", "POKER", PINK));
        d.set(3 * N + 7, new Bind("spin", "", "SPIN", PINK));
        forceMouse(d);
        return d;
    }

    /** The fill colour of a pad: bright when it does something, faint when it is empty. */
    static int fill(Bind b) {
        if (b.type.equals("none")) {
            return 0x1FFFFFFF;
        }
        if (b.empty() || dimmed(b)) {
            return (b.color & 0xFFFFFF) | 0x40000000;
        }
        return (b.color & 0xFFFFFF) | 0xE0000000;
    }

    // ------------------------------------------------------------------ running a pad

    /** Runs what a pad does. closeDeck is called by the CLOSE pad. */
    static void run(NovaActivity host, Bind b, Runnable closeDeck) {
        switch (b.type) {
            case "prev":
                media(host, 0);
                break;
            case "pp":
                media(host, 1);
                break;
            case "next":
                media(host, 2);
                break;
            case "app": {
                AppEntry e = b.arg.isEmpty() ? null : host.repo.find(b.arg);
                if (e == null) {
                    host.toast("That app is not installed. Hold the pad to pick another.");
                } else {
                    host.launch(e);
                }
                break;
            }
            case "link":
                link(host, b.arg);
                break;
            case "flash":
                flash(host);
                break;
            case "voldn":
                volume(host, AudioManager.ADJUST_LOWER);
                break;
            case "volup":
                volume(host, AudioManager.ADJUST_RAISE);
                break;
            case "mute":
                volume(host, AudioManager.ADJUST_TOGGLE_MUTE);
                break;
            case "timer":
                timer(host, 300);
                break;
            case "timer10":
                timer(host, 600);
                break;
            case "timer25":
                timer(host, 1500);
                break;
            case "rew":
                media(host, 3);
                break;
            case "ff":
                media(host, 4);
                break;
            case "volmax":
                setVolume(host, 1f);
                break;
            case "volhalf":
                setVolume(host, 0.5f);
                break;
            case "ring":
                ringer(host);
                break;
            case "wifi":
                open(host, "android.settings.panel.action.INTERNET_CONNECTIVITY", Settings.ACTION_WIFI_SETTINGS);
                break;
            case "bt":
                open(host, Settings.ACTION_BLUETOOTH_SETTINGS, null);
                break;
            case "volpanel":
                open(host, "android.settings.panel.action.VOLUME", Settings.ACTION_SOUND_SETTINGS);
                break;
            case "display":
                open(host, Settings.ACTION_DISPLAY_SETTINGS, null);
                break;
            case "battset":
                open(host, Intent.ACTION_POWER_USAGE_SUMMARY, null);
                break;
            case "airplane":
                open(host, Settings.ACTION_AIRPLANE_MODE_SETTINGS, null);
                break;
            case "location":
                open(host, Settings.ACTION_LOCATION_SOURCE_SETTINGS, null);
                break;
            case "sysset":
                open(host, Settings.ACTION_SETTINGS, null);
                break;
            case "alarms":
                open(host, AlarmClock.ACTION_SHOW_ALARMS, null);
                break;
            case "brtup":
                brightness(host, 40, -1);
                break;
            case "brtdn":
                brightness(host, -40, -1);
                break;
            case "brtmax":
                brightness(host, 0, 255);
                break;
            case "home":
                host.showHome();
                break;
            case "lock":
                Actions.run(host, "lock");
                break;
            case "nset":
                Actions.run(host, "settings");
                break;
            case "phone":
                Actions.run(host, "phone");
                break;
            case "gallery":
                Actions.run(host, "gallery");
                break;
            case "roulette":
                Actions.run(host, "roulette");
                break;
            case "poker":
                Actions.run(host, "poker");
                break;
            case "spin":
                Actions.run(host, "spin");
                break;
            case "clock":
                host.toast(new SimpleDateFormat("EEEE d MMMM  ·  HH:mm", Locale.getDefault()).format(new Date()));
                break;
            case "batt":
                battery(host);
                break;
            case "web":
                link(host, "https://duckduckgo.com");
                break;
            case "m_open":
            case "m_close":
            case "m_center":
            case "m_tap":
            case "m_up":
            case "m_down":
            case "m_left":
            case "m_right":
                // a plain tap on a pad: one press and release (a direction moves a little)
                DeckMouse.press(host, b.type);
                DeckMouse.release(b.type);
                break;
            case "coin":
                host.coinFlip(null);
                break;
            case "dice":
                host.toast("Dice: " + (1 + RND.nextInt(6)));
                break;
            case "camera":
                camera(host);
                break;
            case "notes":
                host.showNotes();
                break;
            case "term":
                host.showTerminal();
                break;
            case "close":
                closeDeck.run();
                break;
            default:
                break;
        }
    }

    /** 0 previous, 1 play/pause, 2 next, 3 rewind, 4 fast forward. Uses the running player, or the media keys without notification access. */
    private static void media(NovaActivity host, int which) {
        MediaController mc = MusicHelper.controller(host);
        if (mc != null) {
            if (which == 0) {
                MusicHelper.previous(host);
            } else if (which == 1) {
                MusicHelper.toggle(host);
            } else if (which == 2) {
                MusicHelper.next(host);
            } else if (which == 3) {
                mc.getTransportControls().rewind();
            } else {
                mc.getTransportControls().fastForward();
            }
            return;
        }
        int key = which == 0 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                : which == 1 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                : which == 2 ? KeyEvent.KEYCODE_MEDIA_NEXT
                : which == 3 ? KeyEvent.KEYCODE_MEDIA_REWIND : KeyEvent.KEYCODE_MEDIA_FAST_FORWARD;
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, key));
        } catch (Exception e) {
            host.toast("Could not control the music");
        }
    }

    private static final Pattern WEB_SPOTIFY = Pattern.compile(
            "open\\.spotify\\.com/(?:intl-[a-z]+/)?(track|album|playlist|artist|episode|show)/([A-Za-z0-9]+)");

    /** "spotify:track:ID" for a Spotify link in either form, or null for anything else. */
    static String spotifyUri(String s) {
        if (s.startsWith("spotify:")) {
            return s;
        }
        Matcher m = WEB_SPOTIFY.matcher(s);
        return m.find() ? "spotify:" + m.group(1) + ":" + m.group(2) : null;
    }

    private static void link(NovaActivity host, String arg) {
        String url = arg.trim();
        if (url.isEmpty()) {
            return;
        }
        String spot = spotifyUri(url);
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(spot != null ? spot : url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (spot != null) {
                i.setPackage("com.spotify.music");
            }
            host.startActivity(i);
        } catch (Exception first) {
            try {
                host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception second) {
                host.toast("Could not open that link");
                return;
            }
        }
        if (spot != null) {
            final String uri = spot;
            final Context app = host.getApplicationContext();
            // Spotify opens the song but does not always start it. Ask its player to play it once it is up.
            new Handler(Looper.getMainLooper()).postDelayed(() -> playInSpotify(app, uri), 1800);
        }
    }

    private static void playInSpotify(Context c, String uri) {
        if (!NovaNotificationService.hasAccess(c)) {
            return;
        }
        try {
            MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            for (MediaController mc : m.getActiveSessions(new ComponentName(c, NovaNotificationService.class))) {
                if ("com.spotify.music".equals(mc.getPackageName())) {
                    mc.getTransportControls().playFromUri(Uri.parse(uri), null);
                    return;
                }
            }
        } catch (Exception ignored) {
            // Spotify did not take the request, the song is still open for you to play
        }
    }

    private static void flash(NovaActivity host) {
        try {
            CameraManager cm = (CameraManager) host.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String s : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(s).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) {
                    id = s;
                    break;
                }
            }
            if (id == null) {
                host.toast("No flashlight on this phone");
                return;
            }
            torchOn = !torchOn;
            cm.setTorchMode(id, torchOn);
        } catch (Exception e) {
            torchOn = false;
            host.toast("Flashlight not available");
        }
    }

    private static void volume(NovaActivity host, int dir) {
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
        } catch (Exception e) {
            host.toast("Could not change the volume");
        }
    }

    private static void timer(NovaActivity host, int seconds) {
        try {
            host.startActivity(new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA deck")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            host.toast((seconds / 60) + " minute timer started");
        } catch (Exception e) {
            host.toast("No clock app to set the timer");
        }
    }

    /** Opens a phone screen: the first action, or the fallback if this phone has no such screen. */
    private static void open(NovaActivity host, String action, String fallback) {
        try {
            host.startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception first) {
            try {
                if (fallback == null) {
                    throw first;
                }
                host.startActivity(new Intent(fallback).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception second) {
                host.toast("This phone has no such screen");
            }
        }
    }

    private static void setVolume(NovaActivity host, float fraction) {
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * fraction), AudioManager.FLAG_SHOW_UI);
        } catch (Exception e) {
            host.toast("Could not change the volume");
        }
    }

    /** Ringer sound on, or vibrate only. Silent needs Do Not Disturb access, so it is left out. */
    private static void ringer(NovaActivity host) {
        try {
            AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
            boolean normal = am.getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
            am.setRingerMode(normal ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_NORMAL);
            host.toast(normal ? "Ringer: vibrate only" : "Ringer: sound on");
        } catch (Exception e) {
            host.toast("Android would not change the ringer (Do Not Disturb may be on)");
        }
    }

    /** delta steps the screen brightness; absolute (0 to 255) sets it, or -1 to step. Needs the one-time settings OK. */
    private static void brightness(NovaActivity host, int delta, int absolute) {
        try {
            if (!Settings.System.canWrite(host)) {
                host.toast("Allow NOVA to change settings, then press the pad again");
                host.startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + host.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            }
            ContentResolver cr = host.getContentResolver();
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            int cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128);
            int next = absolute >= 0 ? absolute : Math.max(10, Math.min(255, cur + delta));
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, next);
            host.toast("Brightness " + (next * 100 / 255) + "%");
        } catch (Exception e) {
            host.toast("Could not change the brightness");
        }
    }

    private static void battery(NovaActivity host) {
        try {
            BatteryManager bm = (BatteryManager) host.getSystemService(Context.BATTERY_SERVICE);
            int pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            host.toast("Battery " + pct + "%" + (bm.isCharging() ? "  ·  charging" : ""));
        } catch (Exception e) {
            host.toast("Could not read the battery");
        }
    }

    private static void camera(NovaActivity host) {
        try {
            host.startActivity(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            host.toast("No camera app found");
        }
    }
}

/**
 * The pop-out launch deck: a full-screen 8 x 8 pad grid like a Launchpad. Tap a pad to run it, hold a pad (or switch
 * on EDIT) to choose what it does, its label and its colour.
 */
final class LaunchDeck extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout grid;
    private final TextView editChip;
    private final TextView resetChip;
    private final TextView usbLine;
    private final Runnable statusCb = this::showStatus;
    private final Runnable rebuildCb = this::build;
    private boolean editing;

    private void showStatus() {
        usbLine.setText("launchpad over USB: " + DeckMidi.status);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        DeckMidi.listener = statusCb;
        DeckMouse.listener = rebuildCb;
        showStatus();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (DeckMidi.listener == statusCb) {
            DeckMidi.listener = null;
        }
        if (DeckMouse.listener == rebuildCb) {
            DeckMouse.listener = null;
        }
        super.onDetachedFromWindow();
    }

    LaunchDeck(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(18));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("LAUNCH DECK", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.15f);
        title.setGravity(Gravity.START);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        resetChip = chip("RESET", this::confirmReset);
        resetChip.setVisibility(GONE);
        head.addView(resetChip);
        head.addView(chip("USB", () -> DeckMidi.rescan(host)));
        editChip = chip("EDIT", this::toggleEdit);
        head.addView(editChip);
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hint = label("tap a pad to run it  ·  hold a pad to change it", 9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(6);
        col.addView(hint, hlp);

        usbLine = label("", 9f, Theme.DIM);
        usbLine.setGravity(Gravity.START);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ulp.topMargin = dp(3);
        ulp.bottomMargin = dp(12);
        col.addView(usbLine, ulp);
        showStatus();

        grid = new LinearLayout(host);
        grid.setOrientation(LinearLayout.VERTICAL);
        col.addView(grid, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView foot = label("bottom half: Spotify (PREV, PLAY, NEXT + song pads)  ·  top right pad: CLOSE\n"
                + "bottom-right 3 x 3 = MOUSE: press MOUSE (bottom right) to open, CLOSE (bottom left) to close, "
                + "UP / LEFT / DOWN (middle) / RIGHT move the cursor (hold to speed up), CENTER (bottom middle) recentres, "
                + "the two top corners tap", 8f,
                Theme.DIM);
        foot.setGravity(Gravity.START);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        flp.topMargin = dp(12);
        col.addView(foot, flp);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        build();
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView label(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private TextView chip(String s, Runnable action) {
        TextView b = label(s, 10f, Theme.ACCENT);
        b.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private void toggleEdit() {
        editing = !editing;
        editChip.setBackground(Theme.rounded(editing ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
        editChip.setTextColor(editing ? Theme.BG : Theme.ACCENT);
        resetChip.setVisibility(editing ? VISIBLE : GONE);
        build();
    }

    private void confirmReset() {
        new AlertDialog.Builder(host).setTitle("Reset the whole deck?")
                .setMessage("All 64 pads go back to the starting layout.")
                .setPositiveButton("RESET", (d, w) -> {
                    DeckBinds.reset();
                    build();
                }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ the grid

    private void build() {
        grid.removeAllViews();
        int pad = (host.getResources().getDisplayMetrics().widthPixels - dp(28)) / DeckBinds.N;
        for (int r = 0; r < DeckBinds.N; r++) {
            LinearLayout row = new LinearLayout(host);
            for (int c = 0; c < DeckBinds.N; c++) {
                final int idx = r * DeckBinds.N + c;
                final DeckBinds.Bind b = DeckBinds.get(idx);
                final TextView t = label(b.empty() && !editing ? "" : b.label, 7f, b.empty() ? Theme.DIM : Theme.BG);
                t.setMaxLines(2);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(dp(1), 0, dp(1), 0);
                t.setBackground(Theme.rounded(DeckBinds.fill(b), 8f, host));
                t.setClickable(true);
                t.setOnClickListener(v -> press(idx, t));
                t.setOnLongClickListener(v -> {
                    edit(idx);
                    return true;
                });
                if (b.type.startsWith("m_")) {
                    // mouse pads react to the finger going down and up, so a held arrow keeps moving the cursor
                    final String mt = b.type;
                    t.setOnTouchListener((v, ev) -> {
                        switch (ev.getActionMasked()) {
                            case MotionEvent.ACTION_DOWN:
                                v.setAlpha(0.5f);
                                host.buzz(10);
                                DeckMouse.press(host, mt);
                                break;
                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL:
                                v.setAlpha(1f);
                                DeckMouse.release(mt);
                                break;
                            default:
                                break;
                        }
                        return true;
                    });
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(pad - dp(3), pad - dp(3));
                lp.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                row.addView(t, lp);
            }
            grid.addView(row);
        }
    }

    private void press(int idx, final TextView v) {
        DeckBinds.Bind b = DeckBinds.get(idx);
        if (editing || b.empty()) {
            edit(idx);
            return;
        }
        host.buzz(15);
        v.animate().alpha(0.45f).setDuration(70)
                .withEndAction(() -> v.animate().alpha(1f).setDuration(130).start()).start();
        DeckBinds.run(host, b, () -> host.hideOverlay());
    }

    // ------------------------------------------------------------------ the editor

    private void edit(final int idx) {
        if (DeckBinds.isMouse(idx)) {
            host.toast("These 9 pads are the mouse. They can't be changed");
            return;
        }
        new AlertDialog.Builder(host)
                .setTitle("Pad " + (idx / DeckBinds.N + 1) + " · " + (idx % DeckBinds.N + 1))
                .setItems(DeckBinds.NAMES, (d, w) -> chosen(idx, w))
                .setNegativeButton("Cancel", null).show();
    }

    private void chosen(final int idx, int which) {
        final String type = DeckBinds.TYPES[which];
        if (type.equals("none")) {
            DeckBinds.put(idx, new DeckBinds.Bind("none", "", "", 0));
            build();
        } else if (type.equals("app")) {
            pickApp(idx);
        } else if (type.equals("link")) {
            askLink(idx);
        } else {
            style(idx, type, "", DeckBinds.SHORT[which]);
        }
    }

    private void pickApp(final int idx) {
        host.repo.ensureFresh();
        final List<AppEntry> apps = new ArrayList<>(host.repo.all);
        Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
        String[] names = new String[apps.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = apps.get(i).label;
        }
        new AlertDialog.Builder(host).setTitle("Pick an app")
                .setItems(names, (d, w) -> style(idx, "app", apps.get(w).pkg,
                        apps.get(w).label.toUpperCase(java.util.Locale.ROOT)))
                .setNegativeButton("Cancel", null).show();
    }

    private void askLink(final int idx) {
        final EditText in = new EditText(host);
        in.setHint("Spotify song link, or any web link");
        in.setSingleLine(true);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        try {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm.getPrimaryClip();
            String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
            if (t.startsWith("http") || t.startsWith("spotify:")) {
                in.setText(t);
            }
        } catch (Exception ignored) {
            // no clipboard to prefill from
        }
        FrameLayout wrap = new FrameLayout(host);
        wrap.setPadding(dp(20), dp(8), dp(20), 0);
        wrap.addView(in);
        new AlertDialog.Builder(host).setTitle("Song link")
                .setMessage("In Spotify: share the song, copy the link, then paste it here. If a link is on your "
                        + "clipboard it is filled in for you.")
                .setView(wrap)
                .setPositiveButton("NEXT", (d, w) -> {
                    String s = in.getText().toString().trim();
                    if (s.isEmpty()) {
                        host.toast("No link entered");
                    } else {
                        style(idx, "link", s, "SONG");
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    /** Last step: the label on the pad and its colour. */
    private void style(final int idx, final String type, final String arg, String defLabel) {
        DeckBinds.Bind old = DeckBinds.get(idx);
        final int[] sel = {0};
        for (int i = 0; i < DeckBinds.COLORS.length; i++) {
            if (old.type.equals(type) && old.color == DeckBinds.COLORS[i]) {
                sel[0] = i;
            }
        }
        final EditText name = new EditText(host);
        name.setSingleLine(true);
        name.setText(old.type.equals(type) && !old.label.isEmpty() ? old.label : defLabel);
        name.setFilters(new InputFilter[] {new InputFilter.LengthFilter(8)});
        name.setHint("label (up to 8 letters)");

        final LinearLayout colors = new LinearLayout(host);
        final View[] chips = new View[DeckBinds.COLORS.length];
        for (int i = 0; i < chips.length; i++) {
            final int k = i;
            View v = new View(host);
            v.setBackground(Theme.rounded(DeckBinds.COLORS[i], 8f, host));
            v.setOnClickListener(x -> {
                sel[0] = k;
                for (int j = 0; j < chips.length; j++) {
                    chips[j].setAlpha(j == k ? 1f : 0.35f);
                }
            });
            chips[i] = v;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
            lp.setMargins(dp(2), dp(10), dp(2), 0);
            colors.addView(v, lp);
        }
        for (int j = 0; j < chips.length; j++) {
            chips[j].setAlpha(j == sel[0] ? 1f : 0.35f);
        }

        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(name);
        box.addView(colors);
        new AlertDialog.Builder(host).setTitle("Label and colour").setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    String l = name.getText().toString().trim();
                    DeckBinds.put(idx, new DeckBinds.Bind(type, arg, l.isEmpty() ? "PAD" : l,
                            DeckBinds.COLORS[sel[0]]));
                    build();
                }).setNegativeButton("Cancel", null).show();
    }
}

/** The home screen widget: the top and bottom rows of the deck live, plus a button that pops the whole deck out. */
final class DeckWidget extends NovaWidget {
    private final LinearLayout top;
    private final LinearLayout bottom;

    DeckWidget(NovaActivity host) {
        super(host);
        setGravity(Gravity.CENTER);
        TextView head = text("LAUNCH DECK", 9f, Theme.DIM);
        addView(head, wide());
        top = row();
        addView(top, wide());
        bottom = row();
        addView(bottom, wide());
        addView(chip("POP OUT THE FULL DECK ▸", () -> host.showOverlay(new LaunchDeck(host))), wide());
    }

    @Override
    void refresh() {
        fill(top, 0);
        fill(bottom, DeckBinds.SIZE - DeckBinds.N);
    }

    private void fill(LinearLayout row, int first) {
        row.removeAllViews();
        for (int c = 0; c < DeckBinds.N; c++) {
            final DeckBinds.Bind b = DeckBinds.get(first + c);
            TextView t = text(b.empty() ? "" : b.label, 6f, b.empty() ? Theme.DIM : Theme.BG);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setBackground(Theme.rounded(DeckBinds.fill(b), 7f, host));
            t.setClickable(true);
            t.setOnClickListener(v -> {
                if (b.empty()) {
                    host.showOverlay(new LaunchDeck(host));
                } else {
                    host.buzz(15);
                    DeckBinds.run(host, b, () -> { });
                }
            });
            t.setOnLongClickListener(v -> {
                host.showOverlay(new LaunchDeck(host));
                return true;
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
            lp.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
            row.addView(t, lp);
        }
    }
}
