package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Everything you can change about NOVA, in one place. */
final class SettingsScreen extends LinearLayout {
    private final NovaActivity host;

    SettingsScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 20);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        // title row
        LinearLayout head = new LinearLayout(host);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("SETTINGS", 12f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView back = label("BACK", 12f, Theme.DIM);
        back.setClickable(true);
        back.setOnClickListener(v -> host.showHome());
        head.addView(back);
        addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(host);
        LinearLayout body = new LinearLayout(host);
        body.setOrientation(VERTICAL);
        sv.addView(body);
        addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        heading(body, "ACCENT");
        body.addView(accentRow(), block(8));

        heading(body, "CLOCK & GLOW");
        body.addView(toggle("Glow around the clock", Prefs.K_GLOW_CLOCK, Prefs.glowClock()));
        body.addView(toggle("Purple edge light", Prefs.K_GLOW_EDGES, Prefs.glowEdges()));
        body.addView(toggle("Battery in header", Prefs.K_BATTERY, Prefs.battery()));

        heading(body, "LOCK SCREEN");
        body.addView(toggle("Typing code wallpaper", Prefs.K_CODE_WALL, Prefs.codeWall()));
        body.addView(toggle("Startup animation on unlock", Prefs.K_BOOT_UNLOCK, Prefs.bootOnUnlock()));
        body.addView(toggle("Beep on unlock", Prefs.K_BEEP, Prefs.beep()));
        body.addView(hint("Your own wallpaper text (empty = NOVA's own code)"));
        body.addView(input(Prefs.K_WALL_TEXT, Prefs.wallText(), true), block(6));

        heading(body, "AFTER UNLOCK");
        body.addView(hint("Greeting line"));
        body.addView(input(Prefs.K_GREETING, Prefs.greeting(), false), block(6));

        heading(body, "STATS");
        body.addView(label("Unlocks: " + Prefs.unlocks() + "    Apps: " + host.repo.all.size(),
                14f, Theme.TEXT), block(8));

        TextView reset = label("RESET ALL SETTINGS", 12f, Theme.ACCENT);
        reset.setClickable(true);
        reset.setPadding(0, Theme.dp(host, 28), 0, Theme.dp(host, 16));
        reset.setOnClickListener(v -> {
            Prefs.reset();
            host.refreshTheme();
        });
        body.addView(reset);
    }

    private View accentRow() {
        LinearLayout row = new LinearLayout(host);
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < Theme.PRESET_NAMES.length; i++) {
            final int idx = i;
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.setClickable(true);
            col.setOnClickListener(v -> {
                Prefs.putInt(Prefs.K_ACCENT, idx);
                host.refreshTheme();
            });

            View dot = new View(host);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Theme.presetAccent(i));
            if (Prefs.accent() == i) {
                g.setStroke(Theme.dp(host, 3), Theme.TEXT);
            }
            dot.setBackground(g);
            col.addView(dot, new LinearLayout.LayoutParams(Theme.dp(host, 48), Theme.dp(host, 48)));

            TextView name = label(Theme.PRESET_NAMES[i].toUpperCase(), 10f, Theme.DIM);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            np.topMargin = Theme.dp(host, 6);
            col.addView(name, np);

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(col, cp);
        }
        return row;
    }

    private View toggle(String text, final String key, boolean value) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));

        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch s = new Switch(host);
        s.setChecked(value);
        s.setOnCheckedChangeListener((b, on) -> Prefs.putBool(key, on));
        r.addView(s);
        return r;
    }

    private EditText input(final String key, String value, boolean multi) {
        EditText e = new EditText(host);
        e.setText(value);
        e.setTextSize(14f);
        e.setTextColor(Theme.TEXT);
        e.setHint("type here");
        e.setHintTextColor(Theme.DIM);
        e.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        e.setPadding(Theme.dp(host, 14), Theme.dp(host, 12), Theme.dp(host, 14), Theme.dp(host, 12));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                Prefs.putString(key, s.toString());
            }
        });
        return e;
    }

    private void heading(LinearLayout body, String text) {
        TextView t = label(text, 11f, Theme.ACCENT);
        t.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams p = block(24);
        body.addView(t, p);
    }

    private void hint(LinearLayout body, String text) {
        body.addView(hint(text));
    }

    private TextView hint(String text) {
        TextView t = label(text, 12f, Theme.DIM);
        t.setTypeface(android.graphics.Typeface.DEFAULT);
        t.setPadding(0, Theme.dp(host, 14), 0, 0);
        return t;
    }

    private TextView label(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams block(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = Theme.dp(host, topDp);
        return p;
    }
}
