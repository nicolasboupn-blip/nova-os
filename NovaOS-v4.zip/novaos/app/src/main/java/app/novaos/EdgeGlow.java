package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

/** Accent light that breathes along the four screen edges. Touches pass straight through. */
final class EdgeGlow extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ValueAnimator pulse;
    private final int depth;
    private LinearGradient top, bottom, left, right;

    EdgeGlow(Context c) {
        super(c);
        depth = Theme.dp(c, 80);
        setClickable(false);
        setVisibility(Prefs.glowEdges() ? VISIBLE : GONE);
        pulse = ValueAnimator.ofFloat(0.2f, 0.9f);
        pulse.setDuration(2400);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.addUpdateListener(a -> setAlpha((float) a.getAnimatedValue()));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        pulse.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        pulse.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        int edge = (0xB0 << 24) | (Theme.GLOW & 0xFFFFFF);
        int clear = Theme.GLOW & 0xFFFFFF;
        top = new LinearGradient(0, 0, 0, depth, edge, clear, Shader.TileMode.CLAMP);
        bottom = new LinearGradient(0, h, 0, h - depth, edge, clear, Shader.TileMode.CLAMP);
        left = new LinearGradient(0, 0, depth, 0, edge, clear, Shader.TileMode.CLAMP);
        right = new LinearGradient(w, 0, w - depth, 0, edge, clear, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (top == null) {
            return;
        }
        paint.setShader(top);
        canvas.drawRect(0, 0, w, depth, paint);
        paint.setShader(bottom);
        canvas.drawRect(0, h - depth, w, h, paint);
        paint.setShader(left);
        canvas.drawRect(0, 0, depth, h, paint);
        paint.setShader(right);
        canvas.drawRect(w - depth, 0, w, h, paint);
    }
}
