package app.novaos;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

/** Name, colors and fonts of the OS. The palette comes from Settings > Accent. */
final class Theme {
    static final String OS_NAME = "NOVA";
    static final String OS_VERSION = "2.0";

    static final String[] PRESET_NAMES = {"Purple", "Ice", "Neon", "Mint"};

    // accent, glow, background 2, background, panel
    private static final int[][] PRESETS = {
        {0xFFB39DFF, 0xFF8A5CFF, 0xFF1A1234, 0xFF0C0917, 0xFF22193F}, // purple
        {0xFF9AE6FF, 0xFF3FA7D6, 0xFF0F1E2E, 0xFF07111C, 0xFF172B40}, // ice
        {0xFFFF9AD5, 0xFFD6408F, 0xFF2A0F24, 0xFF14070F, 0xFF3A1833}, // neon
        {0xFF9CF5C8, 0xFF2FBF8A, 0xFF0F2A22, 0xFF06130F, 0xFF173B30}  // mint
    };

    static int BG = 0xFF0C0917;
    static int BG2 = 0xFF1A1234;
    static int PANEL = 0xFF22193F;
    static int ACCENT = 0xFFB39DFF;
    static int GLOW = 0xFF8A5CFF;
    static final int TEXT = 0xFFF2EEFF;
    static final int DIM = 0xFF8E84B3;

    static final Typeface MONO = Typeface.MONOSPACE;
    static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);

    /** Turns any icon into a purple monochrome version, so every app matches NOVA. */
    private static final ColorFilter PURPLE_ICONS = new ColorMatrixColorFilter(new ColorMatrix(new float[] {
        0.209f, 0.411f, 0.080f, 0f, 20f,
        0.185f, 0.364f, 0.071f, 0f, 0f,
        0.299f, 0.587f, 0.114f, 0f, 60f,
        0f,     0f,     0f,     1f, 0f
    }));

    private Theme() {}

    /** Applies the chosen accent palette. Call once at start and again after a change. */
    static void load() {
        int i = Math.max(0, Math.min(PRESETS.length - 1, Prefs.accent()));
        int[] p = PRESETS[i];
        ACCENT = p[0];
        GLOW = p[1];
        BG2 = p[2];
        BG = p[3];
        PANEL = p[4];
    }

    static int presetAccent(int i) {
        return PRESETS[i][0];
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static Drawable tint(Drawable d) {
        if (d != null) {
            d.setColorFilter(PURPLE_ICONS);
        }
        return d;
    }

    /** Breathing glow behind a text view. Turned off in Settings it stays silent. Cancel it when the view goes away. */
    static ValueAnimator glow(final TextView v) {
        final float max = Prefs.glowClock() ? dp(v.getContext(), 22f) : 0f;
        ValueAnimator a = ValueAnimator.ofFloat(max * 0.25f, max);
        a.setDuration(2200);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.addUpdateListener(an -> v.setShadowLayer((float) an.getAnimatedValue(), 0f, 0f, GLOW));
        a.start();
        return a;
    }

    static GradientDrawable rounded(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable background() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[] {BG2, BG});
    }

    /** Touch ripple for buttons. */
    static void ripple(View v) {
        TypedValue tv = new TypedValue();
        if (v.getContext().getTheme().resolveAttribute(
                android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
            v.setBackgroundResource(tv.resourceId);
        }
    }
}
