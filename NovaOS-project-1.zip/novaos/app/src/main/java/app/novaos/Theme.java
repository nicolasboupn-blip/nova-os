package app.novaos;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;

/** Name, colors and fonts of the OS. Change them here to make it yours. */
final class Theme {
    static final String OS_NAME = "NOVA";
    static final String OS_VERSION = "1.0";

    static final int BG = Color.parseColor("#0B0C10");
    static final int BG2 = Color.parseColor("#14161F");
    static final int PANEL = Color.parseColor("#1A1D29");
    static final int TEXT = Color.parseColor("#ECEFF6");
    static final int DIM = Color.parseColor("#8089A0");
    static final int ACCENT = Color.parseColor("#9B8CFF");

    static final Typeface MONO = Typeface.MONOSPACE;
    static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);

    private Theme() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable background() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[] {BG2, BG});
    }

    /** Touch ripple for buttons. */
    static void ripple(View v) {
        TypedValue tv = new TypedValue();
        if (v.getContext().getTheme().resolveAttribute(
                android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
            v.setBackgroundResource(tv.resourceId);
        }
    }
}
