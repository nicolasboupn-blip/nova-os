package app.novaos;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Clock, pinned apps and a dock. Swipe up on an empty area to open the app drawer. */
final class HomeScreen extends FrameLayout {
    private static final int COLUMNS = 4;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView battery;
    private final android.view.GestureDetector swipe;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshBattery();
            handler.postDelayed(this, 30000);
        }
    };

    HomeScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        int side = Theme.dp(host, 24);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // top row: name on the left, battery on the right
        LinearLayout status = new LinearLayout(host);
        status.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = mono(Theme.OS_NAME, 12f, Theme.ACCENT);
        name.setLetterSpacing(0.3f);
        battery = mono("", 12f, Theme.DIM);
        status.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        status.addView(battery);
        col.addView(status);

        TextClock clock = new TextClock(host);
        clock.setFormat12Hour("HH:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(64f);
        clock.setTypeface(Theme.LIGHT);
        clock.setTextColor(Theme.TEXT);
        clock.setIncludeFontPadding(false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 28);
        col.addView(clock, clp);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(15f);
        date.setTextColor(Theme.DIM);
        col.addView(date);

        // flexible gap
        col.addView(new View(host), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // pinned apps
        host.repo.ensureFresh();
        List<AppEntry> pinned = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                pinned.add(e);
            }
        }
        if (pinned.isEmpty()) {
            TextView empty = mono("Long-press an app in the drawer to pin it here.", 12f, Theme.DIM);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            elp.bottomMargin = Theme.dp(host, 20);
            col.addView(empty, elp);
        } else {
            LinearLayout rows = new LinearLayout(host);
            rows.setOrientation(LinearLayout.VERTICAL);
            LinearLayout row = null;
            int n = 0;
            for (AppEntry e : pinned) {
                if (n % COLUMNS == 0) {
                    row = new LinearLayout(host);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    rows.addView(row, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                }
                row.addView(cell(e), new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                n++;
            }
            while (n % COLUMNS != 0) {
                row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
                n++;
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = Theme.dp(host, 20);
            col.addView(rows, rlp);
        }

        // dock
        LinearLayout dock = new LinearLayout(host);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        dock.setPadding(Theme.dp(host, 6), Theme.dp(host, 4), Theme.dp(host, 6), Theme.dp(host, 4));
        dock.addView(dockButton("APPS", v -> host.showDrawer()), weight());
        dock.addView(dockButton("NOTES", v -> host.showNotes()), weight());
        dock.addView(dockButton("TERMINAL", v -> host.showTerminal()), weight());
        dock.addView(dockButton("MENU", v -> host.showMenu()), weight());
        col.addView(dock, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        swipe = new android.view.GestureDetector(host,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (e1 != null && e2 != null
                                && e1.getY() - e2.getY() > Theme.dp(host, 80) && Math.abs(vy) > 600) {
                            host.showDrawer();
                            return true;
                        }
                        return false;
                    }
                });

        refreshBattery();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return swipe.onTouchEvent(e) || super.onTouchEvent(e);
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView dockButton(String label, OnClickListener click) {
        TextView b = mono(label, 11f, Theme.TEXT);
        b.setLetterSpacing(0.12f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private View cell(final AppEntry e) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));

        ImageView icon = new ImageView(host);
        icon.setImageDrawable(e.icon);
        c.addView(icon, new LinearLayout.LayoutParams(Theme.dp(host, 54), Theme.dp(host, 54)));

        TextView t = new TextView(host);
        t.setText(e.label);
        t.setTextSize(11f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 6);
        c.addView(t, tlp);

        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.confirmUnpin(e);
            return true;
        });
        return c;
    }

    private void refreshBattery() {
        int level = host.batteryLevel();
        if (level < 0) {
            battery.setText("");
            return;
        }
        battery.setText(level + "%" + (host.charging() ? " · charging" : ""));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.postDelayed(tick, 30000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
