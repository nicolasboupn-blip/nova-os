package app.novaos;

import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Fake kernel boot log that plays after every phone restart. Tap to skip. */
final class BootScreen extends FrameLayout {
    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView log;
    private TextView mark;
    private String[] lines;
    private int index = 0;
    private boolean done = false;

    private final Runnable step = new Runnable() {
        @Override
        public void run() {
            if (done) {
                return;
            }
            if (index < lines.length) {
                log.append(lines[index++] + "\n");
                handler.postDelayed(this, 150);
            } else {
                complete();
            }
        }
    };

    BootScreen(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(Color.BLACK);

        log = new TextView(host);
        log.setTypeface(Theme.MONO);
        log.setTextSize(12f);
        log.setTextColor(Theme.DIM);
        log.setLineSpacing(0f, 1.2f);
        log.setPadding(Theme.dp(host, 24), Theme.dp(host, 64), Theme.dp(host, 24), 0);
        addView(log, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        mark = new TextView(host);
        mark.setText(Theme.OS_NAME);
        mark.setTextSize(40f);
        mark.setTypeface(Theme.LIGHT);
        mark.setLetterSpacing(0.5f);
        mark.setTextColor(Theme.ACCENT);
        mark.setAlpha(0f);
        addView(mark, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        String kernel = System.getProperty("os.version");
        lines = new String[] {
            Theme.OS_NAME + " " + Theme.OS_VERSION,
            "",
            "[  ok  ] kernel " + (kernel == null ? "linux" : kernel),
            "[  ok  ] hardware " + Build.MANUFACTURER + " " + Build.MODEL,
            "[  ok  ] android " + Build.VERSION.RELEASE + " (api " + Build.VERSION.SDK_INT + ")",
            "[  ok  ] mounting /data",
            "[  ok  ] starting display",
            "[  ok  ] indexing " + host.repo.all.size() + " apps",
            "[  ok  ] hiding stock launcher",
            "",
            "welcome."
        };

        setOnClickListener(v -> complete());
        handler.postDelayed(step, 300);
    }

    private void complete() {
        if (done) {
            return;
        }
        done = true;
        handler.removeCallbacksAndMessages(null);
        mark.animate().alpha(1f).setDuration(500).start();
        handler.postDelayed(() -> host.showLock(), 1000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
