package app.novaos;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The whole OS lives in this one activity. Because it declares the HOME category,
 * Android offers it as a home app, and when it is the default one Android starts it
 * at boot and whenever you press the home button.
 */
@SuppressWarnings("deprecation")
public class NovaActivity extends Activity {
    static final int BOOT = 0;
    static final int LOCK = 1;
    static final int HOME = 2;
    static final int DRAWER = 3;
    static final int TERMINAL = 4;
    static final int NOTES = 5;

    private static final int REQ_HOME = 77;
    private static final int MAX_FAVS = 8;

    FrameLayout root;
    AppRepo repo;
    SharedPreferences prefs;
    int screen = -1;
    private boolean needLock = false;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            needLock = true;
        }
    };

    private final BroadcastReceiver pkgChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            repo.markDirty();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("nova", MODE_PRIVATE);
        repo = new AppRepo(this);

        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        root = new FrameLayout(this);
        root.setBackground(Theme.background());
        // Keeps the keyboard from covering the terminal and notes.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                bottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, 0, 0, bottom);
            return insets;
        });
        setContentView(root);
        goImmersive();

        reg(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_PACKAGE_ADDED);
        pf.addAction(Intent.ACTION_PACKAGE_REMOVED);
        pf.addAction(Intent.ACTION_PACKAGE_CHANGED);
        pf.addDataScheme("package");
        reg(pkgChanged, pf);

        if (bootChanged()) {
            showBoot();
        } else {
            showLock();
        }
    }

    private void reg(BroadcastReceiver r, IntentFilter f) {
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(r, f);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(screenOff);
            unregisterReceiver(pkgChanged);
        } catch (Exception ignored) {
            // already unregistered
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (needLock) {
            needLock = false;
            if (screen != BOOT && screen != LOCK) {
                showLock();
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing the phone's home button lands here.
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME)
                && screen != LOCK && screen != BOOT) {
            showHome();
        }
    }

    @Override
    public void onBackPressed() {
        // A home screen never closes itself. Back goes up one level instead.
        if (screen == DRAWER || screen == TERMINAL || screen == NOTES) {
            showHome();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            goImmersive();
        }
    }

    /** Hides Android's status bar and navigation bar so only NOVA is visible. */
    private void goImmersive() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ---------------------------------------------------------------- screens

    private void show(View v, int which) {
        hideKeyboard();
        screen = which;
        root.removeAllViews();
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        v.setAlpha(0f);
        v.animate().alpha(1f).setDuration(160).start();
    }

    void showBoot() {
        show(new BootScreen(this), BOOT);
    }

    void showLock() {
        show(new LockScreen(this), LOCK);
    }

    void showHome() {
        show(new HomeScreen(this), HOME);
        maybeAskDefault();
    }

    void showDrawer() {
        show(new DrawerScreen(this), DRAWER);
    }

    void showTerminal() {
        show(new TerminalScreen(this), TERMINAL);
    }

    void showNotes() {
        show(new NotesScreen(this), NOTES);
    }

    void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null && root != null) {
            imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    void launch(AppEntry e) {
        hideKeyboard();
        if (!repo.launch(e)) {
            toast("Could not open " + e.label);
        }
    }

    // ------------------------------------------------------------------ boot

    /** True on first run and after every phone reboot, so the boot animation plays then. */
    private boolean bootChanged() {
        int now = -1;
        try {
            now = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT);
        } catch (Exception ignored) {
            // setting not readable on this phone
        }
        int last = prefs.getInt("boot_count", -2);
        prefs.edit().putInt("boot_count", now).apply();
        return now != last;
    }

    // -------------------------------------------------------- default home app

    boolean isDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return rm.isRoleHeld(RoleManager.ROLE_HOME);
            }
        }
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && getPackageName().equals(ri.activityInfo.packageName);
    }

    private void maybeAskDefault() {
        if (prefs.getBoolean("asked_home", false) || isDefaultHome()) {
            return;
        }
        prefs.edit().putBoolean("asked_home", true).apply();
        root.postDelayed(this::requestHome, 600);
    }

    /** Asks Android to make NOVA the default home app (this is what enables start at boot). */
    void requestHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    toast(Theme.OS_NAME + " is already your home app");
                } else {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME);
                }
                return;
            }
        }
        openHomeSettings();
    }

    /** Opens Android's "Home app" setting, where you can pick the stock launcher again. */
    void openHomeSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                toast("Open Settings > Apps > Default apps > Home app");
            }
        }
    }

    // --------------------------------------------------------------- favorites

    List<String> favs() {
        String s = prefs.getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            out.addAll(repo.defaultPackages());
            saveFavs(out);
            return out;
        }
        if (!s.isEmpty()) {
            out.addAll(Arrays.asList(s.split(",")));
        }
        return out;
    }

    private void saveFavs(List<String> l) {
        prefs.edit().putString("favs", TextUtils.join(",", l)).apply();
    }

    void togglePin(AppEntry e) {
        List<String> l = favs();
        if (l.contains(e.pkg)) {
            l.remove(e.pkg);
            toast("Removed from home");
        } else if (l.size() >= MAX_FAVS) {
            toast("Home is full (" + MAX_FAVS + " apps)");
            return;
        } else {
            l.add(e.pkg);
            toast("Pinned to home");
        }
        saveFavs(l);
    }

    void confirmUnpin(final AppEntry e) {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setMessage("Remove from home?")
                .setPositiveButton("Remove", (d, w) -> {
                    togglePin(e);
                    if (screen == HOME) {
                        showHome();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Long-press menu for an app in the drawer. */
    void appMenu(final AppEntry e) {
        boolean pinned = favs().contains(e.pkg);
        String[] items = {pinned ? "Remove from home" : "Pin to home", "App info", "Uninstall"};
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        togglePin(e);
                    } else if (which == 1) {
                        openPackageIntent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, e.pkg);
                    } else {
                        openPackageIntent(Intent.ACTION_DELETE, e.pkg);
                    }
                })
                .show();
    }

    private void openPackageIntent(String action, String pkg) {
        try {
            startActivity(new Intent(action, Uri.parse("package:" + pkg)));
        } catch (Exception ex) {
            toast("Not available for this app");
        }
    }

    // --------------------------------------------------------------- battery

    int batteryLevel() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return -1;
        }
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return scale > 0 ? level * 100 / scale : -1;
    }

    boolean charging() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) {
            return false;
        }
        int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
    }

    // ------------------------------------------------------------------ menu

    void showMenu() {
        String[] items = {
            "Switch back to Android",
            "Make " + Theme.OS_NAME + " my home app",
            "Replay boot animation",
            "Lock",
            "About"
        };
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(Theme.OS_NAME + " " + Theme.OS_VERSION)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            openHomeSettings();
                            break;
                        case 1:
                            requestHome();
                            break;
                        case 2:
                            showBoot();
                            break;
                        case 3:
                            showLock();
                            break;
                        default:
                            showAbout();
                            break;
                    }
                })
                .show();
    }

    private void showAbout() {
        String msg = Theme.OS_NAME + " " + Theme.OS_VERSION + "\n\n"
                + "A home screen that replaces the Android look and starts when your phone boots.\n\n"
                + "Default home app: " + (isDefaultHome() ? "yes" : "no") + "\n"
                + "Android " + Build.VERSION.RELEASE + ", " + Build.MANUFACTURER + " " + Build.MODEL;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("About")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }
}
