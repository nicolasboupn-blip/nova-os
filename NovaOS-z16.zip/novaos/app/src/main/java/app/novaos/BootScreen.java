package app.novaos;

import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Startup log. Full version after a restart, a quick one every time you unlock. Tap to skip. */
final class BootScreen extends FrameLayout {
    private final NovaActivity host;
    private final boolean quick;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView log;
    private final TextView mark;
    private final android.animation.ValueAnimator markGlow;
    private String[] lines;
    private int index = 0;
    private boolean done = false;
    private boolean left = false;
    private final boolean cinematic;
    private android.view.View bar;
    private TextView pct;
    private TextView tagline;

    private final Runnable step = new Runnable() {
        @Override
        public void run() {
            if (done) {
                return;
            }
            if (index < lines.length) {
                log.append(lines[index++] + "\n");
                if (cinematic) {
                    float f = index / (float) lines.length;
                    bar.setScaleX(f);
                    pct.setText((int) (f * 100) + "%");
                    host.buzz(8);
                }
                handler.postDelayed(this, quick ? 70 : cinematic ? 210 : 150);
            } else {
                complete();
            }
        }
    };

    BootScreen(NovaActivity host, boolean quick) {
        super(host);
        this.host = host;
        this.quick = quick;
        this.cinematic = !quick && Prefs.bootStyle() == 1;
        setBackgroundColor(Color.BLACK);

        log = new TextView(host);
        log.setTypeface(Theme.MONO);
        log.setTextSize(12f);
        log.setTextColor(Theme.DIM);
        log.setLineSpacing(0f, 1.2f);
        log.setPadding(Theme.dp(host, 24), Theme.dp(host, 64), Theme.dp(host, 24), 0);
        addView(log, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        mark = new TextView(host);
        mark.setText(Theme.OS_NAME);
        mark.setTextSize(40f);
        mark.setTypeface(Theme.DIGITAL);
        mark.setLetterSpacing(0.5f);
        mark.setTextColor(Theme.TEXT);
        mark.setAlpha(0f);
        markGlow = Theme.glow(mark);
        addView(mark, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        String kernel = System.getProperty("os.version");
        if (quick) {
            lines = new String[] {
                "unlocking " + Theme.OS_NAME,
                "[  ok  ] session restored",
                "[  ok  ] loading " + host.repo.all.size() + " apps",
                "[  ok  ] home ready",
                "",
                Prefs.greeting()
            };
        } else if (cinematic) {
            lines = new String[] {
                Theme.OS_NAME + " CORE " + Theme.OS_VERSION,
                "initialising secure boot",
                "",
                "[  ok  ] kernel " + (kernel == null ? "linux" : kernel),
                "[  ok  ] hardware " + Build.MANUFACTURER + " " + Build.MODEL,
                "[  ok  ] android " + Build.VERSION.RELEASE + " (api " + Build.VERSION.SDK_INT + ")",
                "[  ok  ] integrity check passed",
                "[  ok  ] mounting /data",
                "[  ok  ] calibrating motion sensors",
                "[  ok  ] starting display",
                "[  ok  ] loading module: glow",
                "[  ok  ] loading module: casino",
                "[  ok  ] loading module: voice",
                "[  ok  ] loading module: music",
                "[  ok  ] linking headphone daemon",
                "[  ok  ] sealing private browser",
                "[  ok  ] indexing " + host.repo.all.size() + " apps",
                "[  ok  ] hiding stock launcher",
                "[  ok  ] all systems nominal",
                "",
                "welcome back."
            };
        } else {
            lines = new String[] {
                Theme.OS_NAME + " " + Theme.OS_VERSION,
                "",
                "[  ok  ] kernel " + (kernel == null ? "linux" : kernel),
                "[  ok  ] hardware " + Build.MANUFACTURER + " " + Build.MODEL,
                "[  ok  ] android " + Build.VERSION.RELEASE + " (api " + Build.VERSION.SDK_INT + ")",
                "[  ok  ] mounting /data",
                "[  ok  ] starting display",
                "[  ok  ] indexing " + host.repo.all.size() + " apps",
                "[  ok  ] hiding stock launcher",
                "",
                "welcome."
            };
        }

        if (cinematic) {
            android.view.View track = new android.view.View(host);
            track.setBackgroundColor(0x22FFFFFF);
            LayoutParams trp = new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 3), Gravity.BOTTOM);
            trp.setMargins(Theme.dp(host, 32), 0, Theme.dp(host, 32), Theme.dp(host, 110));
            addView(track, trp);
            bar = new android.view.View(host);
            bar.setBackgroundColor(Theme.ACCENT);
            bar.setPivotX(0f);
            bar.setScaleX(0f);
            LayoutParams brp = new LayoutParams(LayoutParams.MATCH_PARENT, Theme.dp(host, 3), Gravity.BOTTOM);
            brp.setMargins(Theme.dp(host, 32), 0, Theme.dp(host, 32), Theme.dp(host, 110));
            addView(bar, brp);
            pct = new TextView(host);
            pct.setTypeface(Theme.MONO);
            pct.setTextSize(11f);
            pct.setTextColor(Theme.DIM);
            pct.setText("0%");
            LayoutParams pp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.END);
            pp.setMargins(0, 0, Theme.dp(host, 32), Theme.dp(host, 122));
            addView(pct, pp);
            tagline = new TextView(host);
            tagline.setTypeface(Theme.MONO);
            tagline.setTextSize(11f);
            tagline.setLetterSpacing(0.35f);
            tagline.setTextColor(Theme.ACCENT);
            tagline.setText("PHONE OS · OWNER EDITION");
            tagline.setAlpha(0f);
            LayoutParams tgp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER);
            tgp.topMargin = Theme.dp(host, 90);
            addView(tagline, tgp);
        }

        // first tap finishes the log, a second tap while the logo shows skips the wait
        setOnClickListener(v -> {
            if (done) {
                handler.removeCallbacksAndMessages(null);
                leave();
            } else {
                complete();
            }
        });
        handler.postDelayed(step, quick ? 120 : 300);
    }

    private void complete() {
        if (done) {
            return;
        }
        done = true;
        handler.removeCallbacksAndMessages(null);
        if (cinematic) {
            bar.setScaleX(1f);
            pct.setText("100%");
            host.buzz(60);
            mark.setScaleX(1.5f);
            mark.setScaleY(1.5f);
            mark.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1100)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(2f)).start();
            tagline.animate().alpha(1f).setStartDelay(900).setDuration(700).start();
            log.animate().alpha(0.08f).setDuration(900).start();
            pct.animate().alpha(0f).setDuration(600).start();
            bar.animate().alpha(0f).setStartDelay(600).setDuration(600).start();
            handler.postDelayed(this::leave, 4200);
            return;
        }
        mark.animate().alpha(1f).setDuration(quick ? 200 : 800).start();
        if (!quick) {
            // let the log fade back so the logo stands out
            log.animate().alpha(0.2f).setDuration(800).start();
        }
        // after a restart the NOVA logo stays for 4 seconds
        handler.postDelayed(this::leave, quick ? 350 : 4000);
    }

    private void leave() {
        if (left) {
            return;
        }
        left = true;
        if (quick) {
            host.showHome();
        } else {
            host.showLock();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        markGlow.cancel();
        super.onDetachedFromWindow();
    }
}
