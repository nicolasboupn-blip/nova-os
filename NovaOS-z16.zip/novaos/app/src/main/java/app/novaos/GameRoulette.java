package app.novaos;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * European roulette (one zero, 37 pockets) with the slot coins. A real wheel with a ball that spins, drops and
 * settles, and the full betting table: any single number (pays 35 to 1), dozens and columns (2 to 1), and the
 * even chances red / black / odd / even / low / high (1 to 1). Zero beats every outside bet.
 * The result is picked fairly at random before the spin, then the animation lands exactly on it.
 */
final class GameRoulette extends Game {
    // wheel order, clockwise from the top
    static final int[] ORDER = {0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5,
        24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26};
    private static final Set<Integer> REDS = new HashSet<>(java.util.Arrays.asList(
            1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36));
    private static final int[] CHIPS = {5, 10, 25, 50, 100};

    // bet ids: 0..36 numbers, then the groups
    private static final int DOZEN = 37;   // 37, 38, 39
    private static final int COLUMN = 40;  // 40, 41, 42
    private static final int LOW = 43;
    private static final int EVEN = 44;
    private static final int RED = 45;
    private static final int BLACK = 46;
    private static final int ODD = 47;
    private static final int HIGH = 48;

    private static final int RED_C = 0xFFC4243F;
    private static final int BLACK_C = 0xFF1A1526;
    private static final int GREEN_C = 0xFF1C9C57;

    private final Random rnd = new Random();
    /** The pocket the next spin will land on. Picked fair and uniform ahead of time, used by cheat mode. */
    private int pending = ORDER[rnd.nextInt(ORDER.length)];
    private final RouletteWheel wheel;
    private final Table table;
    private final TextView coinsText;
    private final TextView totalText;
    private final TextView message;
    private final LinearLayout history;
    private final TextView[] chipViews = new TextView[CHIPS.length];
    private final TextView spinBtn;
    private final Map<Integer, Integer> bets = new LinkedHashMap<>();
    private final List<int[]> undo = new ArrayList<>(); // {id, amount}
    private Map<Integer, Integer> lastBets = new LinkedHashMap<>();
    private int chip = 1;
    private boolean spinning;

    GameRoulette(NovaActivity host) {
        super(host);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(58), dp(10), dp(12));
        android.widget.ScrollView sv = new android.widget.ScrollView(host);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new android.widget.FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(host);
        coinsText = label("", 13f, Theme.TEXT);
        coinsText.setGravity(Gravity.START);
        coinsText.setClickable(true);
        coinsText.setOnClickListener(v -> {
            if (!spinning && coins() < CHIPS[0] && bets.isEmpty()) {
                Prefs.putInt("slot_coins", 100);
                say("+100 free coins", Theme.ACCENT);
                refresh();
            }
        });
        totalText = label("", 13f, Theme.ACCENT);
        totalText.setGravity(Gravity.END);
        top.addView(coinsText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(totalText, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        history = new LinearLayout(host);
        history.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(26));
        hp.topMargin = dp(6);
        col.addView(history, hp);

        wheel = new RouletteWheel(host);
        int side = Math.min(host.getResources().getDisplayMetrics().widthPixels - dp(20), dp(340));
        col.addView(wheel, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, side));

        message = label("PLACE YOUR BETS", 14f, Theme.DIM);
        message.setLetterSpacing(0.1f);
        col.addView(message, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        table = new Table(host);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        col.addView(table, tp);

        LinearLayout chips = new LinearLayout(host);
        chips.setGravity(Gravity.CENTER);
        for (int i = 0; i < CHIPS.length; i++) {
            final int idx = i;
            TextView c = label(String.valueOf(CHIPS[i]), 13f, Theme.TEXT);
            c.setClickable(true);
            c.setOnClickListener(v -> {
                if (!spinning) {
                    chip = idx;
                    styleChips();
                }
            });
            chipViews[i] = c;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(46), dp(46));
            cp.setMargins(dp(5), 0, dp(5), 0);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chp.topMargin = dp(10);
        col.addView(chips, chp);

        LinearLayout buttons = new LinearLayout(host);
        buttons.setGravity(Gravity.CENTER);
        buttons.addView(small(button("UNDO", this::undoBet)));
        buttons.addView(small(button("CLEAR", this::clearBets)));
        buttons.addView(small(button("REBET", this::rebet)));
        spinBtn = button("SPIN", this::spin);
        spinBtn.setTextColor(Theme.BG);
        spinBtn.setBackground(Theme.rounded(Theme.ACCENT, 16f, host));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f);
        sp.setMargins(dp(3), 0, 0, 0);
        buttons.addView(spinBtn, sp);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(10);
        col.addView(buttons, bp);

        styleChips();
        refresh();
    }

    @Override
    String title() {
        return "ROULETTE";
    }

    private View small(TextView b) {
        b.setTextSize(11f);
        b.setPadding(dp(6), dp(12), dp(6), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(0, 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int coins() {
        return Prefs.getInt("slot_coins", 100);
    }

    private int total() {
        int t = 0;
        for (int v : bets.values()) {
            t += v;
        }
        return t;
    }

    /**
     * Cheat mode: only the "COINS" word in the top left tells you the next result.
     * green zero = Coins, red = coins, black = COINS.
     */
    private String cs(String s) {
        if (!Prefs.cheat()) {
            return s;
        }
        if (pending == 0) {
            String l = s.toLowerCase(java.util.Locale.ROOT);
            return Character.toUpperCase(l.charAt(0)) + l.substring(1);
        }
        return REDS.contains(pending) ? s.toLowerCase(java.util.Locale.ROOT) : s.toUpperCase(java.util.Locale.ROOT);
    }

    private void say(String s, int color) {
        message.setText(s);
        message.setTextColor(color);
    }

    private void refresh() {
        int t = total();
        int free = coins() - (spinning ? 0 : t);
        coinsText.setText(cs(coins() < CHIPS[0] && bets.isEmpty() && !spinning ? "TAP: FREE COINS" : "COINS " + free));
        totalText.setText(t > 0 ? "BET " + t : "");
        spinBtn.setAlpha(!spinning && t > 0 ? 1f : 0.4f);
        table.invalidate();
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.length; i++) {
            boolean on = i == chip;
            chipViews[i].setBackground(circle(on ? Theme.ACCENT : 0x33FFFFFF, host));
            chipViews[i].setTextColor(on ? Theme.BG : Theme.TEXT);
            chipViews[i].setScaleX(on ? 1.12f : 1f);
            chipViews[i].setScaleY(on ? 1.12f : 1f);
        }
    }

    private static android.graphics.drawable.GradientDrawable circle(int color, Context c) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    // ------------------------------------------------------------------ betting

    private void place(int id) {
        if (spinning) {
            return;
        }
        int amount = CHIPS[chip];
        if (total() + amount > coins()) {
            say("NOT ENOUGH COINS", 0xFFFF6B7F);
            host.buzz(30);
            return;
        }
        Integer cur = bets.get(id);
        bets.put(id, (cur == null ? 0 : cur) + amount);
        undo.add(new int[] {id, amount});
        host.buzz(8);
        say(describe(id) + "  " + bets.get(id), Theme.TEXT);
        table.clearWin();
        refresh();
    }

    private void undoBet() {
        if (spinning || undo.isEmpty()) {
            return;
        }
        int[] last = undo.remove(undo.size() - 1);
        Integer cur = bets.get(last[0]);
        if (cur != null) {
            if (cur - last[1] <= 0) {
                bets.remove(last[0]);
            } else {
                bets.put(last[0], cur - last[1]);
            }
        }
        refresh();
    }

    private void clearBets() {
        if (spinning) {
            return;
        }
        bets.clear();
        undo.clear();
        table.clearWin();
        say("PLACE YOUR BETS", Theme.DIM);
        refresh();
    }

    private void rebet() {
        if (spinning || lastBets.isEmpty()) {
            return;
        }
        bets.clear();
        undo.clear();
        int t = 0;
        for (Map.Entry<Integer, Integer> e : lastBets.entrySet()) {
            t += e.getValue();
        }
        if (t > coins()) {
            say("NOT ENOUGH COINS TO REPEAT", 0xFFFF6B7F);
            return;
        }
        for (Map.Entry<Integer, Integer> e : lastBets.entrySet()) {
            bets.put(e.getKey(), e.getValue());
            undo.add(new int[] {e.getKey(), e.getValue()});
        }
        table.clearWin();
        say("SAME BETS AGAIN", Theme.TEXT);
        refresh();
    }

    private static String describe(int id) {
        if (id <= 36) {
            return "NUMBER " + id;
        }
        switch (id) {
            case 37:
                return "1ST 12";
            case 38:
                return "2ND 12";
            case 39:
                return "3RD 12";
            case 40:
            case 41:
            case 42:
                return "COLUMN " + (id - 39);
            case LOW:
                return "1-18";
            case EVEN:
                return "EVEN";
            case RED:
                return "RED";
            case BLACK:
                return "BLACK";
            case ODD:
                return "ODD";
            default:
                return "19-36";
        }
    }

    /** Total returned per coin staked (stake included): 36 for a number, 3 for dozens and columns, 2 for even chances. */
    private static int payout(int id, int n) {
        if (id <= 36) {
            return id == n ? 36 : 0;
        }
        if (n == 0) {
            return 0;
        }
        switch (id) {
            case 37:
                return n <= 12 ? 3 : 0;
            case 38:
                return n >= 13 && n <= 24 ? 3 : 0;
            case 39:
                return n >= 25 ? 3 : 0;
            case 40:
                return n % 3 == 1 ? 3 : 0;
            case 41:
                return n % 3 == 2 ? 3 : 0;
            case 42:
                return n % 3 == 0 ? 3 : 0;
            case LOW:
                return n <= 18 ? 2 : 0;
            case HIGH:
                return n >= 19 ? 2 : 0;
            case EVEN:
                return n % 2 == 0 ? 2 : 0;
            case ODD:
                return n % 2 == 1 ? 2 : 0;
            case RED:
                return REDS.contains(n) ? 2 : 0;
            default:
                return !REDS.contains(n) ? 2 : 0;
        }
    }

    static int colorOf(int n) {
        return n == 0 ? GREEN_C : REDS.contains(n) ? RED_C : BLACK_C;
    }

    // ------------------------------------------------------------------ spin

    private void spin() {
        if (spinning || bets.isEmpty()) {
            if (bets.isEmpty() && !spinning) {
                say("PLACE A BET FIRST", 0xFFFF6B7F);
            }
            return;
        }
        final int stake = total();
        if (stake > coins()) {
            say("NOT ENOUGH COINS", 0xFFFF6B7F);
            return;
        }
        spinning = true;
        Prefs.putInt("slot_coins", coins() - stake);
        lastBets = new LinkedHashMap<>(bets);
        final Map<Integer, Integer> placed = new HashMap<>(bets);
        table.clearWin();
        say("NO MORE BETS", Theme.ACCENT);
        refresh();
        final int result = pending; // fair: picked uniformly at random, every pocket equally likely
        host.buzz(30);
        wheel.spin(result, () -> settle(result, stake, placed));
    }

    private void settle(int n, int stake, Map<Integer, Integer> placed) {
        int back = 0;
        Set<Integer> winners = new HashSet<>();
        boolean straight = false;
        for (Map.Entry<Integer, Integer> e : placed.entrySet()) {
            int mult = payout(e.getKey(), n);
            if (mult > 0) {
                back += e.getValue() * mult;
                winners.add(e.getKey());
                if (e.getKey() <= 36) {
                    straight = true;
                }
            }
        }
        Prefs.putInt("slot_coins", coins() + back);
        bets.clear();
        undo.clear();
        spinning = false;
        pending = ORDER[rnd.nextInt(ORDER.length)]; // the next spin, picked fresh
        addHistory(n);
        table.setWin(winners, n);
        int net = back - stake;
        String name = n + (n == 0 ? " GREEN" : REDS.contains(n) ? " RED" : " BLACK");
        if (back > 0) {
            if (net > 0) {
                say(name + "   WIN +" + net, Theme.ACCENT);
                host.buzz(60);
                host.confetti(getWidth() / 2f, getHeight() * 0.35f);
            } else if (net == 0) {
                say(name + "   BACK TO EVEN", Theme.TEXT);
                host.buzz(25);
            } else {
                say(name + "   BACK " + back + " (" + net + ")", Theme.TEXT);
                host.buzz(25);
            }
            if (straight) {
                Badges.unlock(host, "roulette");
            }
        } else {
            say(name + "   LOST " + stake, Theme.DIM);
            host.buzz(20);
        }
        Badges.bump("roulette_spins");
        refresh();
    }

    private void addHistory(int n) {
        TextView t = label(String.valueOf(n), 11f, 0xFFFFFFFF);
        t.setBackground(circle(colorOf(n), host));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(24), dp(24));
        lp.setMargins(dp(2), 0, dp(2), 0);
        history.addView(t, 0, lp);
        while (history.getChildCount() > 10) {
            history.removeViewAt(history.getChildCount() - 1);
        }
    }

    // ================================================================== the wheel

    // ================================================================== the betting table

    private final class Table extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<RectF> rects = new ArrayList<>();
        private final List<Integer> ids = new ArrayList<>();
        private final List<String> labels = new ArrayList<>();
        private Set<Integer> winners = new HashSet<>();
        private int resultNumber = -1;
        private int downCell = -1;
        private float u;

        Table(Context c) {
            super(c);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.CENTER);
        }

        void setWin(Set<Integer> w, int n) {
            winners = w;
            resultNumber = n;
            invalidate();
        }

        void clearWin() {
            winners = new HashSet<>();
            resultNumber = -1;
            invalidate();
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            float unit = w / 14f;
            int h = (int) (unit * 1.2f * 3 + unit * 0.9f * 2 + dp(10));
            setMeasuredDimension(w, h);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            rects.clear();
            ids.clear();
            labels.clear();
            u = w / 14f;
            float rowH = u * 1.2f;
            float gap = dp(2);
            // zero
            add(0, "0", 0, 0, u, rowH * 3);
            // the 36 numbers, top row is 3,6,9...
            for (int r = 0; r < 3; r++) {
                for (int c = 0; c < 12; c++) {
                    int n = (c + 1) * 3 - r;
                    add(n, String.valueOf(n), u + c * u, r * rowH, u, rowH);
                }
                add(COLUMN + (2 - r), "2:1", 13 * u, r * rowH, u, rowH);
            }
            float y2 = rowH * 3 + gap;
            float oh2 = u * 0.9f;
            String[] dz = {"1st 12", "2nd 12", "3rd 12"};
            for (int d = 0; d < 3; d++) {
                add(DOZEN + d, dz[d], u + d * 4 * u, y2, 4 * u, oh2);
            }
            float y3 = y2 + oh2 + gap;
            int[] outIds = {LOW, EVEN, RED, BLACK, ODD, HIGH};
            String[] outLabels = {"1-18", "EVEN", "RED", "BLACK", "ODD", "19-36"};
            for (int i = 0; i < 6; i++) {
                add(outIds[i], outLabels[i], u + i * 2 * u, y3, 2 * u, oh2);
            }
        }

        private void add(int id, String label, float x, float y, float w, float h) {
            float g = dp(1);
            rects.add(new RectF(x + g, y + g, x + w - g, y + h - g));
            ids.add(id);
            labels.add(label);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downCell = hit(e.getX(), e.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                    if (downCell >= 0 && hit(e.getX(), e.getY()) == downCell) {
                        place(ids.get(downCell));
                    }
                    downCell = -1;
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    downCell = -1;
                    return true;
                default:
                    return true;
            }
        }

        private int hit(float x, float y) {
            for (int i = 0; i < rects.size(); i++) {
                if (rects.get(i).contains(x, y)) {
                    return i;
                }
            }
            return -1;
        }

        @Override
        protected void onDraw(Canvas c) {
            for (int i = 0; i < rects.size(); i++) {
                RectF r = rects.get(i);
                int id = ids.get(i);
                int fill;
                if (id <= 36) {
                    int base = colorOf(id);
                    fill = base == BLACK_C ? 0xFF241D36 : base;
                } else if (id == RED) {
                    fill = RED_C;
                } else if (id == BLACK) {
                    fill = 0xFF241D36;
                } else {
                    fill = 0xFF2A2145;
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(fill);
                c.drawRoundRect(r, dp(4), dp(4), p);
                boolean won = winners.contains(id) || (id <= 36 && id == resultNumber);
                if (won) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(2.5f));
                    p.setColor(0xFFFFFFFF);
                    c.drawRoundRect(r, dp(4), dp(4), p);
                    p.setStrokeWidth(dp(6));
                    p.setColor((Theme.ACCENT & 0x00FFFFFF) | 0x55000000);
                    c.drawRoundRect(r, dp(4), dp(4), p);
                }
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFFFFF);
                p.setTextSize(id <= 36 ? u * 0.42f : u * 0.34f);
                String text = labels.get(i);
                if (id >= COLUMN && id < LOW) {
                    p.setTextSize(u * 0.3f);
                }
                c.drawText(text, r.centerX(), r.centerY() + p.getTextSize() * 0.35f, p);
                Integer amount = bets.get(id);
                if (amount != null) {
                    float cr = Math.min(u * 0.4f, r.height() * 0.42f);
                    p.setColor(0xFF000000);
                    c.drawCircle(r.centerX(), r.centerY(), cr + dp(1.5f), p);
                    p.setColor(Theme.ACCENT);
                    c.drawCircle(r.centerX(), r.centerY(), cr, p);
                    p.setColor(Theme.BG);
                    p.setTextSize(cr * (amount >= 1000 ? 0.8f : amount >= 100 ? 0.82f : 1.0f));
                    String t = amount >= 10000 ? (amount / 1000) + "k" : String.valueOf(amount);
                    c.drawText(t, r.centerX(), r.centerY() + p.getTextSize() * 0.35f, p);
                }
            }
        }
    }
}
