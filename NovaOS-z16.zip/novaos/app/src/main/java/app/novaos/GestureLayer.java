package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.gesture.Gesture;
import android.gesture.GestureOverlayView;
import android.gesture.GestureStore;
import android.gesture.Prediction;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * Draw a shape on the screen and NOVA runs what you taught it (an app or an action like spinning the wheel) for that shape. Long-press an empty spot
 * on the home screen to start. Draw something new and NOVA asks which app it should open.
 */
final class GestureLayer extends FrameLayout {
    private static final double MIN_SCORE = 1.8;

    private final NovaActivity host;
    private final GestureStore store;

    GestureLayer(final NovaActivity host) {
        super(host);
        this.host = host;
        this.store = load(host);
        setBackgroundColor(0xEE050309);

        final GestureOverlayView pad = new GestureOverlayView(host);
        pad.setGestureStrokeType(GestureOverlayView.GESTURE_STROKE_TYPE_MULTIPLE);
        pad.setGestureColor(Theme.ACCENT);
        pad.setUncertainGestureColor(Theme.DIM);
        pad.setGestureStrokeWidth(Theme.dp(host, 7));
        pad.setFadeOffset(450);
        pad.setEventsInterceptionEnabled(false);
        pad.addOnGesturePerformedListener((overlay, gesture) -> performed(gesture));
        addView(pad, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView title = mono("DRAW A SHAPE", 13f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        LayoutParams tp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tp.topMargin = Theme.dp(host, 90);
        addView(title, tp);

        TextView hint = mono("a letter, a symbol, anything.\nKnown shape: it runs.\nNew shape: pick an app or an action.", 11f, Theme.DIM);
        hint.setGravity(Gravity.CENTER);
        LayoutParams hp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hp.topMargin = Theme.dp(host, 124);
        addView(hint, hp);

        TextView cancel = mono("CANCEL", 12f, Theme.TEXT);
        cancel.setLetterSpacing(0.2f);
        cancel.setPadding(Theme.dp(host, 24), Theme.dp(host, 16), Theme.dp(host, 24), Theme.dp(host, 16));
        cancel.setClickable(true);
        cancel.setOnClickListener(v -> close());
        LayoutParams cp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        cp.bottomMargin = Theme.dp(host, 56);
        addView(cancel, cp);

        setAlpha(0f);
        animate().alpha(1f).setDuration(220).start();
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void close() {
        host.hideOverlay();
    }

    private void performed(final Gesture gesture) {
        if (gesture.getLength() < Theme.dp(host, 60)) {
            return; // a tap or a short scribble
        }
        ArrayList<Prediction> best = store.recognize(gesture);
        if (!best.isEmpty() && best.get(0).score >= MIN_SCORE) {
            String name = best.get(0).name;
            if (name.startsWith(Actions.PREFIX)) {
                close();
                Actions.run(host, name.substring(Actions.PREFIX.length()));
                return;
            }
            AppEntry e = host.repo.find(name);
            if (e != null) {
                close();
                host.launch(e);
                return;
            }
        }
        teach(gesture);
    }

    /** Asks what the new shape should do (an action or an app), then remembers it. */
    private void teach(final Gesture gesture) {
        host.repo.ensureFresh();
        final java.util.List<AppEntry> apps = host.repo.all;
        final int na = Actions.IDS.length;
        String[] names = new String[na + apps.size()];
        for (int i = 0; i < na; i++) {
            names[i] = Actions.LABELS[i];
        }
        for (int i = 0; i < apps.size(); i++) {
            names[na + i] = apps.get(i).label;
        }
        new AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("New shape. What should it do?")
                .setItems(names, (d, which) -> {
                    if (which < na) {
                        store.addGesture(Actions.PREFIX + Actions.IDS[which], gesture);
                        host.toast("Learned it: " + Actions.LABELS[which].replace("⚡ ", ""));
                    } else {
                        store.addGesture(apps.get(which - na).pkg, gesture);
                        host.toast("Learned it: " + apps.get(which - na).label);
                    }
                    save(host, store);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ------------------------------------------------------------------ storage

    private static File file(Context c) {
        return new File(c.getFilesDir(), "nova.gestures");
    }

    static GestureStore load(Context c) {
        GestureStore s = new GestureStore();
        File f = file(c);
        if (f.exists()) {
            try (FileInputStream in = new FileInputStream(f)) {
                s.load(in, false);
            } catch (Exception ignored) {
                // start empty if the file is damaged
            }
        }
        return s;
    }

    static void save(Context c, GestureStore s) {
        try (FileOutputStream out = new FileOutputStream(file(c))) {
            s.save(out, false);
        } catch (Exception ignored) {
            // could not write, the shape is lost next time
        }
    }

    static int count(Context c) {
        return load(c).getGestureEntries().size();
    }

    static void clear(Context c) {
        file(c).delete();
    }
}
