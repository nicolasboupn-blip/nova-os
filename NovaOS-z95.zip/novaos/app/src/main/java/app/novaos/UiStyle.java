package app.novaos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.FrameLayout;

/**
 * The look of the whole OS: NORMAL (the old NOVA), AURORA (frosted glass and moving light), TERMINAL (a green screen with
 * scan lines), BLOCK (hard edges, thick pink outlines, dot grid) and MY STYLE, which you design yourself. A style sets
 * the colours, how round the corners are, borders, how see-through panels are, the font and the background effects.
 * Theme reads all of it, so every screen follows without being changed one by one.
 */
final class UiStyle {
    private UiStyle() {}

    static final String K_STYLE = "ui_style";
    static final String K_DESIGNER = "ui_designer";
    static final String K_DARK = "ui_forcedark";
    static final String[] NAMES = {"Normal", "Aurora", "Terminal", "Block", "My style", "Synthwave", "Ocean", "Inferno",
        "Galaxy"};

    static final int NORMAL = 0, AURORA = 1, TERMINAL = 2, BLOCK = 3, CUSTOM = 4, SYNTH = 5, OCEAN = 6, INFERNO = 7,
        GALAXY = 8;

    /** The fonts you can pick for your own style. */
    static final String[] FONTS = {"Mono", "Clean", "Light", "Condensed", "Serif", "Casual", "Black"};

    // order in a palette: bg, bg2, panel, accent, glow, text, dim
    static final int[] P_AURORA = {0xFF070B1E, 0xFF1B1346, 0xFF1E2552, 0xFF7DF9E1, 0xFFB07CFF, 0xFFF4F7FF, 0xFF9AA6D6};
    static final int[] P_TERMINAL = {0xFF010603, 0xFF03120A, 0xFF07180E, 0xFF39FF88, 0xFF00D26A, 0xFFC9FFDB, 0xFF4C9A6B};
    static final int[] P_BLOCK = {0xFF0A0A0F, 0xFF14141C, 0xFF1C1C28, 0xFFFFE14D, 0xFFFF4D8D, 0xFFFFFFFF, 0xFFB0B0C8};

    static final int[] P_SYNTH = {0xFF0D0221, 0xFF2B0A4D, 0xFF2A1250, 0xFFFF4FD8, 0xFF2DE2E6, 0xFFFFEFFF, 0xFFC49BE8};
    static final int[] P_OCEAN = {0xFF031826, 0xFF0B4F6C, 0xFF0E3A52, 0xFF5CF2D6, 0xFF35A7FF, 0xFFEAFBFF, 0xFF8EC5D6};
    static final int[] P_INFERNO = {0xFF0E0302, 0xFF2B0905, 0xFF2A100B, 0xFFFF7A1A, 0xFFFF3B1F, 0xFFFFF1E6, 0xFFC99A82};
    static final int[] P_GALAXY = {0xFF04030F, 0xFF150B33, 0xFF1B1240, 0xFFB892FF, 0xFFFF7BD5, 0xFFF3EEFF, 0xFFA79CD6};

    // the look settings of the three built in styles: radius %, border (half dp), border colour, glass %, font, fx bits
    static final int FX_SCAN = 1, FX_AURORA = 2, FX_DOTS = 4;

    // what is active right now
    static int id;
    static float radiusScale = 1f;
    static float borderDp;
    static int borderColor;
    static float glass = 1f;
    static int fx;
    static int scene; // 0 none, 1 synthwave, 2 ocean, 3 inferno, 4 galaxy: a full moving picture behind everything
    private static Typeface font;
    private static boolean animating;

    static boolean designerOn() {
        return Prefs.getBool(K_DESIGNER, false);
    }

    static int chosen() {
        int s = Prefs.getInt(K_STYLE, 0);
        if (s == CUSTOM && !designerOn()) {
            return NORMAL; // my style is hidden while the designer is off
        }
        return Math.max(0, Math.min(NAMES.length - 1, s));
    }

    static Typeface fontOf(int i) {
        switch (i) {
            case 1:
                return Typeface.create("sans-serif", Typeface.NORMAL);
            case 2:
                return Typeface.create("sans-serif-light", Typeface.NORMAL);
            case 3:
                return Typeface.create("sans-serif-condensed", Typeface.BOLD);
            case 4:
                return Typeface.create("serif", Typeface.NORMAL);
            case 5:
                return Typeface.create("casual", Typeface.NORMAL);
            case 6:
                return Typeface.create("sans-serif-black", Typeface.NORMAL);
            default:
                return Typeface.MONOSPACE;
        }
    }

    // ------------------------------------------------------------------ your own style

    private static final String[] CK = {"ui_c_bg", "ui_c_bg2", "ui_c_panel", "ui_c_accent", "ui_c_glow", "ui_c_text",
        "ui_c_dim"};

    static int customColor(int i) {
        return Prefs.getInt(CK[i], P_AURORA[i]);
    }

    static void setCustomColor(int i, int c) {
        Prefs.putInt(CK[i], 0xFF000000 | c);
    }

    static final String K_RADIUS = "ui_c_radius", K_BORDER = "ui_c_border", K_BCOL = "ui_c_bcol", K_GLASS = "ui_c_glass",
        K_FONT = "ui_c_font", K_FX = "ui_c_fx";

    /** Copies one of the built in styles into MY STYLE so you can change it. */
    static void copyInto(int style) {
        int[] p = style == TERMINAL ? P_TERMINAL : style == BLOCK ? P_BLOCK : P_AURORA;
        for (int i = 0; i < 7; i++) {
            Prefs.putInt(CK[i], p[i]);
        }
        if (style == TERMINAL) {
            Prefs.putInt(K_RADIUS, 10);
            Prefs.putInt(K_BORDER, 2);
            Prefs.putInt(K_BCOL, 0x8839FF88);
            Prefs.putInt(K_GLASS, 100);
            Prefs.putInt(K_FONT, 0);
            Prefs.putInt(K_FX, FX_SCAN);
        } else if (style == BLOCK) {
            Prefs.putInt(K_RADIUS, 25);
            Prefs.putInt(K_BORDER, 4);
            Prefs.putInt(K_BCOL, 0xFFFF4D8D);
            Prefs.putInt(K_GLASS, 100);
            Prefs.putInt(K_FONT, 3);
            Prefs.putInt(K_FX, FX_DOTS);
        } else {
            Prefs.putInt(K_RADIUS, 170);
            Prefs.putInt(K_BORDER, 2);
            Prefs.putInt(K_BCOL, 0x33FFFFFF);
            Prefs.putInt(K_GLASS, 62);
            Prefs.putInt(K_FONT, 1);
            Prefs.putInt(K_FX, FX_AURORA);
        }
    }

    /** One line that holds the whole style, to send to a friend. */
    static String exportCode() {
        StringBuilder sb = new StringBuilder("NOVASTYLE1");
        for (int i = 0; i < 7; i++) {
            sb.append('|').append(Integer.toHexString(customColor(i)));
        }
        sb.append('|').append(Prefs.getInt(K_RADIUS, 100));
        sb.append('|').append(Prefs.getInt(K_BORDER, 0));
        sb.append('|').append(Integer.toHexString(Prefs.getInt(K_BCOL, 0x33FFFFFF)));
        sb.append('|').append(Prefs.getInt(K_GLASS, 100));
        sb.append('|').append(Prefs.getInt(K_FONT, 0));
        sb.append('|').append(Prefs.getInt(K_FX, 0));
        return sb.toString();
    }

    /** Reads a code made by exportCode. Returns false if it is not a NOVA style code. */
    static boolean importCode(String code) {
        try {
            String[] p = code.trim().split("\\|");
            if (p.length != 14 || !p[0].equals("NOVASTYLE1")) {
                return false;
            }
            int[] col = new int[7];
            for (int i = 0; i < 7; i++) {
                col[i] = (int) Long.parseLong(p[1 + i], 16);
            }
            int radius = Integer.parseInt(p[8]);
            int border = Integer.parseInt(p[9]);
            int bcol = (int) Long.parseLong(p[10], 16);
            int glassPct = Integer.parseInt(p[11]);
            int fontId = Integer.parseInt(p[12]);
            int fxBits = Integer.parseInt(p[13]);
            for (int i = 0; i < 7; i++) {
                Prefs.putInt(CK[i], 0xFF000000 | col[i]);
            }
            Prefs.putInt(K_RADIUS, Math.max(0, Math.min(200, radius)));
            Prefs.putInt(K_BORDER, Math.max(0, Math.min(8, border)));
            Prefs.putInt(K_BCOL, bcol);
            Prefs.putInt(K_GLASS, Math.max(30, Math.min(100, glassPct)));
            Prefs.putInt(K_FONT, Math.max(0, Math.min(FONTS.length - 1, fontId)));
            Prefs.putInt(K_FX, fxBits & 7);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ applying

    /** Called by Theme.load(): replaces the palette and the look numbers when a style other than Normal is chosen. */
    static void apply() {
        id = chosen();
        radiusScale = 1f;
        borderDp = 0f;
        borderColor = 0;
        glass = 1f;
        fx = 0;
        scene = 0;
        font = null;
        int[] p = null;
        switch (id) {
            case AURORA:
                p = P_AURORA;
                radiusScale = 1.7f;
                borderDp = 1f;
                borderColor = 0x33FFFFFF;
                glass = 0.62f;
                font = fontOf(1);
                fx = FX_AURORA;
                break;
            case TERMINAL:
                p = P_TERMINAL;
                radiusScale = 0.1f;
                borderDp = 1f;
                borderColor = 0x8839FF88;
                font = fontOf(0);
                fx = FX_SCAN;
                break;
            case BLOCK:
                p = P_BLOCK;
                radiusScale = 0.25f;
                borderDp = 2f;
                borderColor = 0xFFFF4D8D;
                font = fontOf(3);
                fx = FX_DOTS;
                break;
            case SYNTH:
                p = P_SYNTH;
                radiusScale = 1.4f;
                borderDp = 1.5f;
                borderColor = 0x99FF4FD8;
                glass = 0.55f;
                font = fontOf(6);
                scene = 1;
                break;
            case OCEAN:
                p = P_OCEAN;
                radiusScale = 1.8f;
                borderDp = 1f;
                borderColor = 0x335CF2D6;
                glass = 0.6f;
                font = fontOf(1);
                scene = 2;
                break;
            case INFERNO:
                p = P_INFERNO;
                radiusScale = 0.8f;
                borderDp = 1.5f;
                borderColor = 0xAAFF7A1A;
                glass = 0.8f;
                font = fontOf(3);
                scene = 3;
                break;
            case GALAXY:
                p = P_GALAXY;
                radiusScale = 1.5f;
                borderDp = 1f;
                borderColor = 0x44B892FF;
                glass = 0.55f;
                font = fontOf(2);
                scene = 4;
                break;
            case CUSTOM:
                p = new int[7];
                for (int i = 0; i < 7; i++) {
                    p[i] = customColor(i);
                }
                radiusScale = Prefs.getInt(K_RADIUS, 100) / 100f;
                borderDp = Prefs.getInt(K_BORDER, 0) * 0.5f;
                borderColor = Prefs.getInt(K_BCOL, 0x33FFFFFF);
                glass = Math.max(0.3f, Math.min(1f, Prefs.getInt(K_GLASS, 100) / 100f));
                font = fontOf(Prefs.getInt(K_FONT, 0));
                fx = Prefs.getInt(K_FX, 0) & 7;
                break;
            default:
                break;
        }
        if (forceDark()) {
            if (p == null) {
                p = new int[] {Theme.BG, Theme.BG2, Theme.PANEL, Theme.ACCENT, Theme.GLOW, Theme.TEXT, Theme.DIM};
            }
            p = darken(p);
        }
        if (p != null) {
            Theme.BG = p[0];
            Theme.BG2 = p[1];
            Theme.PANEL = p[2];
            Theme.ACCENT = p[3];
            Theme.GLOW = p[4];
            Theme.TEXT = p[5];
            Theme.DIM = p[6];
        }
        Theme.MONO = font != null ? font : Typeface.MONOSPACE;
    }

    static boolean forceDark() {
        return Prefs.getBool(K_DARK, false);
    }

    private static int hsv(int c, float maxS, float minV, float maxV) {
        float[] h = new float[3];
        Color.colorToHSV(c, h);
        h[1] = Math.min(h[1], maxS);
        h[2] = Math.max(minV, Math.min(maxV, h[2]));
        return Color.HSVToColor(0xFF, h);
    }

    /** Force dark mode: backgrounds and panels get dark, text gets light, accents stay bright. Hue is kept. */
    private static int[] darken(int[] p) {
        int[] o = new int[7];
        o[0] = hsv(p[0], 0.9f, 0f, 0.09f);
        o[1] = hsv(p[1], 0.9f, 0f, 0.17f);
        o[2] = hsv(p[2], 0.85f, 0f, 0.21f);
        o[3] = hsv(p[3], 1f, 0.72f, 1f);
        o[4] = hsv(p[4], 1f, 0.6f, 1f);
        o[5] = hsv(p[5], 0.18f, 0.92f, 1f);
        o[6] = hsv(p[6], 0.25f, 0.58f, 0.78f);
        return o;
    }

    /** The colour a panel is filled with: frosted (see-through) when the style says so. */
    static int fill(int color) {
        if (glass < 1f && color == Theme.PANEL) {
            return (color & 0xFFFFFF) | (Math.round(glass * 255) << 24);
        }
        return color;
    }

    /** Adds the border of the style to a rounded shape. */
    static void border(GradientDrawable g, Context c, int color) {
        if (borderDp > 0f && (color >>> 24) > 0x30) {
            g.setStroke(Math.max(1, Theme.dp(c, borderDp)), borderColor);
        }
    }

    // ------------------------------------------------------------------ background and effects

    private static AuroraDrawable aurora;

    /** The background of the whole OS for the active style. */
    static Drawable background() {
        Drawable d = rawBackground();
        if (forceDark() && scene != 0) {
            return new android.graphics.drawable.LayerDrawable(new Drawable[] {d,
                new android.graphics.drawable.ColorDrawable(0xAA000000)});
        }
        return d;
    }

    private static Drawable rawBackground() {
        if (aurora != null) {
            aurora.stop();
            aurora = null;
        }
        if (scene != 0) {
            return new SceneDrawable(scene);
        }
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Theme.BG2, Theme.BG});
        if ((fx & FX_AURORA) != 0) {
            aurora = new AuroraDrawable();
            return aurora;
        }
        if ((fx & FX_DOTS) != 0) {
            return new DotsDrawable();
        }
        return base;
    }

    /** Puts the scan lines (if the style has them) above everything. */
    static void decorate(FrameLayout root) {
        root.setForeground((fx & FX_SCAN) != 0 ? new ScanDrawable() : null);
    }

    /** Slow moving light behind everything: three soft colour clouds drifting over a dark gradient. */
    private static final class AuroraDrawable extends Drawable {
        private final Paint base = new Paint();
        private final Paint[] cloud = new Paint[3];
        private final float[] r = new float[3];
        private final Handler h = new Handler(Looper.getMainLooper());
        private boolean running = true;
        private final long t0 = SystemClock.uptimeMillis();
        private final Runnable tick = new Runnable() {
            @Override
            public void run() {
                if (!running || getCallback() == null) {
                    running = false;
                    return;
                }
                invalidateSelf();
                h.postDelayed(this, Saver.on() ? 2000 : 60);
            }
        };

        AuroraDrawable() {
            for (int i = 0; i < 3; i++) {
                cloud[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
            }
            h.postDelayed(tick, 100);
        }

        void stop() {
            running = false;
        }

        @Override
        protected void onBoundsChange(Rect b) {
            base.setShader(new LinearGradient(0, 0, b.width() * 0.4f, b.height(), Theme.BG2, Theme.BG,
                    Shader.TileMode.CLAMP));
            int[] cols = {Theme.ACCENT, Theme.GLOW, 0xFF3F7CFF};
            for (int i = 0; i < 3; i++) {
                r[i] = Math.max(b.width(), b.height()) * (0.45f + 0.08f * i);
                cloud[i].setShader(new RadialGradient(0, 0, r[i], (cols[i] & 0xFFFFFF) | 0x40000000,
                        cols[i] & 0xFFFFFF, Shader.TileMode.CLAMP));
            }
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.isEmpty()) {
                return;
            }
            c.drawRect(b, base);
            float t = Saver.on() ? 0f : (SystemClock.uptimeMillis() - t0) / 1000f;
            for (int i = 0; i < 3; i++) {
                float x = b.width() * (0.5f + 0.42f * (float) Math.sin(t * (0.07f + 0.03f * i) + i * 2.1f));
                float y = b.height() * (0.5f + 0.42f * (float) Math.cos(t * (0.05f + 0.025f * i) + i * 1.3f));
                c.save();
                c.translate(x, y);
                c.drawCircle(0, 0, r[i], cloud[i]);
                c.restore();
            }
        }

        @Override
        public void setAlpha(int a) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }

    /** Full moving pictures for the four rich styles: synthwave sunset, ocean, inferno, galaxy. */
    private static final class SceneDrawable extends Drawable {
        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Handler h = new Handler(Looper.getMainLooper());
        private final long t0 = SystemClock.uptimeMillis();
        private final android.graphics.Path path = new android.graphics.Path();
        private boolean running = true;
        private final Runnable tick = new Runnable() {
            @Override
            public void run() {
                if (!running || getCallback() == null) {
                    running = false;
                    return;
                }
                invalidateSelf();
                h.postDelayed(this, Saver.on() ? 2000 : 45);
            }
        };

        SceneDrawable(int kind) {
            this.kind = kind;
            h.postDelayed(tick, 100);
        }

        private float rnd(int i, int k) {
            double x = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453;
            return (float) (x - Math.floor(x));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.isEmpty()) {
                return;
            }
            float w = b.width();
            float hh = b.height();
            float t = Saver.on() ? 0f : (SystemClock.uptimeMillis() - t0) / 1000f;
            switch (kind) {
                case 1:
                    synth(c, w, hh, t);
                    break;
                case 2:
                    ocean(c, w, hh, t);
                    break;
                case 3:
                    inferno(c, w, hh, t);
                    break;
                default:
                    galaxy(c, w, hh, t);
                    break;
            }
        }

        private void synth(Canvas c, float w, float h, float t) {
            float hor = h * 0.58f;
            p.setShader(new LinearGradient(0, 0, 0, hor, new int[] {0xFF0D0221, 0xFF5A1470, 0xFFFF6A3C}, null,
                    Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, hor, p);
            p.setShader(null);
            for (int i = 0; i < 40; i++) {
                float a = 0.4f + 0.6f * (float) Math.abs(Math.sin(t * (0.6f + rnd(i, 3)) + i));
                p.setColor(Color.argb((int) (a * 200), 255, 255, 255));
                c.drawCircle(rnd(i, 1) * w, rnd(i, 2) * hor * 0.7f, 1.2f + rnd(i, 4), p);
            }
            float sr = w * 0.26f;
            p.setShader(new LinearGradient(0, hor - sr * 2, 0, hor, 0xFFFFE066, 0xFFFF2E93, Shader.TileMode.CLAMP));
            c.drawCircle(w / 2f, hor - sr * 0.15f, sr, p);
            p.setShader(null);
            p.setColor(0xFF2B0A4D);
            for (int i = 0; i < 7; i++) {
                float y = hor - sr * 0.9f + i * sr * 0.2f + (t * 6f % (sr * 0.2f));
                c.drawRect(w / 2f - sr, y, w / 2f + sr, y + sr * 0.03f * (i + 1), p);
            }
            p.setColor(0xFF14002B);
            c.drawRect(0, hor, w, h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f);
            p.setColor(0xCCFF4FD8);
            for (int i = 0; i < 12; i++) {
                float f = ((i + (t * 0.35f % 1f)) / 12f);
                float y = hor + (h - hor) * f * f;
                c.drawLine(0, y, w, y, p);
            }
            for (int i = -10; i <= 10; i++) {
                c.drawLine(w / 2f + i * w * 0.02f, hor, w / 2f + i * w * 0.22f, h, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, hor - 6, 0, hor + 24, 0xAAFF4FD8, 0x00FF4FD8, Shader.TileMode.CLAMP));
            c.drawRect(0, hor - 6, w, hor + 24, p);
            p.setShader(null);
        }

        private void ocean(Canvas c, float w, float h, float t) {
            p.setShader(new LinearGradient(0, 0, 0, h, 0xFF0B6A88, 0xFF021320, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            for (int i = 0; i < 4; i++) {
                float x = w * (0.15f + i * 0.25f) + (float) Math.sin(t * 0.3f + i) * w * 0.06f;
                path.reset();
                path.moveTo(x - 20, 0);
                path.lineTo(x + 40, 0);
                path.lineTo(x + w * 0.2f, h * 0.8f);
                path.lineTo(x - w * 0.12f, h * 0.8f);
                path.close();
                p.setColor(0x14BFFFF0);
                c.drawPath(path, p);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f);
            for (int i = 0; i < 26; i++) {
                float f = (t * (0.04f + rnd(i, 3) * 0.08f) + rnd(i, 2)) % 1f;
                float r = 3f + rnd(i, 4) * 10f;
                p.setColor(Color.argb((int) ((1f - f) * 150), 200, 255, 245));
                c.drawCircle(rnd(i, 1) * w + (float) Math.sin(t + i) * 12f, h - f * (h + r), r, p);
            }
            p.setStyle(Paint.Style.FILL);
            int[] cols = {0x55128F9E, 0x66107A8C, 0x880B5E70};
            for (int k = 0; k < 3; k++) {
                path.reset();
                path.moveTo(0, h);
                for (float x = 0; x <= w + 16; x += 16) {
                    float y = h * (0.88f - 0.04f * k) + (float) Math.sin(x / (w / 3f) + t * (0.8f + k * 0.3f) + k * 2) * 14f;
                    path.lineTo(x, y);
                }
                path.lineTo(w, h);
                path.close();
                p.setColor(cols[k]);
                c.drawPath(path, p);
            }
        }

        private void inferno(Canvas c, float w, float h, float t) {
            p.setShader(new LinearGradient(0, 0, 0, h, 0xFF0A0201, 0xFF3A0A03, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            float flick = 0.85f + 0.15f * (float) Math.sin(t * 7f) * (float) Math.sin(t * 3.1f);
            p.setShader(new RadialGradient(w / 2f, h * 1.02f, h * 0.75f * flick, 0xCCFF5A1F, 0x00FF5A1F,
                    Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            for (int i = 0; i < 55; i++) {
                float sp = 0.06f + rnd(i, 5) * 0.14f;
                float f = (t * sp + rnd(i, 2)) % 1f;
                float x = rnd(i, 1) * w + (float) Math.sin(t * 1.3f + i) * 14f;
                int a = (int) ((1f - f) * 230 * (0.6f + 0.4f * Math.abs(Math.sin(t * 8f + i))));
                p.setColor(Color.argb(a, 255, 120 + (int) (rnd(i, 7) * 100), 30));
                c.drawCircle(x, h - f * h * 0.95f, 1.5f + rnd(i, 4) * 3.5f, p);
            }
        }

        private void galaxy(Canvas c, float w, float h, float t) {
            c.drawColor(0xFF04030F);
            int[] cols = {0xFF5B2DE0, 0xFFD43FA5, 0xFF2D6BFF};
            for (int i = 0; i < 3; i++) {
                float x = w * (0.5f + 0.38f * (float) Math.sin(t * (0.03f + 0.012f * i) + i * 2f));
                float y = h * (0.5f + 0.38f * (float) Math.cos(t * (0.025f + 0.01f * i) + i));
                float r = Math.max(w, h) * (0.5f + 0.1f * i);
                p.setShader(new RadialGradient(x, y, r, (cols[i] & 0xFFFFFF) | 0x55000000, cols[i] & 0xFFFFFF,
                        Shader.TileMode.CLAMP));
                c.drawCircle(x, y, r, p);
            }
            p.setShader(null);
            for (int i = 0; i < 110; i++) {
                float layer = 0.3f + rnd(i, 6);
                float x = (rnd(i, 1) * w + t * 2f * layer) % w;
                float a = 0.35f + 0.65f * (float) Math.abs(Math.sin(t * (0.5f + rnd(i, 3) * 2f) + i));
                p.setColor(Color.argb((int) (a * 255), 255, 255, 255));
                c.drawCircle(x, rnd(i, 2) * h, 0.6f + layer, p);
            }
            float cyc = (t % 7f) / 1.1f;
            if (cyc < 1f) {
                float sx = w * (0.9f - cyc * 0.8f);
                float sy = h * (0.1f + cyc * 0.25f);
                p.setShader(new LinearGradient(sx, sy, sx + 90, sy - 30, 0xFFFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
                p.setStrokeWidth(3f);
                c.drawLine(sx, sy, sx + 90, sy - 30, p);
                p.setShader(null);
            }
        }

        @Override
        public void setAlpha(int a) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }

    /** A flat dark background with a grid of small dots, like graph paper. */
    private static final class DotsDrawable extends Drawable {
        private final Paint fill = new Paint();
        private final Paint dots = new Paint();

        DotsDrawable() {
            int s = 48;
            Bitmap tile = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas tc = new Canvas(tile);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x30000000);
            tc.drawCircle(s / 2f, s / 2f, 2.5f, p);
            dots.setShader(new android.graphics.BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
            fill.setColor(Theme.BG);
        }

        @Override
        public void draw(Canvas c) {
            c.drawRect(getBounds(), fill);
            c.drawRect(getBounds(), dots);
        }

        @Override
        public void setAlpha(int a) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }

    /** Thin dark lines across the whole screen and a darker rim, like an old monitor. Drawn above everything. */
    private static final class ScanDrawable extends Drawable {
        private final Paint line = new Paint();
        private final Paint rim = new Paint();

        ScanDrawable() {
            line.setColor(0x26000000);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            rim.setShader(new RadialGradient(b.centerX(), b.centerY(), Math.max(b.width(), b.height()) * 0.75f,
                    0x00000000, 0x77000000, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, rim);
            float step = Math.max(3f, b.height() / 320f);
            for (float y = 0; y < b.height(); y += step * 2f) {
                c.drawRect(0, y, b.width(), y + step * 0.7f, line);
            }
        }

        @Override
        public void setAlpha(int a) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    /** A colour with the alpha changed. */
    static int withAlpha(int c, int a) {
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c));
    }
}
