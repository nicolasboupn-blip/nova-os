package app.novaos;

import android.content.Intent;
import android.net.Uri;
import android.os.BatteryManager;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** A widget you build yourself from blocks in the WIDGET BUILDER (settings). Three slots: MY WIDGET 1 to 3. */
final class CustomWidget extends NovaWidget {
    static final String[] TYPES = {"Text", "Clock", "Date", "Battery bar", "Button", "Counter", "Day progress",
        "Scene status", "Top song", "Line", "Space"};

    static final class Block {
        int type;
        String a = "";
        String b = "";
    }

    private final int slot;
    private boolean clock;

    CustomWidget(NovaActivity host, int slot) {
        super(host);
        this.slot = slot;
    }

    static String key(int slot) {
        return "mw_" + slot;
    }

    static List<Block> load(int slot) {
        List<Block> out = new ArrayList<>();
        String raw = Prefs.getString(key(slot), "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String l : raw.split("\n")) {
            String[] p = l.split("\t", -1);
            try {
                Block b = new Block();
                b.type = Math.max(0, Math.min(TYPES.length - 1, Integer.parseInt(p[0])));
                b.a = p.length > 1 ? p[1] : "";
                b.b = p.length > 2 ? p[2] : "";
                out.add(b);
            } catch (NumberFormatException ignored) {
                // skip a broken line
            }
        }
        return out;
    }

    static void save(int slot, List<Block> blocks) {
        StringBuilder sb = new StringBuilder();
        for (Block b : blocks) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(b.type).append('\t').append(clean(b.a)).append('\t').append(clean(b.b));
        }
        Prefs.putString(key(slot), sb.toString());
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    @Override
    long tickMs() {
        return clock ? 1000 : 30000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        removeAllViews();
        List<Block> blocks = load(slot);
        clock = false;
        if (blocks.isEmpty()) {
            addView(text("MY WIDGET " + slot + " is empty. Settings > PROFILE & SCENES > WIDGET BUILDER.", 10f,
                    Theme.DIM), wide());
            return;
        }
        for (int i = 0; i < blocks.size(); i++) {
            final Block b = blocks.get(i);
            final int idx = i;
            switch (b.type) {
                case 0: {
                    TextView t = text(b.a, size(b.b, 14f), Theme.TEXT);
                    addView(t, wide());
                    break;
                }
                case 1:
                    clock = true;
                    addView(text(new SimpleDateFormat(b.a.equals("12") ? "h:mm a" : "HH:mm:ss", Locale.getDefault())
                            .format(new Date()), 34f, Theme.TEXT), wide());
                    break;
                case 2:
                    addView(text(new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date()), 14f,
                            Theme.TEXT), wide());
                    break;
                case 3:
                    addView(bar("BATTERY", battery(), Theme.ACCENT), wide());
                    break;
                case 4: {
                    TextView c = chip(b.a.isEmpty() ? "BUTTON" : b.a, () -> press(b));
                    addView(c, wide());
                    break;
                }
                case 5: {
                    final String k = "mwc_" + slot + "_" + idx;
                    final TextView c = chip(b.a + "  " + Prefs.getInt(k, 0), null);
                    c.setOnClickListener(v -> {
                        Prefs.putInt(k, Prefs.getInt(k, 0) + 1);
                        c.setText(b.a + "  " + Prefs.getInt(k, 0));
                        host.buzz(12);
                    });
                    c.setOnLongClickListener(v -> {
                        Prefs.putInt(k, 0);
                        c.setText(b.a + "  0");
                        return true;
                    });
                    addView(c, wide());
                    break;
                }
                case 6: {
                    Calendar c = Calendar.getInstance();
                    int pct = (c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)) * 100 / 1440;
                    addView(bar("DAY " + pct + "%", pct, Theme.ACCENT), wide());
                    break;
                }
                case 7:
                    addView(text(Scenes.status().isEmpty() ? "no scene on" : Scenes.status(), 14f, Theme.ACCENT),
                            wide());
                    break;
                case 8: {
                    List<SongLog.Song> top = SongLog.top(3, 1);
                    addView(text(top.isEmpty() ? "no songs yet" : "♪ " + top.get(0).title, 13f, Theme.TEXT), wide());
                    break;
                }
                case 9: {
                    android.view.View line = new android.view.View(host);
                    line.setBackgroundColor(0x33FFFFFF);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
                    lp.topMargin = dp(6);
                    lp.bottomMargin = dp(6);
                    addView(line, lp);
                    break;
                }
                default:
                    addView(new android.view.View(host), new LinearLayout.LayoutParams(-1, dp(14)));
                    break;
            }
        }
    }

    private float size(String s, float def) {
        try {
            return Math.max(8f, Math.min(60f, Float.parseFloat(s)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private int battery() {
        try {
            BatteryManager bm = (BatteryManager) host.getSystemService(android.content.Context.BATTERY_SERVICE);
            return Math.max(0, Math.min(100, bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    private LinearLayout bar(String label, int pct, int color) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(VERTICAL);
        TextView l = text(label.equals("BATTERY") ? "BATTERY " + pct + "%" : label, 10f, Theme.DIM);
        l.setGravity(Gravity.START);
        c.addView(l);
        ProgressBar pb = new ProgressBar(host, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgress(pct);
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        c.addView(pb, new LinearLayout.LayoutParams(-1, dp(8)));
        return c;
    }

    private void press(Block b) {
        String t = b.b.trim();
        if (t.isEmpty()) {
            host.toast("This button has no target yet");
            return;
        }
        try {
            if (t.toLowerCase(Locale.ROOT).startsWith("scene:")) {
                String n = t.substring(6).trim();
                List<Scenes.Scene> all = Scenes.all();
                for (int i = 0; i < all.size(); i++) {
                    if (all.get(i).name.equalsIgnoreCase(n)) {
                        Scenes.apply(host, i);
                        return;
                    }
                }
                host.toast("No scene called " + n);
            } else if (t.contains(":") || t.contains("/")) {
                DeckBinds.playLink(host, t);
            } else {
                Intent i = host.getPackageManager().getLaunchIntentForPackage(t);
                if (i == null) {
                    host.toast("No app with that package");
                } else {
                    host.startActivity(i);
                }
            }
        } catch (RuntimeException e) {
            host.toast("Could not do that");
        }
    }
}
