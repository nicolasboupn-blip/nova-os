package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.MediaRecorder;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** ECHO WALLS widget: your echoes nearby, ＋ ECHO HERE, and (⤢) a big view with MAP, RADAR and LIST. */
final class EchoWidget extends NovaWidget {
    private static final int GLOW = 0xFF7CF5FF;
    private static final int GOLD = 0xFFFFC94D;

    private final boolean big;
    private final TextView head;
    private final LinearLayout near;
    private LinearLayout body;
    private TextView[] tabs;
    private int tab;
    private Location me;
    private float azimuth;
    private boolean compass;
    private SensorManager sm;
    private final SensorEventListener sensor = new SensorEventListener() {
        private final float[] rot = new float[9];
        private final float[] ori = new float[3];

        @Override
        public void onSensorChanged(SensorEvent e) {
            SensorManager.getRotationMatrixFromVector(rot, e.values);
            SensorManager.getOrientation(rot, ori);
            azimuth = (float) Math.toDegrees(ori[0]);
            compass = true;
            if (radar != null) {
                radar.invalidate();
            }
        }

        @Override
        public void onAccuracyChanged(Sensor s, int a) {
        }
    };
    private RadarView radar;
    private MapView map;
    private final Runnable onChange = this::changed;

    private void changed() {
        refresh();
        if (big) {
            showTab(tab);
        }
    }

    EchoWidget(NovaActivity host) {
        this(host, false);
    }

    EchoWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        head = text("", 12f, GLOW);
        head.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        head.setPadding(dp(4), 0, dp(4), 0);
        top.addView(head, weight(1f));
        if (!big) {
            top.addView(chip("⤢", this::openBig), new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                    LayoutParams.WRAP_CONTENT));
        }
        addView(top, wide());
        near = new LinearLayout(host);
        near.setOrientation(VERTICAL);
        if (big) {
            LinearLayout t = row();
            String[] names = {"MAP", "RADAR", "LIST"};
            tabs = new TextView[3];
            for (int i = 0; i < 3; i++) {
                final int k = i;
                tabs[i] = chip(names[i], () -> showTab(k));
                t.addView(tabs[i], weight(1f));
            }
            addView(t, wide());
            body = new LinearLayout(host);
            body.setOrientation(VERTICAL);
            addView(body, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        } else {
            addView(near, wide());
        }
        TextView add = chip("＋  ECHO HERE", this::create);
        add.setTextSize(14f);
        addView(add, wide());
        if (big) {
            showTab(0);
        }
        refresh();
    }

    // ------------------------------------------------------------------ live

    @Override
    void onLive(boolean on) {
        EchoWalls.listener = on ? onChange : null;
        if (on) {
            me = EchoWalls.last(host);
            EchoWalls.sync(host);
            if (big) {
                sm = (SensorManager) host.getSystemService(Context.SENSOR_SERVICE);
                Sensor r = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
                if (r != null) {
                    sm.registerListener(sensor, r, SensorManager.SENSOR_DELAY_UI);
                }
                if (EchoWalls.canLocate(host)) {
                    EchoWalls.here(host, l -> {
                        if (l != null) {
                            me = l;
                            onChange.run();
                        }
                    });
                }
            }
        } else if (sm != null) {
            sm.unregisterListener(sensor);
        }
    }

    @Override
    long tickMs() {
        return 30000;
    }

    @Override
    void tick() {
        Location l = EchoWalls.last(host);
        if (l != null) {
            me = l;
        }
        refresh();
    }

    @Override
    void refresh() {
        List<EchoWalls.Echo> all = EchoWalls.all();
        int live = 0;
        for (EchoWalls.Echo e : all) {
            if (!e.done) {
                live++;
            }
        }
        head.setText("📍 ECHO WALLS  ·  " + all.size() + " echo" + (all.size() == 1 ? "" : "es")
                + (live != all.size() ? "  (" + live + " waiting)" : ""));
        if (big) {
            return;
        }
        near.removeAllViews();
        if (!EchoWalls.canLocate(host)) {
            near.addView(row("Allow location so echoes can find you", "ALLOW", this::askLocation));
            return;
        }
        if (all.isEmpty()) {
            TextView t = text("Leave a note at a place. Next time you're there, it pops up.", 10.5f, Theme.DIM);
            t.setPadding(dp(4), dp(4), dp(4), dp(6));
            near.addView(t, wide());
            return;
        }
        List<EchoWalls.Echo> sorted = sorted(all);
        for (int i = 0; i < Math.min(3, sorted.size()); i++) {
            near.addView(line(sorted.get(i)), wide());
        }
    }

    private List<EchoWalls.Echo> sorted(List<EchoWalls.Echo> all) {
        List<EchoWalls.Echo> s = new ArrayList<>(all);
        if (me != null) {
            final Location m = me;
            Collections.sort(s, (a, b) -> Float.compare(EchoWalls.distance(a, m), EchoWalls.distance(b, m)));
        } else {
            Collections.sort(s, (a, b) -> Long.compare(b.created, a.created));
        }
        return s;
    }

    private View line(final EchoWalls.Echo e) {
        String where = "";
        if (me != null) {
            float d = EchoWalls.distance(e, me);
            where = "  " + arrow(EchoWalls.bearing(e, me)) + " " + EchoWalls.dist(d);
        }
        TextView t = text((e.done ? "○ " : "● ") + e.title() + where, 11.5f, e.locked() ? GOLD : Theme.TEXT);
        t.setGravity(Gravity.START);
        t.setSingleLine(true);
        t.setPadding(dp(6), dp(7), dp(6), dp(7));
        t.setOnClickListener(v -> EchoWalls.show(host, e.id));
        return t;
    }

    private static String arrow(float b) {
        String[] a = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
        int i = Math.round(((b % 360) + 360) % 360 / 45f) % 8;
        return a[i];
    }

    private View row(String msg, String btn, Runnable r) {
        LinearLayout l = row();
        l.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(msg, 10.5f, Theme.DIM);
        t.setGravity(Gravity.START);
        l.addView(t, weight(1f));
        l.addView(chip(btn, r));
        return l;
    }

    private void askLocation() {
        host.ask(new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION}, () -> {
            if (!EchoWalls.canBackground(host) && android.os.Build.VERSION.SDK_INT >= 29) {
                new AlertDialog.Builder(host).setTitle("One more step")
                        .setMessage("So echoes can pop up while NOVA is closed, choose \"Allow all the time\" on the "
                                + "next screen. NOVA uses Android's area alerts: it doesn't track you constantly and "
                                + "nothing leaves the phone.")
                        .setPositiveButton("OK", (d, w) -> host.ask(
                                new String[] {android.Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                                () -> EchoWalls.sync(host), () -> host.toast("Echoes only show while NOVA is open")))
                        .setNegativeButton("SKIP", null).show();
            }
            EchoWalls.sync(host);
            refresh();
        }, () -> host.toast("Echo walls need location"));
    }

    // ------------------------------------------------------------------ making an echo

    private void create() {
        if (!EchoWalls.canLocate(host)) {
            askLocation();
            return;
        }
        final EchoWalls.Echo e = new EchoWalls.Echo();
        e.id = Long.toString(System.currentTimeMillis(), 36);
        e.created = System.currentTimeMillis();
        e.radius = 50;
        final File photo = new File(EchoWalls.dir(host), e.id + ".jpg");
        final File voice = new File(EchoWalls.dir(host), e.id + ".m4a");
        final MediaRecorder[] rec = new MediaRecorder[1];

        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        int p = dp(18);
        v.setPadding(p, p / 2, p, 0);
        final TextView where = text("📡 Finding exactly where you are…", 11f, Theme.DIM);
        where.setGravity(Gravity.START);
        v.addView(where, wide());
        final EditText txt = new EditText(host);
        txt.setHint("Your note (what should future you see here?)");
        txt.setMinLines(2);
        v.addView(txt, wide());

        final TextView photoBtn = chip("📷 ADD A PHOTO", null);
        photoBtn.setOnClickListener(x -> {
            try {
                Uri u = androidx.core.content.FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", photo);
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                i.putExtra(MediaStore.EXTRA_OUTPUT, u);
                i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                host.startActivity(i);
                photoBtn.setText("📷 PHOTO ✔ (tap to take it again)");
            } catch (Exception ex) {
                host.toast("No camera app");
            }
        });
        v.addView(photoBtn, wide());

        final TextView voiceBtn = chip("🎙 RECORD A VOICE MEMO", null);
        voiceBtn.setOnClickListener(x -> host.ask(new String[] {android.Manifest.permission.RECORD_AUDIO}, () -> {
            try {
                if (rec[0] == null) {
                    MediaRecorder r = new MediaRecorder();
                    r.setAudioSource(MediaRecorder.AudioSource.MIC);
                    r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    r.setOutputFile(voice.getAbsolutePath());
                    r.prepare();
                    r.start();
                    rec[0] = r;
                    voiceBtn.setText("■ STOP RECORDING");
                } else {
                    rec[0].stop();
                    rec[0].release();
                    rec[0] = null;
                    voiceBtn.setText("🎙 VOICE MEMO ✔ (tap to record again)");
                }
            } catch (Exception ex) {
                rec[0] = null;
                host.toast("Couldn't record");
            }
        }, () -> host.toast("Needs the microphone")));
        v.addView(voiceBtn, wide());

        final TextView radius = chip("", null);
        final int[] ri = {1};
        radius.setText("RANGE  " + EchoWalls.RADII[ri[0]] + " m");
        radius.setOnClickListener(x -> {
            ri[0] = (ri[0] + 1) % EchoWalls.RADII.length;
            radius.setText("RANGE  " + EchoWalls.RADII[ri[0]] + " m");
        });
        v.addView(radius, wide());

        final TextView mode = chip("", null);
        final int[] mi = {0};
        final long[] openAt = {0};
        mode.setText("SHOWS: " + EchoWalls.MODES[0].toUpperCase(Locale.ROOT));
        mode.setOnClickListener(x -> {
            mi[0] = (mi[0] + 1) % EchoWalls.MODES.length;
            if (mi[0] == 2) {
                Calendar c = Calendar.getInstance();
                c.add(Calendar.YEAR, 1);
                new android.app.DatePickerDialog(host, (dp, y, m, d) -> {
                    Calendar k = Calendar.getInstance();
                    k.set(y, m, d, 0, 0, 0);
                    openAt[0] = k.getTimeInMillis();
                    mode.setText("SHOWS: TIME CAPSULE, OPENS " + EchoWalls.day(openAt[0]).toUpperCase(Locale.ROOT));
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
                openAt[0] = c.getTimeInMillis();
                mode.setText("SHOWS: TIME CAPSULE, OPENS " + EchoWalls.day(openAt[0]).toUpperCase(Locale.ROOT));
            } else {
                mode.setText("SHOWS: " + EchoWalls.MODES[mi[0]].toUpperCase(Locale.ROOT));
            }
        });
        v.addView(mode, wide());

        final Location[] at = {EchoWalls.last(host)};
        EchoWalls.here(host, l -> {
            if (l != null) {
                at[0] = l;
            }
            where.setText(at[0] == null ? "⚠ No position yet (turn on location)"
                    : String.format(Locale.ROOT, "📍 Pinned here (±%d m)", Math.round(at[0].getAccuracy())));
        });

        ScrollView sv = new ScrollView(host);
        sv.addView(v);
        new AlertDialog.Builder(host).setTitle("＋ New echo").setView(sv)
                .setPositiveButton("PIN IT HERE", (d, w) -> {
                    if (rec[0] != null) {
                        try {
                            rec[0].stop();
                        } catch (Exception ignored) {
                            // too short
                        }
                        rec[0].release();
                        rec[0] = null;
                    }
                    if (at[0] == null) {
                        host.toast("No position, echo not saved");
                        return;
                    }
                    e.lat = at[0].getLatitude();
                    e.lon = at[0].getLongitude();
                    e.text = txt.getText().toString().trim();
                    e.photo = photo.exists() && photo.length() > 0 ? photo.getAbsolutePath() : "";
                    e.voice = voice.exists() && voice.length() > 0 ? voice.getAbsolutePath() : "";
                    if (e.text.isEmpty() && e.photo.isEmpty() && e.voice.isEmpty()) {
                        host.toast("Write something, add a photo or a voice memo");
                        return;
                    }
                    e.radius = EchoWalls.RADII[ri[0]];
                    e.mode = mi[0];
                    e.openAt = openAt[0];
                    // don't pop up the second you leave it: wait until you've been away a while
                    e.lastShown = System.currentTimeMillis();
                    EchoWalls.put(host, e);
                    host.buzz(30);
                    host.toast(e.mode == 2 ? "📦 Time capsule pinned" : "📍 Echo pinned here");
                    if (!EchoWalls.canBackground(host)) {
                        askLocation();
                    }
                })
                .setNegativeButton("CANCEL", (d, w) -> {
                    if (rec[0] != null) {
                        try {
                            rec[0].stop();
                        } catch (Exception ignored) {
                            // too short
                        }
                        rec[0].release();
                        rec[0] = null;
                    }
                    photo.delete();
                    voice.delete();
                }).show();
    }

    // ------------------------------------------------------------------ big view

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(0xFF05080C);
        v.setPadding(dp(8), dp(40), dp(8), dp(12));
        v.setClickable(true);
        LinearLayout h = row();
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("ECHO WALLS", 16f, GLOW);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        h.addView(t, weight(1f));
        h.addView(chip("✕ CLOSE", host::hideOverlay));
        v.addView(h, wide());
        v.addView(new EchoWidget(host, true), new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    private void showTab(int k) {
        tab = k;
        for (int i = 0; i < tabs.length; i++) {
            pick(tabs[i], i == k);
        }
        body.removeAllViews();
        radar = null;
        map = null;
        if (k == 0) {
            map = new MapView(host);
            body.addView(map, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        } else if (k == 1) {
            radar = new RadarView(host);
            body.addView(radar, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        } else {
            ScrollView sv = new ScrollView(host);
            LinearLayout l = new LinearLayout(host);
            l.setOrientation(VERTICAL);
            List<EchoWalls.Echo> s = sorted(EchoWalls.all());
            for (EchoWalls.Echo e : s) {
                l.addView(line(e), wide());
            }
            if (s.isEmpty()) {
                l.addView(text("No echoes yet. Tap ＋ ECHO HERE.", 12f, Theme.DIM), wide());
            }
            sv.addView(l);
            body.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
    }

    /** Tap test shared by MAP and RADAR: {x, y, id}. */
    private void tapHit(List<Object[]> hits, float x, float y) {
        float best = dp(30);
        String id = null;
        for (Object[] h : hits) {
            float d = (float) Math.hypot((Float) h[0] - x, (Float) h[1] - y);
            if (d < best) {
                best = d;
                id = (String) h[2];
            }
        }
        if (id != null) {
            EchoWalls.show(host, id);
        }
    }

    // ------------------------------------------------------------------ radar

    private final class RadarView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<Object[]> hits = new ArrayList<>();
        private final float[] ranges = {200, 1000, 5000, 25000};
        private int ri = 1;

        RadarView(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float cx = w / 2f;
            float cy = h / 2f;
            float r = Math.min(w, h) / 2f - dp(16);
            float range = ranges[ri];
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF03070A);
            c.drawRoundRect(0, 0, w, h, dp(12), dp(12), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            for (int i = 1; i <= 4; i++) {
                p.setColor(i == 4 ? 0x667CF5FF : 0x337CF5FF);
                c.drawCircle(cx, cy, r * i / 4f, p);
            }
            float north = compass ? -azimuth : 0;
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(11));
            p.setColor(0xFFFF6B6B);
            double nr = Math.toRadians(north);
            c.drawText("N", cx + (float) Math.sin(nr) * (r + dp(8)), cy - (float) Math.cos(nr) * (r + dp(8)) + dp(4), p);
            p.setColor(0x997CF5FF);
            p.setTextSize(dp(9));
            for (int i = 1; i <= 4; i++) {
                c.drawText(EchoWalls.dist(range * i / 4f), cx + dp(18), cy - r * i / 4f + dp(10), p);
            }
            // me
            p.setColor(0xFFFFFFFF);
            c.drawCircle(cx, cy, dp(6), p);
            hits.clear();
            if (me == null) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(12));
                c.drawText("finding you…", cx, cy + dp(26), p);
                return;
            }
            for (EchoWalls.Echo e : EchoWalls.all()) {
                float d = EchoWalls.distance(e, me);
                float rr = Math.min(1f, d / range) * r;
                double a = Math.toRadians(EchoWalls.bearing(e, me) + north);
                float x = cx + (float) Math.sin(a) * rr;
                float y = cy - (float) Math.cos(a) * rr;
                int col = e.locked() ? GOLD : e.done ? 0xFF667788 : GLOW;
                p.setColor((col & 0x00FFFFFF) | 0x44000000);
                c.drawCircle(x, y, dp(14), p);
                p.setColor(col);
                c.drawCircle(x, y, dp(6), p);
                if (d > range) {
                    p.setTextSize(dp(9));
                    c.drawText(EchoWalls.dist(d), x, y - dp(10), p);
                }
                hits.add(new Object[] {x, y, e.id});
            }
            p.setColor(Theme.DIM);
            p.setTextSize(dp(10));
            c.drawText(compass ? "turn around: the radar turns with you · tap = range" : "tap = change range", cx,
                    h - dp(8), p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                int before = hits.size();
                float best = dp(30);
                String id = null;
                for (Object[] hh : hits) {
                    float d = (float) Math.hypot((Float) hh[0] - e.getX(), (Float) hh[1] - e.getY());
                    if (d < best) {
                        best = d;
                        id = (String) hh[2];
                    }
                }
                if (id != null) {
                    EchoWalls.show(host, id);
                } else if (before >= 0) {
                    ri = (ri + 1) % ranges.length;
                    invalidate();
                }
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ map (OpenStreetMap tiles)

    private static final LruCache<String, Bitmap> TILES = new LruCache<>(120);
    private static final Set<String> LOADING = new HashSet<>();
    private static ExecutorService pool;

    private final class MapView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final List<Object[]> hits = new ArrayList<>();
        private final float scale;
        private double cx;
        private double cy;
        private double zf = 15;
        private boolean placed;
        private final GestureDetector gd;
        private final ScaleGestureDetector sg;

        MapView(Context c) {
            super(c);
            scale = Math.max(1f, getResources().getDisplayMetrics().density / 1.5f);
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                    cx += dx;
                    cy += dy;
                    invalidate();
                    return true;
                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    tapHit(hits, e.getX(), e.getY());
                    return true;
                }
            });
            sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector g) {
                    zoom(Math.log(g.getScaleFactor()) / Math.log(2), g.getFocusX(), g.getFocusY());
                    return true;
                }
            });
        }

        private double world(double z) {
            return 256.0 * scale * Math.pow(2, z);
        }

        private double ux(double lon) {
            return (lon + 180.0) / 360.0;
        }

        private double uy(double lat) {
            double r = Math.toRadians(lat);
            return (1.0 - Math.log(Math.tan(r) + 1.0 / Math.cos(r)) / Math.PI) / 2.0;
        }

        private void center(double lat, double lon) {
            cx = ux(lon) * world(zf);
            cy = uy(lat) * world(zf);
            placed = true;
        }

        private void zoom(double dz, float fx, float fy) {
            double nz = Math.max(3, Math.min(19, zf + dz));
            double k = Math.pow(2, nz - zf);
            double ox = fx - getWidth() / 2.0;
            double oy = fy - getHeight() / 2.0;
            cx = (cx + ox) * k - ox;
            cy = (cy + oy) * k - oy;
            zf = nz;
            invalidate();
        }

        private void tile(int tz, int tx, int ty, Canvas cv, float left, float top, float size) {
            int max = 1 << tz;
            if (ty < 0 || ty >= max) {
                return;
            }
            int txw = ((tx % max) + max) % max;
            final String key = tz + "/" + txw + "/" + ty;
            Bitmap b = TILES.get(key);
            if (b != null) {
                cv.drawBitmap(b, null, new RectF(left, top, left + size, top + size), tp);
                return;
            }
            synchronized (LOADING) {
                if (!LOADING.add(key)) {
                    return;
                }
            }
            if (pool == null) {
                pool = Executors.newFixedThreadPool(4);
            }
            pool.execute(() -> {
                byte[] data = Http.bytes("https://tile.openstreetmap.org/" + key + ".png");
                Bitmap bm = data == null ? null : BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bm != null) {
                    TILES.put(key, bm);
                }
                synchronized (LOADING) {
                    LOADING.remove(key);
                }
                postInvalidate();
            });
        }

        @Override
        protected void onDraw(Canvas cv) {
            int w = getWidth();
            int h = getHeight();
            if (!placed) {
                Location m = me;
                List<EchoWalls.Echo> all = EchoWalls.all();
                if (m != null) {
                    center(m.getLatitude(), m.getLongitude());
                } else if (!all.isEmpty()) {
                    center(all.get(0).lat, all.get(0).lon);
                } else {
                    zf = 12;
                    center(47.3769, 8.5417);
                }
            }
            cv.drawColor(0xFF1B1E24);
            int tz = (int) Math.max(1, Math.min(19, Math.floor(zf)));
            float size = (float) (256.0 * scale * Math.pow(2, zf - tz));
            double left = cx - w / 2.0;
            double top = cy - h / 2.0;
            for (int ty = (int) Math.floor(top / size); ty <= (int) Math.floor((top + h) / size); ty++) {
                for (int tx = (int) Math.floor(left / size); tx <= (int) Math.floor((left + w) / size); tx++) {
                    tile(tz, tx, ty, cv, (float) (tx * size - left), (float) (ty * size - top), size);
                }
            }
            double W = world(zf);
            hits.clear();
            for (EchoWalls.Echo e : EchoWalls.all()) {
                float x = (float) (ux(e.lon) * W - left);
                float y = (float) (uy(e.lat) * W - top);
                int col = e.locked() ? GOLD : e.done ? 0xFF8899AA : GLOW;
                p.setStyle(Paint.Style.FILL);
                p.setColor((col & 0x00FFFFFF) | 0x55000000);
                c(cv, x, y, dp(16));
                p.setColor(0xFF000000);
                c(cv, x, y, dp(8));
                p.setColor(col);
                c(cv, x, y, dp(6));
                hits.add(new Object[] {x, y, e.id});
            }
            Location m = me;
            if (m != null) {
                float x = (float) (ux(m.getLongitude()) * W - left);
                float y = (float) (uy(m.getLatitude()) * W - top);
                p.setColor(0x553D8BFF);
                c(cv, x, y, dp(14));
                p.setColor(0xFFFFFFFF);
                c(cv, x, y, dp(7));
                p.setColor(0xFF3D8BFF);
                c(cv, x, y, dp(5));
            }
            p.setColor(0xAA000000);
            p.setTextSize(dp(8));
            p.setTextAlign(Paint.Align.RIGHT);
            p.setColor(0xFF333333);
            cv.drawText("© OpenStreetMap", w - dp(4), h - dp(4), p);
        }

        private void c(Canvas cv, float x, float y, float r) {
            cv.drawCircle(x, y, r, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN && getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            sg.onTouchEvent(e);
            if (!sg.isInProgress()) {
                gd.onTouchEvent(e);
            }
            return true;
        }
    }
}
