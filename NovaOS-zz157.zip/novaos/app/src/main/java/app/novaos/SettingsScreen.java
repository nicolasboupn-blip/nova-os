package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Everything you can change about NOVA, in one place. */
final class SettingsScreen extends LinearLayout {
    /** Which categories are open (like Android Settings: tap a category to open or close it). */
    private static final java.util.Set<String> OPEN = new java.util.HashSet<>();
    private LinearLayout bodyRef;
    private View noneRef;
    private EditText searchRef;
    private final NovaActivity host;

    SettingsScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        int side = Theme.dp(host, 20);
        setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 12));

        // title row
        LinearLayout head = new LinearLayout(host);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("SETTINGS", 12f, Theme.ACCENT);
        title.setLetterSpacing(0.3f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView back = label("BACK", 12f, Theme.DIM);
        back.setClickable(true);
        back.setOnClickListener(v -> host.showHome());
        head.addView(back);
        addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        final EditText search = new EditText(host);
        search.setHint("Search settings");
        search.setHintTextColor(Theme.DIM);
        search.setTextColor(Theme.TEXT);
        search.setTextSize(14f);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        search.setPadding(Theme.dp(host, 14), Theme.dp(host, 10), Theme.dp(host, 14), Theme.dp(host, 10));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Theme.dp(host, 10);
        addView(search, slp);
        searchRef = search;

        ScrollView sv = new ScrollView(host);
        final LinearLayout body = new LinearLayout(host);
        body.setOrientation(VERTICAL);
        sv.addView(body);
        bodyRef = body;
        addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        heading(body, "UI STYLE");
        body.addView(toggle("laofkdkrjiiais", Chaos.K_ON, Chaos.on(), () -> Chaos.flipped(host)));
        body.addView(hint("Each time you switch it on, something about NOVA's design changes at random: small or big. "
                + "Switch it off and everything goes back to normal."));
        final String[] styleNames = UiStyle.NAMES.clone();
        if (!UiStyle.designerOn()) {
            styleNames[UiStyle.CUSTOM] = "My style (switch on the designer)";
        }
        body.addView(choice("Look of NOVA", UiStyle.K_STYLE, styleNames, Math.min(UiStyle.chosen(), styleNames.length - 1),
                () -> host.refreshTheme()));
        body.addView(choice("Home screen layout", AltHome.K_LAYOUT, AltHome.NAMES,
                Math.max(0, Math.min(AltHome.NAMES.length - 1, Prefs.getInt(AltHome.K_LAYOUT, 0))),
                () -> host.showHome()));
        body.addView(choice("App drawer look", DrawerScreen.K_DRAWER, DrawerScreen.NAMES, DrawerScreen.mode(), null));
        body.addView(toggle("Look picker tab on the home screen (pull it left)", "ui_handle", Prefs.getBool("ui_handle", true),
                () -> host.showHome()));
        TextView picker = label("OPEN THE LOOK PICKER: 10 full skins, colours, home, drawer \u203A", 12f, Theme.ACCENT);
        picker.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        picker.setClickable(true);
        picker.setOnClickListener(v -> {
            host.showHome();
            host.root.postDelayed(() -> UiSwitcher.open(host), 700);
        });
        body.addView(picker);
        body.addView(hint("Real new home screens, not colours. Classic: the original with the castle and pages. "
                + "Bento: a board of tiles. Orbit: apps on turning rings around the clock. Feed: a scrolling feed of "
                + "cards with search. Console: big tiles in a row like a game console. Index: every app as a line of type with an A to Z rail. Fan: a corner button fans your apps out in an arc. Wallet: cards that fold open. Bubbles: apps float as bubbles you can push. Lines: only type. Dock: the familiar grid with a floating dock. Works together with every look "
                + "below. The classic home keeps the castle, widget pages and edit mode; the new ones show your pinned "
                + "apps and the SONGS, PROFILE and SCENES cards."));
        body.addView(hint("Normal: the classic NOVA. Aurora: frosted glass, big round corners, drifting light. "
                + "Terminal: a green screen with scan lines and sharp corners. Block: hard edges, thick pink outlines "
                + "and a dot grid. Synthwave, Ocean, Inferno and Galaxy are full moving pictures. Each one changes colours, shapes, font and background everywhere."));
        body.addView(toggle("Force dark mode (makes every look dark)", UiStyle.K_DARK, UiStyle.forceDark(),
                () -> host.refreshTheme()));
        body.addView(toggle("Theme designer (make your own style)", UiStyle.K_DESIGNER, UiStyle.designerOn(), () -> {
            if (!UiStyle.designerOn() && Prefs.getInt(UiStyle.K_STYLE, 0) == UiStyle.CUSTOM) {
                Prefs.putInt(UiStyle.K_STYLE, 0);
            }
            host.refreshTheme();
        }));
        if (UiStyle.designerOn()) {
            TextView design = label("OPEN THE DESIGNER: colours, corners, borders, font, effects \u203A", 12f, Theme.ACCENT);
            design.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
            design.setClickable(true);
            design.setOnClickListener(v -> host.showOverlay(new ThemeDesigner(host)));
            body.addView(design);
        }

        heading(body, "PROFILE & SCENES");
        TextView prof = label("OPEN MY PROFILE: banner, effects, badges, status \u203A", 12f, Theme.ACCENT);
        prof.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        prof.setClickable(true);
        prof.setOnClickListener(v -> host.showOverlay(new ProfileScreen(host)));
        body.addView(prof);
        TextView scn = label("EDIT SCENES: Gaming, Sleep, Study, your own \u203A", 12f, Theme.ACCENT);
        scn.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        scn.setClickable(true);
        scn.setOnClickListener(v -> host.showOverlay(new ScenesScreen(host)));
        body.addView(scn);
        body.addView(toggle("Switch scenes by the clock (the time rules of each scene)", Scenes.K_AUTO,
                Scenes.autoOn()));
        body.addView(toggle("Remember what I listen to (for the SONGS widget)", SongLog.K_ON, SongLog.on()));
        TextView clearSongs = label("CLEAR SONG HISTORY \u203A", 11f, Theme.DIM);
        clearSongs.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        clearSongs.setClickable(true);
        clearSongs.setOnClickListener(v -> {
            SongLog.clear();
            host.toast("Song history cleared");
        });
        body.addView(clearSongs);
        TextView builder = label("WIDGET BUILDER: make your own widgets \u203A", 12f, Theme.ACCENT);
        builder.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        builder.setClickable(true);
        builder.setOnClickListener(v -> host.showOverlay(new WidgetBuilder(host)));
        body.addView(builder);
        TextView pageOrder = label("PAGE ORDER: put the pages of the main box in your own order \u203A", 12f, Theme.ACCENT);
        pageOrder.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        pageOrder.setClickable(true);
        pageOrder.setOnClickListener(v -> host.showOverlay(new PageOrderSheet(host)));
        body.addView(pageOrder);
        body.addView(hint("Songs are remembered only on this phone, from the music notification, and only the title "
                + "and artist. Scenes change volume, brightness, the look of NOVA and your profile status in one tap."));

        heading(body, "PEAKFINDER");
        TextView pk1 = label("OPEN PEAKFINDER MAP: a normal map, 40 km around you, peaks marked \u203A", 12f, Theme.ACCENT);
        pk1.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        pk1.setClickable(true);
        pk1.setOnClickListener(v -> host.showOverlay(new PeakFinder(host, PeakFinder.MAP)));
        body.addView(pk1);
        TextView pk2 = label("OPEN PEAK STICKS: a stick for each peak around you \u203A", 12f, Theme.ACCENT);
        pk2.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        pk2.setClickable(true);
        pk2.setOnClickListener(v -> host.showOverlay(new PeakFinder(host, PeakFinder.STICKS)));
        body.addView(pk2);
        TextView pk3 = label("OPEN PEAKFINDER 3D: your camera with the mountain names on it \u203A", 12f, Theme.ACCENT);
        pk3.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        pk3.setClickable(true);
        pk3.setOnClickListener(v -> host.showOverlay(new PeakFinder(host, PeakFinder.CAM)));
        body.addView(pk3);
        body.addView(hint("Peaks come from OpenStreetMap and are saved on this phone for your area, so the widget "
                + "works offline. NOVA keeps your last position on the phone to draw the widget. There is no terrain "
                + "data, so a peak behind a ridge can still be shown; peaks that a nearer, higher peak covers are dimmed. "
                + "Add the PEAKFINDER widget in home edit mode."));

        heading(body, "Z\u00DCRICH BUS");
        TextView bus1 = label("OPEN BUS MAP: your routes, where the bus runs late, auto-detect \u203A", 12f, Theme.ACCENT);
        bus1.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        bus1.setClickable(true);
        bus1.setOnClickListener(v -> BusScreen.open(host));
        body.addView(bus1);
        body.addView(hint("Add the ZURICH BUS widget in home edit mode, or as a page of the main box. Routes you rode "
                + "on 3 different days turn into a solid blue line, and where the bus runs late the line goes green to "
                + "red. Bus times come from the free Swiss timetable (transport.opendata.ch)."));

        heading(body, "NOVA ISLAND");
        TextView isl = label(Island.serviceOn() ? "1. Best way: Accessibility is ON \u2714"
                : "1. BEST WAY: turn on \"NOVA Island & deck mouse\" in Accessibility \u203A", 12f, Theme.ACCENT);
        isl.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        isl.setClickable(true);
        isl.setOnClickListener(v -> {
            try {
                host.startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
                host.toast("Installed apps > NOVA Island & deck mouse > On");
            } catch (RuntimeException e) {
                host.toast("Open Android Settings > Accessibility");
            }
        });
        body.addView(isl);
        TextView islRs = label("Greyed out / \"Restricted setting\"? Tap here: \u22EE (top right) > Allow restricted settings, "
                + "then try 1. again \u203A", 12f, Theme.ACCENT);
        islRs.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        islRs.setClickable(true);
        islRs.setOnClickListener(v -> {
            try {
                host.startActivity(new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + host.getPackageName())));
                host.toast("\u22EE top right > Allow restricted settings");
            } catch (RuntimeException e) {
                host.toast("Settings > Apps > NOVA > \u22EE > Allow restricted settings");
            }
        });
        body.addView(islRs);
        TextView ov = label(Island.canOverlay(host) ? "2. Backup way: Display over other apps is ON \u2714"
                : "2. BACKUP WAY: allow \"Display over other apps\" \u203A", 12f, Theme.ACCENT);
        ov.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        ov.setClickable(true);
        ov.setOnClickListener(v -> {
            try {
                host.startActivity(new android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:" + host.getPackageName())));
                host.toast("Turn on: Allow display over other apps");
            } catch (RuntimeException e) {
                host.toast("Settings > Apps > NOVA > Display over other apps");
            }
        });
        body.addView(ov);
        boolean btOk = android.os.Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        TextView bt = label(btOk ? "3. Headphone battery is ON \u2714" : "3. ALLOW HEADPHONE BATTERY (Nearby devices) \u203A",
                12f, Theme.ACCENT);
        bt.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        bt.setClickable(true);
        bt.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                host.ask(new String[] {android.Manifest.permission.BLUETOOTH_CONNECT},
                        () -> host.toast("Headphone battery on \uD83C\uDFA7"),
                        () -> host.toast("Allow \"Nearby devices\" in NOVA's app info"));
            }
        });
        body.addView(bt);
        TextView now = label(Island.showing() ? "Island is showing right now \u2714" : "Island is NOT showing yet: do 1. or 2.",
                12f, Island.showing() ? 0xFF34C759 : 0xFFFF9F0A);
        now.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        body.addView(now);
        body.addView(toggle("Show NOVA Island over all apps", Island.K_ON, Island.enabled(), () -> Island.sync(host)));
        body.addView(toggle("Show new messages in the island", Island.K_NOTIF, Prefs.getBool(Island.K_NOTIF, true)));
        TextView islEdit = label("\u270E MOVE THE ISLAND (drag it, then tap DONE) \u203A", 12f, Theme.ACCENT);
        islEdit.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        islEdit.setClickable(true);
        islEdit.setOnClickListener(v -> {
            if (!Island.showing()) {
                host.toast("Turn the island on first (1. or 2. above)");
                return;
            }
            Island.edit();
            host.showHome();
        });
        body.addView(islEdit);
        TextView islReset = label("PUT IT BACK OVER THE CAMERA \u203A", 12f, Theme.ACCENT);
        islReset.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        islReset.setClickable(true);
        islReset.setOnClickListener(v -> {
            Prefs.putInt("island_cx", -1);
            Prefs.putInt("island_top", -1);
            Island.reload();
            host.toast("Island is back over the camera");
        });
        body.addView(islReset);
        TextView islCenter = label("\u2194 CENTER ISLAND \u203A", 12f, Theme.ACCENT);
        islCenter.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        islCenter.setClickable(true);
        islCenter.setOnClickListener(v -> {
            Island.center();
            host.toast("Island is in the middle now");
        });
        body.addView(islCenter);
        body.addView(choice("Island size (when width is Auto)", "island_size", new String[] {"Small", "Medium", "Wide", "Full width"},
                Prefs.getInt("island_size", 2), Island::reload));
        body.addView(choice("Island width", "island_w", new String[] {"Auto", "30%", "35%", "40%", "45%", "50%", "55%", "60%", "65%", "70%", "75%", "80%", "85%", "90%", "95%", "100%"}, Prefs.getInt("island_w", 0), Island::reload));
        body.addView(choice("Island height", "island_h", new String[] {"Auto", "28dp", "32dp", "36dp", "40dp", "44dp", "48dp", "52dp", "56dp", "60dp"}, Prefs.getInt("island_h", 0), Island::reload));
        body.addView(hint("STYLE"));
        body.addView(choice("Colour", "islo_color", new String[] {"Black", "Graphite", "Navy", "Purple", "Forest", "Wine", "Accent"}, Island.opt("color", 0), Island::reload));
        body.addView(choice("See-through", "islo_alpha", new String[] {"Solid", "90%", "80%", "70%", "60%"}, Island.opt("alpha", 0), Island::reload));
        body.addView(choice("Outline", "islo_outline", new String[] {"None", "Subtle", "Accent", "White"}, Island.opt("outline", Island.serviceOn() ? 0 : 1), Island::reload));
        body.addView(choice("Corners", "islo_corner", new String[] {"Pill", "Rounded", "Sharp"}, Island.opt("corner", 0), Island::reload));
        body.addView(choice("Text size", "islo_tsize", new String[] {"Small", "Normal", "Big"}, Island.opt("tsize", 1), Island::reload));
        body.addView(choice("Font", "islo_font", new String[] {"Sans", "Mono", "Serif", "Condensed"}, Island.opt("font", 0), Island::reload));
        body.addView(choice("Text colour", "islo_tcol", new String[] {"White (time grey)", "Grey", "Accent"}, Island.opt("tcol", 0), Island::reload));
        body.addView(choice("Clock", "islo_h12", new String[] {"24h", "12h"}, Island.opt("h12", 0), Island::reload));
        body.addView(choice("Seconds", "islo_secs", new String[] {"Off", "On"}, Island.opt("secs", 0), Island::reload));
        body.addView(choice("Date", "islo_date", new String[] {"Tue 28", "28.10", "Off"}, Island.opt("date", 0), Island::reload));
        body.addView(choice("Battery look", "islo_batt", new String[] {"Icon + number", "Number %", "Icon only"}, Island.opt("batt", 0), Island::reload));
        body.addView(choice("Battery colours", "islo_bcol", new String[] {"Green / orange / red", "Plain"}, Island.opt("bcol", 0), Island::reload));
        body.addView(choice("Low battery warning at", "islo_low", new String[] {"10%", "15%", "20%", "30%"}, Island.opt("low", 1), Island::reload));
        body.addView(choice("Turn into a dot when quiet", "islo_autodot", new String[] {"Off", "On"}, Island.opt("autodot", 0),
                Island::reload));
        body.addView(choice("Dot after", "islo_dotsecs", new String[] {"3 s", "5 s", "10 s", "20 s", "30 s", "60 s"},
                Island.opt("dotsecs", 2), Island::reload));
        body.addView(choice("When nothing is going on", "islo_idle", new String[] {"Show the time", "Tiny dot", "Hide (still tappable)"}, Island.opt("idle", 0), Island::reload));
        body.addView(choice("Animation speed", "islo_anim", new String[] {"Fast", "Normal", "Slow"}, Island.opt("anim", 1), Island::reload));
        body.addView(choice("Vibration", "islo_haptic", new String[] {"On", "Off"}, Island.opt("haptic", 0), Island::reload));
        body.addView(choice("Tapping the pill", "islo_tap", new String[] {"Opens the dashboard", "Opens NOVA", "Nothing (pull down to open)"}, Island.opt("tap", 0), Island::reload));
        body.addView(choice("New messages stay for", "islo_note", new String[] {"3 s", "5 s", "8 s", "12 s"}, Island.opt("note", 1), Island::reload));
        body.addView(choice("New message shows", "islo_msg", new String[] {"Title", "App name", "Icon only"}, Island.opt("msg", 0), Island::reload));
        body.addView(choice("Music bars", "islo_bars", new String[] {"Green", "Accent", "White"}, Island.opt("bars", 0), Island::reload));
        body.addView(choice("Show the bus from", "islo_bus", new String[] {"30 min before leaving", "60 min before leaving", "90 min before leaving"}, Island.opt("bus", 1), Island::reload));
        body.addView(choice("Dashboard width", "islo_dash", new String[] {"Normal", "Narrow"}, Island.opt("dash", 0), Island::reload));
        body.addView(hint("WHAT THE SMALL PILL SHOWS"));
        body.addView(toggle("Time and date (when nothing is going on)", "isl_clock", Island.show("clock")));
        body.addView(toggle("Phone battery", "isl_batt", Island.show("batt")));
        body.addView(toggle("Headphone battery", "isl_bt", Island.show("bt")));
        body.addView(toggle("Music", "isl_music", Island.show("music")));
        body.addView(toggle("Timer", "isl_timer", Island.show("timer")));
        body.addView(toggle("Focus rounds", "isl_focus", Island.show("focus")));
        body.addView(toggle("Next bus", "isl_bus", Island.show("bus")));
        body.addView(toggle("Charging and low battery", "isl_charge", Island.show("charge")));
        body.addView(hint("WHAT THE BIG DASHBOARD SHOWS"));
        body.addView(toggle("Bluetooth batteries", "isl_d_bt", Island.show("d_bt")));
        body.addView(toggle("Bus", "isl_d_bus", Island.show("d_bus")));
        body.addView(toggle("Mood", "isl_d_mood", Island.show("d_mood")));
        body.addView(toggle("Money left", "isl_d_money", Island.show("d_money")));
        body.addView(toggle("Homework", "isl_d_hw", Island.show("d_hw")));
        body.addView(toggle("Button: torch", "isl_b_torch", Island.show("b_torch")));
        body.addView(toggle("Button: camera", "isl_b_camera", Island.show("b_camera")));
        body.addView(toggle("Button: music", "isl_b_music", Island.show("b_music")));
        body.addView(toggle("Button: bus", "isl_b_bus", Island.show("b_bus")));
        body.addView(toggle("Button: NOVA", "isl_b_nova", Island.show("b_nova")));
        body.addView(hint("A wide black pill at the top, over every app. Left: music, timer, focus, your next bus, "
                + "charging or a new message. Right: your phone and headphone battery. Tap it (or pull it down) and it opens "
                + "a dashboard: all batteries, music controls, your bus, mood, money, homework and buttons for "
                + "torch, camera, music, bus and NOVA. Swipe up or tap outside to close. Hold the pill (or tap \u270E in the dashboard) "
                + "to drag it anywhere; tap DONE to keep it there, or the \u2699 to come here."));

        heading(body, "NOVA WRAPPED");
        TextView wr1 = label("THIS MONTH SO FAR \u203A", 12f, Theme.ACCENT);
        wr1.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        wr1.setClickable(true);
        wr1.setOnClickListener(v -> Wrapped.open(host, 0));
        body.addView(wr1);
        TextView wr2 = label("LAST MONTH \u203A", 12f, Theme.ACCENT);
        wr2.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 6));
        wr2.setClickable(true);
        wr2.setOnClickListener(v -> Wrapped.open(host, -1));
        body.addView(wr2);
        body.addView(hint("Your month as stories: screen time and top apps, mood, money and kebabs, songs, "
                + "focus, workouts and bus rides. Allow app usage (APPS page of the main box) for real screen time. "
                + "On the 1st of each month NOVA asks if you want to see last month."));

        heading(body, "ACCENT");
        body.addView(accentRow(), block(8));

        heading(body, "APP ICONS");
        body.addView(choice("Icon style", Prefs.K_ICON_STYLE,
                new String[] {"Glow", "Purple", "Original"}, Prefs.iconStyle()));
        body.addView(hint("Glow: black and white icons with glowing particles drifting around them."));
        if (Upgrades.has("shapes")) {
            body.addView(choice("Icon shape", "s_icon_shape", Upgrades.SHAPES, Upgrades.shape()));
            body.addView(hint("From the Coin Shop. Shapes crop the icon, so Glow particles stay inside the shape."));
        }
        if (Upgrades.has("grid5")) {
            body.addView(toggle("5 icons per row", "grid5_on", Prefs.getBool("grid5_on", true)));
        }
        body.addView(toggle("Sparks when you touch an icon", Prefs.K_TOUCH_GLOW, Prefs.touchGlow()));
        body.addView(toggle("Holographic icons (rainbow foil, moves with tilt)", Prefs.K_HOLO, Prefs.holo()));
        body.addView(toggle("Draw on home (double-tap empty space)", Prefs.K_DRAW, Prefs.drawOn()));

        heading(body, "CLOCK & GLOW");
        body.addView(toggle("Glow around the clock", Prefs.K_GLOW_CLOCK, Prefs.glowClock()));
        body.addView(toggle("Purple edge light", Prefs.K_GLOW_EDGES, Prefs.glowEdges()));
        body.addView(toggle("Battery in header", Prefs.K_BATTERY, Prefs.battery()));
        body.addView(choice("Glow strength", Prefs.K_GLOW_STRENGTH,
                new String[] {"Soft", "Normal", "Strong"}, Prefs.glowStrength()));
        body.addView(choice("Clock style", Prefs.K_CLOCK_STYLE,
                new String[] {"Digital", "Stacked", "Analog", "Binary"}, Prefs.clockStyle()));
        body.addView(choice("Clock font", Prefs.K_CLOCK_FONT,
                new String[] {"Digital", "Classic", "Mono", "Bold"}, Prefs.clockFont()));
        body.addView(toggle("Hacker mode", Prefs.K_HACKER, Prefs.hacker(), () -> host.refreshTheme()));
        body.addView(hint("Green terminal look. The glow pulses faster as your battery drops."));

        heading(body, "HOME SCREEN");
        body.addView(toggle("Code wallpaper", Prefs.K_HOME_CODE, Prefs.homeCode()));
        body.addView(choice("Wallpaper strength", Prefs.K_HOME_STRENGTH,
                new String[] {"Subtle", "Medium", "Strong"}, Prefs.homeStrength()));
        body.addView(toggle("System panel", Prefs.K_SYSTEM_PANEL, Prefs.systemPanel()));
        body.addView(toggle("Swipe down for the quick panel", "shade_swipe", Prefs.getBool("shade_swipe", true)));

        heading(body, "LIVE & MOTION");
        body.addView(choice("Animated wallpaper", Prefs.K_LIVE, LiveWallpaper.NAMES, Prefs.liveWall(),
                Upgrades::wallpaperOwned, () -> {
                    if (Prefs.liveWall() == 6) {
                        host.askVizPermission();
                    }
                }));
        body.addView(hint("Now playing moves with your music. With microphone access it follows the real sound, "
                + "otherwise it dances to a made-up beat. Needs notification access to show the song."));
        if (Upgrades.has("sounds")) {
            body.addView(choice("Sound pack", "s_sound_pack", Upgrades.SOUND_PACKS, Upgrades.soundPack(), Sfx::reset));
        }
        if (Upgrades.has("daynight")) {
            body.addView(toggle("Auto night colours (21:00 to 06:00)", "s_daynight", Prefs.getBool("s_daynight", Prefs.getInt("up_daynight", 0) > 0),
                    () -> host.refreshTheme()));
        }
        body.addView(toggle("Shake for a golden coin flip", Prefs.K_SHAKE, Prefs.shakeCoin()));
        body.addView(toggle("Parallax (layers move as you tilt)", Prefs.K_PARALLAX, Prefs.parallax()));
        body.addView(toggle("Edge lighting on notifications", Prefs.K_EDGE_FLASH, Prefs.edgeFlash()));
        body.addView(choice("Haptic feel (tap to test)", Prefs.K_HAPTIC,
                new String[] {"Off", "Soft", "Crisp", "Strong"}, Prefs.haptic()));
        body.addView(label("TEST BUZZ", 12f, Theme.ACCENT), block(8));
        body.getChildAt(body.getChildCount() - 1).setOnClickListener(v -> host.buzz(30));
        body.getChildAt(body.getChildCount() - 1).setClickable(true);

        heading(body, "HOME LAYOUT");
        TextView editHome = label("EDIT HOME: APPS & WIDGETS   \u203A", 12f, Theme.ACCENT);
        editHome.setClickable(true);
        editHome.setOnClickListener(v -> {
            HomeScreen.editing = true;
            host.showHome();
        });
        body.addView(editHome);
        body.addView(hint("Icons wiggle. Drag one onto another to swap places, then tap DONE at the top."));
        body.addView(choice("Clock block", "home_clock", new String[] {"Top", "Middle", "Bottom"}, Prefs.getInt("home_clock", 0)));
        body.addView(choice("Icon size", "icon_size", new String[] {"Normal", "Small", "Large"}, Prefs.getInt("icon_size", 0)));
        body.addView(hint("Where the clock and date sit on home, and how big the app icons are."));

        heading(body, "YOUR NAME ON HOME");
        body.addView(choice("Name style", NameTag.K_STYLE, NameTag.STYLES, NameTag.style()));
        body.addView(hint("Elegant serif, graffiti tag, neon sign, or off. Changes show when you go home."));
        body.addView(hint("The name to show (empty uses your setup name, or Nicolas)"));
        body.addView(input(NameTag.K_TEXT, Prefs.getString(NameTag.K_TEXT, ""), false), block(6));

        heading(body, "LOCK SCREEN");
        body.addView(toggle("Remove lock screen (open straight to home)", Prefs.K_NO_LOCK, Prefs.getBool(Prefs.K_NO_LOCK, false)));
        body.addView(hint("Only NOVA's cover goes away. Your phone's own lock still works. Not used while a NOVA PIN is set."));
        body.addView(toggle("Code wallpaper", Prefs.K_CODE_WALL, Prefs.codeWall()));
        body.addView(toggle("Startup animation on unlock", Prefs.K_BOOT_UNLOCK, Prefs.bootOnUnlock()));
        body.addView(toggle("Beep on unlock", Prefs.K_BEEP, Prefs.beep()));
        body.addView(pinRow());
        if (Prefs.hasPin() && BioAuth.available(host)) {
            body.addView(toggle("Fingerprint unlock", Prefs.K_BIO, Prefs.bio()));
        }
        body.addView(hint("A NOVA PIN adds a PIN pad to NOVA's lock screen. Your phone's own lock still works as before."));
        body.addView(hint("Your own wallpaper text (empty = NOVA's own code)"));
        body.addView(input(Prefs.K_WALL_TEXT, Prefs.wallText(), true), block(6));

        heading(body, "LAUNCH DECK");
        body.addView(toggle("Launchpad over USB (Novation Launchpad Mini MK3)", DeckMidi.K_ON, DeckMidi.enabled(),
                () -> DeckMidi.applySetting(host)));
        body.addView(hint("Plug the Launchpad into the phone with a USB data cable. Its pads then run the deck binds "
                + "and light up in their colours. Open the deck (LAUNCH DECK widget) to see the connection status."));
        body.addView(toggle("Water ripples when you hit a pad", DeckRipple.K_ON, DeckRipple.enabled()));
        body.addView(hint("Rings of changing colour spread out over the other pads, on screen and on the Launchpad. "
                + "Off in battery saver."));
        TextView rippleCfg = label("CONFIGURE THE RIPPLES: strength, length, speed, colours, shape ›", 11f, Theme.ACCENT);
        rippleCfg.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        rippleCfg.setOnClickListener(v -> host.showOverlay(new RippleSettings(host)));
        body.addView(rippleCfg);
        heading(body, "SPOTIFY: PLAY WITHOUT OPENING IT");
        final TextView spId = label("", 11f, Theme.ACCENT);
        spId.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        final TextView spLogin = label("", 11f, Theme.ACCENT);
        spLogin.setPadding(0, Theme.dp(host, 6), 0, Theme.dp(host, 10));
        final Runnable spShow = () -> {
            String id = SpotifyApi.clientId();
            spId.setText(id.isEmpty() ? "CLIENT ID: not set (tap to enter) ›"
                    : "CLIENT ID: " + id.substring(0, Math.min(6, id.length())) + "...  (tap to change) ›");
            spLogin.setText(SpotifyApi.connected() ? "CONNECTED  (tap to disconnect) ›" : "NOT CONNECTED  (tap to connect) ›");
        };
        spShow.run();
        spId.setOnClickListener(v -> {
            final android.widget.EditText in = new android.widget.EditText(host);
            in.setSingleLine(true);
            in.setText(SpotifyApi.clientId());
            in.setHint("Client ID from developer.spotify.com");
            android.widget.FrameLayout wrap = new android.widget.FrameLayout(host);
            wrap.setPadding(Theme.dp(host, 20), Theme.dp(host, 8), Theme.dp(host, 20), 0);
            wrap.addView(in);
            new android.app.AlertDialog.Builder(host).setTitle("Spotify Client ID").setView(wrap)
                    .setPositiveButton("SAVE", (d, w) -> {
                        String s = in.getText().toString().trim();
                        if (!s.equals(SpotifyApi.clientId())) {
                            SpotifyApi.disconnect();
                        }
                        Prefs.putString(SpotifyApi.K_ID, s);
                        spShow.run();
                    }).setNegativeButton("Cancel", null).show();
        });
        spLogin.setOnClickListener(v -> {
            if (SpotifyApi.connected()) {
                SpotifyApi.disconnect();
                spShow.run();
                host.toast("Disconnected from Spotify");
            } else {
                SpotifyApi.connect(host);
            }
        });
        body.addView(spId);
        body.addView(spLogin);
        body.addView(hint("Needs Spotify Premium and a free developer app: 1) go to developer.spotify.com/dashboard "
                + "and create an app. 2) Add this Redirect URI exactly: " + SpotifyApi.REDIRECT + "  3) Tick \"Web API\". "
                + "4) Copy the Client ID here, then tap CONNECT and say yes in the browser. After that song pads play "
                + "on this phone's Spotify without bringing Spotify up. Spotify only has to be running in the "
                + "background (open it once after a restart). Spotify's new rules: the app's owner needs Premium and "
                + "new apps allow 5 users, which is enough for you. Nothing is stored except a login token on this phone."));

        heading(body, "DECK SOUNDS");
        body.addView(toggle("Pads make a sound on this phone", DeckSound.K_ON, DeckSound.enabled(),
                () -> DeckSound.stopAll()));
        body.addView(slider("Sound volume", DeckSound.K_VOL, 100, Prefs.getInt(DeckSound.K_VOL, 80), v -> v + " %"));
        body.addView(choice("Instrument for auto pads", DeckSound.K_INST, DeckSound.INST,
                Math.max(0, Math.min(DeckSound.INST.length - 1, Prefs.getInt(DeckSound.K_INST, 0)))));
        body.addView(toggle("PLAY MODE: hold the note while my finger is down", DeckSound.K_HOLD,
                DeckSound.holdSustains()));
        body.addView(toggle("PLAY MODE: slide across pads to play a run", DeckSound.K_SLIDE, DeckSound.slides()));
        body.addView(toggle("PLAY MODE: pads also run their action", DeckSound.K_PLAY_BINDS,
                DeckSound.playRunsBinds()));
        body.addView(hint("Hold any pad in the deck and choose SOUND to give it its own instrument and note. "
                + "Pads you do not change play a scale in PLAY MODE (low at the bottom, high to the right). The PLAY "
                + "button on the deck turns the buttons into plain colour pads that only make sound. A connected "
                + "Launchpad plays too. Sounds are made on the phone, nothing is downloaded."));
        TextView mouseSvc = label(DeckMouse.everywhere()
                ? "MOUSE OVER OTHER APPS: ON  (open Accessibility settings ›)"
                : "MOUSE OVER OTHER APPS: OFF  (switch on \"NOVA mouse\" in Accessibility ›)", 11f, Theme.ACCENT);
        mouseSvc.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        mouseSvc.setOnClickListener(v -> DeckMouse.openAccessibilitySettings(host));
        body.addView(mouseSvc);
        body.addView(hint("The bottom-right 3 x 3 pads of the deck are a mouse. Without this switch the cursor only "
                + "works inside NOVA. With it the cursor floats over every app and taps for real. It only draws the "
                + "cursor and taps where you press a pad, it does not read your screen."));

        heading(body, "STARTUP");
        body.addView(choice("Startup style", Prefs.K_BOOT_STYLE, new String[] {"Normal", "Cinematic"}, Prefs.bootStyle()));
        body.addView(hint("Cinematic: a longer system check with a progress bar and an animated logo after a restart."));

        heading(body, "ACCESS SEQUENCE");
        body.addView(toggle("Access startup", AccessScreen.K_ON, Prefs.getBool(AccessScreen.K_ON, false)));
        body.addView(choice("Look", AccessScreen.K_STYLE, AccessScreen.STYLE_NAMES, Prefs.getInt(AccessScreen.K_STYLE, 0)));
        body.addView(slider("Takes", AccessScreen.K_SECS, 20, AccessScreen.seconds(), v -> Math.max(2, v) + " s"));
        body.addView(choice("Only if away for", AccessScreen.K_AWAY, AccessScreen.AWAY_NAMES, Prefs.getInt(AccessScreen.K_AWAY, 4)));
        TextView play = label("PLAY IT NOW", 12f, Theme.ACCENT);
        play.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        play.setOnClickListener(v -> host.showAccess(true));
        body.addView(play);
        body.addView(hint("Hacker: code rain, smaller glitchy pictures and a terminal progress bar. Cinematic: full-size scene with a smooth bar. Then ACCESS ACCEPTED with an open green padlock. It plays when you unlock after being away at least as long as you pick (Always = every unlock). Tap to skip. Off in battery saver."));

        heading(body, "AFTER UNLOCK");
        body.addView(toggle("Welcome animation", Prefs.K_INTRO, Prefs.intro()));
        body.addView(slider("Greeting stays for", Prefs.K_GREET_HOLD, 20, Prefs.greetHold(), v ->
                v == 0 ? "until you tap" : String.format(java.util.Locale.US, "%.1f s", v / 2f)));
        body.addView(hint("At 0 the greeting waits, and your tap carries on with the animation."));
        body.addView(toggle("Greeting by time of day", Prefs.K_GREET_AUTO, Prefs.greetAuto()));
        body.addView(hint("Your own greeting (used when the switch above is off)"));
        body.addView(input(Prefs.K_GREETING, rawGreeting(), false), block(6));

        heading(body, "GESTURES");
        body.addView(label("Shapes taught: " + GestureLayer.count(host), 14f, Theme.TEXT), block(8));
        body.addView(hint("Long-press an empty spot on the home screen, then draw a letter or symbol. "
                + "NOVA asks what it should do: open an app, or an action like spinning the wheel. "
                + "Next time you draw it, it runs."));
        TextView forget = label("FORGET ALL SHAPES", 12f, Theme.ACCENT);
        forget.setClickable(true);
        forget.setPadding(0, Theme.dp(host, 14), 0, 0);
        forget.setOnClickListener(v -> {
            GestureLayer.clear(host);
            host.toast("All shapes forgotten");
            host.showSettings();
        });
        body.addView(forget);

        heading(body, "HEY NOVA");
        body.addView(toggle("Voice commands", Prefs.K_VOICE, Prefs.voice(), () -> host.syncVoice()));
        body.addView(toggle("Nova speaks answers", Prefs.K_VOICE_SPEAK, Prefs.voiceSpeak()));
        body.addView(hint("Say \"Hey Nova\" then a command. Listens only while NOVA is on screen. "
                + "Your phone may beep when it starts listening."));

        heading(body, "QUIET & NOTIFICATIONS");
        body.addView(toggle("Quiet hours (auto Do Not Disturb)", Prefs.K_QUIET, Prefs.quiet(),
                () -> QuietHours.apply(host)));
        final TextView qs = label("FROM " + QuietHours.format(Prefs.quietStart()), 12f, Theme.ACCENT);
        qs.setClickable(true);
        qs.setOnClickListener(v -> new android.app.TimePickerDialog(host, (tp, h, m) -> {
            Prefs.putInt(Prefs.K_QSTART, h * 60 + m);
            qs.setText("FROM " + QuietHours.format(h * 60 + m));
            QuietHours.apply(host);
        }, Prefs.quietStart() / 60, Prefs.quietStart() % 60, true).show());
        body.addView(qs, block(10));
        final TextView qe = label("UNTIL " + QuietHours.format(Prefs.quietEnd()), 12f, Theme.ACCENT);
        qe.setClickable(true);
        qe.setOnClickListener(v -> new android.app.TimePickerDialog(host, (tp, h, m) -> {
            Prefs.putInt(Prefs.K_QEND, h * 60 + m);
            qe.setText("UNTIL " + QuietHours.format(h * 60 + m));
            QuietHours.apply(host);
        }, Prefs.quietEnd() / 60, Prefs.quietEnd() % 60, true).show());
        body.addView(qe, block(10));
        TextView dnd = label("ALLOW DND ACCESS", 12f, Theme.ACCENT);
        dnd.setClickable(true);
        dnd.setOnClickListener(v -> {
            try {
                host.startActivity(new android.content.Intent(
                        android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            } catch (Exception ignored) {
            }
        });
        body.addView(dnd, block(10));
        body.addView(hint("Quiet hours turns Do Not Disturb on and off by itself. It needs DND access once. "
                + "Timing can be a few minutes off."));
        body.addView(toggle("Notification digest", Prefs.K_DIGEST, Prefs.digest()));
        body.addView(hint("Low-priority notifications fold into one row in the shade."));

        body.addView(toggle("Ask for music when Momentum 4 connects", Prefs.K_HP_ASK, Prefs.headphoneAsk()));

        heading(body, "BATTERY SAVER");
        body.addView(choice("Battery saver", Prefs.K_SAVER, new String[] {"Off", "Auto (20%)", "Always"},
                Prefs.saverMode(), Saver::refresh));
        body.addView(hint("Saver pauses what moves or listens all the time: animated wallpapers, parallax, holo icons, "
                + "pulsing glows, the castle's crumbling and the wizard's sparks, shake and Hey Nova, "
                + "and the cinematic startup. Auto turns it on at 20% or less when not charging. "
                + "Everything else works as normal."));

        heading(body, "BATTERY USE");
        body.addView(hint("Everything in NOVA that costs extra battery, in one place. They're shortcuts: each one is "
                + "also still in its own category. \uD83D\uDD34 high  \uD83D\uDFE0 medium  \uD83D\uDFE2 low."));
        TextView heavyOff = label("\u26A1 SWITCH ALL HEAVY ONES OFF (\uD83D\uDD34 and \uD83D\uDFE0)   \u203A", 12f, Theme.ACCENT);
        heavyOff.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 6));
        heavyOff.setClickable(true);
        heavyOff.setOnClickListener(v -> {
            Prefs.putInt(Prefs.K_LIVE, 0);
            Prefs.putBool(Prefs.K_PARALLAX, false);
            Prefs.putBool(Prefs.K_HOLO, false);
            Prefs.putBool(Prefs.K_VOICE, false);
            Prefs.putBool(Prefs.K_SHAKE, false);
            Prefs.putBool(Prefs.K_HOME_CODE, false);
            Prefs.putBool(Prefs.K_TOUCH_GLOW, false);
            host.syncVoice();
            host.refreshTheme();
            host.toast("Heavy battery stuff is off");
            host.showSettings();
        });
        body.addView(heavyOff);
        body.addView(choice("\uD83D\uDD34 Animated wallpaper", Prefs.K_LIVE, LiveWallpaper.NAMES, Prefs.liveWall(),
                Upgrades::wallpaperOwned, () -> {
                    if (Prefs.liveWall() == 6) {
                        host.askVizPermission();
                    }
                }));
        body.addView(toggle("\uD83D\uDD34 Hey Nova voice commands (listens all the time)", Prefs.K_VOICE, Prefs.voice(),
                () -> host.syncVoice()));
        body.addView(toggle("\uD83D\uDFE0 Parallax (tilt sensor)", Prefs.K_PARALLAX, Prefs.parallax()));
        body.addView(toggle("\uD83D\uDFE0 Holographic icons (tilt sensor)", Prefs.K_HOLO, Prefs.holo()));
        body.addView(toggle("\uD83D\uDFE0 Shake for a coin flip (motion sensor)", Prefs.K_SHAKE, Prefs.shakeCoin()));
        body.addView(toggle("\uD83D\uDFE0 Code wallpaper (moving)", Prefs.K_HOME_CODE, Prefs.homeCode()));
        body.addView(toggle("\uD83D\uDFE0 Sparks when you touch an icon", Prefs.K_TOUCH_GLOW, Prefs.touchGlow()));
        body.addView(toggle("\uD83D\uDFE2 Glow around the clock", Prefs.K_GLOW_CLOCK, Prefs.glowClock()));
        body.addView(toggle("\uD83D\uDFE2 Purple edge light", Prefs.K_GLOW_EDGES, Prefs.glowEdges()));
        body.addView(toggle("\uD83D\uDFE2 Edge lighting on notifications", Prefs.K_EDGE_FLASH, Prefs.edgeFlash()));
        body.addView(toggle("\uD83D\uDFE2 Auto-update checks", AutoUpdate.K_ON, AutoUpdate.on(), () -> AutoUpdate.schedule(host)));
        body.addView(choice("\uD83D\uDFE2 Haptic feel", Prefs.K_HAPTIC, new String[] {"Off", "Soft", "Crisp", "Strong"},
                Prefs.haptic()));
        body.addView(hint("Widgets also use battery only while they're on screen: \uD83D\uDD34 SONAR, PC SCREENS, "
                + "DCS COCKPIT / WEAPONS (Wi-Fi), \uD83D\uDFE0 NOVA Island. Remove them from home if you don't use them."));

        heading(body, "WIZARD & EXTRAS");
        body.addView(toggle("Wizard mascot (explains things you discover)", Prefs.K_WIZARD, Prefs.wizard(), () -> {
            host.syncWizard();
            if (Prefs.wizard()) {
                host.tip("hello");
            }
        }));
        body.addView(toggle("Castle on the home screen (the wizard lives in it)", Prefs.K_CASTLE,
                Prefs.castleSwitch(), () -> host.wizInside = true));
        body.addView(choice("Wizard suggestions", Prefs.K_NUDGE, new String[] {"Off", "5 min", "1 hour", "12 hours"},
                Prefs.nudgeMode()));
        body.addView(hint("After you unlock and reach the home screen, and this long since the last time, there is a "
                + "50% chance the wizard slides your panel to Slots and asks if you want to gamble. Say no and he tries "
                + "games without coins, then music. Needs the wizard on."));
        body.addView(toggle("Surprises (shooting stars, treasure chests, golden coins)", Prefs.K_EVENTS, Prefs.eventsOn()));
        body.addView(toggle("Your character in the top corner (dances to music, tap him)", "s_dancer",
                Prefs.getBool("s_dancer", true), () -> {
                    if (host.home() != null) {
                        host.showHome();
                    }
                }));
        body.addView(toggle("Castle life (dragon, bats, your weather)", Prefs.K_CLIFE, Prefs.castleLife()));
        body.addView(toggle("Wizard reactions (naps, yawns, cheers)", Prefs.K_REACT, Prefs.reactions()));
        body.addView(toggle("Daily quests", Prefs.K_QUESTS, Prefs.questsOn()));
        body.addView(toggle("Notification critters (tap to dismiss)", Prefs.K_CRITTERS, Prefs.critters()));
        body.addView(toggle("Icon pranks", Prefs.K_PRANKS, Prefs.pranks()));
        final TextView petRow = label("COMPANION: " + Pets.label().toUpperCase()
                + (Pets.locked() ? "  \uD83D\uDD12" : "") + "   \u203A", 12f, Theme.ACCENT);
        petRow.setClickable(true);
        petRow.setOnClickListener(v -> PetPicker.dialog(host, () -> petRow.setText("COMPANION: "
                + Pets.label().toUpperCase() + (Pets.locked() ? "  \uD83D\uDD12" : "") + "   \u203A")));
        body.addView(petRow, block(10));
        TextView netRow = label("NOVA NET: CHAT AND RANKLISTS   \u203A", 12f, Theme.ACCENT);
        netRow.setClickable(true);
        netRow.setOnClickListener(v -> NetScreen.open(host));
        if (NovaNet.ENABLED) {
            body.addView(netRow, block(10));
        }
        TextView coinShop = label("COIN SHOP   \u203A", 12f, Theme.ACCENT);
        coinShop.setClickable(true);
        coinShop.setOnClickListener(v -> CoinShop.open(host));
        body.addView(coinShop, block(10));
        TextView shop = label("CASTLE WORKSHOP   \u203A", 12f, Theme.ACCENT);
        shop.setClickable(true);
        shop.setOnClickListener(v -> CastleWorkshop.open(host));
        body.addView(shop, block(10));
        body.addView(toggle("Left-handed home (castle on the left)", "s_lefty", Prefs.getBool("s_lefty", false), () -> {
            if (host.home() != null) {
                host.showHome();
            }
        }));
        body.addView(toggle("Seasonal castle decorations (pumpkins, lights, hearts)", "s_seasons",
                Prefs.getBool("s_seasons", true)));
        TextView again = label("SHOW ALL TIPS AGAIN", 12f, Theme.ACCENT);
        again.setClickable(true);
        again.setOnClickListener(v -> {
            for (String id : Tips.allIds()) {
                Prefs.putInt("tip_" + id, 0);
            }
            host.toast("The wizard will explain everything again");
        });
        body.addView(again, block(10));
        body.addView(toggle("Sounds", Prefs.K_SFX, Prefs.sfx(), () -> Sfx.play(Sfx.BLIP)));
        body.addView(toggle("Charging clock (dim clock when charging and idle)", Prefs.K_NIGHT, Prefs.nightClock()));
        body.addView(toggle("Use NOVA's own Phone, Camera and Gallery", Prefs.K_NATIVE, Prefs.nativeApps()));
        body.addView(hint("When on, opening the stock phone, camera or gallery from NOVA opens NOVA's own. "
                + "Each has a STOCK button if you want the normal app."));
        TextView setup = label("RUN SETUP AGAIN", 12f, Theme.ACCENT);
        setup.setClickable(true);
        setup.setOnClickListener(v -> {
            host.showHome();
            host.root.postDelayed(host::showSetup, 900);
        });
        body.addView(setup, block(14));

        heading(body, "CASINO");
        body.addView(toggle("Cheat mode (roulette)", Prefs.K_CHEAT, Prefs.cheat()));
        body.addView(hint("A secret tell. The word COINS in the top left shows the next result: "
                + "COINS = black, coins = red, Coins = green zero."));

        heading(body, "STATS");
        body.addView(label("Unlocks: " + Prefs.unlocks() + "    Apps: " + host.repo.all.size(),
                14f, Theme.TEXT), block(8));
        body.addView(label("Slot coins: " + Prefs.getInt("slot_coins", 100), 14f, Theme.TEXT), block(8));
        if (!UsageHelper.hasAccess(host)) {
            TextView usage = label("ALLOW APP USAGE ACCESS", 12f, Theme.ACCENT);
            usage.setClickable(true);
            usage.setPadding(0, Theme.dp(host, 14), 0, 0);
            usage.setOnClickListener(v -> {
                try {
                    host.startActivity(new android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    host.toast("Not available on this phone");
                }
            });
            body.addView(usage);
            body.addView(hint("Needed for the APP USAGE and screen-time numbers on the home panel."));
        }

        heading(body, "COMFORT & CARE");
        body.addView(slider("NOVA sound volume", "s_vol", 100, Prefs.getInt("s_vol", 100), v -> v + "%"));
        body.addView(toggle("Reduce motion (calms animations, saves battery)", "s_reduce", Prefs.getBool("s_reduce", false)));
        body.addView(toggle("Warm evening tint", "s_tint", Prefs.getBool("s_tint", false), host::applyTint));
        body.addView(hint("Reduce motion keeps the castle and wizard still, like the battery saver does."));
        TextView safe = label("SAFE MODE: SWITCH THE EXTRAS OFF   \u203A", 12f, Theme.ACCENT);
        safe.setClickable(true);
        safe.setOnClickListener(v -> {
            CrashLog.safeMode(host);
            host.toast("Safe mode: castle life, surprises, critters, pranks and reactions are off");
        });
        body.addView(safe, block(10));
        TextView health = label("HEALTH CHECK   \u203A", 12f, Theme.ACCENT);
        health.setClickable(true);
        health.setOnClickListener(v -> healthCheck());
        body.addView(health, block(10));
        TextView news = label("WHAT'S NEW / CHANGELOG   \u203A", 12f, Theme.ACCENT);
        news.setClickable(true);
        news.setOnClickListener(v -> Changelog.show(host));
        body.addView(news, block(10));
        TextView bk = label("BACKUP: COPY ALL SETTINGS   \u203A", 12f, Theme.ACCENT);
        bk.setClickable(true);
        bk.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    host.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("nova", Admin.exportAll()));
            host.toast("Copied. Paste it somewhere safe.");
        });
        body.addView(bk, block(10));
        TextView rs = label("RESTORE FROM CLIPBOARD   \u203A", 12f, Theme.ACCENT);
        rs.setClickable(true);
        rs.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    host.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            android.content.ClipData d = cm.getPrimaryClip();
            String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
            int n = Admin.importAll(t);
            host.toast(n < 0 ? "The clipboard has no NOVA backup" : n + " values restored. Restart NOVA to see all of it.");
        });
        body.addView(rs, block(10));
        TextView fb = label("SEND FEEDBACK (with the last crash log)   \u203A", 12f, Theme.ACCENT);
        fb.setClickable(true);
        fb.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_SUBJECT, "NOVA " + Theme.OS_VERSION + " feedback");
            String crash = CrashLog.read(host);
            i.putExtra(android.content.Intent.EXTRA_TEXT, "NOVA " + Theme.OS_VERSION + " on " + android.os.Build.MODEL
                    + " (Android " + android.os.Build.VERSION.RELEASE + ")\n\nMy feedback:\n\n\n"
                    + (crash.isEmpty() ? "" : "--- last crash ---\n" + crash));
            host.startActivity(android.content.Intent.createChooser(i, "Send feedback"));
        });
        body.addView(fb, block(10));

        heading(body, "UPDATES");
        String ver;
        try {
            android.content.pm.PackageInfo pi = host.getPackageManager().getPackageInfo(host.getPackageName(), 0);
            ver = pi.versionName + " (build " + pi.versionCode + ")";
        } catch (Exception e) {
            ver = "unknown";
        }
        body.addView(label("Version " + ver, 14f, Theme.TEXT), block(8));
        TextView status = label("", 12f, Theme.DIM);
        status.setPadding(0, Theme.dp(host, 10), 0, 0);
        TextView check = label("CHECK FOR UPDATE", 12f, Theme.ACCENT);
        check.setClickable(true);
        check.setPadding(0, Theme.dp(host, 14), 0, 0);
        check.setOnClickListener(v -> Updater.check(host, status));
        body.addView(check);
        body.addView(status);
        TextView tm = label("\u23EA SWITCH VERSION (any older NOVA, keeps your stuff)   \u203A", 12f, Theme.ACCENT);
        tm.setClickable(true);
        tm.setPadding(0, Theme.dp(host, 14), 0, 0);
        tm.setOnClickListener(v -> TimeMachine.open(host));
        body.addView(tm);
        if (TimeMachine.justRestored(host)) {
            host.toast("\u2714 Your stuff from before the switch is back");
        }
        body.addView(toggle("Auto-update (checks GitHub and installs new builds by itself)", AutoUpdate.K_ON, AutoUpdate.on(),
                () -> AutoUpdate.schedule(host)));
        body.addView(toggle("Only on Wi-Fi", AutoUpdate.K_WIFI, Prefs.getBool(AutoUpdate.K_WIFI, true),
                () -> AutoUpdate.schedule(host)));
        body.addView(choice("Check every", AutoUpdate.K_EVERY, new String[] {"1 hour", "3 hours", "6 hours", "12 hours", "24 hours"},
                Prefs.getInt(AutoUpdate.K_EVERY, 1), () -> AutoUpdate.schedule(host)));
        body.addView(hint(AutoUpdate.lastText() + ". It never installs while you are using NOVA: it waits until the screen is "
                + "off or you are in another app, then NOVA restarts on the new version. The first time, Android may still "
                + "ask you once (or show a \"NOVA update ready\" notification)."));

        TextView tok = label("GITHUB TOKEN (only if the repo is private) \u203A", 12f, Theme.ACCENT);
        tok.setClickable(true);
        tok.setPadding(0, Theme.dp(host, 14), 0, 0);
        tok.setOnClickListener(v -> {
            final android.widget.EditText e = new android.widget.EditText(host);
            e.setSingleLine(true);
            e.setHint("github_pat_...");
            e.setText(Prefs.getString("gh_token", ""));
            new android.app.AlertDialog.Builder(host).setTitle("GitHub token")
                    .setMessage("For a private repo: on github.com > Settings > Developer settings > Personal access "
                            + "tokens, make a fine-grained token for nova-os with read access to Contents. It stays on "
                            + "this phone. Empty = no token.")
                    .setView(e)
                    .setPositiveButton("SAVE", (d, w) -> Prefs.putString("gh_token", e.getText().toString().trim()))
                    .setNegativeButton("Cancel", null).show();
        });
        body.addView(tok);

        TextView upd = label("INSTALL UPDATE FROM A FILE", 12f, Theme.ACCENT);
        upd.setClickable(true);
        upd.setPadding(0, Theme.dp(host, 14), 0, 0);
        upd.setOnClickListener(v -> host.pickUpdate());
        body.addView(upd);
        body.addView(hint("Pick a NOVA .apk file from your phone. Android then asks you to confirm."));

        TextView reset = label("RESET ALL SETTINGS", 12f, Theme.ACCENT);
        reset.setClickable(true);
        reset.setPadding(0, Theme.dp(host, 28), 0, Theme.dp(host, 16));
        reset.setOnClickListener(v -> {
            Prefs.reset();
            host.refreshTheme();
        });
        body.addView(reset);

        final TextView none = label("No setting matches that.", 12f, Theme.DIM);
        none.setPadding(0, Theme.dp(host, 20), 0, 0);
        none.setVisibility(View.GONE);
        body.addView(none);
        noneRef = none;
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                none.setVisibility(filter(body, s.toString(), none) ? View.GONE : View.VISIBLE);
            }
        });

        heading(body, "ADMIN");
        if (Castle.admin()) {
            body.addView(toggle("Admins own every item", "adm_owns", Prefs.getBool("adm_owns", true)));
            body.addView(hint("On: every item shows as owned for you. Purchases still cost coins. Off: you only have what you bought."));
        }
        TextView adm = label(Castle.admin() ? "OPEN ADMIN PANEL   \u203A" : "ADMIN ACCESS   \u203A", 12f, Theme.ACCENT);
        adm.setClickable(true);
        adm.setOnClickListener(v -> {
            if (Castle.admin()) {
                AdminPanel.open(host);
                return;
            }
            final EditText pw = new EditText(host);
            pw.setHint("password");
            pw.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            new android.app.AlertDialog.Builder(host).setTitle("Admin password").setView(pw)
                    .setPositiveButton("OK", (d, w) -> {
                        if (Admin.unlock(pw.getText().toString())) {
                            host.toast("Admin mode on");
                            adm.setText("OPEN ADMIN PANEL   \u203A");
                        } else {
                            host.toast("Wrong password");
                        }
                    }).setNegativeButton("Cancel", null).show();
        });
        body.addView(adm, block(10));
        body.addView(hint("Admin mode: a panel of secret levers, and terminal commands (type adm)."));

        // start with every category closed (or as you left them)
        if (OPEN.isEmpty()) {
            for (String k : Prefs.getString("set_open", "").split("\n")) {
                if (!k.isEmpty()) {
                    OPEN.add(k);
                }
            }
        }
        recount(body);
        filter(body, "", none);
    }

    /** Puts how many settings are inside next to each category name. */
    private void recount(LinearLayout body) {
        TextView head = null;
        int n = 0;
        for (int i = 0; i <= body.getChildCount(); i++) {
            View c = i < body.getChildCount() ? body.getChildAt(i) : null;
            if (c == null || "h".equals(c.getTag())) {
                if (head != null) {
                    String name = String.valueOf(head.getContentDescription());
                    head.setText((OPEN.contains(name) ? "\u25BE  " : "\u25B8  ") + name + "   \u00B7 " + n);
                }
                head = c == null ? null : (TextView) c;
                n = 0;
            } else if (c != noneRef && c.isClickable()) {
                n++;
            } else if (c != noneRef && c instanceof LinearLayout) {
                n++;
            }
        }
    }

    private void toggleCat(String name) {
        if (!OPEN.remove(name)) {
            OPEN.add(name);
        }
        Prefs.putString("set_open", String.join("\n", OPEN));
        if (searchRef != null && searchRef.getText().length() > 0) {
            searchRef.setText("");
        }
        recount(bodyRef);
        filter(bodyRef, "", noneRef);
    }

    /** The palettes, four to a row. */
    /** A row with a label, the current value and a slider underneath. */
    private void healthCheck() {
        StringBuilder sb = new StringBuilder();
        String listeners = android.provider.Settings.Secure.getString(host.getContentResolver(),
                "enabled_notification_listeners");
        sb.append(listeners != null && listeners.contains(host.getPackageName()) ? "OK  " : "OFF ")
                .append("Notification access (music card, critters, badges)\n");
        boolean usage = false;
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager) host.getSystemService(android.content.Context.APP_OPS_SERVICE);
            usage = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), host.getPackageName())
                    == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
            // unknown
        }
        sb.append(usage ? "OK  " : "OFF ").append("Usage access (APP USAGE page)\n");
        sb.append(host.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED ? "OK  " : "OFF ")
                .append("Microphone (Hey Nova, voice notes)\n");
        sb.append(host.checkSelfPermission(android.Manifest.permission.CAMERA)
                == android.content.pm.PackageManager.PERMISSION_GRANTED ? "OK  " : "OFF ")
                .append("Camera\n");
        sb.append(WeatherData.hasCity() ? "OK  " : "OFF ").append("Weather city (castle weather)\n");
        sb.append(Saver.on() ? "ON  " : "off ").append("Battery saver right now\n");
        Runtime rt = Runtime.getRuntime();
        sb.append("\nMemory ").append((rt.totalMemory() - rt.freeMemory()) >> 20).append(" MB of ")
                .append(rt.maxMemory() >> 20).append(" MB\nNOVA ").append(Theme.OS_VERSION);
        new android.app.AlertDialog.Builder(host).setTitle("Health check").setMessage(sb.toString())
                .setPositiveButton("OK", null).show();
    }

    private View slider(String text, final String key, int max, int current,
                        final java.util.function.IntFunction<String> format) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(VERTICAL);
        box.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 4));

        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        top.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView value = label(format.apply(current), 12f, Theme.ACCENT);
        top.addView(value);
        box.addView(top);

        android.widget.SeekBar bar = new android.widget.SeekBar(host);
        bar.setMax(max);
        bar.setProgress(current);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                value.setText(format.apply(progress));
                if (fromUser) {
                    Prefs.putInt(key, progress);
                }
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar sb) {
            }
        });
        box.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private String rawGreeting() {
        String g = Prefs.getString(Prefs.K_GREETING, "welcome");
        return g;
    }

    /** Sets, changes or removes the NOVA PIN. */
    private View pinRow() {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));
        TextView l = new TextView(host);
        l.setText(Prefs.hasPin() ? "NOVA PIN (" + Prefs.pinLength() + " digits)" : "NOVA PIN");
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView set = label(Prefs.hasPin() ? "CHANGE" : "SET", 12f, Theme.ACCENT);
        set.setClickable(true);
        set.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), Theme.dp(host, 10), Theme.dp(host, 6));
        set.setOnClickListener(v -> askPin());
        r.addView(set);
        if (Prefs.hasPin()) {
            TextView rm = label("REMOVE", 12f, Theme.DIM);
            rm.setClickable(true);
            rm.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), 0, Theme.dp(host, 6));
            rm.setOnClickListener(v -> {
                Prefs.clearPin();
                Prefs.putBool(Prefs.K_BIO, false);
                host.toast("PIN removed");
                host.showSettings();
            });
            r.addView(rm);
        }
        return r;
    }

    private void askPin() {
        final EditText e = new EditText(host);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setHint("4 to 8 digits");
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(Theme.DIM);
        e.setPadding(Theme.dp(host, 24), Theme.dp(host, 16), Theme.dp(host, 24), Theme.dp(host, 16));
        new android.app.AlertDialog.Builder(host, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Choose a PIN")
                .setView(e)
                .setPositiveButton("Save", (d, w) -> {
                    String p = e.getText().toString().trim();
                    if (p.length() < 4 || p.length() > 8) {
                        host.toast("Use 4 to 8 digits");
                        return;
                    }
                    Prefs.setPin(p);
                    host.toast("PIN saved");
                    host.showSettings();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** The palettes, four to a row. */
    private View accentRow() {
        LinearLayout all = new LinearLayout(host);
        all.setOrientation(VERTICAL);
        int per = 4;
        for (int start = 0; start < Theme.PRESET_NAMES.length; start += per) {
            LinearLayout row = new LinearLayout(host);
            row.setOrientation(HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            for (int i = start; i < Math.min(start + per, Theme.PRESET_NAMES.length); i++) {
                final int idx = i;
                LinearLayout col = new LinearLayout(host);
                col.setOrientation(VERTICAL);
                col.setGravity(Gravity.CENTER_HORIZONTAL);
                col.setClickable(true);
                col.setPadding(0, Theme.dp(host, 4), 0, Theme.dp(host, 4));
                final boolean locked = idx >= Shop.FIRST_PREMIUM && !Castle.owns("accent", idx) && !Castle.adminOwns();
                col.setOnClickListener(v -> {
                    if (locked) {
                        host.toast("Premium colour: buy it in the Coin Shop (" + Shop.ACCENT_COST + " coins)");
                        return;
                    }
                    Prefs.putInt(Prefs.K_ACCENT, idx);
                    host.refreshTheme();
                });

                View dot = new View(host);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(Theme.presetAccent(i));
                if (Prefs.accent() == i) {
                    g.setStroke(Theme.dp(host, 3), Theme.TEXT);
                }
                dot.setBackground(g);
                col.addView(dot, new LinearLayout.LayoutParams(Theme.dp(host, 44), Theme.dp(host, 44)));

                TextView name = label((i >= Shop.FIRST_PREMIUM && !Castle.owns("accent", i) && !Castle.adminOwns() ? "\uD83D\uDD12 " : "")
                        + Theme.PRESET_NAMES[i].toUpperCase(), 10f, Theme.DIM);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                np.topMargin = Theme.dp(host, 6);
                col.addView(name, np);

                row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            }
            all.addView(row);
        }
        return all;
    }

    private View toggle(String text, final String key, boolean value) {
        return toggle(text, key, value, null);
    }

    private View toggle(String text, final String key, boolean value, final Runnable after) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));

        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        Switch s = new Switch(host);
        s.setChecked(value);
        s.setOnCheckedChangeListener((b, on) -> {
            Prefs.putBool(key, on);
            if (after != null) {
                r.post(after);
            }
        });
        r.addView(s);
        return r;
    }

    /** A row that cycles through a few options each time you tap its value. */
    private View choice(String text, final String key, final String[] options, int current) {
        return choice(text, key, options, current, null);
    }

    private View choice(String text, final String key, final String[] options, int current, final Runnable after) {
        return choice(text, key, options, current, i -> true, after);
    }

    private View choice(String text, final String key, final String[] options, int current,
            final java.util.function.IntPredicate allowed, final Runnable after) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, Theme.dp(host, 10), 0, Theme.dp(host, 10));

        TextView l = new TextView(host);
        l.setText(text);
        l.setTextSize(15f);
        l.setTextColor(Theme.TEXT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final int[] idx = {Math.max(0, Math.min(options.length - 1, current))};
        final TextView v = label(options[idx[0]].toUpperCase(), 12f, Theme.ACCENT);
        v.setClickable(true);
        v.setOnClickListener(x -> {
            if (options.length > 12) {
                // long lists open as a list to pick from instead of stepping through them one by one
                new android.app.AlertDialog.Builder(host)
                        .setTitle(text)
                        .setSingleChoiceItems(options, idx[0], (dlg, which) -> {
                            dlg.dismiss();
                            if (!allowed.test(which)) {
                                return;
                            }
                            idx[0] = which;
                            Prefs.putInt(key, which);
                            v.setText(options[which].toUpperCase());
                            if (after != null) {
                                after.run();
                            }
                        })
                        .show();
                return;
            }
            int tries = 0;
            do {
                idx[0] = (idx[0] + 1) % options.length;
            } while (!allowed.test(idx[0]) && ++tries < options.length);
            Prefs.putInt(key, idx[0]);
            v.setText(options[idx[0]].toUpperCase());
            if (after != null) {
                after.run();
            }
        });
        r.addView(v);
        return r;
    }

    private EditText input(final String key, String value, boolean multi) {
        EditText e = new EditText(host);
        e.setText(value);
        e.setTextSize(14f);
        e.setTextColor(Theme.TEXT);
        e.setHint("type here");
        e.setHintTextColor(Theme.DIM);
        e.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        e.setPadding(Theme.dp(host, 14), Theme.dp(host, 12), Theme.dp(host, 14), Theme.dp(host, 12));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | (multi ? InputType.TYPE_TEXT_FLAG_MULTI_LINE : 0));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                Prefs.putString(key, s.toString());
            }
        });
        return e;
    }

    /** All the text inside a view, lower case. */
    private static String textOf(View v) {
        StringBuilder sb = new StringBuilder();
        if (v instanceof TextView) {
            sb.append(((TextView) v).getText()).append(' ');
        }
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                sb.append(textOf(g.getChildAt(i)));
            }
        }
        return sb.toString().toLowerCase(java.util.Locale.ROOT);
    }

    /** Shows only the settings that match, with their headings. Returns false if nothing matched. */
    private boolean filter(LinearLayout body, String query, View none) {
        String q = query.trim().toLowerCase(java.util.Locale.ROOT);
        boolean any = false;
        View head = null;
        boolean headMatch = false;
        int shown = 0;
        boolean lastMatched = false;
        for (int i = 0; i < body.getChildCount(); i++) {
            View c = body.getChildAt(i);
            if (c == none) {
                continue;
            }
            if ("line".equals(c.getTag())) {
                c.setVisibility(q.isEmpty() ? View.VISIBLE : View.GONE);
                continue;
            }
            if ("h".equals(c.getTag())) {
                if (head != null) {
                    head.setVisibility(q.isEmpty() || shown > 0 || headMatch ? View.VISIBLE : View.GONE);
                }
                head = c;
                headMatch = !q.isEmpty() && textOf(c).contains(q);
                shown = 0;
                lastMatched = false;
                continue;
            }
            boolean isHint = c instanceof TextView && !c.isClickable();
            boolean closed = q.isEmpty() && head != null && !OPEN.contains(String.valueOf(head.getContentDescription()));
            boolean match = !closed && (q.isEmpty() || headMatch || textOf(c).contains(q) || (isHint && lastMatched));
            c.setVisibility(match ? View.VISIBLE : View.GONE);
            lastMatched = match && !q.isEmpty() && !headMatch;
            if (match) {
                shown++;
                any = true;
            }
        }
        if (head != null) {
            head.setVisibility(q.isEmpty() || shown > 0 || headMatch ? View.VISIBLE : View.GONE);
        }
        return q.isEmpty() || any;
    }

    private void heading(LinearLayout body, String text) {
        TextView t = label("\u25B8  " + text, 13f, Theme.ACCENT);
        t.setTag("h");
        t.setContentDescription(text);
        t.setLetterSpacing(0.15f);
        t.setClickable(true);
        t.setPadding(0, Theme.dp(host, 14), 0, Theme.dp(host, 14));
        t.setOnClickListener(v -> toggleCat(text));
        LinearLayout.LayoutParams p = block(4);
        body.addView(t, p);
        // a thin line under each category, like Android Settings
        View line = new View(host);
        line.setTag("line");
        line.setBackgroundColor(0x18FFFFFF);
        body.addView(line, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
    }

    private void hint(LinearLayout body, String text) {
        body.addView(hint(text));
    }

    private TextView hint(String text) {
        TextView t = label(text, 12f, Theme.DIM);
        t.setTypeface(android.graphics.Typeface.DEFAULT);
        t.setPadding(0, Theme.dp(host, 14), 0, 0);
        return t;
    }

    private TextView label(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams block(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = Theme.dp(host, topDp);
        return p;
    }
}
