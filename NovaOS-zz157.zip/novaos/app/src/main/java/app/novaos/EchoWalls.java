package app.novaos;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * ECHO WALLS: notes pinned to real places. Leave text, a photo and/or a voice memo where you stand; the next time you
 * come back, NOVA pops it up. Uses Android's own area alerts (no constant tracking). Everything stays on the phone.
 */
final class EchoWalls {
    static final String K_LIST = "echo_list";
    static final int[] RADII = {20, 50, 100, 500};
    static final String[] MODES = {"Every time I'm there", "Only once", "Time capsule: only after a date"};
    private static final String CHANNEL = "nova_echo";
    private static final long COOLDOWN = 45 * 60000L;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    static volatile Runnable listener;

    private EchoWalls() {
    }

    /** One echo. */
    static final class Echo {
        String id;
        double lat;
        double lon;
        int radius;
        String text = "";
        String photo = "";
        String voice = "";
        int mode;
        long openAt;
        long created;
        long lastShown;
        boolean done;

        boolean locked() {
            return mode == 2 && System.currentTimeMillis() < openAt;
        }

        JSONObject json() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("lat", lat);
            o.put("lon", lon);
            o.put("r", radius);
            o.put("text", text);
            o.put("photo", photo);
            o.put("voice", voice);
            o.put("mode", mode);
            o.put("openAt", openAt);
            o.put("created", created);
            o.put("last", lastShown);
            o.put("done", done);
            return o;
        }

        static Echo of(JSONObject o) {
            Echo e = new Echo();
            e.id = o.optString("id");
            e.lat = o.optDouble("lat");
            e.lon = o.optDouble("lon");
            e.radius = o.optInt("r", 50);
            e.text = o.optString("text", "");
            e.photo = o.optString("photo", "");
            e.voice = o.optString("voice", "");
            e.mode = o.optInt("mode", 0);
            e.openAt = o.optLong("openAt", 0);
            e.created = o.optLong("created", 0);
            e.lastShown = o.optLong("last", 0);
            e.done = o.optBoolean("done", false);
            return e;
        }

        String title() {
            if (locked()) {
                return "🔒 Time capsule · opens " + day(openAt);
            }
            String t = text.trim();
            if (t.isEmpty()) {
                t = !photo.isEmpty() ? "📷 Photo" : !voice.isEmpty() ? "🎙 Voice memo" : "Echo";
            }
            return t.length() > 40 ? t.substring(0, 40) + "…" : t;
        }
    }

    // ------------------------------------------------------------------ storage

    static synchronized List<Echo> all() {
        List<Echo> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.getString(K_LIST, "[]"));
            for (int i = 0; i < a.length(); i++) {
                out.add(Echo.of(a.getJSONObject(i)));
            }
        } catch (Exception ignored) {
            // empty
        }
        return out;
    }

    static synchronized void save(List<Echo> list) {
        try {
            JSONArray a = new JSONArray();
            for (Echo e : list) {
                a.put(e.json());
            }
            Prefs.putString(K_LIST, a.toString());
        } catch (Exception ignored) {
            // keep the old list
        }
        Runnable r = listener;
        if (r != null) {
            MAIN.post(r);
        }
    }

    static Echo find(String id) {
        for (Echo e : all()) {
            if (e.id.equals(id)) {
                return e;
            }
        }
        return null;
    }

    static void put(Context c, Echo e) {
        List<Echo> l = all();
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id.equals(e.id)) {
                l.set(i, e);
                found = true;
            }
        }
        if (!found) {
            l.add(e);
        }
        save(l);
        sync(c);
    }

    static void delete(Context c, String id) {
        List<Echo> l = all();
        for (int i = l.size() - 1; i >= 0; i--) {
            Echo e = l.get(i);
            if (e.id.equals(id)) {
                if (!e.photo.isEmpty()) {
                    new File(e.photo).delete();
                }
                if (!e.voice.isEmpty()) {
                    new File(e.voice).delete();
                }
                unwatch(c, e.id);
                l.remove(i);
            }
        }
        save(l);
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "echo");
        d.mkdirs();
        return d;
    }

    static String day(long t) {
        return new SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(new Date(t));
    }

    // ------------------------------------------------------------------ location

    static boolean canLocate(Context c) {
        return c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    static boolean canBackground(Context c) {
        return Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(android.Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    /** The newest position the phone knows, or null. */
    static Location last(Context c) {
        if (!canLocate(c)) {
            return null;
        }
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        try {
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) {
                    best = l;
                }
            }
        } catch (SecurityException ignored) {
            // no permission
        }
        return best;
    }

    interface Got {
        void got(Location l);
    }

    /** A fresh position (GPS), up to 12 s; falls back to the last known one. Calls back on the main thread. */
    @SuppressWarnings({"deprecation", "MissingPermission"})
    static void here(final Context c, final Got cb) {
        final LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        final boolean[] answered = {false};
        final android.location.LocationListener[] ll = new android.location.LocationListener[1];
        final Runnable fallback = () -> {
            if (!answered[0]) {
                answered[0] = true;
                if (ll[0] != null) {
                    lm.removeUpdates(ll[0]);
                }
                cb.got(last(c));
            }
        };
        try {
            String prov = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? LocationManager.GPS_PROVIDER
                    : LocationManager.NETWORK_PROVIDER;
            ll[0] = new android.location.LocationListener() {
                @Override
                public void onLocationChanged(Location l) {
                    if (!answered[0] && l.getAccuracy() < 40) {
                        answered[0] = true;
                        lm.removeUpdates(this);
                        MAIN.removeCallbacks(fallback);
                        cb.got(l);
                    }
                }

                @Override
                public void onStatusChanged(String p, int s, android.os.Bundle b) {
                }

                @Override
                public void onProviderEnabled(String p) {
                }

                @Override
                public void onProviderDisabled(String p) {
                }
            };
            lm.requestLocationUpdates(prov, 1000L, 0f, ll[0], Looper.getMainLooper());
        } catch (Exception e) {
            // no provider
        }
        MAIN.postDelayed(fallback, 12000);
    }

    static float distance(Echo e, Location me) {
        float[] r = new float[1];
        Location.distanceBetween(me.getLatitude(), me.getLongitude(), e.lat, e.lon, r);
        return r[0];
    }

    static float bearing(Echo e, Location me) {
        float[] r = new float[2];
        Location.distanceBetween(me.getLatitude(), me.getLongitude(), e.lat, e.lon, r);
        return r.length > 1 ? r[1] : 0;
    }

    static String dist(float m) {
        return m < 1000 ? Math.round(m) + " m" : String.format(Locale.ROOT, "%.1f km", m / 1000f);
    }

    // ------------------------------------------------------------------ area alerts

    private static PendingIntent pi(Context c, String id, int flag) {
        Intent i = new Intent(c, Near.class);
        i.setData(Uri.parse("echo://" + id));
        int mut = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flag | mut);
    }

    /** Registers an area alert for every echo that can still show up (after boot, changes, start). */
    @SuppressWarnings("MissingPermission")
    static void sync(Context c) {
        if (!canLocate(c)) {
            return;
        }
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        for (Echo e : all()) {
            try {
                PendingIntent p = pi(c, e.id, PendingIntent.FLAG_UPDATE_CURRENT);
                lm.removeProximityAlert(p);
                if (!e.done) {
                    lm.addProximityAlert(e.lat, e.lon, Math.max(20, e.radius), -1, p);
                }
            } catch (Exception ignored) {
                // no location right now
            }
        }
    }

    private static void unwatch(Context c, String id) {
        try {
            LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            lm.removeProximityAlert(pi(c, id, PendingIntent.FLAG_UPDATE_CURRENT));
        } catch (Exception ignored) {
            // not watched
        }
    }

    /** Android says: you just walked into an echo's area. */
    public static class Near extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            Prefs.init(c);
            if (!i.getBooleanExtra(LocationManager.KEY_PROXIMITY_ENTERING, false) || i.getData() == null) {
                return;
            }
            String id = i.getData().getHost();
            Echo e = id == null ? null : find(id);
            if (e == null || e.done || e.locked()) {
                return;
            }
            long now = System.currentTimeMillis();
            if (now - e.lastShown < COOLDOWN) {
                return;
            }
            e.lastShown = now;
            if (e.mode == 1 || e.mode == 2) {
                e.done = true;
                unwatch(c, e.id);
            }
            put(c, e);
            notify(c, e);
        }
    }

    static void notify(Context c, Echo e) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Echo walls", NotificationManager.IMPORTANCE_HIGH));
            Intent open = new Intent(c, NovaActivity.class);
            open.putExtra("open", "echo:" + e.id);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, e.id.hashCode(), open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String when = "left on " + day(e.created);
            Notification n = new Notification.Builder(c, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_map)
                    .setContentTitle(e.mode == 2 ? "📦 A time capsule opened here!" : "📍 You left an echo here")
                    .setContentText(e.text.isEmpty() ? when + " · tap to open" : e.text)
                    .setStyle(new Notification.BigTextStyle().bigText((e.text.isEmpty() ? "" : e.text + "\n") + when))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(e.id.hashCode(), n);
        } catch (Exception ignored) {
            // notifications off
        }
    }

    // ------------------------------------------------------------------ showing one

    static void show(final NovaActivity host, String id) {
        final Echo e = find(id);
        if (e == null) {
            host.toast("That echo is gone");
            return;
        }
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(LinearLayout.VERTICAL);
        int p = Theme.dp(host, 18);
        v.setPadding(p, p / 2, p, 0);
        Location me = last(host);
        TextView meta = new TextView(host);
        meta.setTextColor(Theme.DIM);
        meta.setTextSize(11f);
        meta.setText("Left " + day(e.created) + (me != null ? " · " + dist(distance(e, me)) + " away" : "")
                + " · " + MODES[e.mode] + (e.mode == 2 ? " (" + day(e.openAt) + ")" : ""));
        v.addView(meta);
        final MediaPlayer[] player = new MediaPlayer[1];
        if (e.locked()) {
            TextView t = new TextView(host);
            t.setTextColor(Theme.TEXT);
            t.setTextSize(15f);
            t.setPadding(0, p / 2, 0, 0);
            t.setText("🔒 Sealed until " + day(e.openAt) + ".\nCome back to this place after that day.");
            v.addView(t);
        } else {
            if (!e.text.isEmpty()) {
                TextView t = new TextView(host);
                t.setTextColor(Theme.TEXT);
                t.setTextSize(16f);
                t.setPadding(0, p / 2, 0, 0);
                t.setText(e.text);
                v.addView(t);
            }
            if (!e.photo.isEmpty() && new File(e.photo).exists()) {
                ImageView iv = new ImageView(host);
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 4;
                Bitmap b = BitmapFactory.decodeFile(e.photo, o);
                iv.setImageBitmap(b);
                iv.setAdjustViewBounds(true);
                iv.setPadding(0, p / 2, 0, 0);
                v.addView(iv, new LinearLayout.LayoutParams(-1, -2));
            }
            if (!e.voice.isEmpty() && new File(e.voice).exists()) {
                TextView play = new TextView(host);
                play.setTextColor(Theme.ACCENT);
                play.setTextSize(14f);
                play.setPadding(0, p / 2, 0, p / 2);
                play.setText("▶  PLAY THE VOICE MEMO");
                play.setOnClickListener(x -> {
                    try {
                        if (player[0] != null) {
                            player[0].release();
                        }
                        player[0] = new MediaPlayer();
                        player[0].setDataSource(e.voice);
                        player[0].prepare();
                        player[0].start();
                    } catch (Exception ex) {
                        host.toast("Couldn't play it");
                    }
                });
                v.addView(play);
            }
        }
        ScrollView sv = new ScrollView(host);
        sv.addView(v);
        new AlertDialog.Builder(host).setTitle(e.mode == 2 ? "📦 Time capsule" : "📍 Echo")
                .setView(sv)
                .setPositiveButton("CLOSE", null)
                .setNeutralButton("DELETE", (d, w) -> new AlertDialog.Builder(host).setTitle("Delete this echo?")
                        .setPositiveButton("DELETE", (d2, w2) -> {
                            delete(host, e.id);
                            host.toast("Echo deleted");
                        }).setNegativeButton("KEEP", null).show())
                .setNegativeButton("MAP", (d, w) -> {
                    try {
                        host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + e.lat + "," + e.lon
                                + "?q=" + e.lat + "," + e.lon + "(Echo)")));
                    } catch (Exception ex) {
                        host.toast("No maps app");
                    }
                })
                .setOnDismissListener(d -> {
                    if (player[0] != null) {
                        player[0].release();
                    }
                })
                .show();
    }
}
