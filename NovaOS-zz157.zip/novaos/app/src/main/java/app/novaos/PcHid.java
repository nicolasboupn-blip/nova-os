package app.novaos;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * The phone as a Bluetooth keyboard, mouse and media remote for a PC (Android 9+). Windows sees "NOVA Remote" as a
 * normal keyboard and mouse, so nothing has to be installed on the PC. Keys are sent by position, so text is typed
 * through a map for the PC's keyboard layout (Swiss German, German or US).
 */
final class PcHid {
    static final String K_ADDR = "pc_addr";
    static final String K_LAYOUT = "pc_layout";
    static final String[] LAYOUTS = {"Swiss (CH)", "German (DE)", "US"};

    static final int CTRL = 0x01;
    static final int SHIFT = 0x02;
    static final int ALT = 0x04;
    static final int WIN = 0x08;
    static final int ALTGR = 0x40;

    private static final byte[] DESCRIPTOR = {
        // keyboard, report 1: modifiers, reserved, 6 keys
        0x05, 0x01, 0x09, 0x06, (byte) 0xA1, 0x01, (byte) 0x85, 0x01,
        0x05, 0x07, 0x19, (byte) 0xE0, 0x29, (byte) 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, (byte) 0x95, 0x08,
        (byte) 0x81, 0x02,
        (byte) 0x95, 0x01, 0x75, 0x08, (byte) 0x81, 0x01,
        (byte) 0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x26, (byte) 0xFF, 0x00, 0x05, 0x07, 0x19, 0x00, 0x2A, (byte) 0xFF,
        0x00, (byte) 0x81, 0x00,
        (byte) 0xC0,
        // mouse, report 2: buttons, x, y, wheel
        0x05, 0x01, 0x09, 0x02, (byte) 0xA1, 0x01, (byte) 0x85, 0x02, 0x09, 0x01, (byte) 0xA1, 0x00,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, (byte) 0x95, 0x03, 0x75, 0x01, (byte) 0x81, 0x02,
        (byte) 0x95, 0x01, 0x75, 0x05, (byte) 0x81, 0x01,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, (byte) 0x81, 0x25, 0x7F, 0x75, 0x08, (byte) 0x95, 0x03,
        (byte) 0x81, 0x06,
        (byte) 0xC0, (byte) 0xC0,
        // media keys, report 3: one 16-bit consumer usage
        0x05, 0x0C, 0x09, 0x01, (byte) 0xA1, 0x01, (byte) 0x85, 0x03, 0x15, 0x00, 0x26, (byte) 0xFF, 0x03, 0x19, 0x00,
        0x2A, (byte) 0xFF, 0x03, 0x75, 0x10, (byte) 0x95, 0x01, (byte) 0x81, 0x00,
        (byte) 0xC0,
        // joystick, report 4: X, Y, Z (the thrust lever) 0..1023 and 16 buttons
        0x05, 0x01, 0x09, 0x04, (byte) 0xA1, 0x01, (byte) 0x85, 0x04,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x15, 0x00, 0x26, (byte) 0xFF, 0x03, 0x75, 0x10, (byte) 0x95, 0x03,
        (byte) 0x81, 0x02,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, (byte) 0x95, 0x10, (byte) 0x81, 0x02,
        (byte) 0xC0,
    };

    private static int axisZ;

    /** The thrust lever as a joystick axis (0..1). DCS sees it as the Z axis of "NOVA Remote". */
    static void axis(float z) {
        axisZ = Math.max(0, Math.min(1023, Math.round(z * 1023)));
        final int v = axisZ;
        post(() -> report(4, new byte[] {(byte) 0x00, (byte) 0x02, (byte) 0x00, (byte) 0x02, (byte) (v & 0xFF),
            (byte) (v >> 8), 0, 0}));
    }

    static volatile BluetoothHidDevice hid;
    static volatile BluetoothDevice host;
    static volatile boolean registered;
    static volatile String state = "Not started";
    static volatile Runnable listener;
    private static Context app;
    private static Handler sender;
    private static final Handler main = new Handler(Looper.getMainLooper());

    private PcHid() {
    }

    static boolean connected() {
        return host != null && hid != null;
    }

    private static void set(String s) {
        state = s;
        Runnable l = listener;
        if (l != null) {
            main.post(l);
        }
    }

    static BluetoothAdapter adapter(Context c) {
        BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
        return bm == null ? null : bm.getAdapter();
    }

    /** Registers NOVA as a keyboard + mouse. Needs Bluetooth on and the Bluetooth permission. */
    static void start(Context c) {
        app = c.getApplicationContext();
        if (Build.VERSION.SDK_INT < 28) {
            set("Needs Android 9 or newer");
            return;
        }
        if (sender == null) {
            HandlerThread t = new HandlerThread("nova-pc");
            t.start();
            sender = new Handler(t.getLooper());
        }
        BluetoothAdapter a = adapter(app);
        if (a == null) {
            set("No Bluetooth on this phone");
            return;
        }
        if (!a.isEnabled()) {
            set("Turn Bluetooth on");
            return;
        }
        if (hid != null) {
            if (registered) {
                reconnect();
            }
            return;
        }
        set("Starting…");
        try {
            boolean ok = a.getProfileProxy(app, new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    hid = (BluetoothHidDevice) proxy;
                    register();
                }

                @Override
                public void onServiceDisconnected(int profile) {
                    hid = null;
                    registered = false;
                    host = null;
                    set("Bluetooth stopped");
                }
            }, BluetoothProfile.HID_DEVICE);
            if (!ok) {
                set("This phone does not allow Bluetooth keyboards");
            }
        } catch (SecurityException e) {
            set("Allow Bluetooth (Nearby devices) for NOVA");
        }
    }

    private static void register() {
        try {
            BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings("NOVA Remote",
                    "NOVA keyboard and mouse", "NOVA", BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR);
            hid.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), new BluetoothHidDevice.Callback() {
                @Override
                public void onAppStatusChanged(BluetoothDevice plugged, boolean ok) {
                    registered = ok;
                    if (ok) {
                        set("Ready: connect from the PC or tap CONNECT");
                        if (plugged != null) {
                            host = plugged;
                        }
                        reconnect();
                    } else {
                        host = null;
                        set("Stopped");
                    }
                }

                @Override
                public void onConnectionStateChanged(BluetoothDevice d, int st) {
                    if (st == BluetoothProfile.STATE_CONNECTED) {
                        host = d;
                        Prefs.putString(K_ADDR, d.getAddress());
                        set("Connected to " + name(d));
                    } else if (st == BluetoothProfile.STATE_CONNECTING) {
                        set("Connecting to " + name(d) + "…");
                    } else if (st == BluetoothProfile.STATE_DISCONNECTED) {
                        if (host != null && host.equals(d)) {
                            host = null;
                        }
                        set("Disconnected");
                    }
                }

                @Override
                public void onGetReport(BluetoothDevice d, byte type, byte id, int size) {
                    try {
                        hid.replyReport(d, type, id, new byte[id == 1 ? 8 : id == 2 ? 4 : id == 4 ? 8 : 2]);
                    } catch (RuntimeException ignored) {
                        // fine
                    }
                }
            });
        } catch (SecurityException e) {
            set("Allow Bluetooth (Nearby devices) for NOVA");
        }
    }

    static String name(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? d.getAddress() : n;
        } catch (SecurityException e) {
            return "PC";
        }
    }

    /** Connects to the PC used last time. */
    static void reconnect() {
        String addr = Prefs.getString(K_ADDR, "");
        if (hid == null || !registered || addr.isEmpty() || connected()) {
            return;
        }
        connectTo(addr);
    }

    static void connectTo(String addr) {
        try {
            BluetoothAdapter a = adapter(app);
            if (a == null || hid == null) {
                return;
            }
            BluetoothDevice d = a.getRemoteDevice(addr);
            Prefs.putString(K_ADDR, addr);
            set("Connecting to " + name(d) + "…");
            hid.connect(d);
        } catch (RuntimeException e) {
            set("Could not connect: " + e.getMessage());
        }
    }

    static void disconnect() {
        try {
            if (hid != null && host != null) {
                hid.disconnect(host);
            }
        } catch (RuntimeException ignored) {
            // gone
        }
    }

    // ================================================================== sending

    private static void report(int id, byte[] data) {
        BluetoothHidDevice h = hid;
        BluetoothDevice d = host;
        if (h == null || d == null) {
            return;
        }
        // a dropped report can leave a key (or the Windows key) held down on the PC, so retry until it goes out
        for (int t = 0; t < 6; t++) {
            try {
                if (h.sendReport(d, id, data)) {
                    return;
                }
            } catch (RuntimeException ignored) {
                // busy
            }
            sleep(6);
        }
    }

    private static void keyNow(int mods, int key) {
        if (mods != 0) {
            // modifier first, then the key: some PCs miss a Shift / AltGr that arrives together with the key
            report(1, new byte[] {(byte) mods, 0, 0, 0, 0, 0, 0, 0});
            sleep(4);
        }
        report(1, new byte[] {(byte) mods, 0, (byte) key, 0, 0, 0, 0, 0});
        sleep(10);
        report(1, new byte[8]);
        sleep(10);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // fine
        }
    }

    /** Mouse move / buttons / wheel, straight away. buttons: 1 left, 2 right, 4 middle. */
    static void mouse(int buttons, int dx, int dy, int wheel) {
        report(2, new byte[] {(byte) buttons, (byte) clamp(dx), (byte) clamp(dy), (byte) clamp(wheel)});
    }

    private static int clamp(int v) {
        return Math.max(-127, Math.min(127, v));
    }

    static void click(final int button) {
        post(() -> {
            mouse(button, 0, 0, 0);
            sleep(25);
            mouse(0, 0, 0, 0);
        });
    }

    /** Bumped by stop(): every queued script / typing job from before quits right away. */
    private static volatile int gen;

    static void post(Runnable r) {
        if (sender != null) {
            sender.post(r);
        }
    }

    /** Stops all typing and scripts NOW and lets go of every key. */
    static void stop() {
        gen++;
        if (sender != null) {
            sender.removeCallbacksAndMessages(null);
        }
        post(() -> {
            HELD.clear();
            report(1, new byte[8]);
            report(2, new byte[4]);
            report(3, new byte[2]);
        });
        Typing.done(app);
    }

    private static boolean stopped(int g) {
        return g != gen;
    }

    /**
     * Runs a little script. Steps are split by "|":
     * K:WIN+R (keys), T:text (type it), W:300 (wait ms), C:E9 (media key, hex), M:L / M:R (click).
     */
    static void run(final String script) {
        final int g = gen;
        post(() -> {
            for (String step : script.split("\\|")) {
                if (stopped(g)) {
                    return;
                }
                if (step.length() < 2) {
                    continue;
                }
                String arg = step.substring(2);
                switch (step.charAt(0)) {
                    case 'K':
                        combo(arg);
                        break;
                    case 'T':
                        typeNow(fill(arg), g);
                        break;
                    case 'N': {
                        // move dx,dy,times
                        String[] f = arg.split(",");
                        try {
                            int n = f.length > 2 ? Integer.parseInt(f[2]) : 1;
                            for (int i = 0; i < n; i++) {
                                mouse(0, Integer.parseInt(f[0]), Integer.parseInt(f[1]), 0);
                                sleep(8);
                            }
                        } catch (NumberFormatException ignored) {
                            // bad move
                        }
                        break;
                    }
                    case 'S': {
                        String[] f = arg.split(",");
                        try {
                            int n = f.length > 1 ? Integer.parseInt(f[1]) : 1;
                            for (int i = 0; i < n; i++) {
                                mouse(0, 0, 0, Integer.parseInt(f[0]));
                                sleep(30);
                            }
                        } catch (NumberFormatException ignored) {
                            // bad scroll
                        }
                        break;
                    }
                    case 'H':
                        mouse(1, 0, 0, 0);
                        try {
                            sleep(Long.parseLong(arg));
                        } catch (NumberFormatException ignored) {
                            sleep(500);
                        }
                        mouse(0, 0, 0, 0);
                        break;
                    case 'W':
                        try {
                            sleep(Long.parseLong(arg));
                        } catch (NumberFormatException ignored) {
                            // bad wait
                        }
                        break;
                    case 'C':
                        try {
                            int u = Integer.parseInt(arg, 16);
                            report(3, new byte[] {(byte) (u & 0xFF), (byte) ((u >> 8) & 0xFF)});
                            sleep(30);
                            report(3, new byte[2]);
                            sleep(20);
                        } catch (NumberFormatException ignored) {
                            // bad code
                        }
                        break;
                    case 'M':
                        mouse(arg.equals("R") ? 2 : arg.equals("M") ? 4 : 1, 0, 0, 0);
                        sleep(25);
                        mouse(0, 0, 0, 0);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private static String fill(String s) {
        if (s.contains("{date}")) {
            s = s.replace("{date}", new java.text.SimpleDateFormat("dd.MM.yyyy", Locale.ROOT).format(new java.util.Date()));
        }
        if (s.contains("{time}")) {
            s = s.replace("{time}", new java.text.SimpleDateFormat("HH:mm", Locale.ROOT).format(new java.util.Date()));
        }
        return s;
    }

    // ------------------------------------------------------------------ KEY DECK: tap, hold and toggle

    static final int RCTRL = 0x10;
    static final int RSHIFT = 0x20;
    static final int RALT = 0x40;
    private static final java.util.List<int[]> HELD = new java.util.ArrayList<>();

    /** The key code for a key name ("G", "F10", "SPACE"...), by position, with Y/Z swapped on CH/DE keyboards. */
    static int code(String name) {
        String n = name.toUpperCase(Locale.ROOT);
        if (Prefs.getInt(K_LAYOUT, 0) != 2 && (n.equals("Y") || n.equals("Z"))) {
            n = n.equals("Y") ? "Z" : "Y";
        }
        Integer k = KEYS.get(n);
        return k == null ? 0 : k;
    }

    /** The key code by US position, never swapped: games like DCS read keys by position. */
    static int rawCode(String name) {
        Integer k = KEYS.get(name.toUpperCase(Locale.ROOT));
        return k == null ? 0 : k;
    }

    static String[] keyNames() {
        List<String> out = new ArrayList<>();
        for (char c = 'A'; c <= 'Z'; c++) {
            out.add(String.valueOf(c));
        }
        for (int i = 0; i <= 9; i++) {
            out.add(String.valueOf(i));
        }
        for (int i = 1; i <= 24; i++) {
            out.add("F" + i);
        }
        String[] more = {"SPACE", "ENTER", "ESC", "TAB", "BKSP", "DEL", "INS", "HOME", "END", "PGUP", "PGDN", "UP", "DOWN",
            "LEFT", "RIGHT", "PAUSE", "PRTSC", "SCROLL", "CAPS", "KP0", "KP1", "KP2", "KP3", "KP4", "KP5", "KP6", "KP7",
            "KP8", "KP9", "KPPLUS", "KPMINUS", "KPSTAR", "KPSLASH", "KPDOT", "KPENTER", "NUMLOCK", "MINUS", "EQUAL",
            "LBRACKET", "RBRACKET", "BACKSLASH", "SEMICOLON", "QUOTE", "GRAVE", "COMMA", "DOT", "SLASH", "ISO", "APPS",
            "(modifier only)"};
        for (String m : more) {
            out.add(m);
        }
        return out.toArray(new String[0]);
    }

    private static void sendHeld() {
        int mods = 0;
        byte[] r = new byte[8];
        int n = 2;
        for (int[] h : HELD) {
            mods |= h[0];
            if (h[1] != 0 && n < 8) {
                r[n++] = (byte) h[1];
            }
        }
        r[0] = (byte) mods;
        report(1, r);
    }

    /** Press (down = true) or let go of a key, keeping other held keys down. */
    static void hold(final int mods, final int key, final boolean down) {
        post(() -> {
            for (int i = HELD.size() - 1; i >= 0; i--) {
                if (HELD.get(i)[0] == mods && HELD.get(i)[1] == key) {
                    HELD.remove(i);
                }
            }
            if (down) {
                HELD.add(new int[] {mods, key});
            }
            sendHeld();
        });
    }

    static boolean held(int mods, int key) {
        for (int[] h : HELD) {
            if (h[0] == mods && h[1] == key) {
                return true;
            }
        }
        return false;
    }

    /** A quick press, times times in a row (DCS eject needs 3). Keeps held keys down. */
    static void tap(final int mods, final int key, final int times, final int pressMs) {
        post(() -> {
            for (int t = 0; t < Math.max(1, times); t++) {
                HELD.add(new int[] {mods, key});
                sendHeld();
                sleep(Math.max(20, pressMs));
                HELD.remove(HELD.size() - 1);
                sendHeld();
                sleep(70);
            }
        });
    }

    static void releaseAll() {
        post(() -> {
            HELD.clear();
            sendHeld();
        });
    }

    static void type(final String text) {
        final int g = gen;
        post(() -> typeNow(text, g));
    }

    /** Drops indentation, blank lines and whole-line comments, so a script types in far less time. */
    static String compact(String text, String comment) {
        StringBuilder b = new StringBuilder();
        for (String line : text.replace("\r", "").split("\n")) {
            String t = line.trim();
            if (t.isEmpty() || t.startsWith(comment)) {
                continue;
            }
            b.append(t).append('\n');
        }
        return b.toString();
    }

    /** Roughly how long typing this takes, in seconds. */
    static int typeSeconds(String text) {
        return Math.max(1, text.length() * 26 / 1000);
    }

    private static final Map<String, Integer> KEYS = new HashMap<>();

    static {
        String[][] k = {
            {"ENTER", "28"}, {"ESC", "29"}, {"BKSP", "2A"}, {"TAB", "2B"}, {"SPACE", "2C"}, {"PRTSC", "46"},
            {"INS", "49"}, {"HOME", "4A"}, {"PGUP", "4B"}, {"DEL", "4C"}, {"END", "4D"}, {"PGDN", "4E"},
            {"RIGHT", "4F"}, {"LEFT", "50"}, {"DOWN", "51"}, {"UP", "52"}, {"KPMINUS", "56"}, {"KPPLUS", "57"},
            {"DOT", "37"}, {"COMMA", "36"}, {"APPS", "65"}, {"CAPS", "39"}, {"PAUSE", "48"}, {"SCROLL", "47"},
            {"KPSLASH", "54"}, {"KPSTAR", "55"}, {"KPENTER", "58"}, {"KPDOT", "63"}, {"NUMLOCK", "53"},
            {"MINUS", "2D"}, {"EQUAL", "2E"}, {"LBRACKET", "2F"}, {"RBRACKET", "30"}, {"BACKSLASH", "31"},
            {"SEMICOLON", "33"}, {"QUOTE", "34"}, {"GRAVE", "35"}, {"SLASH", "38"}, {"ISO", "64"},
        };
        for (String[] e : k) {
            KEYS.put(e[0], Integer.parseInt(e[1], 16));
        }
        for (int i = 1; i <= 12; i++) {
            KEYS.put("F" + i, 0x3A + i - 1);
        }
        for (int i = 13; i <= 24; i++) {
            KEYS.put("F" + i, 0x68 + i - 13);
        }
        KEYS.put("KP0", 0x62);
        for (int i = 1; i <= 9; i++) {
            KEYS.put("KP" + i, 0x59 + i - 1);
        }
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            KEYS.put(String.valueOf(ch), 0x04 + ch - 'A');
        }
        for (int i = 1; i <= 9; i++) {
            KEYS.put(String.valueOf(i), 0x1E + i - 1);
        }
        KEYS.put("0", 0x27);
    }

    /** "CTRL+SHIFT+ESC", "WIN+E", "WIN" (just the Windows key). Letters are by position (US names). */
    private static void combo(String s) {
        int mods = 0;
        int key = 0;
        for (String part : s.toUpperCase(Locale.ROOT).split("\\+")) {
            switch (part) {
                case "CTRL":
                    mods |= CTRL;
                    break;
                case "SHIFT":
                    mods |= SHIFT;
                    break;
                case "ALT":
                    mods |= ALT;
                    break;
                case "WIN":
                    mods |= WIN;
                    break;
                default:
                    // on Swiss / German keyboards Y and Z swap places, so Ctrl+Z must press the key labelled Z there
                    if (Prefs.getInt(K_LAYOUT, 0) != 2 && (part.equals("Y") || part.equals("Z"))) {
                        part = part.equals("Y") ? "Z" : "Y";
                    }
                    Integer k = KEYS.get(part);
                    if (k != null) {
                        key = k;
                    }
                    break;
            }
        }
        keyNow(mods, key);
    }

    // ================================================================== text through the PC's keyboard layout

    private static void typeNow(String text, int g) {
        int layout = Prefs.getInt(K_LAYOUT, 0);
        boolean big = text.length() > 300;
        if (big) {
            Typing.show(app, 0);
        }
        report(1, new byte[8]); // start clean: nothing held
        long lastShow = 0;
        for (int i = 0; i < text.length(); i++) {
            if (stopped(g)) {
                report(1, new byte[8]);
                return;
            }
            int[] k = map(text.charAt(i), layout);
            if (k != null) {
                keyNow(k[1], k[0]);
            }
            if (big && System.currentTimeMillis() - lastShow > 1000) {
                lastShow = System.currentTimeMillis();
                Typing.show(app, i * 100 / text.length());
            }
        }
        report(1, new byte[8]);
        if (big) {
            Typing.done(app);
        }
    }

    /** {key, modifiers} for a character, or null when it can't be typed. */
    static int[] map(char ch, int layout) {
        boolean euro = layout == 0 || layout == 1;
        if (ch >= 'a' && ch <= 'z') {
            char c = ch;
            if (euro && c == 'y') {
                c = 'z';
            } else if (euro && c == 'z') {
                c = 'y';
            }
            return new int[] {0x04 + c - 'a', 0};
        }
        if (ch >= 'A' && ch <= 'Z') {
            int[] k = map(Character.toLowerCase(ch), layout);
            return new int[] {k[0], SHIFT};
        }
        if (ch >= '1' && ch <= '9') {
            return new int[] {0x1E + ch - '1', 0};
        }
        if (ch == '0') {
            return new int[] {0x27, 0};
        }
        if (ch == ' ') {
            return new int[] {0x2C, 0};
        }
        if (ch == '\n') {
            return new int[] {0x28, 0};
        }
        if (ch == '\t') {
            return new int[] {0x2B, 0};
        }
        String table;
        if (layout == 0) {
            // Swiss German: char, key (hex), modifier (n none, s shift, a AltGr)
            table = "-38n _38s .37n :37s ,36n ;36s /24s +1Es \"1Fs *20s %22s &23s (25s )26s =27s '2Dn ?2Ds @1Fa #20a "
                    + "\\64a <64n >64s !30s $32n [2Fa ]30a {34a }32a |24a ü2Fn ö33n ä34n Ü2Fs Ö33s Ä34s";
        } else if (layout == 1) {
            table = "-38n _38s .37n :37s ,36n ;36s /24s +30n *30s \"1Fs %22s &23s (25s )26s =27s ?2Ds '32s #32n "
                    + "@14a \\2Da !1Es $21s <64n >64s |64a [25a ]26a {24a }27a ü2Fn ö33n ä34n Ü2Fs Ö33s Ä34s";
        } else {
            table = "-2Dn _2Ds =2En +2Es [2Fn {2Fs ]30n }30s \\31n |31s ;33n :33s '34n \"34s `35n ~35s ,36n <36s .37n "
                    + ">37s /38n ?38s !1Es @1Fs #20s $21s %22s ^23s &24s *25s (26s )27s";
        }
        for (String e : table.split(" ")) {
            if (e.length() >= 4 && e.charAt(0) == ch) {
                int key = Integer.parseInt(e.substring(1, 3), 16);
                char m = e.charAt(3);
                return new int[] {key, m == 's' ? SHIFT : m == 'a' ? ALTGR : 0};
            }
        }
        return null;
    }

    /** "NOVA is typing on your PC 43 %" with a STOP button, while long text goes out. */
    static final class Typing {
        private static final int ID = 4801;

        private Typing() {
        }

        static void show(Context c, int pct) {
            if (c == null) {
                return;
            }
            try {
                android.app.NotificationManager nm = (android.app.NotificationManager)
                        c.getSystemService(Context.NOTIFICATION_SERVICE);
                nm.createNotificationChannel(new android.app.NotificationChannel("nova_typing", "Typing on the PC",
                        android.app.NotificationManager.IMPORTANCE_LOW));
                android.app.PendingIntent stop = android.app.PendingIntent.getBroadcast(c, ID,
                        new android.content.Intent(c, Stop.class),
                        android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);
                android.app.Notification n = new android.app.Notification.Builder(c, "nova_typing")
                        .setSmallIcon(android.R.drawable.ic_menu_edit)
                        .setContentTitle("NOVA is typing on your PC  " + pct + " %")
                        .setContentText("Don't touch the PC until it's done. Going wrong? Tap STOP")
                        .setProgress(100, pct, false)
                        .setOngoing(true)
                        .setOnlyAlertOnce(true)
                        .addAction(new android.app.Notification.Action.Builder(null, "\u25A0 STOP", stop).build())
                        .build();
                nm.notify(ID, n);
            } catch (RuntimeException ignored) {
                // no notifications allowed
            }
        }

        static void done(Context c) {
            if (c == null) {
                return;
            }
            try {
                ((android.app.NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
            } catch (RuntimeException ignored) {
                // gone
            }
        }
    }

    /** STOP on the typing notification. */
    public static class Stop extends android.content.BroadcastReceiver {
        @Override
        public void onReceive(Context c, android.content.Intent i) {
            stop();
        }
    }
}
