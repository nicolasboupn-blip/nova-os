package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * SWITCH VERSION: go to any older NOVA (or back to the newest) without losing anything.
 * Android won't install an older app over a newer one, so GitHub builds the version you pick again with a NEW build
 * number ("Build an older NOVA" workflow); then it installs like an update and your data stays. Before switching, NOVA
 * backs up all its settings and files; going back to NEWEST puts that backup back.
 */
final class TimeMachine {
    private static final String WORKFLOW = "oldversion.yml";
    private static final String K_WANT = "tm_want";
    private static final String K_SINCE = "tm_since";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile boolean polling;
    private static volatile TextView statusView;

    private TimeMachine() {
    }

    /** {code, version, title, date}, newest first. */
    static List<String[]> versions(Context c) {
        List<String[]> out = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("versions.txt"),
                StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] f = line.split("\t");
                if (f.length >= 4) {
                    out.add(f);
                }
            }
        } catch (Exception ignored) {
            // no list
        }
        return out;
    }

    // ------------------------------------------------------------------ backup and restore

    private static File root(Context c) {
        File ext = c.getExternalFilesDir("timemachine");
        return ext != null ? ext : new File(c.getFilesDir().getParentFile(), "timemachine");
    }

    private static void copyDir(File from, File to) throws Exception {
        File[] list = from.listFiles();
        if (list == null) {
            return;
        }
        to.mkdirs();
        for (File f : list) {
            File t = new File(to, f.getName());
            if (f.isDirectory()) {
                copyDir(f, t);
            } else {
                try (InputStream in = new FileInputStream(f); OutputStream out = new FileOutputStream(t)) {
                    byte[] b = new byte[16384];
                    int n;
                    while ((n = in.read(b)) > 0) {
                        out.write(b, 0, n);
                    }
                }
            }
        }
    }

    private static void wipe(File d) {
        File[] list = d.listFiles();
        if (list != null) {
            for (File f : list) {
                if (f.isDirectory()) {
                    wipe(f);
                }
                f.delete();
            }
        }
    }

    /** Copies every NOVA setting and file into the backup folder. Returns false if it couldn't. */
    static boolean backup(Context c) {
        try {
            File data = c.getFilesDir().getParentFile();
            File b = new File(root(c), "backup");
            wipe(b);
            b.mkdirs();
            copyDir(new File(data, "shared_prefs"), new File(b, "shared_prefs"));
            copyDir(c.getFilesDir(), new File(b, "files"));
            try (OutputStream o = new FileOutputStream(new File(b, "info.txt"))) {
                o.write(("build " + Updater.currentBuild(c) + " " + System.currentTimeMillis()).getBytes(StandardCharsets.UTF_8));
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean hasBackup(Context c) {
        return new File(new File(root(c), "backup"), "info.txt").exists();
    }

    /** Called by Prefs.init before any setting is read: puts the backup back after switching to NEWEST. */
    static void restoreIfPending(Context c) {
        try {
            File marker = new File(root(c), "restore.txt");
            if (!marker.exists()) {
                return;
            }
            String s;
            try (InputStream in = new FileInputStream(marker)) {
                byte[] b = new byte[64];
                int n = in.read(b);
                s = new String(b, 0, Math.max(0, n), StandardCharsets.UTF_8).trim();
            }
            int from = Integer.parseInt(s);
            if (Updater.currentBuild(c) <= from) {
                return; // the new build isn't installed yet
            }
            File b = new File(root(c), "backup");
            File data = c.getFilesDir().getParentFile();
            if (new File(b, "shared_prefs").isDirectory()) {
                copyDir(new File(b, "shared_prefs"), new File(data, "shared_prefs"));
            }
            if (new File(b, "files").isDirectory()) {
                copyDir(new File(b, "files"), c.getFilesDir());
            }
            marker.delete();
            new File(root(c), "restored.txt").createNewFile();
        } catch (Exception ignored) {
            // keep what's there
        }
    }

    /** True once, right after a restore (to say so). */
    static boolean justRestored(Context c) {
        File f = new File(root(c), "restored.txt");
        return f.exists() && f.delete();
    }

    // ------------------------------------------------------------------ the screen

    static void open(final NovaActivity host) {
        final List<String[]> vs = versions(host);
        int current = Updater.currentBuild(host);
        String mine = BuildConfigName.of(host);
        final String[] items = new String[vs.size() + 1];
        items[0] = "⏩  NEWEST (back to the newest NOVA, your stuff comes back)";
        for (int i = 0; i < vs.size(); i++) {
            String[] v = vs.get(i);
            items[i + 1] = v[1] + "  ·  " + v[2] + "   (" + v[3].substring(5) + ")" + (v[1].equals(mine) ? "  ◀ now" : "");
        }
        String want = Prefs.getString(K_WANT, "");
        AlertDialog.Builder b = new AlertDialog.Builder(host).setTitle("⏪ Switch version (now " + mine + ", build "
                + current + ")")
                .setItems(items, (d, w) -> confirm(host, w == 0 ? "NEWEST" : vs.get(w - 1)[0],
                        w == 0 ? "the newest NOVA" : "NOVA " + vs.get(w - 1)[1] + " (" + vs.get(w - 1)[2] + ")"))
                .setNegativeButton("CLOSE", null);
        if (!want.isEmpty()) {
            b.setNeutralButton("WAITING FOR " + want + "…", (d, w) -> progress(host, want));
        }
        b.show();
    }

    private static void confirm(final NovaActivity host, final String code, String name) {
        boolean back = code.equals("NEWEST");
        String msg = back
                ? "GitHub builds the newest NOVA again (about 5 min), NOVA installs it and puts back your settings and "
                        + "files from the backup it made when you switched away."
                        + (hasBackup(host) ? "" : "\n\n(No backup found: your current settings simply stay.)")
                : "1. NOVA backs up ALL your settings, widgets, pages and files.\n"
                        + "2. GitHub builds " + name + " again with a new build number (about 5 min).\n"
                        + "3. NOVA installs it over this one. Nothing gets deleted.\n\n"
                        + "Auto-update gets switched off, or it would jump straight back. Old versions don't have "
                        + "newer features, but your data for them is kept. To come back: SWITCH VERSION > NEWEST "
                        + "(or, in very old versions without this button, run \"Build an older NOVA\" with NEWEST on "
                        + "GitHub and install the APK).";
        new AlertDialog.Builder(host).setTitle(back ? "Back to the newest?" : "Switch to " + name + "?")
                .setMessage(msg)
                .setPositiveButton("GO", (d, w) -> start(host, code))
                .setNegativeButton("CANCEL", null).show();
    }

    private static void start(final NovaActivity host, final String code) {
        boolean back = code.equals("NEWEST");
        if (!back) {
            if (!backup(host)) {
                host.toast("Backup failed, nothing was changed");
                return;
            }
            Prefs.putBool(AutoUpdate.K_ON, false);
            AutoUpdate.schedule(host);
        } else {
            try {
                File r = root(host);
                r.mkdirs();
                try (OutputStream o = new FileOutputStream(new File(r, "restore.txt"))) {
                    o.write(String.valueOf(Updater.currentBuild(host)).getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {
                // then nothing is restored
            }
        }
        Prefs.putString(K_WANT, code);
        Prefs.putString(K_SINCE, String.valueOf(System.currentTimeMillis() - 60000));
        new Thread(() -> {
            final boolean started = dispatch(code);
            MAIN.post(() -> {
                if (started) {
                    host.toast("GitHub is building it. NOVA installs it when it's ready");
                } else {
                    ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText("NOVA version", code));
                    }
                    new AlertDialog.Builder(host).setTitle("Start the build on GitHub")
                            .setMessage("1. Tap OPEN GITHUB (sign in if it asks).\n2. Tap \"Run workflow\".\n3. In the box, "
                                    + "paste " + code + " (it's already copied).\n4. Tap the green \"Run workflow\".\n\n"
                                    + "Then come back here: NOVA waits for the build and installs it.")
                            .setPositiveButton("OPEN GITHUB", (d, w) -> {
                                try {
                                    host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/"
                                            + Updater.REPO + "/actions/workflows/" + WORKFLOW)));
                                } catch (Exception e) {
                                    host.toast("No browser");
                                }
                                progress(host, code);
                            }).setNegativeButton("LATER", null).show();
                    return;
                }
                progress(host, code);
            });
        }).start();
    }

    /** With a GitHub token that may run workflows, NOVA starts the build itself. */
    private static boolean dispatch(String code) {
        if (Updater.token().isEmpty()) {
            return false;
        }
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + Updater.REPO
                    + "/actions/workflows/" + WORKFLOW + "/dispatches").openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("Authorization", "Bearer " + Updater.token());
            c.setRequestProperty("Content-Type", "application/json");
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            JSONObject body = new JSONObject();
            body.put("ref", "main");
            body.put("inputs", new JSONObject().put("version", code));
            try (OutputStream o = c.getOutputStream()) {
                o.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            return c.getResponseCode() == 204;
        } catch (Exception e) {
            return false;
        }
    }

    private static void progress(final NovaActivity host, final String code) {
        TextView t = new TextView(host);
        t.setTextColor(Theme.TEXT);
        t.setTextSize(13f);
        int p = Theme.dp(host, 20);
        t.setPadding(p, p / 2, p, 0);
        t.setText("Waiting for GitHub to build " + code + "… (usually about 5 min)");
        statusView = t;
        new AlertDialog.Builder(host).setTitle("⏳ Switching version").setView(t)
                .setPositiveButton("HIDE", null)
                .setNegativeButton("CANCEL SWITCH", (d, w) -> {
                    Prefs.putString(K_WANT, "");
                    polling = false;
                    new File(root(host), "restore.txt").delete();
                    host.toast("Switch cancelled");
                }).show();
        poll(host);
    }

    private static void say(final String s) {
        MAIN.post(() -> {
            TextView t = statusView;
            if (t != null) {
                t.setText(s);
            }
        });
    }

    private static void poll(final NovaActivity host) {
        if (polling) {
            return;
        }
        polling = true;
        new Thread(() -> {
            long end = System.currentTimeMillis() + 20 * 60000L;
            try {
                while (polling && System.currentTimeMillis() < end) {
                    String code = Prefs.getString(K_WANT, "");
                    if (code.isEmpty()) {
                        return;
                    }
                    String[] found = find(code);
                    if (found != null) {
                        say("Build " + found[0] + " is ready, downloading…");
                        File dir = new File(host.getCacheDir(), "updates");
                        dir.mkdirs();
                        final File apk = new File(dir, "nova-switch.apk");
                        Updater.download(found[1], apk);
                        Prefs.putString(K_WANT, "");
                        say("Installing… NOVA restarts on the new version.");
                        MAIN.post(() -> {
                            try {
                                Installer.install(host, new FileInputStream(apk));
                            } catch (Exception e) {
                                host.toast("Install failed: " + e.getMessage());
                            }
                        });
                        return;
                    }
                    long mins = (System.currentTimeMillis() - Long.parseLong(Prefs.getString(K_SINCE, "0"))) / 60000;
                    say("Waiting for GitHub to build " + code + "… (" + mins + " min so far, usually about 5)."
                            + "\n\nYou can HIDE this, NOVA keeps waiting while it's open.");
                    Thread.sleep(20000);
                }
                say("No build showed up after 20 min. Check GitHub > Actions > \"Build an older NOVA\" for a red X.");
            } catch (Exception e) {
                say("Problem: " + e.getMessage());
            } finally {
                polling = false;
            }
        }, "nova-timemachine").start();
    }

    /** {build number, APK url} of a finished build for this code made after the request, or null. */
    private static String[] find(String code) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + Updater.REPO
                + "/releases?per_page=15").openConnection();
        c.setRequestProperty("Accept", "application/vnd.github+json");
        if (!Updater.token().isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + Updater.token());
        }
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        if (c.getResponseCode() != 200) {
            return null;
        }
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        try (InputStream in = c.getInputStream()) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) {
                o.write(b, 0, n);
            }
        }
        JSONArray a = new JSONArray(o.toString("UTF-8"));
        long since = Long.parseLong(Prefs.getString(K_SINCE, "0"));
        java.text.SimpleDateFormat iso = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.ROOT);
        iso.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        String prefix = code.equals("NEWEST") ? "nova-" : "old-" + code + "-";
        for (int i = 0; i < a.length(); i++) {
            JSONObject r = a.getJSONObject(i);
            String tag = r.optString("tag_name", "");
            if (!tag.startsWith(prefix)) {
                continue;
            }
            long when;
            try {
                when = iso.parse(r.optString("published_at", r.optString("created_at", ""))).getTime();
            } catch (Exception e) {
                when = 0;
            }
            if (when < since) {
                continue;
            }
            String num = tag.substring(tag.lastIndexOf('-') + 1);
            JSONArray assets = r.optJSONArray("assets");
            if (assets == null) {
                continue;
            }
            for (int k = 0; k < assets.length(); k++) {
                JSONObject as = assets.getJSONObject(k);
                if (as.optString("name").endsWith(".apk")) {
                    return new String[] {num, Updater.token().isEmpty() ? as.getString("browser_download_url")
                            : as.getString("url")};
                }
            }
        }
        return null;
    }

    /** The versionName of the installed NOVA. */
    static final class BuildConfigName {
        private BuildConfigName() {
        }

        static String of(Context c) {
            try {
                return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "?";
            }
        }
    }
}
