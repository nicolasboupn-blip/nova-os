package app.novaos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

/**
 * LOUD ALARM: once armed, the next notification or incoming call makes the phone beep as loud as it can for 20 minutes
 * (or until STOP). It plays on the ALARM channel at full volume (gets through silent mode and, by default, Do Not
 * Disturb), as a harsh full-scale 2.8 / 3.4 kHz two-tone square wave with a LoudnessEnhancer on top, plus vibration.
 * It can't go past what the speaker itself can do.
 */
final class LoudAlarm {
    static final String K_ON = "la_on";
    static final String K_AT = "la_at";
    static final String K_LEN = "la_len";
    /** 0 LOUD beep, 1 LOCATE noise bursts, 2 BOTH in turns. */
    static final String K_SOUND = "la_sound";
    /** 0 ALWAYS the chosen sound, 1 SWITCH between LOUD and LOCATE with every message. */
    static final String K_MODE = "la_mode";
    private static final String K_NEXT = "la_next";
    static final String[] SOUNDS = {"LOUD", "LOCATE", "BOTH"};
    static final String[] MODES = {"ALWAYS", "SWITCH"};
    private static final String CHANNEL = "nova_loud";
    private static final int NOTE = 4790;
    private static final int RATE = 44100;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static volatile boolean ringing;
    private static volatile long ringSince;
    private static Thread player;
    private static int oldVolume = -1;
    static volatile Runnable listener;

    private LoudAlarm() {
    }

    static boolean armed() {
        return Prefs.getBool(K_ON, false);
    }

    /** When it goes live (ms since 1970); 0 = right away. */
    static long armAt() {
        return Prefs.getLong(K_AT, 0);
    }

    static boolean active() {
        return armed() && System.currentTimeMillis() >= armAt();
    }

    static boolean ringing() {
        return ringing;
    }

    static long ringSince() {
        return ringSince;
    }

    static int minutes() {
        return Prefs.getInt(K_LEN, 20);
    }

    static void arm(long delayMs) {
        Prefs.putLong(K_AT, delayMs <= 0 ? 0 : System.currentTimeMillis() + delayMs);
        Prefs.putBool(K_ON, true);
        changed();
    }

    static void disarm(Context c) {
        Prefs.putBool(K_ON, false);
        stop(c);
        changed();
    }

    private static void changed() {
        Runnable r = listener;
        if (r != null) {
            MAIN.post(r);
        }
    }

    /** Called for every new notification (and so every incoming call). */
    static void onNotification(Context c) {
        Prefs.init(c);
        if (active() && !ringing) {
            int snd = Prefs.getInt(K_SOUND, 2);
            if (Prefs.getInt(K_MODE, 0) == 1) {
                int n = Prefs.getInt(K_NEXT, 0);
                snd = n % 2;
                Prefs.putInt(K_NEXT, n + 1);
            }
            start(c, minutes() * 60000L, snd);
        }
    }

    /** Which sound the next message will get. */
    static int nextSound() {
        return Prefs.getInt(K_MODE, 0) == 1 ? Prefs.getInt(K_NEXT, 0) % 2 : Prefs.getInt(K_SOUND, 2);
    }

    static synchronized void start(final Context c, final long ms) {
        start(c, ms, Prefs.getInt(K_SOUND, 2));
    }

    static synchronized void start(final Context c, final long ms, final int sound) {
        if (ringing) {
            return;
        }
        ringing = true;
        ringSince = System.currentTimeMillis();
        final Context app = c.getApplicationContext();
        AudioManager am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        try {
            oldVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (RuntimeException ignored) {
            // some phones refuse; it still plays at the alarm volume you have
        }
        showNotification(app);
        vibrate(app, true);
        player = new Thread(() -> play(ms, sound), "nova-loud");
        player.setPriority(Thread.MAX_PRIORITY);
        player.start();
        MAIN.postDelayed(STOP_LATER, ms);
        changed();
    }

    private static final Runnable STOP_LATER = () -> {
        if (ringing) {
            stopNow(null);
        }
    };

    static void stop(Context c) {
        stopNow(c);
    }

    private static synchronized void stopNow(Context c) {
        MAIN.removeCallbacks(STOP_LATER);
        boolean was = ringing;
        ringing = false;
        Thread t = player;
        if (t != null) {
            t.interrupt();
        }
        player = null;
        if (was && c == null) {
            c = appContext;
        }
        if (c != null) {
            Context app = c.getApplicationContext();
            vibrate(app, false);
            if (oldVolume >= 0) {
                try {
                    ((AudioManager) app.getSystemService(Context.AUDIO_SERVICE))
                            .setStreamVolume(AudioManager.STREAM_ALARM, oldVolume, 0);
                } catch (RuntimeException ignored) {
                    // keep it
                }
                oldVolume = -1;
            }
            try {
                ((NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTE);
            } catch (RuntimeException ignored) {
                // gone
            }
        }
        changed();
    }

    private static Context appContext;

    /** LOUD: 0.22 s 2.8 kHz, 0.22 s 3.4 kHz square, 0.08 s gap. Carries far, grabs attention. */
    private static void loud(short[] buf, int at) {
        int on = RATE * 22 / 100;
        int i = at;
        for (int k = 0; k < 2; k++) {
            double f = k == 0 ? 2800 : 3400;
            for (int n = 0; n < on; n++) {
                double ph = (n * f / RATE) % 1.0;
                buf[i++] = ph < 0.5 ? Short.MAX_VALUE : Short.MIN_VALUE + 1;
            }
        }
    }

    private static int loudLen() {
        return RATE * 22 / 100 * 2 + RATE * 8 / 100;
    }

    /**
     * LOCATE: full-scale broadband noise bursts, 50 ms on / 70 ms off, with hard edges. Every frequency at once and a
     * sharp start each time give your ears the timing and level cues to point at it (like "shh-shh" reversing alarms).
     */
    private static void bursts(short[] buf, int at, int count, java.util.Random r) {
        int on = RATE * 5 / 100;
        int off = RATE * 7 / 100;
        int i = at;
        for (int b = 0; b < count; b++) {
            for (int n = 0; n < on; n++) {
                buf[i++] = r.nextBoolean() ? Short.MAX_VALUE : Short.MIN_VALUE + 1;
            }
            i += off;
        }
    }

    private static int burstLen(int count) {
        return (RATE * 5 / 100 + RATE * 7 / 100) * count;
    }

    private static short[] pattern(int sound) {
        java.util.Random r = new java.util.Random();
        if (sound == 0) {
            short[] b = new short[loudLen()];
            loud(b, 0);
            return b;
        }
        if (sound == 1) {
            short[] b = new short[burstLen(10)];
            bursts(b, 0, 10, r);
            return b;
        }
        // BOTH: about 1 s of LOUD to hear roughly where, then 1.5 s of LOCATE to walk straight to it
        short[] b = new short[loudLen() * 2 + RATE / 10 + burstLen(12)];
        loud(b, 0);
        loud(b, loudLen());
        bursts(b, loudLen() * 2 + RATE / 10, 12, r);
        return b;
    }

    private static void play(long ms, int sound) {
        short[] buf = pattern(sound);
        AudioTrack tr = null;
        LoudnessEnhancer le = null;
        try {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            tr = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(min, 8192) * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            try {
                le = new LoudnessEnhancer(tr.getAudioSessionId());
                le.setTargetGain(1500);
                le.setEnabled(true);
            } catch (Throwable ignored) {
                // no booster on this phone
            }
            tr.setVolume(AudioTrack.getMaxVolume());
            tr.play();
            long end = System.currentTimeMillis() + ms;
            while (ringing && System.currentTimeMillis() < end && !Thread.currentThread().isInterrupted()) {
                tr.write(buf, 0, buf.length);
            }
        } catch (Throwable ignored) {
            // audio failed; the vibration and notification still run
        } finally {
            if (tr != null) {
                try {
                    tr.pause();
                    tr.flush();
                    tr.release();
                } catch (Throwable ignored) {
                    // gone
                }
            }
            if (le != null) {
                try {
                    le.release();
                } catch (Throwable ignored) {
                    // gone
                }
            }
        }
    }

    private static void vibrate(Context c, boolean on) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) {
                return;
            }
            if (!on) {
                v.cancel();
                return;
            }
            long[] p = {0, 600, 200, 600, 200};
            AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build();
            v.vibrate(VibrationEffect.createWaveform(p, 1), aa);
        } catch (RuntimeException ignored) {
            // no vibrator
        }
    }

    private static void showNotification(Context c) {
        appContext = c;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Loud alarm", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.setBypassDnd(true);
            nm.createNotificationChannel(ch);
            PendingIntent stop = PendingIntent.getBroadcast(c, 4790, new Intent(c, Stop.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent open = PendingIntent.getActivity(c, 4791, new Intent(c, NovaActivity.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = new Notification.Builder(c, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("NOVA LOUD ALARM")
                    .setContentText("Something came in. Tap STOP to end the beeping")
                    .setCategory(Notification.CATEGORY_ALARM)
                    .setOngoing(true)
                    .setContentIntent(open)
                    .setFullScreenIntent(open, true)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .addAction(new Notification.Action.Builder(null, "STOP", stop).build());
            nm.notify(NOTE, b.build());
        } catch (RuntimeException ignored) {
            // the widget can still stop it
        }
    }

    /** The STOP button on the notification. */
    public static class Stop extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            Prefs.init(c);
            stop(c);
        }
    }

    static boolean dndAccess(Context c) {
        try {
            return Build.VERSION.SDK_INT < 23
                    || ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();
        } catch (RuntimeException e) {
            return false;
        }
    }
}
