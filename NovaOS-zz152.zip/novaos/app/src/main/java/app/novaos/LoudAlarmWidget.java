package app.novaos;

import android.app.AlertDialog;
import android.content.Intent;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/** LOUD ALARM widget: arm now / in 20 min / in 1 h / custom; the next notification or call beeps as loud as the phone can. */
final class LoudAlarmWidget extends NovaWidget {
    private static final int RED = 0xFFFF453A;
    private static final int GREEN = 0xFF30D158;
    private static final int AMBER = 0xFFFFB020;

    private final TextView state;
    private final TextView sub;
    private final TextView stop;
    private final TextView off;
    private final TextView lenChip;
    private final LinearLayout arms;
    private TextView soundChip;
    private TextView modeChip;
    private final Runnable onChange = this::refresh;

    LoudAlarmWidget(NovaActivity host) {
        super(host);
        state = text("", 22f, Theme.TEXT);
        state.setLetterSpacing(0.15f);
        state.setPadding(0, dp(6), 0, 0);
        addView(state, wide());
        sub = text("", 10f, Theme.DIM);
        sub.setPadding(dp(6), dp(2), dp(6), dp(6));
        addView(sub, wide());

        stop = text("■  STOP", 22f, 0xFFFFFFFF);
        stop.setBackground(Theme.rounded(RED, 16f, host));
        stop.setPadding(0, dp(22), 0, dp(22));
        stop.setClickable(true);
        Theme.ripple(stop);
        stop.setOnClickListener(v -> {
            LoudAlarm.stop(host);
            host.buzz(30);
            refresh();
        });
        addView(stop, wide());

        arms = row();
        arms.addView(chip("ARM NOW", () -> arm(0)), weight(1f));
        arms.addView(chip("IN 20 MIN", () -> arm(20)), weight(1f));
        arms.addView(chip("IN 1 H", () -> arm(60)), weight(1f));
        arms.addView(chip("CUSTOM…", this::custom), weight(1f));
        addView(arms, wide());

        LinearLayout tools = row();
        off = chip("TURN OFF", () -> {
            LoudAlarm.disarm(host);
            host.toast("Loud alarm off");
            refresh();
        });
        tools.addView(off, weight(1f));
        lenChip = chip("", () -> {
            int[] opts = {1, 5, 10, 20, 30, 60};
            int cur = LoudAlarm.minutes();
            int next = opts[0];
            for (int i = 0; i < opts.length; i++) {
                if (opts[i] == cur) {
                    next = opts[(i + 1) % opts.length];
                }
            }
            Prefs.putInt(LoudAlarm.K_LEN, next);
            refresh();
        });
        tools.addView(lenChip, weight(1f));
        tools.addView(chip("TEST 3 S", () -> {
            host.toast("Careful, it's LOUD: " + LoudAlarm.SOUNDS[LoudAlarm.nextSound()]);
            LoudAlarm.start(host, 3000, LoudAlarm.nextSound());
        }), weight(1f));
        addView(tools, wide());
        LinearLayout snd = row();
        soundChip = chip("", () -> {
            Prefs.putInt(LoudAlarm.K_SOUND, (Prefs.getInt(LoudAlarm.K_SOUND, 2) + 1) % LoudAlarm.SOUNDS.length);
            String[] why = {"LOUD: harsh beep, best to be noticed from far away",
                "LOCATE: sharp noise bursts, best to find exactly where the phone is",
                "BOTH: loud beep to hear roughly where, then bursts to walk straight to it"};
            host.toast(why[Prefs.getInt(LoudAlarm.K_SOUND, 2)]);
            refresh();
        });
        snd.addView(soundChip, weight(1f));
        modeChip = chip("", () -> {
            Prefs.putInt(LoudAlarm.K_MODE, (Prefs.getInt(LoudAlarm.K_MODE, 0) + 1) % LoudAlarm.MODES.length);
            host.toast(Prefs.getInt(LoudAlarm.K_MODE, 0) == 1 ? "SWITCH: message 1 LOUD, message 2 LOCATE, and so on"
                    : "ALWAYS: every message uses the SOUND you picked");
            refresh();
        });
        snd.addView(modeChip, weight(1f));
        addView(snd, wide());
        refresh();
    }

    private void arm(int minutes) {
        if (!NovaNotificationService.hasAccess(host)) {
            new AlertDialog.Builder(host).setTitle("Notification access needed")
                    .setMessage("LOUD ALARM listens for notifications and incoming calls. Switch on NOVA notifications on the "
                            + "next screen, then arm it again.")
                    .setPositiveButton("OPEN SETTINGS", (d, w) -> {
                        try {
                            host.startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        } catch (RuntimeException e) {
                            host.toast("Open Settings > Notifications > Notification access");
                        }
                    }).setNegativeButton("CANCEL", null).show();
            return;
        }
        LoudAlarm.arm(minutes * 60000L);
        host.buzz(20);
        host.toast(minutes == 0 ? "Armed: the next notification or call makes it beep"
                : "Arms itself in " + minutes + " min");
        if (!LoudAlarm.dndAccess(host) && !Prefs.getBool("la_dnd_asked", false)) {
            Prefs.putBool("la_dnd_asked", true);
            new AlertDialog.Builder(host).setTitle("Through Do Not Disturb?")
                    .setMessage("Alarms usually get through Do Not Disturb already. To be sure, allow NOVA on the next screen.")
                    .setPositiveButton("ALLOW", (d, w) -> {
                        try {
                            host.startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                        } catch (RuntimeException ignored) {
                            // not on this phone
                        }
                    }).setNegativeButton("SKIP", null).show();
        }
        refresh();
    }

    private void custom() {
        final EditText e = new EditText(host);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setHint("minutes");
        e.setGravity(Gravity.CENTER);
        new AlertDialog.Builder(host).setTitle("Arm in how many minutes?").setView(e)
                .setPositiveButton("ARM", (d, w) -> {
                    try {
                        int m = Integer.parseInt(e.getText().toString().trim());
                        arm(Math.max(0, Math.min(60 * 24 * 7, m)));
                    } catch (NumberFormatException ex) {
                        host.toast("Type a number of minutes");
                    }
                }).setNegativeButton("CANCEL", null).show();
    }

    @Override
    void onLive(boolean on) {
        LoudAlarm.listener = on ? onChange : null;
    }

    @Override
    long tickMs() {
        return 1000;
    }

    @Override
    void tick() {
        refresh();
    }

    @Override
    void refresh() {
        boolean ring = LoudAlarm.ringing();
        boolean armed = LoudAlarm.armed();
        long now = System.currentTimeMillis();
        stop.setVisibility(ring ? VISIBLE : GONE);
        arms.setVisibility(ring ? GONE : VISIBLE);
        off.setVisibility(armed || ring ? VISIBLE : GONE);
        lenChip.setText("BEEPS " + LoudAlarm.minutes() + " MIN");
        boolean sw = Prefs.getInt(LoudAlarm.K_MODE, 0) == 1;
        soundChip.setText("SOUND " + (sw ? "\u2014" : LoudAlarm.SOUNDS[Prefs.getInt(LoudAlarm.K_SOUND, 2)]));
        soundChip.setAlpha(sw ? 0.4f : 1f);
        modeChip.setText(sw ? "SWITCH \u00B7 next " + LoudAlarm.SOUNDS[LoudAlarm.nextSound()] : "MODE ALWAYS");
        if (ring) {
            long s = (now - LoudAlarm.ringSince()) / 1000;
            state.setText("🔊 RINGING");
            state.setTextColor(RED);
            sub.setText(String.format(Locale.ROOT, "for %d:%02d · stops by itself after %d min", s / 60, s % 60,
                    LoudAlarm.minutes()));
        } else if (armed && now < LoudAlarm.armAt()) {
            long s = (LoudAlarm.armAt() - now + 999) / 1000;
            state.setText(s >= 3600 ? String.format(Locale.ROOT, "ARMS IN %d:%02d:%02d", s / 3600, s / 60 % 60, s % 60)
                    : String.format(Locale.ROOT, "ARMS IN %d:%02d", s / 60, s % 60));
            state.setTextColor(AMBER);
            sub.setText("then the next notification or call beeps at full volume");
        } else if (armed) {
            state.setText("● ARMED");
            state.setTextColor(GREEN);
            sub.setText(NovaNotificationService.hasAccess(host)
                    ? "the next notification or call beeps at full volume for " + LoudAlarm.minutes() + " min"
                    : "⚠ NOVA has no notification access: tap ARM NOW to fix");
        } else {
            state.setText("OFF");
            state.setTextColor(Theme.DIM);
            sub.setText("arm it and the next notification or call makes the phone beep as loud as it can");
        }
    }
}
