package app.novaos;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The setting "laofkdkrjiiais". Every time you switch it on, NOVA changes something about its design at random:
 * usually one small thing (clock font, icon style, accent colour...), sometimes a few, and now and then something big
 * (a whole new home layout, look and colour). Switch it off and everything goes back to how it was.
 */
final class Chaos {
    static final String K_ON = "laofkdkrjiiais";
    private static final String K_SNAP = "chaos_snap";
    private static final Random RNG = new Random();

    private Chaos() {
    }

    /** {key, label, number of choices (0 = on/off), first allowed, is big}. */
    private static final Object[][] THINGS = {
        {Prefs.K_ACCENT, "accent colour", Shop.FIRST_PREMIUM, 0, false},
        {Prefs.K_CLOCK_FONT, "clock font", 4, 0, false},
        {Prefs.K_CLOCK_STYLE, "clock style", 4, 0, false},
        {Prefs.K_ICON_STYLE, "icon style", 3, 0, false},
        {Prefs.K_GLOW_STRENGTH, "glow strength", 3, 0, false},
        {Prefs.K_HOME_STRENGTH, "wallpaper strength", 3, 0, false},
        {Prefs.K_GLOW_CLOCK, "clock glow", 0, 0, false},
        {Prefs.K_GLOW_EDGES, "edge light", 0, 0, false},
        {Prefs.K_HOME_CODE, "code wallpaper", 0, 0, false},
        {Prefs.K_HOLO, "holographic icons", 0, 0, false},
        {NameTag.K_STYLE, "name style", NameTag.STYLES.length, 0, false},
        {DrawerScreen.K_DRAWER, "app drawer look", DrawerScreen.NAMES.length, 0, false},
        {"islo_color", "island colour", 7, 0, false},
        {"islo_corner", "island corners", 3, 0, false},
        {"islo_font", "island font", 4, 0, false},
        {"islo_outline", "island outline", 4, 0, false},
        {Prefs.K_LIVE, "animated wallpaper", LiveWallpaper.NAMES.length, 1, true},
        {UiStyle.K_STYLE, "look of NOVA", UiStyle.NAMES.length, 0, true},
        {AltHome.K_LAYOUT, "home screen layout", AltHome.NAMES.length, 0, true},
        {Prefs.K_HACKER, "hacker mode", 0, 0, true},
    };

    static boolean on() {
        return Prefs.getBool(K_ON, false);
    }

    /** Called right after the switch was flipped. */
    static void flipped(NovaActivity host) {
        if (on()) {
            shuffle(host);
        } else {
            restore(host);
        }
    }

    private static void shuffle(NovaActivity host) {
        // remember how everything is now (only the first time: flipping on twice keeps the real original)
        if (Prefs.getString(K_SNAP, "").isEmpty()) {
            StringBuilder b = new StringBuilder();
            for (Object[] t : THINGS) {
                String k = (String) t[0];
                if ((int) t[2] == 0) {
                    boolean a = Prefs.getBool(k, true);
                    boolean z = Prefs.getBool(k, false);
                    b.append(k).append('=').append(a != z ? "-" : a ? "b1" : "b0").append(';');
                } else {
                    int v = Prefs.getInt(k, Integer.MIN_VALUE);
                    b.append(k).append('=').append(v == Integer.MIN_VALUE ? "-" : "i" + v).append(';');
                }
            }
            Prefs.putString(K_SNAP, b.toString());
        }
        // how wild: mostly one small thing, sometimes a few, sometimes something big
        int roll = RNG.nextInt(100);
        List<Object[]> pool = new ArrayList<>();
        for (Object[] t : THINGS) {
            if (roll >= 85 || !(boolean) t[4]) {
                pool.add(t);
            }
        }
        int n = roll < 60 ? 1 : roll < 85 ? 2 + RNG.nextInt(2) : 3 + RNG.nextInt(3);
        List<String> changed = new ArrayList<>();
        boolean big = false;
        for (int i = 0; i < n && !pool.isEmpty(); i++) {
            Object[] t = pool.remove(RNG.nextInt(pool.size()));
            String k = (String) t[0];
            int count = (int) t[2];
            if (count == 0) {
                Prefs.putBool(k, !Prefs.getBool(k, false));
            } else {
                int old = Prefs.getInt(k, 0);
                int v = old;
                for (int tries = 0; tries < 20 && (v == old || !allowed(k, v)); tries++) {
                    v = (int) t[3] + RNG.nextInt(Math.max(1, count - (int) t[3]));
                }
                if (!allowed(k, v)) {
                    continue;
                }
                Prefs.putInt(k, v);
            }
            big |= (boolean) t[4];
            changed.add((String) t[1]);
        }
        Theme.load();
        Island.reload();
        host.refreshTheme();
        host.toast((big ? "🌪 BIG change: " : "🎲 changed: ") + String.join(", ", changed));
    }

    private static boolean allowed(String k, int v) {
        if (k.equals(UiStyle.K_STYLE)) {
            return v != UiStyle.CUSTOM;
        }
        if (k.equals(Prefs.K_LIVE)) {
            return v != 6 && Upgrades.wallpaperOwned(v);
        }
        return true;
    }

    private static void restore(NovaActivity host) {
        String snap = Prefs.getString(K_SNAP, "");
        if (snap.isEmpty()) {
            return;
        }
        for (String part : snap.split(";")) {
            int eq = part.indexOf('=');
            if (eq <= 0) {
                continue;
            }
            String k = part.substring(0, eq);
            String v = part.substring(eq + 1);
            if (v.equals("-")) {
                Prefs.remove(k);
            } else if (v.startsWith("b")) {
                Prefs.putBool(k, v.equals("b1"));
            } else if (v.startsWith("i")) {
                try {
                    Prefs.putInt(k, Integer.parseInt(v.substring(1)));
                } catch (NumberFormatException ignored) {
                    // leave it
                }
            }
        }
        Prefs.remove(K_SNAP);
        Theme.load();
        Island.reload();
        host.refreshTheme();
        host.toast("Back to normal ✔");
    }
}
