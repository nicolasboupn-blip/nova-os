#!/usr/bin/env python3
"""
NOVA Net server: accounts, friends, group chats and ranklists for the NOVA launcher.

One file, Python 3.8+, no extra packages. Data lives in one SQLite file.

    python3 server.py                     # listens on 127.0.0.1:8080, data in nova_net.db
    python3 server.py --host 0.0.0.0      # reachable from your network
    python3 server.py --help

Run it behind HTTPS (a Cloudflare Tunnel, Caddy or nginx). Android blocks plain http by default.
See README.md next to this file.
"""
import argparse
import hashlib
import hmac
import json
import os
import re
import secrets
import smtplib
import sqlite3
import sys
import threading
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

VERSION = 1
SESSION_DAYS = 90
MAX_MSG = 500
MAX_BODY = 20000
BOARDS = {
    "week": "coins_week",
    "all": "coins_all",
    "stage": "stage",
    "streak": "streak",
    "quests": "quests_total",
    "collection": "cosmetics",
}
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")
NAME_RE = re.compile(r"^[a-z0-9_]{3,16}$")
CTRL_RE = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  username TEXT NOT NULL,
  username_l TEXT NOT NULL UNIQUE,
  pw_hash BLOB NOT NULL,
  salt BLOB NOT NULL,
  created INTEGER NOT NULL,
  last_seen INTEGER NOT NULL DEFAULT 0,
  banned INTEGER NOT NULL DEFAULT 0,
  hidden INTEGER NOT NULL DEFAULT 0,
  cheat INTEGER NOT NULL DEFAULT 0,
  verified INTEGER NOT NULL DEFAULT 1,
  verify_code TEXT,
  verify_until INTEGER,
  coins_all INTEGER NOT NULL DEFAULT 0,
  coins_week INTEGER NOT NULL DEFAULT 0,
  week_id TEXT NOT NULL DEFAULT '',
  stage INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  quests_total INTEGER NOT NULL DEFAULT 0,
  cosmetics INTEGER NOT NULL DEFAULT 0,
  title TEXT NOT NULL DEFAULT '',
  look TEXT NOT NULL DEFAULT '',
  synced INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS friendships (
  a INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  b INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  requester INTEGER NOT NULL,
  created INTEGER NOT NULL,
  PRIMARY KEY (a, b)
);
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  code TEXT UNIQUE,
  owner INTEGER,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS members (
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_read INTEGER NOT NULL DEFAULT 0,
  joined INTEGER NOT NULL,
  PRIMARY KEY (room_id, user_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_room ON messages(room_id, id);
CREATE TABLE IF NOT EXISTS blocks (
  blocker INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (blocker, blocked)
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reporter INTEGER NOT NULL,
  message_id INTEGER NOT NULL,
  reported INTEGER NOT NULL,
  text TEXT NOT NULL,
  reason TEXT NOT NULL,
  ts INTEGER NOT NULL,
  handled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS resets (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  until INTEGER NOT NULL
);
"""

CONFIG = {"db": "nova_net.db", "proxy": False}


# ---------------------------------------------------------------------- helpers
class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


def now():
    return int(time.time())


def week_id(ts=None):
    d = datetime.fromtimestamp(ts if ts is not None else time.time(), timezone.utc)
    y, w, _ = d.isocalendar()
    return "%04d-W%02d" % (y, w)


def connect():
    c = sqlite3.connect(CONFIG["db"], timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    return c


def init_db():
    c = connect()
    c.execute("PRAGMA journal_mode = WAL")
    c.executescript(SCHEMA)
    c.commit()
    c.close()


def clean_text(s, limit):
    s = CTRL_RE.sub("", str(s)).strip()
    return s[:limit]


def hash_pw(pw, salt):
    return hashlib.scrypt(pw.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)


def new_code(n=6):
    return "".join(secrets.choice(CODE_ALPHABET) for _ in range(n))


class Limiter:
    """A small in-memory limiter: at most `count` hits per `seconds` for a key."""

    def __init__(self):
        self.hits = {}
        self.lock = threading.Lock()

    def check(self, key, count, seconds):
        t = time.time()
        with self.lock:
            q = [x for x in self.hits.get(key, []) if t - x < seconds]
            if len(q) >= count:
                self.hits[key] = q
                return False
            q.append(t)
            self.hits[key] = q
            if len(self.hits) > 20000:
                for k in list(self.hits)[:5000]:
                    self.hits.pop(k, None)
            return True


LIMITS = Limiter()


def limit(key, count, seconds, what="Too many tries"):
    if not LIMITS.check(key, count, seconds):
        raise ApiError(429, what + ". Please wait a bit.")


def send_mail(to, subject, body):
    host = os.environ.get("NOVA_SMTP_HOST")
    if not host:
        return False
    msg = EmailMessage()
    msg["From"] = os.environ.get("NOVA_SMTP_FROM", os.environ.get("NOVA_SMTP_USER", "nova@localhost"))
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    port = int(os.environ.get("NOVA_SMTP_PORT", "587"))
    with smtplib.SMTP(host, port, timeout=15) as s:
        s.starttls()
        user = os.environ.get("NOVA_SMTP_USER")
        if user:
            s.login(user, os.environ.get("NOVA_SMTP_PASS", ""))
        s.send_message(msg)
    return True


def mail_enabled():
    return bool(os.environ.get("NOVA_SMTP_HOST"))


# ---------------------------------------------------------------------- data views
def look_list(s):
    out = []
    for x in (s or "").split(","):
        try:
            out.append(int(x))
        except ValueError:
            pass
    return out[:20]


def public_user(r):
    return {
        "username": r["username"],
        "title": r["title"],
        "stage": r["stage"],
        "look": look_list(r["look"]),
        "last_seen": r["last_seen"],
    }


def user_by_name(db, name):
    return db.execute("SELECT * FROM users WHERE username_l = ?", (str(name).strip().lower(),)).fetchone()


def pair(x, y):
    return (x, y) if x < y else (y, x)


def are_friends(db, x, y):
    a, b = pair(x, y)
    r = db.execute("SELECT status FROM friendships WHERE a = ? AND b = ?", (a, b)).fetchone()
    return bool(r and r["status"] == "ok")


def is_blocked(db, x, y):
    """True if either of them has blocked the other."""
    r = db.execute(
        "SELECT 1 FROM blocks WHERE (blocker = ? AND blocked = ?) OR (blocker = ? AND blocked = ?)", (x, y, y, x)
    ).fetchone()
    return bool(r)


def require_member(db, room_id, uid):
    r = db.execute("SELECT 1 FROM members WHERE room_id = ? AND user_id = ?", (room_id, uid)).fetchone()
    if not r:
        raise ApiError(404, "No such chat")


# ---------------------------------------------------------------------- handlers
def h_register(ctx, body):
    db = ctx.db
    email = clean_text(body.get("email", ""), 254).lower()
    username = clean_text(body.get("username", ""), 40)
    pw = str(body.get("password", ""))
    if not EMAIL_RE.match(email):
        raise ApiError(400, "That does not look like an email address")
    if not NAME_RE.match(username.lower()):
        raise ApiError(400, "Username: 3 to 16 letters, numbers or underscore")
    if len(pw) < 8 or len(pw) > 200:
        raise ApiError(400, "Password needs at least 8 characters")
    limit("reg:" + ctx.ip, 8, 3600, "Too many sign ups from here")
    if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        raise ApiError(409, "That email already has an account")
    if user_by_name(db, username):
        raise ApiError(409, "That username is taken")
    salt = secrets.token_bytes(16)
    verified = 0 if mail_enabled() else 1
    code = None
    until = None
    if not verified:
        code = "%06d" % secrets.randbelow(1000000)
        until = now() + 3600
    cur = db.execute(
        "INSERT INTO users (email, username, username_l, pw_hash, salt, created, last_seen, verified, verify_code, "
        "verify_until) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (email, username, username.lower(), hash_pw(pw, salt), salt, now(), now(), verified, code, until),
    )
    uid = cur.lastrowid
    if not verified:
        try:
            send_mail(email, "NOVA Net: your code", "Your NOVA Net code is %s. It works for one hour." % code)
        except Exception as e:  # mail trouble must not lose the account
            print("mail failed:", e, file=sys.stderr)
    return {"token": make_session(db, uid), "username": username, "verified": bool(verified)}


def make_session(db, uid):
    token = secrets.token_urlsafe(32)
    db.execute(
        "INSERT INTO sessions (token_hash, user_id, created) VALUES (?,?,?)",
        (hashlib.sha256(token.encode()).hexdigest(), uid, now()),
    )
    return token


def h_login(ctx, body):
    db = ctx.db
    who = clean_text(body.get("login", body.get("email", "")), 254).lower()
    pw = str(body.get("password", ""))
    limit("login:" + ctx.ip, 20, 600, "Too many log in tries")
    limit("login:" + who, 8, 600, "Too many log in tries")
    r = db.execute("SELECT * FROM users WHERE email = ? OR username_l = ?", (who, who)).fetchone()
    ok = False
    if r:
        ok = hmac.compare_digest(hash_pw(pw, r["salt"]), r["pw_hash"])
    else:
        hash_pw(pw, b"0" * 16)  # same time either way
    if not ok:
        raise ApiError(401, "Wrong name or password")
    if r["banned"]:
        raise ApiError(403, "This account is banned")
    return {"token": make_session(db, r["id"]), "username": r["username"], "verified": bool(r["verified"])}


def h_verify(ctx, body):
    u = ctx.user
    code = str(body.get("code", "")).strip()
    limit("verify:%d" % u["id"], 8, 600)
    if u["verified"]:
        return {"verified": True}
    if not u["verify_code"] or now() > (u["verify_until"] or 0) or not hmac.compare_digest(code, u["verify_code"]):
        raise ApiError(400, "That code is wrong or has expired")
    ctx.db.execute("UPDATE users SET verified = 1, verify_code = NULL WHERE id = ?", (u["id"],))
    return {"verified": True}


def h_resend(ctx, body):
    u = ctx.user
    limit("resend:%d" % u["id"], 3, 3600)
    if u["verified"] or not mail_enabled():
        return {"ok": True}
    code = "%06d" % secrets.randbelow(1000000)
    ctx.db.execute("UPDATE users SET verify_code = ?, verify_until = ? WHERE id = ?", (code, now() + 3600, u["id"]))
    ctx.db.commit()
    send_mail(u["email"], "NOVA Net: your code", "Your NOVA Net code is %s. It works for one hour." % code)
    return {"ok": True}


def h_reset_request(ctx, body):
    email = clean_text(body.get("email", ""), 254).lower()
    limit("reset:" + ctx.ip, 5, 3600)
    if not mail_enabled():
        raise ApiError(501, "This server cannot send email, ask its owner to reset your password")
    r = ctx.db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if r:
        code = "%06d" % secrets.randbelow(1000000)
        ctx.db.execute("INSERT OR REPLACE INTO resets (user_id, code, until) VALUES (?,?,?)", (r["id"], code, now() + 1800))
        ctx.db.commit()
        try:
            send_mail(email, "NOVA Net: reset code", "Your reset code is %s. It works for 30 minutes." % code)
        except Exception as e:
            print("mail failed:", e, file=sys.stderr)
    return {"ok": True}  # the same answer whether or not the email exists


def h_reset_confirm(ctx, body):
    db = ctx.db
    email = clean_text(body.get("email", ""), 254).lower()
    code = str(body.get("code", "")).strip()
    pw = str(body.get("password", ""))
    limit("resetc:" + ctx.ip, 10, 3600)
    if len(pw) < 8:
        raise ApiError(400, "Password needs at least 8 characters")
    r = db.execute("SELECT u.id AS id, s.code AS code, s.until AS until FROM users u JOIN resets s ON s.user_id = u.id "
                   "WHERE u.email = ?", (email,)).fetchone()
    if not r or now() > r["until"] or not hmac.compare_digest(code, r["code"]):
        raise ApiError(400, "That code is wrong or has expired")
    salt = secrets.token_bytes(16)
    db.execute("UPDATE users SET pw_hash = ?, salt = ? WHERE id = ?", (hash_pw(pw, salt), salt, r["id"]))
    db.execute("DELETE FROM resets WHERE user_id = ?", (r["id"],))
    db.execute("DELETE FROM sessions WHERE user_id = ?", (r["id"],))
    return {"ok": True}


def h_logout(ctx, body):
    ctx.db.execute("DELETE FROM sessions WHERE token_hash = ?", (ctx.token_hash,))
    return {"ok": True}


def h_me(ctx, body):
    u = ctx.user
    return {
        "username": u["username"],
        "email": u["email"],
        "verified": bool(u["verified"]),
        "hidden": bool(u["hidden"]),
        "stats": {k: u[k] for k in ("coins_all", "coins_week", "stage", "streak", "quests_total", "cosmetics")},
    }


def h_password(ctx, body):
    u = ctx.user
    limit("pw:%d" % u["id"], 6, 600)
    old = str(body.get("old", ""))
    new = str(body.get("new", ""))
    if not hmac.compare_digest(hash_pw(old, u["salt"]), u["pw_hash"]):
        raise ApiError(401, "Your old password is wrong")
    if len(new) < 8 or len(new) > 200:
        raise ApiError(400, "Password needs at least 8 characters")
    salt = secrets.token_bytes(16)
    ctx.db.execute("UPDATE users SET pw_hash = ?, salt = ? WHERE id = ?", (hash_pw(new, salt), salt, u["id"]))
    ctx.db.execute("DELETE FROM sessions WHERE user_id = ? AND token_hash != ?", (u["id"], ctx.token_hash))
    return {"ok": True}


def h_delete_account(ctx, body):
    u = ctx.user
    limit("del:%d" % u["id"], 5, 600)
    if not hmac.compare_digest(hash_pw(str(body.get("password", "")), u["salt"]), u["pw_hash"]):
        raise ApiError(401, "Wrong password")
    db = ctx.db
    uid = u["id"]
    # groups they own go to another member, or are removed when empty
    for r in db.execute("SELECT id FROM rooms WHERE kind = 'group' AND owner = ?", (uid,)).fetchall():
        nxt = db.execute("SELECT user_id FROM members WHERE room_id = ? AND user_id != ? ORDER BY joined LIMIT 1",
                         (r["id"], uid)).fetchone()
        if nxt:
            db.execute("UPDATE rooms SET owner = ? WHERE id = ?", (nxt["user_id"], r["id"]))
        else:
            db.execute("DELETE FROM rooms WHERE id = ?", (r["id"],))
    db.execute("DELETE FROM rooms WHERE kind = 'dm' AND id IN (SELECT room_id FROM members WHERE user_id = ?)", (uid,))
    db.execute("DELETE FROM reports WHERE reporter = ?", (uid,))
    db.execute("DELETE FROM users WHERE id = ?", (uid,))
    return {"ok": True}


def h_settings(ctx, body):
    if "hidden" in body:
        ctx.db.execute("UPDATE users SET hidden = ? WHERE id = ?", (1 if body["hidden"] else 0, ctx.user["id"]))
    return {"ok": True}


def num(v, lo=0, hi=10 ** 12):
    try:
        v = int(v)
    except (TypeError, ValueError):
        return lo
    return max(lo, min(hi, v))


def h_sync(ctx, body):
    """The app reports its stats. The server keeps them sane: all time numbers only go up."""
    u = ctx.user
    limit("sync:%d" % u["id"], 60, 3600)
    db = ctx.db
    coins_all = num(body.get("coins_all"))
    stage = num(body.get("stage"), 0, 10)
    streak = num(body.get("streak"), 0, 100000)
    quests = num(body.get("quests_total"), 0, 10 ** 7)
    cosm = num(body.get("cosmetics"), 0, 5000)
    cheat = 1 if body.get("cheat") else u["cheat"]
    # an impossible jump marks the account, so it stays off the ranklists
    if coins_all - u["coins_all"] > 400000 and u["synced"]:
        cheat = 1
    coins_all = max(coins_all, u["coins_all"])
    wk = week_id()
    coins_week = u["coins_week"] if u["week_id"] == wk else 0
    if str(body.get("week_id", "")) == wk:
        coins_week = max(coins_week, num(body.get("coins_week")))
    title = clean_text(body.get("title", ""), 20)
    look = ",".join(str(num(x, 0, 99)) for x in (body.get("look") or [])[:20])
    db.execute(
        "UPDATE users SET coins_all=?, coins_week=?, week_id=?, stage=?, streak=?, quests_total=?, cosmetics=?, "
        "title=?, look=?, cheat=?, synced=1, last_seen=? WHERE id=?",
        (coins_all, coins_week, wk, stage, streak, max(quests, u["quests_total"]), cosm, title, look, cheat, now(), u["id"]),
    )
    return {"week_id": wk, "ok": True}


def h_rank(ctx, body):
    db = ctx.db
    q = ctx.query
    board = q.get("board", ["week"])[0]
    scope = q.get("scope", ["all"])[0]
    if board not in BOARDS:
        raise ApiError(400, "Unknown board")
    col = BOARDS[board]
    wk = week_id()
    base = "FROM users WHERE banned = 0 AND hidden = 0 AND cheat = 0 AND synced = 1"
    if board == "week":
        base += " AND week_id = '%s'" % wk
    args = []
    if scope == "friends":
        base += (" AND (id = ? OR id IN (SELECT CASE WHEN a = ? THEN b ELSE a END FROM friendships "
                 "WHERE status = 'ok' AND (a = ? OR b = ?)))")
        uid = ctx.user["id"]
        args = [uid, uid, uid, uid]
    rows = db.execute("SELECT * %s AND %s > 0 ORDER BY %s DESC, id ASC LIMIT 50" % (base, col, col), args).fetchall()
    out = []
    for i, r in enumerate(rows):
        d = public_user(r)
        d["rank"] = i + 1
        d["value"] = r[col]
        d["me"] = r["id"] == ctx.user["id"]
        out.append(d)
    me = ctx.user
    mine = None
    if not me["hidden"] and not me["cheat"] and me["synced"]:
        val = me[col] if (board != "week" or me["week_id"] == wk) else 0
        cnt = db.execute("SELECT COUNT(*) AS n %s AND %s > ?" % (base, col), args + [val]).fetchone()["n"]
        mine = {"rank": cnt + 1, "value": val}
    return {"board": board, "scope": scope, "week_id": wk, "rows": out, "me": mine,
            "hidden": bool(me["hidden"]), "cheat": bool(me["cheat"])}


# ---------------------------------------------------------------------- friends
def friend_rows(db, uid):
    rows = db.execute(
        "SELECT f.a, f.b, f.status, f.requester, u.* FROM friendships f JOIN users u ON u.id = "
        "CASE WHEN f.a = ? THEN f.b ELSE f.a END WHERE f.a = ? OR f.b = ?", (uid, uid, uid)).fetchall()
    out = []
    for r in rows:
        if is_blocked(db, uid, r["id"]):
            continue
        d = public_user(r)
        if r["status"] == "ok":
            d["status"] = "friend"
        else:
            d["status"] = "outgoing" if r["requester"] == uid else "incoming"
        out.append(d)
    order = {"incoming": 0, "friend": 1, "outgoing": 2}
    out.sort(key=lambda d: (order[d["status"]], d["username"].lower()))
    return out


def h_friends(ctx, body):
    return {"friends": friend_rows(ctx.db, ctx.user["id"])}


def h_friend_request(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    limit("freq:%d" % uid, 30, 3600, "Too many friend requests")
    other = user_by_name(db, body.get("username", ""))
    if not other or other["banned"]:
        raise ApiError(404, "No one with that username")
    if other["id"] == uid:
        raise ApiError(400, "That is you")
    if is_blocked(db, uid, other["id"]):
        raise ApiError(404, "No one with that username")
    a, b = pair(uid, other["id"])
    r = db.execute("SELECT * FROM friendships WHERE a = ? AND b = ?", (a, b)).fetchone()
    if r:
        if r["status"] == "ok":
            return {"status": "friend"}
        if r["requester"] != uid:  # they asked first, so this is an accept
            db.execute("UPDATE friendships SET status = 'ok' WHERE a = ? AND b = ?", (a, b))
            return {"status": "friend"}
        return {"status": "outgoing"}
    db.execute("INSERT INTO friendships (a, b, status, requester, created) VALUES (?,?,?,?,?)",
               (a, b, "pending", uid, now()))
    return {"status": "outgoing"}


def h_friend_accept(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    other = user_by_name(db, body.get("username", ""))
    if not other:
        raise ApiError(404, "No one with that username")
    a, b = pair(uid, other["id"])
    r = db.execute("SELECT * FROM friendships WHERE a = ? AND b = ? AND status = 'pending' AND requester != ?",
                   (a, b, uid)).fetchone()
    if not r:
        raise ApiError(404, "No request from that person")
    db.execute("UPDATE friendships SET status = 'ok' WHERE a = ? AND b = ?", (a, b))
    return {"status": "friend"}


def h_friend_remove(ctx, body):
    """Removes a friend, declines a request or cancels one you sent."""
    db = ctx.db
    uid = ctx.user["id"]
    other = user_by_name(db, body.get("username", ""))
    if other:
        a, b = pair(uid, other["id"])
        db.execute("DELETE FROM friendships WHERE a = ? AND b = ?", (a, b))
    return {"ok": True}


def h_user(ctx, body):
    other = user_by_name(ctx.db, ctx.query.get("name", [""])[0])
    if not other or other["banned"] or is_blocked(ctx.db, ctx.user["id"], other["id"]):
        raise ApiError(404, "No one with that username")
    d = public_user(other)
    d["stats"] = {k: other[k] for k in ("coins_all", "coins_week", "stage", "streak", "quests_total", "cosmetics")}
    return d


def h_block(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    other = user_by_name(db, body.get("username", ""))
    if not other or other["id"] == uid:
        raise ApiError(404, "No one with that username")
    db.execute("INSERT OR IGNORE INTO blocks (blocker, blocked) VALUES (?,?)", (uid, other["id"]))
    a, b = pair(uid, other["id"])
    db.execute("DELETE FROM friendships WHERE a = ? AND b = ?", (a, b))
    return {"ok": True}


def h_unblock(ctx, body):
    other = user_by_name(ctx.db, body.get("username", ""))
    if other:
        ctx.db.execute("DELETE FROM blocks WHERE blocker = ? AND blocked = ?", (ctx.user["id"], other["id"]))
    return {"ok": True}


def h_blocks(ctx, body):
    rows = ctx.db.execute("SELECT u.username FROM blocks b JOIN users u ON u.id = b.blocked WHERE b.blocker = ?",
                          (ctx.user["id"],)).fetchall()
    return {"blocked": [r["username"] for r in rows]}


# ---------------------------------------------------------------------- chats
def room_title(db, room, uid):
    if room["kind"] == "dm":
        r = db.execute("SELECT u.username FROM members m JOIN users u ON u.id = m.user_id "
                       "WHERE m.room_id = ? AND m.user_id != ?", (room["id"], uid)).fetchone()
        return r["username"] if r else "(left)"
    return room["name"]


def visible_filter(db, uid):
    """SQL text and args that hide messages from people the user blocked, or who blocked them."""
    return ("AND m.user_id NOT IN (SELECT blocked FROM blocks WHERE blocker = ?) "
            "AND m.user_id NOT IN (SELECT blocker FROM blocks WHERE blocked = ?)"), [uid, uid]


def h_chats(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    rooms = db.execute("SELECT r.*, mm.last_read FROM rooms r JOIN members mm ON mm.room_id = r.id "
                       "WHERE mm.user_id = ?", (uid,)).fetchall()
    vf, vargs = visible_filter(db, uid)
    out = []
    for r in rooms:
        if r["kind"] == "dm":
            other = db.execute("SELECT user_id FROM members WHERE room_id = ? AND user_id != ?", (r["id"], uid)).fetchone()
            if other and is_blocked(db, uid, other["user_id"]):
                continue
        last = db.execute("SELECT m.id, m.text, m.ts, u.username FROM messages m JOIN users u ON u.id = m.user_id "
                          "WHERE m.room_id = ? %s ORDER BY m.id DESC LIMIT 1" % vf, [r["id"]] + vargs).fetchone()
        unread = db.execute("SELECT COUNT(*) AS n FROM messages m WHERE m.room_id = ? AND m.id > ? AND m.user_id != ? %s"
                            % vf, [r["id"], r["last_read"], uid] + vargs).fetchone()["n"]
        out.append({
            "id": r["id"], "kind": r["kind"], "name": room_title(db, r, uid),
            "code": r["code"] if r["kind"] == "group" and r["owner"] == uid else None,
            "owner": r["owner"] == uid,
            "last": {"text": last["text"], "user": last["username"], "ts": last["ts"]} if last else None,
            "unread": unread, "ts": last["ts"] if last else r["created"],
        })
    out.sort(key=lambda d: -d["ts"])
    return {"chats": out, "unread": sum(c["unread"] for c in out)}


def h_dm(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    other = user_by_name(db, body.get("username", ""))
    if not other or other["banned"]:
        raise ApiError(404, "No one with that username")
    if not are_friends(db, uid, other["id"]) or is_blocked(db, uid, other["id"]):
        raise ApiError(403, "You can only message friends")
    r = db.execute("SELECT r.id FROM rooms r JOIN members a ON a.room_id = r.id AND a.user_id = ? "
                   "JOIN members b ON b.room_id = r.id AND b.user_id = ? WHERE r.kind = 'dm'", (uid, other["id"])).fetchone()
    if r:
        return {"id": r["id"]}
    rid = db.execute("INSERT INTO rooms (kind, name, owner, created) VALUES ('dm', '', NULL, ?)", (now(),)).lastrowid
    for x in (uid, other["id"]):
        db.execute("INSERT INTO members (room_id, user_id, joined) VALUES (?,?,?)", (rid, x, now()))
    return {"id": rid}


def h_group_create(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    limit("gcreate:%d" % uid, 10, 3600)
    name = clean_text(body.get("name", ""), 24)
    if len(name) < 2:
        raise ApiError(400, "Give the group a name")
    if db.execute("SELECT COUNT(*) AS n FROM rooms WHERE kind = 'group' AND owner = ?", (uid,)).fetchone()["n"] >= 8:
        raise ApiError(400, "You already own 8 groups")
    for _ in range(20):
        code = new_code()
        if not db.execute("SELECT 1 FROM rooms WHERE code = ?", (code,)).fetchone():
            break
    rid = db.execute("INSERT INTO rooms (kind, name, code, owner, created) VALUES ('group', ?, ?, ?, ?)",
                     (name, code, uid, now())).lastrowid
    db.execute("INSERT INTO members (room_id, user_id, joined) VALUES (?,?,?)", (rid, uid, now()))
    return {"id": rid, "code": code}


def h_group_join(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    limit("gjoin:%d" % uid, 15, 3600, "Too many tries")
    code = clean_text(body.get("code", ""), 12).upper()
    r = db.execute("SELECT * FROM rooms WHERE kind = 'group' AND code = ?", (code,)).fetchone()
    if not r:
        raise ApiError(404, "No group with that code")
    if db.execute("SELECT COUNT(*) AS n FROM members WHERE room_id = ?", (r["id"],)).fetchone()["n"] >= 30:
        raise ApiError(400, "That group is full (30 people)")
    owner = r["owner"]
    if owner and is_blocked(db, uid, owner):
        raise ApiError(404, "No group with that code")
    db.execute("INSERT OR IGNORE INTO members (room_id, user_id, last_read, joined) VALUES (?,?,"
               "(SELECT COALESCE(MAX(id),0) FROM messages WHERE room_id = ?),?)", (r["id"], uid, r["id"], now()))
    return {"id": r["id"], "name": r["name"]}


def h_group_leave(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    rid = num(body.get("room_id"))
    r = db.execute("SELECT * FROM rooms WHERE id = ? AND kind = 'group'", (rid,)).fetchone()
    require_member(db, rid, uid)
    db.execute("DELETE FROM members WHERE room_id = ? AND user_id = ?", (rid, uid))
    if r and r["owner"] == uid:
        nxt = db.execute("SELECT user_id FROM members WHERE room_id = ? ORDER BY joined LIMIT 1", (rid,)).fetchone()
        if nxt:
            db.execute("UPDATE rooms SET owner = ? WHERE id = ?", (nxt["user_id"], rid))
        else:
            db.execute("DELETE FROM rooms WHERE id = ?", (rid,))
    return {"ok": True}


def h_group_kick(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    rid = num(body.get("room_id"))
    r = db.execute("SELECT * FROM rooms WHERE id = ? AND kind = 'group' AND owner = ?", (rid, uid)).fetchone()
    if not r:
        raise ApiError(403, "Only the group owner can remove people")
    other = user_by_name(db, body.get("username", ""))
    if other and other["id"] != uid:
        db.execute("DELETE FROM members WHERE room_id = ? AND user_id = ?", (rid, other["id"]))
    return {"ok": True}


def h_members(ctx, rid):
    db = ctx.db
    require_member(db, rid, ctx.user["id"])
    rows = db.execute("SELECT u.*, r.owner AS owner FROM members m JOIN users u ON u.id = m.user_id "
                      "JOIN rooms r ON r.id = m.room_id WHERE m.room_id = ? ORDER BY m.joined", (rid,)).fetchall()
    out = []
    for r in rows:
        d = public_user(r)
        d["owner"] = r["owner"] == r["id"]
        out.append(d)
    return {"members": out}


def h_messages(ctx, rid):
    db = ctx.db
    uid = ctx.user["id"]
    require_member(db, rid, uid)
    q = ctx.query
    after = num(q.get("after", ["0"])[0])
    limit_n = max(1, min(100, num(q.get("limit", ["50"])[0], 1, 100)))
    vf, vargs = visible_filter(db, uid)
    if after:
        rows = db.execute("SELECT m.id, m.text, m.ts, u.username FROM messages m JOIN users u ON u.id = m.user_id "
                          "WHERE m.room_id = ? AND m.id > ? %s ORDER BY m.id ASC LIMIT ?" % vf,
                          [rid, after] + vargs + [limit_n]).fetchall()
    else:
        rows = db.execute("SELECT m.id, m.text, m.ts, u.username FROM messages m JOIN users u ON u.id = m.user_id "
                          "WHERE m.room_id = ? %s ORDER BY m.id DESC LIMIT ?" % vf, [rid] + vargs + [limit_n]).fetchall()
        rows = list(reversed(rows))
    newest = db.execute("SELECT COALESCE(MAX(id),0) AS n FROM messages WHERE room_id = ?", (rid,)).fetchone()["n"]
    db.execute("UPDATE members SET last_read = ? WHERE room_id = ? AND user_id = ?", (newest, rid, uid))
    return {"messages": [{"id": r["id"], "user": r["username"], "text": r["text"], "ts": r["ts"]} for r in rows]}


def h_send(ctx, rid, body):
    db = ctx.db
    u = ctx.user
    uid = u["id"]
    if not u["verified"]:
        raise ApiError(403, "Verify your email first")
    require_member(db, rid, uid)
    limit("msg:%d" % uid, 25, 60, "You are sending too fast")
    text = clean_text(body.get("text", ""), MAX_MSG)
    if not text:
        raise ApiError(400, "Empty message")
    room = db.execute("SELECT kind FROM rooms WHERE id = ?", (rid,)).fetchone()
    if room["kind"] == "dm":
        other = db.execute("SELECT user_id FROM members WHERE room_id = ? AND user_id != ?", (rid, uid)).fetchone()
        if not other or is_blocked(db, uid, other["user_id"]) or not are_friends(db, uid, other["user_id"]):
            raise ApiError(403, "You can only message friends")
    mid = db.execute("INSERT INTO messages (room_id, user_id, text, ts) VALUES (?,?,?,?)", (rid, uid, text, now())).lastrowid
    db.execute("UPDATE members SET last_read = ? WHERE room_id = ? AND user_id = ?", (mid, rid, uid))
    db.execute("UPDATE users SET last_seen = ? WHERE id = ?", (now(), uid))
    return {"id": mid}


def h_report(ctx, body):
    db = ctx.db
    uid = ctx.user["id"]
    limit("report:%d" % uid, 20, 3600)
    mid = num(body.get("message_id"))
    m = db.execute("SELECT * FROM messages WHERE id = ?", (mid,)).fetchone()
    if not m:
        raise ApiError(404, "No such message")
    require_member(db, m["room_id"], uid)
    db.execute("INSERT INTO reports (reporter, message_id, reported, text, reason, ts) VALUES (?,?,?,?,?,?)",
               (uid, mid, m["user_id"], m["text"], clean_text(body.get("reason", ""), 200), now()))
    return {"ok": True}


# ---------------------------------------------------------------------- the web server
class Ctx:
    pass


def route(method, path):
    """Returns (handler, needs_login, extra) for a path."""
    simple = {
        ("POST", "/api/register"): (h_register, False),
        ("POST", "/api/login"): (h_login, False),
        ("POST", "/api/reset/request"): (h_reset_request, False),
        ("POST", "/api/reset/confirm"): (h_reset_confirm, False),
        ("POST", "/api/logout"): (h_logout, True),
        ("POST", "/api/verify"): (h_verify, True),
        ("POST", "/api/verify/resend"): (h_resend, True),
        ("GET", "/api/me"): (h_me, True),
        ("POST", "/api/password"): (h_password, True),
        ("POST", "/api/me/delete"): (h_delete_account, True),
        ("POST", "/api/settings"): (h_settings, True),
        ("POST", "/api/sync"): (h_sync, True),
        ("GET", "/api/rank"): (h_rank, True),
        ("GET", "/api/friends"): (h_friends, True),
        ("POST", "/api/friends/request"): (h_friend_request, True),
        ("POST", "/api/friends/accept"): (h_friend_accept, True),
        ("POST", "/api/friends/remove"): (h_friend_remove, True),
        ("GET", "/api/user"): (h_user, True),
        ("POST", "/api/block"): (h_block, True),
        ("POST", "/api/unblock"): (h_unblock, True),
        ("GET", "/api/blocks"): (h_blocks, True),
        ("GET", "/api/chats"): (h_chats, True),
        ("POST", "/api/chats/dm"): (h_dm, True),
        ("POST", "/api/groups"): (h_group_create, True),
        ("POST", "/api/groups/join"): (h_group_join, True),
        ("POST", "/api/groups/leave"): (h_group_leave, True),
        ("POST", "/api/groups/kick"): (h_group_kick, True),
        ("POST", "/api/report"): (h_report, True),
    }
    if (method, path) in simple:
        h, need = simple[(method, path)]
        return h, need, None
    m = re.match(r"^/api/chats/(\d+)/(messages|members)$", path)
    if m:
        rid = int(m.group(1))
        if m.group(2) == "messages" and method == "GET":
            return h_messages, True, rid
        if m.group(2) == "messages" and method == "POST":
            return h_send, True, rid
        if m.group(2) == "members" and method == "GET":
            return h_members, True, rid
    return None, False, None


class Handler(BaseHTTPRequestHandler):
    server_version = "NovaNet/%d" % VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if os.environ.get("NOVA_LOG"):
            sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))

    def client_ip(self):
        if CONFIG["proxy"]:
            fwd = self.headers.get("X-Forwarded-For") or self.headers.get("CF-Connecting-IP")
            if fwd:
                return fwd.split(",")[0].strip()
        return self.client_address[0]

    def reply(self, status, obj):
        data = json.dumps(obj, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def handle_any(self, method):
        db = None
        try:
            url = urlparse(self.path)
            path = url.path.rstrip("/") or "/"
            if method == "GET" and path == "/":
                return self.reply(200, {"name": "NOVA Net", "version": VERSION, "ok": True, "mail": mail_enabled()})
            body = {}
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                if n > MAX_BODY:
                    raise ApiError(413, "Too big")
                raw = self.rfile.read(n) if n else b""
                try:
                    body = json.loads(raw.decode("utf-8")) if raw else {}
                except ValueError:
                    raise ApiError(400, "Bad JSON")
                if not isinstance(body, dict):
                    raise ApiError(400, "Bad JSON")
            handler, need, extra = route(method, path)
            if handler is None:
                raise ApiError(404, "Not found")
            ctx = Ctx()
            ctx.ip = self.client_ip()
            ctx.query = parse_qs(url.query)
            limit("ip:" + ctx.ip, 600, 60, "Too many requests")
            db = connect()
            ctx.db = db
            ctx.user = None
            ctx.token_hash = None
            if need:
                auth = self.headers.get("Authorization", "")
                token = auth[7:].strip() if auth.startswith("Bearer ") else ""
                th = hashlib.sha256(token.encode()).hexdigest()
                row = db.execute("SELECT u.*, s.created AS s_created FROM sessions s JOIN users u ON u.id = s.user_id "
                                 "WHERE s.token_hash = ?", (th,)).fetchone() if token else None
                if not row or now() - row["s_created"] > SESSION_DAYS * 86400:
                    raise ApiError(401, "Please log in again")
                if row["banned"]:
                    raise ApiError(403, "This account is banned")
                ctx.user = row
                ctx.token_hash = th
                if now() - row["last_seen"] > 60:
                    db.execute("UPDATE users SET last_seen = ? WHERE id = ?", (now(), row["id"]))
            result = handler(ctx, extra) if extra is not None and method == "GET" and handler in (h_messages, h_members) \
                else handler(ctx, extra, body) if extra is not None else handler(ctx, body)
            db.commit()
            self.reply(200, result)
        except ApiError as e:
            if db:
                db.rollback()
            self.reply(e.status, {"error": e.message})
        except Exception as e:  # never leak details to the app
            if db:
                db.rollback()
            print("error:", repr(e), file=sys.stderr)
            self.reply(500, {"error": "Server trouble"})
        finally:
            if db:
                db.close()

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")


# ---------------------------------------------------------------------- owner tools
def cli_tools(args):
    db = connect()
    if args.reports:
        rows = db.execute("SELECT r.id, r.ts, ru.username AS reporter, tu.username AS reported, r.text, r.reason, r.handled "
                          "FROM reports r JOIN users ru ON ru.id = r.reporter JOIN users tu ON tu.id = r.reported "
                          "ORDER BY r.id DESC LIMIT 50").fetchall()
        for r in rows:
            print("#%d %s  %s reported %s%s\n    \"%s\"\n    reason: %s" % (
                r["id"], datetime.fromtimestamp(r["ts"]).strftime("%d.%m %H:%M"), r["reporter"], r["reported"],
                " (handled)" if r["handled"] else "", r["text"], r["reason"] or "-"))
        if not rows:
            print("no reports")
    elif args.ban or args.unban:
        name = args.ban or args.unban
        r = user_by_name(db, name)
        if not r:
            print("no such user")
            return
        db.execute("UPDATE users SET banned = ? WHERE id = ?", (1 if args.ban else 0, r["id"]))
        if args.ban:
            db.execute("DELETE FROM sessions WHERE user_id = ?", (r["id"],))
        db.execute("UPDATE reports SET handled = 1 WHERE reported = ?", (r["id"],))
        db.commit()
        print(("banned " if args.ban else "unbanned ") + r["username"])
    elif args.delete_message:
        db.execute("DELETE FROM messages WHERE id = ?", (args.delete_message,))
        db.commit()
        print("deleted")
    elif args.stats:
        for label, q in (("users", "SELECT COUNT(*) FROM users"), ("rooms", "SELECT COUNT(*) FROM rooms"),
                         ("messages", "SELECT COUNT(*) FROM messages"),
                         ("open reports", "SELECT COUNT(*) FROM reports WHERE handled = 0")):
            print("%-13s %d" % (label, db.execute(q).fetchone()[0]))
    db.close()


def main():
    ap = argparse.ArgumentParser(description="NOVA Net server")
    ap.add_argument("--host", default="127.0.0.1", help="address to listen on (default 127.0.0.1)")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--db", default="nova_net.db", help="SQLite file")
    ap.add_argument("--proxy", action="store_true", help="trust X-Forwarded-For (use behind a tunnel or reverse proxy)")
    ap.add_argument("--reports", action="store_true", help="list recent reports and exit")
    ap.add_argument("--ban", metavar="USERNAME", help="ban a user and exit")
    ap.add_argument("--unban", metavar="USERNAME", help="unban a user and exit")
    ap.add_argument("--delete-message", type=int, metavar="ID", help="delete one message and exit")
    ap.add_argument("--stats", action="store_true", help="show counts and exit")
    args = ap.parse_args()
    CONFIG["db"] = args.db
    CONFIG["proxy"] = args.proxy
    init_db()
    if args.reports or args.ban or args.unban or args.delete_message or args.stats:
        cli_tools(args)
        return
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    srv.daemon_threads = True
    print("NOVA Net listening on http://%s:%d  (db: %s)%s" % (
        args.host, args.port, args.db, "  email: on" if mail_enabled() else "  email: off (accounts are verified at once)"))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("bye")


if __name__ == "__main__":
    main()
