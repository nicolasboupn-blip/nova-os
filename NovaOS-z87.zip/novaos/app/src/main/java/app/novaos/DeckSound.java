package app.novaos;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The deck's own little synth: every pad can make a sound (an instrument and a note) when it is pressed, right on the
 * phone. Nothing is downloaded and no sound files are used, the sounds are made from numbers. In PLAY MODE the deck has
 * no buttons at all, only sound pads. Everything here runs on the main thread.
 */
final class DeckSound {
    private DeckSound() {}

    static final String K_ON = "deck_snd";
    static final String K_VOL = "deck_snd_vol";
    static final String K_INST = "deck_snd_inst";
    static final String K_PLAY = "deck_playmode";
    static final String K_PLAY_BINDS = "deck_play_binds";
    static final String K_HOLD = "deck_play_hold";
    static final String K_SLIDE = "deck_play_slide";

    static final String[] INST = {"Soft", "Retro", "Buzz", "Flute", "Pluck", "Bell", "Marimba", "Kick", "Snare",
        "Hi-hat", "Clap", "Zap"};
    private static final int SUSTAINED = 4; // instruments 0 to 3 can be held
    private static final int FIRST_DRUM = 7; // instruments from here have no note
    private static final String[] NOTE = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    private static final int[] PENTA = {0, 2, 4, 7, 9};
    private static final int RATE = 22050;

    static final int NOTE_MIN = 36, NOTE_MAX = 96;

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static final Map<Integer, Buf> CACHE = new java.util.concurrent.ConcurrentHashMap<>();
    private static final List<Voice> LIVE = new ArrayList<>();
    private static final Random RND = new Random(7);

    private static final class Buf {
        short[] pcm;
        int loopStart;
        int loopEnd;
        boolean loops;
        int ms;
    }

    /** One sound that is playing now. */
    static final class Voice {
        AudioTrack track;
        boolean looping;
        boolean dead;
    }

    // ------------------------------------------------------------------ settings

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    static boolean playMode() {
        return Prefs.getBool(K_PLAY, false);
    }

    static void setPlayMode(boolean on) {
        Prefs.putBool(K_PLAY, on);
    }

    static boolean playRunsBinds() {
        return Prefs.getBool(K_PLAY_BINDS, false);
    }

    static boolean holdSustains() {
        return Prefs.getBool(K_HOLD, true);
    }

    static boolean slides() {
        return Prefs.getBool(K_SLIDE, true);
    }

    static String noteName(int note) {
        return NOTE[((note % 12) + 12) % 12] + (note / 12 - 1);
    }

    static boolean pitched(int inst) {
        return inst < FIRST_DRUM || inst == 6;
    }

    /** The saved sound of a pad: "" (not set), "off", "auto" or "instrument:note". */
    static String spec(int idx) {
        return Prefs.getString("dsn_" + idx, "");
    }

    static void setSpec(int idx, String s) {
        Prefs.putString("dsn_" + idx, s);
    }

    /** The note a pad gets by its place on the grid: a pentatonic scale, low at the bottom and rising to the right. */
    static int autoNote(int idx) {
        int row = idx / DeckBinds.N;
        int col = idx % DeckBinds.N;
        int step = col + 2 * (DeckBinds.N - 1 - row);
        return Math.min(NOTE_MAX + 6, 48 + 12 * (step / 5) + PENTA[step % 5]);
    }

    /** The instrument and note this pad makes right now, or null when it is silent. */
    static int[] resolve(int idx) {
        String s = spec(idx);
        if (s.isEmpty()) {
            s = playMode() ? "auto" : "off";
        }
        if (s.equals("off")) {
            return null;
        }
        if (s.equals("auto")) {
            return new int[] {Math.max(0, Math.min(INST.length - 1, Prefs.getInt(K_INST, 0))), autoNote(idx)};
        }
        try {
            String[] p = s.split(":");
            int inst = Math.max(0, Math.min(INST.length - 1, Integer.parseInt(p[0])));
            int note = Math.max(NOTE_MIN, Math.min(NOTE_MAX + 6, Integer.parseInt(p[1])));
            return new int[] {inst, note};
        } catch (Exception e) {
            return null;
        }
    }

    static boolean has(int idx) {
        return enabled() && resolve(idx) != null;
    }

    /** A short text for the editor: what this pad sounds like. */
    static String describe(int idx) {
        String s = spec(idx);
        if (s.equals("off")) {
            return "no sound";
        }
        int[] r = resolve(idx);
        if (r == null) {
            return "no sound";
        }
        String what = INST[r[0]] + (pitched(r[0]) ? " " + noteName(r[1]) : "");
        return s.isEmpty() || s.equals("auto") ? "auto: " + what : what;
    }

    // ------------------------------------------------------------------ playing

    /** A normal press: plays the pad's sound once. Returns true if it made a sound. */
    static boolean tap(int idx) {
        if (!enabled()) {
            return false;
        }
        int[] r = resolve(idx);
        if (r == null) {
            return false;
        }
        start(r[0], r[1], false);
        return true;
    }

    /** Play mode, finger down: starts the pad's sound (held while the finger stays if the instrument can be held). */
    static Voice down(int idx) {
        if (!enabled()) {
            return null;
        }
        int[] r = resolve(idx);
        return r == null ? null : start(r[0], r[1], holdSustains());
    }

    /** Play mode, finger up. */
    static void up(Voice v) {
        if (v == null || v.dead) {
            return;
        }
        if (!v.looping) {
            return; // it just plays out
        }
        fade(v, 6);
    }

    static void preview(int inst, int note) {
        start(inst, note, false);
    }

    static void stopAll() {
        for (Voice v : new ArrayList<>(LIVE)) {
            kill(v);
        }
    }

    private static Voice start(int inst, int note, boolean hold) {
        Buf b = buf(inst, note);
        try {
            AudioTrack t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(b.pcm.length * 2)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .setTransferMode(AudioTrack.MODE_STATIC).build();
            t.write(b.pcm, 0, b.pcm.length);
            final Voice v = new Voice();
            v.track = t;
            if (hold && b.loops) {
                t.setLoopPoints(b.loopStart, b.loopEnd, -1);
                v.looping = true;
            }
            t.setVolume(Math.max(0f, Math.min(1f, Prefs.getInt(K_VOL, 80) / 100f)));
            while (LIVE.size() >= 10) {
                kill(LIVE.get(0));
            }
            LIVE.add(v);
            t.play();
            if (!v.looping) {
                ui.postDelayed(() -> kill(v), b.ms + 150);
            }
            return v;
        } catch (Exception e) {
            return null; // no sound on this phone right now, the rest of the deck still works
        }
    }

    private static void fade(final Voice v, final int steps) {
        if (v.dead) {
            return;
        }
        if (steps <= 0) {
            kill(v);
            return;
        }
        try {
            float vol = Math.max(0f, Math.min(1f, Prefs.getInt(K_VOL, 80) / 100f));
            v.track.setVolume(vol * (steps - 1) / 6f);
        } catch (Exception ignored) {
            kill(v);
            return;
        }
        ui.postDelayed(() -> fade(v, steps - 1), 20);
    }

    private static void kill(Voice v) {
        if (v.dead) {
            return;
        }
        v.dead = true;
        LIVE.remove(v);
        try {
            v.track.stop();
        } catch (Exception ignored) {
            // already stopped
        }
        try {
            v.track.release();
        } catch (Exception ignored) {
            // already released
        }
    }

    /** Makes the sounds of the 64 pads ready in the background, so the first touch does not have to wait. */
    static void warm() {
        new Thread(() -> {
            try {
                for (int i = 0; i < DeckBinds.SIZE; i++) {
                    int[] r = resolve(i);
                    if (r != null) {
                        buf(r[0], r[1]);
                    }
                }
            } catch (Exception ignored) {
                // they are made when first needed instead
            }
        }, "nova-sound-warm").start();
    }

    // ------------------------------------------------------------------ the sounds

    private static Buf buf(int inst, int note) {
        int key = inst * 1000 + (pitched(inst) ? note : 0);
        Buf b = CACHE.get(key);
        if (b == null) {
            b = render(inst, note);
            CACHE.put(key, b);
        }
        return b;
    }

    private static Buf render(int inst, int note) {
        double f = 440.0 * Math.pow(2.0, (note - 69) / 12.0);
        Buf b = new Buf();
        if (inst < SUSTAINED) {
            int a = (int) (RATE * 0.012);
            int cycles = Math.max(1, (int) Math.round(0.25 * f));
            int sus = (int) Math.round(cycles * RATE / f);
            int rel = (int) (RATE * 0.30);
            int n = a + sus + rel;
            short[] p = new short[n];
            for (int i = 0; i < n; i++) {
                double ph = 2 * Math.PI * f * i / RATE;
                double s;
                switch (inst) {
                    case 1:
                        s = (Math.sin(ph) >= 0 ? 0.34 : -0.34);
                        break;
                    case 2:
                        s = 0.36 * (2.0 * ((f * i / RATE) % 1.0) - 1.0);
                        break;
                    case 3:
                        s = 0.5 * (2.0 / Math.PI) * Math.asin(Math.sin(ph));
                        break;
                    default:
                        s = 0.45 * Math.sin(ph) + 0.12 * Math.sin(2 * ph);
                        break;
                }
                double env = i < a ? i / (double) a : i < a + sus ? 1.0 : Math.max(0.0, 1.0 - (i - a - sus) / (double) rel);
                p[i] = (short) (s * env * 30000);
            }
            b.pcm = p;
            b.loops = true;
            b.loopStart = a;
            b.loopEnd = a + sus;
            b.ms = n * 1000 / RATE;
            return b;
        }
        double secs = inst == 9 ? 0.14 : inst == 7 ? 0.45 : inst == 8 ? 0.30 : inst == 10 ? 0.30 : inst == 11 ? 0.30
                : inst == 4 ? 1.0 : inst == 5 ? 1.2 : 0.7;
        int n = (int) (RATE * secs);
        short[] p = new short[n];
        double hp = 0;
        double lastNoise = 0;
        int ks = Math.max(2, (int) (RATE / f));
        double[] line = new double[ks];
        if (inst == 4) {
            for (int i = 0; i < ks; i++) {
                line[i] = RND.nextDouble() * 2 - 1;
            }
        }
        int pos = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double s;
            switch (inst) {
                case 4: { // pluck: a string that loses its brightness
                    int nx = (pos + 1) % ks;
                    s = line[pos];
                    line[pos] = 0.4985 * (line[pos] + line[nx]);
                    pos = nx;
                    s *= 0.9 * Math.min(1.0, i / 40.0);
                    break;
                }
                case 5: { // bell
                    double mod = 3.0 * Math.exp(-3 * t) * Math.sin(2 * Math.PI * f * 1.41 * t);
                    s = 0.5 * Math.exp(-2.6 * t) * Math.sin(2 * Math.PI * f * t + mod);
                    break;
                }
                case 6: // marimba
                    s = 0.55 * Math.exp(-5 * t) * Math.sin(2 * Math.PI * f * t)
                            + 0.25 * Math.exp(-14 * t) * Math.sin(2 * Math.PI * f * 4 * t);
                    break;
                case 7: { // kick
                    double fr = 45 + 110 * Math.exp(-22 * t);
                    s = 0.9 * Math.exp(-7 * t) * Math.sin(2 * Math.PI * fr * t * 0.5 + 6 * (1 - Math.exp(-22 * t)));
                    break;
                }
                case 8: // snare
                    s = 0.55 * (RND.nextDouble() * 2 - 1) * Math.exp(-16 * t)
                            + 0.4 * Math.exp(-22 * t) * Math.sin(2 * Math.PI * 190 * t);
                    break;
                case 9: { // hi-hat: noise with the low part taken out
                    double x = RND.nextDouble() * 2 - 1;
                    hp = x - lastNoise;
                    lastNoise = x;
                    s = 0.5 * hp * Math.exp(-45 * t);
                    break;
                }
                case 10: { // clap: three quick bursts and a tail
                    double burst = Math.exp(-90 * (t % 0.012)) * (t < 0.036 ? 1 : 0) + Math.exp(-14 * Math.max(0, t - 0.036));
                    s = 0.55 * (RND.nextDouble() * 2 - 1) * burst * (t < 0.036 ? 1 : 0.7);
                    break;
                }
                default: { // zap: a quick slide down
                    double fr = 200 + 1300 * Math.exp(-14 * t);
                    s = 0.5 * Math.exp(-7 * t) * Math.sin(2 * Math.PI * fr * t);
                    break;
                }
            }
            double fadeOut = Math.min(1.0, (n - i) / 200.0);
            p[i] = (short) (Math.max(-1.0, Math.min(1.0, s * fadeOut)) * 30000);
        }
        b.pcm = p;
        b.ms = (int) (secs * 1000);
        return b;
    }
}
