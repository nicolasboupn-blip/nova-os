package app.novaos;

import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/**
 * The water effect on the deck: hit a pad and rings of colour spread out over the other pads, like a stone dropped in
 * water, then fade. It shows on the on-screen deck and on the Launchpad's lights. Every number of it can be set in
 * RippleSettings. Everything here runs on the main thread.
 */
final class DeckRipple {
    private DeckRipple() {}

    static final String K_ON = "deck_ripple";

    // indexes into KEYS, DEFAULTS and V
    static final int STRENGTH = 0, LENGTH = 1, SPEED = 2, WIDTH = 3, RINGS = 4, GAP = 5, FALLOFF = 6, SHAPE = 7,
        DIRECTION = 8, COLOR = 9, HUE = 10, SPREAD = 11, SAT = 12, VAL = 13, FLASH = 14, FLASH_MS = 15, ON_SCREEN = 16,
        ON_PAD = 17, FPS = 18, WAVES = 19, FROM_MOUSE = 20;

    static final String[] KEYS = {"rp_str", "rp_len", "rp_speed", "rp_width", "rp_rings", "rp_gap", "rp_decay",
        "rp_shape", "rp_dir", "rp_color", "rp_hue", "rp_spread", "rp_sat", "rp_val", "rp_flash", "rp_flashms",
        "rp_screen", "rp_pad", "rp_fps", "rp_waves", "rp_mouse"};
    /**
     * Strength % (can go above 100 for fatter rings), length in tenths of a second, speed in pads per second, ring
     * width in tenths of a pad, rings, gap in pads, falloff %, shape, direction, colour style, hue, spread in degrees per
     * pad, saturation %, brightness %, flash on/off, flash ms, on screen, on pad, frames per second, waves, mouse pads.
     */
    static final int[] DEFAULTS = {100, 15, 8, 7, 3, 2, 70, 0, 0, 0, 200, 28, 85, 100, 1, 180, 1, 1, 16, 4, 1};

    static final String[] SHAPES = {"Round", "Diamond", "Square"};
    static final String[] DIRECTIONS = {"Outward", "Inward"};
    static final String[] COLOR_STYLES = {"Changing rainbow", "Fixed rainbow", "One colour", "The pad's own colour",
        "Fire", "Ocean", "White"};

    private static final float[] REACH = {10.5f, 14.5f, 7.5f}; // how far a ring must travel to leave the deck, per shape
    private static final int[] V = DEFAULTS.clone();
    private static boolean loaded;

    private static final class Hit {
        final int idx;
        final long start;
        final float hue;
        final int own;

        Hit(int idx, long start, float hue, int own) {
            this.idx = idx;
            this.start = start;
            this.hue = hue;
            this.own = own;
        }
    }

    private static final List<Hit> HITS = new ArrayList<>();
    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static float nextHue = 190f;
    private static boolean running;

    /** Set by the open deck screen (or the settings preview) so it repaints on every frame. */
    static Runnable screen;

    // ------------------------------------------------------------------ settings

    static int get(int i) {
        return Prefs.getInt(KEYS[i], DEFAULTS[i]);
    }

    static void load() {
        for (int i = 0; i < V.length; i++) {
            V[i] = get(i);
        }
        loaded = true;
    }

    private static int v(int i) {
        if (!loaded) {
            load();
        }
        return V[i];
    }

    static void resetAll() {
        for (int i = 0; i < KEYS.length; i++) {
            Prefs.putInt(KEYS[i], DEFAULTS[i]);
        }
        load();
    }

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    /** True when ripples are switched on and the battery saver is not asking for calm. */
    static boolean active() {
        return enabled() && !Saver.on();
    }

    static boolean screenOn() {
        return v(ON_SCREEN) == 1;
    }

    static boolean padOn() {
        return v(ON_PAD) == 1;
    }

    /** The Launchpad shows the ripple, so the plain white flash on a hit is not needed there. */
    static boolean ledActive() {
        return active() && padOn();
    }

    static boolean busy() {
        return !HITS.isEmpty();
    }

    // ------------------------------------------------------------------ running

    /** A pad was hit: start rings from it. */
    static void hit(int idx) {
        if (!active()) {
            return;
        }
        load();
        if (v(FROM_MOUSE) != 1 && DeckBinds.isMouse(idx)) {
            return;
        }
        nextHue = (nextHue + 67f) % 360f;
        int c = DeckBinds.get(idx).color;
        int own = c == 0 ? 0xFFFFFFFF : (0xFF000000 | (c & 0xFFFFFF));
        HITS.add(new Hit(idx, SystemClock.uptimeMillis(), nextHue, own));
        while (HITS.size() > Math.max(1, v(WAVES))) {
            HITS.remove(0);
        }
        if (!running) {
            running = true;
            ui.post(TICK);
        }
    }

    private static float lengthS() {
        return Math.max(0.2f, v(LENGTH) / 10f);
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.uptimeMillis();
            float len = lengthS();
            for (int i = HITS.size() - 1; i >= 0; i--) {
                if ((now - HITS.get(i).start) / 1000f > len) {
                    HITS.remove(i);
                }
            }
            // when the last ring is gone this frame paints the normal colours again
            Runnable s = screen;
            if (s != null) {
                s.run();
            }
            DeckMidi.rippleFrame();
            if (HITS.isEmpty()) {
                running = false;
                return;
            }
            ui.postDelayed(this, 1000 / Math.max(5, Math.min(30, v(FPS))));
        }
    };

    // ------------------------------------------------------------------ the picture

    private static float gauss(float d, float width) {
        return (float) Math.exp(-(d * d) / (2f * width * width));
    }

    private static int mix(int a, int b, float k) {
        int out = 0;
        for (int shift = 24; shift >= 0; shift -= 8) {
            int ca = (a >>> shift) & 0xFF;
            int cb = (b >>> shift) & 0xFF;
            out |= (Math.round(ca + (cb - ca) * k) & 0xFF) << shift;
        }
        return out;
    }

    private static int hsv(float hue, float sat, float val) {
        float h = ((hue % 360f) + 360f) % 360f;
        return 0xFF000000 | (Color.HSVToColor(new float[] {h, Math.max(0f, Math.min(1f, sat)),
            Math.max(0f, Math.min(1f, val))}) & 0xFFFFFF);
    }

    private static int ringColor(Hit h, int ring, float dist) {
        float sat = v(SAT) / 100f;
        float val = v(VAL) / 100f;
        float spread = v(SPREAD);
        switch (v(COLOR)) {
            case 1:
                return hsv(v(HUE) + ring * 110f + dist * spread, sat, val);
            case 2:
                return hsv(v(HUE), sat, val);
            case 3:
                return h.own;
            case 4: // fire: yellow near the hit, red further out
                return hsv(Math.max(0f, 60f - dist * spread * 0.4f - ring * 14f), sat, val);
            case 5: // ocean: teal to deep blue
                return hsv(170f + ((dist * spread * 0.3f + ring * 20f) % 60f), sat, val);
            case 6:
                return hsv(0f, 0f, val);
            default:
                return hsv(h.hue + ring * 110f + dist * spread, sat, val);
        }
    }

    /**
     * The colour of pad idx (0 to 63, row by row from the top left) right now: its own colour (base, as ARGB) with any
     * ring that is passing over it. The pad that was hit flashes white for a moment instead.
     */
    static int tint(int idx, int base) {
        if (HITS.isEmpty()) {
            return base;
        }
        long now = SystemClock.uptimeMillis();
        float len = lengthS();
        float speed = v(SPEED);
        float width = Math.max(0.2f, v(WIDTH) / 10f);
        int rings = Math.max(1, v(RINGS));
        float gap = Math.max(0.5f, v(GAP));
        float falloff = Math.max(0.05f, v(FALLOFF) / 100f);
        float strength = v(STRENGTH) / 100f;
        int shape = Math.max(0, Math.min(2, v(SHAPE)));
        boolean inward = v(DIRECTION) == 1;
        int out = base;
        int row = idx / DeckBinds.N;
        int col = idx % DeckBinds.N;
        for (Hit h : HITS) {
            float t = (now - h.start) / 1000f;
            if (t > len) {
                continue;
            }
            if (idx == h.idx) {
                if (v(FLASH) == 1 && t < v(FLASH_MS) / 1000f) {
                    out = 0xFFFFFFFF;
                }
                continue;
            }
            float dr = Math.abs(row - h.idx / DeckBinds.N);
            float dc = Math.abs(col - h.idx % DeckBinds.N);
            float dist = shape == 0 ? (float) Math.hypot(dr, dc) : shape == 1 ? dr + dc : Math.max(dr, dc);
            float fade = 1f - t / len;
            float lead = inward ? REACH[shape] - t * speed : t * speed;
            for (int ring = 0; ring < rings; ring++) {
                float r = inward ? lead + ring * gap : lead - ring * gap;
                if (r <= 0f) {
                    continue;
                }
                float k = gauss(dist - r, width) * (float) Math.pow(falloff, ring) * fade * strength;
                if (k < 0.03f) {
                    continue;
                }
                out = mix(out, ringColor(h, ring, dist), Math.min(1f, k));
            }
        }
        return out;
    }
}
