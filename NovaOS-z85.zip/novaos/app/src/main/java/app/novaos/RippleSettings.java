package app.novaos;

import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Every setting of the water effect in one place. The 8 x 8 pads at the top are a live preview: tap any pad to drop a
 * stone there, and move a slider to see the change at once.
 */
final class RippleSettings extends FrameLayout implements BackAware {
    private static final int BASE = 0xFF22203A;

    private final NovaActivity host;
    private final GradientDrawable[] bgs = new GradientDrawable[DeckBinds.SIZE];
    private final LinearLayout controls;
    private final Runnable paintCb = this::paint;

    RippleSettings(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("WATER RIPPLES", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.15f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(chip("TEST", () -> DeckRipple.hit(27)));
        head.addView(chip("RESET", this::confirmReset));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hint = text("tap a pad to drop a stone  ·  move any slider to see it live", 9f, Theme.DIM);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(6);
        hlp.bottomMargin = dp(8);
        col.addView(hint, hlp);

        // the preview grid is a square as wide as the screen allows
        DisplayMetrics dm = host.getResources().getDisplayMetrics();
        int side = Math.min(dm.widthPixels - dp(28), (int) (dm.heightPixels * 0.34f));
        LinearLayout grid = new LinearLayout(host);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < DeckBinds.N; r++) {
            LinearLayout row = new LinearLayout(host);
            for (int c = 0; c < DeckBinds.N; c++) {
                final int idx = r * DeckBinds.N + c;
                View pad = new View(host);
                GradientDrawable g = Theme.rounded(BASE, 5f, host);
                bgs[idx] = g;
                pad.setBackground(g);
                pad.setClickable(true);
                pad.setOnClickListener(v -> DeckRipple.hit(idx));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                p.setMargins(dp(1.5f), dp(1.5f), dp(1.5f), dp(1.5f));
                row.addView(pad, p);
            }
            grid.addView(row, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(side, side);
        glp.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(grid, glp);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        controls = new LinearLayout(host);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(0, dp(6), 0, dp(40));
        sv.addView(controls, new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(8);
        col.addView(sv, slp);

        addView(col, new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        build();
        paint();
    }

    // ------------------------------------------------------------------ the controls

    private void build() {
        controls.removeAllViews();
        controls.addView(switchRow("Water ripples", DeckRipple.K_ON, true, null));
        if (!DeckRipple.enabled()) {
            controls.addView(note("Ripples are off, so the preview stays still. Switch them on above."));
        }
        if (Saver.on()) {
            controls.addView(note("Battery saver is on, so the ripple is paused until it is off."));
        }

        section("SIZE AND TIME");
        controls.addView(slider(DeckRipple.STRENGTH, "Strength", 10, 300, v -> v + " %"));
        controls.addView(slider(DeckRipple.LENGTH, "Length (how long it lasts)", 3, 60, v -> (v / 10f) + " s"));
        controls.addView(slider(DeckRipple.SPEED, "Speed", 2, 30, v -> v + " pads/s"));
        controls.addView(slider(DeckRipple.WIDTH, "Ring thickness", 2, 30, v -> (v / 10f) + " pad"));
        controls.addView(slider(DeckRipple.RINGS, "Rings per hit", 1, 6, v -> String.valueOf(v)));
        controls.addView(slider(DeckRipple.GAP, "Gap between rings", 1, 5, v -> v + " pads"));
        controls.addView(slider(DeckRipple.FALLOFF, "Later rings fade", 10, 100, v -> v + " %"));

        section("SHAPE");
        controls.addView(choiceRow(DeckRipple.SHAPE, "Shape", DeckRipple.SHAPES));
        controls.addView(choiceRow(DeckRipple.DIRECTION, "Direction", DeckRipple.DIRECTIONS));
        controls.addView(slider(DeckRipple.WAVES, "Waves at the same time", 1, 8, v -> String.valueOf(v)));

        section("COLOUR");
        controls.addView(choiceRow(DeckRipple.COLOR, "Colour style", DeckRipple.COLOR_STYLES));
        controls.addView(slider(DeckRipple.HUE, "Start colour (fixed styles)", 0, 359, v -> v + "°"));
        controls.addView(slider(DeckRipple.SPREAD, "Colour change per pad", 0, 90, v -> v + "°"));
        controls.addView(slider(DeckRipple.SAT, "Colour richness", 0, 100, v -> v + " %"));
        controls.addView(slider(DeckRipple.VAL, "Brightness", 10, 100, v -> v + " %"));

        section("THE HIT");
        controls.addView(switchRow("White flash on the pad you hit", DeckRipple.KEYS[DeckRipple.FLASH], false,
                DeckRipple.FLASH));
        controls.addView(slider(DeckRipple.FLASH_MS, "Flash time", 0, 600, v -> v + " ms"));
        controls.addView(switchRow("Also from the mouse pads", DeckRipple.KEYS[DeckRipple.FROM_MOUSE], false,
                DeckRipple.FROM_MOUSE));

        section("WHERE");
        controls.addView(switchRow("On the phone screen", DeckRipple.KEYS[DeckRipple.ON_SCREEN], false,
                DeckRipple.ON_SCREEN));
        controls.addView(switchRow("On the Launchpad lights", DeckRipple.KEYS[DeckRipple.ON_PAD], false,
                DeckRipple.ON_PAD));
        controls.addView(slider(DeckRipple.FPS, "Smoothness (frames per second)", 5, 30, v -> v + " fps"));
        controls.addView(note("A higher smoothness looks better but uses more battery, and the Launchpad may blink if "
                + "the USB cable is slow. 16 is a good middle."));
    }

    private void section(String s) {
        TextView t = text(s, 10f, Theme.ACCENT);
        t.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(20);
        controls.addView(t, p);
    }

    private TextView note(String s) {
        TextView t = text(s, 11f, Theme.DIM);
        t.setTypeface(android.graphics.Typeface.DEFAULT);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private View slider(final int id, String label, int min, int max, final java.util.function.IntFunction<String> fmt) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(2));

        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = text(label, 13f, Theme.TEXT);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        top.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final int cur = Math.max(min, Math.min(max, DeckRipple.get(id)));
        final TextView value = text(fmt.apply(cur), 12f, Theme.ACCENT);
        top.addView(value);
        box.addView(top);

        SeekBar bar = new SeekBar(host);
        bar.setMin(min);
        bar.setMax(max);
        bar.setProgress(cur);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.ACCENT));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                value.setText(fmt.apply(progress));
                if (fromUser) {
                    Prefs.putInt(DeckRipple.KEYS[id], progress);
                    DeckRipple.load();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                DeckRipple.hit(27); // show what the new number looks like
            }
        });
        box.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    /** A row that cycles through named choices on every tap. */
    private View choiceRow(final int id, String label, final String[] names) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        TextView l = text(label, 13f, Theme.TEXT);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView value = text(names[Math.max(0, Math.min(names.length - 1, DeckRipple.get(id)))] + "  ›", 12f,
                Theme.ACCENT);
        value.setClickable(true);
        value.setPadding(dp(10), dp(6), 0, dp(6));
        value.setOnClickListener(v -> {
            int next = (DeckRipple.get(id) + 1) % names.length;
            Prefs.putInt(DeckRipple.KEYS[id], next);
            DeckRipple.load();
            value.setText(names[next] + "  ›");
            DeckRipple.hit(27);
        });
        r.addView(value);
        return r;
    }

    /**
     * An on/off row. With id < 0 it switches a boolean setting named key; otherwise it switches the 0 or 1 number
     * setting id.
     */
    private View switchRow(String label, final String key, final boolean isBool, final Integer id) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        TextView l = text(label, 13f, Theme.TEXT);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Switch s = new android.widget.Switch(host);
        s.setChecked(isBool ? Prefs.getBool(key, true) : DeckRipple.get(id) == 1);
        s.setOnCheckedChangeListener((b, on) -> {
            if (isBool) {
                Prefs.putBool(key, on);
            } else {
                Prefs.putInt(key, on ? 1 : 0);
                DeckRipple.load();
            }
            if (isBool) {
                build();
            }
            DeckRipple.hit(27);
        });
        r.addView(s);
        return r;
    }

    // ------------------------------------------------------------------ the preview

    private void paint() {
        for (int i = 0; i < DeckBinds.SIZE; i++) {
            bgs[i].setColor(DeckRipple.tint(i, BASE));
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        DeckRipple.screen = paintCb;
        DeckRipple.load();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (DeckRipple.screen == paintCb) {
            DeckRipple.screen = null;
        }
        super.onDetachedFromWindow();
    }

    private void confirmReset() {
        new android.app.AlertDialog.Builder(host)
                .setTitle("Reset the ripple?")
                .setMessage("Every ripple setting goes back to how it was at first.")
                .setPositiveButton("Reset", (d, w) -> {
                    DeckRipple.resetAll();
                    build();
                    DeckRipple.hit(27);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    // ------------------------------------------------------------------ small helpers

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.TEXT);
        t.setBackground(Theme.rounded(0x26FFFFFF, 12f, host));
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
