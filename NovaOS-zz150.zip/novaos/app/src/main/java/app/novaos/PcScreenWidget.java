package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.wifi.WifiManager;
import android.text.InputType;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * PC SCREENS: live view of the PC's screens over Wi-Fi. The PC runs the small helper NovaScreens.ps1 (NOVA can type
 * it in and start it over the PC REMOTE Bluetooth link). SCREEN 1 / SCREEN 2 / BOTH switch screens, pinch to zoom,
 * with CLICK on: tap = left click, double tap = double click, hold = right click, right where you touched.
 */
final class PcScreenWidget extends NovaWidget {
    static final String K_IP = "pcs_ip";
    private static final String K_MODE = "pcs_mode";
    private static final String K_Q = "pcs_q";
    private static final String K_CLICK = "pcs_click";
    static final int PORT = 41910;
    private static final int BEACON = 41911;
    private static final String[] QN = {"LOW", "MED", "HIGH"};
    private static final int[] QW = {640, 1024, 1600};
    private static final int[] QQ = {35, 55, 75};
    private static final String START = "K:WIN+R|W:800|T:powershell -NoExit -ExecutionPolicy Bypass -File "
            + "\"%USERPROFILE%\\NovaScreens.ps1\"|K:ENTER";

    /** While the full-screen view is open the small one pauses, so the PC is only asked once. */
    private static volatile boolean bigOpen;

    private final boolean big;
    private final boolean mini;
    private final TextView status;
    private final TextView[] modeChips = new TextView[3];
    private TextView qChip;
    private TextView clickChip;
    private final ScreenView view;
    private volatile boolean running;
    private Thread worker;
    private final Bitmap[] shots = new Bitmap[2];
    private volatile int screens;
    private volatile String[] sizes = new String[0];
    private int fails;
    private final java.util.concurrent.ExecutorService clicker = java.util.concurrent.Executors.newSingleThreadExecutor();

    PcScreenWidget(NovaActivity host) {
        this(host, false, false);
    }

    PcScreenWidget(NovaActivity host, boolean big, boolean mini) {
        super(host);
        this.big = big;
        this.mini = mini;
        status = text("", mini ? 8f : 10f, Theme.DIM);
        status.setSingleLine(true);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setPadding(dp(4), 0, dp(4), dp(2));
        LinearLayout modes = row();
        String[] mn = {"SCREEN 1", "SCREEN 2", "BOTH"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            modeChips[i] = chip(mini ? (i == 2 ? "1+2" : String.valueOf(i + 1)) : mn[i], () -> setMode(k));
            if (mini) {
                modeChips[i].setPadding(dp(5), dp(3), dp(5), dp(3));
                modeChips[i].setTextSize(9f);
            }
            modes.addView(modeChips[i], weight(1f));
        }
        if (mini) {
            LinearLayout top = row();
            top.addView(status, weight(1.4f));
            top.addView(modes, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.6f));
            addView(top, wide());
        } else {
            addView(status, wide());
            if (!big) {
                modes.addView(chip("⤢", this::openBig), new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT));
            }
            addView(modes, wide());
        }
        view = new ScreenView(host);
        if (big || mini) {
            addView(view, fill());
        } else {
            LinearLayout.LayoutParams lp = wide();
            lp.setMargins(0, dp(4), 0, dp(4));
            addView(view, lp);
        }
        if (!mini) {
            LinearLayout tools = row();
            qChip = chip("", () -> {
                Prefs.putInt(K_Q, (Prefs.getInt(K_Q, 1) + 1) % QN.length);
                paint();
            });
            tools.addView(qChip, weight(1f));
            clickChip = chip("", () -> {
                Prefs.putBool(K_CLICK, !Prefs.getBool(K_CLICK, true));
                paint();
                host.toast(Prefs.getBool(K_CLICK, true) ? "CLICK on: tap = click, double tap = double click, hold = right click"
                        : "CLICK off: just watching (double tap zooms)");
            });
            tools.addView(clickChip, weight(1f));
            tools.addView(chip("SETUP", this::setup), weight(1f));
            addView(tools, wide());
        }
        paint();
    }

    // ------------------------------------------------------------------ state

    private void setMode(int m) {
        if (m == 1 && screens == 1) {
            host.toast("The PC says it has only 1 screen right now");
        }
        Prefs.putInt(K_MODE, m);
        view.reset();
        paint();
    }

    private int mode() {
        return Prefs.getInt(K_MODE, 2);
    }

    private void paint() {
        int m = mode();
        for (int i = 0; i < 3; i++) {
            pick(modeChips[i], i == m);
        }
        if (qChip != null) {
            qChip.setText("QUALITY " + QN[Prefs.getInt(K_Q, 1)]);
        }
        if (clickChip != null) {
            boolean c = Prefs.getBool(K_CLICK, true);
            clickChip.setText(c ? "CLICK ON" : "CLICK OFF");
            pick(clickChip, c);
        }
        view.invalidate();
    }

    private void say(final String s) {
        ui.post(() -> status.setText(s));
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            if (running) {
                return;
            }
            running = true;
            if (Prefs.getString(K_IP, "").isEmpty()) {
                say("○ Looking for the PC… (SETUP if it's the first time)");
            }
            worker = new Thread(this::loop, "nova-pcscreen");
            worker.start();
        } else {
            running = false;
            if (worker != null) {
                worker.interrupt();
            }
        }
    }

    // ------------------------------------------------------------------ fetching

    private void loop() {
        long t0 = System.currentTimeMillis();
        long infoAt = t0;
        int frames = 0;
        while (running) {
            if (bigOpen && !big) {
                say("○ Open in full screen");
                nap(400);
                continue;
            }
            String ip = Prefs.getString(K_IP, "");
            if (ip.isEmpty()) {
                String f = listen(2500);
                if (f != null) {
                    Prefs.putString(K_IP, f);
                    say("● Found the PC at " + f);
                }
                continue;
            }
            try {
                if (screens == 0) {
                    String info = new String(get(ip, "/info"), StandardCharsets.US_ASCII).trim();
                    String[] p = info.split(";");
                    if (p.length < 2 || !p[0].equals("NOVASCREEN")) {
                        throw new IOException("not NOVA");
                    }
                    String[] sz = new String[p.length - 2];
                    System.arraycopy(p, 2, sz, 0, sz.length);
                    sizes = sz;
                    screens = Math.max(1, Integer.parseInt(p[1]));
                }
                int m = mode();
                int q = Prefs.getInt(K_Q, 1);
                boolean both = m == 2 && screens > 1;
                int w = both ? QW[q] * 3 / 4 : QW[q];
                for (int slot = 0; slot < (both ? 2 : 1); slot++) {
                    int s = both ? slot : (m == 2 ? 0 : Math.min(m, screens - 1));
                    byte[] b = get(ip, "/shot?s=" + s + "&w=" + w + "&q=" + QQ[q]);
                    final Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length);
                    if (bm == null) {
                        throw new IOException("bad picture");
                    }
                    final int sl = slot;
                    final boolean bb = both;
                    ui.post(() -> {
                        shots[sl] = bm;
                        if (!bb) {
                            shots[1] = null;
                        }
                        view.requestLayout();
                        view.invalidate();
                    });
                }
                fails = 0;
                frames++;
                long now = System.currentTimeMillis();
                if (now - t0 >= 1000) {
                    float fps = frames * 1000f / (now - t0);
                    say(String.format(Locale.US, "● LIVE  %.1f fps  ·  %d screen%s  ·  %s", fps, screens,
                            screens == 1 ? "" : "s", ip));
                    frames = 0;
                    t0 = now;
                    if (now - infoAt > 15000) {
                        screens = 0; // re-check the screens now and then (monitor plugged in or out)
                        infoAt = now;
                    }
                }
            } catch (Exception e) {
                screens = 0;
                fails++;
                say("○ Can't reach the PC at " + ip + (fails > 2 ? "  ·  is NovaScreens running? (SETUP)" : "…"));
                if (fails > 2) {
                    String f = listen(2500);
                    if (f != null && !f.equals(ip)) {
                        Prefs.putString(K_IP, f);
                        fails = 0;
                    }
                } else {
                    nap(600);
                }
            }
        }
    }

    private static void nap(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // stopping
        }
    }

    /** Waits for the PC helper's Wi-Fi beacon and returns its address, or null. */
    private String listen(int ms) {
        WifiManager.MulticastLock lock = null;
        try {
            WifiManager wm = (WifiManager) host.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("nova-pcscreen");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (RuntimeException ignored) {
            // broadcasts may still arrive
        }
        try (DatagramSocket s = new DatagramSocket(null)) {
            s.setReuseAddress(true);
            s.setBroadcast(true);
            s.bind(new InetSocketAddress(BEACON));
            s.setSoTimeout(ms);
            byte[] buf = new byte[64];
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            s.receive(p);
            String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.US_ASCII);
            if (msg.startsWith("NOVASCREEN") && p.getAddress() != null) {
                return p.getAddress().getHostAddress();
            }
        } catch (IOException ignored) {
            // nothing heard
        } finally {
            if (lock != null) {
                try {
                    lock.release();
                } catch (RuntimeException ignored) {
                    // already gone
                }
            }
        }
        return null;
    }

    /** A tiny HTTP/1.0 GET over a raw socket (Android blocks plain-HTTP URLs by default). */
    static byte[] get(String ip, String path) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(ip, PORT), 2000);
            s.setSoTimeout(5000);
            s.setTcpNoDelay(true);
            OutputStream o = s.getOutputStream();
            o.write(("GET " + path + " HTTP/1.0\r\nHost: " + ip + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
            o.flush();
            InputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            String first = line(in);
            if (first == null || !first.contains(" 200")) {
                throw new IOException("bad answer");
            }
            int len = -1;
            String h;
            while ((h = line(in)) != null && !h.isEmpty()) {
                if (h.toLowerCase(Locale.ROOT).startsWith("content-length:")) {
                    len = Integer.parseInt(h.substring(15).trim());
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream(len > 0 ? len : 65536);
            byte[] buf = new byte[32768];
            int n;
            while ((len < 0 || out.size() < len) && (n = in.read(buf, 0, len < 0 ? buf.length
                    : Math.min(buf.length, len - out.size()))) > 0) {
                out.write(buf, 0, n);
            }
            if (len >= 0 && out.size() < len) {
                throw new IOException("cut off");
            }
            return out.toByteArray();
        }
    }

    private static String line(InputStream in) throws IOException {
        StringBuilder b = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') {
                break;
            }
            if (c != '\r') {
                b.append((char) c);
            }
            if (b.length() > 4000) {
                break;
            }
        }
        return c < 0 && b.length() == 0 ? null : b.toString();
    }

    private void click(int screen, float rx, float ry, final String button) {
        final String ip = Prefs.getString(K_IP, "");
        if (ip.isEmpty()) {
            return;
        }
        host.buzz(button.equals("R") ? 25 : 10);
        final String path = String.format(Locale.US, "/click?s=%d&x=%.4f&y=%.4f&b=%s", screen,
                Math.max(0f, Math.min(0.9999f, rx)), Math.max(0f, Math.min(0.9999f, ry)), button);
        clicker.execute(() -> {
            try {
                get(ip, path);
            } catch (Exception e) {
                ui.post(() -> host.toast("Click didn't reach the PC"));
            }
        });
    }

    // ------------------------------------------------------------------ setup

    private void setup() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setPadding(dp(18), dp(8), dp(18), dp(4));
        TextView t = text("NOVA shows the PC's screens over Wi-Fi with a small helper script on the PC.\n\n"
                + "1. Connect the phone to the PC over Bluetooth (PC REMOTE > CONNECT).\n"
                + "2. TYPE THE HELPER: NOVA opens Notepad and types it in, then saves it as NovaScreens.ps1 in your user "
                + "folder (about 2 minutes, don't touch the PC).\n"
                + "3. START ON PC: opens it in a PowerShell window. Leave that window open. If Windows asks, allow it "
                + "(private and public networks).\n"
                + "4. Phone and PC on the same Wi-Fi. NOVA finds the PC by itself.\n\n"
                + "Next time only step 3 is needed.", 11f, Theme.TEXT);
        t.setGravity(Gravity.START);
        v.addView(t, wide());
        final AlertDialog[] dlg = new AlertDialog[1];
        v.addView(chip("⌨ TYPE THE HELPER ON THE PC", () -> {
            if (!PcHid.connected()) {
                host.toast("Connect the phone to the PC first (PC REMOTE > CONNECT)");
                return;
            }
            host.toast("Typing NovaScreens.ps1 into Notepad (don't touch the PC)");
            PcHid.run("K:WIN+R|W:800|T:notepad %USERPROFILE%\\NovaScreens.ps1|K:ENTER|W:2500|K:ENTER|W:1500|K:CTRL+A|K:DEL");
            PcHid.type(script(host));
            PcHid.run("W:600|K:CTRL+S|W:1000");
            dlg[0].dismiss();
        }), wide());
        v.addView(chip("▶ START ON PC", () -> {
            if (!PcHid.connected()) {
                host.toast("Connect the phone to the PC first (PC REMOTE > CONNECT)");
                return;
            }
            PcHid.run(START);
            host.toast("Starting NovaScreens on the PC…");
            dlg[0].dismiss();
        }), wide());
        v.addView(chip("↪ SHARE THE SCRIPT", () -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "NovaScreens.ps1");
            i.putExtra(Intent.EXTRA_TEXT, script(host));
            host.startActivity(Intent.createChooser(i, "Send NovaScreens.ps1 to your PC"));
        }), wide());
        v.addView(chip("✎ PC ADDRESS: " + (Prefs.getString(K_IP, "").isEmpty() ? "auto" : Prefs.getString(K_IP, "")), () -> {
            dlg[0].dismiss();
            final EditText e = new EditText(host);
            e.setInputType(InputType.TYPE_CLASS_PHONE);
            e.setText(Prefs.getString(K_IP, ""));
            e.setHint("192.168.1.20 (empty = find it)");
            new AlertDialog.Builder(host).setTitle("PC address").setMessage("The NovaScreens window on the PC shows it.")
                    .setView(e).setPositiveButton("OK", (d, w) -> {
                        Prefs.putString(K_IP, e.getText().toString().trim());
                        screens = 0;
                        fails = 0;
                    }).setNegativeButton("FIND IT", (d, w) -> {
                        Prefs.putString(K_IP, "");
                        screens = 0;
                        say("○ Looking for the PC…");
                    }).show();
        }), wide());
        dlg[0] = new AlertDialog.Builder(host).setTitle("PC SCREENS setup").setView(v)
                .setPositiveButton("CLOSE", null).show();
    }

    static String script(Context c) {
        try (InputStream in = c.getAssets().open("NovaScreens.ps1")) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) {
                o.write(b, 0, n);
            }
            return o.toString("UTF-8").replace("\r", "");
        } catch (Exception e) {
            return "";
        }
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(8), dp(40), dp(8), dp(12));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("PC SCREENS", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", () -> {
            bigOpen = false;
            host.hideOverlay();
            paint();
        }));
        v.addView(head, wide());
        v.addView(new PcScreenWidget(host, true, false), new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        bigOpen = true;
        host.showOverlay(v);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (big) {
            bigOpen = false;
        }
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ the picture

    private final class ScreenView extends View {
        private final Paint img = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF[] slot = {new RectF(), new RectF()};
        private final int[] slotScreen = {0, 1};
        private int slots;
        private float zoom = 1f;
        private float tx;
        private float ty;
        private final ScaleGestureDetector sg;
        private final GestureDetector gd;

        ScreenView(Context c) {
            super(c);
            sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector d) {
                    zoomBy(d.getScaleFactor(), d.getFocusX(), d.getFocusY());
                    return true;
                }
            });
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    return hit(e, "L");
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    if (Prefs.getBool(K_CLICK, true)) {
                        return hit(e, "D");
                    }
                    zoomBy(zoom > 1.2f ? 1f / zoom : 2.5f / zoom, e.getX(), e.getY());
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    if (!sg.isInProgress()) {
                        hit(e, "R");
                    }
                }

                @Override
                public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                    if (zoom <= 1.01f) {
                        return false;
                    }
                    tx -= dx;
                    ty -= dy;
                    clamp();
                    invalidate();
                    return true;
                }
            });
        }

        void reset() {
            zoom = 1f;
            tx = 0;
            ty = 0;
            requestLayout();
            invalidate();
        }

        private void zoomBy(float f, float fx, float fy) {
            float nz = Math.max(1f, Math.min(6f, zoom * f));
            f = nz / zoom;
            tx = fx - (fx - tx) * f;
            ty = fy - (fy - ty) * f;
            zoom = nz;
            clamp();
            invalidate();
        }

        private void clamp() {
            float w = getWidth();
            float h = getHeight();
            tx = Math.max(w - w * zoom, Math.min(0f, tx));
            ty = Math.max(h - h * zoom, Math.min(0f, ty));
        }

        private boolean hit(MotionEvent e, String button) {
            if (!Prefs.getBool(K_CLICK, true)) {
                return false;
            }
            float cx = (e.getX() - tx) / zoom;
            float cy = (e.getY() - ty) / zoom;
            for (int i = 0; i < slots; i++) {
                RectF r = slot[i];
                if (r.contains(cx, cy) && shots[i] != null) {
                    click(slotScreen[i], (cx - r.left) / r.width(), (cy - r.top) / r.height(), button);
                    return true;
                }
            }
            return false;
        }

        private float aspect(int i) {
            Bitmap b = shots[i];
            if (b != null && b.getWidth() > 0) {
                return b.getHeight() / (float) b.getWidth();
            }
            String[] sz = sizes;
            int s = i;
            if (shots[1] == null && mode() != 2) {
                s = Math.min(mode(), Math.max(0, screens - 1));
            }
            if (s < sz.length) {
                String[] wh = sz[s].split("x");
                try {
                    return Integer.parseInt(wh[1]) / (float) Integer.parseInt(wh[0]);
                } catch (RuntimeException ignored) {
                    // default
                }
            }
            return 0.5625f;
        }

        private int count() {
            return shots[1] != null ? 2 : 1;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            if (big || mini || MeasureSpec.getMode(hSpec) == MeasureSpec.EXACTLY) {
                super.onMeasure(wSpec, hSpec);
                return;
            }
            float h = 0;
            for (int i = 0; i < count(); i++) {
                h += w * aspect(i);
            }
            h += (count() - 1) * dp(6);
            setMeasuredDimension(w, Math.max(dp(120), (int) h));
        }

        private void layoutSlots() {
            float w = getWidth();
            float h = getHeight();
            int n = count();
            float gap = dp(6);
            boolean side = w > h * 1.6f && n == 2;
            float total = 0;
            for (int i = 0; i < n; i++) {
                total += side ? 1f / aspect(i) : aspect(i);
            }
            float sc;
            if (side) {
                // side by side: widths in units of height
                sc = Math.min((w - gap) / total, h);
                float x = (w - (sc * total + gap)) / 2f;
                for (int i = 0; i < n; i++) {
                    float sw = sc / aspect(i);
                    slot[i].set(x, (h - sc) / 2f, x + sw, (h + sc) / 2f);
                    x += sw + gap;
                }
            } else {
                sc = Math.min(w, (h - gap * (n - 1)) / total);
                float y = (h - (sc * total + gap * (n - 1))) / 2f;
                for (int i = 0; i < n; i++) {
                    float sh = sc * aspect(i);
                    slot[i].set((w - sc) / 2f, y, (w + sc) / 2f, y + sh);
                    y += sh + gap;
                }
            }
            slots = n;
            int m = mode();
            if (n == 2) {
                slotScreen[0] = 0;
                slotScreen[1] = 1;
            } else {
                slotScreen[0] = m == 2 ? 0 : Math.min(m, Math.max(0, screens - 1));
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            layoutSlots();
            c.save();
            c.translate(tx, ty);
            c.scale(zoom, zoom);
            p.setTextAlign(Paint.Align.CENTER);
            for (int i = 0; i < slots; i++) {
                RectF r = slot[i];
                Bitmap b = shots[i];
                if (b != null) {
                    c.drawBitmap(b, null, r, img);
                } else {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0x14FFFFFF);
                    c.drawRoundRect(r, dp(8), dp(8), p);
                    p.setColor(Theme.DIM);
                    p.setTextSize(dp(12));
                    c.drawText("waiting for the PC…", r.centerX(), r.centerY(), p);
                }
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                p.setColor(0x55FFFFFF);
                c.drawRect(r, p);
            }
            c.restore();
            // screen number tags
            p.setStyle(Paint.Style.FILL);
            p.setTextSize(dp(10));
            for (int i = 0; i < slots; i++) {
                RectF r = slot[i];
                float x = tx + r.left * zoom + dp(4);
                float y = ty + r.top * zoom + dp(4);
                if (x < 0 || y < 0) {
                    continue;
                }
                p.setColor(0xAA000000);
                c.drawRoundRect(x, y, x + dp(20), y + dp(16), dp(4), dp(4), p);
                p.setColor(Theme.ACCENT);
                c.drawText(String.valueOf(slotScreen[i] + 1), x + dp(10), y + dp(12), p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getPointerCount() > 1 || zoom > 1.01f) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            sg.onTouchEvent(e);
            gd.onTouchEvent(e);
            return true;
        }
    }
}
