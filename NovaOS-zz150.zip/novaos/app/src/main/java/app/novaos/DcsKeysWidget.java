package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * DCS KEYS: the default keyboard commands for the F/A-18C Hornet, the Su-27 Flanker and the Su-25T Frogfoot, each
 * with a short explanation, in three tabs. Tap a line to press that key on the PC (when PC REMOTE / KEY DECK is
 * connected), hold it to put it on your KEY DECK. Key names are DCS's (US key positions).
 *
 * Sources: DCS F/A-18C Early Access Guide, DCS Su-27 / Flaming Cliffs 3 flight manuals, Su-25T key list and flight
 * manual. Full-fidelity modules like the Hornet are mostly flown with clickable switches.
 */
final class DcsKeysWidget extends NovaWidget {
    private static final String K_TAB = "dcs_tab";
    private static final String[] TABS = {"F/A-18C", "Su-27", "Su-25T"};

    /** "#Group" or "KEYS|Action|What it does". KEYS like LCTRL+E, x3:LCTRL+E, LALT+LSHIFT+V, KP5, SEMICOLON. */
    private static final String[][] LISTS = {
        {
            "#Start-up",
            "LWIN+HOME|Auto start|DCS starts the engines and systems for you",
            "LWIN+END|Stop auto start|Cancels the automatic start-up",
            "RALT+HOME|Left throttle OFF → IDLE|Moves the left throttle to idle during engine start",
            "LSHIFT+HOME|Right throttle OFF → IDLE|Moves the right throttle to idle during engine start",
            "LCTRL+C|Canopy|Opens or closes the canopy",
            "LALT+C|Mouse in cockpit|Switches the mouse between clicking switches and looking around",
            "#Taxi, take-off, landing",
            "PGUP|Throttle up (taxi)|More power on the ground",
            "PGDN|Throttle down (taxi)|Less power on the ground",
            "Z|Steer left|Nose wheel / rudder left",
            "X|Steer right|Nose wheel / rudder right",
            "W|Wheel brakes|Hold to brake",
            "G|Landing gear|Gear up or down",
            "LSHIFT+F|Flaps HALF|Half flaps for take-off and landing",
            "LCTRL+F|Flaps FULL|Full flaps for landing",
            "LCTRL+H|Arresting hook|Lowers or raises the tail hook for the carrier",
            "#Flight",
            "KPPLUS|Throttle up|More power in flight",
            "KPMINUS|Throttle down|Less power in flight",
            "UP|Pitch down|Keyboard flying: nose down",
            "DOWN|Pitch up|Keyboard flying: nose up",
            "LEFT|Roll left|Keyboard flying",
            "RIGHT|Roll right|Keyboard flying",
            "RCTRL+ENTER|Controls indicator|Shows where your stick, rudder and throttle are",
            "Y|FCS BIT switch|Flight control self-test switch (start-up check)",
            "#Instruments",
            "LALT+LSHIFT+V|SARI cage / pitch up|Standby attitude indicator",
            "LALT+LSHIFT+X|SARI pitch down|Standby attitude indicator",
            "LALT+LSHIFT+S|Standby altimeter +|Sets the standby altimeter pressure up",
            "LALT+LSHIFT+A|Standby altimeter −|Sets the standby altimeter pressure down",
            "LALT+LSHIFT+2|Heading +|Moves the heading bug on the MPCD",
            "LALT+LSHIFT+1|Heading −|Moves the heading bug on the MPCD",
            "LALT+LSHIFT+4|Course +|Sets the navigation course on the MPCD",
            "LALT+LSHIFT+3|Course −|Sets the navigation course on the MPCD",
            "#Emergency & views",
            "x3:LCTRL+E|Eject|Press 3 times quickly to eject",
            "KP8|Look up|View",
            "KP2|Look down|View",
            "KP4|Look left|View",
            "KP6|Look right|View",
            "KPSTAR|Zoom in|View",
            "KPSLASH|Zoom out|View",
            "F1|Cockpit view|Back inside the jet",
            "F2|Outside view|Look at your aircraft",
            "F10|Map|The mission map",
        },
        {
            "#Modes",
            "1|Navigation|Cycles ROUTE, RETURN, LANDING and no task",
            "2|BVR (SCAN)|Long-range air-to-air radar search",
            "3|Vertical scan|Dogfight mode: radar scans a vertical strip",
            "4|BORE|Dogfight mode: locks what is straight ahead",
            "5|Helmet sight|Dogfight mode: lock by looking at the target",
            "6|Fi0|Backup aiming for IR missiles only",
            "7|Air-to-ground|Ground attack mode",
            "8|Fixed reticle|Shows the fixed gun cross",
            "LCTRL+GRAVE|Next waypoint / airfield|Cycles route points (ROUTE) or airfields (LANDING)",
            "#Radar & sensors",
            "I|Radar on/off|Also turns on the datalink",
            "RALT+I|TWS|Switches SCAN to track-while-scan",
            "RSHIFT+I|Target aspect|Expected target aspect (PRF)",
            "EQUAL|Range scale +|Radar range out",
            "MINUS|Range scale −|Radar range in",
            "RCTRL+EQUAL|Target range +|Expected target range",
            "RCTRL+MINUS|Target range −|Expected target range (also gives launch OK)",
            "RSHIFT+SEMICOLON|Target altitude +|Expected relative altitude",
            "RSHIFT+DOT|Target altitude −|Expected relative altitude",
            "SEMICOLON|Cursor up|Moves the radar / target cursor",
            "DOT|Cursor down|Moves the radar / target cursor",
            "COMMA|Cursor left|Moves the radar / target cursor",
            "SLASH|Cursor right|Moves the radar / target cursor",
            "ENTER|Lock target|Locks what is under the cursor (also jammers, AOJ)",
            "RALT+F5|Auto-lock nearest|Locks the closest aircraft",
            "RALT+F6|Auto-lock center|Locks the aircraft in the middle",
            "RALT+F7|Auto-lock next|Next aircraft",
            "RALT+F8|Auto-lock previous|Previous aircraft",
            "RSHIFT+R|RWR filter|Hides search radars on the warning receiver",
            "RALT+COMMA|RWR volume −|Quieter warnings",
            "RALT+DOT|RWR volume +|Louder warnings",
            "#Weapons",
            "D|Select missile|Radar missiles need the radar on",
            "C|Select cannon|Gun mode",
            "SPACE|Fire gun|Shoots the cannon",
            "RALT+MINUS|Gun funnel −|Target size for the gun funnel",
            "RALT+EQUAL|Gun funnel +|Target size for the gun funnel",
            "LALT+W|Launch override|Allows a launch without full authorisation",
            "KPDOT|Padlock|Locks your view on a target (use before helmet mode)",
            "INS|Chaff|Drops chaff against radar missiles (FC3 standard)",
            "DEL|Flare|Drops flares against IR missiles (FC3 standard)",
            "#Flight & autopilot",
            "S|Direct control|Turns the fly-by-wire helper off or on",
            "RCTRL+DOT|Trim nose down|Pitch trim",
            "RCTRL+SEMICOLON|Trim nose up|Pitch trim",
            "RCTRL+COMMA|Trim roll left|Roll trim",
            "RCTRL+SLASH|Trim roll right|Roll trim",
            "RCTRL+Z|Trim rudder left|Rudder trim",
            "RCTRL+X|Trim rudder right|Rudder trim",
            "LCTRL+T|Trim neutral|Resets all trim",
            "A|Route + altitude hold|Autopilot flies the route",
            "H|Altitude hold|Holds barometric altitude",
            "LALT+1|Attitude hold|Holds pitch and bank",
            "LALT+2|Baro altitude hold|Holds barometric altitude",
            "LALT+3|Level to horizon|Emergency wings-level",
            "LALT+5|Radar altitude hold|Holds height above the ground",
            "LALT+6|Route following|Follows the waypoints",
            "LALT+9|Autopilot off|Resets the automatic control",
            "#General (FC3 standard)",
            "G|Landing gear|Gear up or down",
            "F|Flaps|Flaps up or down",
            "B|Airbrake|Speed brake",
            "W|Wheel brakes|Hold to brake",
            "LCTRL+C|Canopy|Opens or closes the canopy",
            "x3:LCTRL+E|Eject|Press 3 times quickly",
        },
        {
            "#Start-up",
            "RSHIFT+L|APU|Starts the auxiliary power unit",
            "L|Cockpit lights|Instrument lights on/off",
            "LCTRL+C|Canopy|Opens or closes the canopy",
            "RALT+HOME|Start engine 1|Left engine",
            "RCTRL+HOME|Start engine 2|Right engine",
            "RCTRL+L|Navigation lights|Cycles the nav lights",
            "W|Wheel brakes|Hold to brake",
            "#Take-off & landing",
            "1|Navigation mode|Route / return / landing",
            "F|Flaps|Flaps up or down",
            "G|Landing gear|Gear up or down",
            "LCTRL+GRAVE|Next waypoint / airfield|Cycles route points or airfields",
            "#Weapons & sensors",
            "7|Air-to-ground mode|Ground attack",
            "D|Cycle weapon stations|Picks the next weapon",
            "C|Select cannon|Gun",
            "SPACE|Fire weapon|Launches or fires the selected weapon",
            "LCTRL+V|Salvo mode|Fires pairs",
            "V|Ripple interval|Time between bombs or rockets",
            "LCTRL+SPACE|Ripple quantity|How many go in one ripple",
            "O|Shkval cage/uncage|TV targeting camera",
            "SEMICOLON|Shkval up|Moves the camera",
            "DOT|Shkval down|Moves the camera",
            "COMMA|Shkval left|Moves the camera",
            "SLASH|Shkval right|Moves the camera",
            "ENTER|Lock target|Locks what the Shkval sees",
            "RCTRL+O|Mercury LLTV|Night TV pod",
            "I|Fantasmagoria|Anti-radar pod (for Kh-58 / Kh-25MPU)",
            "LCTRL+W|Jettison weapons|Drops all weapons",
            "LALT+R|Jettison fuel tanks|Drops external tanks",
            "#Defence",
            "LSHIFT+E|IR jammer|Rear-hemisphere IR jammer",
            "INS|Chaff|Against radar missiles",
            "DEL|Flare|Against IR missiles",
            "#Autopilot & trim",
            "GRAVE|Autopilot override|Hold to fly by hand for a moment",
            "LALT+1|Attitude hold|Holds pitch and bank",
            "LALT+2|Altitude + roll hold|Holds altitude and bank",
            "LALT+3|Level flight|Wings level",
            "LALT+4|Baro altitude hold|Holds barometric altitude",
            "LALT+5|Radar altitude hold|Holds height above the ground",
            "LALT+9|Autopilot off|Disengages",
            "A|Autopilot in nav mode|Flies the selected navigation mode",
            "RCTRL+DOT|Trim nose up|Pitch trim",
            "RCTRL+SEMICOLON|Trim nose down|Pitch trim",
            "RCTRL+COMMA|Trim roll left|Roll trim",
            "RCTRL+SLASH|Trim roll right|Roll trim",
            "#Emergency",
            "x3:LCTRL+E|Eject|Press 3 times quickly",
        },
    };

    private final List<TextView> tabs = new ArrayList<>();
    private final LinearLayout list;

    DcsKeysWidget(NovaActivity host) {
        super(host);
        LinearLayout r = row();
        for (int i = 0; i < TABS.length; i++) {
            final int t = i;
            TextView c = chip(TABS[i], () -> show(t));
            c.setTextSize(12f);
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), 0, dp(2), dp(4));
            r.addView(c, p);
            tabs.add(c);
        }
        addView(r, wide());
        TextView hint = text("Tap a line to press it on the PC · hold to add it to KEY DECK · keys are DCS's names "
                + "(US positions: DCS's Z is your Y, ; is ö)", 9f, Theme.DIM);
        hint.setPadding(dp(4), 0, dp(4), dp(4));
        addView(hint, wide());
        list = new LinearLayout(host);
        list.setOrientation(VERTICAL);
        addView(list, wide());
        show(Math.max(0, Math.min(2, Prefs.getInt(K_TAB, 0))));
    }

    @Override
    void onLive(boolean on) {
        if (on && PcHid.hid == null && android.os.Build.VERSION.SDK_INT >= 28
                && (android.os.Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            PcHid.start(host);
        }
    }

    private void show(int t) {
        Prefs.putInt(K_TAB, t);
        for (int i = 0; i < tabs.size(); i++) {
            pick(tabs.get(i), i == t);
        }
        list.removeAllViews();
        for (String e : LISTS[t]) {
            if (e.startsWith("#")) {
                TextView h = text(e.substring(1).toUpperCase(Locale.ROOT), 10f, Theme.ACCENT);
                h.setGravity(Gravity.START);
                h.setLetterSpacing(0.15f);
                h.setPadding(dp(4), dp(10), 0, dp(4));
                list.addView(h, wide());
                continue;
            }
            final String[] f = e.split("\\|");
            LinearLayout line = row();
            line.setGravity(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(4), dp(6), dp(4), dp(6));
            line.setBackground(Theme.rounded(0x10FFFFFF, 10f, host));
            TextView k = text(pretty(f[0]), 10f, Theme.ACCENT);
            k.setGravity(Gravity.CENTER);
            k.setBackground(Theme.rounded(0x22FFFFFF, 8f, host));
            k.setPadding(dp(6), dp(4), dp(6), dp(4));
            k.setMinWidth(dp(84));
            line.addView(k);
            TextView d = text(f[1] + "\n" + f[2], 11f, Theme.TEXT);
            d.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            d.setPadding(dp(10), 0, 0, 0);
            line.addView(d, weight(1f));
            line.setClickable(true);
            Theme.ripple(line);
            line.setOnClickListener(v -> press(f[0]));
            line.setOnLongClickListener(v -> {
                addToDeck(f);
                return true;
            });
            LinearLayout.LayoutParams p = wide();
            p.setMargins(0, dp(2), 0, dp(2));
            list.addView(line, p);
        }
    }

    /** "x3:LCTRL+E" -> {mods, key name, times}. */
    static Object[] parse(String spec) {
        int times = 1;
        if (spec.startsWith("x") && spec.indexOf(':') > 0) {
            times = Integer.parseInt(spec.substring(1, spec.indexOf(':')));
            spec = spec.substring(spec.indexOf(':') + 1);
        }
        int mods = 0;
        String key = "";
        for (String p : spec.split("\\+")) {
            switch (p) {
                case "LCTRL":
                    mods |= PcHid.CTRL;
                    break;
                case "LSHIFT":
                    mods |= PcHid.SHIFT;
                    break;
                case "LALT":
                    mods |= PcHid.ALT;
                    break;
                case "LWIN":
                    mods |= PcHid.WIN;
                    break;
                case "RCTRL":
                    mods |= PcHid.RCTRL;
                    break;
                case "RSHIFT":
                    mods |= PcHid.RSHIFT;
                    break;
                case "RALT":
                    mods |= PcHid.RALT;
                    break;
                default:
                    key = p;
                    break;
            }
        }
        return new Object[] {mods, key, times};
    }

    static String pretty(String spec) {
        String s = spec;
        String times = "";
        if (s.startsWith("x") && s.indexOf(':') > 0) {
            times = " ×" + s.substring(1, s.indexOf(':'));
            s = s.substring(s.indexOf(':') + 1);
        }
        s = s.replace("LCTRL", "LCtrl").replace("RCTRL", "RCtrl").replace("LSHIFT", "LShift").replace("RSHIFT", "RShift")
                .replace("LALT", "LAlt").replace("RALT", "RAlt").replace("LWIN", "LWin").replace("SEMICOLON", ";")
                .replace("COMMA", ",").replace("SLASH", "/").replace("DOT", ".").replace("GRAVE", "~").replace("EQUAL", "=")
                .replace("MINUS", "−").replace("KPPLUS", "Num+").replace("KP−", "Num−").replace("KPSTAR", "Num*")
                .replace("KP/", "Num/").replace("KP.", "Num Del").replace("PGUP", "PgUp").replace("PGDN", "PgDn")
                .replace("INS", "Insert").replace("DEL", "Delete").replace("SPACE", "Space").replace("ENTER", "Enter")
                .replace("HOME", "Home").replace("END", "End").replace("KP", "Num").replace("+", " + ");
        return s + times;
    }

    private void press(String spec) {
        if (!PcHid.connected()) {
            host.toast("Connect in PC REMOTE or KEY DECK to press keys on the PC");
            return;
        }
        Object[] k = parse(spec);
        host.buzz(10);
        PcHid.tap((int) k[0], PcHid.rawCode((String) k[1]), (int) k[2], 40);
    }

    private void addToDeck(final String[] f) {
        new AlertDialog.Builder(host).setTitle("Add “" + f[1] + "” to KEY DECK?")
                .setMessage(pretty(f[0]) + " goes on a new square in the KEY DECK profile you use now.")
                .setPositiveButton("ADD", (d, w) -> {
                    Object[] k = parse(f[0]);
                    KeyDeckWidget.addToDeck(f[1].toUpperCase(Locale.ROOT), (String) k[1], (int) k[0], (int) k[2]);
                    host.toast("Added to KEY DECK");
                })
                .setNegativeButton("CANCEL", null).show();
    }
}
