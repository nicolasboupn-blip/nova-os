package app.novaos;

import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * KEY DECK: a Launchpad on the phone. A big grid of squares, 4 per row, that you scroll. Every square has a name, a
 * colour and a key (with Ctrl / Shift / Alt / Win, left or right), and works as TAP, HOLD (down while your finger is
 * on it, for wheel brakes and push-to-talk) or TOGGLE (stays down until you tap again). It sends the key to the PC over
 * NOVA's Bluetooth keyboard, so games like DCS see a real key press. Several profiles; DCS comes ready.
 */
final class KeyDeckWidget extends NovaWidget {
    private static final String K_PROFILE = "deck_profile";
    private static final String K_NAMES = "deck_names";
    private static final String[] MODES = {"TAP", "HOLD", "TOGGLE"};
    private static final int[] COLORS = {0xFF2C2C2E, 0xFFFF453A, 0xFFFF9F0A, 0xFFFFD60A, 0xFF30D158, 0xFF0A84FF, 0xFF5E5CE6,
        0xFFBF5AF2, 0xFFFF375F, 0xFF64D2FF};
    private static final String[][] MOD_NAMES = {{"L-Ctrl", "1"}, {"L-Shift", "2"}, {"L-Alt", "4"}, {"Win", "8"},
        {"R-Ctrl", "16"}, {"R-Shift", "32"}, {"R-Alt", "64"}};

    /** One square: name, key name, modifier bits, mode, colour index, presses. */
    static final class Sq {
        String name = "NEW";
        String key = "G";
        int mods;
        int mode;
        int color = 5;
        int times = 1;

        String line() {
            return name.replace("\t", " ").replace("\n", " ") + "\t" + key + "\t" + mods + "\t" + mode + "\t" + color + "\t"
                    + times;
        }

        static Sq parse(String l) {
            String[] f = l.split("\t");
            if (f.length < 6) {
                return null;
            }
            Sq q = new Sq();
            try {
                q.name = f[0];
                q.key = f[1];
                q.mods = Integer.parseInt(f[2]);
                q.mode = Integer.parseInt(f[3]);
                q.color = Integer.parseInt(f[4]);
                q.times = Integer.parseInt(f[5]);
            } catch (NumberFormatException e) {
                return null;
            }
            return q;
        }

        String keyLabel() {
            StringBuilder b = new StringBuilder();
            for (String[] m : MOD_NAMES) {
                if ((mods & Integer.parseInt(m[1])) != 0) {
                    b.append(m[0]).append('+');
                }
            }
            b.append(key.startsWith("(") ? "" : key);
            if (times > 1) {
                b.append(" ×").append(times);
            }
            return b.toString();
        }

        int code() {
            // games read keys by position (DCS shows US key names), so no Y/Z swap here
            return key.startsWith("(") ? 0 : PcHid.rawCode(key);
        }
    }

    private final boolean big;
    private final TextView status;
    private final TextView connect;
    private final TextView profile;
    private final TextView editChip;
    private final LinearLayout grid;
    private boolean editing;
    private List<Sq> squares = new ArrayList<>();
    private final List<Sq> toggled = new ArrayList<>();

    KeyDeckWidget(NovaActivity host) {
        this(host, false);
    }

    KeyDeckWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setSingleLine(true);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        connect = chip("CONNECT", () -> PcConnect.connect(host));
        top.addView(connect);
        profile = chip("", this::profiles);
        top.addView(profile, margin());
        editChip = chip("✎ EDIT", () -> {
            editing = !editing;
            build();
        });
        top.addView(editChip, margin());
        if (!big) {
            top.addView(chip("⤢", this::openBig), margin());
        }
        addView(top, wide());
        grid = new LinearLayout(host);
        grid.setOrientation(VERTICAL);
        LinearLayout.LayoutParams gp = wide();
        gp.setMargins(0, dp(6), 0, 0);
        addView(grid, gp);
        load();
        build();
    }

    private LinearLayout.LayoutParams margin() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        return lp;
    }

    @Override
    void refresh() {
        status.setText(PcHid.connected() ? "● " + PcHid.state : PcHid.state);
        status.setTextColor(PcHid.connected() ? 0xFF34C759 : Theme.DIM);
        connect.setText(PcHid.connected() ? "✔" : "CONNECT");
        pick(connect, PcHid.connected());
        profile.setText(names().get(current()) + " ▾");
        editChip.setText(editing ? "✔ DONE" : "✎ EDIT");
        pick(editChip, editing);
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            PcHid.listener = this::refresh;
            if (PcHid.hid == null && (Build.VERSION.SDK_INT < 31 || host.checkSelfPermission(
                    android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)) {
                PcHid.start(host);
            }
        } else if (!big) {
            // never leave a key stuck down on the PC
            if (!toggled.isEmpty()) {
                toggled.clear();
                PcHid.releaseAll();
            }
        }
    }

    // ------------------------------------------------------------------ profiles

    private int current() {
        return Math.max(0, Math.min(names().size() - 1, Prefs.getInt(K_PROFILE, 0)));
    }

    private List<String> names() {
        List<String> out = new ArrayList<>();
        for (String n : Prefs.getString(K_NAMES, "DCS\nMY DECK").split("\n")) {
            if (!n.trim().isEmpty()) {
                out.add(n.trim());
            }
        }
        if (out.isEmpty()) {
            out.add("MY DECK");
        }
        return out;
    }

    private void saveNames(List<String> n) {
        Prefs.putString(K_NAMES, String.join("\n", n));
    }

    private String key() {
        return "deck_sq_" + current();
    }

    private void load() {
        squares = new ArrayList<>();
        String raw = Prefs.getString(key(), null);
        if (raw == null) {
            squares = names().get(current()).equals("DCS") ? dcs() : blank();
            if (names().get(current()).equals("DCS")) {
                squares.addAll(carrierRow());
                Prefs.putBool("deck_hookrow_" + current(), true);
            }
            save();
            return;
        }
        for (String l : raw.split("\n")) {
            Sq q = Sq.parse(l);
            if (q != null) {
                squares.add(q);
            }
        }
        // 3.33: a carrier / landing row for the DCS profile, added once without touching your squares
        if (names().get(current()).equals("DCS") && !Prefs.getBool("deck_hookrow_" + current(), false)) {
            Prefs.putBool("deck_hookrow_" + current(), true);
            boolean has = false;
            for (Sq q : squares) {
                has |= q.name.equals("HOOK");
            }
            if (!has) {
                squares.addAll(carrierRow());
                save();
            }
        }
    }

    private static List<Sq> carrierRow() {
        List<Sq> l = new ArrayList<>();
        l.add(sq("HOOK", "H", PcHid.CTRL, 0, 3, 1));
        l.add(sq("FLAPS HALF", "F", PcHid.SHIFT, 0, 2, 1));
        l.add(sq("FLAPS FULL", "F", PcHid.CTRL, 0, 2, 1));
        l.add(sq("WHEEL BRAKE", "W", 0, 1, 1, 1));
        return l;
    }

    /** Adds a square to the KEY DECK profile in use (from DCS KEYS). */
    static void addToDeck(String name, String key, int mods, int times) {
        int prof = Prefs.getInt(K_PROFILE, 0);
        String k = "deck_sq_" + prof;
        String raw = Prefs.getString(k, null);
        if (raw == null) {
            raw = "";
        }
        Sq q = sq(name, key, mods, 0, 5, times);
        Prefs.putString(k, raw + q.line() + "\n");
    }

    private void save() {
        StringBuilder b = new StringBuilder();
        for (Sq q : squares) {
            b.append(q.line()).append('\n');
        }
        Prefs.putString(key(), b.toString());
    }

    private static Sq sq(String name, String key, int mods, int mode, int color, int times) {
        Sq q = new Sq();
        q.name = name;
        q.key = key;
        q.mods = mods;
        q.mode = mode;
        q.color = color;
        q.times = times;
        return q;
    }

    /** Common DCS default keys (most aircraft). Change any square in EDIT if your plane uses others. */
    private static List<Sq> dcs() {
        List<Sq> l = new ArrayList<>();
        l.add(sq("GEAR", "G", 0, 0, 3, 1));
        l.add(sq("FLAPS", "F", 0, 0, 2, 1));
        l.add(sq("AIRBRAKE", "B", 0, 0, 2, 1));
        l.add(sq("WHEEL BRAKE", "W", 0, 1, 1, 1));
        l.add(sq("CANOPY", "C", PcHid.CTRL, 0, 6, 1));
        l.add(sq("AUTO START", "HOME", PcHid.WIN, 0, 4, 1));
        l.add(sq("AUTO STOP", "END", PcHid.WIN, 0, 1, 1));
        l.add(sq("EJECT", "E", PcHid.CTRL, 0, 1, 3));
        l.add(sq("GUN", "SPACE", 0, 1, 1, 1));
        l.add(sq("WEAPON", "SPACE", PcHid.RALT, 1, 1, 1));
        l.add(sq("CHAFF", "INS", 0, 0, 7, 1));
        l.add(sq("FLARE", "DEL", 0, 0, 7, 1));
        l.add(sq("RADAR", "I", 0, 0, 5, 1));
        l.add(sq("TRIM RESET", "T", PcHid.CTRL, 0, 0, 1));
        l.add(sq("THROTTLE +", "KPPLUS", 0, 1, 4, 1));
        l.add(sq("THROTTLE −", "KPMINUS", 0, 1, 4, 1));
        l.add(sq("COCKPIT", "F1", 0, 0, 0, 1));
        l.add(sq("OUTSIDE", "F2", 0, 0, 0, 1));
        l.add(sq("FLY-BY", "F3", 0, 0, 0, 1));
        l.add(sq("MAP", "F10", 0, 0, 0, 1));
        l.add(sq("COMMS", "BACKSLASH", 0, 0, 9, 1));
        l.add(sq("LABELS", "F10", PcHid.SHIFT, 0, 0, 1));
        l.add(sq("NVG", "H", PcHid.RSHIFT, 0, 4, 1));
        l.add(sq("KNEEBOARD", "K", PcHid.RSHIFT, 0, 0, 1));
        l.add(sq("ZOOM IN", "KPSTAR", 0, 1, 0, 1));
        l.add(sq("ZOOM OUT", "KPSLASH", 0, 1, 0, 1));
        l.add(sq("CENTER VIEW", "KP5", 0, 0, 0, 1));
        l.add(sq("CHAT", "TAB", 0, 0, 9, 1));
        l.add(sq("TIME FAST", "Z", PcHid.CTRL, 0, 8, 1));
        l.add(sq("TIME NORMAL", "Z", PcHid.SHIFT, 0, 8, 1));
        l.add(sq("PAUSE", "PAUSE", 0, 0, 3, 1));
        l.add(sq("SCREENSHOT", "PRTSC", 0, 0, 0, 1));
        return l;
    }

    private static List<Sq> blank() {
        List<Sq> l = new ArrayList<>();
        String[] k = {"1", "2", "3", "4", "5", "6", "7", "8"};
        for (int i = 0; i < k.length; i++) {
            l.add(sq("KEY " + k[i], k[i], 0, 0, 5 + i % 5, 1));
        }
        return l;
    }

    private void profiles() {
        final List<String> n = names();
        List<String> items = new ArrayList<>();
        for (int i = 0; i < n.size(); i++) {
            items.add((i == current() ? "● " : "   ") + n.get(i) + " (" + count(i) + ")");
        }
        items.add("➕ New profile");
        items.add("✎ Rename this one");
        items.add("↺ Reset this one");
        items.add("🗑 Delete this one");
        new AlertDialog.Builder(host).setTitle("Profiles")
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    if (w < n.size()) {
                        switchTo(w);
                    } else if (w == n.size()) {
                        ask("New profile", "", name -> {
                            n.add(name.toUpperCase(Locale.ROOT));
                            saveNames(n);
                            switchTo(n.size() - 1);
                        });
                    } else if (w == n.size() + 1) {
                        ask("Rename", n.get(current()), name -> {
                            n.set(current(), name.toUpperCase(Locale.ROOT));
                            saveNames(n);
                            refresh();
                        });
                    } else if (w == n.size() + 2) {
                        Prefs.remove(key());
                        load();
                        build();
                    } else if (n.size() > 1) {
                        int c = current();
                        // shift the later profiles down
                        for (int i = c; i < n.size() - 1; i++) {
                            Prefs.putString("deck_sq_" + i, Prefs.getString("deck_sq_" + (i + 1), ""));
                        }
                        Prefs.remove("deck_sq_" + (n.size() - 1));
                        n.remove(c);
                        saveNames(n);
                        switchTo(Math.max(0, c - 1));
                    } else {
                        host.toast("Keep at least one profile");
                    }
                }).show();
    }

    private int count(int i) {
        String raw = Prefs.getString("deck_sq_" + i, "");
        int c = 0;
        for (String l : raw.split("\n")) {
            if (!l.isEmpty()) {
                c++;
            }
        }
        return c;
    }

    private void switchTo(int p) {
        releaseToggles();
        Prefs.putInt(K_PROFILE, p);
        load();
        build();
    }

    private void releaseToggles() {
        for (Sq q : toggled) {
            PcHid.hold(q.mods, q.code(), false);
        }
        toggled.clear();
    }

    private interface Got {
        void got(String s);
    }

    private void ask(String title, String now, Got g) {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setText(now);
        new AlertDialog.Builder(host).setTitle(title).setView(e)
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (!s.isEmpty()) {
                        g.got(s);
                    }
                }).setNegativeButton("CANCEL", null).show();
    }

    // ------------------------------------------------------------------ the grid

    private void build() {
        grid.removeAllViews();
        int per = 4;
        int total = squares.size() + (editing ? 1 : 0);
        LinearLayout r = null;
        for (int i = 0; i < total; i++) {
            if (i % per == 0) {
                r = row();
                grid.addView(r, wide());
            }
            View v = i < squares.size() ? square(i) : addSquare();
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(3), dp(3), dp(3), dp(3));
            r.addView(v, p);
        }
        while (r != null && r.getChildCount() < per) {
            r.addView(new View(host), weight(1f));
        }
        if (squares.isEmpty() && !editing) {
            TextView t = text("Tap ✎ EDIT, then + to add squares", 11f, Theme.DIM);
            t.setPadding(0, dp(20), 0, dp(20));
            grid.addView(t, wide());
        }
        if (editing) {
            TextView addRow = chip("+ ADD A ROW (4 squares)", () -> {
                for (int k = 0; k < 4; k++) {
                    squares.add(sq("NEW", "G", 0, 0, 0, 1));
                }
                save();
                build();
            });
            LinearLayout.LayoutParams ap = wide();
            ap.setMargins(dp(3), dp(6), dp(3), 0);
            grid.addView(addRow, ap);
        }
        TextView hint = text(editing ? "Tap a square to change it. HOLD = down while pressed, TOGGLE = stays down."
                : "DCS keys differ a bit by aircraft: ✎ EDIT to change any square.", 9f, Theme.DIM);
        hint.setPadding(0, dp(6), 0, 0);
        grid.addView(hint, wide());
        refresh();
    }

    /** A square that keeps its height equal to its width. */
    private final class Box extends TextView {
        Box() {
            super(host);
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(w), MeasureSpec.EXACTLY));
        }
    }

    private View square(final int i) {
        final Sq q = squares.get(i);
        final Box b = new Box();
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Theme.MONO);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(big ? 12f : 10f);
        b.setText(q.name + "\n" + q.keyLabel() + (q.mode == 1 ? "\n● HOLD" : q.mode == 2 ? "\n⇄ TOGGLE" : ""));
        b.setPadding(dp(3), dp(3), dp(3), dp(3));
        paint(b, q, toggled.contains(q));
        if (editing) {
            b.setOnClickListener(v -> edit(i));
            return b;
        }
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (!PcHid.connected()) {
                    host.toast("Not connected: tap CONNECT");
                    return true;
                }
                v.getParent().requestDisallowInterceptTouchEvent(true);
                host.buzz(10);
                if (q.mode == 0) {
                    PcHid.tap(q.mods, q.code(), q.times, 40);
                    flash(b, q);
                } else if (q.mode == 1) {
                    PcHid.hold(q.mods, q.code(), true);
                    paint(b, q, true);
                } else {
                    boolean on = !toggled.contains(q);
                    if (on) {
                        toggled.add(q);
                    } else {
                        toggled.remove(q);
                    }
                    PcHid.hold(q.mods, q.code(), on);
                    paint(b, q, on);
                }
                return true;
            }
            if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) && q.mode == 1) {
                PcHid.hold(q.mods, q.code(), false);
                paint(b, q, false);
            }
            return true;
        });
        return b;
    }

    private void paint(TextView b, Sq q, boolean lit) {
        int c = COLORS[Math.max(0, Math.min(COLORS.length - 1, q.color))];
        int fill = lit ? c : (c & 0x00FFFFFF) | 0x55000000;
        b.setBackground(Theme.rounded(fill, 14f, host));
        b.setTextColor(lit && (q.color == 3 || q.color == 9) ? 0xFF000000 : 0xFFFFFFFF);
    }

    private void flash(TextView b, Sq q) {
        paint(b, q, true);
        b.postDelayed(() -> paint(b, q, false), 160);
    }

    private View addSquare() {
        Box b = new Box();
        b.setGravity(Gravity.CENTER);
        b.setText("+");
        b.setTextSize(26f);
        b.setTextColor(Theme.ACCENT);
        b.setBackground(Theme.rounded(0x14FFFFFF, 14f, host));
        b.setOnClickListener(v -> {
            squares.add(new Sq());
            save();
            edit(squares.size() - 1);
        });
        return b;
    }

    private void edit(final int i) {
        final Sq q = squares.get(i);
        LinearLayout f = new LinearLayout(host);
        f.setOrientation(VERTICAL);
        f.setPadding(dp(18), dp(8), dp(18), 0);
        final EditText name = new EditText(host);
        name.setHint("Name (GEAR, FLAPS…)");
        name.setText(q.name);
        name.setSingleLine(true);
        f.addView(name);
        final TextView keyBtn = new TextView(host);
        keyBtn.setTextSize(15f);
        keyBtn.setTextColor(Theme.ACCENT);
        keyBtn.setPadding(0, dp(12), 0, dp(12));
        final String[] chosen = {q.key};
        keyBtn.setText("KEY: " + chosen[0] + "  ›");
        keyBtn.setOnClickListener(v -> {
            final String[] all = PcHid.keyNames();
            new AlertDialog.Builder(host).setTitle("Which key?")
                    .setItems(all, (d, w) -> {
                        chosen[0] = all[w];
                        keyBtn.setText("KEY: " + chosen[0] + "  ›");
                    }).show();
        });
        f.addView(keyBtn);
        final List<CheckBox> boxes = new ArrayList<>();
        LinearLayout mr = new LinearLayout(host);
        mr.setOrientation(VERTICAL);
        for (String[] m : MOD_NAMES) {
            CheckBox cb = new CheckBox(host);
            cb.setText("+ " + m[0]);
            cb.setChecked((q.mods & Integer.parseInt(m[1])) != 0);
            boxes.add(cb);
            mr.addView(cb);
        }
        f.addView(mr);
        final int[] mode = {q.mode};
        final TextView modeBtn = new TextView(host);
        modeBtn.setTextSize(15f);
        modeBtn.setTextColor(Theme.ACCENT);
        modeBtn.setPadding(0, dp(10), 0, dp(10));
        modeBtn.setText("MODE: " + MODES[mode[0]] + "  ›");
        modeBtn.setOnClickListener(v -> {
            mode[0] = (mode[0] + 1) % MODES.length;
            modeBtn.setText("MODE: " + MODES[mode[0]] + "  ›");
        });
        f.addView(modeBtn);
        final int[] times = {q.times};
        final TextView timesBtn = new TextView(host);
        timesBtn.setTextSize(15f);
        timesBtn.setTextColor(Theme.ACCENT);
        timesBtn.setPadding(0, dp(10), 0, dp(10));
        timesBtn.setText("PRESSES (tap mode): " + times[0] + "  ›");
        timesBtn.setOnClickListener(v -> {
            times[0] = times[0] % 5 + 1;
            timesBtn.setText("PRESSES (tap mode): " + times[0] + "  ›");
        });
        f.addView(timesBtn);
        final int[] color = {q.color};
        LinearLayout cr = new LinearLayout(host);
        final List<View> dots = new ArrayList<>();
        for (int c = 0; c < COLORS.length; c++) {
            final int ci = c;
            View dot = new View(host);
            dot.setBackground(Theme.rounded(COLORS[c], 20f, host));
            dot.setAlpha(c == color[0] ? 1f : 0.35f);
            dot.setOnClickListener(v -> {
                color[0] = ci;
                for (int k = 0; k < dots.size(); k++) {
                    dots.get(k).setAlpha(k == ci ? 1f : 0.35f);
                }
            });
            LinearLayout.LayoutParams dp0 = new LinearLayout.LayoutParams(0, dp(26), 1f);
            dp0.setMargins(dp(2), dp(8), dp(2), dp(8));
            cr.addView(dot, dp0);
            dots.add(dot);
        }
        f.addView(cr);
        ScrollView sv = new ScrollView(host);
        sv.addView(f);
        new AlertDialog.Builder(host).setTitle("Square " + (i + 1))
                .setView(sv)
                .setPositiveButton("SAVE", (d, w) -> {
                    q.name = name.getText().toString().trim().isEmpty() ? chosen[0] : name.getText().toString().trim();
                    q.key = chosen[0];
                    int m = 0;
                    for (int k = 0; k < boxes.size(); k++) {
                        if (boxes.get(k).isChecked()) {
                            m |= Integer.parseInt(MOD_NAMES[k][1]);
                        }
                    }
                    q.mods = m;
                    q.mode = mode[0];
                    q.times = times[0];
                    q.color = color[0];
                    save();
                    build();
                })
                .setNeutralButton("DELETE", (d, w) -> {
                    toggled.remove(q);
                    squares.remove(i);
                    save();
                    build();
                })
                .setNegativeButton("← MOVE", (d, w) -> {
                    if (i > 0) {
                        squares.remove(i);
                        squares.add(i - 1, q);
                        save();
                    }
                    build();
                }).show();
    }

    // ------------------------------------------------------------------ full screen

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(Theme.BG | 0xFF000000);
        v.setPadding(dp(10), dp(40), dp(10), dp(12));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("KEY DECK", 16f, Theme.ACCENT);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", () -> {
            host.hideOverlay();
            PcHid.releaseAll();
            PcHid.listener = this::refresh;
            load();
            build();
        }));
        v.addView(head, wide());
        ScrollView sv = new ScrollView(host);
        sv.addView(new KeyDeckWidget(host, true));
        v.addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }
}
