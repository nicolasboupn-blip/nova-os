package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Four real alternative home screens (Settings > UI STYLE > Home screen layout). They are not colour themes: each one
 * arranges NOVA in a different way. BENTO: a board of tiles. ORBIT: apps on turning rings around the clock.
 * FEED: a scrolling feed of cards with search. CONSOLE: big tiles in one row like a game console.
 * The classic home screen stays the default, and every look (Aurora, Terminal, Block, My style) works with all of them.
 */
abstract class AltHome extends FrameLayout {
    static final String K_LAYOUT = "ui_layout";
    static final String[] NAMES = {"Classic", "Bento", "Orbit", "Feed", "Console", "Index", "Fan", "Wallet", "Bubbles", "Lines", "Dock"};

    final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            tick();
            ui.postDelayed(this, tickMs());
        }
    };

    static AltHome create(NovaActivity host, int layout) {
        switch (layout) {
            case 2:
                return new Orbit(host);
            case 3:
                return new Feed(host);
            case 4:
                return new Console(host);
            case 5:
                return new Index(host);
            case 6:
                return new Fan(host);
            case 7:
                return new Wallet(host);
            case 8:
                return new Bubbles(host);
            case 9:
                return new Lines(host);
            case 10:
                return new Dock(host);
            default:
                return new Bento(host);
        }
    }

    AltHome(NovaActivity host) {
        super(host);
        this.host = host;
    }

    long tickMs() {
        return 1000;
    }

    void tick() {
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.removeCallbacks(loop);
        ui.post(loop);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacks(loop);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ shared helpers

    int dp(float v) {
        return Theme.dp(host, v);
    }

    TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    List<AppEntry> pinned() {
        host.repo.ensureFresh();
        List<AppEntry> out = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                out.add(e);
            }
        }
        return out;
    }

    /** Pinned apps first, then the rest, up to n. */
    List<AppEntry> appsFor(int n) {
        List<AppEntry> out = pinned();
        for (AppEntry e : host.repo.all) {
            if (out.size() >= n) {
                break;
            }
            if (!out.contains(e)) {
                out.add(e);
            }
        }
        return out.size() > n ? new ArrayList<>(out.subList(0, n)) : out;
    }

    String clock() {
        return new SimpleDateFormat(Prefs.getBool("clock_12h", false) ? "h:mm" : "HH:mm", Locale.getDefault())
                .format(new Date());
    }

    String date() {
        return new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(new Date());
    }

    int battery() {
        try {
            BatteryManager bm = (BatteryManager) host.getSystemService(Context.BATTERY_SERVICE);
            return Math.max(0, Math.min(100, bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g = h < 5 ? "Good night" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
        String n = Profile.name();
        return g + ", " + n;
    }

    View appTile(final AppEntry e, int iconDp, boolean label) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4), dp(8), dp(4), dp(8));
        ImageView iv = new ImageView(host);
        iv.setImageDrawable(Theme.tint(host, e.icon));
        Upgrades.shapeIcon(iv);
        c.addView(iv, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));
        if (label) {
            TextView t = text(e.label, 10f, Theme.TEXT);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(4);
            c.addView(t, lp);
        }
        c.setClickable(true);
        Theme.ripple(c);
        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.appMenu(e);
            return true;
        });
        return c;
    }

    TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    /** APPS, TERMINAL, SETTINGS along the bottom of every layout. */
    View bar() {
        LinearLayout b = new LinearLayout(host);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(12), dp(6), dp(12), dp(14));
        String[] names = {"APPS", "PROFILE", "TERMINAL", "SETTINGS"};
        Runnable[] acts = {() -> host.showDrawer(), () -> host.showOverlay(new ProfileScreen(host)),
            () -> host.showTerminal(), () -> host.showSettings()};
        for (int i = 0; i < names.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            b.addView(chip(names[i], acts[i]), lp);
        }
        return b;
    }

    FrameLayout card(String title, View content) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        box.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        if (title != null) {
            TextView t = text(title, 9f, Theme.DIM);
            t.setGravity(Gravity.START);
            t.setLetterSpacing(0.15f);
            box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout f = new FrameLayout(host);
        f.addView(box, new FrameLayout.LayoutParams(-1, -2));
        return f;
    }

    // ================================================================== BENTO

    /** A board of tiles: big clock, small status tiles, widgets, then your apps as square tiles. */
    static final class Bento extends AltHome {
        private final TextView time;
        private final TextView day;
        private final TextView batt;

        Bento(NovaActivity host) {
            super(host);
            LinearLayout page = new LinearLayout(host);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(dp(12), dp(46), dp(12), dp(12));

            LinearLayout r1 = new LinearLayout(host);
            LinearLayout clockTile = tile();
            clockTile.setGravity(Gravity.CENTER_VERTICAL);
            time = text(clock(), 44f, Theme.TEXT);
            time.setGravity(Gravity.START);
            clockTile.addView(time);
            day = text(date(), 12f, Theme.DIM);
            day.setGravity(Gravity.START);
            clockTile.addView(day);
            r1.addView(clockTile, lp(0, dp(150), 3f, 0, 0, 6));

            LinearLayout side = new LinearLayout(host);
            side.setOrientation(LinearLayout.VERTICAL);
            LinearLayout scene = tile();
            scene.setGravity(Gravity.CENTER);
            TextView st = text(Scenes.status().isEmpty() ? "SCENE\ntap" : Scenes.status(), 12f, Theme.ACCENT);
            st.setGravity(Gravity.CENTER);
            scene.addView(st);
            scene.setOnClickListener(v -> host.showOverlay(new ScenesScreen(host)));
            side.addView(scene, lp(-1, 0, 1f, 0, 0, 6));
            LinearLayout bt = tile();
            bt.setGravity(Gravity.CENTER);
            batt = text(battery() + "%", 20f, Theme.TEXT);
            bt.addView(batt);
            bt.addView(text("BATTERY", 8f, Theme.DIM));
            side.addView(bt, lp(-1, 0, 1f, 0, 0, 0));
            r1.addView(side, lp(0, dp(150), 2f, 0, 0, 0));
            page.addView(r1, new LinearLayout.LayoutParams(-1, -2));

            page.addView(card("SONGS", new SongsWidget(host)), top(10));
            page.addView(card(null, new ProfileWidget(host)), top(10));

            List<AppEntry> apps = appsFor(11);
            LinearLayout row = null;
            for (int i = 0; i <= apps.size(); i++) {
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    page.addView(row, top(10));
                }
                View t;
                if (i == apps.size()) {
                    TextView all = text("ALL\nAPPS", 11f, Theme.ACCENT);
                    all.setGravity(Gravity.CENTER);
                    all.setOnClickListener(v -> host.showDrawer());
                    LinearLayout w = tile();
                    w.setGravity(Gravity.CENTER);
                    w.addView(all);
                    w.setOnClickListener(v -> host.showDrawer());
                    t = w;
                } else {
                    LinearLayout w = tile();
                    w.setGravity(Gravity.CENTER);
                    w.setPadding(0, 0, 0, 0);
                    w.addView(appTile(apps.get(i), 40, true));
                    t = w;
                }
                row.addView(t, lp(0, dp(84), 1f, 3, 0, 3));
            }
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(page);
            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
            all.addView(bar());
            addView(all, new FrameLayout.LayoutParams(-1, -1));
        }

        private LinearLayout tile() {
            LinearLayout t = new LinearLayout(host);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setPadding(dp(14), dp(10), dp(14), dp(10));
            t.setBackground(Theme.rounded(Theme.PANEL, 20f, host));
            t.setClickable(true);
            return t;
        }

        private LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h == 0 ? 0 : h, weight);
            if (w == -1) {
                p = new LinearLayout.LayoutParams(-1, 0, weight);
            }
            if (h == dp(150)) {
                p = new LinearLayout.LayoutParams(w, h, weight);
            }
            p.setMargins(dp(l), dp(t), dp(r), 0);
            return p;
        }

        private LinearLayout.LayoutParams top(int m) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(m);
            return p;
        }

        @Override
        void tick() {
            time.setText(clock());
            day.setText(date());
            batt.setText(battery() + "%");
        }
    }

    // ================================================================== ORBIT

    /** Apps sit on two rings around the clock. Drag to turn the rings, tap an app to open it, tap the middle for all apps. */
    static final class Orbit extends AltHome {
        private final OrbitView view;

        Orbit(NovaActivity host) {
            super(host);
            view = new OrbitView(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(view, new LinearLayout.LayoutParams(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        long tickMs() {
            return 15000;
        }

        @Override
        void tick() {
            view.invalidate();
        }

        private final class OrbitView extends View {
            private final List<AppEntry> inner = new ArrayList<>();
            private final List<AppEntry> outer = new ArrayList<>();
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private float a1;
            private float a2;
            private float lastAngle;
            private float downX;
            private float downY;
            private boolean moved;
            private float vel;
            private long lastT;
            private final float slop = ViewConfiguration.get(host).getScaledTouchSlop();
            private final Runnable longPress = new Runnable() {
                @Override
                public void run() {
                    AppEntry e = hit(downX, downY);
                    if (e != null && !moved) {
                        host.appMenu(e);
                        moved = true;
                    }
                }
            };
            private final Runnable spin = new Runnable() {
                @Override
                public void run() {
                    if (Math.abs(vel) < 0.02f) {
                        return;
                    }
                    a1 += vel;
                    a2 -= vel * 0.7f;
                    vel *= 0.94f;
                    invalidate();
                    postOnAnimation(this);
                }
            };

            OrbitView(Context c) {
                super(c);
                List<AppEntry> apps = appsFor(16);
                for (int i = 0; i < apps.size(); i++) {
                    (i < 6 ? inner : outer).add(apps.get(i));
                }
            }

            private float cx() {
                return getWidth() / 2f;
            }

            private float cy() {
                return getHeight() / 2f;
            }

            private float r1() {
                return Math.min(getWidth(), getHeight()) * 0.27f;
            }

            private float r2() {
                return Math.min(getWidth(), getHeight()) * 0.43f;
            }

            private float[] pos(int ring, int i) {
                List<AppEntry> l = ring == 0 ? inner : outer;
                double a = (ring == 0 ? a1 : a2) + i * 2 * Math.PI / Math.max(1, l.size());
                float r = ring == 0 ? r1() : r2();
                return new float[] {cx() + (float) Math.cos(a) * r, cy() + (float) Math.sin(a) * r};
            }

            private AppEntry hit(float x, float y) {
                for (int ring = 0; ring < 2; ring++) {
                    List<AppEntry> l = ring == 0 ? inner : outer;
                    for (int i = 0; i < l.size(); i++) {
                        float[] q = pos(ring, i);
                        float rad = dp(ring == 0 ? 30 : 24);
                        if ((q[0] - x) * (q[0] - x) + (q[1] - y) * (q[1] - y) < rad * rad) {
                            return l.get(i);
                        }
                    }
                }
                return null;
            }

            @Override
            protected void onDraw(Canvas cv) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                p.setColor(0x22FFFFFF);
                cv.drawCircle(cx(), cy(), r1(), p);
                cv.drawCircle(cx(), cy(), r2(), p);
                p.setStyle(Paint.Style.FILL);
                p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x22000000);
                cv.drawCircle(cx(), cy(), r1() * 0.72f, p);
                p.setTypeface(Theme.MONO);
                p.setTextAlign(Paint.Align.CENTER);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(34));
                cv.drawText(clock(), cx(), cy() + dp(4), p);
                p.setColor(Theme.DIM);
                p.setTextSize(dp(11));
                cv.drawText(date(), cx(), cy() + dp(24), p);
                String st = Scenes.status();
                if (!st.isEmpty()) {
                    p.setColor(Theme.ACCENT);
                    cv.drawText(st, cx(), cy() + dp(42), p);
                }
                for (int ring = 0; ring < 2; ring++) {
                    List<AppEntry> l = ring == 0 ? inner : outer;
                    int size = dp(ring == 0 ? 52 : 42);
                    for (int i = 0; i < l.size(); i++) {
                        float[] q = pos(ring, i);
                        Drawable d = Theme.tint(host, l.get(i).icon);
                        d.setBounds((int) q[0] - size / 2, (int) q[1] - size / 2, (int) q[0] + size / 2,
                                (int) q[1] + size / 2);
                        d.draw(cv);
                    }
                }
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float x = e.getX();
                float y = e.getY();
                float ang = (float) Math.atan2(y - cy(), x - cx());
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        removeCallbacks(spin);
                        vel = 0;
                        downX = x;
                        downY = y;
                        moved = false;
                        lastAngle = ang;
                        lastT = e.getEventTime();
                        postDelayed(longPress, 500);
                        getParent().requestDisallowInterceptTouchEvent(true);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        if (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop) {
                            moved = true;
                            removeCallbacks(longPress);
                        }
                        float d = ang - lastAngle;
                        if (d > Math.PI) {
                            d -= 2 * Math.PI;
                        } else if (d < -Math.PI) {
                            d += 2 * Math.PI;
                        }
                        a1 += d;
                        a2 -= d * 0.7f;
                        long dt = Math.max(1, e.getEventTime() - lastT);
                        vel = d * 16f / dt;
                        lastAngle = ang;
                        lastT = e.getEventTime();
                        invalidate();
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        removeCallbacks(longPress);
                        if (!moved) {
                            AppEntry a = hit(x, y);
                            if (a != null) {
                                host.launch(a);
                            } else if ((x - cx()) * (x - cx()) + (y - cy()) * (y - cy()) < r1() * r1() * 0.6f) {
                                host.showDrawer();
                            }
                        } else {
                            vel = Math.max(-0.25f, Math.min(0.25f, vel));
                            postOnAnimation(spin);
                        }
                        return true;
                    default:
                        removeCallbacks(longPress);
                        return true;
                }
            }
        }
    }

    // ================================================================== FEED

    /** A scrolling feed of cards, with a search box. Typing shows matching apps instead of the feed. */
    static final class Feed extends AltHome {
        private final TextView time;
        private final LinearLayout feed;
        private final LinearLayout results;

        Feed(NovaActivity host) {
            super(host);
            LinearLayout page = new LinearLayout(host);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(dp(14), dp(46), dp(14), dp(12));

            TextView hi = text(greeting(), 12f, Theme.ACCENT);
            hi.setGravity(Gravity.START);
            page.addView(hi);
            time = text(clock() + "   " + date(), 20f, Theme.TEXT);
            time.setGravity(Gravity.START);
            page.addView(time);

            EditText search = new EditText(host);
            search.setHint("search apps");
            search.setHintTextColor(Theme.DIM);
            search.setTextColor(Theme.TEXT);
            search.setTextSize(14f);
            search.setSingleLine(true);
            search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            search.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
            search.setPadding(dp(16), dp(11), dp(16), dp(11));
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
            slp.topMargin = dp(12);
            page.addView(search, slp);

            results = new LinearLayout(host);
            results.setOrientation(LinearLayout.VERTICAL);
            results.setVisibility(GONE);
            page.addView(results, new LinearLayout.LayoutParams(-1, -2));

            feed = new LinearLayout(host);
            feed.setOrientation(LinearLayout.VERTICAL);
            page.addView(feed, new LinearLayout.LayoutParams(-1, -2));
            addCard("SCENES", new ScenesWidget(host));
            addCard("SONGS", new SongsWidget(host));
            addCard(null, new ProfileWidget(host));
            LinearLayout recent = new LinearLayout(host);
            for (AppEntry a : appsFor(5)) {
                recent.addView(appTile(a, 38, false), new LinearLayout.LayoutParams(0, -2, 1f));
            }
            addCard("YOUR APPS", recent);
            addCard("THIS PHONE", Widgets.create(host, "device"));

            search.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {
                }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {
                    String q = s.toString().trim();
                    results.removeAllViews();
                    feed.setVisibility(q.isEmpty() ? VISIBLE : GONE);
                    results.setVisibility(q.isEmpty() ? GONE : VISIBLE);
                    if (q.isEmpty()) {
                        return;
                    }
                    List<AppEntry> found = host.repo.search(q);
                    for (int i = 0; i < found.size() && i < 12; i++) {
                        final AppEntry e = found.get(i);
                        LinearLayout r = new LinearLayout(host);
                        r.setGravity(Gravity.CENTER_VERTICAL);
                        r.setPadding(dp(6), dp(8), dp(6), dp(8));
                        ImageView iv = new ImageView(host);
                        iv.setImageDrawable(Theme.tint(host, e.icon));
                        r.addView(iv, new LinearLayout.LayoutParams(dp(36), dp(36)));
                        TextView t = text(e.label, 14f, Theme.TEXT);
                        t.setPadding(dp(12), 0, 0, 0);
                        r.addView(t);
                        r.setClickable(true);
                        Theme.ripple(r);
                        r.setOnClickListener(v -> host.launch(e));
                        results.addView(r);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(page);
            LinearLayout all = new LinearLayout(host);
            all.setOrientation(LinearLayout.VERTICAL);
            all.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
            all.addView(bar());
            addView(all, new FrameLayout.LayoutParams(-1, -1));
        }

        private void addCard(String title, View content) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(12);
            feed.addView(card(title, content), p);
        }

        @Override
        void tick() {
            time.setText(clock() + "   " + date());
        }
    }

    // ================================================================== CONSOLE

    /** Big tiles in one row, like a game console. The tile in the middle grows; the name shows underneath. */
    static final class Console extends AltHome {
        private final HorizontalScrollView hs;
        private final LinearLayout row;
        private final TextView name;
        private final TextView time;
        private final TextView info;
        private final List<View> tiles = new ArrayList<>();
        private final List<String> names = new ArrayList<>();

        Console(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(0, dp(46), 0, 0);

            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(20), 0, dp(20), 0);
            time = text(clock(), 22f, Theme.TEXT);
            top.addView(time, new LinearLayout.LayoutParams(0, -2, 1f));
            info = text(battery() + "%", 12f, Theme.DIM);
            top.addView(info);
            col.addView(top, new LinearLayout.LayoutParams(-1, -2));

            hs = new HorizontalScrollView(host) {
                @Override
                protected void onScrollChanged(int l, int t, int ol, int ot) {
                    super.onScrollChanged(l, t, ol, ot);
                    fit();
                }

                @Override
                public boolean onTouchEvent(MotionEvent ev) {
                    boolean r = super.onTouchEvent(ev);
                    if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                        postDelayed(Console.this::snap, 160);
                    }
                    return r;
                }
            };
            hs.setHorizontalScrollBarEnabled(false);
            hs.setClipChildren(false);
            hs.setClipToPadding(false);
            row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setClipChildren(false);
            hs.addView(row);
            col.addView(hs, new LinearLayout.LayoutParams(-1, 0, 1f));

            name = text("", 18f, Theme.TEXT);
            name.setGravity(Gravity.CENTER);
            name.setPadding(0, 0, 0, dp(10));
            col.addView(name, new LinearLayout.LayoutParams(-1, -2));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));

            for (AppEntry a : appsFor(7)) {
                add(a.label, appTile(a, 64, false), 150, null);
            }
            add("SONGS", new SongsWidget(host), 280, null);
            add("PROFILE", new ProfileWidget(host), 280, null);
            add("SCENES", new ScenesWidget(host), 280, null);
            add("ALL APPS", big("▦"), 150, () -> host.showDrawer());
            add("SETTINGS", big("⚙"), 150, () -> host.showSettings());
            post(this::snap);
        }

        private View big(String s) {
            TextView t = text(s, 44f, Theme.ACCENT);
            t.setGravity(Gravity.CENTER);
            return t;
        }

        private void add(String label, View content, int widthDp, Runnable open) {
            FrameLayout tile = new FrameLayout(host);
            tile.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
            tile.setPadding(dp(8), dp(8), dp(8), dp(8));
            tile.addView(content, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            if (open != null) {
                tile.setClickable(true);
                tile.setOnClickListener(v -> open.run());
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), dp(widthDp > 200 ? 300 : 220));
            lp.setMargins(dp(8), 0, dp(8), 0);
            row.addView(tile, lp);
            tiles.add(tile);
            names.add(label);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            int pad = Math.max(0, w / 2 - dp(75));
            row.setPadding(pad, 0, pad, 0);
            fit();
        }

        private int centered() {
            float mid = hs.getScrollX() + hs.getWidth() / 2f;
            int best = 0;
            float bd = Float.MAX_VALUE;
            for (int i = 0; i < tiles.size(); i++) {
                View t = tiles.get(i);
                float d = Math.abs(t.getLeft() + t.getWidth() / 2f - mid);
                if (d < bd) {
                    bd = d;
                    best = i;
                }
            }
            return best;
        }

        private void fit() {
            if (tiles.isEmpty()) {
                return;
            }
            float mid = hs.getScrollX() + hs.getWidth() / 2f;
            for (View t : tiles) {
                float d = Math.abs(t.getLeft() + t.getWidth() / 2f - mid) / Math.max(1f, hs.getWidth() / 2f);
                float s = Math.max(0.78f, 1.08f - d * 0.35f);
                t.setScaleX(s);
                t.setScaleY(s);
                t.setAlpha(Math.max(0.45f, 1f - d * 0.5f));
            }
            int c = centered();
            if (c >= 0 && c < names.size()) {
                name.setText(names.get(c));
            }
        }

        private void snap() {
            if (tiles.isEmpty()) {
                return;
            }
            View t = tiles.get(centered());
            hs.smoothScrollTo(t.getLeft() + t.getWidth() / 2 - hs.getWidth() / 2, 0);
        }

        @Override
        void tick() {
            time.setText(clock());
            info.setText((Scenes.status().isEmpty() ? "" : Scenes.status() + "   ") + battery() + "%");
        }
    }

    // ================================================================== INDEX

    /** Text only: a big clock, then every app as a line of type, with an A to Z rail on the right to jump. */
    static final class Index extends AltHome {
        private final TextView time;
        private final ScrollView sv;
        private final java.util.Map<Character, View> heads = new java.util.HashMap<>();

        Index(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(22), dp(50), 0, 0);
            time = text(clock(), 56f, Theme.TEXT);
            time.setGravity(Gravity.START);
            col.addView(time);
            TextView day = text(date() + (Scenes.status().isEmpty() ? "" : "   " + Scenes.status()), 12f, Theme.DIM);
            day.setGravity(Gravity.START);
            col.addView(day);

            LinearLayout body = new LinearLayout(host);
            sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            LinearLayout list = new LinearLayout(host);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(0, dp(16), 0, dp(20));
            List<AppEntry> apps = new ArrayList<>(host.repo.all);
            java.util.Collections.sort(apps, (a, b) -> a.label.compareToIgnoreCase(b.label));
            char last = 0;
            for (final AppEntry e : apps) {
                char ch = e.label.isEmpty() ? '#' : Character.toUpperCase(e.label.charAt(0));
                if (!Character.isLetter(ch)) {
                    ch = '#';
                }
                if (ch != last) {
                    last = ch;
                    TextView hd = text(String.valueOf(ch), 13f, Theme.ACCENT);
                    hd.setPadding(0, dp(14), 0, dp(2));
                    hd.setGravity(Gravity.START);
                    list.addView(hd);
                    heads.put(ch, hd);
                }
                TextView t = text(e.label, 24f, Theme.TEXT);
                t.setGravity(Gravity.START);
                t.setSingleLine(true);
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.setPadding(0, dp(6), 0, dp(6));
                t.setClickable(true);
                Theme.ripple(t);
                t.setOnClickListener(v -> host.launch(e));
                t.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                list.addView(t);
            }
            sv.addView(list);
            body.addView(sv, new LinearLayout.LayoutParams(0, -1, 1f));

            final String letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            LinearLayout rail = new LinearLayout(host);
            rail.setOrientation(LinearLayout.VERTICAL);
            rail.setPadding(dp(4), dp(8), dp(8), dp(8));
            for (int i = 0; i < letters.length(); i++) {
                TextView l = text(String.valueOf(letters.charAt(i)), 9f, Theme.DIM);
                l.setGravity(Gravity.CENTER);
                rail.addView(l, new LinearLayout.LayoutParams(dp(22), 0, 1f));
            }
            rail.setOnTouchListener((v, ev) -> {
                float f = Math.max(0f, Math.min(0.999f, ev.getY() / Math.max(1f, v.getHeight())));
                char c = letters.charAt((int) (f * letters.length()));
                for (int k = letters.indexOf(c); k < letters.length(); k++) {
                    View h = heads.get(letters.charAt(k));
                    if (h != null) {
                        sv.scrollTo(0, h.getTop());
                        break;
                    }
                }
                return true;
            });
            body.addView(rail, new LinearLayout.LayoutParams(-2, -1));
            col.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== FAN

    /** One-handed: the clock and cards on top, one big button in the corner that fans your apps out in an arc. */
    static final class Fan extends AltHome {
        private final TextView time;
        private final List<View> fans = new ArrayList<>();
        private final List<float[]> targets = new ArrayList<>();
        private boolean open;
        private final TextView fab;

        Fan(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(50), dp(16), 0);
            time = text(clock(), 48f, Theme.TEXT);
            time.setGravity(Gravity.START);
            col.addView(time);
            TextView day = text(date(), 12f, Theme.DIM);
            day.setGravity(Gravity.START);
            col.addView(day);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.topMargin = dp(14);
            col.addView(card("SONGS", new SongsWidget(host)), cp);
            LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, -2);
            cp2.topMargin = dp(10);
            col.addView(card(null, new ProfileWidget(host)), cp2);
            View spacer = new View(host);
            col.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));

            final FrameLayout layer = new FrameLayout(host);
            layer.setClipChildren(false);
            addView(layer, new FrameLayout.LayoutParams(-1, -1));
            int fabSize = dp(66);
            List<AppEntry> apps = appsFor(13);
            int inner = Math.min(6, apps.size());
            for (int i = 0; i < apps.size(); i++) {
                boolean second = i >= inner;
                int idx = second ? i - inner : i;
                int count = second ? apps.size() - inner : inner;
                double a = Math.PI + (Math.PI / 2) * (count == 1 ? 0.5 : idx / (double) (count - 1));
                float radius = dp(second ? 250 : 150);
                View ic = appTile(apps.get(i), second ? 42 : 48, false);
                ic.setBackground(Theme.rounded(Theme.PANEL, 28f, host));
                ic.setVisibility(INVISIBLE);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM | Gravity.END);
                lp.rightMargin = dp(24);
                lp.bottomMargin = dp(104);
                layer.addView(ic, lp);
                fans.add(ic);
                targets.add(new float[] {(float) Math.cos(a) * radius, (float) Math.sin(a) * radius});
            }
            fab = text("\u25C9", 28f, Theme.BG);
            fab.setGravity(Gravity.CENTER);
            fab.setBackground(Theme.rounded(Theme.ACCENT, 33f, host));
            fab.setClickable(true);
            fab.setOnClickListener(v -> toggle());
            FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(fabSize, fabSize, Gravity.BOTTOM | Gravity.END);
            fp.rightMargin = dp(22);
            fp.bottomMargin = dp(100);
            layer.addView(fab, fp);
        }

        private void toggle() {
            open = !open;
            fab.animate().rotation(open ? 45f : 0f).setDuration(200).start();
            for (int i = 0; i < fans.size(); i++) {
                final View v = fans.get(i);
                float[] t = targets.get(i);
                if (open) {
                    v.setVisibility(VISIBLE);
                    v.setAlpha(0f);
                    v.setScaleX(0.3f);
                    v.setScaleY(0.3f);
                    v.animate().translationX(t[0]).translationY(t[1]).alpha(1f).scaleX(1f).scaleY(1f)
                            .setStartDelay(i * 18L).setDuration(240).start();
                } else {
                    v.animate().translationX(0).translationY(0).alpha(0f).scaleX(0.3f).scaleY(0.3f).setStartDelay(0)
                            .setDuration(180).withEndAction(() -> v.setVisibility(INVISIBLE)).start();
                }
            }
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== WALLET

    /** Cards like in a wallet. Tap a card to open it, the others fold down to a strip. */
    static final class Wallet extends AltHome {
        private final List<View[]> cards = new ArrayList<>();
        private final LinearLayout col;
        private final TextView time;

        Wallet(NovaActivity host) {
            super(host);
            LinearLayout page = new LinearLayout(host);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setPadding(dp(14), dp(48), dp(14), dp(10));
            time = text(clock(), 12f, Theme.ACCENT);
            col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutTransition(new android.animation.LayoutTransition());
            col.setPadding(0, dp(6), 0, dp(20));

            LinearLayout apps = new LinearLayout(host);
            apps.setOrientation(LinearLayout.VERTICAL);
            List<AppEntry> list = appsFor(12);
            LinearLayout row = null;
            for (int i = 0; i < list.size(); i++) {
                if (i % 4 == 0) {
                    row = new LinearLayout(host);
                    apps.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                row.addView(appTile(list.get(i), 44, true), new LinearLayout.LayoutParams(0, -2, 1f));
            }
            addCard("YOUR APPS", "pinned and recent", apps, Profile.c1(), true);
            addCard("SCENES", Scenes.status().isEmpty() ? "none on" : Scenes.status(), new ScenesWidget(host),
                    Profile.c2(), false);
            addCard("SONGS", "most played, pinned", new SongsWidget(host), Profile.c3(), false);
            addCard("PROFILE", Profile.name(), new ProfileWidget(host), Profile.c1(), false);
            addCard("PEAKS", "mountains around you", new PeakWidget(host), Profile.c2(), false);
            addCard("THIS PHONE", battery() + "% battery", Widgets.create(host, "device"), Profile.c3(), false);

            page.addView(time);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(col);
            page.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
            page.addView(bar());
            addView(page, new FrameLayout.LayoutParams(-1, -1));
        }

        private void addCard(String title, String sub, View content, int stripe, boolean open) {
            LinearLayout card = new LinearLayout(host);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackground(Theme.rounded(Theme.PANEL, 20f, host));
            LinearLayout head = new LinearLayout(host);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.setPadding(dp(16), dp(14), dp(16), dp(14));
            View strip = new View(host);
            strip.setBackground(Theme.rounded(stripe | 0xFF000000, 3f, host));
            head.addView(strip, new LinearLayout.LayoutParams(dp(5), dp(30)));
            TextView t = text(title, 13f, Theme.TEXT);
            t.setPadding(dp(12), 0, 0, 0);
            head.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView s = text(sub, 10f, Theme.DIM);
            head.addView(s);
            card.addView(head, new LinearLayout.LayoutParams(-1, -2));
            FrameLayout body = new FrameLayout(host);
            body.setPadding(dp(12), 0, dp(12), dp(12));
            body.addView(content, new FrameLayout.LayoutParams(-1, -2));
            body.setVisibility(open ? VISIBLE : GONE);
            card.addView(body, new LinearLayout.LayoutParams(-1, -2));
            final View[] pair = {card, body};
            cards.add(pair);
            head.setOnClickListener(v -> {
                boolean wasOpen = body.getVisibility() == VISIBLE;
                for (View[] c : cards) {
                    c[1].setVisibility(GONE);
                }
                body.setVisibility(wasOpen ? GONE : VISIBLE);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(8);
            col.addView(card, lp);
        }

        @Override
        void tick() {
            time.setText(greeting() + "  ·  " + clock());
        }
    }

    // ================================================================== BUBBLES

    /** Your apps float around as bubbles. Push them, fling them, tap one to open it. */
    static final class Bubbles extends AltHome {
        Bubbles(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(new Field(host), new LinearLayout.LayoutParams(-1, 0, 1f));
            col.addView(bar());
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        private final class Field extends View {
            private final class B {
                AppEntry e;
                float x;
                float y;
                float vx;
                float vy;
                float r;
                Drawable icon;
            }

            private final List<B> bs = new ArrayList<>();
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private B held;
            private float lx;
            private float ly;
            private float downX;
            private float downY;
            private boolean moved;
            private long last;
            private final Runnable longPress = new Runnable() {
                @Override
                public void run() {
                    if (held != null && !moved) {
                        host.appMenu(held.e);
                        held = null;
                    }
                }
            };

            Field(Context c) {
                super(c);
                java.util.Random rnd = new java.util.Random(7);
                for (AppEntry e : appsFor(16)) {
                    B b = new B();
                    b.e = e;
                    b.icon = Theme.tint(host, e.icon);
                    b.r = dp(28 + rnd.nextInt(14));
                    b.x = dp(60) + rnd.nextFloat() * dp(240);
                    b.y = dp(120) + rnd.nextFloat() * dp(380);
                    b.vx = (rnd.nextFloat() - 0.5f) * dp(40);
                    b.vy = (rnd.nextFloat() - 0.5f) * dp(40);
                    bs.add(b);
                }
            }

            @Override
            protected void onAttachedToWindow() {
                super.onAttachedToWindow();
                last = 0;
                postOnAnimation(this::step);
            }

            private void step() {
                if (!isAttachedToWindow()) {
                    return;
                }
                long now = System.nanoTime();
                float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
                last = now;
                int w = getWidth();
                int h = getHeight();
                for (B b : bs) {
                    if (b == held) {
                        continue;
                    }
                    b.vx += (float) (Math.sin(now / 2e9 + b.r) * dp(8)) * dt;
                    b.vy += (float) (Math.cos(now / 2.3e9 + b.r) * dp(8)) * dt;
                    b.x += b.vx * dt;
                    b.y += b.vy * dt;
                    b.vx *= 0.995f;
                    b.vy *= 0.995f;
                    float top = dp(110);
                    if (b.x < b.r) {
                        b.x = b.r;
                        b.vx = Math.abs(b.vx);
                    } else if (b.x > w - b.r) {
                        b.x = w - b.r;
                        b.vx = -Math.abs(b.vx);
                    }
                    if (b.y < top + b.r) {
                        b.y = top + b.r;
                        b.vy = Math.abs(b.vy);
                    } else if (b.y > h - b.r) {
                        b.y = h - b.r;
                        b.vy = -Math.abs(b.vy);
                    }
                }
                for (int i = 0; i < bs.size(); i++) {
                    for (int j = i + 1; j < bs.size(); j++) {
                        B a = bs.get(i);
                        B c = bs.get(j);
                        float dx = c.x - a.x;
                        float dy = c.y - a.y;
                        float min = a.r + c.r;
                        float d2 = dx * dx + dy * dy;
                        if (d2 < min * min && d2 > 0.01f) {
                            float dist = (float) Math.sqrt(d2);
                            float nx = dx / dist;
                            float ny = dy / dist;
                            float push = (min - dist) / 2f;
                            if (a != held) {
                                a.x -= nx * push;
                                a.y -= ny * push;
                            }
                            if (c != held) {
                                c.x += nx * push;
                                c.y += ny * push;
                            }
                            float rel = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
                            if (rel < 0) {
                                a.vx += nx * rel;
                                a.vy += ny * rel;
                                c.vx -= nx * rel;
                                c.vy -= ny * rel;
                            }
                        }
                    }
                }
                invalidate();
                postOnAnimation(this::step);
            }

            @Override
            protected void onDraw(Canvas cv) {
                p.setTypeface(Theme.MONO);
                p.setTextAlign(Paint.Align.CENTER);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(46));
                cv.drawText(clock(), getWidth() / 2f, dp(80), p);
                p.setColor(Theme.DIM);
                p.setTextSize(dp(11));
                cv.drawText(date(), getWidth() / 2f, dp(100), p);
                for (B b : bs) {
                    p.setStyle(Paint.Style.FILL);
                    p.setColor((Theme.PANEL & 0xFFFFFF) | 0xAA000000);
                    cv.drawCircle(b.x, b.y, b.r, p);
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.5f));
                    p.setColor((Theme.ACCENT & 0xFFFFFF) | 0x66000000);
                    cv.drawCircle(b.x, b.y, b.r, p);
                    int s = (int) (b.r * 1.15f);
                    b.icon.setBounds((int) b.x - s / 2, (int) b.y - s / 2, (int) b.x + s / 2, (int) b.y + s / 2);
                    b.icon.draw(cv);
                }
            }

            private B hit(float x, float y) {
                for (int i = bs.size() - 1; i >= 0; i--) {
                    B b = bs.get(i);
                    if ((b.x - x) * (b.x - x) + (b.y - y) * (b.y - y) <= b.r * b.r) {
                        return b;
                    }
                }
                return null;
            }

            @Override
            public boolean onTouchEvent(MotionEvent e) {
                float x = e.getX();
                float y = e.getY();
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        held = hit(x, y);
                        downX = x;
                        downY = y;
                        lx = x;
                        ly = y;
                        moved = false;
                        if (held != null) {
                            held.vx = 0;
                            held.vy = 0;
                            postDelayed(longPress, 500);
                        } else {
                            // push the bubbles near a tap away
                            for (B b : bs) {
                                float dx = b.x - x;
                                float dy = b.y - y;
                                float d = (float) Math.max(dp(20), Math.hypot(dx, dy));
                                if (d < dp(180)) {
                                    float f = (dp(180) - d) / dp(180) * dp(420);
                                    b.vx += dx / d * f;
                                    b.vy += dy / d * f;
                                }
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (held != null) {
                            if (Math.hypot(x - downX, y - downY) > dp(8)) {
                                moved = true;
                                removeCallbacks(longPress);
                            }
                            held.vx = (x - lx) * 40f;
                            held.vy = (y - ly) * 40f;
                            held.x = x;
                            held.y = y;
                        }
                        lx = x;
                        ly = y;
                        return true;
                    case MotionEvent.ACTION_UP:
                        removeCallbacks(longPress);
                        if (held != null && !moved) {
                            host.launch(held.e);
                        }
                        held = null;
                        return true;
                    default:
                        removeCallbacks(longPress);
                        held = null;
                        return true;
                }
            }
        }
    }

    // ================================================================== LINES

    /** Nothing but type: a big clock and your pinned apps as plain words. Quiet and fast. */
    static final class Lines extends AltHome {
        private final TextView time;

        Lines(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(30), dp(70), dp(30), dp(26));
            time = text(clock(), 64f, Theme.TEXT);
            time.setGravity(Gravity.START);
            time.setIncludeFontPadding(false);
            col.addView(time);
            TextView day = text(date().toLowerCase(Locale.getDefault()) + "   " + battery() + "%", 12f, Theme.DIM);
            day.setGravity(Gravity.START);
            day.setPadding(0, dp(4), 0, dp(36));
            col.addView(day);
            for (final AppEntry e : appsFor(7)) {
                TextView t = text(e.label.toLowerCase(Locale.getDefault()), 28f, Theme.TEXT);
                t.setGravity(Gravity.START);
                t.setSingleLine(true);
                t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t.setPadding(0, dp(7), 0, dp(7));
                t.setClickable(true);
                t.setOnClickListener(v -> host.launch(e));
                t.setOnLongClickListener(v -> {
                    host.appMenu(e);
                    return true;
                });
                col.addView(t);
            }
            col.addView(new View(host), new LinearLayout.LayoutParams(-1, 0, 1f));
            LinearLayout row = new LinearLayout(host);
            String[] names = {"all apps", "profile", "terminal", "settings"};
            Runnable[] acts = {() -> host.showDrawer(), () -> host.showOverlay(new ProfileScreen(host)),
                () -> host.showTerminal(), () -> host.showSettings()};
            for (int i = 0; i < names.length; i++) {
                TextView t = text(names[i], 13f, i == 0 ? Theme.ACCENT : Theme.DIM);
                t.setPadding(0, dp(10), dp(18), dp(10));
                final Runnable r = acts[i];
                t.setOnClickListener(v -> r.run());
                row.addView(t);
            }
            col.addView(row);
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }

    // ================================================================== DOCK

    /** The familiar phone layout: a small clock, a search pill, a grid of icons and a floating dock of four. */
    static final class Dock extends AltHome {
        private final TextView time;

        Dock(NovaActivity host) {
            super(host);
            LinearLayout col = new LinearLayout(host);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(48), dp(16), dp(16));
            LinearLayout top = new LinearLayout(host);
            top.setGravity(Gravity.CENTER_VERTICAL);
            time = text(clock(), 38f, Theme.TEXT);
            top.addView(time);
            LinearLayout side = new LinearLayout(host);
            side.setOrientation(LinearLayout.VERTICAL);
            side.setPadding(dp(14), 0, 0, 0);
            TextView d = text(date(), 12f, Theme.TEXT);
            d.setGravity(Gravity.START);
            side.addView(d);
            TextView b = text(battery() + "% battery", 10f, Theme.DIM);
            b.setGravity(Gravity.START);
            side.addView(b);
            top.addView(side);
            col.addView(top, new LinearLayout.LayoutParams(-1, -2));

            TextView search = text("search apps", 13f, Theme.DIM);
            search.setGravity(Gravity.CENTER_VERTICAL);
            search.setPadding(dp(18), dp(13), dp(18), dp(13));
            search.setBackground(Theme.rounded(Theme.PANEL, 24f, host));
            search.setOnClickListener(v -> host.showDrawer());
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
            sp.topMargin = dp(16);
            col.addView(search, sp);

            List<AppEntry> apps = appsFor(20);
            int dockN = Math.min(4, apps.size());
            LinearLayout rows = new LinearLayout(host);
            rows.setOrientation(LinearLayout.VERTICAL);
            for (int r = 0; r < 4; r++) {
                LinearLayout line = new LinearLayout(host);
                for (int c = 0; c < 4; c++) {
                    int idx = dockN + r * 4 + c;
                    if (idx < apps.size()) {
                        line.addView(appTile(apps.get(idx), 52, true), new LinearLayout.LayoutParams(0, -2, 1f));
                    } else {
                        line.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
                    }
                }
                rows.addView(line, new LinearLayout.LayoutParams(-1, -2));
            }
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, 0, 1f);
            gp.topMargin = dp(14);
            ScrollView sv = new ScrollView(host);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(rows);
            col.addView(sv, gp);

            LinearLayout dock = new LinearLayout(host);
            dock.setGravity(Gravity.CENTER);
            dock.setPadding(dp(8), dp(6), dp(8), dp(6));
            dock.setBackground(Theme.rounded(Theme.PANEL, 30f, host));
            for (int i = 0; i < dockN; i++) {
                dock.addView(appTile(apps.get(i), 52, false), new LinearLayout.LayoutParams(0, -2, 1f));
            }
            TextView more = text("\u22EF", 26f, Theme.ACCENT);
            more.setGravity(Gravity.CENTER);
            more.setOnClickListener(v -> host.showDrawer());
            dock.addView(more, new LinearLayout.LayoutParams(0, dp(64), 1f));
            LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, -2);
            dp2.topMargin = dp(8);
            col.addView(dock, dp2);
            addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override
        void tick() {
            time.setText(clock());
        }
    }
}
