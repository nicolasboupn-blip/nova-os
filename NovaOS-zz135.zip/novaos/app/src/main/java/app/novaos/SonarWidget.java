package app.novaos;

import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.SystemClock;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * SONAR: the phone as a people radar, no extra chip. The speaker sends a silent ultrasound chirp (18-21 kHz) ten times
 * a second, the microphone hears the echoes, and NOVA works out how far away the things are that bounce it back. Still
 * things (walls, furniture) are learned and taken away, so only what MOVES shows up as a dot. One phone knows the
 * distance, not the direction, so the dots sit on rings: the ring is the real distance.
 */
final class SonarWidget extends NovaWidget {
    private static final String K_RANGE = "sonar_range";
    private static final String K_SENS = "sonar_sens";
    private static final String K_ALERT = "sonar_alert";
    private static final float[] RANGES = {3f, 5f, 8f};
    private static final float[] SENS = {6f, 3.5f, 2.2f};
    private static final String[] SENS_NAMES = {"LOW", "MID", "HIGH"};

    private final Radar radar;
    private final TextView status;
    private final TextView go;
    private final TextView rangeChip;
    private final TextView sensChip;
    private final TextView alertChip;
    private volatile Engine engine;

    SonarWidget(NovaActivity host) {
        super(host);
        radar = new Radar();
        radar.setOnClickListener(v -> toggle());
        status = text("Tap START (or the radar). Lay the phone flat, speaker free, media volume up.", 10f, Theme.DIM);
        status.setPadding(dp(6), dp(2), dp(6), dp(2));
        LinearLayout r = row();
        go = chip("START", this::toggle);
        rangeChip = chip("", () -> {
            Prefs.putInt(K_RANGE, (range() + 1) % RANGES.length);
            label();
            restartIfRunning();
        });
        sensChip = chip("", () -> {
            Prefs.putInt(K_SENS, (Prefs.getInt(K_SENS, 1) + 1) % SENS.length);
            label();
        });
        alertChip = chip("", () -> {
            Prefs.putBool(K_ALERT, !Prefs.getBool(K_ALERT, false));
            label();
        });
        TextView[] all = {go, rangeChip, sensChip, alertChip};
        for (TextView t : all) {
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(t, p);
        }
        // buttons first so they are always visible, even in the small main box
        addView(r, wide());
        addView(status, wide());
        addView(radar, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(150)));
        label();
    }

    private int range() {
        return Math.max(0, Math.min(RANGES.length - 1, Prefs.getInt(K_RANGE, 1)));
    }

    private void label() {
        rangeChip.setText(String.format(Locale.ROOT, "%.0f M", RANGES[range()]));
        sensChip.setText(SENS_NAMES[Math.max(0, Math.min(2, Prefs.getInt(K_SENS, 1)))]);
        alertChip.setText(Prefs.getBool(K_ALERT, false) ? "ALERT ON" : "ALERT OFF");
        go.setText(engine != null ? "STOP" : "START");
        pick(go, engine != null);
    }

    private void toggle() {
        if (engine != null) {
            stop();
            status.setText("Stopped.");
        } else {
            if (host.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                start();
            } else {
                host.ask(new String[] {android.Manifest.permission.RECORD_AUDIO}, this::start,
                        () -> status.setText("SONAR needs the microphone to hear the echoes."));
            }
        }
        label();
    }

    private void restartIfRunning() {
        if (engine != null) {
            stop();
            start();
        }
    }

    private void start() {
        if (engine != null) {
            return;
        }
        engine = new Engine(RANGES[range()]);
        engine.begin();
        status.setText("Listening… hold still for 2 seconds so it can learn the room.");
        label();
    }

    private void stop() {
        Engine e = engine;
        engine = null;
        if (e != null) {
            e.end();
        }
        radar.invalidate();
        label();
    }

    @Override
    void onLive(boolean on) {
        if (!on) {
            stop();
        }
    }

    // ================================================================== the sound part

    /** One moving thing the sonar is following. */
    static final class Track {
        float dist;
        float speed;
        float angle;
        float strength;
        long seen;
        long born;
    }

    private final class Engine {
        static final int FS = 48000;
        static final int P = 4800;
        static final int M = 240;
        static final int BIN = 8;
        final float maxRange;
        final int len;
        final int bins;
        final float[] tc = new float[M];
        final float[] ts = new float[M];
        final float[] buf = new float[3 * P];
        static final int STEP = 2;
        final int pts;
        final float[] prevC;
        final float[] prevS;
        final float[] inst;
        boolean havePrev;
        final float[] diff;
        final List<Track> tracks = new ArrayList<>();
        final float[][] fall = new float[60][];
        int fallAt;
        volatile boolean running;
        int direct = -1;
        int frames;
        float quality;
        AudioTrack out;
        AudioRecord in;
        Thread player;
        Thread listener;
        final Random rng = new Random();
        String problem;

        Engine(float maxRange) {
            this.maxRange = maxRange;
            len = (int) (2 * maxRange / 343f * FS) + BIN;
            bins = len / BIN;
            pts = bins * BIN / STEP;
            prevC = new float[pts];
            prevS = new float[pts];
            inst = new float[pts];
            diff = new float[bins];
            for (int m = 0; m < M; m++) {
                double t = m / (double) FS;
                double dur = M / (double) FS;
                double f0 = 18000;
                double f1 = 21000;
                double ph = 2 * Math.PI * (f0 * t + (f1 - f0) * t * t / (2 * dur));
                double w = 0.5 - 0.5 * Math.cos(2 * Math.PI * m / (M - 1));
                tc[m] = (float) (Math.cos(ph) * w);
                ts[m] = (float) (Math.sin(ph) * w);
            }
        }

        void begin() {
            running = true;
            try {
                int minOut = AudioTrack.getMinBufferSize(FS, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                out = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(FS)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(Math.max(minOut, P * 4))
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build();
                int src = MediaRecorder.AudioSource.VOICE_RECOGNITION;
                AudioManager am = (AudioManager) host.getSystemService(android.content.Context.AUDIO_SERVICE);
                if (am != null && "true".equals(am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED))) {
                    src = MediaRecorder.AudioSource.UNPROCESSED;
                }
                int minIn = AudioRecord.getMinBufferSize(FS, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                in = new AudioRecord(src, FS, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        Math.max(minIn, P * 8));
                if (in.getState() != AudioRecord.STATE_INITIALIZED) {
                    throw new IllegalStateException("microphone busy");
                }
            } catch (RuntimeException e) {
                problem = "Could not start: " + e.getMessage();
                running = false;
                ui.post(() -> {
                    status.setText(problem);
                    stop();
                });
                return;
            }
            final short[] ping = new short[P];
            for (int m = 0; m < M; m++) {
                ping[m] = (short) (tc[m] * 26000);
            }
            player = new Thread(() -> {
                try {
                    out.play();
                    while (running) {
                        out.write(ping, 0, P);
                    }
                } catch (RuntimeException ignored) {
                    // stopped
                }
            }, "nova-sonar-out");
            listener = new Thread(this::listen, "nova-sonar-in");
            player.start();
            listener.start();
        }

        void end() {
            running = false;
            try {
                if (out != null) {
                    out.pause();
                    out.flush();
                }
            } catch (RuntimeException ignored) {
                // gone
            }
            new Thread(() -> {
                try {
                    if (player != null) {
                        player.join(400);
                    }
                    if (listener != null) {
                        listener.join(400);
                    }
                } catch (InterruptedException ignored) {
                    // fine
                }
                try {
                    if (out != null) {
                        out.release();
                    }
                    if (in != null) {
                        in.release();
                    }
                } catch (RuntimeException ignored) {
                    // gone
                }
            }).start();
        }

        private void listen() {
            short[] block = new short[P];
            try {
                in.startRecording();
                while (running) {
                    int got = 0;
                    while (got < P && running) {
                        int n = in.read(block, got, P - got);
                        if (n <= 0) {
                            throw new IllegalStateException("microphone stopped");
                        }
                        got += n;
                    }
                    System.arraycopy(buf, P, buf, 0, 2 * P);
                    for (int i = 0; i < P; i++) {
                        buf[2 * P + i] = block[i] / 32768f;
                    }
                    if (++frames >= 3) {
                        process();
                    }
                }
                in.stop();
            } catch (RuntimeException e) {
                if (running) {
                    problem = "Microphone problem: " + e.getMessage();
                    ui.post(() -> {
                        status.setText(problem);
                        stop();
                    });
                }
            }
        }

        private float mag(int start) {
            float c = 0;
            float s = 0;
            for (int m = 0; m < M; m++) {
                float v = buf[start + m];
                c += v * tc[m];
                s += v * ts[m];
            }
            return (float) Math.sqrt(c * c + s * s);
        }

        /** Finds our own ping (the loudest thing) in the middle block, then reads the echoes after it. */
        private void process() {
            int from = P;
            int to = 2 * P;
            if (direct >= 0) {
                from = Math.max(P / 2, direct - 60);
                to = Math.min(2 * P, direct + 60);
            }
            float best = 0;
            int at = -1;
            for (int i = from; i < to; i++) {
                float v = mag(i);
                if (v > best) {
                    best = v;
                    at = i;
                }
            }
            if (at < 0 || at + len + M >= buf.length) {
                direct = -1;
                return;
            }
            // how clearly we hear ourselves: the ping against the quiet part before it
            float floor = 0;
            int n = 0;
            for (int i = Math.max(P / 2, at - P / 2); i < at - M; i += 37) {
                floor += mag(i);
                n++;
            }
            floor = n > 0 ? floor / n : 1e-6f;
            quality = quality * 0.8f + 0.2f * (best / Math.max(1e-6f, floor));
            if (direct >= 0 && Math.abs(at - direct) > 6 && Math.abs(at - direct) < P - 200) {
                // the timing jumped: the old phases mean nothing now
                havePrev = false;
            }
            // the ping repeats every P samples: keep the search window away from the edges as the clocks drift
            direct = at > 2 * P - 80 ? at - P : at < P / 2 + 80 ? at + P : at;
            // echo picture as I/Q (strength AND phase). At 20 kHz one wavelength is about 1.7 cm, so the phase of an
            // echo jumps as soon as something there moves, even a little. Still things keep their phase and give 0.
            float rc = 0;
            float rs = 0;
            for (int m = 0; m < M; m++) {
                float v = buf[at + m];
                rc += v * tc[m];
                rs += v * ts[m];
            }
            float rmag = (float) Math.sqrt(rc * rc + rs * rs) + 1e-9f;
            // turn everything so our own ping has phase 0: small timing wobbles then cancel out
            float uc = rc / rmag;
            float us = -rs / rmag;
            int skip = (int) (2 * 0.3f / 343f * FS);
            boolean fresh = !havePrev;
            for (int pnt = 0; pnt < pts; pnt++) {
                int off = pnt * STEP;
                float c = 0;
                float sn = 0;
                int base = at + off;
                for (int m = 0; m < M; m++) {
                    float v = buf[base + m];
                    c += v * tc[m];
                    sn += v * ts[m];
                }
                float zc = (c * uc - sn * us) / rmag;
                float zs = (c * us + sn * uc) / rmag;
                float dc = zc - prevC[pnt];
                float ds = zs - prevS[pnt];
                prevC[pnt] = zc;
                prevS[pnt] = zs;
                inst[pnt] = fresh || off < skip ? 0 : (float) Math.sqrt(dc * dc + ds * ds);
            }
            havePrev = true;
            for (int b = 0; b < bins; b++) {
                float mx = 0;
                int p0 = b * BIN / STEP;
                int p1 = Math.min(pts, (b + 1) * BIN / STEP);
                for (int q = p0; q < p1; q++) {
                    mx = Math.max(mx, inst[q]);
                }
                // a little memory so a dot does not blink
                diff[b] = diff[b] * 0.45f + mx * 0.55f;
            }
            float[] sorted = diff.clone();
            Arrays.sort(sorted);
            float med = sorted[sorted.length / 2] + 1e-7f;
            float k = SENS[Math.max(0, Math.min(2, Prefs.getInt(K_SENS, 1)))];
            float thr = Math.max(med * k, 0.0008f);
            boolean learning = frames < 8;
            // waterfall row
            float[] row = new float[64];
            for (int i = 0; i < 64; i++) {
                int b0 = i * bins / 64;
                int b1 = Math.max(b0 + 1, (i + 1) * bins / 64);
                float mx = 0;
                for (int b = b0; b < b1; b++) {
                    mx = Math.max(mx, diff[b]);
                }
                row[i] = Math.min(1f, mx / (thr * 2f));
            }
            synchronized (this) {
                fall[fallAt] = row;
                fallAt = (fallAt + 1) % fall.length;
            }
            if (learning) {
                return;
            }
            // up to three moving things, at least 40 cm apart
            List<float[]> found = new ArrayList<>();
            boolean[] used = new boolean[bins];
            int gap = (int) (2 * 0.4f / 343f * FS / BIN);
            for (int pass = 0; pass < 3; pass++) {
                float mx = thr;
                int mb = -1;
                for (int b = 0; b < bins; b++) {
                    if (!used[b] && diff[b] > mx) {
                        mx = diff[b];
                        mb = b;
                    }
                }
                if (mb < 0) {
                    break;
                }
                for (int b = Math.max(0, mb - gap); b < Math.min(bins, mb + gap); b++) {
                    used[b] = true;
                }
                float d = (mb * BIN + BIN / 2f) / FS * 343f / 2f;
                found.add(new float[] {d, mx / thr});
            }
            long now = SystemClock.uptimeMillis();
            boolean newcomer = false;
            synchronized (this) {
                for (float[] f : found) {
                    Track best0 = null;
                    float bd = 0.6f;
                    for (Track t : tracks) {
                        float dd = Math.abs(t.dist - f[0]);
                        if (dd < bd) {
                            bd = dd;
                            best0 = t;
                        }
                    }
                    if (best0 == null) {
                        best0 = new Track();
                        best0.dist = f[0];
                        best0.angle = -150 + rng.nextFloat() * 120;
                        best0.born = now;
                        tracks.add(best0);
                        newcomer = true;
                    }
                    float old = best0.dist;
                    best0.dist = best0.dist * 0.55f + f[0] * 0.45f;
                    best0.speed = best0.speed * 0.7f + (best0.dist - old) * 10f * 0.3f;
                    best0.strength = f[1];
                    best0.seen = now;
                }
                for (int i = tracks.size() - 1; i >= 0; i--) {
                    if (now - tracks.get(i).seen > 900) {
                        tracks.remove(i);
                    }
                }
            }
            if (newcomer && Prefs.getBool(K_ALERT, false)) {
                ui.post(() -> host.buzz(60));
            }
        }
    }

    // ================================================================== the picture

    private final class Radar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long lastText;

        Radar() {
            super(host);
        }

        @Override
        protected void onDraw(Canvas c) {
            Engine e = engine;
            float w = getWidth();
            float h = getHeight();
            float fallH = dp(34);
            float rh = h - fallH - dp(6);
            float cx = w / 2f;
            float cy = rh;
            float R = Math.min(w / 2f - dp(8), rh - dp(6));
            float range = e != null ? e.maxRange : RANGES[range()];
            int acc = Theme.ACCENT;
            // rings, one per metre
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setTextSize(dp(8));
            p.setTypeface(Theme.MONO);
            for (int m = 1; m <= (int) range; m++) {
                float rr = R * m / range;
                p.setColor((acc & 0x00FFFFFF) | 0x40000000);
                c.drawArc(new RectF(cx - rr, cy - rr, cx + rr, cy + rr), 180, 180, false, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor((acc & 0x00FFFFFF) | 0x80000000);
                c.drawText(m + "m", cx + rr - dp(12), cy - dp(2), p);
                p.setStyle(Paint.Style.STROKE);
            }
            c.drawLine(cx - R, cy, cx + R, cy, p);
            // sweep
            long t = SystemClock.uptimeMillis();
            if (e != null) {
                float sw = 180 + (t % 2400) / 2400f * 180;
                for (int i = 0; i < 18; i++) {
                    double a = Math.toRadians(sw - i * 2);
                    p.setColor((acc & 0x00FFFFFF) | ((int) (90 * (1 - i / 18f)) << 24));
                    p.setStrokeWidth(dp(2));
                    c.drawLine(cx, cy, cx + (float) Math.cos(a) * R, cy + (float) Math.sin(a) * R, p);
                }
            }
            // the phone
            p.setStyle(Paint.Style.FILL);
            p.setColor(Theme.TEXT);
            c.drawCircle(cx, cy, dp(3), p);
            // dots
            List<Track> copy = new ArrayList<>();
            float[][] rows = null;
            int at = 0;
            if (e != null) {
                synchronized (e) {
                    for (Track tr : e.tracks) {
                        Track k = new Track();
                        k.dist = tr.dist;
                        k.speed = tr.speed;
                        k.angle = tr.angle;
                        k.strength = tr.strength;
                        k.seen = tr.seen;
                        copy.add(k);
                    }
                    rows = e.fall.clone();
                    at = e.fallAt;
                }
            }
            for (Track tr : copy) {
                float rr = R * Math.min(1f, tr.dist / range);
                double a = Math.toRadians(tr.angle);
                float x = cx + (float) Math.cos(a) * rr;
                float y = cy + (float) Math.sin(a) * rr;
                float fade = Math.max(0.2f, 1f - (t - tr.seen) / 900f);
                int col = tr.speed < -0.15f ? 0xFFFF453A : tr.speed > 0.15f ? 0xFF34C759 : 0xFFFFC21A;
                p.setColor((col & 0x00FFFFFF) | ((int) (70 * fade) << 24));
                c.drawCircle(x, y, dp(12), p);
                p.setColor((col & 0x00FFFFFF) | ((int) (255 * fade) << 24));
                c.drawCircle(x, y, dp(5), p);
                // its ring, so you can read the real distance
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1));
                p.setColor((col & 0x00FFFFFF) | ((int) (60 * fade) << 24));
                c.drawArc(new RectF(cx - rr, cy - rr, cx + rr, cy + rr), 180, 180, false, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Theme.TEXT);
                p.setTextSize(dp(9));
                c.drawText(String.format(Locale.ROOT, "%.1fm", tr.dist), x + dp(8), y - dp(6), p);
            }
            // waterfall: distance left to right, newest on top
            float fy = h - fallH;
            p.setColor(0x22FFFFFF);
            c.drawRect(dp(8), fy, w - dp(8), h, p);
            if (rows != null) {
                float cw = (w - dp(16)) / 64f;
                float chh = fallH / 20f;
                for (int r = 0; r < 20; r++) {
                    float[] row = rows[((at - 1 - r) % rows.length + rows.length) % rows.length];
                    if (row == null) {
                        continue;
                    }
                    for (int i = 0; i < 64; i++) {
                        float v = row[i];
                        if (v < 0.08f) {
                            continue;
                        }
                        p.setColor((acc & 0x00FFFFFF) | ((int) (255 * v) << 24));
                        c.drawRect(dp(8) + i * cw, fy + r * chh, dp(8) + (i + 1) * cw, fy + (r + 1) * chh, p);
                    }
                }
            }
            p.setColor(Theme.DIM);
            p.setTextSize(dp(8));
            c.drawText("0m", dp(10), fy - dp(2), p);
            String rl = String.format(Locale.ROOT, "%.0fm", range);
            c.drawText(rl, w - dp(10) - p.measureText(rl), fy - dp(2), p);
            // words
            if (e != null && t - lastText > 400) {
                lastText = t;
                final String msg;
                if (e.frames < 8) {
                    msg = "Learning the room… keep still";
                } else if (e.quality < 3f) {
                    msg = "Can't hear its own ping: turn MEDIA volume up, and don't cover the speaker or mic";
                } else if (copy.isEmpty()) {
                    msg = "Nothing moving. (Ring = distance; one phone can't tell direction.)";
                } else {
                    Track n = copy.get(0);
                    for (Track tr : copy) {
                        if (tr.dist < n.dist) {
                            n = tr;
                        }
                    }
                    String way = n.speed < -0.15f ? "coming closer" : n.speed > 0.15f ? "going away" : "moving";
                    msg = copy.size() + (copy.size() == 1 ? " thing" : " things") + " moving · nearest "
                            + String.format(Locale.ROOT, "%.1f m", n.dist) + ", " + way;
                }
                ui.post(() -> status.setText(msg));
            }
            if (e != null) {
                postInvalidateDelayed(40);
            }
        }
    }

    static int dim(int c) {
        return Color.argb(80, Color.red(c), Color.green(c), Color.blue(c));
    }
}
