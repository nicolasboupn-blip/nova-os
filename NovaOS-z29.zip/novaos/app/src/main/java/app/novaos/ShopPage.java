package app.novaos;

import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Random;

/** Status panel page: shop shortcut and a free daily lucky spin. */
final class ShopPage extends LinearLayout {
    private final NovaActivity host;
    private final TextView info;
    private final TextView spin;
    private final AvatarView me;

    ShopPage(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
        setPadding(Theme.dp(host, 20), Theme.dp(host, 6), Theme.dp(host, 20), Theme.dp(host, 6));
        info = new TextView(host);
        info.setTypeface(Theme.MONO);
        info.setTextSize(12f);
        info.setTextColor(Theme.TEXT);
        info.setGravity(Gravity.CENTER);
        LinearLayout top = new LinearLayout(host);
        top.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        me = new AvatarView(host, Math.max(2, Math.round(host.getResources().getDisplayMetrics().density * 1.5f)));
        me.setClickable(true);
        me.setOnClickListener(v -> AvatarEditor.open(host));
        top.addView(me, new LayoutParams(-2, -2));
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(Theme.dp(host, 14), 0, 0, 0);
        top.addView(info, new LayoutParams(-2, -2));
        top.setPadding(0, 0, 0, Theme.dp(host, 10));
        addView(top);
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        spin = button("DAILY SPIN", true, v -> doSpin());
        row.addView(spin);
        row.addView(button("COIN SHOP", false, v -> CoinShop.open(host)));
        addView(row);
        LinearLayout row2 = new LinearLayout(host);
        row2.setGravity(Gravity.CENTER);
        row2.setPadding(0, Theme.dp(host, 6), 0, 0);
        row2.addView(button("MY CHARACTER", false, v -> AvatarEditor.open(host)));
        addView(row2);
        refresh();
    }

    private TextView button(String s, boolean main, OnClickListener l) {
        TextView b = new TextView(host);
        b.setText(s);
        b.setTypeface(Theme.MONO);
        b.setTextSize(12f);
        b.setTextColor(main ? Theme.BG : Theme.TEXT);
        b.setBackground(Theme.rounded(main ? Theme.ACCENT : 0x26FFFFFF, 14f, host));
        b.setPadding(Theme.dp(host, 16), Theme.dp(host, 9), Theme.dp(host, 16), Theme.dp(host, 9));
        LayoutParams lp = new LayoutParams(-2, -2);
        lp.leftMargin = lp.rightMargin = Theme.dp(host, 5);
        b.setLayoutParams(lp);
        b.setClickable(true);
        b.setOnClickListener(l);
        return b;
    }

    private static int today() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
    }

    private boolean spun() {
        return Prefs.getInt("spin_day", 0) == today() && !Castle.admin();
    }

    private void doSpin() {
        if (spun()) {
            host.toast("Already spun today. Come back tomorrow!");
            return;
        }
        Prefs.putInt("spin_day", today());
        int r = new Random().nextInt(100);
        String msg;
        if (r < 40) {
            int n = Coins.earn(15);
            msg = "Spin: " + n + " coins";
        } else if (r < 70) {
            int n = Coins.earn(40);
            msg = "Spin: " + n + " coins";
        } else if (r < 88) {
            int n = Coins.earn(90);
            msg = "Spin: " + n + " coins!";
        } else if (r < 96) {
            Shop.addShield();
            msg = "Spin: a streak shield!";
        } else {
            int n = Coins.earn(400);
            msg = "JACKPOT! " + n + " coins!!";
            host.confetti(host.root.getWidth() / 2f, host.root.getHeight() * 0.35f);
        }
        Sfx.play(Sfx.WIN);
        host.wizardSay(msg);
        refresh();
    }

    void refresh() {
        String s = "Coins: " + Coins.get() + "   " + Shop.titleName();
        if (Shop.boostMinutes() > 0) {
            s += "\nx2 coins: " + Shop.boostText() + " left";
        }
        if (Shop.bank() > 0) {
            s += "\nBank: " + Shop.bank();
        }
        info.setText(s);
        me.reload();
        spin.setAlpha(spun() ? 0.4f : 1f);
    }
}
