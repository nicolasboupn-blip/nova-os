package app.novaos;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Scenes: one tap changes the volume, ringer, brightness, the look of NOVA, the accent colour and can start a song.
 * The active scene is your status on the profile. A scene can have a start time; with the clock switch on, NOVA
 * moves to the scene whose time has come (it checks while NOVA is open or comes back to the front).
 */
final class Scenes {
    private Scenes() {}

    static final String K_AUTO = "scenes_auto";
    private static final String KEY = "scenes_v1";
    private static final String K_ACTIVE = "scene_active";
    private static final String K_AUTOKEY = "scene_autokey";

    static final String[] RINGER = {"No change", "Normal", "Vibrate"};
    static final String[] LOOKS = {"No change", "Normal", "Aurora", "Terminal", "Block", "My style"};

    static final class Scene {
        String name = "New scene";
        String emoji = "✨";
        int volume = -1;      // 0 to 100, or -1 for no change
        int brightness = -1;  // 1 to 100, or -1
        int ringer;           // 0 no change, 1 normal, 2 vibrate
        int look;             // 0 no change, then UiStyle id + 1
        int accent = -1;      // accent preset 0..13, or -1
        String link = "";     // a Spotify link or web link to open
        int from = -1;        // minute of the day it starts, or -1
        int days;             // 0 every day, 1 weekdays, 2 weekends
    }

    private static List<Scene> cache;

    static boolean autoOn() {
        return Prefs.getBool(K_AUTO, false);
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    static List<Scene> all() {
        if (cache != null) {
            return cache;
        }
        List<Scene> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw.isEmpty()) {
            out = defaults();
        } else {
            for (String line : raw.split("\n")) {
                String[] p = line.split("\t", -1);
                if (p.length < 11) {
                    continue;
                }
                try {
                    Scene s = new Scene();
                    s.name = p[0];
                    s.emoji = p[1];
                    s.volume = Integer.parseInt(p[2]);
                    s.brightness = Integer.parseInt(p[3]);
                    s.ringer = Integer.parseInt(p[4]);
                    s.look = Integer.parseInt(p[5]);
                    s.accent = Integer.parseInt(p[6]);
                    s.link = p[7];
                    s.from = Integer.parseInt(p[8]);
                    s.days = Integer.parseInt(p[9]);
                    out.add(s);
                } catch (NumberFormatException ignored) {
                    // skip a broken line
                }
            }
            if (out.isEmpty()) {
                out = defaults();
            }
        }
        cache = out;
        return out;
    }

    private static Scene mk(String name, String emoji, int vol, int brt, int ringer, int look, int from) {
        Scene s = new Scene();
        s.name = name;
        s.emoji = emoji;
        s.volume = vol;
        s.brightness = brt;
        s.ringer = ringer;
        s.look = look;
        s.from = from;
        return s;
    }

    private static List<Scene> defaults() {
        List<Scene> d = new ArrayList<>();
        d.add(mk("Morning", "☀️", 50, 70, 1, 1, 7 * 60));
        d.add(mk("Study", "📚", 20, 60, 2, 1, -1));
        d.add(mk("Gaming", "🎮", 80, 100, 1, 4, -1));
        d.add(mk("Chill", "🍃", 40, 50, 1, 2, -1));
        d.add(mk("Sleep", "🌙", 0, 5, 2, 3, 22 * 60 + 30));
        return d;
    }

    static void save() {
        List<String> lines = new ArrayList<>();
        for (Scene s : all()) {
            lines.add(clean(s.name) + "\t" + clean(s.emoji) + "\t" + s.volume + "\t" + s.brightness + "\t" + s.ringer
                    + "\t" + s.look + "\t" + s.accent + "\t" + clean(s.link) + "\t" + s.from + "\t" + s.days + "\t0");
        }
        Prefs.putString(KEY, TextUtils.join("\n", lines));
    }

    static void resetAll() {
        cache = defaults();
        save();
    }

    /** The scene that is on now, or null. */
    static Scene active() {
        int i = Prefs.getInt(K_ACTIVE, -1);
        List<Scene> a = all();
        return i >= 0 && i < a.size() ? a.get(i) : null;
    }

    static int activeIndex() {
        return Prefs.getInt(K_ACTIVE, -1);
    }

    static String status() {
        Scene s = active();
        return s == null ? "" : s.emoji + " " + s.name;
    }

    static String describe(Scene s) {
        List<String> p = new ArrayList<>();
        if (s.volume >= 0) {
            p.add("vol " + s.volume + "%");
        }
        if (s.brightness >= 0) {
            p.add("light " + s.brightness + "%");
        }
        if (s.ringer > 0) {
            p.add(RINGER[s.ringer].toLowerCase(java.util.Locale.ROOT));
        }
        if (s.look > 0) {
            p.add(LOOKS[s.look].toLowerCase(java.util.Locale.ROOT));
        }
        if (s.accent >= 0 && s.accent < Theme.PRESET_NAMES.length) {
            p.add(Theme.PRESET_NAMES[s.accent].toLowerCase(java.util.Locale.ROOT));
        }
        if (!s.link.isEmpty()) {
            p.add("plays a link");
        }
        if (s.from >= 0) {
            p.add("from " + time(s.from) + (s.days == 1 ? " on weekdays" : s.days == 2 ? " on weekends" : ""));
        }
        return p.isEmpty() ? "changes nothing" : TextUtils.join("  ·  ", p);
    }

    static String time(int minute) {
        return String.format(java.util.Locale.ROOT, "%02d:%02d", minute / 60, minute % 60);
    }

    // ------------------------------------------------------------------ switching

    static void apply(NovaActivity host, int index) {
        List<Scene> all = all();
        if (index < 0 || index >= all.size()) {
            return;
        }
        Scene s = all.get(index);
        Prefs.putInt(K_ACTIVE, index);
        boolean lookChanged = false;
        if (s.look > 0) {
            int style = s.look - 1;
            if (style == UiStyle.CUSTOM && !UiStyle.designerOn()) {
                style = UiStyle.NORMAL;
            }
            if (Prefs.getInt(UiStyle.K_STYLE, 0) != style) {
                Prefs.putInt(UiStyle.K_STYLE, style);
                lookChanged = true;
            }
        }
        if (s.accent >= 0 && s.accent < Theme.PRESET_NAMES.length && Prefs.accent() != s.accent) {
            Prefs.putInt(Prefs.K_ACCENT, s.accent);
            lookChanged = true;
        }
        AudioManager am = (AudioManager) host.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            try {
                if (s.volume >= 0) {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC,
                            Math.round(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * s.volume / 100f), 0);
                }
                if (s.ringer == 1) {
                    am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                } else if (s.ringer == 2) {
                    am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                }
            } catch (RuntimeException ignored) {
                // Android refused (do not disturb is on), the rest of the scene still applies
            }
        }
        if (s.brightness >= 0) {
            brightness(host, s.brightness);
        }
        if (!s.link.isEmpty()) {
            DeckBinds.playLink(host, s.link);
        }
        host.toast("Scene: " + s.emoji + " " + s.name);
        if (lookChanged) {
            Theme.load();
            host.showHome();
        }
    }

    private static void brightness(NovaActivity host, int pct) {
        int v = Math.max(1, Math.min(100, pct));
        try {
            if (Settings.System.canWrite(host)) {
                Settings.System.putInt(host.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(host.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
                        Math.round(255f * v / 100f));
                return;
            }
        } catch (RuntimeException ignored) {
            // fall back to this window
        }
        // without the write-settings permission only NOVA's own window changes
        android.view.WindowManager.LayoutParams lp = host.getWindow().getAttributes();
        lp.screenBrightness = v / 100f;
        host.getWindow().setAttributes(lp);
    }

    // ------------------------------------------------------------------ the clock

    private static final Handler ui = new Handler(Looper.getMainLooper());
    private static Runnable watch;

    /** Starts checking the scene times once a minute while NOVA is on screen. */
    static void startWatch(final NovaActivity host) {
        stopWatch();
        watch = new Runnable() {
            @Override
            public void run() {
                checkAuto(host);
                ui.postDelayed(this, 60000);
            }
        };
        ui.post(watch);
    }

    static void stopWatch() {
        if (watch != null) {
            ui.removeCallbacks(watch);
            watch = null;
        }
    }

    static void checkAuto(NovaActivity host) {
        if (!autoOn()) {
            return;
        }
        Calendar c = Calendar.getInstance();
        int now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int dow = c.get(Calendar.DAY_OF_WEEK);
        boolean weekend = dow == Calendar.SATURDAY || dow == Calendar.SUNDAY;
        List<Scene> all = all();
        int best = -1;
        for (int i = 0; i < all.size(); i++) {
            Scene s = all.get(i);
            if (s.from < 0 || s.from > now) {
                continue;
            }
            if (s.days == 1 && weekend || s.days == 2 && !weekend) {
                continue;
            }
            if (best < 0 || s.from > all.get(best).from) {
                best = i;
            }
        }
        if (best < 0) {
            return;
        }
        String key = c.get(Calendar.YEAR) + "-" + c.get(Calendar.DAY_OF_YEAR) + ":" + best;
        if (!key.equals(Prefs.getString(K_AUTOKEY, ""))) {
            Prefs.putString(K_AUTOKEY, key);
            apply(host, best);
        }
    }
}
