package app.novaos;

import android.app.AlertDialog;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Your profile, shown like a Discord profile, with the editor right under it. */
final class ProfileScreen extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final LinearLayout col;

    ProfileScreen(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(48), dp(12), dp(40));
        sv.addView(col);
        addView(sv, new FrameLayout.LayoutParams(-1, -1));
        build();
    }

    /** Rebuild everything, e.g. after picking a banner picture. */
    void build() {
        col.removeAllViews();
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("PROFILE", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.15f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("SCENES", () -> host.showOverlay(new ScenesScreen(host))));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ProfileCard card = new ProfileCard(host, false);
        card.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        card.setClipToOutline(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(10);
        col.addView(card, cp);

        col.addView(heading("EDIT"));
        col.addView(row("Name and about me", "EDIT", this::editText));
        col.addView(row("Avatar", "OPEN", () -> AvatarEditor.open(host)));
        col.addView(cycler("Banner", Profile.BANNER_MODES, Profile.K_MODE, Profile.mode()));
        if (Profile.mode() == 2) {
            col.addView(row("Banner picture", "PICK", () -> host.pickBanner()));
        }
        col.addView(colorRow("Colour 1", Profile.K_C1, Profile.c1()));
        col.addView(colorRow("Colour 2", Profile.K_C2, Profile.c2()));
        col.addView(colorRow("Colour 3", Profile.K_C3, Profile.c3()));
        col.addView(colorRow("Ring and status colour", Profile.K_ACCENT, Profile.accent()));
        col.addView(cycler("Effect on the banner", Profile.EFFECTS, Profile.K_FX, Profile.fx()));
        col.addView(cycler("Avatar ring", Profile.RINGS, Profile.K_RING, Profile.ring()));
        col.addView(cycler("Name style", Profile.NAME_FX, Profile.K_NAMEFX, Profile.nameFx()));
        col.addView(row("Start over with the default look", "RESET", () -> {
            Profile.resetLook();
            build();
        }));
        TextView hint = text("Your status is the scene you have on. Badges you earn show up on the card.", 9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        hint.setPadding(0, dp(10), 0, 0);
        col.addView(hint);
    }

    private void editText() {
        final EditText name = new EditText(host);
        name.setSingleLine(true);
        name.setHint("display name");
        name.setText(Prefs.getString(Profile.K_NAME, ""));
        final EditText about = new EditText(host);
        about.setHint("about me");
        about.setText(Profile.about());
        about.setMaxLines(4);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(name);
        box.addView(about);
        new AlertDialog.Builder(host).setTitle("Your profile").setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    Prefs.putString(Profile.K_NAME, name.getText().toString().trim());
                    Prefs.putString(Profile.K_ABOUT, about.getText().toString().trim());
                    build();
                }).setNegativeButton("Cancel", null).show();
    }

    private View cycler(String label, final String[] names, final String key, int cur) {
        return row(label, names[cur] + "  ›", null, v -> {
            int n = (Math.max(0, Math.min(names.length - 1, Prefs.getInt(key, cur))) + 1) % names.length;
            Prefs.putInt(key, n);
            build();
        });
    }

    private View colorRow(String label, final String key, int color) {
        LinearLayout r = row(label, "CHANGE", () -> ColorPicker.show(host, label, color, c -> {
            Prefs.putInt(key, c | 0xFF000000);
            build();
        }));
        TextView sw = new TextView(host);
        sw.setBackground(Theme.rounded(color, 8f, host));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(26), dp(26));
        p.rightMargin = dp(10);
        r.addView(sw, 1, p);
        return r;
    }

    private LinearLayout row(String label, String action, Runnable run) {
        return row(label, action, run, null);
    }

    private LinearLayout row(String label, String action, Runnable run, View.OnClickListener l) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(11), dp(4), dp(11));
        TextView t = text(label, 12f, Theme.TEXT);
        t.setGravity(Gravity.START);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView a = text(action, 12f, Theme.ACCENT);
        a.setPadding(dp(10), dp(4), dp(4), dp(4));
        r.addView(a);
        r.setClickable(true);
        r.setOnClickListener(l != null ? l : v -> run.run());
        return r;
    }

    private TextView heading(String s) {
        TextView t = text(s, 10f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setPadding(0, dp(18), 0, dp(2));
        return t;
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
