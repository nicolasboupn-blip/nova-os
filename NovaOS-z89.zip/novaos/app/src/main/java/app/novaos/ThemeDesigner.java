package app.novaos;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Make your own look for NOVA: seven colours, how round the corners are, borders, how see-through panels are, the
 * font and three background effects. The card at the top shows it live. USE MY STYLE applies it everywhere. COPY CODE
 * gives one line you can send to a friend, PASTE CODE reads such a line.
 */
final class ThemeDesigner extends FrameLayout implements BackAware {
    private static final String[] COLOR_NAMES = {"Background", "Background 2 (top)", "Panels", "Accent", "Glow", "Text",
        "Dim text"};

    private final NovaActivity host;
    private final FrameLayout card;
    private final LinearLayout controls;

    ThemeDesigner(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("THEME DESIGNER", 15f, 0xFFB39DFF);
        title.setLetterSpacing(0.15f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(chip("USE IT", this::useIt));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        card = new FrameLayout(host);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(150));
        clp.topMargin = dp(10);
        col.addView(card, clp);

        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        controls = new LinearLayout(host);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(0, dp(6), 0, dp(40));
        sv.addView(controls);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(8);
        col.addView(sv, slp);

        addView(col, new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
        build();
        preview();
    }

    // ------------------------------------------------------------------ the live card

    private void preview() {
        card.removeAllViews();
        int bg = UiStyle.customColor(0);
        int bg2 = UiStyle.customColor(1);
        int panel = UiStyle.customColor(2);
        int accent = UiStyle.customColor(3);
        int text = UiStyle.customColor(5);
        int dim = UiStyle.customColor(6);
        float radius = Prefs.getInt(UiStyle.K_RADIUS, 100) / 100f;
        float border = Prefs.getInt(UiStyle.K_BORDER, 0) * 0.5f;
        int bcol = Prefs.getInt(UiStyle.K_BCOL, 0x33FFFFFF);
        float glass = Math.max(0.3f, Math.min(1f, Prefs.getInt(UiStyle.K_GLASS, 100) / 100f));
        android.graphics.Typeface face = UiStyle.fontOf(Prefs.getInt(UiStyle.K_FONT, 0));

        GradientDrawable back = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {bg2, bg});
        back.setCornerRadius(dp(12));
        card.setBackground(back);

        LinearLayout inner = new LinearLayout(host);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable pd = new GradientDrawable();
        pd.setColor((panel & 0xFFFFFF) | (Math.round(glass * 255) << 24));
        pd.setCornerRadius(dp(16 * radius));
        if (border > 0f) {
            pd.setStroke(Math.max(1, dp(border)), bcol);
        }
        inner.setBackground(pd);

        TextView t1 = new TextView(host);
        t1.setText("NOVA  12:34");
        t1.setTextColor(text);
        t1.setTypeface(face);
        t1.setTextSize(18f);
        inner.addView(t1);
        TextView t2 = new TextView(host);
        t2.setText("This is how panels and text look");
        t2.setTextColor(dim);
        t2.setTypeface(face);
        t2.setTextSize(12f);
        inner.addView(t2);
        TextView btn = new TextView(host);
        btn.setText("BUTTON");
        btn.setTextColor(bg);
        btn.setTypeface(face);
        btn.setTextSize(12f);
        btn.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable bd = new GradientDrawable();
        bd.setColor(accent);
        bd.setCornerRadius(dp(12 * radius));
        btn.setBackground(bd);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(10);
        inner.addView(btn, blp);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        ilp.setMargins(dp(14), dp(10), dp(14), dp(10));
        card.addView(inner, ilp);
    }

    // ------------------------------------------------------------------ the controls

    private void build() {
        controls.removeAllViews();
        section("START FROM A STYLE");
        LinearLayout starts = new LinearLayout(host);
        starts.addView(chip("AURORA", () -> start(UiStyle.AURORA)));
        starts.addView(chip("TERMINAL", () -> start(UiStyle.TERMINAL)));
        starts.addView(chip("BLOCK", () -> start(UiStyle.BLOCK)));
        controls.addView(starts);

        section("COLOURS (tap one)");
        for (int i = 0; i < COLOR_NAMES.length; i++) {
            final int k = i;
            controls.addView(colorRow(COLOR_NAMES[i], UiStyle.customColor(i), c -> {
                UiStyle.setCustomColor(k, c);
                refresh();
            }));
        }

        section("SHAPE");
        controls.addView(slider(UiStyle.K_RADIUS, "Corner roundness", 0, 200, 100, v -> v + " %"));
        controls.addView(slider(UiStyle.K_BORDER, "Border thickness", 0, 8, 0, v -> (v * 0.5f) + " dp"));
        controls.addView(colorRow("Border colour", Prefs.getInt(UiStyle.K_BCOL, 0x33FFFFFF), c -> {
            Prefs.putInt(UiStyle.K_BCOL, c);
            refresh();
        }));
        controls.addView(slider(UiStyle.K_GLASS, "Panel see-through (100 = solid)", 30, 100, 100, v -> v + " %"));

        section("FONT");
        controls.addView(fontRow());

        section("BACKGROUND EFFECTS");
        controls.addView(fxRow("Scan lines over everything", UiStyle.FX_SCAN));
        controls.addView(fxRow("Moving soft light", UiStyle.FX_AURORA));
        controls.addView(fxRow("Dot grid", UiStyle.FX_DOTS));

        section("SHARE");
        LinearLayout share = new LinearLayout(host);
        share.addView(chip("COPY CODE", () -> {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("NOVA style", UiStyle.exportCode()));
            host.toast("Style code copied. Send it to a friend");
        }));
        share.addView(chip("PASTE CODE", () -> {
            try {
                ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                String t = d != null && d.getItemCount() > 0 ? String.valueOf(d.getItemAt(0).getText()) : "";
                if (UiStyle.importCode(t)) {
                    host.toast("Style loaded. Tap USE IT");
                    refresh();
                    build();
                } else {
                    host.toast("That is not a NOVA style code");
                }
            } catch (Exception e) {
                host.toast("Could not read the clipboard");
            }
        }));
        controls.addView(share);
        TextView note = text("Tap USE IT at the top to switch NOVA to MY STYLE. You can come back here any time.", 11f,
                0xFF8E84B3);
        note.setTypeface(android.graphics.Typeface.DEFAULT);
        note.setPadding(0, dp(12), 0, 0);
        controls.addView(note);
    }

    private void refresh() {
        preview();
    }

    private void start(int style) {
        UiStyle.copyInto(style);
        build();
        preview();
    }

    private void useIt() {
        Prefs.putInt(UiStyle.K_STYLE, UiStyle.CUSTOM);
        host.refreshTheme();
    }

    private void section(String s) {
        TextView t = text(s, 10f, 0xFFB39DFF);
        t.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(18);
        p.bottomMargin = dp(4);
        controls.addView(t, p);
    }

    private View colorRow(String label, int color, final java.util.function.IntConsumer set) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final View sw = new View(host);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color | 0xFF000000);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0x66FFFFFF);
        sw.setBackground(g);
        r.addView(sw, new LinearLayout.LayoutParams(dp(54), dp(30)));
        r.setClickable(true);
        r.setOnClickListener(v -> ColorPicker.show(host, label, color, c -> {
            set.accept(c);
            build();
        }));
        return r;
    }

    private View slider(final String key, String label, int min, int max, int def,
            final java.util.function.IntFunction<String> fmt) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(2));
        LinearLayout top = new LinearLayout(host);
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        top.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        int cur = Math.max(min, Math.min(max, Prefs.getInt(key, def)));
        final TextView value = text(fmt.apply(cur), 12f, 0xFFB39DFF);
        top.addView(value);
        box.addView(top);
        SeekBar bar = new SeekBar(host);
        bar.setMin(min);
        bar.setMax(max);
        bar.setProgress(cur);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                value.setText(fmt.apply(p));
                if (user) {
                    Prefs.putInt(key, p);
                    preview();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        box.addView(bar);
        return box;
    }

    private View fontRow() {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text("Font", 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView v = text(UiStyle.FONTS[Math.max(0, Math.min(UiStyle.FONTS.length - 1,
                Prefs.getInt(UiStyle.K_FONT, 0)))] + "  ›", 13f, 0xFFB39DFF);
        v.setClickable(true);
        v.setPadding(dp(10), dp(6), 0, dp(6));
        v.setOnClickListener(x -> {
            int n = (Prefs.getInt(UiStyle.K_FONT, 0) + 1) % UiStyle.FONTS.length;
            Prefs.putInt(UiStyle.K_FONT, n);
            v.setText(UiStyle.FONTS[n] + "  ›");
            v.setTypeface(UiStyle.fontOf(n));
            preview();
        });
        r.addView(v);
        return r;
    }

    private View fxRow(String label, final int bit) {
        LinearLayout r = new LinearLayout(host);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        TextView l = text(label, 13f, 0xFFF2EEFF);
        l.setTypeface(android.graphics.Typeface.DEFAULT);
        r.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Switch s = new android.widget.Switch(host);
        s.setChecked((Prefs.getInt(UiStyle.K_FX, 0) & bit) != 0);
        s.setOnCheckedChangeListener((b, on) -> {
            int cur = Prefs.getInt(UiStyle.K_FX, 0);
            Prefs.putInt(UiStyle.K_FX, on ? cur | bit : cur & ~bit);
        });
        r.addView(s);
        return r;
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(android.graphics.Typeface.MONOSPACE);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, 0xFFF2EEFF);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x26FFFFFF);
        g.setCornerRadius(dp(12));
        t.setBackground(g);
        t.setPadding(dp(11), dp(8), dp(11), dp(8));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
