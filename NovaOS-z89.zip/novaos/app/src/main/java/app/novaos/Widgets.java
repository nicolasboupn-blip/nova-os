package app.novaos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Every widget NOVA has: the 30 new ones (their own pages on the quick panel), plus the older panel pages that can
 * also be placed on their own on the home screen. Also stores which widgets sit where on the home screen.
 */
final class Widgets {
    private Widgets() {
    }

    static final String[] NEW_IDS = {"analog", "world", "binary", "progress", "moon", "hourglass",
        "search", "shortcuts", "recent", "device", "uptime", "volume", "clipboard", "password", "compass", "level",
        "light", "baro",
        "counter", "habits", "water", "breathe", "metronome", "eightball", "decider", "tictactoe", "mathquiz",
        "morse", "sketch", "quote", "deck", "songs", "profile", "scenes", "mine1", "mine2", "mine3"};
    static final String[] NEW_TITLES = {"ANALOG CLOCK", "WORLD CLOCK", "BINARY CLOCK", "TIME PROGRESS", "MOON",
        "HOURGLASS",
        "SEARCH", "SHORTCUTS", "RECENT APPS", "DEVICE", "UPTIME", "VOLUME", "CLIPBOARD", "PASSWORD", "COMPASS",
        "LEVEL", "LIGHT METER", "BAROMETER",
        "COUNTER", "HABITS", "WATER", "BREATHE", "METRONOME", "MAGIC 8 BALL", "DECIDER", "TIC-TAC-TOE",
        "MATH QUIZ", "MORSE", "SKETCH", "QUOTE", "LAUNCH DECK", "SONGS", "PROFILE", "SCENES", "MY WIDGET 1",
        "MY WIDGET 2", "MY WIDGET 3"};

    /** Older quick panel pages that also work on their own. */
    private static final String[] OLD_IDS = {"map", "weather", "calendar", "casino", "slots", "games", "stopwatch",
        "timer", "sun", "switches", "converter", "calc", "countdown", "crypto", "quests", "pet", "castle", "todo",
        "focus", "code", "servers", "vehicles"};
    private static final String[] OLD_TITLES = {"MAP", "WEATHER", "CALENDAR", "CASINO", "SLOTS", "GAMES",
        "STOPWATCH", "TIMER", "SUN", "QUICK SWITCHES", "CONVERTER", "CALCULATOR", "COUNTDOWN", "CRYPTO", "QUESTS",
        "PET", "CASTLE", "TO-DO", "FOCUS", "CODE", "SERVERS", "VEHICLES"};

    static final int HALF = 0;
    static final int WIDE = 1;
    static final int BIG = 2;
    static final String[] SIZE_NAMES = {"HALF", "WIDE", "BIG"};

    static String[] placeIds() {
        String[] out = new String[OLD_IDS.length + NEW_IDS.length];
        System.arraycopy(OLD_IDS, 0, out, 0, OLD_IDS.length);
        System.arraycopy(NEW_IDS, 0, out, OLD_IDS.length, NEW_IDS.length);
        return out;
    }

    static String[] placeTitles() {
        String[] out = new String[OLD_TITLES.length + NEW_TITLES.length];
        System.arraycopy(OLD_TITLES, 0, out, 0, OLD_TITLES.length);
        System.arraycopy(NEW_TITLES, 0, out, OLD_TITLES.length, NEW_TITLES.length);
        return out;
    }

    static String title(String id) {
        String[] ids = placeIds();
        String[] titles = placeTitles();
        for (int i = 0; i < ids.length; i++) {
            if (ids[i].equals(id)) {
                return titles[i];
            }
        }
        return id.toUpperCase(java.util.Locale.ROOT);
    }

    /** Builds a fresh widget. Each call makes a new, independent view. */
    static View create(NovaActivity host, String id) {
        switch (id) {
            case "analog":
                return new WidgetsTime.Analog(host);
            case "world":
                return new WidgetsTime.World(host);
            case "binary":
                return new WidgetsTime.Binary(host);
            case "progress":
                return new WidgetsTime.Progress(host);
            case "moon":
                return new WidgetsTime.Moon(host);
            case "hourglass":
                return new WidgetsTime.Hourglass(host);
            case "search":
                return new WidgetsSystem.Search(host);
            case "shortcuts":
                return new WidgetsSystem.Shortcuts(host);
            case "recent":
                return new WidgetsSystem.Recent(host);
            case "device":
                return new WidgetsSystem.Device(host);
            case "uptime":
                return new WidgetsSystem.Uptime(host);
            case "volume":
                return new WidgetsSystem.Volume(host);
            case "clipboard":
                return new WidgetsSystem.Clip(host);
            case "password":
                return new WidgetsSystem.Password(host);
            case "compass":
                return new WidgetsSystem.Compass(host);
            case "level":
                return new WidgetsSystem.Level(host);
            case "light":
                return new WidgetsSystem.Light(host);
            case "baro":
                return new WidgetsSystem.Baro(host);
            case "counter":
                return new WidgetsFun.Counter(host);
            case "habits":
                return new WidgetsFun.Habits(host);
            case "water":
                return new WidgetsFun.Water(host);
            case "breathe":
                return new WidgetsFun.Breathe(host);
            case "metronome":
                return new WidgetsFun.Metronome(host);
            case "eightball":
                return new WidgetsFun.EightBall(host);
            case "decider":
                return new WidgetsFun.Decider(host);
            case "tictactoe":
                return new WidgetsFun.TicTacToe(host);
            case "mathquiz":
                return new WidgetsFun.MathQuiz(host);
            case "morse":
                return new WidgetsFun.Morse(host);
            case "sketch":
                return new WidgetsFun.Sketch(host);
            case "quote":
                return new WidgetsFun.Quote(host);
            case "deck":
                return new DeckWidget(host);
            case "songs":
                return new SongsWidget(host);
            case "profile":
                return new ProfileWidget(host);
            case "scenes":
                return new ScenesWidget(host);
            case "mine1":
                return new CustomWidget(host, 1);
            case "mine2":
                return new CustomWidget(host, 2);
            case "mine3":
                return new CustomWidget(host, 3);
            // ------------------------------------------------ older panel pages
            case "map": {
                MapPage p = new MapPage(host);
                return new Legacy(host, p, p::refresh, 0, false);
            }
            case "weather":
                return new Legacy(host, new WeatherPage(host), null, 0, false);
            case "calendar":
                return new Legacy(host, new CalendarView(host), null, 160, false);
            case "casino": {
                CasinoPage p = new CasinoPage(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "slots":
                return new Legacy(host, new SlotMachine(host), null, 0, true);
            case "games": {
                MiniGames g = new MiniGames(host);
                return new Legacy(host, g, g::refreshBests, 0, true);
            }
            case "stopwatch":
                return new Legacy(host, new StopwatchPage(host), null, 0, false);
            case "timer":
                return new Legacy(host, new TimerPage(host), null, 0, false);
            case "sun":
                return new Legacy(host, new SunPage(host), null, 158, false);
            case "switches":
                return new Legacy(host, new TogglesPage(host), null, 0, false);
            case "converter":
                return new Legacy(host, new ConverterPage(host), null, 156, false);
            case "calc":
                return new Legacy(host, new CalcPage(host), null, 0, true);
            case "countdown":
                return new Legacy(host, new CountdownPage(host), null, 0, false);
            case "crypto":
                return new Legacy(host, new CryptoPage(host), null, 156, false);
            case "quests": {
                QuestPage p = new QuestPage(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "pet": {
                PetPage p = new PetPage(host);
                return new Legacy(host, p, p::refresh, 0, false);
            }
            case "castle": {
                CastlePage p = new CastlePage(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "todo": {
                TodoPage p = new TodoPage(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "focus":
                return new Legacy(host, new FocusPage(host), null, 0, false);
            case "code": {
                CodeWidget p = new CodeWidget(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "servers": {
                ServersWidget p = new ServersWidget(host);
                return new Legacy(host, p, p::refresh, 0, true);
            }
            case "vehicles":
                return new Legacy(host, new VehicleQuiz.Page(host), null, 0, true);
            default: {
                TextView t = new TextView(host);
                t.setText("unknown widget");
                t.setTextColor(Theme.DIM);
                t.setGravity(Gravity.CENTER);
                return t;
            }
        }
    }

    /** Tells a widget its page was just shown, so it can update. */
    static void refresh(View v) {
        if (v instanceof NovaWidget) {
            ((NovaWidget) v).refresh();
        }
    }

    // ------------------------------------------------------------------ home screen placement

    /** One widget placed on the home screen. */
    static final class Placed {
        int page;
        String id;
        int size;

        Placed(int page, String id, int size) {
            this.page = page;
            this.id = id;
            this.size = size;
        }
    }

    private static final String KEY = "home_widgets";

    static List<Placed> load() {
        List<Placed> out = new ArrayList<>();
        String raw = Prefs.getString(KEY, "");
        if (raw == null || raw.isEmpty()) {
            return out;
        }
        for (String part : raw.split(";")) {
            String[] f = part.split(",");
            if (f.length != 3) {
                continue;
            }
            try {
                int page = Math.max(0, Math.min(1, Integer.parseInt(f[0])));
                int size = Math.max(HALF, Math.min(BIG, Integer.parseInt(f[2])));
                out.add(new Placed(page, f[1], size));
            } catch (NumberFormatException ignored) {
                // a broken entry is skipped
            }
        }
        return out;
    }

    static void save(List<Placed> list) {
        List<String> parts = new ArrayList<>();
        for (Placed p : list) {
            parts.add(p.page + "," + p.id + "," + p.size);
        }
        Prefs.putString(KEY, TextUtils.join(";", parts));
    }

    // ------------------------------------------------------------------ older pages in a widget frame

    /** Wraps an older panel page so it can sit on the home screen and update when it comes into view. */
    static final class Legacy extends NovaWidget {
        private final Runnable refresher;

        Legacy(NovaActivity host, View child, Runnable refresher, int fixedHeightDp, boolean scroll) {
            super(host);
            this.refresher = refresher;
            setGravity(Gravity.NO_GRAVITY);
            int h = fixedHeightDp > 0 ? dp(fixedHeightDp) : LayoutParams.WRAP_CONTENT;
            if (scroll) {
                ScrollView sv = new ScrollView(host);
                sv.setVerticalScrollBarEnabled(false);
                sv.setOverScrollMode(OVER_SCROLL_NEVER);
                sv.addView(child, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, h));
                addView(sv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            } else {
                addView(child, new LayoutParams(LayoutParams.MATCH_PARENT, h));
            }
        }

        @Override
        void refresh() {
            if (refresher != null) {
                refresher.run();
            }
        }
    }
}

/**
 * Base for NOVA's own widgets. It knows when it is really on screen (its panel page showing, the home page visible,
 * the screen on), so sensors, sounds and ticking only run then and the battery is spared.
 */
abstract class NovaWidget extends LinearLayout {
    final NovaActivity host;
    final Handler ui = new Handler(Looper.getMainLooper());
    private boolean live;
    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (live) {
                tick();
                ui.postDelayed(this, tickMs());
            }
        }
    };

    NovaWidget(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);
    }

    /** Called when the widget comes on screen, and when its panel page is shown. */
    void refresh() {
    }

    /** How often tick() runs while on screen, in ms. 0 means never. */
    long tickMs() {
        return 0;
    }

    void tick() {
    }

    /** Start (true) or stop (false) sensors, sounds and animations. */
    void onLive(boolean on) {
    }

    boolean live() {
        return live;
    }

    private void update(boolean want) {
        if (want == live) {
            return;
        }
        live = want;
        ui.removeCallbacks(loop);
        onLive(want);
        if (want) {
            refresh();
            if (tickMs() > 0) {
                ui.post(loop);
            }
        }
    }

    private void recheck() {
        update(isAttachedToWindow() && getWindowVisibility() == VISIBLE && isShown());
    }

    @Override
    public void onVisibilityAggregated(boolean isVisible) {
        super.onVisibilityAggregated(isVisible);
        update(isVisible && isAttachedToWindow() && getWindowVisibility() == VISIBLE);
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        update(visibility == VISIBLE && isAttachedToWindow() && isShown());
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        post(this::recheck);
    }

    @Override
    protected void onDetachedFromWindow() {
        update(false);
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ helpers for the widgets

    int dp(float v) {
        return Theme.dp(host, v);
    }

    TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** A small rounded button. */
    TextView chip(String s, Runnable action) {
        TextView b = text(s, 10f, Theme.ACCENT);
        b.setSingleLine(true);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        b.setPadding(dp(8), dp(7), dp(8), dp(7));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    /** Highlights a chip as the chosen one, or not. */
    void pick(TextView chip, boolean on) {
        chip.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
        chip.setTextColor(on ? Theme.BG : Theme.ACCENT);
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, w);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        return lp;
    }

    LinearLayout.LayoutParams fill() {
        return new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f);
    }

    LinearLayout.LayoutParams wide() {
        return new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
    }
}

/** A thin rounded progress bar. */
final class WidgetBar extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float frac;
    private int color = Theme.ACCENT;

    WidgetBar(Context c) {
        super(c);
    }

    void set(float f) {
        frac = Math.max(0f, Math.min(1f, f));
        invalidate();
    }

    void color(int c) {
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float h = getHeight();
        float rad = h / 2f;
        r.set(0, 0, getWidth(), h);
        p.setColor(0x26FFFFFF);
        c.drawRoundRect(r, rad, rad, p);
        if (frac > 0f) {
            r.set(0, 0, Math.max(h, getWidth() * frac), h);
            p.setColor(color);
            c.drawRoundRect(r, rad, rad, p);
        }
    }
}
