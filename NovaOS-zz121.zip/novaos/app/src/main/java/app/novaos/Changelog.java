package app.novaos;

import android.app.AlertDialog;

/** What changed in each version, and a one-time "what's new" popup after an update. */
final class Changelog {
    private Changelog() {}

    static final String TEXT =
            "3.13  Look picker and skins\n"
            + " - FRIENDS POKER: when a betting round is done, everyone now sees THE FLOP / THE TURN / THE RIVER with the new cards big on screen before the phone is passed again, and the pass screen shows the cards in the middle as real cards\n"
            + " - NIGHT, MORNING, SCHOOL and the other new screens: scroll down to the bottom for all your pinned apps\n"
            + " - 10 HOME SCREENS WITH A JOB: MORNING (leave countdown, next bus, weather, a checklist that resets every day, how you woke up), SCHOOL (your timetable with the lesson now and next, homework with due days, test countdowns), NIGHT (red night screen: best bedtimes for your wake-up time, SET ALARM, what is on tomorrow, how today was, breathing), COMMUTE (bus map and sign, music keys, travel apps), FOCUS (25 or 50 minute focus timer with breaks, today's top 3, only work apps), MONEY (pocket money, a saving goal, the month), HEALTH (water, workout counters, habits, mood), PLANNER (your week: events, homework and tests per day), JOURNAL (a line a day, streak, what you wrote a week, month and year ago) and STATS (apps opened, top apps, per hour, mood week)\n"
            + " - 10 HOME SCREENS TO PLAY: QUEST (your real day as an RPG: XP, levels, quests, apps as items), GATE (social, video and game apps need a quick sum first), PIANO (two octaves, three sounds, record and play back, learn songs), DOODLE (a drawing wall that is kept, share it), PARTY (spin wheel, dice, coin, random teams), SCORE (scoreboard with a round timer), FIVE (a new five-letter word every day, Swiss keyboard), ARCADE (reaction, tap race, memory), PIXEL (16x16 pixel art, 4 slots, share) and SOUNDBOARD (12 sound pads and a beat maker)\n"
            + " - POCKET MONEY: a new main box page (and widget). Type what you spent, like -15 kebab, or what you got, like +20 birthday. It sorts it (food, travel, fun, clothes, phone ...), shows what is left of your week in CHF with a bar, how much you can spend per day until Monday, and warns you before you run out. Tap the budget to change it, tap a cross to remove a mistake\n"
            + " - 10 FUN HOME SCREENS that move: AQUARIUM (apps are fish, tap the water to feed them), CLAW (a claw machine: grab an app to open it), JACKPOT (spin the slot machine, three in a row is a jackpot), SKYLINE (apps are buildings in a city that follows the real time of day), MAGNETS (drag app magnets around a fridge, they stay where you put them), BALLOONS (pop a balloon to open its app), RAIN (apps are drops on a rainy window, with a wiper), LAVA (a lava lamp), GARDEN (flowers grow taller the more you use an app, water them) and BOARD GAME (roll the dice, hop around a board of apps). All in the look picker as skins\n"
            + " - MOOD CALENDAR: a new main box page (and widget). Tap a smiley whenever your mood changes. Every day gets a colour and a smiley from how long you were in each mood (half good, half bad = in the middle). Tap a day to see its mix. The mood block in MY WIDGET counts too\n"
            + " - 10 NORMAL HOME SCREENS: GLANCE, SPRING (widgets, pages, glass dock), ONE HAND, WAVE (A to Z rail), FOLDERS (apps sort themselves), PAGES (classic pages + all-apps button), SMART (apps for this time of day), GLASS, CLEAN and BOARD (widgets first)\n"
            + " - Every home screen is now a skin in the look picker (46 skins), so you can find them all\n"
            + " - 20 NEW HOME SCREENS (Settings > UI STYLE > Home screen layout, or the look picker): METRO (live tiles that flip), GLYPH (dot-matrix clock, black and white with one red dot), DESKTOP (an old PC desktop with a Start menu, a window you can drag and a taskbar clock), POCKET (a handheld game console: D-pad, A and B), KEYPAD (an old mobile phone: number keys open your apps), HONEYCOMB (a watch-style honeycomb you drag around), STACK (swipe through a pile of big app cards), TIMELINE (your day as a line of the apps you opened), SHELF (apps as books on wooden shelves), COLUMNS (pinned, recent and A to Z side by side), TUI (a terminal dashboard with bars and a command line), SPOTLIGHT (one search box for apps, maths and the web), DRIVE (a car dashboard with gauges, big buttons and music keys), CORKBOARD (polaroids and sticky notes on cork), SUBWAY (your apps as stops on a tram line map), CAROUSEL (covers that turn in 3D), SIDEBAR (a rail of round apps with widgets beside it), WHEEL (a music player with a click wheel you turn), RADIO (turn the dial to tune into an app) and MASONRY (a two-column wall of colourful cards). Plus 5 new skins in the look picker\n"
            + " - Long lists in Settings (like the home screen layout) now open as a list to pick from\n"
            + " - Any page in the main box scrolls down when its content does not fit\n"
            + " - ONE HOME PAGE: page 2 is gone. All your pinned apps now sit on the first page, and widgets from the old page 2 moved there too.\n"
            + " - PAGE ORDER: choose the order of the pages in the main box. Tap the page name on the home screen > ORDER (or Settings > PAGE ORDER), hold a page and drag it, or use the arrows. Empty MY WIDGET cards no longer sit on the home screen\n"
            + " - BUS SIGN: the yellow dot-matrix sign from the Zürich stops. It shows the next buses on your routes (line, where it goes, minutes with a ') at the stop where you get in, live. It always comes together with the ZURICH BUS map widget (and can also be placed alone). Routes can be taken off the sign with ON SIGN in the BUS window\n"
            + " - Z\u00DCRICH BUS: a new widget (and big window) with a real map of your bus routes. A blue bus symbol where you get in, small blue dots for the stops you pass. Add a route by hand (+ ROUTE) or switch on AUTO-DETECT and NOVA asks you after a ride. After 3 different days the route is a solid blue line, and where the bus is late the line goes green to red. Zoom with pinch, + / - or double tap. Settings > ZURICH BUS or the widget picker\n"
            + " - NOVA NET is hidden for now (the NET button, the Settings row and the Shop button are gone). The code stays and comes back with one switch\n"
            + " - Home screens Feed, Console, Wallet, Bento and Fan: the SCENES card is now a big clock with the day's info (or your own MY WIDGET 1 if you built one), and the PROFILE card is one card you flip through: profile, scenes, weather, to-do, calendar, casino, slots, badges, games. BADGES can also be placed as a widget\n"
            + " - MY WIDGET 1, 2 and 3 are pages of the main box (the 1 / 52 one with the arrows). PUT ON HOME SCREEN opens that page for you. Widgets can no longer spill over the apps: they grow to fit their blocks\n"
            + " - WIDGET BUILDER redone: a big live preview of your widget, the whole block list below it, and you drag blocks onto the widget (hold a block, drag, release where the line shows). Tap a block in the widget for edit / move / duplicate / remove, hold it to move it, drag it back down to remove it. RESET empties the widget, CLOSE and PUT ON HOME SCREEN sit in the top rows\n"
            + " - WIDGET BUILDER: 50 new blocks (61 in total), picked from groups. TIME: analog clock, big clock, 12 hour, world clock, stopwatch, timer, hours left today, status strip. DATE: weekday, day number, month, week number, day of the year, year / month / week progress, countdown, days since, days to the weekend, moon phase. PHONE: battery big, charging, storage, memory, uptime, phone model, Android version, network, volume, brightness. YOU: greeting, name, top 3 songs, scenes row, habit streak, water today, mood today, checklist item. TOOLS: app button, tally +/-, manual progress, quote, fun fact. GAMES: coin flip, dice, random number, 8 ball. TEXT: heading, big emoji, rainbow text. Blocks can be duplicated and moved with the arrows\n"
            + " - WIDGETS sheet: move every widget up or down, change its size (half, wide, big) and its page\n"
            + " - WIDGETS button on every home screen layout (bottom bar, Lines, Dock): shows the widgets you placed, lets you add or remove any widget and open the widget builder. Widgets from the builder now show up even when you use a layout other than Classic\n"
            + " - PEAKFINDER 3D: a new 3D tab shows your live camera with the mountain names drawn on the real peaks (uses the phone's rotation sensor, so it follows left/right, up/down and tilt; pinch to match the camera zoom if names sit slightly off). The map now zooms smoothly (pinch, + / -, double tap). New PEAKFINDER widget: the real map in the middle, range in km with - / + on the left, big OPEN button on the right for the full menu\n"
            + " - LOOK PICKER: a tab on the right edge of the home screen (tap it or pull it left) slides out a panel. 10 SKINS (Ink, Candy, Paper, Tokyo, Sunset, Arcade, Newspaper, Forest, Gold, Bubblegum) each change colours, shapes, font, home screen AND app drawer at once, and you can mix colours / home screen / drawer yourself. Every tap applies instantly\n"
            + " - 2 new home screens: LINES (only type) and DOCK (familiar grid + floating dock). 6 app drawer looks: Grid, List, Letters (A to Z rail), Cards, Dense, Wide\n"
            + " - What's new now shows the newest change first and appears once per update\n"
            + " - Peak widget loads the peaks by itself now (uses your last known location), no need to open the map first\n"
            + " - PEAKFINDER fixes: shows the last known position and loads peaks right away (even if GPS is slow), takes your height from a height map instead of the GPS (the GPS height was often wrong or 0, which made every stick too tall), and a drawing problem now shows a message instead of crashing\n"
            + " - Fix updates: installs now go through Android\'s package installer, which tells you the exact reason when an install fails (different signing key, older build, not allowed to install). CHECK FOR UPDATE now explains a private GitHub repo (404) and can use a GitHub token (Settings > UPDATES) so updates work with a private repo. INSTALL UPDATE FROM A FILE also asks for the install permission if it is missing\n"
            + " - PEAKFINDER: a normal map (OpenStreetMap, about 40 km around you, drag/pinch/+/-) with every peak marked by a triangle with name and height, rings every 10 km, DARK map option and a ME button. STICKS: no camera, a stick stands in the ground at each peak's direction, as tall as it looks, with name, height and distance; it turns with the compass, drag to look around, pinch to see all 360 degrees. Tap a peak to open it in Google Maps. Peaks come from OpenStreetMap (and Wikidata as a backup) and are saved on the phone. Settings > PEAKFINDER or the widget\n"
            + " - Force dark mode (Settings > UI STYLE): makes every look dark, keeps the colours' hue\n"
            + " - 4 MORE real home screens: INDEX (text only, every app as a line of type with an A to Z rail), FAN (one-handed: a corner button fans your apps out in an arc), WALLET (cards that fold open like a wallet) and BUBBLES (your apps float as bubbles you can push and fling)\n"
            + " - Fix PEAKFINDER not loading: it now uses three public peak servers (the main one is often overloaded, and one old one is gone), no longer saves an empty answer, tries a smaller area when a server is busy, accepts approximate location, and shows the exact reason on screen when it fails\n"
            + " - PEAKFINDER second source: if the OpenStreetMap servers are busy it asks Wikidata for mountains with a height. Tap the peak info line to open the peak in Google Maps (or your maps app)\n"
            + " - 4 more rich themes with their own moving pictures: SYNTHWAVE (neon sunset and moving grid), OCEAN (light rays, bubbles, waves), INFERNO (glow and rising embers), GALAXY (nebula, stars, shooting stars). Settings > UI STYLE > Look of NOVA, and in scenes\n"
            + " - 4 REAL new home screens (Settings > UI STYLE > Home screen layout), not just colours: BENTO (board of tiles), ORBIT (apps on turning rings around the clock, drag to spin), FEED (scrolling cards with app search) and CONSOLE (big tiles in a row like a game console). Classic stays the default and all looks work with all layouts\n\n"
            + "3.12  Achievements and upgrades\n"
            + " - Theme designer now shows a whole little home screen (clock, widget panel, app icons, dock, effects) that changes live, and TRY ON HOME shows your real home screen in the style with KEEP / EDIT / UNDO\n"
            + " - Profile is edited like Discord: tap the banner, picture, name, status, about me or badges on the card. New pronouns, your own status text and choose which badges to show\n"
            + " - Widget builder: PUT ON HOME SCREEN button (page and size), CLEAR, live preview, highlighted slot\n"
            + " - Settings > UI STYLE: three new looks for all of NOVA, switchable with Normal any time: AURORA (moving soft colour clouds, glass panels), TERMINAL (green on black, scan lines, sharp corners) and BLOCK (bold dark with thick borders and a dot grid). Switch on \"Theme designer\" to make MY STYLE: 7 colours, corner roundness, border, glass, font and effects, with copy/paste codes\n"
            + " - PROFILE like a Discord profile (Settings > PROFILE & SCENES, or the PROFILE widget): banner as gradient, one colour or your own picture, 8 moving effects (aurora waves, stars, rain, glitter, embers, matrix, bubbles, snow), avatar ring styles, name effects, 3 custom colours, about me, your scene as status, earned badges and stats\n"
            + " - SCENES: Morning, Study, Gaming, Chill, Sleep (make your own). One tap sets volume, ringer, brightness, look, accent colour and can start a song. Optional clock: a scene starts at its time while NOVA is open. Quick switcher widget SCENES\n"
            + " - SONGS widget: your most played songs of the last 3 days and your pinned songs. Tap to play, star to pin. Needs notification access to learn what you play\n"
            + " - WIDGET BUILDER: build MY WIDGET 1 to 3 from blocks (text, clock, date, battery bar, button, counter, day progress, scene, top song)\n"
            + " - Edit home layout (Settings > HOME LAYOUT): icons wiggle, drag one onto another to swap places, tap DONE\n"
            + " - Castle visitors: knight every ~40 min, merchant every ~10 min, thief every ~3 hours. Admin can send any of them. The merchant and Margon now have short conversations at the gate\n"
            + " - Admin mode unlocks the achievements admin cannot reach by playing (cosmetic collector 5/20/50, Zigzag castle skins, full Zigzag set). No coin rewards\n"
            + " - New VEHICLES page on the status panel: name one of 100 military vehicles from its side silhouette. Right +200 coins, wrong -1000 coins\n"
            + " - Bets of 100K and 1M in slots, roulette, blackjack and dice. Chips share the row evenly now\n"
            + " - New DUEL game on the Games page (page 3): pass-the-phone for 2 to 4 players, best of three rounds. REACTION or TAP RACE\n"
            + " - New LAUNCH DECK: a Launchpad-style 8 x 8 pad grid that pops out from the LAUNCH DECK widget (add it in edit mode) or the terminal command deck. Spotify PREV/PLAY/NEXT, song pads, app pads, and 10 binds of NOVA's own. Hold a pad to change what it does, its label and colour\n"
            + " - LAUNCH DECK water ripples: hit a pad and rings of changing colour spread out over the other pads like waves on water, on screen and on the Launchpad lights. Switch in Settings > LAUNCH DECK\n"
            + " - Ripples are now fully configurable (FX button on the deck, or Settings > LAUNCH DECK): strength, length, speed, ring thickness, number of rings, gap, fade, round/diamond/square, outward/inward, 7 colour styles, colour, richness, brightness, flash, screen and/or Launchpad, smoothness, waves at once, with a live preview and reset\n"
            + " - LAUNCH DECK SOUNDS: every pad can make a sound on the phone (12 instruments incl. drums, any note). Hold a pad > SOUND to choose and hear it. New PLAY mode on the deck: no buttons, only colour pads that make sound; keep your finger down to hold a note, slide across pads, use several fingers. A connected Launchpad plays too. Settings > DECK SOUNDS\n"
            + " - Deck sounds: pick any of the 88 piano keys (A0 to C8) for a pad. Hold a pad > SOUND, then tap a key on the piano, type the note yourself (C4, F#3, Bb5, A0 or 21 to 108), or step with + and -. Pad colours: hold a pad > COLOUR for a colour picker with sliders and a #RRGGBB box, and \"+\" in the label dialog for your own colour. Empty pads can have a colour too\n"
            + " - Spotify song pads play WITHOUT opening Spotify (Settings > SPOTIFY: your own free Spotify developer Client ID, then CONNECT). Needs Spotify Premium and Spotify running in the background. Without it the pads work as before\n"
            + " - Fixes and speed: deck pads only repaint when their colour really changed (smoother ripples and WHACK), sliders save when you let go instead of on every move, sounds start faster (low-latency audio, notes made ready in the background), the whack game and sounds are cleaned up when NOVA closes, and all three system receivers are now released even if one was already gone\n"
            + " - New game WHACK on the LAUNCH DECK: whack-a-mole on the 8 x 8 pads, on the phone and on a connected Launchpad at the same time. Green = 1 point, gold = 5, red = bomb (-3). Streak multiplier, 3 levels, 45 seconds, best score saved. Press WHACK on the deck\n"
            + " - LAUNCH DECK MOUSE: the bottom-right 3 x 3 pads are a mouse. MOUSE (bottom right) opens a white round cursor, CLOSE (bottom left) closes it, the arrows move it (hold to speed up; DOWN is the middle pad, CENTER recentres it from the bottom middle), the two top corner pads tap. Inside NOVA out of the box; over every app after you switch on the optional NOVA mouse service in Android Accessibility settings\n"
            + " - 30 new LAUNCH DECK binds: rewind/fast forward, volume max/50%, ringer, Wi-Fi/Bluetooth/volume/display/battery/airplane/location/Android settings, brightness up/down/max, NOVA home/lock/settings/phone/gallery, roulette/poker/party wheel, show time/battery, 10 and 25 minute timers, alarms, web search. 20 of them are in the starting layout\n"
            + " - LAUNCH DECK works with a Novation Launchpad Mini MK3 plugged in over USB: the real pads run the binds and light up in their colours. Switch in Settings > LAUNCH DECK, status and a USB button in the deck\n"
            + " - Admin mode: BADGES > PICK BADGES is a tick list of every badge. Tick the ones you want, untick the ones you don't (no coin rewards, unticked ones stay off)\n"
            + " - New setting LOCK SCREEN > Remove lock screen: NOVA opens straight to home. Off while a NOVA PIN is set. The terminal lock command still shows it\n"
            + " - Choose which pages the quick panel shows: tap the panel title, then CHOOSE PAGES. The arrows and swipes skip the ones you turned off\n"
            + " - FRIENDS TABLE now has BLACKJACK (1 to 4 players vs the dealer) and POKER (Texas Hold'em, 2 to 4 players, blinds 10/20, side pots, pass the phone so only you see your cards) next to roulette. Same guests and saved coins\n"
            + " - Hold any app on the home screen and drag it: drop it on another app to swap, on empty space to move it to the end of that page, on the screen edge to flip pages, or on REMOVE at the top\n"
            + " - Widgets on the home screen: Settings > EDIT HOME, then + WIDGET. Every widget can sit on page 1 or 2 as HALF (two side by side), WIDE or BIG, and be moved, resized or removed\n"
            + " - 30 new widgets, on the quick panel and placeable: analog, world and binary clock, time progress, moon, hourglass, search, shortcuts, recent apps, device, uptime, volume, clipboard, password, compass, level, light meter, barometer, counter, habits, water, breathe, metronome, magic 8 ball, decider, tic-tac-toe, math quiz, morse, sketch, quote\n"
            + " - The quick panel shows a page number (like 12 / 63) instead of dots\n"
            + " - New SERVERS page on the quick panel: live player counts for your three favourite Arma Reforger servers (WCS Serhiivka East West, Spearhead Yunakivka, NEXTGEN France) from the free ReforgerMods server list, matched by name with nothing to set up. If a row picks the wrong server, tap it and paste a gamemonitoring.net link\n"
            + " - The casino page now scrolls, so Party Wheel, Baccarat and the Friends Table are no longer cut off\n"
            + " - New FRIENDS TABLE in the casino: pass-the-phone roulette for 1 to 4 players. Sit down as YOU with your own coins, or keep up to 20 guest profiles that each keep their own coins between games (new guests start with 1000)\n"
            + " - Sounds: a jackpot cascade on the slots, orb pickup and bust sounds in Snake, card and chip sounds at the casino tables, and win or lose sounds. Game sounds now play on the media volume, and only a full silent phone mutes them\n"
            + " - CODE is a quick-panel page now (swipe to CODE). Tap a project or NEW PROJECT to open the full editor, with SAVE, files, colours, and RUN for HTML and JavaScript\n"
            + " - Roulette straight numbers now pay 40 to 1 (was 35 to 1)\n"
            + " - Dice duel replaced by Texas Hold'em vs the dealer: two cards each, the flop, turn and river come out one card at a time, keep going or fold at each step (folding reveals the board). HOW TO PLAY panel, and the wizard explains it the first time\n"
            + " - Home layout: clock block at top, middle or bottom, and icon size normal, small or large (Settings > HOME LAYOUT)\n"
            + " - New casino game: BACCARAT (player, banker or tie, closest to 9 wins), 6 games on the casino page\n"
            + " - Admins own every item (Settings > ADMIN, on by default, can be turned off). Purchases always cost coins, nothing is free for admins anymore. INVEST is also a button on the SHOP page\n"
            + " - Invest (COIN SHOP > INVEST): 10 coins (Bitcoin, Ethereum, Solana, Dogecoin, XRP, Cardano, Avalanche, Chainlink, Litecoin, Tron) with live prices. Buy with 100, 1K or 10K coins, sell half or all. Game coins only, no real money\n"
            + " - Access startup (Settings > ACCESS SEQUENCE): roulette wheel, castle, slot machine and wizard with a fake progress bar, then ACCESS ACCEPTED and an open green padlock. Look: Hacker (code rain, glitchy pictures, terminal bar) or Cinematic. Set how long it takes and how long you must be away before it plays\n"
            + " - 65 achievements in bronze, silver and gold. Each pays coins (50, 150, 400) and has a progress counter. Scroll the BADGES page. Your best 3 show on your NOVA Net profile\n"
            + " - Coin Shop > UPGRADES: 4th daily quest, spin tickets, lucky charm, high roller bets (100, 250), auto-spin x10 (hold the lever), golden magnet, castle gold mine (earns while you are away), bigger vault, 3% interest, 3-pack of streak shields\n"
            + " - Phone upgrades: 5 icons per row, a fifth dock button (NET), icon shapes, 3 new animated wallpapers (Nebula, Ocean, Petals), sound packs (Retro, Bell, Wood), auto night colours, dancer pack (DJ, skateboard, fishing)\n"
            + " - NOVA Net style (bubble colours, profile frame), stickers, castle decorations (fireflies, lanterns, fountain)\n"
            + " - Zigzag castle skins now only recolour the roofs and windows (walls and rock keep their natural colours), with a pulsing aura and rising zigzag sparks\n"
            + " - Casino rule: the clock and date hide while the SLOTS or CASINO page is open on the home panel\n"
            + " - Roulette cheat mode: a tiny v-number in the top right corner shows the next pocket (it looks like a version tag)\n"
            + " - New big bets: 1K and 10K chips in Roulette, Blackjack and Dice, and 1000 and 10000 bets on the slot machine\n"
            + " - Settings: a search bar at the top (type a word, only matching settings and their headings stay), and the sections are in a better order: looks first, then lock and startup, controls, notifications, extras, updates and admin last\n"
            + " - Fixed: admin mode switched the night colours on by itself, so no theme showed after 21:00\n"
            + " - New character looks: Tracksuit, Wizard robe, Royal plate and the Ponytail, Curly and Undercut hair\n\n"
            + "3.11  Dancer and slots\n"
            + " - Fixed a crash after confetti (a view was removed while the screen was drawing it)\n"
            + " - Admin: CALL HIM BACK (also terminal: dragon call) ends the dragon's trip and he flies home. The admin panel shows when he is due back\n"
            + " - Your character lives in the top corner of the home screen. He dances to your music (4 dances) and otherwise waves, drinks coffee, reads, texts, does jumping jacks, sleeps at night and holds an umbrella when it rains. Tap him for the next thing. He cheers on quests and big coin wins. Switch him off in Settings\n"
            + " - Slot machine: new look (gold cabinet, chasing lights, curved reels, win line), a rolling ratchet sound with a clunk as each reel stops\n"
            + " - The 777 jackpot now pays 70% of the coins the machine kept since the last jackpot, plus 100 (never less than the old x10)\n\n"
            + "3.10  NOVA Net\n"
            + " - Accounts, friends, direct and group chats and ranklists, on a server you host yourself (server folder, README inside)\n"
            + " - Settings > NOVA NET (or the Shop page): enter your server address, then create an account\n"
            + " - Ranks: coins this week, coins all time, castle stage, quest streak, quests done, cosmetics. Show everyone or only friends\n"
            + " - Block and report people, hide yourself from the ranks, change password, delete account\n"
            + " - Friends without an Android phone can use the web version at your-server/app\n\n"
            + "3.9.2  Zigzag, redrawn\n"
            + " - New Zigzag shield (metal rim, gem, lightning bolt) and big solid wings with pointed feather tips\n"
            + " - New Zigzag cape in every edition, with a zigzag hem that sways. Buy it in the Coin Shop or wear it in My Character\n"
            + " - The full set now includes the cape (still 20% off)\n\n"
            + "3.9.1  Fixes\n"
            + " - The wizard and the dragon no longer fade in and out: they were drawn see-through by mistake\n"
            + " - The castle by day has warmer colours\n\n"
            + "3.9  Admin in the panel\n"
            + " - New ADMIN page on the home panel (admin mode only): every lever plus a command line, compact and scrollable, not full screen\n"
            + " - New admin commands: boost, spin reset, shield, bank\n\n"
            + "3.8  The Zigzag collection\n"
            + " - 7 editions (I to V, Black, Gold), each with a shield, wings that flap and an animated castle skin\n"
            + " - Coin Shop > Zigzag editions: buy parts or the full set at 20% off. Wear them in My Character and the Castle Workshop\n\n"
            + "3.7.1  Fix\n"
            + " - MAP page: the buttons were cut off, so it never loaded. Fixed, and it now finds you by itself once location is allowed\n\n"
            + "3.7  The Coin Shop\n"
            + " - My character: a pixel art figure of you. Skin, hair, tops, hats, glasses, capes, shoes. Dress him with coins (Shop page or long-press the wizard)\n"
            + " - Double coins now comes in 1 hour (150), 1 day (3000) and 1 week (20000)\n"
            + " - Settings > Coin Shop, or long-press the wizard\n"
            + " - Double-coins potion, quest re-roll, streak shields, fireworks, dragon treats, mystery chest\n"
            + " - Titles from Squire to Emperor, pet hats, 6 premium colour themes\n"
            + " - The bank: save coins and earn 2% a day\n"
            + " - New SHOP page on the status panel with a free daily lucky spin\n"
            + " - Your name on the home screen under the date: elegant, graffiti or neon (Settings > Your name on home)\n"
            + " - New MAP page on the status panel: tap LOCATE to see where you are (OpenStreetMap, nothing saved)\n"
            + " - Castle visitors (from castle stage 2): a knight pays tribute, a merchant sells shop items at 40% off, a thief steals coins unless you tap him in time\n\n"
            + "3.6  New dragon, new pig\n"
            + " - Ember redrawn: bat wings that flap, sleeping and awake poses, fire, 8 colours\n"
            + " - He carries the roast pig to you in his claws, and the pig has a new look\n"
            + " - The extra towers and the sword are gone\n"
            + " - Admin only: Ember can coil around the main tower\n\n"
            + "3.5  The castle update\n"
            + " - Castle workshop: 10 upgrades (water wheel, lava, sword and banner of your country, towers, dragon, styles)\n"
            + " - Ember the dragon grows up, breathes fire, talks, travels for days, brings roast pigs\n"
            + " - Wizard wardrobe: robes and staff orbs. Second pet at stage 7.\n"
            + " - Long-press the wizard: jokes, riddles, fortune, 8-ball, spells, lesson of the day\n"
            + " - 4 new games: fishing, horse race, treasure map, word of the day\n"
            + " - To-do + habits and a focus timer on the home panel\n"
            + " - Daily login bonus with a streak, sound volume, night tint, reduce motion, left-handed mode\n"
            + " - Backup and restore, health check, safe mode, admin panel\n\n"
            + "3.3  Pets, surprises, quests, critters, pranks, wizard reactions\n"
            + "3.2  Wizard suggestions\n"
            + "3.1  Battery saver\n"
            + "3.0  Gallery and castle";

    /** The newest version's lines are shown with the newest change first, so the top is always what just changed. */
    static String newestFirst() {
        return TEXT;
    }

    static void show(NovaActivity host) {
        new AlertDialog.Builder(host).setTitle("What's new in NOVA " + Theme.OS_VERSION)
                .setMessage(newestFirst()).setPositiveButton("Nice", null).show();
    }

    private static String build(NovaActivity host) {
        try {
            return Theme.OS_VERSION + "." + host.getPackageManager().getPackageInfo(host.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return Theme.OS_VERSION;
        }
    }

    static void showIfNew(NovaActivity host) {
        if (Prefs.getInt("setup_done", 0) == 0) {
            return;
        }
        String seen = Prefs.getString("whatsnew", "");
        String now = build(host);
        if (!seen.equals(now)) {
            Prefs.putString("whatsnew", now);
            if (!seen.isEmpty()) {
                show(host);
            }
        }
    }
}
