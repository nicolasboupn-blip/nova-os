package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The SERVERS page on the quick panel: live player counts for four favourite Arma Reforger servers. Each row looks
 * its server up by name on BattleMetrics (no account, the app sends no token), so there is nothing to set up.
 * If BattleMetrics ever refuses, tap the row and paste the server's gamemonitoring.net page link instead, which
 * is read from that site's key-free API. Refreshes by itself every minute while the page is on screen.
 */
final class ServersWidget extends LinearLayout {
    private static final int FAVS = 4;
    private static final String API = "https://api.gamemonitoring.net/servers/";
    private static final String BM = "https://api.battlemetrics.com/servers";
    private static final String SITE = "https://gamemonitoring.net/arma-reforger";
    private static final String[] DEFAULTS = {"WCS Serhiivka East", "WCS Serhiivka West",
        "Spearhead Yunakivka", "NEXTGEN France"};
    private static final long REFRESH_MS = 60_000L;

    private static final class Result {
        String name = "";
        int players;
        int max;
        boolean online;
        String err = "";
        boolean ok;
    }

    private final NovaActivity host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView[] labels = new TextView[FAVS];
    private final TextView[] subs = new TextView[FAVS];
    private final TextView[] counts = new TextView[FAVS];
    private final Result[] results = new Result[FAVS];
    private final TextView status;
    private String statusText = "loading...";
    private boolean loading;
    private long lastLoad;

    private final Runnable auto = new Runnable() {
        @Override
        public void run() {
            if (isShown()) {
                load(false);
            }
            ui.postDelayed(this, REFRESH_MS);
        }
    };

    ServersWidget(NovaActivity host) {
        super(host);
        this.host = host;
        setOrientation(VERTICAL);
        for (int i = 0; i < FAVS; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(host);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(5), dp(10), dp(5));
            row.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
            row.setClickable(true);
            Theme.ripple(row);
            row.setOnClickListener(v -> edit(idx));
            LinearLayout left = new LinearLayout(host);
            left.setOrientation(VERTICAL);
            labels[i] = mono(DEFAULTS[i].toUpperCase(Locale.ROOT), 11f, Theme.TEXT);
            labels[i].setSingleLine(true);
            labels[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i] = mono("", 8f, Theme.DIM);
            subs[i].setSingleLine(true);
            subs[i].setEllipsize(TextUtils.TruncateAt.END);
            subs[i].setVisibility(GONE);
            left.addView(labels[i]);
            left.addView(subs[i]);
            row.addView(left, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
            counts[i] = mono("--", 13f, Theme.DIM);
            counts[i].setPadding(dp(8), 0, 0, 0);
            row.addView(counts[i]);
            LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(3);
            addView(row, lp);
        }
        LinearLayout bottom = new LinearLayout(host);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        status = mono(statusText, 9f, Theme.DIM);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.END);
        bottom.addView(status, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        bottom.addView(button("REFRESH", () -> load(true)));
        LayoutParams bp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(4);
        addView(bottom, bp);
        render();
    }

    /** Called when the page is shown. */
    void refresh() {
        render();
        load(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ui.postDelayed(auto, REFRESH_MS);
    }

    @Override
    protected void onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ settings

    private static String serverId(int i) {
        String id = Prefs.getString("srv_gm" + i, "");
        return id == null ? "" : id.trim();
    }

    /** Pulls the server number out of a gamemonitoring.net link, or accepts a bare number. */
    private static String parseId(String s) {
        String t = s.trim();
        Matcher m = Pattern.compile("servers/(\\d+)").matcher(t);
        if (m.find()) {
            return m.group(1);
        }
        return t.matches("\\d+") ? t : "";
    }

    // ------------------------------------------------------------------ loading

    private void load(boolean force) {
        long now = System.currentTimeMillis();
        if (loading || (!force && now - lastLoad < 40_000L)) {
            return;
        }
        loading = true;
        lastLoad = now;
        statusText = "updating...";
        status.setText(statusText);
        new Thread(() -> {
            final Result[] res = new Result[FAVS];
            for (int i = 0; i < FAVS; i++) {
                res[i] = fetchOne(i);
            }
            ui.post(() -> {
                loading = false;
                int bad = 0;
                String firstErr = "";
                for (int i = 0; i < FAVS; i++) {
                    results[i] = res[i];
                    if (!res[i].ok) {
                        bad++;
                        if (firstErr.isEmpty()) {
                            firstErr = res[i].err;
                        }
                    }
                }
                String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                if (bad == FAVS && firstErr.equals("blocked")) {
                    statusText = "BattleMetrics refused: tap a row and paste a gamemonitoring link";
                } else if (bad == FAVS) {
                    statusText = firstErr + " · " + time;
                } else {
                    statusText = "updated " + time;
                }
                render();
            });
        }).start();
    }

    private Result fetchOne(int i) {
        Result r = new Result();
        String id = serverId(i);
        String body = Http.get(id.isEmpty() ? searchUrl(DEFAULTS[i]) : API + id);
        if (body == null) {
            r.err = errFor(Http.lastCode);
            return r;
        }
        try {
            JSONObject root = new JSONObject(body);
            if (id.isEmpty()) {
                JSONArray arr = root.optJSONArray("data");
                if (arr == null) {
                    r.err = "bad reply";
                    return r;
                }
                bestMatch(arr, DEFAULTS[i], r);
                if (!r.ok) {
                    r.err = "not found";
                }
                return r;
            }
            JSONObject o = root.optJSONObject("response");
            if (o == null) {
                r.err = "not found";
                return r;
            }
            r.name = o.optString("name");
            r.players = o.optInt("numplayers", 0);
            r.max = o.optInt("maxplayers", 0);
            r.online = o.optBoolean("status", false);
            r.ok = true;
        } catch (Exception e) {
            r.err = "bad reply";
        }
        return r;
    }

    private static String searchUrl(String q) {
        try {
            return BM + "?filter%5Bgame%5D=reforger&filter%5Bsearch%5D=" + URLEncoder.encode(q, "UTF-8")
                    + "&page%5Bsize%5D=10&sort=-players";
        } catch (Exception e) {
            return BM + "?filter%5Bgame%5D=reforger&page%5Bsize%5D=10&sort=-players";
        }
    }

    /** Fills r from the busiest server whose name has every word of the phrase, or the first result if none does. */
    private static void bestMatch(JSONArray arr, String q, Result r) {
        String[] words = q.toLowerCase(Locale.ROOT).split("\\s+");
        JSONObject pick = null;
        JSONObject first = null;
        int pickPlayers = -1;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            JSONObject a = o == null ? null : o.optJSONObject("attributes");
            if (a == null) {
                continue;
            }
            if (first == null) {
                first = a;
            }
            String n = a.optString("name").toLowerCase(Locale.ROOT);
            boolean all = true;
            for (String w : words) {
                if (!n.contains(w)) {
                    all = false;
                    break;
                }
            }
            if (all && a.optInt("players", 0) > pickPlayers) {
                pick = a;
                pickPlayers = a.optInt("players", 0);
            }
        }
        JSONObject a = pick != null ? pick : first;
        if (a == null) {
            return;
        }
        r.name = a.optString("name");
        r.players = a.optInt("players", 0);
        r.max = a.optInt("maxPlayers", 0);
        r.online = "online".equalsIgnoreCase(a.optString("status"));
        r.ok = true;
    }

    private static String errFor(int code) {
        if (code == 401 || code == 403) {
            return "blocked";
        }
        if (code == 404) {
            return "not found";
        }
        if (code == 429) {
            return "rate limit";
        }
        return code <= 0 ? "no network" : "error " + code;
    }

    // ------------------------------------------------------------------ drawing

    private void render() {
        for (int i = 0; i < FAVS; i++) {
            Result r = results[i];
            if (r == null) {
                counts[i].setTextSize(13f);
                counts[i].setText(loading ? "..." : "--");
                counts[i].setTextColor(Theme.DIM);
                subs[i].setVisibility(GONE);
                continue;
            }
            if (!r.ok) {
                counts[i].setTextSize(10f);
                counts[i].setText(r.err);
                counts[i].setTextColor(0xFFFF6B7F);
                subs[i].setVisibility(GONE);
                continue;
            }
            counts[i].setTextSize(13f);
            counts[i].setText(r.online ? r.players + "/" + r.max : "offline");
            counts[i].setTextColor(r.online ? Theme.ACCENT : Theme.DIM);
            subs[i].setText(r.name);
            subs[i].setVisibility(r.name.isEmpty() || r.name.equalsIgnoreCase(DEFAULTS[i]) ? GONE : VISIBLE);
        }
        status.setText(statusText);
    }

    // ------------------------------------------------------------------ dialogs

    /** Tap a row: paste the server's gamemonitoring.net link (or number) to set it, or clear it. */
    private void edit(final int i) {
        final EditText e = new EditText(host);
        e.setSingleLine(true);
        e.setHint("gamemonitoring.net link or number");
        String cur = serverId(i);
        String clip = clipboard();
        e.setText(clip.contains("gamemonitoring") ? clip : cur);
        new AlertDialog.Builder(host)
                .setTitle(DEFAULTS[i])
                .setMessage("Optional. Rows find their server by name by themselves. To lock this row to one exact "
                        + "server, find it on gamemonitoring.net (game: Arma Reforger), open its page and paste "
                        + "the link here. Leave empty to go back to automatic.")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    String text = e.getText().toString().trim();
                    String id = text.isEmpty() ? "" : parseId(text);
                    if (!text.isEmpty() && id.isEmpty()) {
                        statusText = "that is not a gamemonitoring link";
                        status.setText(statusText);
                        return;
                    }
                    Prefs.putString("srv_gm" + i, id);
                    results[i] = null;
                    load(true);
                    render();
                })
                .setNeutralButton("FIND ON SITE", (d, w) -> {
                    try {
                        host.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SITE)));
                    } catch (Exception ignored) {
                        // no browser, nothing to open
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private String clipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) host.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm == null ? null : cm.getPrimaryClip();
            if (d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null) {
                return d.getItemAt(0).getText().toString().trim();
            }
        } catch (Exception ignored) {
            // clipboard not readable right now
        }
        return "";
    }

    // ------------------------------------------------------------------ small helpers

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView mono(String text, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView button(String text, Runnable action) {
        TextView b = mono(text, 9f, Theme.TEXT);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setBackground(Theme.rounded(Theme.PANEL, 10f, host));
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(v -> action.run());
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }
}
