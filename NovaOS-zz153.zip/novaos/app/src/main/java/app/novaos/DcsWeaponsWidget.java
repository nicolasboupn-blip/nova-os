package app.novaos;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * DCS WEAPONS: pick a weapon from your real loadout, tap a contact on the radar to make it your target, see whether
 * it's in range, STEER onto it, LOCK it and FIRE under a safety cover. Weapon select, master arm, lock and fire are
 * the aircraft's own keys over the PC REMOTE Bluetooth link (all editable in KEYS); the loadout, contacts and lock
 * come from NovaExport.lua. Ranges are rough estimates (altitude and aspect), not the jet's own DLZ.
 */
final class DcsWeaponsWidget extends NovaWidget {
    private static final int GREEN = 0xFF30D158;
    private static final int AMBER = 0xFFFFB020;
    private static final int RED = 0xFFFF453A;
    private static final int HUD = 0xFF3CFF7A;
    private static final int[] RANGES = {5, 10, 20, 40, 80, 160};
    private static final String K_RANGE = "dcsw_range";
    private static final String K_FILTER = "dcsw_filter";

    private static final int GUN = 0;
    private static final int AAM = 1;
    private static final int AGM = 2;
    private static final int BOMB = 3;
    private static final int ROCKET = 4;

    // keys
    private static final String[] ACT = {"ARM", "AIM9", "AIM7", "AIM120", "GUN", "NEXT", "BVR", "BORE", "LOCK", "UNLOCK",
        "FIRE_AA", "FIRE_AG"};
    private static final String[] ACT_NAMES = {"Master arm", "Select Sidewinder", "Select Sparrow", "Select AMRAAM",
        "Select gun", "Next weapon", "Radar BVR / search mode", "Close-range auto-lock mode", "Lock", "Unlock / drop lock",
        "Fire (air-to-air and gun)", "Release (air-to-ground)"};

    private static String def(String fam, int a) {
        if (fam.equals("hornet")) {
            String[] h = {"M", "LSHIFT+S", "LSHIFT+W", "LSHIFT+D", "LSHIFT+X", "", "", "RALT+SEMICOLON", "RALT+SEMICOLON", "S",
                "SPACE", "RALT+SPACE"};
            return h[a];
        }
        if (fam.equals("frogfoot")) {
            String[] f = {"", "", "", "", "C", "D", "", "", "ENTER", "BKSP", "SPACE", "SPACE"};
            return f[a];
        }
        String[] k = {"", "", "", "", "C", "D", "2", "4", "ENTER", "BKSP", "SPACE", "SPACE"};
        return k[a];
    }

    /** A weapon type in the loadout. */
    private static final class W {
        String name;
        int count;
        int kind;
        float maxNm;
        float minNm;
        int station;
    }

    /** A missile on its way (estimated). */
    private static final class Shot {
        String weapon;
        String target;
        String tgtId;
        long t0;
        float tti;
        boolean inRange;
        boolean active;
    }

    private final boolean big;
    private final TextView status;
    private final TextView armChip;
    private final TextView rangeChip;
    private final TextView filterChip;
    private final LinearLayout weaponRow;
    private final Scope scope;
    private final TextView info;
    private final TextView shotsView;
    private final TextView steerChip;
    private final FireButton fire;
    private LinearLayout list;
    private String builtLoad = "";
    private String sel = "";
    private String target = "";
    private final Map<String, float[]> prev = new HashMap<>();
    private final Map<String, Float> closure = new HashMap<>();
    private final List<Shot> shots = new ArrayList<>();
    private Map<String, Integer> lastCounts = new HashMap<>();
    private boolean steering;
    private boolean cycling;
    private long lastAuto;
    private static final Map<String, Integer> SIM_LOAD = new LinkedHashMap<>();
    private static String simFam = "";
    private final Runnable onData = this::data;

    DcsWeaponsWidget(NovaActivity host) {
        this(host, false);
    }

    DcsWeaponsWidget(NovaActivity host, boolean big) {
        super(host);
        this.big = big;
        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        status = text("", 10f, Theme.DIM);
        status.setSingleLine(true);
        status.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        armChip = chip("ARM", () -> {
            if (key(0, true)) {
                host.buzz(30);
                host.toast("MASTER ARM");
            }
        });
        top.addView(armChip, wrap());
        rangeChip = chip("", () -> {
            Prefs.putInt(K_RANGE, (Prefs.getInt(K_RANGE, 2) + 1) % RANGES.length);
            paintChips();
            invalidateScope();
        });
        top.addView(rangeChip, wrap());
        filterChip = chip("", () -> {
            Prefs.putInt(K_FILTER, (Prefs.getInt(K_FILTER, 0) + 1) % 3);
            paintChips();
            data();
        });
        top.addView(filterChip, wrap());
        if (!big) {
            top.addView(chip("⤢", this::openBig), wrap());
        }
        addView(top, wide());

        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        weaponRow = row();
        weaponRow.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        hs.addView(weaponRow);
        addView(hs, wide());

        scope = new Scope(host);
        if (big) {
            addView(scope, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.4f));
        } else {
            addView(scope, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(250)));
        }
        info = text("", big ? 12f : 10.5f, Theme.TEXT);
        info.setGravity(Gravity.START);
        info.setPadding(dp(6), dp(4), dp(6), dp(2));
        addView(info, wide());
        shotsView = text("", 10f, AMBER);
        shotsView.setGravity(Gravity.START);
        shotsView.setPadding(dp(6), 0, dp(6), dp(2));
        addView(shotsView, wide());

        LinearLayout ctl = row();
        steerChip = chip("STEER", this::toggleSteer);
        ctl.addView(steerChip, weight(1f));
        ctl.addView(chip("LOCK", this::lock), weight(1f));
        ctl.addView(chip("UNLOCK", () -> {
            if (key(9, true)) {
                host.toast("Lock dropped");
            }
        }), weight(1f));
        ctl.addView(chip("KEYS", this::keysDialog), weight(1f));
        addView(ctl, wide());

        fire = new FireButton(host);
        addView(fire, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(big ? 84 : 64)));

        if (big) {
            ScrollView sv = new ScrollView(host);
            list = new LinearLayout(host);
            list.setOrientation(VERTICAL);
            sv.addView(list);
            addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 0.6f));
        }
        paintChips();
    }

    private void invalidateScope() {
        if (scope != null) {
            scope.invalidate();
        }
    }

    private LinearLayout.LayoutParams wrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        return lp;
    }

    private String fam() {
        return DcsCockpitWidget.family(DcsLink.st.name);
    }

    private void paintChips() {
        rangeChip.setText(RANGES[Prefs.getInt(K_RANGE, 2)] + " NM");
        String[] f = {"ALL", "AIR", "GND"};
        filterChip.setText(f[Prefs.getInt(K_FILTER, 0)]);
        armChip.setVisibility(spec(0).isEmpty() ? GONE : VISIBLE);
        steerChip.setText(steering ? "STEER ON" : "STEER");
        pick(steerChip, steering);
    }

    @Override
    void onLive(boolean on) {
        if (on) {
            DcsLink.start(host);
            DcsLink.listen(onData);
        } else {
            DcsLink.unlisten(onData);
            DcsLink.stop();
            if (steering) {
                toggleSteer();
            }
        }
    }

    @Override
    long tickMs() {
        return 250;
    }

    @Override
    void tick() {
        data();
    }

    // ------------------------------------------------------------------ loadout

    private static int kind(DcsLink.Wpn w) {
        String u = w.name.toUpperCase(Locale.ROOT);
        if (u.contains("FUEL") || u.contains("TANK") || u.contains("POD") || u.contains("ALQ") || u.contains("LITENING")
                || u.contains("ATFLIR") || u.contains("SMOKE") || u.contains("PTB") || u.contains("AN/") || u.contains("LANTIRN")) {
            return -1;
        }
        if (u.startsWith("AIM") || u.matches("R-?(27|73|77|60|33|40|24|23|13|3|550|530|PL).*") || u.contains("MAGIC")
                || u.contains("PL-") || u.contains("PYTHON") || u.contains("SD-10") || u.contains("MICA") || u.contains("IRIS")) {
            return AAM;
        }
        if (w.lvl2 == 4 && w.lvl3 == 7) {
            return AAM;
        }
        if (u.contains("KH-") || u.contains("KH ") || u.startsWith("AGM") || u.contains("VIKHR") || u.contains("9M") || u.contains("S-25L")
                || u.contains("MAVERICK") || u.contains("HARM") || u.contains("JSOW") || u.contains("SLAM") || w.lvl2 == 4) {
            return AGM;
        }
        if (u.contains("S-8") || u.contains("S-13") || u.contains("S-25") || u.contains("S-24") || u.contains("LAU") || u.contains("HYDRA")
                || u.contains("B-8") || u.contains("B8") || u.contains("ZUNI") || u.contains("UB-") || w.lvl2 == 7) {
            return ROCKET;
        }
        if (u.contains("GBU") || u.contains("MK-") || u.contains("MK8") || u.contains("FAB") || u.contains("KAB") || u.contains("CBU")
                || u.contains("BDU") || u.contains("RBK") || u.contains("OFAB") || u.contains("BOMB") || w.lvl2 == 5) {
            return BOMB;
        }
        return w.name.isEmpty() ? -1 : AGM;
    }

    /** {max, min} range in NM, rough, for a medium-altitude head-on shot. */
    private static float[] range(String name, int kind) {
        String u = name.toUpperCase(Locale.ROOT);
        String[][] t = {{"AIM-120", "40", "1"}, {"AIM-7", "25", "1"}, {"AIM-9", "9", "0.4"}, {"R-77", "35", "1"},
            {"R-27ER", "38", "1"}, {"R-27ET", "30", "1"}, {"R-27R", "25", "1"}, {"R-27T", "18", "1"}, {"R-73", "11", "0.3"},
            {"R-60", "5", "0.3"}, {"R-33", "60", "2"}, {"R-40", "25", "1"}, {"MICA", "30", "1"}, {"MAGIC", "8", "0.3"},
            {"SD-10", "38", "1"}, {"PL-5", "8", "0.3"}, {"PL-8", "10", "0.3"}, {"KH-25", "5.5", "1"}, {"KH-29", "6", "1"},
            {"KH-31", "50", "5"}, {"KH-58", "60", "5"}, {"VIKHR", "5.4", "0.5"}, {"9M127", "5.4", "0.5"}, {"AGM-65", "8", "0.5"},
            {"AGM-88", "50", "5"}, {"AGM-154", "35", "3"}, {"AGM-84", "60", "5"}, {"S-25L", "4", "0.5"}};
        for (String[] r : t) {
            if (u.contains(r[0])) {
                return new float[] {Float.parseFloat(r[1]), Float.parseFloat(r[2])};
            }
        }
        switch (kind) {
            case GUN:
                return new float[] {0.8f, 0.05f};
            case AAM:
                return new float[] {12f, 0.5f};
            case ROCKET:
                return new float[] {2.5f, 0.3f};
            case BOMB:
                return new float[] {3f, 0.2f};
            default:
                return new float[] {6f, 0.5f};
        }
    }

    private List<W> weapons() {
        LinkedHashMap<String, W> m = new LinkedHashMap<>();
        W gun = new W();
        gun.name = "GUN";
        gun.kind = GUN;
        int shells = DcsLink.st.shells;
        gun.count = shells;
        float[] gr = range("GUN", GUN);
        gun.maxNm = gr[0];
        gun.minNm = gr[1];
        m.put("GUN", gun);
        if (DcsLink.sim) {
            simLoad();
            for (Map.Entry<String, Integer> e : SIM_LOAD.entrySet()) {
                W w = new W();
                w.name = e.getKey();
                w.count = e.getValue();
                w.kind = w.name.startsWith("AIM") || w.name.startsWith("R-") ? AAM : AGM;
                float[] r = range(w.name, w.kind);
                w.maxNm = r[0];
                w.minNm = r[1];
                m.put(w.name, w);
            }
            if (gun.count < 0) {
                gun.count = 500;
            }
        } else {
            for (DcsLink.Wpn x : DcsLink.loadout) {
                int k = kind(x);
                if (k < 0) {
                    continue;
                }
                W w = m.get(x.name);
                if (w == null) {
                    w = new W();
                    w.name = x.name;
                    w.kind = k;
                    w.station = x.station;
                    float[] r = range(x.name, k);
                    w.maxNm = r[0];
                    w.minNm = r[1];
                    m.put(x.name, w);
                }
                w.count += x.count;
            }
        }
        return new ArrayList<>(m.values());
    }

    private void simLoad() {
        String f = fam();
        if (f.equals(simFam) && !SIM_LOAD.isEmpty()) {
            return;
        }
        simFam = f;
        SIM_LOAD.clear();
        if (f.equals("hornet")) {
            SIM_LOAD.put("AIM-9X", 2);
            SIM_LOAD.put("AIM-120C", 4);
            SIM_LOAD.put("AIM-7M", 2);
        } else if (f.equals("frogfoot")) {
            SIM_LOAD.put("R-60M", 2);
            SIM_LOAD.put("9M127 Vikhr", 16);
            SIM_LOAD.put("Kh-25ML", 2);
        } else {
            SIM_LOAD.put("R-73", 4);
            SIM_LOAD.put("R-27ER", 2);
            SIM_LOAD.put("R-27ET", 2);
        }
    }

    private W selected(List<W> ws) {
        for (W w : ws) {
            if (w.name.equals(sel)) {
                return w;
            }
        }
        return null;
    }

    /** Name of the weapon the jet itself has selected now, or "". */
    private String inJet() {
        int cs = DcsLink.curStation;
        for (DcsLink.Wpn x : DcsLink.loadout) {
            if (x.station == cs) {
                return x.name;
            }
        }
        return "";
    }

    private void buildWeapons(List<W> ws) {
        StringBuilder sig = new StringBuilder(fam());
        for (W w : ws) {
            sig.append(w.name).append(w.count).append(',');
        }
        sig.append(sel).append(inJet());
        if (sig.toString().equals(builtLoad)) {
            return;
        }
        builtLoad = sig.toString();
        weaponRow.removeAllViews();
        String jet = inJet();
        for (final W w : ws) {
            String c = w.count >= 0 ? (w.kind == GUN ? "  " + w.count : "  ×" + w.count) : "";
            TextView t = chip(w.name + c, () -> select(w));
            t.setTextSize(big ? 12f : 10.5f);
            pick(t, w.name.equals(sel));
            if (!w.name.equals(sel) && !jet.isEmpty() && w.name.equals(jet)) {
                t.setTextColor(GREEN);
            }
            if (w.count == 0) {
                t.setAlpha(0.4f);
            }
            weaponRow.addView(t, wrap());
        }
        if (ws.size() <= 1 && !DcsLink.sim) {
            TextView t = text(DcsLink.live() ? "  waiting for the loadout (needs the new NovaExport.lua: SETUP in DCS COCKPIT)"
                    : "  start DCS or SIM in DCS COCKPIT", 9.5f, Theme.DIM);
            weaponRow.addView(t);
        }
    }

    private void select(final W w) {
        sel = w.name;
        builtLoad = "";
        host.buzz(15);
        data();
        if (DcsLink.sim) {
            host.toast(w.name + " selected (SIM)");
            return;
        }
        String f = fam();
        String u = w.name.toUpperCase(Locale.ROOT);
        if (w.kind == GUN) {
            key(4, true);
            return;
        }
        if (f.equals("hornet")) {
            if (u.contains("AIM-9")) {
                key(1, true);
            } else if (u.contains("AIM-7")) {
                key(2, true);
            } else if (u.contains("AIM-120")) {
                key(3, true);
            } else {
                host.toast("Pick " + w.name + " on the left DDI (STORES page). LOCK and FIRE work from here");
            }
            return;
        }
        if (spec(5).isEmpty()) {
            return;
        }
        if (w.kind == AAM && !spec(6).isEmpty()) {
            key(6, true);
        }
        cycle(w.name);
    }

    /** FC3 jets only have NEXT WEAPON: press it until the jet reports the weapon you picked. */
    private void cycle(final String name) {
        if (cycling || !PcHid.connected()) {
            if (!PcHid.connected()) {
                host.toast("Not connected: tap CONNECT in KEY DECK or PC REMOTE");
            }
            return;
        }
        cycling = true;
        new Thread(() -> {
            for (int i = 0; i < 8 && !inJet().equals(name); i++) {
                Object[] k = DcsKeysWidget.parse(spec(5));
                PcHid.tap((int) k[0], PcHid.rawCode((String) k[1]), 1, 40);
                SystemClock.sleep(1200);
            }
            cycling = false;
            final boolean ok = inJet().equals(name);
            ui.post(() -> {
                builtLoad = "";
                host.toast(ok ? name + " selected" : "Couldn't find " + name + " with NEXT WEAPON (wrong master mode?)");
            });
        }, "nova-dcs-wpn").start();
    }

    // ------------------------------------------------------------------ keys

    /** DCS command names (lower case regex) for each action, to find YOUR key when NOVA's default isn't a DCS one. */
    private static final String[] ACT_RX = {"master arm", "sidewinder", "sparrow", "amraam", "gun (select|mode)|select gun",
        "weapon change|next weapon|weapon select", "bvr|beyond visual", "bore", "lock target|target lock|tdc depress",
        "unlock|drop lock|undesignate|break lock", "trigger|fire weapon|weapon fire|gun fire",
        "weapon release|release weapon|pickle"};

    /** Your key override in NOVA, else your DCS key for this command, else NOVA's default. */
    private String spec(int a) {
        String own = Prefs.getString("dcsw_" + fam() + "_" + ACT[a], null);
        if (own != null) {
            return own;
        }
        String d = def(fam(), a);
        if (!d.isEmpty() && DcsLink.knows(d)) {
            return DcsLink.mine(d);
        }
        String n = DcsLink.byName(ACT_RX[a]);
        return n != null ? n : d;
    }

    /** Taps (or holds) a weapons key. Returns false when it can't. */
    private boolean key(int a, boolean tap) {
        if (DcsLink.sim) {
            return true;
        }
        String s = spec(a);
        if (s.isEmpty()) {
            host.toast(ACT_NAMES[a] + ": no key set for this jet (KEYS)");
            return false;
        }
        if (!PcHid.connected()) {
            host.toast("Not connected: tap CONNECT in KEY DECK or PC REMOTE (or try SIM)");
            return false;
        }
        Object[] k = DcsKeysWidget.parse(s);
        PcHid.tap((int) k[0], PcHid.rawCode((String) k[1]), (int) k[2], 40);
        return true;
    }

    private void hold(int a, boolean down) {
        if (DcsLink.sim || !PcHid.connected() || spec(a).isEmpty()) {
            return;
        }
        Object[] k = DcsKeysWidget.parse(spec(a));
        PcHid.hold((int) k[0], PcHid.rawCode((String) k[1]), down);
    }

    private void keysDialog() {
        final String f = fam();
        String[] items = new String[ACT.length + 1];
        for (int i = 0; i < ACT.length; i++) {
            String s = spec(i);
            items[i] = ACT_NAMES[i] + ":  " + (s.isEmpty() ? "—" : DcsKeysWidget.pretty(s));
        }
        items[ACT.length] = "↺ Reset to the DCS defaults";
        new AlertDialog.Builder(host).setTitle("Weapon keys for " + f.toUpperCase(Locale.ROOT)).setItems(items, (d, w) -> {
            if (w == ACT.length) {
                for (String a : ACT) {
                    Prefs.putString("dcsw_" + f + "_" + a, null);
                }
                host.toast("Back to the DCS default keys");
                paintChips();
                return;
            }
            final EditText e = new EditText(host);
            e.setSingleLine(true);
            e.setText(spec(w));
            e.setHint("e.g. SPACE, RALT+SPACE, LSHIFT+D (empty = none)");
            new AlertDialog.Builder(host).setTitle(ACT_NAMES[w]).setMessage("The same key you have in DCS > Controls.")
                    .setView(e).setPositiveButton("SAVE", (dd, ww) -> {
                        Prefs.putString("dcsw_" + f + "_" + ACT[w], e.getText().toString().trim().toUpperCase(Locale.ROOT));
                        paintChips();
                    }).setNegativeButton("CANCEL", null).show();
        }).show();
    }

    // ------------------------------------------------------------------ target, lock, steer

    private DcsLink.Obj find(String id) {
        if (id.isEmpty()) {
            return null;
        }
        for (DcsLink.Obj o : DcsLink.objs) {
            if (id.equals(o.id)) {
                return o;
            }
        }
        return null;
    }

    private static double dist(DcsLink.Obj o) {
        DcsLink.State s = DcsLink.st;
        return Math.hypot(o.x - s.x, o.z - s.z);
    }

    /** Bearing off the nose, -180..180. */
    private static float rel(DcsLink.Obj o) {
        DcsLink.State s = DcsLink.st;
        double b = Math.toDegrees(Math.atan2(o.z - s.z, o.x - s.x));
        double r = b - s.hdg;
        while (r > 180) {
            r -= 360;
        }
        while (r < -180) {
            r += 360;
        }
        return (float) r;
    }

    /** 0 = coming straight at you, 180 = flying away. */
    private static float aspect(DcsLink.Obj o) {
        DcsLink.State s = DcsLink.st;
        double toMe = Math.toDegrees(Math.atan2(s.z - o.z, s.x - o.x));
        double a = Math.abs(toMe - o.hdg) % 360;
        return (float) (a > 180 ? 360 - a : a);
    }

    /** Estimated max range now for weapon w against o. */
    private static float rmax(W w, DcsLink.Obj o) {
        if (w == null) {
            return 0;
        }
        if (w.kind != AAM) {
            return w.maxNm;
        }
        float altK = 0.45f + 0.55f * Math.min(1f, (DcsLink.st.alt + (o == null ? DcsLink.st.alt : o.alt)) / 2f / 9000f);
        float asp = o == null ? 0 : aspect(o);
        float aspK = 0.6f + 0.6f * (float) ((Math.cos(Math.toRadians(asp)) + 1) / 2);
        return w.maxNm * altK * Math.min(1.15f, aspK);
    }

    private boolean isEnemy(DcsLink.Obj o) {
        int me = DcsLink.st.coal;
        return o.coal != 0 && me != 0 ? o.coal != me : o.coal == 1;
    }

    private void toggleSteer() {
        steering = !steering;
        if (steering) {
            DcsLink.Obj o = find(target);
            if (o == null) {
                steering = false;
                host.toast("Tap a target on the radar first");
            } else {
                DcsLink.apTx = o.x;
                DcsLink.apTz = o.z;
                DcsLink.apAlt = DcsLink.st.alt;
                DcsLink.apAltOn = false;
                DcsLink.setAp(2);
                host.toast("Steering onto " + o.name + " (you keep pitch). Stick input or STEER again to stop");
            }
        } else {
            DcsLink.setAp(0);
        }
        paintChips();
    }

    private void lock() {
        DcsLink.Obj o = find(target);
        if (o == null) {
            host.toast("Tap a target on the radar first");
            return;
        }
        if (DcsLink.sim) {
            host.toast("SIM: locked " + o.name);
            return;
        }
        double nm = dist(o) / 1852.0;
        float r = Math.abs(rel(o));
        String f = fam();
        if (f.equals("hornet")) {
            if (nm > 10 || r > 10) {
                host.toast("Hornet auto-lock: get it within 10 NM and on the nose (STEER helps), then LOCK. "
                        + String.format(Locale.ROOT, "Now %.1f NM, %.0f° off", nm, r));
                if (!steering) {
                    toggleSteer();
                }
                return;
            }
            key(7, true);
            host.toast("ACM boresight: locks the first jet on the nose");
            return;
        }
        if (nm < 5.4 && r < 12 && !spec(7).isEmpty()) {
            key(7, true);
            ui.postDelayed(() -> key(8, true), 400);
            host.toast("Close range: BORE + LOCK");
        } else {
            key(8, true);
            if (nm >= 5.4) {
                host.toast("LOCK pressed: locks what's under the radar cursor. Under 5 NM on the nose NOVA can auto-lock");
            }
        }
    }

    // ------------------------------------------------------------------ live data

    private void data() {
        if (!live()) {
            return;
        }
        DcsLink.State s = DcsLink.st;
        boolean on = DcsLink.live();
        List<W> ws = weapons();
        buildWeapons(ws);
        long now = SystemClock.elapsedRealtime();
        // closure from successive positions
        for (DcsLink.Obj o : DcsLink.objs) {
            float d = (float) dist(o);
            float[] p = prev.get(o.id);
            if (p == null || now - (long) p[1] > 400) {
                if (p != null && now - (long) p[1] < 5000) {
                    float c = -(d - p[0]) / ((now - (long) p[1]) / 1000f);
                    Float old = closure.get(o.id);
                    closure.put(o.id, old == null ? c : old * 0.6f + c * 0.4f);
                }
                prev.put(o.id, new float[] {d, now});
            }
        }
        // shots: counts going down = something left the rail
        Map<String, Integer> counts = new HashMap<>();
        for (W w : ws) {
            if (w.kind != GUN) {
                counts.put(w.name, w.count);
            }
        }
        if (!DcsLink.sim) {
            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                Integer was = lastCounts.get(e.getKey());
                if (was != null && e.getValue() < was && lastCounts.size() > 0) {
                    W w = null;
                    for (W x : ws) {
                        if (x.name.equals(e.getKey())) {
                            w = x;
                        }
                    }
                    shot(w);
                }
            }
        }
        lastCounts = counts;

        W w = selected(ws);
        DcsLink.Obj o = find(target);
        if (steering && o != null) {
            DcsLink.apTx = o.x;
            DcsLink.apTz = o.z;
            if (DcsLink.apMode != 2) {
                DcsLink.setAp(2);
            }
        } else if (steering && o == null) {
            toggleSteer();
        }
        String fm = fam();
        String head = on ? "● " + (DcsLink.sim ? "SIM · " : "") + (s.name.isEmpty() ? "DCS" : s.name)
                + (DcsLink.haveKeys() && !DcsLink.sim ? "  \u2714 YOUR KEYS" : "")
                : "○ No DCS data (start a mission, or SIM in DCS COCKPIT)";
        String jet = inJet();
        if (on && !jet.isEmpty()) {
            head += "  ·  jet has " + jet;
        }
        status.setText(head);
        status.setTextColor(on ? HUD : Theme.DIM);

        StringBuilder b = new StringBuilder();
        if (o == null) {
            b.append(target.isEmpty() ? "Tap a contact on the radar to make it your target" : "Target lost");
            if (s.lockDist > 0) {
                b.append(String.format(Locale.ROOT, "\nJET LOCK: %s  %.1f NM", s.lockName, s.lockDist / 1852.0));
            }
        } else {
            double nm = dist(o) / 1852.0;
            float r = rel(o);
            float asp = aspect(o);
            Float cl = closure.get(o.id);
            boolean locked = o.id.equals(s.lockId) && !o.id.isEmpty();
            b.append(locked ? "◆ LOCKED  " : "◇ TARGET  ").append(o.name).append(isEnemy(o) ? "  (hostile)" : "  (FRIENDLY!)");
            b.append(String.format(Locale.ROOT, "\n%.1f NM  ·  %s %.0f°  ·  %,d ft  ·  %s (aspect %.0f°)",
                    nm, r < 0 ? "L" : "R", Math.abs(r), Math.round(o.alt * 3.281f),
                    asp < 45 ? "HOT" : asp > 135 ? "COLD" : "FLANKING", asp));
            if (cl != null) {
                b.append(String.format(Locale.ROOT, "  ·  closing %d kt", Math.round(cl * 1.944f)));
            }
            if (w != null) {
                float rm = rmax(w, o);
                b.append("\n").append(w.name).append(": ");
                if (o.cat != 1 && w.kind == AAM) {
                    b.append("air-to-air weapon, pick a ground weapon");
                } else if (o.cat == 1 && (w.kind == AGM || w.kind == BOMB || w.kind == ROCKET)) {
                    b.append("ground weapon, pick a missile");
                } else if (nm < w.minNm) {
                    b.append("TOO CLOSE");
                } else if (nm <= rm * 0.45f) {
                    b.append(String.format(Locale.ROOT, "IN RANGE ✔✔ no escape (max ~%.0f NM)", rm));
                } else if (nm <= rm) {
                    b.append(String.format(Locale.ROOT, "IN RANGE ✔ (max ~%.0f NM)", rm));
                } else {
                    b.append(String.format(Locale.ROOT, "TOO FAR: %.1f NM to go (max ~%.0f NM)", nm - rm, rm));
                }
                if (Math.abs(r) > 60 && w.kind != GUN) {
                    b.append("  ·  turn onto it");
                }
            }
        }
        info.setText(b);

        // shot tracker
        StringBuilder sb = new StringBuilder();
        for (int i = shots.size() - 1; i >= 0 && i >= shots.size() - 3; i--) {
            Shot x = shots.get(i);
            float left = x.tti - (now - x.t0) / 1000f;
            DcsLink.Obj t = find(x.tgtId);
            if (left > 0) {
                sb.append(String.format(Locale.ROOT, "➤ %s → %s   impact in ~%.0f s", x.weapon, x.target, left));
                if (x.active) {
                    sb.append("  PITBULL");
                }
            } else if (left > -8) {
                if (DcsLink.sim) {
                    sb.append(x.inRange ? "✹ SPLASH! " + x.target + " (SIM)" : "✖ " + x.weapon + " missed (out of range)");
                } else {
                    sb.append(x.weapon).append(" should be there by now: ").append(t == null ? "target gone ✔" : "target still flying");
                }
            } else {
                continue;
            }
            sb.append('\n');
        }
        shotsView.setText(sb.toString().trim());
        shotsView.setVisibility(sb.length() == 0 ? GONE : VISIBLE);
        if (list != null) {
            buildList();
        }
        armChip.setVisibility(spec(0).isEmpty() ? GONE : VISIBLE);
        if (!fm.equals(simFam) && DcsLink.sim) {
            builtLoad = "";
        }
        scope.invalidate();
        fire.invalidate();
    }

    private void shot(W w) {
        DcsLink.Obj o = find(target);
        Shot x = new Shot();
        x.weapon = w == null ? "weapon" : w.name;
        x.target = o == null ? (DcsLink.st.lockName.isEmpty() ? "?" : DcsLink.st.lockName) : o.name;
        x.tgtId = o == null ? DcsLink.st.lockId : o.id;
        x.t0 = SystemClock.elapsedRealtime();
        double d = o != null ? dist(o) : Math.max(1000, DcsLink.st.lockDist);
        String u = x.weapon.toUpperCase(Locale.ROOT);
        float v = u.contains("AIM-9") || u.contains("R-73") || u.contains("R-60") ? 550 : u.contains("120") || u.contains("R-77") ? 800 : 700;
        if (w != null && w.kind != AAM) {
            v = w.kind == BOMB ? 220 : w.kind == ROCKET ? 600 : 400;
        }
        x.tti = (float) (d / v);
        x.inRange = w != null && o != null && d / 1852.0 <= rmax(w, o) && d / 1852.0 >= w.minNm;
        x.active = u.contains("120") || u.contains("R-77") || u.contains("MICA") || u.contains("SD-10");
        shots.add(x);
        String call = w == null ? "RIFLE" : w.kind == AAM ? (u.contains("AIM-7") || u.contains("R-27R") || u.contains("R-27ER")
                ? "FOX 1" : x.active ? "FOX 3" : "FOX 2") : w.kind == BOMB ? "PICKLE" : "RIFLE";
        host.toast(call + "!  " + x.weapon + " → " + x.target);
        if (x.active) {
            // active seeker on its own about 10 NM out
            final Shot sx = x;
            sx.active = false;
            long pit = (long) (Math.max(0, d - 18500) / v * 1000);
            ui.postDelayed(() -> sx.active = true, pit);
        }
    }

    private void doFire(boolean down) {
        List<W> ws = weapons();
        W w = selected(ws);
        boolean ag = w != null && (w.kind == AGM || w.kind == BOMB || w.kind == ROCKET);
        int a = ag ? 11 : 10;
        if (DcsLink.sim) {
            if (!down) {
                return;
            }
            if (w == null) {
                host.toast("Pick a weapon first");
                return;
            }
            if (w.kind == GUN) {
                host.toast("BRRRT (SIM)");
                return;
            }
            Integer c = SIM_LOAD.get(w.name);
            if (c == null || c <= 0) {
                host.toast(w.name + ": none left (SIM)");
                return;
            }
            SIM_LOAD.put(w.name, c - 1);
            builtLoad = "";
            shot(w);
            data();
            return;
        }
        if (w != null && w.kind == GUN) {
            hold(a, down);
            return;
        }
        if (down) {
            hold(a, true);
            ui.postDelayed(() -> hold(a, false), 600);
        }
    }

    private void buildList() {
        list.removeAllViews();
        List<DcsLink.Obj> os = visible();
        java.util.Collections.sort(os, (p, q) -> Double.compare(dist(p), dist(q)));
        W w = selected(weapons());
        for (final DcsLink.Obj o : os) {
            double nm = dist(o) / 1852.0;
            String inR = w != null && nm <= rmax(w, o) && nm >= w.minNm ? "  ✔" : "";
            TextView t = text(String.format(Locale.ROOT, "%s  %s   %.1f NM  %s%.0f°  %,d ft%s",
                    o.cat == 1 ? "✈" : o.cat == 3 ? "⚓" : "■", o.name, nm, rel(o) < 0 ? "L" : "R",
                    Math.abs(rel(o)), Math.round(o.alt * 3.281f), inR), 11f, isEnemy(o) ? RED : GREEN);
            t.setGravity(Gravity.START);
            t.setPadding(dp(8), dp(7), dp(8), dp(7));
            if (o.id.equals(target)) {
                t.setBackground(Theme.rounded(0x33FFB020, 8f, host));
            }
            t.setOnClickListener(v -> {
                target = o.id;
                host.buzz(10);
                data();
            });
            list.addView(t, wide());
            if (list.getChildCount() > 40) {
                break;
            }
        }
        if (os.isEmpty()) {
            list.addView(text("No contacts", 11f, Theme.DIM), wide());
        }
    }

    private List<DcsLink.Obj> visible() {
        int f = Prefs.getInt(K_FILTER, 0);
        List<DcsLink.Obj> out = new ArrayList<>();
        for (DcsLink.Obj o : DcsLink.objs) {
            if (f == 1 && o.cat != 1 || f == 2 && o.cat == 1) {
                continue;
            }
            out.add(o);
        }
        return out;
    }

    private void openBig() {
        LinearLayout v = new LinearLayout(host);
        v.setOrientation(VERTICAL);
        v.setBackgroundColor(0xFF020604);
        v.setPadding(dp(8), dp(40), dp(8), dp(10));
        v.setClickable(true);
        LinearLayout head = row();
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text("DCS WEAPONS", 16f, HUD);
        t.setLetterSpacing(0.3f);
        t.setGravity(Gravity.START);
        head.addView(t, weight(1f));
        head.addView(chip("✕ CLOSE", host::hideOverlay));
        v.addView(head, wide());
        DcsWeaponsWidget w = new DcsWeaponsWidget(host, true);
        w.sel = sel;
        w.target = target;
        v.addView(w, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f));
        host.showOverlay(v);
    }

    // ------------------------------------------------------------------ radar scope

    private final class Scope extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final DashPathEffect dash = new DashPathEffect(new float[] {12, 10}, 0);
        private float cx;
        private float cy;
        private float rad;
        private final List<Object[]> hits = new ArrayList<>();

        Scope(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF020A05);
            c.drawRoundRect(0, 0, w, h, dp(10), dp(10), p);
            cx = w / 2f;
            cy = h * 0.62f;
            rad = Math.min(w / 2f - dp(8), cy - dp(10));
            float rangeNm = RANGES[Prefs.getInt(K_RANGE, 2)];
            float pxNm = rad / rangeNm;
            // rings
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setTextSize(dp(9));
            for (int i = 1; i <= 4; i++) {
                p.setColor(i == 4 ? 0x7730FF70 : 0x3330FF70);
                c.drawCircle(cx, cy, rad * i / 4f, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x8830FF70);
            p.setTextAlign(Paint.Align.LEFT);
            for (int i = 1; i <= 4; i++) {
                float nm = rangeNm * i / 4f;
                c.drawText(nm < 10 ? String.format(Locale.ROOT, "%.1f", nm) : String.valueOf(Math.round(nm)), cx + dp(3),
                        cy - rad * i / 4f + dp(10), p);
            }
            // nose line and 60 deg lines
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x3330FF70);
            for (int a = -60; a <= 60; a += 60) {
                double r = Math.toRadians(a);
                c.drawLine(cx, cy, cx + (float) Math.sin(r) * rad, cy - (float) Math.cos(r) * rad, p);
            }
            // own jet
            p.setStyle(Paint.Style.FILL);
            p.setColor(HUD);
            path.reset();
            path.moveTo(cx, cy - dp(9));
            path.lineTo(cx - dp(6), cy + dp(6));
            path.lineTo(cx, cy + dp(3));
            path.lineTo(cx + dp(6), cy + dp(6));
            path.close();
            c.drawPath(path, p);

            List<W> ws = weapons();
            W wsel = selected(ws);
            DcsLink.Obj tgt = find(target);
            // weapon range ring
            if (wsel != null) {
                float rm = rmax(wsel, tgt) * pxNm;
                p.setStyle(Paint.Style.STROKE);
                p.setPathEffect(dash);
                p.setStrokeWidth(dp(1.5f));
                p.setColor(0xAAFFB020);
                if (rm < rad * 1.6f) {
                    c.drawCircle(cx, cy, rm, p);
                }
                p.setPathEffect(null);
            }
            // contacts
            hits.clear();
            String lockId = DcsLink.st.lockId;
            for (DcsLink.Obj o : visible()) {
                double nm = dist(o) / 1852.0;
                if (nm > rangeNm * 1.15) {
                    continue;
                }
                double r = Math.toRadians(rel(o));
                float x = cx + (float) (Math.sin(r) * nm * pxNm);
                float y = cy - (float) (Math.cos(r) * nm * pxNm);
                if (y < dp(4) || y > h - dp(4)) {
                    continue;
                }
                int col = o.coal == 0 ? AMBER : isEnemy(o) ? RED : GREEN;
                p.setColor(col);
                p.setStyle(Paint.Style.FILL);
                float s = dp(5);
                if (o.cat == 1) {
                    path.reset();
                    path.moveTo(x, y - s);
                    path.lineTo(x - s, y + s * 0.8f);
                    path.lineTo(x + s, y + s * 0.8f);
                    path.close();
                    c.drawPath(path, p);
                    // where it's heading
                    double hr = Math.toRadians(o.hdg - DcsLink.st.hdg);
                    p.setStrokeWidth(dp(1.2f));
                    c.drawLine(x, y, x + (float) Math.sin(hr) * dp(14), y - (float) Math.cos(hr) * dp(14), p);
                } else if (o.cat == 3) {
                    path.reset();
                    path.moveTo(x, y - s);
                    path.lineTo(x + s, y);
                    path.lineTo(x, y + s);
                    path.lineTo(x - s, y);
                    path.close();
                    c.drawPath(path, p);
                } else {
                    c.drawRect(x - s * 0.8f, y - s * 0.8f, x + s * 0.8f, y + s * 0.8f, p);
                }
                if (big || o.id.equals(target)) {
                    p.setTextSize(dp(8.5f));
                    p.setTextAlign(Paint.Align.LEFT);
                    c.drawText(o.name, x + dp(8), y - dp(5), p);
                    c.drawText(String.format(Locale.ROOT, "%d", Math.round(o.alt * 3.281f / 1000f)), x + dp(8), y + dp(6), p);
                }
                if (o.id.equals(lockId) && !lockId.isEmpty()) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(2));
                    p.setColor(0xFFFFFFFF);
                    path.reset();
                    float L = dp(11);
                    path.moveTo(x, y - L);
                    path.lineTo(x + L, y);
                    path.lineTo(x, y + L);
                    path.lineTo(x - L, y);
                    path.close();
                    c.drawPath(path, p);
                }
                if (o.id.equals(target)) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(2));
                    p.setColor(AMBER);
                    float b = dp(13);
                    float k = dp(5);
                    c.drawLine(x - b, y - b, x - b + k, y - b, p);
                    c.drawLine(x - b, y - b, x - b, y - b + k, p);
                    c.drawLine(x + b, y - b, x + b - k, y - b, p);
                    c.drawLine(x + b, y - b, x + b, y - b + k, p);
                    c.drawLine(x - b, y + b, x - b + k, y + b, p);
                    c.drawLine(x - b, y + b, x - b, y + b - k, p);
                    c.drawLine(x + b, y + b, x + b - k, y + b, p);
                    c.drawLine(x + b, y + b, x + b, y + b - k, p);
                    // steer cue line from the jet
                    p.setStrokeWidth(dp(1));
                    p.setPathEffect(dash);
                    c.drawLine(cx, cy, x, y, p);
                    p.setPathEffect(null);
                }
                hits.add(new Object[] {x, y, o.id});
            }
            // heading readout
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(11));
            p.setColor(HUD);
            c.drawText(String.format(Locale.ROOT, "%03.0f°", (DcsLink.st.hdg + 360) % 360), cx, dp(14), p);
            if (DcsLink.objs.isEmpty()) {
                p.setColor(Theme.DIM);
                p.setTextSize(dp(10));
                c.drawText(DcsLink.objectsLive() ? "no contacts nearby" : "no contacts (multiplayer servers can block them)",
                        cx, h - dp(8), p);
            }
            if (wsel != null) {
                p.setTextAlign(Paint.Align.LEFT);
                p.setTextSize(dp(10));
                p.setColor(AMBER);
                c.drawText(wsel.name + (wsel.count >= 0 ? "  " + wsel.count : ""), dp(8), h - dp(8), p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                return true;
            }
            if (e.getActionMasked() != MotionEvent.ACTION_UP) {
                return true;
            }
            float best = dp(30);
            String id = null;
            for (Object[] hh : hits) {
                float d = (float) Math.hypot((float) hh[0] - e.getX(), (float) hh[1] - e.getY());
                if (d < best) {
                    best = d;
                    id = (String) hh[2];
                }
            }
            if (id != null) {
                target = id;
                host.buzz(12);
                DcsLink.Obj o = find(id);
                if (o != null && !isEnemy(o)) {
                    host.toast("Careful: " + o.name + " is FRIENDLY");
                }
                data();
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ fire button with a safety cover

    private final class FireButton extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private long openUntil;
        private boolean pressed;
        private final Runnable shut = this::invalidate;

        FireButton(Context c) {
            super(c);
        }

        private boolean open() {
            return SystemClock.elapsedRealtime() < openUntil;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            r.set(dp(4), dp(4), w - dp(4), h - dp(4));
            boolean o = open();
            p.setStyle(Paint.Style.FILL);
            p.setColor(pressed ? 0xFFFF7060 : o ? RED : 0xFF5A1410);
            c.drawRoundRect(r, dp(14), dp(14), p);
            if (!o) {
                // striped cover
                c.save();
                c.clipRect(r);
                p.setColor(0xCCFFC400);
                for (float x = -h; x < w + h; x += dp(26)) {
                    Path s = new Path();
                    s.moveTo(x, r.bottom);
                    s.lineTo(x + dp(13), r.bottom);
                    s.lineTo(x + dp(13) + h, r.top);
                    s.lineTo(x + h, r.top);
                    s.close();
                    c.drawPath(s, p);
                }
                c.restore();
            }
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(o ? 20 : 13));
            p.setFakeBoldText(true);
            p.setColor(0xFFFFFFFF);
            String t = o ? "FIRE" : "▲ LIFT COVER";
            float tw = p.measureText(t) + dp(16);
            if (!o) {
                p.setColor(0xDD000000);
                c.drawRoundRect(w / 2 - tw / 2, h / 2 - dp(12), w / 2 + tw / 2, h / 2 + dp(10), dp(6), dp(6), p);
                p.setColor(0xFFFFFFFF);
            }
            c.drawText(t, w / 2, h / 2 + p.getTextSize() / 3, p);
            p.setFakeBoldText(false);
            if (o) {
                p.setTextSize(dp(9));
                List<W> ws = weapons();
                W s = selected(ws);
                c.drawText(s == null ? "pick a weapon" : s.name, w / 2, h - dp(10), p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                if (!open()) {
                    openUntil = SystemClock.elapsedRealtime() + 6000;
                    host.buzz(25);
                    removeCallbacks(shut);
                    postDelayed(shut, 6100);
                    invalidate();
                    return true;
                }
                pressed = true;
                host.buzz(60);
                doFire(true);
                openUntil = SystemClock.elapsedRealtime() + 6000;
                removeCallbacks(shut);
                postDelayed(shut, 6100);
                invalidate();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                if (pressed) {
                    pressed = false;
                    doFire(false);
                    invalidate();
                }
                return true;
            }
            return true;
        }
    }
}
