package app.novaos;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Everyday data shared by the "serious" home screens: the morning checklist and leave time, wake time, school
 * timetable, homework, tests, planner events, journal, workouts, savings goal and focus sessions. All saved on the
 * phone only.
 */
final class Life {
    private Life() {
    }

    static String day(Calendar c) {
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(c.getTime());
    }

    static String today() {
        return day(Calendar.getInstance());
    }

    static String dayPlus(int n) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, n);
        return day(c);
    }

    static Calendar parse(String day) {
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(new SimpleDateFormat("yyyyMMdd", Locale.ROOT).parse(day));
        } catch (Exception ignored) {
            // keep today
        }
        return c;
    }

    /** Whole days from today to that day (negative = past). */
    static int daysUntil(String day) {
        Calendar a = parse(today());
        Calendar b = parse(day);
        return (int) Math.round((b.getTimeInMillis() - a.getTimeInMillis()) / 86400000.0);
    }

    static String nice(String day) {
        int n = daysUntil(day);
        if (n == 0) {
            return "today";
        }
        if (n == 1) {
            return "tomorrow";
        }
        if (n == -1) {
            return "yesterday";
        }
        if (n < 0) {
            return (-n) + " days ago";
        }
        if (n < 7) {
            return new SimpleDateFormat("EEEE", Locale.getDefault()).format(parse(day).getTime());
        }
        return new SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(parse(day).getTime());
    }

    static int nowMin() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    static String hm(int min) {
        min = ((min % 1440) + 1440) % 1440;
        return String.format(Locale.ROOT, "%02d:%02d", min / 60, min % 60);
    }

    static String dur(int min) {
        if (min < 60) {
            return min + " min";
        }
        return (min / 60) + "h " + String.format(Locale.ROOT, "%02d", min % 60) + "m";
    }

    // ------------------------------------------------------------------ simple line lists

    static List<String> lines(String key) {
        List<String> out = new ArrayList<>();
        for (String s : Prefs.getString(key, "").split("\n")) {
            if (!s.trim().isEmpty()) {
                out.add(s);
            }
        }
        return out;
    }

    static void saveLines(String key, List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) {
            b.append(s.replace("\n", " ")).append('\n');
        }
        Prefs.putString(key, b.toString());
    }

    // ------------------------------------------------------------------ morning

    static List<String> morningItems() {
        List<String> l = lines("morning_items");
        if (l.isEmpty() && !Prefs.getBool("morning_set", false)) {
            l.add("Get up, no snooze");
            l.add("Brush teeth");
            l.add("Breakfast");
            l.add("Pack your bag");
            l.add("Keys, wallet, ticket");
        }
        return l;
    }

    static void saveMorningItems(List<String> l) {
        Prefs.putBool("morning_set", true);
        saveLines("morning_items", l);
    }

    static boolean morningDone(int i) {
        String s = Prefs.getString("morning_done", "");
        return s.startsWith(today() + "|") && ("," + s.substring(9) + ",").contains("," + i + ",");
    }

    static void toggleMorning(int i) {
        String s = Prefs.getString("morning_done", "");
        List<String> on = new ArrayList<>();
        if (s.startsWith(today() + "|")) {
            for (String k : s.substring(9).split(",")) {
                if (!k.isEmpty()) {
                    on.add(k);
                }
            }
        }
        if (!on.remove(String.valueOf(i))) {
            on.add(String.valueOf(i));
        }
        Prefs.putString("morning_done", today() + "|" + String.join(",", on));
    }

    static int morningCount() {
        int n = 0;
        for (int i = 0; i < morningItems().size(); i++) {
            if (morningDone(i)) {
                n++;
            }
        }
        return n;
    }

    static int leaveMin() {
        return Prefs.getInt("leave_min", 7 * 60 + 20);
    }

    static int wakeMin() {
        return Prefs.getInt("wake_min", 6 * 60 + 45);
    }

    static boolean weekend(Calendar c) {
        int d = c.get(Calendar.DAY_OF_WEEK);
        return d == Calendar.SATURDAY || d == Calendar.SUNDAY;
    }

    // ------------------------------------------------------------------ timetable: per weekday "08:00 Maths R12"

    static List<Object[]> lessons(int dow) {
        List<Object[]> out = new ArrayList<>();
        for (String s : lines("tt_" + dow)) {
            s = s.trim();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d{1,2})[:.](\\d{2})\\s*(.*)$").matcher(s);
            if (m.find()) {
                out.add(new Object[] {Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2)),
                    m.group(3).isEmpty() ? "Lesson" : m.group(3)});
            }
        }
        out.sort((a, b) -> (int) a[0] - (int) b[0]);
        return out;
    }

    // ------------------------------------------------------------------ homework "due|done|text", tests "day|text"

    static List<String[]> homework() {
        List<String[]> out = new ArrayList<>();
        for (String s : lines("hw")) {
            String[] f = s.split("\\|", 3);
            if (f.length == 3) {
                out.add(f);
            }
        }
        out.sort((a, b) -> a[0].compareTo(b[0]));
        return out;
    }

    static void saveHomework(List<String[]> l) {
        List<String> s = new ArrayList<>();
        for (String[] f : l) {
            s.add(f[0] + "|" + f[1] + "|" + f[2]);
        }
        saveLines("hw", s);
    }

    static List<String[]> tests() {
        List<String[]> out = new ArrayList<>();
        for (String s : lines("tests")) {
            String[] f = s.split("\\|", 2);
            if (f.length == 2 && daysUntil(f[0]) >= 0) {
                out.add(f);
            }
        }
        out.sort((a, b) -> a[0].compareTo(b[0]));
        return out;
    }

    static void saveTests(List<String[]> l) {
        List<String> s = new ArrayList<>();
        for (String[] f : l) {
            s.add(f[0] + "|" + f[1]);
        }
        saveLines("tests", s);
    }

    // ------------------------------------------------------------------ planner events "day|min|text" (min -1 = all day)

    static List<String[]> events(String day) {
        List<String[]> out = new ArrayList<>();
        for (String s : lines("events")) {
            String[] f = s.split("\\|", 3);
            if (f.length == 3 && f[0].equals(day)) {
                out.add(f);
            }
        }
        out.sort((a, b) -> Integer.parseInt(a[1]) - Integer.parseInt(b[1]));
        return out;
    }

    static void addEvent(String day, int min, String text) {
        List<String> l = lines("events");
        l.add(day + "|" + min + "|" + text);
        // keep only the last 400
        while (l.size() > 400) {
            l.remove(0);
        }
        saveLines("events", l);
    }

    static void removeEvent(String[] e) {
        List<String> l = lines("events");
        l.remove(e[0] + "|" + e[1] + "|" + e[2]);
        saveLines("events", l);
    }

    // ------------------------------------------------------------------ journal

    static String journal(String day) {
        return Prefs.getString("journal_" + day, "");
    }

    static void setJournal(String day, String text) {
        Prefs.putString("journal_" + day, text);
        List<String> days = lines("journal_days");
        if (!text.trim().isEmpty() && !days.contains(day)) {
            days.add(day);
            saveLines("journal_days", days);
        }
    }

    static int journalStreak() {
        List<String> days = lines("journal_days");
        int n = 0;
        Calendar c = Calendar.getInstance();
        if (!days.contains(day(c)) || journal(day(c)).trim().isEmpty()) {
            c.add(Calendar.DAY_OF_MONTH, -1);
        }
        while (days.contains(day(c)) && !journal(day(c)).trim().isEmpty()) {
            n++;
            c.add(Calendar.DAY_OF_MONTH, -1);
        }
        return n;
    }

    // ------------------------------------------------------------------ workouts "day|type|amount"

    static final String[] WORKOUTS = {"Push-ups", "Sit-ups", "Squats", "Plank (s)", "Run (km)"};
    static final int[] STEPS = {10, 10, 10, 30, 1};

    static int workout(String day, int type) {
        int sum = 0;
        for (String s : lines("workout_log")) {
            String[] f = s.split("\\|");
            if (f.length == 3 && f[0].equals(day) && f[1].equals(String.valueOf(type))) {
                try {
                    sum += Integer.parseInt(f[2]);
                } catch (NumberFormatException ignored) {
                    // broken
                }
            }
        }
        return sum;
    }

    static void addWorkout(int type, int amount) {
        List<String> l = lines("workout_log");
        l.add(today() + "|" + type + "|" + amount);
        while (l.size() > 1500) {
            l.remove(0);
        }
        saveLines("workout_log", l);
    }

    // ------------------------------------------------------------------ focus sessions

    static int focusDone(String day) {
        String s = Prefs.getString("focus_done", "");
        if (s.startsWith(day + "|")) {
            try {
                return Integer.parseInt(s.substring(9));
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
        return 0;
    }

    static void addFocus() {
        Prefs.putString("focus_done", today() + "|" + (focusDone(today()) + 1));
    }

    static String format(Date d, String pattern) {
        return new SimpleDateFormat(pattern, Locale.getDefault()).format(d);
    }
}
