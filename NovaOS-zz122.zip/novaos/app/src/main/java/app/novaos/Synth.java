package app.novaos;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * A tiny synthesizer for the PIANO, SOUNDBOARD and ARCADE home screens: notes with three sounds (piano, organ,
 * 8-bit) and a set of drum and effect sounds, all made from maths, so no sound files are needed.
 */
final class Synth {
    static final int RATE = 22050;
    static final String[] VOICES = {"PIANO", "ORGAN", "8-BIT"};
    static final String[] PADS = {"KICK", "SNARE", "HI-HAT", "CLAP", "AIR HORN", "LASER", "COIN", "BOING", "SIREN",
        "BEEP", "BASS", "CHORD"};
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final Map<String, short[]> CACHE = new HashMap<>();

    private Synth() {
    }

    static double freq(int midi) {
        return 440.0 * Math.pow(2, (midi - 69) / 12.0);
    }

    /** One note: midi number, voice 0 piano, 1 organ, 2 8-bit. */
    static void note(int midi, int voice) {
        String k = "n" + midi + "/" + voice;
        short[] pcm = CACHE.get(k);
        if (pcm == null) {
            pcm = makeNote(freq(midi), voice, voice == 1 ? 700 : 900);
            CACHE.put(k, pcm);
        }
        play(pcm);
    }

    static void pad(int i) {
        String k = "p" + i;
        short[] pcm = CACHE.get(k);
        if (pcm == null) {
            pcm = makePad(i);
            CACHE.put(k, pcm);
        }
        play(pcm);
    }

    /** A short clean tone, for game sounds. */
    static void tone(double hz, int ms) {
        String k = "t" + Math.round(hz) + "/" + ms;
        short[] pcm = CACHE.get(k);
        if (pcm == null) {
            pcm = makeNote(hz, 1, ms);
            CACHE.put(k, pcm);
        }
        play(pcm);
    }

    private static short[] makeNote(double f, int voice, int ms) {
        int n = RATE * ms / 1000;
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v;
            double env;
            if (voice == 0) {
                v = Math.sin(2 * Math.PI * f * t) + 0.45 * Math.sin(4 * Math.PI * f * t) + 0.18 * Math.sin(6 * Math.PI * f * t);
                env = Math.min(1, t * 400) * Math.exp(-t * 3.2);
            } else if (voice == 1) {
                v = Math.sin(2 * Math.PI * f * t) + 0.5 * Math.sin(2 * Math.PI * f * 2 * t) + 0.3 * Math.sin(2 * Math.PI * f * 3 * t);
                env = Math.min(1, t * 80) * Math.min(1, (n - i) / (RATE * 0.08));
            } else {
                v = ((t * f) % 1.0) < 0.5 ? 0.8 : -0.8;
                env = Math.min(1, t * 500) * Math.exp(-t * 2.5);
            }
            out[i] = (short) (Math.max(-1, Math.min(1, v * env * 0.33)) * 32000);
        }
        return out;
    }

    private static short[] makePad(int id) {
        Random r = new Random(id);
        int ms = new int[] {350, 250, 120, 220, 900, 450, 380, 500, 1200, 200, 500, 900}[id];
        int n = RATE * ms / 1000;
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            double t = i / (double) RATE;
            double v;
            switch (id) {
                case 0: { // kick: a falling sine
                    double f = 150 * Math.exp(-t * 18) + 45;
                    v = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 9);
                    break;
                }
                case 1: // snare: noise plus a tone
                    v = ((r.nextDouble() * 2 - 1) * 0.7 + 0.3 * Math.sin(2 * Math.PI * 190 * t)) * Math.exp(-t * 16);
                    break;
                case 2: // hi-hat: thin noise
                    v = (r.nextDouble() * 2 - 1) * Math.exp(-t * 45) * 0.6;
                    break;
                case 3: { // clap: three quick bursts
                    double e = Math.exp(-((t % 0.03) * 120)) * (t < 0.09 ? 1 : Math.exp(-(t - 0.09) * 20));
                    v = (r.nextDouble() * 2 - 1) * e;
                    break;
                }
                case 4: { // air horn
                    double f = 440 + 5 * Math.sin(2 * Math.PI * 6 * t);
                    v = (((t * f) % 1.0) < 0.5 ? 0.6 : -0.6) + 0.3 * Math.signum(Math.sin(2 * Math.PI * f * 1.5 * t));
                    v *= Math.min(1, t * 30) * Math.min(1, (n - i) / (RATE * 0.05));
                    break;
                }
                case 5: { // laser: fast falling tone
                    double f = 2200 * Math.exp(-t * 6) + 200;
                    v = Math.signum(Math.sin(2 * Math.PI * f * t)) * 0.5 * Math.exp(-t * 4);
                    break;
                }
                case 6: { // coin: two notes
                    double f = t < 0.08 ? 988 : 1319;
                    v = Math.signum(Math.sin(2 * Math.PI * f * t)) * 0.45 * Math.exp(-Math.max(0, t - 0.08) * 6);
                    break;
                }
                case 7: { // boing: wobbly tone
                    double f = 220 + 140 * Math.sin(2 * Math.PI * 9 * t) * Math.exp(-t * 4);
                    v = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 3);
                    break;
                }
                case 8: { // siren up and down
                    double f = 700 + 300 * Math.sin(2 * Math.PI * 1.6 * t);
                    v = Math.sin(2 * Math.PI * f * t) * 0.7 * Math.min(1, (n - i) / (RATE * 0.1));
                    break;
                }
                case 9: // beep
                    v = Math.sin(2 * Math.PI * 1000 * t) * 0.6 * Math.min(1, (n - i) / (RATE * 0.02));
                    break;
                case 10: { // bass
                    double f = 55;
                    v = (Math.sin(2 * Math.PI * f * t) + 0.5 * Math.sin(2 * Math.PI * 2 * f * t)) * Math.exp(-t * 4) * 0.8;
                    break;
                }
                default: { // a major chord
                    v = (Math.sin(2 * Math.PI * 261.6 * t) + Math.sin(2 * Math.PI * 329.6 * t) + Math.sin(2 * Math.PI * 392 * t))
                            * 0.3 * Math.exp(-t * 2.2);
                    break;
                }
            }
            out[i] = (short) (Math.max(-1, Math.min(1, v * 0.8)) * 30000);
        }
        return out;
    }

    static void play(final short[] pcm) {
        try {
            final AudioTrack t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.length * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build();
            t.write(pcm, 0, pcm.length);
            t.play();
            H.postDelayed(() -> {
                try {
                    t.release();
                } catch (Throwable ignored) {
                    // already gone
                }
            }, pcm.length * 1000L / RATE + 300);
        } catch (Throwable ignored) {
            // no sound is better than a crash
        }
    }
}
