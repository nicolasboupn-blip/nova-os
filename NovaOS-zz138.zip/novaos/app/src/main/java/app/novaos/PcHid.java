package app.novaos;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * The phone as a Bluetooth keyboard, mouse and media remote for a PC (Android 9+). Windows sees "NOVA Remote" as a
 * normal keyboard and mouse, so nothing has to be installed on the PC. Keys are sent by position, so text is typed
 * through a map for the PC's keyboard layout (Swiss German, German or US).
 */
final class PcHid {
    static final String K_ADDR = "pc_addr";
    static final String K_LAYOUT = "pc_layout";
    static final String[] LAYOUTS = {"Swiss (CH)", "German (DE)", "US"};

    static final int CTRL = 0x01;
    static final int SHIFT = 0x02;
    static final int ALT = 0x04;
    static final int WIN = 0x08;
    static final int ALTGR = 0x40;

    private static final byte[] DESCRIPTOR = {
        // keyboard, report 1: modifiers, reserved, 6 keys
        0x05, 0x01, 0x09, 0x06, (byte) 0xA1, 0x01, (byte) 0x85, 0x01,
        0x05, 0x07, 0x19, (byte) 0xE0, 0x29, (byte) 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, (byte) 0x95, 0x08,
        (byte) 0x81, 0x02,
        (byte) 0x95, 0x01, 0x75, 0x08, (byte) 0x81, 0x01,
        (byte) 0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x26, (byte) 0xFF, 0x00, 0x05, 0x07, 0x19, 0x00, 0x2A, (byte) 0xFF,
        0x00, (byte) 0x81, 0x00,
        (byte) 0xC0,
        // mouse, report 2: buttons, x, y, wheel
        0x05, 0x01, 0x09, 0x02, (byte) 0xA1, 0x01, (byte) 0x85, 0x02, 0x09, 0x01, (byte) 0xA1, 0x00,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, (byte) 0x95, 0x03, 0x75, 0x01, (byte) 0x81, 0x02,
        (byte) 0x95, 0x01, 0x75, 0x05, (byte) 0x81, 0x01,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, (byte) 0x81, 0x25, 0x7F, 0x75, 0x08, (byte) 0x95, 0x03,
        (byte) 0x81, 0x06,
        (byte) 0xC0, (byte) 0xC0,
        // media keys, report 3: one 16-bit consumer usage
        0x05, 0x0C, 0x09, 0x01, (byte) 0xA1, 0x01, (byte) 0x85, 0x03, 0x15, 0x00, 0x26, (byte) 0xFF, 0x03, 0x19, 0x00,
        0x2A, (byte) 0xFF, 0x03, 0x75, 0x10, (byte) 0x95, 0x01, (byte) 0x81, 0x00,
        (byte) 0xC0,
    };

    static volatile BluetoothHidDevice hid;
    static volatile BluetoothDevice host;
    static volatile boolean registered;
    static volatile String state = "Not started";
    static volatile Runnable listener;
    private static Context app;
    private static Handler sender;
    private static final Handler main = new Handler(Looper.getMainLooper());

    private PcHid() {
    }

    static boolean connected() {
        return host != null && hid != null;
    }

    private static void set(String s) {
        state = s;
        Runnable l = listener;
        if (l != null) {
            main.post(l);
        }
    }

    static BluetoothAdapter adapter(Context c) {
        BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
        return bm == null ? null : bm.getAdapter();
    }

    /** Registers NOVA as a keyboard + mouse. Needs Bluetooth on and the Bluetooth permission. */
    static void start(Context c) {
        app = c.getApplicationContext();
        if (Build.VERSION.SDK_INT < 28) {
            set("Needs Android 9 or newer");
            return;
        }
        if (sender == null) {
            HandlerThread t = new HandlerThread("nova-pc");
            t.start();
            sender = new Handler(t.getLooper());
        }
        BluetoothAdapter a = adapter(app);
        if (a == null) {
            set("No Bluetooth on this phone");
            return;
        }
        if (!a.isEnabled()) {
            set("Turn Bluetooth on");
            return;
        }
        if (hid != null) {
            if (registered) {
                reconnect();
            }
            return;
        }
        set("Starting…");
        try {
            boolean ok = a.getProfileProxy(app, new BluetoothProfile.ServiceListener() {
                @Override
                public void onServiceConnected(int profile, BluetoothProfile proxy) {
                    hid = (BluetoothHidDevice) proxy;
                    register();
                }

                @Override
                public void onServiceDisconnected(int profile) {
                    hid = null;
                    registered = false;
                    host = null;
                    set("Bluetooth stopped");
                }
            }, BluetoothProfile.HID_DEVICE);
            if (!ok) {
                set("This phone does not allow Bluetooth keyboards");
            }
        } catch (SecurityException e) {
            set("Allow Bluetooth (Nearby devices) for NOVA");
        }
    }

    private static void register() {
        try {
            BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings("NOVA Remote",
                    "NOVA keyboard and mouse", "NOVA", BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR);
            hid.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), new BluetoothHidDevice.Callback() {
                @Override
                public void onAppStatusChanged(BluetoothDevice plugged, boolean ok) {
                    registered = ok;
                    if (ok) {
                        set("Ready: connect from the PC or tap CONNECT");
                        if (plugged != null) {
                            host = plugged;
                        }
                        reconnect();
                    } else {
                        host = null;
                        set("Stopped");
                    }
                }

                @Override
                public void onConnectionStateChanged(BluetoothDevice d, int st) {
                    if (st == BluetoothProfile.STATE_CONNECTED) {
                        host = d;
                        Prefs.putString(K_ADDR, d.getAddress());
                        set("Connected to " + name(d));
                    } else if (st == BluetoothProfile.STATE_CONNECTING) {
                        set("Connecting to " + name(d) + "…");
                    } else if (st == BluetoothProfile.STATE_DISCONNECTED) {
                        if (host != null && host.equals(d)) {
                            host = null;
                        }
                        set("Disconnected");
                    }
                }

                @Override
                public void onGetReport(BluetoothDevice d, byte type, byte id, int size) {
                    try {
                        hid.replyReport(d, type, id, new byte[id == 1 ? 8 : id == 2 ? 4 : 2]);
                    } catch (RuntimeException ignored) {
                        // fine
                    }
                }
            });
        } catch (SecurityException e) {
            set("Allow Bluetooth (Nearby devices) for NOVA");
        }
    }

    static String name(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? d.getAddress() : n;
        } catch (SecurityException e) {
            return "PC";
        }
    }

    /** Connects to the PC used last time. */
    static void reconnect() {
        String addr = Prefs.getString(K_ADDR, "");
        if (hid == null || !registered || addr.isEmpty() || connected()) {
            return;
        }
        connectTo(addr);
    }

    static void connectTo(String addr) {
        try {
            BluetoothAdapter a = adapter(app);
            if (a == null || hid == null) {
                return;
            }
            BluetoothDevice d = a.getRemoteDevice(addr);
            Prefs.putString(K_ADDR, addr);
            set("Connecting to " + name(d) + "…");
            hid.connect(d);
        } catch (RuntimeException e) {
            set("Could not connect: " + e.getMessage());
        }
    }

    static void disconnect() {
        try {
            if (hid != null && host != null) {
                hid.disconnect(host);
            }
        } catch (RuntimeException ignored) {
            // gone
        }
    }

    // ================================================================== sending

    private static void report(int id, byte[] data) {
        BluetoothHidDevice h = hid;
        BluetoothDevice d = host;
        if (h == null || d == null) {
            return;
        }
        try {
            h.sendReport(d, id, data);
        } catch (RuntimeException ignored) {
            // dropped
        }
    }

    private static void keyNow(int mods, int key) {
        report(1, new byte[] {(byte) mods, 0, (byte) key, 0, 0, 0, 0, 0});
        sleep(18);
        report(1, new byte[8]);
        sleep(18);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // fine
        }
    }

    /** Mouse move / buttons / wheel, straight away. buttons: 1 left, 2 right, 4 middle. */
    static void mouse(int buttons, int dx, int dy, int wheel) {
        report(2, new byte[] {(byte) buttons, (byte) clamp(dx), (byte) clamp(dy), (byte) clamp(wheel)});
    }

    private static int clamp(int v) {
        return Math.max(-127, Math.min(127, v));
    }

    static void click(final int button) {
        post(() -> {
            mouse(button, 0, 0, 0);
            sleep(25);
            mouse(0, 0, 0, 0);
        });
    }

    static void post(Runnable r) {
        if (sender != null) {
            sender.post(r);
        }
    }

    /**
     * Runs a little script. Steps are split by "|":
     * K:WIN+R (keys), T:text (type it), W:300 (wait ms), C:E9 (media key, hex), M:L / M:R (click).
     */
    static void run(final String script) {
        post(() -> {
            for (String step : script.split("\\|")) {
                if (step.length() < 2) {
                    continue;
                }
                String arg = step.substring(2);
                switch (step.charAt(0)) {
                    case 'K':
                        combo(arg);
                        break;
                    case 'T':
                        typeNow(arg);
                        break;
                    case 'W':
                        try {
                            sleep(Long.parseLong(arg));
                        } catch (NumberFormatException ignored) {
                            // bad wait
                        }
                        break;
                    case 'C':
                        try {
                            int u = Integer.parseInt(arg, 16);
                            report(3, new byte[] {(byte) (u & 0xFF), (byte) ((u >> 8) & 0xFF)});
                            sleep(30);
                            report(3, new byte[2]);
                            sleep(20);
                        } catch (NumberFormatException ignored) {
                            // bad code
                        }
                        break;
                    case 'M':
                        mouse(arg.equals("R") ? 2 : arg.equals("M") ? 4 : 1, 0, 0, 0);
                        sleep(25);
                        mouse(0, 0, 0, 0);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    static void type(final String text) {
        post(() -> typeNow(text));
    }

    private static final Map<String, Integer> KEYS = new HashMap<>();

    static {
        String[][] k = {
            {"ENTER", "28"}, {"ESC", "29"}, {"BKSP", "2A"}, {"TAB", "2B"}, {"SPACE", "2C"}, {"PRTSC", "46"},
            {"INS", "49"}, {"HOME", "4A"}, {"PGUP", "4B"}, {"DEL", "4C"}, {"END", "4D"}, {"PGDN", "4E"},
            {"RIGHT", "4F"}, {"LEFT", "50"}, {"DOWN", "51"}, {"UP", "52"}, {"KPMINUS", "56"}, {"KPPLUS", "57"},
            {"DOT", "37"}, {"COMMA", "36"}, {"APPS", "65"}, {"CAPS", "39"},
        };
        for (String[] e : k) {
            KEYS.put(e[0], Integer.parseInt(e[1], 16));
        }
        for (int i = 1; i <= 12; i++) {
            KEYS.put("F" + i, 0x3A + i - 1);
        }
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            KEYS.put(String.valueOf(ch), 0x04 + ch - 'A');
        }
        for (int i = 1; i <= 9; i++) {
            KEYS.put(String.valueOf(i), 0x1E + i - 1);
        }
        KEYS.put("0", 0x27);
    }

    /** "CTRL+SHIFT+ESC", "WIN+E", "WIN" (just the Windows key). Letters are by position (US names). */
    private static void combo(String s) {
        int mods = 0;
        int key = 0;
        for (String part : s.toUpperCase(Locale.ROOT).split("\\+")) {
            switch (part) {
                case "CTRL":
                    mods |= CTRL;
                    break;
                case "SHIFT":
                    mods |= SHIFT;
                    break;
                case "ALT":
                    mods |= ALT;
                    break;
                case "WIN":
                    mods |= WIN;
                    break;
                default:
                    Integer k = KEYS.get(part);
                    if (k != null) {
                        key = k;
                    }
                    break;
            }
        }
        keyNow(mods, key);
    }

    // ================================================================== text through the PC's keyboard layout

    private static void typeNow(String text) {
        int layout = Prefs.getInt(K_LAYOUT, 0);
        for (int i = 0; i < text.length(); i++) {
            int[] k = map(text.charAt(i), layout);
            if (k != null) {
                keyNow(k[1], k[0]);
            }
        }
    }

    /** {key, modifiers} for a character, or null when it can't be typed. */
    static int[] map(char ch, int layout) {
        boolean euro = layout == 0 || layout == 1;
        if (ch >= 'a' && ch <= 'z') {
            char c = ch;
            if (euro && c == 'y') {
                c = 'z';
            } else if (euro && c == 'z') {
                c = 'y';
            }
            return new int[] {0x04 + c - 'a', 0};
        }
        if (ch >= 'A' && ch <= 'Z') {
            int[] k = map(Character.toLowerCase(ch), layout);
            return new int[] {k[0], SHIFT};
        }
        if (ch >= '1' && ch <= '9') {
            return new int[] {0x1E + ch - '1', 0};
        }
        if (ch == '0') {
            return new int[] {0x27, 0};
        }
        if (ch == ' ') {
            return new int[] {0x2C, 0};
        }
        if (ch == '\n') {
            return new int[] {0x28, 0};
        }
        if (ch == '\t') {
            return new int[] {0x2B, 0};
        }
        String table;
        if (layout == 0) {
            // Swiss German: char, key (hex), modifier (n none, s shift, a AltGr)
            table = "-38n _38s .37n :37s ,36n ;36s /24s +1Es \"1Fs *20s %22s &23s (25s )26s =27s '2Dn ?2Ds @1Fa #20a "
                    + "\\64a <64n >64s !30s $32n [2Fa ]30a {34a }32a |24a ü2Fn ö33n ä34n Ü2Fs Ö33s Ä34s";
        } else if (layout == 1) {
            table = "-38n _38s .37n :37s ,36n ;36s /24s +30n *30s \"1Fs %22s &23s (25s )26s =27s ?2Ds '32s #32n "
                    + "@14a \\2Da !1Es $21s <64n >64s |64a [25a ]26a {24a }27a ü2Fn ö33n ä34n Ü2Fs Ö33s Ä34s";
        } else {
            table = "-2Dn _2Ds =2En +2Es [2Fn {2Fs ]30n }30s \\31n |31s ;33n :33s '34n \"34s `35n ~35s ,36n <36s .37n "
                    + ">37s /38n ?38s !1Es @1Fs #20s $21s %22s ^23s &24s *25s (26s )27s";
        }
        for (String e : table.split(" ")) {
            if (e.length() >= 4 && e.charAt(0) == ch) {
                int key = Integer.parseInt(e.substring(1, 3), 16);
                char m = e.charAt(3);
                return new int[] {key, m == 's' ? SHIFT : m == 'a' ? ALTGR : 0};
            }
        }
        return null;
    }
}
