package app.novaos;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * PC REMOTE: control a Windows PC from NOVA over Bluetooth. NOVA shows up on the PC as a keyboard and mouse
 * ("NOVA Remote"), so nothing needs installing there. Tabs: a trackpad, typing, and 150+ one-tap actions to open
 * apps, settings and folders, manage windows, play music, browse and game.
 */
final class PcRemoteWidget extends NovaWidget {
    private static final String K_TAB = "pc_tab";
    private static final String K_APPS = "pc_my_apps";

    /** Run "ms-settings:x" / "shell:x" / any command through Win+R. */
    private static String runBox(String what) {
        return "K:WIN+R|W:550|T:" + what + "|W:150|K:ENTER";
    }

    /** Open an app by searching for it in the Start menu. */
    private static String app(String name) {
        return "K:WIN|W:700|T:" + name + "|W:1100|K:ENTER";
    }

    private static String power(String key) {
        return "K:WIN+X|W:600|K:U|W:500|K:" + key;
    }

    private static final String[] TABS = {"MOUSE", "TYPE", "APPS", "WINDOWS", "MEDIA", "SETTINGS", "FILES", "BROWSER",
        "GAMING", "KEYS"};

    /** {label, script}; a label starting with "!" asks first. */
    private static final String[][][] ACTIONS = {
        {}, {},
        {
            {"Chrome", app("chrome")}, {"Edge", app("edge")}, {"Spotify", app("spotify")}, {"Discord", app("discord")},
            {"Steam", app("steam")}, {"WhatsApp", app("whatsapp")}, {"Teams", app("teams")},
            {"War Thunder", app("war thunder")}, {"Arma Reforger", app("arma reforger")},
            {"NitroSense", app("nitrosense")}, {"Xbox", app("xbox")}, {"Notepad", app("notepad")},
            {"Calculator", app("calculator")}, {"Paint", app("paint")}, {"Word", app("word")},
            {"Excel", app("excel")}, {"PowerPoint", app("powerpoint")}, {"Photos", app("photos")},
            {"Camera", app("camera")}, {"Snipping", app("snipping tool")}, {"Store", app("microsoft store")},
            {"OBS", app("obs studio")}, {"VS Code", app("visual studio code")},
            {"Task Manager", "K:CTRL+SHIFT+ESC"}, {"CMD", runBox("cmd")}, {"PowerShell", runBox("powershell")},
            {"Control Panel", runBox("control")}, {"Clock", app("clock")}, {"Mail", app("outlook")},
            {"YouTube", runBox("https://youtube.com")},
        },
        {
            {"Start", "K:WIN"}, {"Search", "K:WIN+S"}, {"Run", "K:WIN+R"}, {"Desktop", "K:WIN+D"},
            {"Task view", "K:WIN+TAB"}, {"Switch app", "K:ALT+TAB"}, {"Close app", "K:ALT+F4"},
            {"Minimize", "K:WIN+DOWN"}, {"Maximize", "K:WIN+UP"}, {"Snap left", "K:WIN+LEFT"},
            {"Snap right", "K:WIN+RIGHT"}, {"Next desktop", "K:CTRL+WIN+RIGHT"}, {"Prev desktop", "K:CTRL+WIN+LEFT"},
            {"New desktop", "K:CTRL+WIN+D"}, {"Close desktop", "K:CTRL+WIN+F4"}, {"Screenshot area", "K:WIN+SHIFT+S"},
            {"Screenshot all", "K:WIN+PRTSC"}, {"Notifications", "K:WIN+N"}, {"Quick settings", "K:WIN+A"},
            {"Clipboard", "K:WIN+V"}, {"Emoji", "K:WIN+DOT"}, {"Widgets", "K:WIN+W"}, {"Project", "K:WIN+P"},
            {"Zoom in", "K:WIN+KPPLUS"}, {"Zoom off", "K:WIN+ESC"}, {"Quick menu", "K:WIN+X"},
            {"Lock", "K:WIN+L"}, {"!Sleep", power("S")}, {"!Sign out", power("I")}, {"!Restart", power("R")},
            {"!Shut down", power("U")},
        },
        {
            {"Vol +", "C:E9"}, {"Vol −", "C:EA"}, {"Mute", "C:E2"}, {"Play/Pause", "C:CD"}, {"Next", "C:B5"},
            {"Previous", "C:B6"}, {"Stop", "C:B7"}, {"Vol +5", "C:E9|C:E9|C:E9|C:E9|C:E9"},
            {"Vol −5", "C:EA|C:EA|C:EA|C:EA|C:EA"}, {"Bright +", "C:6F"}, {"Bright −", "C:70"},
            {"Sound out", "K:WIN+CTRL+V"}, {"Spotify", app("spotify")}, {"Sound settings", runBox("ms-settings:sound")},
            {"Mixer", runBox("ms-settings:apps-volume")},
        },
        {
            {"Settings", "K:WIN+I"}, {"Display", runBox("ms-settings:display")}, {"Sound", runBox("ms-settings:sound")},
            {"Bluetooth", runBox("ms-settings:bluetooth")}, {"Wi-Fi", runBox("ms-settings:network-wifi")},
            {"Battery", runBox("ms-settings:batterysaver")}, {"Power", runBox("ms-settings:powersleep")},
            {"Apps", runBox("ms-settings:appsfeatures")}, {"Default apps", runBox("ms-settings:defaultapps")},
            {"Startup apps", runBox("ms-settings:startupapps")}, {"Storage", runBox("ms-settings:storagesense")},
            {"Update", runBox("ms-settings:windowsupdate")}, {"Night light", runBox("ms-settings:nightlight")},
            {"Personalize", runBox("ms-settings:personalization")},
            {"Background", runBox("ms-settings:personalization-background")},
            {"Colors / dark", runBox("ms-settings:colors")}, {"Taskbar", runBox("ms-settings:taskbar")},
            {"Mouse", runBox("ms-settings:mousetouchpad")}, {"Game mode", runBox("ms-settings:gaming-gamemode")},
            {"Notifications", runBox("ms-settings:notifications")}, {"Focus", runBox("ms-settings:quiethours")},
            {"Privacy", runBox("ms-settings:privacy")}, {"Account", runBox("ms-settings:yourinfo")},
            {"Date & time", runBox("ms-settings:dateandtime")}, {"VPN", runBox("ms-settings:network-vpn")},
            {"Graphics", runBox("ms-settings:display-advancedgraphics")}, {"About PC", runBox("ms-settings:about")},
            {"Devices", runBox("ms-settings:devices")}, {"Hotspot", runBox("ms-settings:network-mobilehotspot")},
        },
        {
            {"Explorer", "K:WIN+E"}, {"Downloads", runBox("shell:downloads")}, {"Documents", runBox("shell:personal")},
            {"Desktop", runBox("shell:desktop")}, {"Pictures", runBox("shell:my pictures")},
            {"Music", runBox("shell:my music")}, {"Videos", runBox("shell:my video")},
            {"This PC", runBox("shell:mycomputerfolder")}, {"Recycle bin", runBox("shell:recyclebinfolder")},
            {"Startup", runBox("shell:startup")}, {"AppData", runBox("%appdata%")},
            {"Screenshots", runBox("shell:screenshots")}, {"New folder", "K:CTRL+SHIFT+N"}, {"Rename", "K:F2"},
            {"Delete", "K:DEL"}, {"Copy", "K:CTRL+C"}, {"Cut", "K:CTRL+X"}, {"Paste", "K:CTRL+V"},
            {"Select all", "K:CTRL+A"}, {"Undo", "K:CTRL+Z"}, {"Redo", "K:CTRL+Y"}, {"Refresh", "K:F5"},
            {"Properties", "K:ALT+ENTER"}, {"Back", "K:ALT+LEFT"}, {"Up a folder", "K:ALT+UP"},
            {"Address bar", "K:ALT+D"}, {"Search here", "K:CTRL+E"}, {"New window", "K:CTRL+N"},
        },
        {
            {"New tab", "K:CTRL+T"}, {"Close tab", "K:CTRL+W"}, {"Reopen tab", "K:CTRL+SHIFT+T"},
            {"Next tab", "K:CTRL+TAB"}, {"Prev tab", "K:CTRL+SHIFT+TAB"}, {"Reload", "K:F5"}, {"Back", "K:ALT+LEFT"},
            {"Forward", "K:ALT+RIGHT"}, {"Address", "K:CTRL+L"}, {"Incognito", "K:CTRL+SHIFT+N"},
            {"Find", "K:CTRL+F"}, {"Zoom +", "K:CTRL+KPPLUS"}, {"Zoom −", "K:CTRL+KPMINUS"},
            {"Zoom 100%", "K:CTRL+0"}, {"Fullscreen", "K:F11"}, {"Downloads", "K:CTRL+J"}, {"History", "K:CTRL+H"},
            {"Bookmark", "K:CTRL+D"}, {"YouTube", "K:CTRL+L|W:200|T:youtube.com|K:ENTER"},
            {"Google", "K:CTRL+L|W:200|T:google.com|K:ENTER"}, {"Scroll down", "K:SPACE"},
            {"Scroll up", "K:SHIFT+SPACE"}, {"Top", "K:HOME"}, {"Bottom", "K:END"},
        },
        {
            {"Game bar", "K:WIN+G"}, {"Clip last 30s", "K:WIN+ALT+G"}, {"Record on/off", "K:WIN+ALT+R"},
            {"Game shot", "K:WIN+ALT+PRTSC"}, {"NVIDIA overlay", "K:ALT+Z"}, {"Discord mute", "K:CTRL+SHIFT+M"},
            {"Discord deafen", "K:CTRL+SHIFT+D"}, {"NitroSense", app("nitrosense")}, {"Steam", app("steam")},
            {"War Thunder", app("war thunder")}, {"Arma Reforger", app("arma reforger")}, {"Esc", "K:ESC"},
            {"Enter", "K:ENTER"}, {"Space", "K:SPACE"}, {"Tab", "K:TAB"}, {"Map (M)", "K:M"},
            {"Alt+Tab out", "K:ALT+TAB"}, {"Fullscreen", "K:ALT+ENTER"},
        },
        {
            {"↑", "K:UP"}, {"↓", "K:DOWN"}, {"←", "K:LEFT"}, {"→", "K:RIGHT"}, {"Enter", "K:ENTER"},
            {"Esc", "K:ESC"}, {"Tab", "K:TAB"}, {"Backspace", "K:BKSP"}, {"Space", "K:SPACE"}, {"Delete", "K:DEL"},
            {"Home", "K:HOME"}, {"End", "K:END"}, {"Page up", "K:PGUP"}, {"Page down", "K:PGDN"},
            {"Right-click menu", "K:APPS"}, {"Caps lock", "K:CAPS"}, {"F1", "K:F1"}, {"F2", "K:F2"}, {"F3", "K:F3"},
            {"F4", "K:F4"}, {"F5", "K:F5"}, {"F11", "K:F11"}, {"F12", "K:F12"}, {"Save", "K:CTRL+S"},
            {"Print", "K:CTRL+P"}, {"Copy", "K:CTRL+C"}, {"Paste", "K:CTRL+V"}, {"Undo", "K:CTRL+Z"},
        },
    };

    private final TextView status;
    private final TextView connect;
    private final TextView layoutChip;
    private final FrameLayout body;
    private final List<TextView> tabChips = new ArrayList<>();
    private int tab;

    PcRemoteWidget(NovaActivity host) {
        super(host);
        LinearLayout top = row();
        status = text("", 10f, Theme.DIM);
        status.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
        status.setPadding(dp(4), 0, dp(4), 0);
        top.addView(status, weight(1f));
        connect = chip("CONNECT", this::connectTapped);
        connect.setOnLongClickListener(v -> {
            choosePc();
            return true;
        });
        top.addView(connect);
        layoutChip = chip("", () -> {
            Prefs.putInt(PcHid.K_LAYOUT, (Prefs.getInt(PcHid.K_LAYOUT, 0) + 1) % PcHid.LAYOUTS.length);
            refresh();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(4), 0, 0, 0);
        top.addView(layoutChip, lp);
        addView(top, wide());

        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = row();
        for (int i = 0; i < TABS.length; i++) {
            final int t = i;
            TextView c = chip(TABS[i], () -> show(t));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            p.setMargins(dp(2), dp(4), dp(2), dp(4));
            tabs.addView(c, p);
            tabChips.add(c);
        }
        hs.addView(tabs);
        addView(hs, wide());
        body = new FrameLayout(host);
        addView(body, wide());
        show(Math.max(0, Math.min(TABS.length - 1, Prefs.getInt(K_TAB, 0))));
    }

    @Override
    void refresh() {
        status.setText(PcHid.connected() ? "● " + PcHid.state : PcHid.state);
        status.setTextColor(PcHid.connected() ? 0xFF34C759 : Theme.DIM);
        connect.setText(PcHid.connected() ? "CONNECTED" : "CONNECT");
        pick(connect, PcHid.connected());
        layoutChip.setText(new String[] {"CH", "DE", "US"}[Math.max(0, Math.min(2, Prefs.getInt(PcHid.K_LAYOUT, 0)))]);
    }

    @Override
    void onLive(boolean on) {
        PcHid.listener = on ? this::refresh : null;
        if (on && PcHid.hid == null && btAllowed()) {
            PcHid.start(host);
        }
    }

    private boolean btAllowed() {
        return Build.VERSION.SDK_INT < 31
                || host.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    // ------------------------------------------------------------------ connecting

    private void connectTapped() {
        if (PcHid.connected()) {
            new AlertDialog.Builder(host).setTitle("PC REMOTE")
                    .setMessage(PcHid.state)
                    .setPositiveButton("DISCONNECT", (d, w) -> PcHid.disconnect())
                    .setNeutralButton("OTHER PC", (d, w) -> choosePc())
                    .setNegativeButton("OK", null).show();
            return;
        }
        String[] perms = Build.VERSION.SDK_INT >= 31
                ? new String[] {android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_ADVERTISE}
                : new String[0];
        Runnable go = () -> {
            BluetoothAdapter a = PcHid.adapter(host);
            if (a != null && !a.isEnabled()) {
                try {
                    host.startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                } catch (RuntimeException e) {
                    host.toast("Turn Bluetooth on");
                }
                return;
            }
            PcHid.start(host);
            if (Prefs.getString(PcHid.K_ADDR, "").isEmpty()) {
                choosePc();
            } else {
                PcHid.reconnect();
            }
        };
        if (perms.length == 0) {
            go.run();
        } else {
            host.ask(perms, go, () -> host.toast("PC REMOTE needs Nearby devices (Bluetooth)"));
        }
    }

    /** Pick a PC that is already paired, or pair a new one. */
    private void choosePc() {
        final List<BluetoothDevice> pcs = new ArrayList<>();
        List<String> names = new ArrayList<>();
        try {
            BluetoothAdapter a = PcHid.adapter(host);
            if (a != null) {
                for (BluetoothDevice d : a.getBondedDevices()) {
                    BluetoothClass bc = d.getBluetoothClass();
                    boolean computer = bc != null && bc.getMajorDeviceClass() == BluetoothClass.Device.Major.COMPUTER;
                    pcs.add(computer ? 0 : pcs.size(), d);
                    names.add(computer ? 0 : names.size(), (computer ? "💻 " : "") + PcHid.name(d));
                }
            }
        } catch (SecurityException e) {
            host.toast("Allow Nearby devices first");
            return;
        }
        names.add("➕ PAIR A NEW PC");
        new AlertDialog.Builder(host).setTitle("Which PC?")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    if (which >= pcs.size()) {
                        pairNew();
                    } else {
                        String addr = pcs.get(which).getAddress();
                        Prefs.putString(PcHid.K_ADDR, addr);
                        if (PcHid.registered) {
                            PcHid.connectTo(addr);
                        } else {
                            PcHid.start(host);
                        }
                    }
                }).show();
    }

    private void pairNew() {
        try {
            Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            host.startActivity(i);
        } catch (RuntimeException ignored) {
            // the phone will show it anyway from its Bluetooth screen
        }
        new AlertDialog.Builder(host).setTitle("Pair your PC")
                .setMessage("1. Your phone is now visible for 5 minutes.\n\n"
                        + "2. On the PC: Settings > Bluetooth & devices > Add device > Bluetooth, and pick this phone.\n\n"
                        + "3. Accept the code on both screens. Windows adds it as a keyboard and mouse.\n\n"
                        + "Tip: if the PC already knew this phone, remove it there first (Bluetooth & devices > ⋯ > "
                        + "Remove device) and pair again, so Windows sees the new keyboard and mouse.")
                .setPositiveButton("OK", null).show();
    }

    // ------------------------------------------------------------------ tabs

    private void show(int t) {
        tab = t;
        Prefs.putInt(K_TAB, t);
        for (int i = 0; i < tabChips.size(); i++) {
            pick(tabChips.get(i), i == t);
        }
        body.removeAllViews();
        if (t == 0) {
            body.addView(mousePanel());
        } else if (t == 1) {
            body.addView(typePanel());
        } else {
            body.addView(grid(t));
        }
        refresh();
    }

    private boolean ready() {
        if (!PcHid.connected()) {
            host.toast("Not connected: tap CONNECT");
            return false;
        }
        return true;
    }

    private View grid(int t) {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        List<String[]> list = new ArrayList<>();
        for (String[] a : ACTIONS[t]) {
            list.add(a);
        }
        if (t == 2) {
            for (String n : Prefs.getString(K_APPS, "").split("\n")) {
                if (!n.trim().isEmpty()) {
                    list.add(new String[] {n.trim(), app(n.trim().toLowerCase(java.util.Locale.ROOT))});
                }
            }
            list.add(new String[] {"+ ANY APP", ""});
        }
        LinearLayout r = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % 3 == 0) {
                r = row();
                col.addView(r, wide());
            }
            final String[] a = list.get(i);
            final boolean danger = a[0].startsWith("!");
            String label = danger ? a[0].substring(1) : a[0];
            TextView b = chip(label, () -> {
                if (a[1].isEmpty()) {
                    addApp();
                    return;
                }
                if (!ready()) {
                    return;
                }
                if (danger) {
                    new AlertDialog.Builder(host).setTitle(label + " the PC?")
                            .setPositiveButton(label.toUpperCase(java.util.Locale.ROOT), (d, w) -> PcHid.run(a[1]))
                            .setNegativeButton("CANCEL", null).show();
                } else {
                    host.buzz(8);
                    PcHid.run(a[1]);
                }
            });
            if (danger) {
                b.setTextColor(0xFFFF453A);
            }
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(b, p);
        }
        while (r != null && r.getChildCount() < 3) {
            r.addView(new View(host), weight(1f));
        }
        return col;
    }

    private void addApp() {
        final EditText e = new EditText(host);
        e.setHint("App name as in the Start menu");
        e.setSingleLine(true);
        new AlertDialog.Builder(host).setTitle("Add an app button")
                .setView(e)
                .setPositiveButton("ADD", (d, w) -> {
                    String n = e.getText().toString().trim();
                    if (!n.isEmpty()) {
                        String old = Prefs.getString(K_APPS, "");
                        Prefs.putString(K_APPS, old + n + "\n");
                        show(2);
                    }
                })
                .setNeutralButton("CLEAR MINE", (d, w) -> {
                    Prefs.putString(K_APPS, "");
                    show(2);
                })
                .setNegativeButton("CANCEL", null).show();
    }

    private View typePanel() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        final EditText e = new EditText(host);
        e.setHint("Type here, then SEND");
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(Theme.DIM);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setMaxLines(4);
        col.addView(e, wide());
        LinearLayout r = row();
        String[][] b = {{"SEND", ""}, {"SEND + ENTER", ""}, {"ENTER", "K:ENTER"}, {"⌫", "K:BKSP"}};
        for (final String[] x : b) {
            TextView c = chip(x[0], () -> {
                if (!ready()) {
                    return;
                }
                if (x[1].isEmpty()) {
                    String s = e.getText().toString();
                    PcHid.type(x[0].length() > 4 ? s + "\n" : s);
                    e.setText("");
                } else {
                    PcHid.run(x[1]);
                }
            });
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(c, p);
        }
        col.addView(r, wide());
        TextView hint = text("Set CH / DE / US (top right) to your PC's keyboard layout so symbols come out right.", 9f,
                Theme.DIM);
        hint.setPadding(0, dp(4), 0, 0);
        col.addView(hint, wide());
        return col;
    }

    private View mousePanel() {
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(VERTICAL);
        Trackpad pad = new Trackpad();
        col.addView(pad, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(150)));
        LinearLayout r = row();
        String[][] b = {{"LEFT", "1"}, {"MIDDLE", "4"}, {"RIGHT", "2"}};
        for (final String[] x : b) {
            TextView c = chip(x[0], () -> {
                if (ready()) {
                    PcHid.click(Integer.parseInt(x[1]));
                }
            });
            LinearLayout.LayoutParams p = weight(1f);
            p.setMargins(dp(2), dp(2), dp(2), dp(2));
            r.addView(c, p);
        }
        col.addView(r, wide());
        TextView hint = text("Drag = move · tap = click · 2-finger tap = right click · 2-finger drag = scroll "
                + "· double-tap + drag = hold and drag", 9f, Theme.DIM);
        col.addView(hint, wide());
        return col;
    }

    /** The trackpad: moves the mouse with acceleration, taps click, two fingers scroll or right-click. */
    private final class Trackpad extends View {
        private float lx;
        private float ly;
        private float sx;
        private float sy;
        private long downAt;
        private long lastTap;
        private boolean moved;
        private boolean two;
        private boolean holding;
        private float scrollAcc;
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        Trackpad() {
            super(host);
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            p.setColor(0x18FFFFFF);
            c.drawRoundRect(new android.graphics.RectF(dp(2), dp(2), getWidth() - dp(2), getHeight() - dp(2)), dp(14), dp(14), p);
            p.setColor(Theme.DIM);
            p.setTextSize(dp(10));
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            c.drawText(PcHid.connected() ? "TRACKPAD" : "connect first", getWidth() / 2f, getHeight() / 2f, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lx = sx = e.getX();
                    ly = sy = e.getY();
                    downAt = SystemClock.uptimeMillis();
                    moved = false;
                    two = false;
                    // double-tap then drag: hold the left button
                    holding = downAt - lastTap < 250;
                    if (holding) {
                        PcHid.mouse(1, 0, 0, 0);
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    two = true;
                    ly = e.getY(0);
                    scrollAcc = 0;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    if (two && e.getPointerCount() >= 2) {
                        float dy = e.getY(0) - ly;
                        ly = e.getY(0);
                        scrollAcc += dy;
                        int steps = (int) (scrollAcc / dp(14));
                        if (steps != 0) {
                            scrollAcc -= steps * dp(14);
                            PcHid.mouse(holding ? 1 : 0, 0, 0, steps);
                            moved = true;
                        }
                        return true;
                    }
                    float dx = e.getX() - lx;
                    float dy = e.getY() - ly;
                    lx = e.getX();
                    ly = e.getY();
                    if (Math.hypot(e.getX() - sx, e.getY() - sy) > dp(6)) {
                        moved = true;
                    }
                    float speed = (float) Math.hypot(dx, dy);
                    float acc = 1.1f + Math.min(2.4f, speed / dp(9));
                    PcHid.mouse(holding ? 1 : 0, Math.round(dx * acc / getResources().getDisplayMetrics().density * 1.6f),
                            Math.round(dy * acc / getResources().getDisplayMetrics().density * 1.6f), 0);
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    long now = SystemClock.uptimeMillis();
                    if (holding) {
                        PcHid.mouse(0, 0, 0, 0);
                        holding = false;
                        lastTap = 0;
                        return true;
                    }
                    if (!moved && now - downAt < 220) {
                        if (!ready()) {
                            return true;
                        }
                        PcHid.click(two ? 2 : 1);
                        lastTap = two ? 0 : now;
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }
}
