package app.novaos;

import android.animation.ValueAnimator;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.PathInterpolator;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * NOVA ISLAND: a wide black pill at the top of the screen, over every app. Left: what is going on (music, timer,
 * focus, bus, charging, a new message). Right: phone and headphone battery. Tap it and it grows into a dashboard with
 * all batteries, the thing going on with its buttons, your day and quick buttons (torch, camera, music, bus, NOVA).
 *
 * Shown through NOVA's accessibility service (around the camera, over the status bar) or, if that is blocked, with
 * "display over other apps" (then it sits just under the status bar).
 */
final class Island {
    static final String K_ON = "island_on";
    static final String K_NOTIF = "island_notif";

    private static IslandView view;
    private static boolean viewIsAccess;
    private static WindowManager accessWm;
    private static Context accessCtx;
    private static BroadcastReceiver power;
    private static Context powerCtx;

    private Island() {
    }

    static boolean enabled() {
        return Prefs.getBool(K_ON, true);
    }

    static boolean serviceOn() {
        return MouseService.instance != null;
    }

    static boolean canOverlay(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static boolean showing() {
        return view != null;
    }

    /** What the island shows, all on unless switched off in Settings > NOVA ISLAND. */
    static boolean show(String what) {
        return Prefs.getBool("isl_" + what, true);
    }

    /** A style option chosen in Settings > NOVA ISLAND > STYLE (the index of the choice). */
    static int opt(String key, int def) {
        return Prefs.getInt("islo_" + key, def);
    }

    /** Moves the island to the middle of the screen, keeping its height. */
    static void center() {
        if (view != null) {
            view.post(view::centerIt);
        }
    }

    /** After "reset position" or a new size in Settings. */
    static void reload() {
        if (view != null) {
            view.post(view::reloadPos);
        }
    }

    /** Puts the island into drag mode (from Settings). */
    static void edit() {
        if (view != null) {
            view.post(view::startEdit);
        }
    }

    static void start(Context c, WindowManager w) {
        Prefs.init(c);
        accessCtx = c;
        accessWm = w;
        sync(c);
    }

    static void stop() {
        if (viewIsAccess) {
            detach();
        }
        accessCtx = null;
        accessWm = null;
        sync(Prefs.appContext());
    }

    /** Shows or hides the island to match the setting, the best way that is allowed right now. */
    static void sync(Context any) {
        try {
            if (!enabled()) {
                detach();
                return;
            }
            if (accessCtx != null) {
                if (view != null && !viewIsAccess) {
                    detach();
                }
                if (view == null) {
                    attach(accessCtx, accessWm, true);
                }
                return;
            }
            if (any != null && canOverlay(any) && view == null) {
                Context app = any.getApplicationContext();
                attach(app, (WindowManager) app.getSystemService(Context.WINDOW_SERVICE), false);
            }
        } catch (RuntimeException e) {
            detach();
        }
    }

    static void sync() {
        sync(accessCtx != null ? accessCtx : Prefs.appContext());
    }

    private static void attach(Context c, WindowManager w, boolean access) {
        IslandView v = new IslandView(c, w, access);
        if (!v.add()) {
            return;
        }
        view = v;
        viewIsAccess = access;
        power = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (view != null) {
                    view.powerChanged(Intent.ACTION_POWER_CONNECTED.equals(intent.getAction()));
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                c.registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                c.registerReceiver(power, f);
            }
            powerCtx = c;
        } catch (RuntimeException ignored) {
            power = null;
        }
        NovaNotificationService.islandListener = item -> {
            final IslandView iv = view;
            if (iv != null && Prefs.getBool(K_NOTIF, true)) {
                iv.post(() -> iv.notified(item));
            }
        };
    }

    private static void detach() {
        NovaNotificationService.islandListener = null;
        if (power != null && powerCtx != null) {
            try {
                powerCtx.unregisterReceiver(power);
            } catch (RuntimeException ignored) {
                // already gone
            }
        }
        power = null;
        powerCtx = null;
        if (view != null) {
            view.remove();
            view = null;
        }
    }

    /** {name, level 0..100 or -1, is audio} for every connected Bluetooth device. */
    static List<Object[]> bluetooth(Context c) {
        List<Object[]> out = new ArrayList<>();
        try {
            if (Build.VERSION.SDK_INT >= 31
                    && c.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return out;
            }
            BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter a = bm == null ? null : bm.getAdapter();
            if (a == null || !a.isEnabled()) {
                return out;
            }
            for (BluetoothDevice dev : a.getBondedDevices()) {
                boolean conn;
                try {
                    conn = (boolean) dev.getClass().getMethod("isConnected").invoke(dev);
                } catch (Exception e) {
                    conn = false;
                }
                if (!conn) {
                    continue;
                }
                int lvl = -1;
                try {
                    lvl = (int) dev.getClass().getMethod("getBatteryLevel").invoke(dev);
                } catch (Exception ignored) {
                    // not told
                }
                String name = null;
                if (Build.VERSION.SDK_INT >= 30) {
                    name = dev.getAlias();
                }
                if (name == null) {
                    name = dev.getName();
                }
                BluetoothClass bc = dev.getBluetoothClass();
                boolean audio = bc == null || bc.getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO;
                out.add(new Object[] {name == null ? "Bluetooth" : name, lvl, audio});
            }
        } catch (RuntimeException ignored) {
            // no Bluetooth info
        }
        return out;
    }

    static final class Act {
        static final int MUSIC = 0;
        static final int TIMER = 1;
        static final int FOCUS = 2;
        static final int BUS = 3;
        static final int LEAVE = 4;
        static final int CHARGE = 5;
        static final int NOTE = 6;
        static final int LOW = 7;
        final int kind;
        final int color;

        Act(int kind, int color) {
            this.kind = kind;
            this.color = color;
        }
    }

    static final class IslandView extends View {
        private static final int GREEN = 0xFF34C759;
        private static final int ORANGE = 0xFFFF9F0A;
        private static final int RED = 0xFFFF453A;
        private static final int YELLOW = 0xFFFFC21A;
        private static final int BLUE = 0xFF0A84FF;
        private static final int PINK = 0xFFFF375F;
        private static final int GREY = 0xFF98989D;
        private static final int CARD = 0xFF1C1C1E;

        private final WindowManager wm;
        private final WindowManager.LayoutParams lp;
        private final boolean access;
        private final float d;
        private final Handler h = new Handler(Looper.getMainLooper());
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final PathInterpolator ease = new PathInterpolator(0.32f, 0.72f, 0f, 1f);

        private float camX;
        private float camY;
        private float camR;
        private float barTop;
        private int screenW;
        private int screenH;

        private float curW;
        private float curH;
        private float fromW;
        private float fromH;
        private float toW;
        private float toH;
        private float contentAlpha = 1f;
        private ValueAnimator anim;

        private boolean expanded;
        private boolean added;
        private boolean landscape;
        private final List<Act> acts = new ArrayList<>();
        private int focusKind = -1;

        private MediaController music;
        private Bitmap art;
        private String artKey = "";
        private long timerEnd;
        private long focusEnd;
        private long focusLeft;
        private boolean focusWork = true;
        private long chargeUntil;
        private boolean charging;
        private int battery;
        private List<Object[]> bt = new ArrayList<>();
        private long btAt;
        private NovaNotificationService.Item note;
        private long noteUntil;
        private Drawable noteIcon;
        private List<BusData.Dep> deps;
        private String busStop = "";
        private long busFetched;
        private boolean busBusy;
        private boolean torch;
        private String torchId;

        private boolean editing;
        private float customCx = -1;
        private float customTop = -1;
        private float dragRawX;
        private float dragRawY;
        private float dragCx;
        private float dragTop;
        private boolean dragged;
        private float downX;
        private float downY;
        private long downAt;
        private final List<Object[]> hits = new ArrayList<>();
        private final Runnable poll = new Runnable() {
            @Override
            public void run() {
                try {
                    update();
                } catch (RuntimeException ignored) {
                    // never let one bad read stop the island
                }
                h.postDelayed(this, expanded || !acts.isEmpty() ? 1000 : 2500);
            }
        };

        IslandView(Context c, WindowManager wm, boolean access) {
            super(c);
            this.wm = wm;
            this.access = access;
            d = c.getResources().getDisplayMetrics().density;
            Prefs.init(c);
            int type = access ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    : WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            lp = new WindowManager.LayoutParams(1, 1, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 30) {
                lp.setFitInsetsTypes(0);
                lp.setFitInsetsSides(0);
                lp.setFitInsetsIgnoringVisibility(true);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            } else if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            try {
                CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
                for (String id : cm.getCameraIdList()) {
                    Boolean fl = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (fl != null && fl) {
                        torchId = id;
                        break;
                    }
                }
                cm.registerTorchCallback(new CameraManager.TorchCallback() {
                    @Override
                    public void onTorchModeChanged(String id, boolean on) {
                        if (id.equals(torchId)) {
                            torch = on;
                            postInvalidate();
                        }
                    }
                }, h);
            } catch (Exception ignored) {
                // no torch
            }
        }

        boolean add() {
            loadPos();
            findCamera();
            curW = toW = compactW();
            curH = toH = compactH();
            place();
            try {
                wm.addView(this, lp);
                added = true;
            } catch (RuntimeException e) {
                added = false;
                return false;
            }
            h.post(poll);
            return true;
        }

        void remove() {
            h.removeCallbacksAndMessages(null);
            if (anim != null) {
                anim.cancel();
            }
            if (added) {
                try {
                    wm.removeView(this);
                } catch (RuntimeException ignored) {
                    // already gone
                }
            }
            added = false;
        }

        private int sbH;

        private void loadPos() {
            customCx = Prefs.getInt("island_cx", -1);
            customTop = Prefs.getInt("island_top", -1);
        }

        void reloadPos() {
            loadPos();
            findCamera();
            curW = toW = expanded ? expandedW() : compactW();
            curH = toH = expanded ? curH : compactH();
            place();
            invalidate();
        }

        void centerIt() {
            if (customTop < 0) {
                customTop = barTop;
            }
            customCx = screenW / 2f;
            if (!editing) {
                Prefs.putInt("island_cx", Math.round(customCx));
                Prefs.putInt("island_top", Math.round(customTop));
            }
            place();
            invalidate();
        }

        void startEdit() {
            editing = true;
            expanded = false;
            vibrate();
            curW = toW = compactW();
            curH = toH = compactH();
            place();
            invalidate();
        }

        private void stopEdit() {
            editing = false;
            Prefs.putInt("island_cx", Math.round(customCx));
            Prefs.putInt("island_top", Math.round(customTop));
            vibrate();
            invalidate();
        }

        private float top() {
            return customTop >= 0 ? customTop : barTop;
        }

        private float centerX() {
            return customCx >= 0 ? customCx : camX;
        }

        /** True when the camera hole is inside the small pill (then text keeps away from it). */
        private boolean camInPill() {
            float l = lp.x;
            float t = top();
            return camR > 0 && camX > l && camX < l + curW && camY > t && camY < t + compactH();
        }

        private void findCamera() {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            camX = screenW / 2f;
            camR = 0;
            int sb = 0;
            int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) {
                sb = getResources().getDimensionPixelSize(id);
            }
            sbH = Math.max(sb, Math.round(24 * d));
            camY = sbH / 2f;
            DisplayCutout cut = null;
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    android.view.WindowMetrics m = wm.getCurrentWindowMetrics();
                    screenW = m.getBounds().width();
                    screenH = m.getBounds().height();
                    camX = screenW / 2f;
                    cut = m.getWindowInsets().getDisplayCutout();
                } catch (RuntimeException ignored) {
                    // try the display
                }
            }
            if (cut == null && Build.VERSION.SDK_INT >= 29) {
                try {
                    cut = wm.getDefaultDisplay().getCutout();
                } catch (RuntimeException ignored) {
                    // none
                }
            }
            if (cut != null) {
                for (Rect b : cut.getBoundingRects()) {
                    if (b.top < 200 * d && b.width() < screenW / 3) {
                        camX = b.exactCenterX();
                        camY = b.exactCenterY();
                        camR = Math.max(b.width(), b.height()) / 2f;
                        break;
                    }
                }
            }
            if (camR <= 0) {
                // no cutout reported: most phones have a punch hole in the middle of the status bar
                camR = Math.max(sbH * 0.3f, 6 * d);
            }
            // over the camera in both modes
            barTop = Math.max(0, camY - compactH() / 2f);
        }

        private float compactH() {
            int hi = Prefs.getInt("island_h", 0);
            if (hi > 0) {
                return (24 + hi * 4) * d;
            }
            float h0 = Math.max(camR * 2 + 12 * d, 34 * d);
            if (!access) {
                // with "display over other apps" the status bar catches touches, so reach a bit below it
                h0 = Math.max(h0, (sbH + 12 * d - Math.max(0, camY - h0 / 2f)));
            }
            return h0;
        }

        private boolean idleNow;
        private boolean dotted;
        private long awakeAt = SystemClock.uptimeMillis();

        private long dotDelay() {
            return new int[] {3, 5, 10, 20, 30, 60}[Math.max(0, Math.min(5, opt("dotsecs", 2)))] * 1000L;
        }

        private float compactW() {
            if ((dotted || idleNow && opt("idle", 0) == 1) && !editing) {
                return compactH();
            }
            int wi = Prefs.getInt("island_w", 0);
            if (wi > 0) {
                return Math.min(screenW, screenW * (0.25f + wi * 0.05f));
            }
            int size = Prefs.getInt("island_size", 2);
            if (size >= 3) {
                return screenW - 12 * d;
            }
            float[] f = {0.5f, 0.68f, 0.86f};
            return Math.min(screenW - 24 * d, 400 * d) * f[Math.max(0, size)];
        }

        private float expandedW() {
            float w = Math.min(screenW - 16 * d, 460 * d);
            return opt("dash", 0) == 1 ? w * 0.84f : w;
        }

        private void place() {
            int w = Math.round(curW);
            int hh = Math.round(curH);
            float cx = curW > compactW() + 2 && customCx < 0 ? screenW / 2f : centerX();
            lp.width = Math.max(1, w);
            lp.height = Math.max(1, hh);
            lp.x = Math.round(Math.max(0, Math.min(screenW - w, cx - w / 2f)));
            lp.y = Math.round(Math.max(0, Math.min(screenH - hh, top())));
            if (added) {
                try {
                    wm.updateViewLayout(this, lp);
                } catch (RuntimeException ignored) {
                    // window gone
                }
            }
        }

        private void animateTo(float w, float hh) {
            if (Math.abs(w - toW) < 1 && Math.abs(hh - toH) < 1) {
                return;
            }
            if (anim != null) {
                anim.cancel();
            }
            fromW = curW;
            fromH = curH;
            toW = w;
            toH = hh;
            final boolean growing = hh > fromH + 1;
            final boolean bigJump = Math.abs(hh - fromH) > 40 * d;
            anim = ValueAnimator.ofFloat(0f, 1f);
            float speed = new float[] {0.55f, 1f, 1.6f}[Math.max(0, Math.min(2, opt("anim", 1)))];
            anim.setDuration(Math.round((growing ? 440 : 340) * speed));
            anim.setInterpolator(ease);
            anim.addUpdateListener(a -> {
                float m = (float) a.getAnimatedValue();
                curW = fromW + (toW - fromW) * m;
                curH = fromH + (toH - fromH) * m;
                contentAlpha = !bigJump ? 1f : m < 0.3f ? 1f - m / 0.3f : Math.max(0f, (m - 0.5f) / 0.5f);
                place();
                invalidate();
            });
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator a) {
                    curW = toW;
                    curH = toH;
                    contentAlpha = 1f;
                    anim = null;
                    place();
                    invalidate();
                }
            });
            anim.start();
        }

        private void update() {
            boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
            if (land != landscape) {
                landscape = land;
                setVisibility(land ? GONE : VISIBLE);
                if (!land) {
                    findCamera();
                    curW = toW = expanded ? expandedW() : compactW();
                    place();
                }
            }
            if (land) {
                if (added && lp.width != 1) {
                    lp.width = 1;
                    lp.height = 1;
                    try {
                        wm.updateViewLayout(this, lp);
                    } catch (RuntimeException ignored) {
                        // gone
                    }
                }
                return;
            }
            long now = System.currentTimeMillis();
            acts.clear();
            music = MusicHelper.controller(getContext());
            if (music != null && MusicHelper.isPlaying(music)) {
                acts.add(new Act(Act.MUSIC, GREEN));
                loadArt();
            } else if (music != null && MusicHelper.active(music) && expanded && focusKind == Act.MUSIC) {
                acts.add(new Act(Act.MUSIC, GREEN));
            }
            timerEnd = TimerPage.endsAt();
            if (timerEnd > now) {
                acts.add(0, new Act(Act.TIMER, ORANGE));
            }
            try {
                focusEnd = Long.parseLong(Prefs.getString("focus_end", "0"));
                focusLeft = Long.parseLong(Prefs.getString("focus_left", "0"));
            } catch (NumberFormatException e) {
                focusEnd = 0;
                focusLeft = 0;
            }
            focusWork = Prefs.getInt("focus_mode", 0) == 0;
            if (focusEnd > now || focusLeft > 0) {
                acts.add(new Act(Act.FOCUS, focusWork ? PINK : GREEN));
            }
            Calendar c = Calendar.getInstance();
            boolean schoolDay = !Life.weekend(c);
            int left = Life.leaveMin() - Life.nowMin();
            boolean commute = schoolDay && left > -15 && left <= new int[] {30, 60, 90}[Math.max(0, Math.min(2, opt("bus", 1)))];
            if (commute || expanded) {
                fetchBus(false);
            }
            if (commute && deps != null && !deps.isEmpty()) {
                acts.add(new Act(Act.BUS, YELLOW));
            } else if (commute && left > 0) {
                acts.add(new Act(Act.LEAVE, YELLOW));
            }
            battery = Theme.batteryPct(getContext());
            try {
                Intent bi = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (bi != null) {
                    charging = bi.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
                }
            } catch (RuntimeException ignored) {
                // keep
            }
            if (chargeUntil > now) {
                acts.add(0, new Act(Act.CHARGE, GREEN));
            } else if (battery > 0 && battery <= lowAt() && !charging) {
                acts.add(new Act(Act.LOW, RED));
            }
            if (note != null && noteUntil > now) {
                acts.add(0, new Act(Act.NOTE, BLUE));
            } else if (note != null && !(expanded && focusKind == Act.NOTE)) {
                note = null;
            }
            if (now - btAt > (expanded ? 5000 : 30000)) {
                btAt = now;
                bt = bluetooth(getContext());
            }
            boolean stillThere = focusKind < 0;
            for (Act a : acts) {
                stillThere |= a.kind == focusKind;
            }
            boolean idle = true;
            for (Act x : acts) {
                idle &= !showsInPill(x.kind);
            }
            idleNow = idle;
            long up = SystemClock.uptimeMillis();
            if (!idle || expanded || editing) {
                awakeAt = up;
            }
            dotted = opt("autodot", 0) == 1 && idle && !expanded && !editing && up - awakeAt > dotDelay();
            if (editing) {
                return;
            }
            if (!expanded) {
                focusKind = acts.isEmpty() ? -1 : acts.get(0).kind;
                animateTo(compactW(), compactH());
            } else {
                if (!stillThere) {
                    focusKind = acts.isEmpty() ? -1 : acts.get(0).kind;
                }
                animateTo(expandedW(), dash(null, expandedW()));
            }
            invalidate();
        }

        private void loadArt() {
            try {
                MediaMetadata md = music.getMetadata();
                String key = md == null ? "" : MusicHelper.title(music) + MusicHelper.artist(music);
                if (key.equals(artKey)) {
                    return;
                }
                artKey = key;
                Bitmap b = md == null ? null : md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (b == null && md != null) {
                    b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                }
                art = b == null ? null : Bitmap.createScaledBitmap(b, Math.round(64 * d), Math.round(64 * d), true);
            } catch (RuntimeException e) {
                art = null;
            }
        }

        private void fetchBus(boolean force) {
            long now = System.currentTimeMillis();
            if (busBusy || (!force && now - busFetched < 60000)) {
                return;
            }
            final List<BusData.Route> routes = new ArrayList<>();
            BusData.Stop stop = null;
            for (BusData.Route rt : BusData.routes()) {
                if (!rt.show) {
                    continue;
                }
                for (BusData.Stop s : rt.stops) {
                    if (rt.boardIds.contains(s.id) && (stop == null || stop.id.equals(s.id))) {
                        stop = s;
                        if (!routes.contains(rt)) {
                            routes.add(rt);
                        }
                    }
                }
            }
            if (stop == null) {
                return;
            }
            busBusy = true;
            busFetched = now;
            final BusData.Stop st = stop;
            new Thread(() -> {
                List<BusData.Dep> got = null;
                try {
                    got = BusData.board(st, routes);
                } catch (RuntimeException ignored) {
                    // later
                }
                final List<BusData.Dep> res = got;
                h.post(() -> {
                    busBusy = false;
                    if (res != null) {
                        deps = res;
                        busStop = st.shortName();
                    }
                    invalidate();
                });
            }).start();
        }

        void powerChanged(boolean on) {
            charging = on;
            chargeUntil = System.currentTimeMillis() + 4000;
            safeUpdate();
            h.postDelayed(this::safeUpdate, 4100);
        }

        void notified(NovaNotificationService.Item item) {
            note = item;
            long secs = new int[] {3, 5, 8, 12}[Math.max(0, Math.min(3, opt("note", 1)))] * 1000L;
            noteUntil = System.currentTimeMillis() + secs;
            noteIcon = null;
            try {
                noteIcon = getContext().getPackageManager().getApplicationIcon(item.pkg);
            } catch (Exception ignored) {
                // no icon
            }
            safeUpdate();
            h.postDelayed(this::safeUpdate, secs + 100);
        }

        private void safeUpdate() {
            try {
                update();
            } catch (RuntimeException ignored) {
                // next poll
            }
        }

        private void expand() {
            expanded = true;
            vibrate();
            btAt = 0;
            safeUpdate();
        }

        private void collapse() {
            expanded = false;
            safeUpdate();
        }

        private int lowAt() {
            return new int[] {10, 15, 20, 30}[Math.max(0, Math.min(3, opt("low", 1)))];
        }

        private int textCol() {
            int t = opt("tcol", 0);
            return t == 1 ? GREY : t == 2 ? Theme.ACCENT : 0xFFFFFFFF;
        }

        private int bgCol() {
            int[] cols = {0xFF000000, 0xFF1C1C1E, 0xFF0B1A3A, 0xFF24103D, 0xFF0D2A1A, 0xFF3A0D16};
            int ci = opt("color", 0);
            int col = ci >= cols.length ? HomeKit.darker(Theme.ACCENT, 0.35f) | 0xFF000000 : cols[Math.max(0, ci)];
            int a = new int[] {255, 230, 204, 178, 153}[Math.max(0, Math.min(4, opt("alpha", 0)))];
            return (col & 0x00FFFFFF) | (a << 24);
        }

        private void vibrate() {
            if (opt("haptic", 0) == 1) {
                return;
            }
            try {
                performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK);
            } catch (RuntimeException ignored) {
                // none
            }
        }

        private void launch(Intent i) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (RuntimeException e) {
                // nothing to open
            }
            collapse();
        }

        private void openNova(String extra) {
            Intent i = new Intent(getContext(), NovaActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            if (extra != null) {
                i.putExtra("open", extra);
            }
            launch(i);
        }

        private void toggleTorch() {
            try {
                if (torchId != null) {
                    ((CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE)).setTorchMode(torchId, !torch);
                }
            } catch (Exception ignored) {
                // camera busy
            }
        }

        private void toggleFocus(boolean running) {
            long now = System.currentTimeMillis();
            if (running) {
                Prefs.putString("focus_left", String.valueOf(focusEnd - now));
                Prefs.putString("focus_end", "0");
            } else {
                long left = focusLeft > 0 ? focusLeft : (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                Prefs.putString("focus_end", String.valueOf(now + left));
                Prefs.putString("focus_left", "0");
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (editing) {
                return editTouch(e);
            }
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_OUTSIDE:
                    if (expanded) {
                        collapse();
                    }
                    return true;
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    downAt = SystemClock.uptimeMillis();
                    h.removeCallbacks(holdEdit);
                    if (!expanded) {
                        h.postDelayed(holdEdit, 650);
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    h.removeCallbacks(holdEdit);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.hypot(e.getX() - downX, e.getY() - downY) > 10 * d) {
                        h.removeCallbacks(holdEdit);
                    }
                    if (!expanded && e.getY() - downY > 20 * d && downAt > 0) {
                        downAt = -1;
                        expand();
                    }
                    return true;
                case MotionEvent.ACTION_UP: {
                    h.removeCallbacks(holdEdit);
                    if (downAt < 0 || editing) {
                        return true;
                    }
                    float dy = e.getY() - downY;
                    if (expanded && dy < -30 * d) {
                        collapse();
                        return true;
                    }
                    if (Math.hypot(e.getX() - downX, dy) > 14 * d) {
                        return true;
                    }
                    if (!expanded && dotted) {
                        // first tap on the dot: back to the normal pill, the next tap opens it big
                        vibrate();
                        dotted = false;
                        awakeAt = SystemClock.uptimeMillis();
                        safeUpdate();
                        return true;
                    }
                    if (!expanded) {
                        awakeAt = SystemClock.uptimeMillis();
                        int tap = opt("tap", 0);
                        if (tap == 0) {
                            expand();
                        } else if (tap == 1) {
                            vibrate();
                            openNova(null);
                        }
                        return true;
                    }
                    for (int i = hits.size() - 1; i >= 0; i--) {
                        Object[] hit = hits.get(i);
                        if (((RectF) hit[0]).contains(e.getX(), e.getY())) {
                            vibrate();
                            try {
                                ((Runnable) hit[1]).run();
                            } catch (RuntimeException ignored) {
                                // button failed
                            }
                            h.postDelayed(this::safeUpdate, 300);
                            invalidate();
                            return true;
                        }
                    }
                    collapse();
                    return true;
                }
                default:
                    return true;
            }
        }

        private final Runnable holdEdit = () -> {
            downAt = -1;
            startEdit();
        };

        /** Drag mode: move the pill anywhere. Tap DONE on the right to keep it there, the gear on the left to customise. */
        private boolean editTouch(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragRawX = e.getRawX();
                    dragRawY = e.getRawY();
                    dragCx = lp.x + curW / 2f;
                    dragTop = lp.y;
                    downX = e.getX();
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - dragRawX;
                    float dy = e.getRawY() - dragRawY;
                    if (Math.hypot(dx, dy) > 8 * d) {
                        dragged = true;
                    }
                    if (dragged) {
                        customCx = Math.max(curW / 2f, Math.min(screenW - curW / 2f, dragCx + dx));
                        customTop = Math.max(0, Math.min(screenH - curH, dragTop + dy));
                        place();
                        invalidate();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!dragged) {
                        if (downX > curW * 0.68f) {
                            stopEdit();
                        } else if (downX < curW * 0.3f) {
                            stopEdit();
                            openNova("island");
                        } else {
                            vibrate();
                            centerIt();
                        }
                    }
                    return true;
                case MotionEvent.ACTION_OUTSIDE:
                    return true;
                default:
                    return true;
            }
        }

        private String mmss(long ms) {
            ms = Math.max(0, ms);
            long s = (ms + 999) / 1000;
            return s >= 3600 ? String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                    : String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
        }

        private long focusRemaining() {
            long now = System.currentTimeMillis();
            return focusEnd > now ? focusEnd - now : focusLeft;
        }

        private int busMinutes() {
            if (deps == null) {
                return -1;
            }
            long now = System.currentTimeMillis();
            for (BusData.Dep dep : deps) {
                if (dep.at > now - 20000) {
                    return (int) Math.max(0, (dep.at - now) / 60000);
                }
            }
            return -1;
        }

        private void text(Canvas c, String s, float x, float y, float sp, int color, int alpha, boolean bold,
                Paint.Align al, float maxW) {
            if (s == null) {
                return;
            }
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            String fam = new String[] {"sans-serif", "monospace", "serif", "sans-serif-condensed"}[Math.max(0, Math.min(3, opt("font", 0)))];
            p.setTypeface(Typeface.create(fam, bold ? Typeface.BOLD : Typeface.NORMAL));
            p.setTextSize(sp * d);
            p.setTextAlign(al);
            if (c == null) {
                return;
            }
            p.setColor(color);
            p.setAlpha(Math.round(((color >>> 24) & 0xFF) * alpha / 255f));
            if (maxW > 0) {
                int n = p.breakText(s, true, maxW, null);
                if (n < s.length()) {
                    s = s.substring(0, Math.max(1, n - 1)) + "…";
                }
            }
            c.drawText(s, x, y, p);
        }

        private void dot(Canvas c, float x, float y, float rr, int color, int alpha) {
            if (c == null) {
                return;
            }
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(Math.round(((color >>> 24) & 0xFF) * alpha / 255f));
            c.drawCircle(x, y, rr, p);
        }

        private void box(Canvas c, RectF r, float rad, int color, int alpha) {
            if (c == null) {
                return;
            }
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setAlpha(Math.round(((color >>> 24) & 0xFF) * alpha / 255f));
            c.drawRoundRect(r, rad, rad, p);
        }

        private void art(Canvas c, float cx, float cy, float rr, int alpha) {
            if (c == null) {
                return;
            }
            if (art == null) {
                box(c, new RectF(cx - rr, cy - rr, cx + rr, cy + rr), rr * 0.3f, 0xFF2C2C2E, alpha);
                text(c, "♪", cx, cy + rr * 0.4f, rr / d * 1.1f, GREEN, alpha, true, Paint.Align.CENTER, 0);
                return;
            }
            Matrix m = new Matrix();
            float s = rr * 2 / art.getWidth();
            m.setScale(s, s);
            m.postTranslate(cx - rr, cy - rr);
            BitmapShader sh = new BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            sh.setLocalMatrix(m);
            p.setShader(sh);
            p.setAlpha(alpha);
            c.drawRoundRect(new RectF(cx - rr, cy - rr, cx + rr, cy + rr), rr * 0.3f, rr * 0.3f, p);
            p.setShader(null);
        }

        private void icon(Canvas c, Drawable dr, float cx, float cy, float rr, int alpha) {
            if (c == null || dr == null) {
                return;
            }
            Rect old = dr.copyBounds();
            dr.setBounds(Math.round(cx - rr), Math.round(cy - rr), Math.round(cx + rr), Math.round(cy + rr));
            dr.setAlpha(alpha);
            dr.draw(c);
            dr.setBounds(old);
        }

        private void bars(Canvas c, float right, float cy, float hgt, int color, int alpha, boolean moving) {
            if (c == null) {
                return;
            }
            float t = SystemClock.uptimeMillis() / 1000f;
            float bw = 2.6f * d;
            for (int i = 0; i < 4; i++) {
                float v = moving ? 0.35f + 0.65f * Math.abs((float) Math.sin(t * (5.1f + i * 1.3f) + i)) : 0.3f;
                float bh = hgt * v;
                float x = right - (4 - i) * (bw + 2.2f * d);
                box(c, new RectF(x, cy - bh / 2, x + bw, cy + bh / 2), bw / 2, color, alpha);
            }
            if (moving) {
                postInvalidateDelayed(70);
            }
        }

        private void ring(Canvas c, float cx, float cy, float rr, float v, int color, int alpha) {
            if (c == null) {
                return;
            }
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(rr * 0.3f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0x44FFFFFF);
            p.setAlpha(Math.round(0x44 * alpha / 255f));
            c.drawCircle(cx, cy, rr * 0.82f, p);
            p.setColor(color);
            p.setAlpha(alpha);
            c.drawArc(new RectF(cx - rr * 0.82f, cy - rr * 0.82f, cx + rr * 0.82f, cy + rr * 0.82f), -90,
                    360 * Math.max(0.01f, Math.min(1f, v)), false, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void batt(Canvas c, float x, float cy, float w, int level, int color, int alpha) {
            if (c == null) {
                return;
            }
            float bh = w * 0.5f;
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.3f * d);
            p.setColor(0x99FFFFFF);
            p.setAlpha(Math.round(0x99 * alpha / 255f));
            RectF b = new RectF(x, cy - bh / 2, x + w, cy + bh / 2);
            c.drawRoundRect(b, 3 * d, 3 * d, p);
            p.setStyle(Paint.Style.FILL);
            c.drawRect(b.right + 0.8f * d, cy - bh * 0.2f, b.right + 2.2f * d, cy + bh * 0.2f, p);
            if (level >= 0) {
                p.setColor(color);
                p.setAlpha(alpha);
                float fill = (w - 3.4f * d) * Math.max(0.06f, Math.min(1f, level / 100f));
                c.drawRoundRect(new RectF(b.left + 1.7f * d, b.top + 1.7f * d, b.left + 1.7f * d + fill, b.bottom - 1.7f * d),
                        1.5f * d, 1.5f * d, p);
            }
        }

        private int battColor(int level, boolean chg) {
            if (opt("bcol", 0) == 1) {
                return textCol();
            }
            return chg ? GREEN : level <= lowAt() ? RED : level <= 30 ? ORANGE : textCol();
        }

        private void hit(RectF r, Runnable act) {
            hits.add(new Object[] {r, act});
        }

        private void pill(Canvas c, String label, float x, float y, float w, float hgt, int bg, int fg, int alpha, Runnable act) {
            RectF rr = new RectF(x, y, x + w, y + hgt);
            box(c, rr, hgt / 2, bg, alpha);
            text(c, label, rr.centerX(), rr.centerY() + 4.3f * d, 12f, fg, alpha, true, Paint.Align.CENTER, w - 8 * d);
            if (c != null) {
                hit(new RectF(rr.left, rr.top - 4 * d, rr.right, rr.bottom + 4 * d), act);
            }
        }

        private void round(Canvas c, String glyph, String label, float cx, float cy, float rr, int bg, int fg, int alpha,
                Runnable act) {
            dot(c, cx, cy, rr, bg, alpha);
            text(c, glyph, cx, cy + rr * 0.36f, rr / d * 0.95f, fg, alpha, true, Paint.Align.CENTER, 0);
            if (label != null) {
                text(c, label, cx, cy + rr + 14 * d, 10f, GREY, alpha, false, Paint.Align.CENTER, rr * 2.6f);
            }
            if (c != null) {
                hit(new RectF(cx - rr - 6 * d, cy - rr - 6 * d, cx + rr + 6 * d, cy + rr + 18 * d), act);
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            try {
                float w = getWidth();
                float hh = getHeight();
                boolean big = hh > compactH() * 1.6f;
                int corner = opt("corner", 0);
                float rad = corner == 2 ? 8 * d : corner == 1 ? (big ? 22 * d : hh * 0.3f) : (big ? 34 * d : hh / 2f);
                if (!big && !editing && idleNow && opt("idle", 0) == 2) {
                    hits.clear();
                    return;
                }
                box(c, new RectF(0, 0, w, hh), rad, bgCol(), 255);
                int ol = opt("outline", access ? 0 : 1);
                if (ol > 0) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth((ol == 1 ? 1f : 1.6f) * d);
                    p.setColor(ol == 1 ? 0x33FFFFFF : ol == 2 ? Theme.ACCENT : 0xFFFFFFFF);
                    c.drawRoundRect(new RectF(0.8f * d, 0.8f * d, w - 0.8f * d, hh - 0.8f * d), rad, rad, p);
                    p.setStyle(Paint.Style.FILL);
                }
                hits.clear();
                if (editing) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(2f * d);
                    p.setColor(YELLOW);
                    c.drawRoundRect(new RectF(d, d, w - d, hh - d), rad, rad, p);
                    p.setStyle(Paint.Style.FILL);
                    float base = hh / 2f + 4.5f * d;
                    text(c, "\u2699", hh / 2f, base + d, 15f, 0xFFFFFFFF, 255, true, Paint.Align.LEFT, 0);
                    text(c, w > 200 * d ? "drag \u00B7 tap = center" : "drag", w / 2f, base, 12.5f, GREY, 255, true, Paint.Align.CENTER, 0);
                    box(c, new RectF(w - hh / 2f - 58 * d, hh / 2f - 12 * d, w - hh / 2f + 4 * d, hh / 2f + 12 * d), 12 * d,
                            YELLOW, 255);
                    text(c, "DONE", w - hh / 2f - 27 * d, base, 12f, 0xFF000000, 255, true, Paint.Align.CENTER, 0);
                    return;
                }
                if (contentAlpha <= 0.01f) {
                    return;
                }
                int alpha = Math.round(255 * contentAlpha);
                if (big && expanded) {
                    c.save();
                    c.clipRect(0, 0, w, hh);
                    dash(c, w);
                    c.restore();
                } else if (!big) {
                    drawCompact(c, w, hh, alpha);
                }
            } catch (RuntimeException ignored) {
                // a bad frame is better than a crashed service
            }
        }

        private void drawCompact(Canvas c, float w, float hh, int alpha) {
            float cy = hh / 2f;
            float pad = hh / 2f;
            float camLeft;
            float camRight;
            if (camInPill()) {
                camLeft = (camX - lp.x) - camR - 12 * d;
                camRight = (camX - lp.x) + camR + 12 * d;
            } else {
                camLeft = w / 2f - 4 * d;
                camRight = w / 2f + 4 * d;
            }
            float ir = hh * 0.31f;
            float sp = Math.min(13.5f, hh / d * 0.4f) * new float[] {0.85f, 1f, 1.18f}[Math.max(0, Math.min(2, opt("tsize", 1)))];
            float base = cy + sp * d * 0.36f;
            long now = System.currentTimeMillis();
            Act a = null;
            for (Act x : acts) {
                if (showsInPill(x.kind)) {
                    a = x;
                    break;
                }
            }
            float lx = pad;
            float ix = lx + ir - 4 * d;
            String leftText = null;
            int leftColor = textCol();
            if (dotted && !editing) {
                dot(c, w / 2f, cy, hh * 0.18f, Theme.ACCENT, alpha);
                return;
            }
            if (a == null && !show("clock")) {
                leftText = null;
            } else if (a == null) {
                if (opt("idle", 0) == 1 && !editing) {
                    dot(c, w / 2f, cy, hh * 0.18f, Theme.ACCENT, alpha);
                    return;
                }
                Calendar cal = Calendar.getInstance();
                boolean secs = opt("secs", 0) == 1;
                String tp = opt("h12", 0) == 1 ? (secs ? "h:mm:ss a" : "h:mm a") : (secs ? "HH:mm:ss" : "HH:mm");
                int df = opt("date", 0);
                leftText = new java.text.SimpleDateFormat(tp, Locale.getDefault()).format(cal.getTime())
                        + (df == 2 ? "" : "  " + new java.text.SimpleDateFormat(df == 1 ? "dd.MM" : "EEE d", Locale.getDefault())
                        .format(cal.getTime()));
                text(c, leftText, lx - 2 * d, base, sp, opt("tcol", 0) == 0 ? GREY : textCol(),
                        alpha, true, Paint.Align.LEFT, camLeft - lx);
                if (secs) {
                    postInvalidateDelayed(1000);
                }
            } else {
                switch (a.kind) {
                    case Act.MUSIC:
                        art(c, ix, cy, ir, alpha);
                        leftText = MusicHelper.title(music);
                        break;
                    case Act.TIMER:
                        dot(c, ix, cy, ir, ORANGE, alpha);
                        leftText = mmss(timerEnd - now);
                        leftColor = ORANGE;
                        break;
                    case Act.FOCUS: {
                        long len = (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                        long left = focusRemaining();
                        ring(c, ix, cy, ir, 1f - left / (float) len, a.color, alpha);
                        leftText = mmss(left) + (focusEnd > now ? "" : " ‖");
                        leftColor = a.color;
                        break;
                    }
                    case Act.BUS: {
                        dot(c, ix, cy, ir, YELLOW, alpha);
                        text(c, deps.get(0).line, ix, cy + sp * d * 0.3f, sp * 0.72f, 0xFF000000, alpha, true, Paint.Align.CENTER, 0);
                        int m = busMinutes();
                        leftText = m < 0 ? "…" : m == 0 ? "now" : "in " + m + "'";
                        leftColor = YELLOW;
                        break;
                    }
                    case Act.LEAVE:
                        dot(c, ix, cy, ir, YELLOW, alpha);
                        leftText = "leave in " + (Life.leaveMin() - Life.nowMin()) + "'";
                        leftColor = YELLOW;
                        break;
                    case Act.CHARGE:
                    case Act.LOW:
                        batt(c, lx - 2 * d, cy, ir * 2, battery, a.color, alpha);
                        leftText = a.kind == Act.CHARGE ? (charging ? "charging" : "unplugged") : "low battery";
                        leftColor = a.color;
                        break;
                    case Act.NOTE:
                        if (noteIcon != null) {
                            icon(c, noteIcon, ix, cy, ir, alpha);
                        } else {
                            dot(c, ix, cy, ir, BLUE, alpha);
                        }
                        int nm = opt("msg", 0);
                        leftText = note == null || nm == 2 ? "" : nm == 1 ? note.app : note.title;
                        break;
                    default:
                        break;
                }
                float tx = lx + ir * 2 + 2 * d;
                text(c, leftText, tx, base, sp, leftColor, alpha, true, Paint.Align.LEFT, camLeft - tx);
            }
            // right: phone battery, then headphones, then music bars
            float rx = w - pad + 2 * d;
            if (show("batt")) {
                int lvl = battery;
                int bc = battColor(lvl, charging);
                int bst = opt("batt", 0);
                if (bst != 1) {
                    batt(c, rx - 22 * d, cy, 20 * d, lvl, bc, alpha);
                    rx -= 26 * d;
                }
                if (bst != 2) {
                    String bs = lvl + (bst == 1 ? "%" : "") + (charging ? "⚡" : "");
                    text(c, bs, rx, base, sp * 0.95f, bc, alpha, true, Paint.Align.RIGHT, 0);
                    rx -= p.measureText(bs);
                }
                rx -= 10 * d;
            }
            for (Object[] b : (show("bt") ? bt : new ArrayList<Object[]>())) {
                int bl = (int) b[1];
                if (bl < 0) {
                    continue;
                }
                String s = ((boolean) b[2] ? "🎧" : "⌚") + bl;
                text(c, s, 0, 0, sp * 0.95f, 0, 0, true, Paint.Align.RIGHT, 0);
                if (rx - p.measureText(s) < camRight) {
                    break;
                }
                text(c, s, rx, base, sp * 0.95f, battColor(bl, false), alpha, true, Paint.Align.RIGHT, 0);
                rx -= p.measureText(s) + 10 * d;
            }
            if (a != null && a.kind == Act.MUSIC && rx - 20 * d > camRight) {
                int bcI = opt("bars", 0);
                bars(c, rx, cy, hh * 0.42f, bcI == 1 ? Theme.ACCENT : bcI == 2 ? 0xFFFFFFFF : GREEN, alpha, MusicHelper.isPlaying(music));
            }
        }

        private boolean showsInPill(int kind) {
            switch (kind) {
                case Act.MUSIC:
                    return show("music");
                case Act.TIMER:
                    return show("timer");
                case Act.FOCUS:
                    return show("focus");
                case Act.BUS:
                case Act.LEAVE:
                    return show("bus");
                case Act.CHARGE:
                case Act.LOW:
                    return show("charge");
                default:
                    return true;
            }
        }

        /** The big dashboard. With c == null it only measures and returns the height. */
        private float dash(Canvas c, float w) {
            int alpha = Math.round(255 * contentAlpha);
            float pad = 18 * d;
            float y = Math.max(16 * d, (camY - barTop) + camR + 10 * d);
            long now = System.currentTimeMillis();
            Calendar cal = Calendar.getInstance();
            String time = String.format(Locale.ROOT, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
            text(c, time, pad, y + 30 * d, 32f, 0xFFFFFFFF, alpha, false, Paint.Align.LEFT, 0);
            text(c, new java.text.SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(cal.getTime()), pad, y + 50 * d,
                    12f, GREY, alpha, false, Paint.Align.LEFT, 0);
            float bx = w - pad;
            float by = y + 14 * d;
            batt(c, bx - 30 * d, by, 26 * d, battery, battColor(battery, charging), alpha);
            text(c, battery + "%" + (charging ? " ⚡" : ""), bx - 36 * d, by + 5 * d, 14f, battColor(battery, charging), alpha,
                    true, Paint.Align.RIGHT, 0);
            text(c, "phone", bx - 36 * d, by + 20 * d, 10f, GREY, alpha, false, Paint.Align.RIGHT, 0);
            y += 64 * d;
            for (Object[] b : (show("d_bt") ? bt : new ArrayList<Object[]>())) {
                int bl = (int) b[1];
                text(c, ((boolean) b[2] ? "🎧  " : "⌚  ") + b[0], pad, y + 14 * d, 13f, 0xFFFFFFFF, alpha, false,
                        Paint.Align.LEFT, w * 0.55f);
                if (bl >= 0) {
                    batt(c, w - pad - 30 * d, y + 9 * d, 26 * d, bl, battColor(bl, false), alpha);
                    text(c, bl + "%", w - pad - 36 * d, y + 14 * d, 13f, battColor(bl, false), alpha, true, Paint.Align.RIGHT, 0);
                } else {
                    text(c, "connected", w - pad, y + 14 * d, 11f, GREY, alpha, false, Paint.Align.RIGHT, 0);
                }
                y += 24 * d;
            }
            if (!show("d_bt")) {
                y += 0;
            } else if (bt.isEmpty() && Build.VERSION.SDK_INT >= 31 && getContext().checkSelfPermission(
                    android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                RectF r = new RectF(pad - 6 * d, y, w - pad + 6 * d, y + 22 * d);
                text(c, "🎧  tap to allow headphone battery", pad, y + 15 * d, 12f, BLUE, alpha, false, Paint.Align.LEFT,
                        w - 2 * pad);
                if (c != null) {
                    hit(r, () -> openNova("bt"));
                }
                y += 26 * d;
            } else if (bt.isEmpty()) {
                text(c, "🎧  no headphones connected", pad, y + 15 * d, 12f, GREY, alpha, false, Paint.Align.LEFT, 0);
                y += 26 * d;
            }
            y += 8 * d;
            if (focusKind >= 0) {
                y = card(c, w, pad, y, alpha, now);
                if (acts.size() > 1) {
                    float x = pad;
                    for (final Act a : acts) {
                        if (a.kind == focusKind) {
                            continue;
                        }
                        String name = a.kind == Act.MUSIC ? "music" : a.kind == Act.TIMER ? "timer" : a.kind == Act.FOCUS ? "focus"
                                : a.kind == Act.BUS || a.kind == Act.LEAVE ? "bus" : a.kind == Act.NOTE ? "message" : "battery";
                        float cw = 76 * d;
                        if (x + cw > w - pad) {
                            break;
                        }
                        RectF r = new RectF(x, y, x + cw, y + 26 * d);
                        box(c, r, 13 * d, CARD, alpha);
                        dot(c, x + 13 * d, y + 13 * d, 4 * d, a.color, alpha);
                        text(c, name, x + 22 * d, y + 17 * d, 11f, 0xFFFFFFFF, alpha, false, Paint.Align.LEFT, cw - 26 * d);
                        if (c != null) {
                            hit(r, () -> focusKind = a.kind);
                        }
                        x += cw + 6 * d;
                    }
                    y += 34 * d;
                }
            }
            List<String[]> rows = new ArrayList<>();
            try {
                int m = busMinutes();
                if (show("d_bus") && m >= 0 && deps != null && !deps.isEmpty() && focusKind != Act.BUS) {
                    rows.add(new String[] {"🚌", "Bus " + deps.get(0).line + " in " + m + "'", "#FFC21A"});
                }
                int mood = MoodLog.current();
                if (show("d_mood")) rows.add(new String[] {mood >= 0 ? MoodLog.FACES[mood] : "😶",
                    mood >= 0 ? "Mood: " + MoodLog.NAMES[mood] : "No mood yet today", "#FFFFFF"});
                long leftCents = Math.round(MoneyWidget.budget() * 100);
                boolean money = show("d_money");
                long start = MoneyWidget.weekStart();
                for (Object[] o : MoneyWidget.entries()) {
                    if ((long) o[0] >= start) {
                        leftCents += (long) o[1];
                    }
                }
                if (money) rows.add(new String[] {"💸", MoneyWidget.chf(leftCents) + " left this week",
                    leftCents < 0 ? "#FF453A" : "#34C759"});
                for (String[] f : (show("d_hw") ? Life.homework() : new ArrayList<String[]>())) {
                    if (!"1".equals(f[1])) {
                        rows.add(new String[] {"📚", f[2] + "  ·  " + Life.nice(f[0]), "#FF9F0A"});
                        break;
                    }
                }
            } catch (RuntimeException ignored) {
                // skip the day rows
            }
            for (String[] row : rows) {
                text(c, row[0], pad + 10 * d, y + 15 * d, 14f, 0xFFFFFFFF, alpha, false, Paint.Align.CENTER, 0);
                text(c, row[1], pad + 30 * d, y + 15 * d, 13f, android.graphics.Color.parseColor(row[2]), alpha, false,
                        Paint.Align.LEFT, w - 2 * pad - 30 * d);
                y += 23 * d;
            }
            y += 14 * d;
            float rr = Math.min(21 * d, (w - 2 * pad) / 6f * 0.4f);
            boolean playing = music != null && MusicHelper.isPlaying(music);
            String[] g0 = {"🔦", "📷", playing ? "⏸" : "▶", "🚌", "N", "\u270E"};
            String[] l0 = {torch ? "torch on" : "torch", "camera", "music", "bus", "NOVA", "edit"};
            String[] k0 = {"b_torch", "b_camera", "b_music", "b_bus", "b_nova", ""};
            Runnable[] a0 = {this::toggleTorch, () -> launch(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
                () -> MusicHelper.toggle(getContext()), () -> openNova("bus"), () -> openNova(null), this::startEdit};
            List<Integer> on0 = new ArrayList<>();
            for (int i = 0; i < g0.length; i++) {
                if (k0[i].isEmpty() || show(k0[i])) {
                    on0.add(i);
                }
            }
            String[] g = new String[on0.size()];
            String[] l = new String[on0.size()];
            Runnable[] act = new Runnable[on0.size()];
            for (int i = 0; i < g.length; i++) {
                g[i] = g0[on0.get(i)];
                l[i] = l0[on0.get(i)];
                act[i] = a0[on0.get(i)];
            }
            float step = (w - 2 * pad) / g.length;
            for (int i = 0; i < g.length; i++) {
                boolean on = on0.get(i) == 0 && torch;
                round(c, g[i], l[i], pad + step * (i + 0.5f), y + rr, rr, on ? 0xFFFFFFFF : CARD, on ? 0xFF000000 : 0xFFFFFFFF,
                        alpha, act[i]);
            }
            y += rr * 2 + 28 * d;
            return Math.min(y, screenH * 0.8f);
        }

        private float card(Canvas c, float w, float pad, float y, int alpha, long now) {
            float x0 = pad - 6 * d;
            float cw = w - 2 * pad + 12 * d;
            switch (focusKind) {
                case Act.MUSIC: {
                    float h0 = 150 * d;
                    box(c, new RectF(x0, y, x0 + cw, y + h0), 22 * d, CARD, alpha);
                    float s = 52 * d;
                    art(c, pad + 6 * d + s / 2, y + 14 * d + s / 2, s / 2, alpha);
                    float tx = pad + s + 18 * d;
                    text(c, music == null ? "" : MusicHelper.title(music), tx, y + 34 * d, 15f, 0xFFFFFFFF, alpha, true,
                            Paint.Align.LEFT, w - tx - pad - 36 * d);
                    text(c, music == null ? "" : MusicHelper.artist(music), tx, y + 54 * d, 12f, GREY, alpha, false,
                            Paint.Align.LEFT, w - tx - pad - 36 * d);
                    boolean playing = music != null && MusicHelper.isPlaying(music);
                    bars(c, w - pad, y + 30 * d, 16 * d, GREEN, alpha, playing);
                    long pos = 0;
                    long dur = 0;
                    if (music != null) {
                        PlaybackState ps = music.getPlaybackState();
                        MediaMetadata md = music.getMetadata();
                        dur = md == null ? 0 : md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                        if (ps != null) {
                            pos = ps.getPosition();
                            if (ps.getState() == PlaybackState.STATE_PLAYING) {
                                pos += (long) ((SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) * ps.getPlaybackSpeed());
                            }
                        }
                    }
                    float by = y + 80 * d;
                    box(c, new RectF(pad + 6 * d, by, w - pad - 6 * d, by + 4 * d), 2 * d, 0x33FFFFFF, alpha);
                    if (dur > 0) {
                        float f = Math.max(0, Math.min(1, pos / (float) dur));
                        box(c, new RectF(pad + 6 * d, by, pad + 6 * d + (w - 2 * pad - 12 * d) * f, by + 4 * d), 2 * d, 0xFFFFFFFF,
                                alpha);
                        text(c, mmss(pos), pad + 6 * d, by + 17 * d, 10f, GREY, alpha, false, Paint.Align.LEFT, 0);
                        text(c, "-" + mmss(dur - pos), w - pad - 6 * d, by + 17 * d, 10f, GREY, alpha, false, Paint.Align.RIGHT, 0);
                    }
                    float cy = y + 124 * d;
                    round(c, "⏮", null, w / 2 - 64 * d, cy, 17 * d, 0xFF2C2C2E, 0xFFFFFFFF, alpha,
                            () -> MusicHelper.previous(getContext()));
                    round(c, playing ? "⏸" : "▶", null, w / 2, cy, 20 * d, 0xFFFFFFFF, 0xFF000000, alpha,
                            () -> MusicHelper.toggle(getContext()));
                    round(c, "⏭", null, w / 2 + 64 * d, cy, 17 * d, 0xFF2C2C2E, 0xFFFFFFFF, alpha,
                            () -> MusicHelper.next(getContext()));
                    if (c != null && playing) {
                        postInvalidateDelayed(500);
                    }
                    return y + h0 + 10 * d;
                }
                case Act.TIMER: {
                    float h0 = 76 * d;
                    box(c, new RectF(x0, y, x0 + cw, y + h0), 22 * d, CARD, alpha);
                    text(c, "TIMER", pad + 6 * d, y + 22 * d, 11f, ORANGE, alpha, true, Paint.Align.LEFT, 0);
                    text(c, mmss(timerEnd - now), pad + 6 * d, y + 60 * d, 34f, ORANGE, alpha, false, Paint.Align.LEFT, 0);
                    if (c != null) {
                        postInvalidateDelayed(500);
                    }
                    return y + h0 + 10 * d;
                }
                case Act.FOCUS: {
                    float h0 = 86 * d;
                    box(c, new RectF(x0, y, x0 + cw, y + h0), 22 * d, CARD, alpha);
                    long left = focusRemaining();
                    long len = (focusWork ? Prefs.getInt("focus_len", 25) : 5) * 60000L;
                    int col = focusWork ? PINK : GREEN;
                    ring(c, pad + 34 * d, y + h0 / 2, 28 * d, 1f - left / (float) len, col, alpha);
                    text(c, focusWork ? "FOCUS" : "BREAK", pad + 74 * d, y + 30 * d, 11f, col, alpha, true, Paint.Align.LEFT, 0);
                    text(c, mmss(left), pad + 74 * d, y + 64 * d, 30f, 0xFFFFFFFF, alpha, false, Paint.Align.LEFT, 0);
                    final boolean running = focusEnd > now;
                    pill(c, running ? "PAUSE" : "GO ON", w - pad - 92 * d, y + h0 / 2 - 17 * d, 92 * d, 34 * d, col, 0xFF000000,
                            alpha, () -> toggleFocus(running));
                    if (c != null) {
                        postInvalidateDelayed(500);
                    }
                    return y + h0 + 10 * d;
                }
                case Act.BUS:
                case Act.LEAVE: {
                    float h0 = 128 * d;
                    box(c, new RectF(x0, y, x0 + cw, y + h0), 18 * d, 0xFF0B0B0B, alpha);
                    text(c, busStop.isEmpty() ? "next bus" : busStop, pad + 6 * d, y + 22 * d, 12f, YELLOW, alpha, true,
                            Paint.Align.LEFT, w - 2 * pad - 90 * d);
                    int left = Life.leaveMin() - Life.nowMin();
                    text(c, left > 0 && left < 120 ? "leave in " + left + "'" : "", w - pad - 6 * d, y + 22 * d, 12f,
                            left <= 3 ? RED : YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                    if (deps == null || deps.isEmpty()) {
                        text(c, busBusy ? "loading…" : "no departures", pad + 6 * d, y + 60 * d, 14f, YELLOW, alpha, false,
                                Paint.Align.LEFT, 0);
                    } else {
                        int row = 0;
                        for (BusData.Dep dep : deps) {
                            if (dep.at < now - 20000) {
                                continue;
                            }
                            float yy = y + 54 * d + row * 26 * d;
                            long mm = Math.max(0, (dep.at - now) / 60000);
                            text(c, dep.line, pad + 34 * d, yy, 16f, YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                            text(c, dep.to, pad + 44 * d, yy, 15f, YELLOW, alpha, false, Paint.Align.LEFT, w - 2 * pad - 100 * d);
                            text(c, mm + "'", w - pad - 6 * d, yy, 16f, YELLOW, alpha, true, Paint.Align.RIGHT, 0);
                            if (++row >= 3) {
                                break;
                            }
                        }
                    }
                    return y + h0 + 10 * d;
                }
                case Act.CHARGE:
                case Act.LOW: {
                    float h0 = 60 * d;
                    int col = focusKind == Act.LOW ? RED : GREEN;
                    box(c, new RectF(x0, y, x0 + cw, y + h0), 22 * d, CARD, alpha);
                    batt(c, pad + 6 * d, y + h0 / 2, 40 * d, battery, col, alpha);
                    text(c, battery + "%  " + (charging ? "charging" : focusKind == Act.LOW ? "low battery" : "unplugged"),
                            pad + 60 * d, y + h0 / 2 + 6 * d, 16f, col, alpha, true, Paint.Align.LEFT, 0);
                    return y + h0 + 10 * d;
                }
                case Act.NOTE: {
                    if (note == null) {
                        return y;
                    }
                    float h0 = 78 * d;
                    RectF r = new RectF(x0, y, x0 + cw, y + h0);
                    box(c, r, 22 * d, CARD, alpha);
                    icon(c, noteIcon, pad + 22 * d, y + 26 * d, 16 * d, alpha);
                    text(c, note.app, pad + 46 * d, y + 20 * d, 11f, GREY, alpha, false, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    text(c, note.title, pad + 46 * d, y + 40 * d, 14f, 0xFFFFFFFF, alpha, true, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    text(c, note.text, pad + 46 * d, y + 60 * d, 12f, 0xFFD1D1D6, alpha, false, Paint.Align.LEFT, w - 2 * pad - 50 * d);
                    if (c != null) {
                        final NovaNotificationService.Item it = note;
                        hit(r, () -> {
                            try {
                                if (it.open != null) {
                                    it.open.send();
                                }
                            } catch (Exception ignored) {
                                // gone
                            }
                            note = null;
                            collapse();
                        });
                    }
                    return y + h0 + 10 * d;
                }
                default:
                    return y;
            }
        }
    }
}
