package app.novaos;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * NOVA WRAPPED: your month as stories, like Spotify Wrapped but for your phone. Screen time and top apps, your
 * mood, money (and kebabs), songs, focus, workouts, journal and bus rides, with a word for your month at the
 * end. Tap right for the next card, left for the last one, hold to pause, and share any card as a picture.
 */
final class Wrapped extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final Calendar month;
    private final Story story;
    private final List<Card> cards = new ArrayList<>();
    private final Handler h = new Handler(Looper.getMainLooper());

    /** One story card: background colours, a small title, a big line and some rows. */
    static final class Card {
        int c1;
        int c2;
        String kicker = "";
        String big = "";
        String sub = "";
        final List<String[]> rows = new ArrayList<>(); // {left, right, bar 0..1 or ""}
        int[] dots; // mood colours per day, 0 = no data
        String emoji = "";
    }

    /** Opens the stories for this month (offset 0) or the month before (-1). */
    static void open(NovaActivity host, int offset) {
        host.showOverlay(new Wrapped(host, offset));
    }

    /** In the first three days of a month, once: says last month's Wrapped is ready. */
    static void maybePrompt(NovaActivity host) {
        Calendar c = Calendar.getInstance();
        if (c.get(Calendar.DAY_OF_MONTH) > 3) {
            return;
        }
        c.add(Calendar.MONTH, -1);
        String key = new SimpleDateFormat("yyyyMM", Locale.ROOT).format(c.getTime());
        if (key.equals(Prefs.getString("wrap_told", ""))) {
            return;
        }
        Prefs.putString("wrap_told", key);
        String name = new SimpleDateFormat("MMMM", Locale.getDefault()).format(c.getTime());
        new android.app.AlertDialog.Builder(host).setTitle("Your " + name + " Wrapped is ready 🎁")
                .setMessage("See your month on NOVA: top apps, mood, money, songs and more.")
                .setPositiveButton("SHOW ME", (dd, w) -> open(host, -1))
                .setNegativeButton("LATER", null).show();
    }

    /** Counts an app opening for this month (called whenever NOVA opens an app). */
    static void countOpen(String pkg) {
        String key = "wrap_open_" + new SimpleDateFormat("yyyyMM", Locale.ROOT).format(new java.util.Date());
        Map<String, Integer> m = parseCounts(Prefs.getString(key, ""));
        m.put(pkg, (m.containsKey(pkg) ? m.get(pkg) : 0) + 1);
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String, Integer> en : m.entrySet()) {
            b.append(en.getKey()).append('=').append(en.getValue()).append(';');
        }
        Prefs.putString(key, b.toString());
    }

    private static Map<String, Integer> parseCounts(String s) {
        Map<String, Integer> m = new HashMap<>();
        for (String p : s.split(";")) {
            int eq = p.lastIndexOf('=');
            if (eq > 0) {
                try {
                    m.put(p.substring(0, eq), Integer.parseInt(p.substring(eq + 1)));
                } catch (NumberFormatException ignored) {
                    // broken
                }
            }
        }
        return m;
    }

    Wrapped(NovaActivity host, int offset) {
        super(host);
        this.host = host;
        month = Calendar.getInstance();
        month.add(Calendar.MONTH, offset);
        setBackgroundColor(0xFF000000);
        setClickable(true);
        story = new Story(host);
        addView(story, new LayoutParams(-1, -1));
        TextView x = label("✕", 20f);
        x.setOnClickListener(v -> host.hideOverlay());
        LayoutParams xp = new LayoutParams(Theme.dp(host, 48), Theme.dp(host, 48), Gravity.TOP | Gravity.END);
        xp.topMargin = Theme.dp(host, 52);
        xp.rightMargin = Theme.dp(host, 8);
        addView(x, xp);
        TextView share = label("SHARE ↗", 13f);
        share.setBackground(Theme.rounded(0x33FFFFFF, 22f, host));
        share.setPadding(Theme.dp(host, 22), Theme.dp(host, 12), Theme.dp(host, 22), Theme.dp(host, 12));
        share.setOnClickListener(v -> share());
        LayoutParams sp = new LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = Theme.dp(host, 40);
        addView(share, sp);
        Card loading = new Card();
        loading.c1 = 0xFF6A11CB;
        loading.c2 = 0xFF2575FC;
        loading.kicker = "NOVA WRAPPED";
        loading.big = "Wrapping up…";
        cards.add(loading);
        new Thread(() -> {
            final List<Card> built = build(host, month);
            h.post(() -> {
                cards.clear();
                cards.addAll(built);
                story.restart();
            });
        }).start();
    }

    private TextView label(String s, float sp) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    // ------------------------------------------------------------------ gathering the month

    static List<Card> build(Context c, Calendar month) {
        List<Card> out = new ArrayList<>();
        Calendar s = (Calendar) month.clone();
        s.set(Calendar.DAY_OF_MONTH, 1);
        s.set(Calendar.HOUR_OF_DAY, 0);
        s.set(Calendar.MINUTE, 0);
        s.set(Calendar.SECOND, 0);
        s.set(Calendar.MILLISECOND, 0);
        long start = s.getTimeInMillis();
        Calendar e = (Calendar) s.clone();
        e.add(Calendar.MONTH, 1);
        long end = Math.min(e.getTimeInMillis(), System.currentTimeMillis());
        String ym = new SimpleDateFormat("yyyyMM", Locale.ROOT).format(s.getTime());
        String monthName = new SimpleDateFormat("MMMM", Locale.getDefault()).format(s.getTime());
        boolean soFar = e.getTimeInMillis() > System.currentTimeMillis();
        int days = s.getActualMaximum(Calendar.DAY_OF_MONTH);

        // 1. intro
        Card intro = new Card();
        intro.c1 = 0xFF6A11CB;
        intro.c2 = 0xFFFC2575;
        intro.kicker = "NOVA WRAPPED " + s.get(Calendar.YEAR);
        intro.big = "Your " + monthName;
        intro.sub = (soFar ? "so far. " : "") + "Let's see what you did with your phone. Tap to go on →";
        intro.emoji = "🎁";
        out.add(intro);

        // 2. screen time and top apps
        Card apps = new Card();
        apps.c1 = 0xFF0F2027;
        apps.c2 = 0xFF2C5364;
        apps.kicker = "YOUR APPS";
        apps.emoji = "📱";
        List<String[]> top = new ArrayList<>();
        long totalMs = 0;
        if (UsageHelper.hasAccess(c)) {
            try {
                UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
                Map<String, UsageStats> agg = usm.queryAndAggregateUsageStats(start, end);
                List<UsageStats> list = new ArrayList<>(agg.values());
                list.sort((a, b) -> Long.compare(b.getTotalTimeInForeground(), a.getTotalTimeInForeground()));
                long max = 0;
                for (UsageStats u : list) {
                    if (u.getPackageName().equals(c.getPackageName()) || u.getTotalTimeInForeground() < 60000) {
                        continue;
                    }
                    totalMs += u.getTotalTimeInForeground();
                    if (top.size() < 5) {
                        max = Math.max(max, u.getTotalTimeInForeground());
                        top.add(new String[] {label(c, u.getPackageName()), UsageHelper.duration(u.getTotalTimeInForeground()),
                            String.valueOf(u.getTotalTimeInForeground() / (float) Math.max(1, max))});
                    }
                }
                for (String[] t : top) {
                    // bars relative to the top app
                    t[2] = String.valueOf(Math.min(1f, Float.parseFloat(t[2])));
                }
            } catch (RuntimeException ignored) {
                // no usage data
            }
        }
        if (top.isEmpty()) {
            Map<String, Integer> m = parseCounts(Prefs.getString("wrap_open_" + ym, ""));
            List<String> keys = new ArrayList<>(m.keySet());
            keys.sort((a, b) -> m.get(b) - m.get(a));
            int max = keys.isEmpty() ? 1 : m.get(keys.get(0));
            int sum = 0;
            for (int v : m.values()) {
                sum += v;
            }
            for (int i = 0; i < Math.min(5, keys.size()); i++) {
                top.add(new String[] {label(c, keys.get(i)), m.get(keys.get(i)) + "×",
                    String.valueOf(m.get(keys.get(i)) / (float) max)});
            }
            apps.big = sum + " apps opened";
            apps.sub = sum == 0 ? "Open apps from NOVA and next month this card is full." : "your favourites:";
        } else {
            apps.big = Math.round(totalMs / 3600000f) + " hours";
            apps.sub = "on your phone, about " + UsageHelper.duration(totalMs / Math.max(1, Math.min(days,
                    (int) ((end - start) / 86400000L) + 1))) + " a day. Your top apps:";
        }
        apps.rows.addAll(top);
        out.add(apps);

        // 3. mood
        Card mood = new Card();
        mood.c1 = 0xFFF7971E;
        mood.c2 = 0xFFFFD200;
        mood.kicker = "YOUR MOOD";
        mood.dots = new int[days];
        float sum = 0;
        int n = 0;
        String best = "";
        float bestS = -1;
        Calendar k = (Calendar) s.clone();
        for (int i = 0; i < days; i++) {
            String st = MoodLog.stamp(k);
            float sc = MoodLog.score(st);
            if (sc >= 0) {
                mood.dots[i] = MoodLog.colorOf(sc);
                sum += sc;
                n++;
                if (sc > bestS) {
                    bestS = sc;
                    best = new SimpleDateFormat("EEEE d", Locale.getDefault()).format(k.getTime());
                }
            }
            k.add(Calendar.DAY_OF_MONTH, 1);
        }
        if (n == 0) {
            mood.emoji = "😶";
            mood.big = "No mood yet";
            mood.sub = "Tap the smileys on the MOOD CALENDAR and next month shows how it went.";
        } else {
            float avg = sum / n;
            mood.emoji = MoodLog.FACES[MoodLog.faceOf(avg)];
            mood.big = "A " + MoodLog.NAMES[MoodLog.faceOf(avg)] + " month";
            mood.sub = n + " days rated  ·  best day: " + best;
        }
        out.add(mood);

        // 4. money
        Card money = new Card();
        money.c1 = 0xFF11998E;
        money.c2 = 0xFF38EF7D;
        money.kicker = "YOUR MONEY";
        money.emoji = "💸";
        long spent = 0;
        long got = 0;
        int kebabs = 0;
        long biggest = 0;
        String biggestWhat = "";
        Map<String, Long> cat = new HashMap<>();
        for (Object[] o : MoneyWidget.entries()) {
            long t = (long) o[0];
            long cents = (long) o[1];
            if (t < start || t >= e.getTimeInMillis()) {
                continue;
            }
            String what = ((String) o[2]).toLowerCase(Locale.ROOT);
            if (cents < 0) {
                spent -= cents;
                String cc = MoneyWidget.category(what, cents);
                cat.put(cc, (cat.containsKey(cc) ? cat.get(cc) : 0L) - cents);
                if (-cents > biggest) {
                    biggest = -cents;
                    biggestWhat = (String) o[2];
                }
                if (what.contains("kebab") || what.contains("döner") || what.contains("doner") || what.contains("dürüm")
                        || what.contains("durum")) {
                    kebabs++;
                }
            } else {
                got += cents;
            }
        }
        money.big = MoneyWidget.chf(spent) + " spent";
        if (spent == 0) {
            money.sub = "Nothing tracked. Try POCKET MONEY: type -15 kebab and it counts.";
        } else {
            String topCat = "";
            long topV = 0;
            for (Map.Entry<String, Long> en : cat.entrySet()) {
                if (en.getValue() > topV) {
                    topV = en.getValue();
                    topCat = en.getKey();
                }
            }
            money.sub = "most on " + topCat.toLowerCase(Locale.ROOT) + " (" + MoneyWidget.chf(topV) + ")";
            money.rows.add(new String[] {"got", MoneyWidget.chf(got), ""});
            money.rows.add(new String[] {"biggest", MoneyWidget.chf(biggest) + "  " + biggestWhat, ""});
            if (kebabs > 0) {
                money.rows.add(new String[] {"🥙 kebabs", kebabs + (kebabs >= 4 ? "  (legend)" : ""), ""});
            }
        }
        out.add(money);

        // 5. songs (from the last two weeks the song log keeps)
        Map<String, Integer> songs = new HashMap<>();
        Map<String, Integer> artists = new HashMap<>();
        for (String line : Prefs.getString("songlog_v1", "").split("\n")) {
            String[] f = line.split("\t");
            if (f.length < 3) {
                continue;
            }
            try {
                long t = Long.parseLong(f[0]);
                if (t < start || t >= e.getTimeInMillis()) {
                    continue;
                }
            } catch (NumberFormatException ex) {
                continue;
            }
            String key = f[1] + "  ·  " + f[2];
            songs.put(key, (songs.containsKey(key) ? songs.get(key) : 0) + 1);
            if (!f[2].isEmpty()) {
                artists.put(f[2], (artists.containsKey(f[2]) ? artists.get(f[2]) : 0) + 1);
            }
        }
        if (!songs.isEmpty()) {
            Card sc = new Card();
            sc.c1 = 0xFF1DB954;
            sc.c2 = 0xFF191414;
            sc.kicker = "YOUR SONGS";
            sc.emoji = "🎧";
            String topArtist = "";
            int ta = 0;
            for (Map.Entry<String, Integer> en : artists.entrySet()) {
                if (en.getValue() > ta) {
                    ta = en.getValue();
                    topArtist = en.getKey();
                }
            }
            sc.big = topArtist.isEmpty() ? "On repeat" : topArtist;
            sc.sub = topArtist.isEmpty() ? "" : "your top artist, " + ta + " plays";
            List<String> keys = new ArrayList<>(songs.keySet());
            keys.sort((a, b) -> songs.get(b) - songs.get(a));
            int max = songs.get(keys.get(0));
            for (int i = 0; i < Math.min(5, keys.size()); i++) {
                sc.rows.add(new String[] {keys.get(i), songs.get(keys.get(i)) + "×", String.valueOf(songs.get(keys.get(i)) / (float) max)});
            }
            out.add(sc);
        }

        // 6. getting better: focus, workouts, journal
        Card grow = new Card();
        grow.c1 = 0xFF8E2DE2;
        grow.c2 = 0xFF4A00E0;
        grow.kicker = "GETTING BETTER";
        grow.emoji = "💪";
        int focus = Prefs.getInt("wrap_focus_" + ym, 0);
        int journal = 0;
        int[] work = new int[Life.WORKOUTS.length];
        Calendar j = (Calendar) s.clone();
        for (int i = 0; i < days; i++) {
            String day = Life.day(j);
            if (!Life.journal(day).trim().isEmpty()) {
                journal++;
            }
            for (int w = 0; w < work.length; w++) {
                work[w] += Life.workout(day, w);
            }
            j.add(Calendar.DAY_OF_MONTH, 1);
        }
        grow.big = focus + " focus rounds";
        grow.sub = "time you locked in";
        grow.rows.add(new String[] {"journal days", journal + " / " + days, ""});
        for (int w = 0; w < work.length; w++) {
            if (work[w] > 0) {
                grow.rows.add(new String[] {Life.WORKOUTS[w].toLowerCase(Locale.ROOT), String.valueOf(work[w]), ""});
            }
        }
        out.add(grow);

        // 7. out and about
        int rides = 0;
        for (BusData.Route r : BusData.routes()) {
            for (String dd : r.days) {
                if (dd.startsWith(ym)) {
                    rides++;
                }
            }
        }
        if (rides > 0) {
            Card bus = new Card();
            bus.c1 = 0xFF0052D4;
            bus.c2 = 0xFF65C7F7;
            bus.kicker = "OUT AND ABOUT";
            bus.emoji = "🚌";
            bus.big = rides + " bus rides";
            bus.sub = "on your Zürich routes";
            out.add(bus);
        }

        // 8. the month in one word
        Card end1 = new Card();
        end1.c1 = 0xFFFC466B;
        end1.c2 = 0xFF3F5EFB;
        end1.kicker = monthName.toUpperCase(Locale.getDefault()) + " IN ONE WORD";
        String word;
        String why;
        if (kebabs >= 4) {
            word = "KEBAB KING";
            why = kebabs + " kebabs. Respect. 🥙";
        } else if (focus >= 15) {
            word = "LOCKED IN";
            why = focus + " focus rounds";
        } else if (n > 0 && sum / n >= 0.7f) {
            word = "GOOD VIBES";
            why = "your mood was mostly great";
        } else if (totalMs > 100L * 3600000L) {
            word = "ONLINE";
            why = Math.round(totalMs / 3600000f) + " hours of screen time 👀";
        } else if (rides >= 10) {
            word = "ON THE MOVE";
            why = rides + " bus rides";
        } else {
            word = "CHILL";
            why = "a calm month";
        }
        end1.big = word;
        end1.sub = why;
        end1.emoji = "✨";
        out.add(end1);
        return out;
    }

    private static String label(Context c, String pkg) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    // ------------------------------------------------------------------ share

    private void share() {
        try {
            Bitmap b = Bitmap.createBitmap(1080, 1920, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            float scale = 1080f / Math.max(1, story.getWidth());
            c.scale(scale, 1920f / Math.max(1, story.getHeight()));
            story.paintCard(c, story.getWidth(), story.getHeight(), cards.get(story.index), true);
            File dir = new File(host.getCacheDir(), "share");
            dir.mkdirs();
            File f = new File(dir, "nova-wrapped.png");
            try (FileOutputStream o = new FileOutputStream(f)) {
                b.compress(Bitmap.CompressFormat.PNG, 100, o);
            }
            android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(host, host.getPackageName() + ".fileprovider", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("image/png");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            host.startActivity(Intent.createChooser(i, "Share your Wrapped"));
        } catch (Exception e) {
            host.toast("Could not share the card");
        }
    }

    // ------------------------------------------------------------------ the stories

    final class Story extends View {
        private static final long CARD_MS = 6500;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int index;
        private long shownAt;
        private long pausedAt = -1;
        private float downX;
        private long downAt;

        Story(Context c) {
            super(c);
        }

        void restart() {
            index = 0;
            shownAt = SystemClock.uptimeMillis();
            invalidate();
        }

        private void go(int dir) {
            int ni = index + dir;
            if (ni < 0) {
                ni = 0;
            }
            if (ni >= cards.size()) {
                host.hideOverlay();
                return;
            }
            index = ni;
            shownAt = SystemClock.uptimeMillis();
            host.buzz(6);
            invalidate();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downAt = SystemClock.uptimeMillis();
                    pausedAt = downAt;
                    return true;
                case MotionEvent.ACTION_UP: {
                    long held = SystemClock.uptimeMillis() - downAt;
                    shownAt += SystemClock.uptimeMillis() - pausedAt;
                    pausedAt = -1;
                    if (held < 300) {
                        go(downX < getWidth() * 0.3f ? -1 : 1);
                    }
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    if (pausedAt >= 0) {
                        shownAt += SystemClock.uptimeMillis() - pausedAt;
                    }
                    pausedAt = -1;
                    return true;
                default:
                    return true;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            if (cards.isEmpty()) {
                return;
            }
            long now = pausedAt >= 0 ? pausedAt : SystemClock.uptimeMillis();
            float prog = Math.min(1f, (now - shownAt) / (float) CARD_MS);
            if (prog >= 1f && cards.size() > 1 && pausedAt < 0) {
                if (index < cards.size() - 1) {
                    go(1);
                    return;
                }
            }
            paintCard(c, getWidth(), getHeight(), cards.get(Math.min(index, cards.size() - 1)), false);
            // progress segments at the top
            float d = getResources().getDisplayMetrics().density;
            float gap = 4 * d;
            float segW = (getWidth() - 24 * d - gap * (cards.size() - 1)) / cards.size();
            for (int i = 0; i < cards.size(); i++) {
                float x = 12 * d + i * (segW + gap);
                p.setShader(null);
                p.setColor(0x55FFFFFF);
                c.drawRoundRect(new RectF(x, 40 * d, x + segW, 43 * d), 2 * d, 2 * d, p);
                float f = i < index ? 1f : i == index ? prog : 0f;
                p.setColor(0xFFFFFFFF);
                c.drawRoundRect(new RectF(x, 40 * d, x + segW * f, 43 * d), 2 * d, 2 * d, p);
            }
            postInvalidateOnAnimation();
        }

        /** Draws one card; also used for the picture you share. */
        void paintCard(Canvas c, float w, float hh, Card card, boolean forShare) {
            float d = getResources().getDisplayMetrics().density;
            float t = SystemClock.uptimeMillis() / 1000f;
            float shift = forShare ? 0 : (float) Math.sin(t * 0.4f) * w * 0.15f;
            p.setShader(new LinearGradient(shift, 0, w + shift, hh, card.c1, card.c2, Shader.TileMode.MIRROR));
            c.drawRect(0, 0, w, hh, p);
            p.setShader(null);
            // soft floating circles
            for (int i = 0; i < 4; i++) {
                float cx = w * (0.2f + 0.25f * i) + (forShare ? 0 : (float) Math.sin(t * 0.5f + i) * 20 * d);
                float cy = hh * (0.18f + 0.2f * (i % 2)) + (forShare ? 0 : (float) Math.cos(t * 0.4f + i) * 20 * d);
                p.setColor(0x14FFFFFF);
                c.drawCircle(cx, cy, w * (0.18f + 0.06f * i), p);
            }
            float pad = 28 * d;
            float y = hh * 0.22f;
            p.setTextAlign(Paint.Align.LEFT);
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            p.setColor(0xCCFFFFFF);
            p.setTextSize(13 * d);
            p.setLetterSpacing(0.15f);
            c.drawText(card.kicker, pad, y, p);
            p.setLetterSpacing(0f);
            if (!card.emoji.isEmpty()) {
                p.setTextSize(64 * d);
                c.drawText(card.emoji, pad - 4 * d, y + 86 * d, p);
                y += 96 * d;
            } else {
                y += 20 * d;
            }
            p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
            float size = 40 * d;
            p.setTextSize(size);
            while (p.measureText(card.big) > w - 2 * pad && size > 20 * d) {
                size -= 2 * d;
                p.setTextSize(size);
            }
            c.drawText(card.big, pad, y + size, p);
            y += size + 16 * d;
            p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            p.setTextSize(15 * d);
            p.setColor(0xEEFFFFFF);
            for (String line : wrap(card.sub, w - 2 * pad)) {
                c.drawText(line, pad, y + 15 * d, p);
                y += 22 * d;
            }
            y += 18 * d;
            for (String[] row : card.rows) {
                p.setTextSize(15 * d);
                p.setColor(0xFFFFFFFF);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                p.setTextAlign(Paint.Align.LEFT);
                String left = row[0];
                int nn = p.breakText(left, true, w * 0.58f - pad, null);
                if (nn < left.length()) {
                    left = left.substring(0, Math.max(1, nn - 1)) + "…";
                }
                c.drawText(left, pad, y + 16 * d, p);
                p.setTextAlign(Paint.Align.RIGHT);
                p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                c.drawText(row[1], w - pad, y + 16 * d, p);
                if (!row[2].isEmpty()) {
                    float f;
                    try {
                        f = Float.parseFloat(row[2]);
                    } catch (NumberFormatException ex) {
                        f = 0;
                    }
                    p.setColor(0x33FFFFFF);
                    c.drawRoundRect(new RectF(pad, y + 24 * d, w - pad, y + 30 * d), 3 * d, 3 * d, p);
                    p.setColor(0xFFFFFFFF);
                    c.drawRoundRect(new RectF(pad, y + 24 * d, pad + (w - 2 * pad) * Math.max(0.02f, f), y + 30 * d), 3 * d,
                            3 * d, p);
                    y += 44 * d;
                } else {
                    y += 32 * d;
                }
            }
            if (card.dots != null) {
                float cell = (w - 2 * pad) / 7f;
                for (int i = 0; i < card.dots.length; i++) {
                    float cx = pad + (i % 7 + 0.5f) * cell;
                    float cy = y + (i / 7 + 0.5f) * cell;
                    p.setColor(card.dots[i] == 0 ? 0x33FFFFFF : card.dots[i]);
                    c.drawCircle(cx, cy, cell * 0.36f, p);
                }
            }
            if (forShare) {
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                p.setTextSize(13 * d);
                p.setColor(0xAAFFFFFF);
                c.drawText("made with NOVA", w / 2, hh - 30 * d, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }

        private List<String> wrap(String s, float maxW) {
            List<String> out = new ArrayList<>();
            if (s == null || s.isEmpty()) {
                return out;
            }
            StringBuilder line = new StringBuilder();
            for (String word : s.split(" ")) {
                String tryL = line.length() == 0 ? word : line + " " + word;
                if (p.measureText(tryL) > maxW && line.length() > 0) {
                    out.add(line.toString());
                    line = new StringBuilder(word);
                } else {
                    line = new StringBuilder(tryL);
                }
            }
            if (line.length() > 0) {
                out.add(line.toString());
            }
            return out;
        }
    }
}
