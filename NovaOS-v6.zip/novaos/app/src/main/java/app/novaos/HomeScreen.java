package app.novaos;

import android.animation.ValueAnimator;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Clock, pinned apps and a dock. Swipe up on an empty area to open the app drawer. */
final class HomeScreen extends FrameLayout {
    private static final int COLUMNS = 4;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView battery;
    private final android.view.GestureDetector swipe;
    private ValueAnimator glowAnim;
    private ValueAnimator nameGlow;
    private TextView batteryText, unlocksText, appsText, uptimeText;
    private View barFill;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshBattery();
            refreshStatus();
            handler.postDelayed(this, 30000);
        }
    };

    HomeScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        int side = Theme.dp(host, 24);

        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        // code wallpaper behind everything, typing itself at the chosen opacity
        if (Prefs.homeCode()) {
            CodeWallpaper code = new CodeWallpaper(host, true);
            code.setAlpha(Theme.wallAlpha());
            code.setPadding(side, Theme.dp(host, 44), side, 0);
            addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        // top row: name on the left, battery on the right
        LinearLayout status = new LinearLayout(host);
        status.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = mono(Theme.OS_NAME, 12f, Theme.ACCENT);
        name.setLetterSpacing(0.3f);
        nameGlow = Theme.glow(name);
        battery = mono("", 12f, Theme.DIM);
        status.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        status.addView(battery);
        col.addView(status);

        TextClock clock = new TextClock(host);
        clock.setFormat12Hour("HH:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(64f);
        clock.setTypeface(Theme.clockFace());
        clock.setTextColor(Theme.TEXT);
        clock.setIncludeFontPadding(false);
        glowAnim = Theme.glow(clock);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 28);
        col.addView(clock, clp);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(15f);
        date.setTextColor(Theme.DIM);
        col.addView(date);

        // live system panel, then a flexible gap
        LinearLayout panel = statusPanel();
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.topMargin = Theme.dp(host, 28);
        if (Prefs.systemPanel()) {
            col.addView(panel, plp);
        }
        col.addView(new View(host), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // pinned apps
        host.repo.ensureFresh();
        List<AppEntry> pinned = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                pinned.add(e);
            }
        }
        if (pinned.isEmpty()) {
            TextView empty = mono("Long-press an app in the drawer to pin it here.", 12f, Theme.DIM);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            elp.bottomMargin = Theme.dp(host, 20);
            col.addView(empty, elp);
        } else {
            LinearLayout rows = new LinearLayout(host);
            rows.setOrientation(LinearLayout.VERTICAL);
            LinearLayout row = null;
            int n = 0;
            for (AppEntry e : pinned) {
                if (n % COLUMNS == 0) {
                    row = new LinearLayout(host);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    rows.addView(row, new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                }
                row.addView(cell(e), new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                n++;
            }
            while (n % COLUMNS != 0) {
                row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
                n++;
            }
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = Theme.dp(host, 20);
            col.addView(rows, rlp);
        }

        // dock
        LinearLayout dock = new LinearLayout(host);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        dock.setPadding(Theme.dp(host, 6), Theme.dp(host, 4), Theme.dp(host, 6), Theme.dp(host, 4));
        dock.addView(dockButton("APPS", v -> host.showDrawer()), weight());
        dock.addView(dockButton("NOTES", v -> host.showNotes()), weight());
        dock.addView(dockButton("TERMINAL", v -> host.showTerminal()), weight());
        dock.addView(dockButton("SETUP", v -> host.showSettings()), weight());
        col.addView(dock, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        swipe = new android.view.GestureDetector(host,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (e1 != null && e2 != null
                                && e1.getY() - e2.getY() > Theme.dp(host, 80) && Math.abs(vy) > 600) {
                            host.showDrawer();
                            return true;
                        }
                        return false;
                    }
                });

        refreshBattery();
        refreshStatus();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        return swipe.onTouchEvent(e) || super.onTouchEvent(e);
    }

    /** A small boxed panel with live phone stats. Refreshes every 30 seconds with the clock. */
    private LinearLayout statusPanel() {
        LinearLayout p = new LinearLayout(host);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        int pad = Theme.dp(host, 16);
        p.setPadding(pad, pad, pad, pad);

        TextView head = mono("SYSTEM", 11f, Theme.ACCENT);
        head.setLetterSpacing(0.2f);
        p.addView(head);

        batteryText = statValue(p, "BATTERY");
        LinearLayout bar = new LinearLayout(host);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setWeightSum(100f);
        bar.setBackground(Theme.rounded(0x33FFFFFF, 3f, host));
        barFill = new View(host);
        barFill.setBackground(Theme.rounded(Theme.ACCENT, 3f, host));
        bar.addView(barFill, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 0f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Theme.dp(host, 6));
        blp.topMargin = Theme.dp(host, 6);
        p.addView(bar, blp);

        unlocksText = statValue(p, "UNLOCKS");
        appsText = statValue(p, "APPS");
        uptimeText = statValue(p, "UPTIME");
        return p;
    }

    private TextView statValue(LinearLayout parent, String key) {
        LinearLayout r = new LinearLayout(host);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, Theme.dp(host, 8), 0, 0);
        TextView k = mono(key, 11f, Theme.DIM);
        k.setLetterSpacing(0.12f);
        r.addView(k, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = mono("", 11f, Theme.TEXT);
        r.addView(v);
        parent.addView(r, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return v;
    }

    private void refreshStatus() {
        int level = host.batteryLevel();
        if (level >= 0) {
            batteryText.setText(level + "%" + (host.charging() ? " · charging" : ""));
            ((LinearLayout.LayoutParams) barFill.getLayoutParams()).weight = level;
            barFill.getParent().requestLayout();
        } else {
            batteryText.setText("--");
        }
        unlocksText.setText(String.valueOf(Prefs.unlocks()));
        appsText.setText(String.valueOf(host.repo.all.size()));
        long mins = SystemClock.elapsedRealtime() / 60000L;
        uptimeText.setText(mins >= 60 ? (mins / 60) + "h " + (mins % 60) + "m" : mins + "m");
    }

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView dockButton(String label, OnClickListener click) {
        TextView b = mono(label, 11f, Theme.TEXT);
        b.setLetterSpacing(0.12f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private View cell(final AppEntry e) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));

        ImageView icon = new ImageView(host);
        icon.setImageDrawable(Theme.tint(e.icon));
        c.addView(icon, new LinearLayout.LayoutParams(Theme.dp(host, 54), Theme.dp(host, 54)));

        TextView t = new TextView(host);
        t.setText(e.label);
        t.setTextSize(11f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 6);
        c.addView(t, tlp);

        c.setOnClickListener(v -> host.launch(e));
        c.setOnLongClickListener(v -> {
            host.confirmUnpin(e);
            return true;
        });
        return c;
    }

    private void refreshBattery() {
        if (!Prefs.battery()) {
            battery.setText("");
            return;
        }
        int level = host.batteryLevel();
        if (level < 0) {
            battery.setText("");
            return;
        }
        battery.setText(level + "%" + (host.charging() ? " · charging" : ""));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.postDelayed(tick, 30000);
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        glowAnim.cancel();
        nameGlow.cancel();
        super.onDetachedFromWindow();
    }
}
