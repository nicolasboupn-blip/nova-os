package app.novaos;

import android.app.AlertDialog;

/** What changed in each version, and a one-time "what's new" popup after an update. */
final class Changelog {
    private Changelog() {}

    static final String TEXT =
            "3.12  Achievements and upgrades\n"
            + " - 70 achievements in bronze, silver and gold. Each pays coins (50, 150, 400) and has a progress counter. Scroll the BADGES page. Your best 3 show on your NOVA Net profile\n"
            + " - Coin Shop > UPGRADES: 4th daily quest, spin tickets, lucky charm, high roller bets (100, 250), auto-spin x10 (hold the lever), golden magnet, castle gold mine (earns while you are away), bigger vault, 3% interest, 3-pack of streak shields\n"
            + " - Phone upgrades: 5 icons per row, a fifth dock button (NET), icon shapes, 3 new animated wallpapers (Nebula, Ocean, Petals), sound packs (Retro, Bell, Wood), auto night colours, dancer pack (DJ, skateboard, fishing)\n"
            + " - NOVA Net style (bubble colours, profile frame), stickers, castle decorations (fireflies, lanterns, fountain)\n"
            + " - Zigzag castle skins now only recolour the roofs and windows (walls and rock keep their natural colours), with a pulsing aura and rising zigzag sparks\n"
            + " - Casino rule: the clock and date hide while the SLOTS or CASINO page is open on the home panel\n"
            + " - Roulette cheat mode: a tiny v-number in the top right corner shows the next pocket (it looks like a version tag)\n"
            + " - New character looks: Tracksuit, Wizard robe, Royal plate and the Ponytail, Curly and Undercut hair\n\n"
            + "3.11  Dancer and slots\n"
            + " - Fixed a crash after confetti (a view was removed while the screen was drawing it)\n"
            + " - Admin: CALL HIM BACK (also terminal: dragon call) ends the dragon's trip and he flies home. The admin panel shows when he is due back\n"
            + " - Your character lives in the top corner of the home screen. He dances to your music (4 dances) and otherwise waves, drinks coffee, reads, texts, does jumping jacks, sleeps at night and holds an umbrella when it rains. Tap him for the next thing. He cheers on quests and big coin wins. Switch him off in Settings\n"
            + " - Slot machine: new look (gold cabinet, chasing lights, curved reels, win line), a rolling ratchet sound with a clunk as each reel stops\n"
            + " - The 777 jackpot now pays 70% of the coins the machine kept since the last jackpot, plus 100 (never less than the old x10)\n\n"
            + "3.10  NOVA Net\n"
            + " - Accounts, friends, direct and group chats and ranklists, on a server you host yourself (server folder, README inside)\n"
            + " - Settings > NOVA NET (or the Shop page): enter your server address, then create an account\n"
            + " - Ranks: coins this week, coins all time, castle stage, quest streak, quests done, cosmetics. Show everyone or only friends\n"
            + " - Block and report people, hide yourself from the ranks, change password, delete account\n"
            + " - Friends without an Android phone can use the web version at your-server/app\n\n"
            + "3.9.2  Zigzag, redrawn\n"
            + " - New Zigzag shield (metal rim, gem, lightning bolt) and big solid wings with pointed feather tips\n"
            + " - New Zigzag cape in every edition, with a zigzag hem that sways. Buy it in the Coin Shop or wear it in My Character\n"
            + " - The full set now includes the cape (still 20% off)\n\n"
            + "3.9.1  Fixes\n"
            + " - The wizard and the dragon no longer fade in and out: they were drawn see-through by mistake\n"
            + " - The castle by day has warmer colours\n\n"
            + "3.9  Admin in the panel\n"
            + " - New ADMIN page on the home panel (admin mode only): every lever plus a command line, compact and scrollable, not full screen\n"
            + " - New admin commands: boost, spin reset, shield, bank\n\n"
            + "3.8  The Zigzag collection\n"
            + " - 7 editions (I to V, Black, Gold), each with a shield, wings that flap and an animated castle skin\n"
            + " - Coin Shop > Zigzag editions: buy parts or the full set at 20% off. Wear them in My Character and the Castle Workshop\n\n"
            + "3.7.1  Fix\n"
            + " - MAP page: the buttons were cut off, so it never loaded. Fixed, and it now finds you by itself once location is allowed\n\n"
            + "3.7  The Coin Shop\n"
            + " - My character: a pixel art figure of you. Skin, hair, tops, hats, glasses, capes, shoes. Dress him with coins (Shop page or long-press the wizard)\n"
            + " - Double coins now comes in 1 hour (150), 1 day (3000) and 1 week (20000)\n"
            + " - Settings > Coin Shop, or long-press the wizard\n"
            + " - Double-coins potion, quest re-roll, streak shields, fireworks, dragon treats, mystery chest\n"
            + " - Titles from Squire to Emperor, pet hats, 6 premium colour themes\n"
            + " - The bank: save coins and earn 2% a day\n"
            + " - New SHOP page on the status panel with a free daily lucky spin\n"
            + " - Your name on the home screen under the date: elegant, graffiti or neon (Settings > Your name on home)\n"
            + " - New MAP page on the status panel: tap LOCATE to see where you are (OpenStreetMap, nothing saved)\n"
            + " - Castle visitors (from castle stage 2): a knight pays tribute, a merchant sells shop items at 40% off, a thief steals coins unless you tap him in time\n\n"
            + "3.6  New dragon, new pig\n"
            + " - Ember redrawn: bat wings that flap, sleeping and awake poses, fire, 8 colours\n"
            + " - He carries the roast pig to you in his claws, and the pig has a new look\n"
            + " - The extra towers and the sword are gone\n"
            + " - Admin only: Ember can coil around the main tower\n\n"
            + "3.5  The castle update\n"
            + " - Castle workshop: 10 upgrades (water wheel, lava, sword and banner of your country, towers, dragon, styles)\n"
            + " - Ember the dragon grows up, breathes fire, talks, travels for days, brings roast pigs\n"
            + " - Wizard wardrobe: robes and staff orbs. Second pet at stage 7.\n"
            + " - Long-press the wizard: jokes, riddles, fortune, 8-ball, spells, lesson of the day\n"
            + " - 4 new games: fishing, horse race, treasure map, word of the day\n"
            + " - To-do + habits and a focus timer on the home panel\n"
            + " - Daily login bonus with a streak, sound volume, night tint, reduce motion, left-handed mode\n"
            + " - Backup and restore, health check, safe mode, admin panel\n\n"
            + "3.3  Pets, surprises, quests, critters, pranks, wizard reactions\n"
            + "3.2  Wizard suggestions\n"
            + "3.1  Battery saver\n"
            + "3.0  Gallery and castle";

    static void show(NovaActivity host) {
        new AlertDialog.Builder(host).setTitle("What's new in NOVA " + Theme.OS_VERSION)
                .setMessage(TEXT).setPositiveButton("Nice", null).show();
    }

    static void showIfNew(NovaActivity host) {
        if (Prefs.getInt("setup_done", 0) == 0) {
            return;
        }
        String seen = Prefs.getString("whatsnew", "");
        if (!seen.equals(Theme.OS_VERSION)) {
            Prefs.putString("whatsnew", Theme.OS_VERSION);
            if (!seen.isEmpty()) {
                show(host);
            }
        }
    }
}
