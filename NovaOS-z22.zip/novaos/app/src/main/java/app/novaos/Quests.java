package app.novaos;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Three small goals every day, with coins as the reward and a streak for finishing them all. */
final class Quests {
    static final class Def {
        final String id;
        final String text;
        final int target;
        final int reward;

        Def(String id, String text, int target, int reward) {
            this.id = id;
            this.text = text;
            this.target = target;
            this.reward = reward;
        }
    }

    private static final Def[] POOL = {
        new Def("spin", "Spin the slots 5 times", 5, 30),
        new Def("game", "Open 3 mini-games", 3, 30),
        new Def("app", "Open 6 apps", 6, 25),
        new Def("coin", "Flip the golden coin", 1, 20),
        new Def("pet", "Pet your companion 3 times", 3, 25),
        new Def("castle", "Tap the castle twice", 2, 20),
        new Def("event", "Catch 2 surprises", 2, 40),
        new Def("critter", "Squash 1 notification critter", 1, 30),
    };

    private Quests() {}

    static boolean on() {
        return Prefs.questsOn();
    }

    private static int today() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR);
    }

    private static Def find(String id) {
        for (Def d : POOL) {
            if (d.id.equals(id)) {
                return d;
            }
        }
        return null;
    }

    /** Makes sure today's three quests exist. */
    private static void roll() {
        int day = today();
        if (Prefs.getInt("q_day", 0) == day) {
            return;
        }
        // streak: kept only if yesterday was finished
        int yesterdayDone = Prefs.getInt("q_all_day", 0);
        Calendar y = Calendar.getInstance();
        y.add(Calendar.DAY_OF_YEAR, -1);
        int yday = y.get(Calendar.YEAR) * 1000 + y.get(Calendar.DAY_OF_YEAR);
        if (yesterdayDone != yday) {
            Prefs.putInt("q_streak", yesterdayDone == day ? Prefs.getInt("q_streak", 0) : 0);
        }
        List<Def> pool = new ArrayList<>();
        for (Def d : POOL) {
            if (d.id.equals("pet") && !Pets.hasBody()) {
                continue;
            }
            pool.add(d);
        }
        Collections.shuffle(pool, new Random(day * 31L + 7));
        StringBuilder ids = new StringBuilder();
        for (int i = 0; i < 3 && i < pool.size(); i++) {
            ids.append(pool.get(i).id).append(',');
            Prefs.putInt("q_p_" + pool.get(i).id, 0);
            Prefs.putInt("q_d_" + pool.get(i).id, 0);
        }
        Prefs.putString("q_ids", ids.toString());
        Prefs.putInt("q_day", day);
    }

    static List<Def> today3() {
        roll();
        List<Def> l = new ArrayList<>();
        for (String id : Prefs.getString("q_ids", "").split(",")) {
            Def d = find(id);
            if (d != null) {
                l.add(d);
            }
        }
        return l;
    }

    static int progress(Def d) {
        return Math.min(d.target, Prefs.getInt("q_p_" + d.id, 0));
    }

    static boolean done(Def d) {
        return Prefs.getInt("q_d_" + d.id, 0) == 1;
    }

    static int streak() {
        roll();
        return Prefs.getInt("q_streak", 0);
    }

    /** Something happened that may count towards a quest. */
    static void event(NovaActivity host, String id) {
        if (!on()) {
            return;
        }
        for (Def d : today3()) {
            if (!d.id.equals(id) || done(d)) {
                continue;
            }
            int n = Prefs.getInt("q_p_" + id, 0) + 1;
            Prefs.putInt("q_p_" + id, n);
            if (n >= d.target) {
                Prefs.putInt("q_d_" + id, 1);
                Coins.add(d.reward);
                Sfx.play(Sfx.WIN);
                host.wizardSay("Quest done: " + d.text + "! +" + d.reward + " coins");
                allDone(host);
            }
        }
    }

    private static void allDone(NovaActivity host) {
        for (Def d : today3()) {
            if (!done(d)) {
                return;
            }
        }
        int day = today();
        if (Prefs.getInt("q_all_day", 0) == day) {
            return;
        }
        Prefs.putInt("q_all_day", day);
        int streak = Prefs.getInt("q_streak", 0) + 1;
        Prefs.putInt("q_streak", streak);
        int bonus = Math.min(100, 20 * streak);
        Coins.add(bonus);
        host.root.postDelayed(() -> host.wizardSay("All three quests! Streak " + streak + " 🔥 Bonus +"
                + bonus + " coins"), 3500);
    }
}
