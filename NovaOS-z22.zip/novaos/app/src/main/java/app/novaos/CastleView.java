package app.novaos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * The wizard's castle, a pixel-art picture that sits on the home screen next to the clock. At night the windows
 * glow, by day it turns to sunlit stone. The rock under it crumbles into little cubes that drift off, some in the
 * theme colour. The wizard lives inside: tap the castle and he comes out, tap it again and he goes home.
 */
final class CastleView extends View {
    static final int SW = 140;      // sprite size in pixels
    static final int SH = 194;
    private static final int DOOR_X = 56;   // middle of the door, in sprite pixels
    private static final int DOOR_TOP = 108;
    private static final int DOOR_BOTTOM = 117;
    private static final int ROCK_FROM = 124; // rows from here down are the crumbling rock

    private static final class Cube {
        float x, y, vx, vy, size, life, age;
        int color;
    }

    private final NovaActivity host;
    private final Bitmap night;
    private final Bitmap day;
    private final int sc;
    private final Paint p = new Paint();
    private final Rect src = new Rect(0, 0, SW, SH);
    private final Rect dst = new Rect();
    private final Random rnd = new Random();
    private final List<Cube> cubes = new ArrayList<>();
    private final int[] rockX = new int[SW * (SH - ROCK_FROM)];
    private final int[] rockY = new int[SW * (SH - ROCK_FROM)];
    private int rockN;
    private final long born = System.nanoTime();
    private long last = System.nanoTime();
    private float spawnDebt;
    private float dayness;
    // night and day blended pixel by pixel, so the windows go out one at a time at dawn
    private final int[] nightPx = new int[SW * SH];
    private final int[] dayPx = new int[SW * SH];
    private final int[] mixPx = new int[SW * SH];
    private final float[] thr = new float[SW * SH];
    private Bitmap mix;
    private int mixLevel = -1;
    // life: dragon, bats, weather
    private int weather;            // 0 clear, 1 rain, 2 snow, 3 storm
    private float dragonAt = -1f;   // seconds into its flight, -1 = not flying
    private float nextDragon = 40f + new Random().nextInt(80);
    private float flash;
    private float nextFlash = 6f;
    private final float[] dropX = new float[48];
    private final float[] dropY = new float[48];
    private long dayChecked;

    CastleView(NovaActivity host) {
        super(host);
        this.host = host;
        night = load("castle_night");
        day = load("castle_day");
        int w = host.getResources().getDisplayMetrics().widthPixels;
        sc = Math.max(2, Math.round(w * 0.44f / SW));
        p.setFilterBitmap(false);
        p.setAntiAlias(false);
        if (night != null && day != null) {
            night.getPixels(nightPx, 0, SW, 0, 0, SW, SH);
            day.getPixels(dayPx, 0, SW, 0, 0, SW, SH);
            Random tr = new Random(42);
            for (int i = 0; i < thr.length; i++) {
                thr[i] = tr.nextFloat();
            }
            mix = Bitmap.createBitmap(SW, SH, Bitmap.Config.ARGB_8888);
        }
        for (int i = 0; i < dropX.length; i++) {
            dropX[i] = rnd.nextFloat();
            dropY[i] = rnd.nextFloat();
        }
        weather = Prefs.getInt("wx_kind", 0);
        if (night != null) {
            for (int y = ROCK_FROM; y < SH; y++) {
                for (int x = 0; x < SW; x++) {
                    if (night.getPixel(x, y) >>> 24 > 0) {
                        rockX[rockN] = x;
                        rockY[rockN] = y;
                        rockN++;
                    }
                }
            }
        }
    }

    private Bitmap load(String name) {
        int id = getContext().getResources().getIdentifier(name, "drawable", getContext().getPackageName());
        if (id == 0) {
            return null;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeResource(getContext().getResources(), id, o);
    }

    int spriteW() {
        return SW * sc;
    }

    int spriteH() {
        return SH * sc;
    }

    /** Where it goes in the home screen: top right, level with the clock. */
    FrameLayout.LayoutParams params() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(spriteW(), spriteH(),
                android.view.Gravity.TOP | android.view.Gravity.END);
        lp.topMargin = Theme.dp(host, 52);
        lp.rightMargin = Theme.dp(host, 6);
        return lp;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        host.castle = this;
        if (WeatherData.hasCity()) {
            new Thread(() -> {
                try {
                    if (WeatherData.load(false)) {
                        int code = WeatherData.code;
                        int kind = code >= 95 ? 3 : (code >= 71 && code <= 77) || code == 85 || code == 86 ? 2
                                : (code >= 51 && code <= 67) || (code >= 80 && code <= 82) ? 1 : 0;
                        Prefs.putInt("wx_kind", kind);
                        weather = kind;
                    }
                } catch (Exception ignored) {
                    // no weather, no problem
                }
            }).start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (host.castle == this) {
            host.castle = null;
        }
        super.onDetachedFromWindow();
    }

    /** 0 at night, 1 in daylight, eased around sunrise and sunset. */
    private float computeDay() {
        Calendar c = Calendar.getInstance();
        float h = c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f;
        return smooth(5.5f, 8f, h) * (1f - smooth(18f, 20.5f, h));
    }

    private static float smooth(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    /** The door, bottom middle, in the coordinates of the given parent. */
    float[] door(View parent) {
        int[] a = new int[2];
        int[] b = new int[2];
        getLocationOnScreen(a);
        parent.getLocationOnScreen(b);
        float sx = getScaleX();
        return new float[] {a[0] - b[0] + DOOR_X * sc * sx, a[1] - b[1] + DOOR_BOTTOM * sc * sx};
    }

    /** True if a screen touch lands on the castle itself (not the empty air around it). */
    boolean hit(float rawX, float rawY) {
        int[] a = new int[2];
        getLocationOnScreen(a);
        int px = (int) ((rawX - a[0]) / sc);
        int py = (int) ((rawY - a[1]) / sc);
        if (night == null) {
            return false;
        }
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int x = px + dx;
                int y = py + dy;
                if (x >= 0 && y >= 0 && x < SW && y < SH && night.getPixel(x, y) >>> 24 > 128) {
                    return true;
                }
            }
        }
        return false;
    }

    /** A little burst of cubes at the door, when the wizard goes in or out. */
    void puff() {
        for (int i = 0; i < 22; i++) {
            Cube c = new Cube();
            c.x = (DOOR_X + rnd.nextFloat() * 4f - 2f) * sc;
            c.y = (DOOR_BOTTOM - rnd.nextFloat() * 6f) * sc;
            c.vx = (rnd.nextFloat() - 0.5f) * 90f * sc / 3f;
            c.vy = -rnd.nextFloat() * 70f * sc / 3f;
            c.size = sc * (1 + rnd.nextInt(2));
            c.life = 0.8f + rnd.nextFloat() * 0.8f;
            c.color = rnd.nextBoolean() ? 0xFFFFD84D : Theme.ACCENT;
            cubes.add(c);
        }
    }

    private void spawnCrumb() {
        if (rockN == 0 || cubes.size() > 70) {
            return;
        }
        int i = rnd.nextInt(rockN);
        Cube c = new Cube();
        c.x = rockX[i] * sc;
        c.y = rockY[i] * sc;
        c.vx = (rnd.nextFloat() - 0.4f) * 14f * sc / 3f;
        c.vy = 8f * sc / 3f + rnd.nextFloat() * 22f * sc / 3f;
        c.size = sc * (rnd.nextInt(5) == 0 ? 2 : 1);
        c.life = 2.2f + rnd.nextFloat() * 2.6f;
        if (rnd.nextInt(100) < 28) {
            c.color = Theme.ACCENT;
        } else {
            Bitmap b = dayness > 0.5f && day != null ? day : night;
            c.color = b.getPixel(rockX[i], rockY[i]) | 0xFF000000;
        }
        cubes.add(c);
    }

    private void drawLife(Canvas c, float dt, float t) {
        float W = SW * sc;
        float H = SH * sc;
        p.setStyle(Paint.Style.FILL);
        // bats come out at night
        float darkness = 1f - dayness;
        if (darkness > 0.3f) {
            for (int i = 0; i < 3; i++) {
                float ph = i * 2.1f;
                float bx = W * (0.5f + 0.44f * (float) Math.cos(t * 0.5f + ph));
                float by = H * (0.16f + 0.10f * (float) Math.sin(t * 0.9f + ph * 1.7f)) + i * sc * 6;
                boolean up = (int) (t * 7f + i) % 2 == 0;
                p.setColor(((int) (230 * darkness) << 24) | 0x140C1E);
                c.drawRect(bx - sc, by, bx + sc, by + sc * 1.5f, p);
                c.drawRect(bx - 4 * sc, by + (up ? -sc : sc * 0.5f), bx - sc, by + (up ? 0.5f * sc : 1.5f * sc), p);
                c.drawRect(bx + sc, by + (up ? -sc : sc * 0.5f), bx + 4 * sc, by + (up ? 0.5f * sc : 1.5f * sc), p);
            }
        }
        // a dragon flies past now and then
        if (dragonAt < 0f) {
            nextDragon -= dt;
            if (nextDragon <= 0f) {
                dragonAt = 0f;
            }
        } else {
            dragonAt += dt;
            float k = dragonAt / 9f;
            if (k > 1f) {
                dragonAt = -1f;
                nextDragon = 80f + rnd.nextInt(100);
            } else {
                float dx = -10 * sc + (W + 20 * sc) * k;
                float dy = H * 0.10f + (float) Math.sin(k * 9f) * sc * 5f;
                int body = dayness > 0.5f ? 0xFF2E7D4F : 0xFF2A1B3D;
                boolean up = (int) (t * 5f) % 2 == 0;
                p.setColor(body);
                c.drawRect(dx, dy, dx + 8 * sc, dy + 2 * sc, p);                        // body
                c.drawRect(dx + 8 * sc, dy - sc, dx + 11 * sc, dy + sc, p);             // head
                c.drawRect(dx - 5 * sc, dy + sc, dx, dy + 2 * sc, p);                   // tail
                c.drawRect(dx + 2 * sc, up ? dy - 4 * sc : dy + 2 * sc, dx + 6 * sc,
                        up ? dy : dy + 5 * sc, p);                                       // wing
                p.setColor(0xFFFF3A2A);
                c.drawRect(dx + 10 * sc, dy - sc, dx + 11 * sc, dy, p);                 // eye
                if ((int) (t * 3f) % 4 == 0) {                                          // a puff of fire
                    p.setColor(0xCCFFA030);
                    c.drawRect(dx + 11 * sc, dy, dx + 14 * sc, dy + sc, p);
                    p.setColor(0xCCFFE060);
                    c.drawRect(dx + 11 * sc, dy, dx + 12 * sc, dy + sc, p);
                }
            }
        }
        // the weather outside, to match yours
        if (weather > 0) {
            boolean snow = weather == 2;
            for (int i = 0; i < dropX.length; i++) {
                dropY[i] += dt * (snow ? 0.12f : 0.9f);
                dropX[i] += dt * (snow ? 0.03f * (float) Math.sin(t + i) : -0.12f);
                if (dropY[i] > 1f) {
                    dropY[i] -= 1f;
                    dropX[i] = rnd.nextFloat();
                }
                if (dropX[i] < 0f) {
                    dropX[i] += 1f;
                }
                float px = dropX[i] * W;
                float py = dropY[i] * H * 0.8f;
                if (snow) {
                    p.setColor(0xDDFFFFFF);
                    c.drawRect(px, py, px + sc, py + sc, p);
                } else {
                    p.setColor(0x99A8C8FF);
                    c.drawRect(px, py, px + sc * 0.6f, py + sc * 3f, p);
                }
            }
            if (weather == 3) {
                nextFlash -= dt;
                if (nextFlash <= 0f) {
                    flash = 0.35f;
                    nextFlash = 6f + rnd.nextInt(8);
                }
                if (flash > 0f) {
                    flash -= dt;
                    p.setColor(((int) (Math.max(0f, flash) * 500) << 24) | 0xFFFFFF);
                    c.drawRect(0, 0, W, H * 0.7f, p);
                }
            }
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        float t = (now - born) / 1e9f;
        if (night == null) {
            return;
        }
        if (now - dayChecked > 20_000_000_000L || dayChecked == 0) {
            dayness = computeDay();
            dayChecked = now == 0 ? 1 : now;
        }
        dst.set(0, 0, SW * sc, SH * sc);
        p.setAlpha(255);
        if (mix == null) {
            c.drawBitmap(night, src, dst, p);
        } else {
            int level = Math.round(dayness * 40f);
            if (level != mixLevel) {
                mixLevel = level;
                float lv = level / 40f;
                for (int i = 0; i < mixPx.length; i++) {
                    mixPx[i] = thr[i] < lv ? dayPx[i] : nightPx[i];
                }
                mix.setPixels(mixPx, 0, SW, 0, 0, SW, SH);
            }
            c.drawBitmap(mix, src, dst, p);
        }
        final boolean life = Prefs.castleLife() && !Saver.on();
        if (life) {
            drawLife(c, dt, t);
        }
        // the wizard's light in the doorway while he is at home
        if (host.wizInside && dayness < 0.9f) {
            float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.6);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (210 * pulse * (1f - dayness)) << 24) | 0xFFC04D);
            c.drawRect((DOOR_X - 2) * sc, (DOOR_TOP + 3) * sc, (DOOR_X + 2) * sc, DOOR_BOTTOM * sc, p);
        }
        // crumbling cubes
        boolean eco = Saver.on();
        spawnDebt += eco ? 0f : dt * 11f;
        while (spawnDebt >= 1f) {
            spawnDebt -= 1f;
            spawnCrumb();
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = cubes.size() - 1; i >= 0; i--) {
            Cube q = cubes.get(i);
            q.age += dt;
            if (q.age >= q.life) {
                cubes.remove(i);
                continue;
            }
            q.x += q.vx * dt + (float) Math.sin(t * 2f + i) * 0.15f * sc;
            q.y += q.vy * dt;
            float a = 1f - q.age / q.life;
            p.setColor((q.color & 0x00FFFFFF) | ((int) (230 * a) << 24));
            c.drawRect(q.x, q.y, q.x + q.size, q.y + q.size, p);
        }
        if (isShown()) {
            // while saving battery: no crumbling, and the picture only redraws now and then
            postInvalidateDelayed(eco && cubes.isEmpty() ? 4000 : 33);
        }
    }
}
