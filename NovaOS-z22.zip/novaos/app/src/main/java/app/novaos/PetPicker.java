package app.novaos;

import android.app.AlertDialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Choose your companion. The first choice is free. After that it is locked for 30 days, unless you know the password.
 */
final class PetPicker {
    private PetPicker() {}

    /** Builds the chooser into a layout. changed runs after every pick. */
    static void build(final NovaActivity host, final LinearLayout into, final Runnable changed) {
        into.removeAllViews();
        into.setGravity(Gravity.CENTER_HORIZONTAL);
        int cur = Pets.kind();
        if (Pets.locked()) {
            TextView lock = text(host, "🔒 Locked for " + Pets.daysLeft() + " more days. "
                    + "Tap a pet and type the password to change it now.", 11f, Theme.DIM);
            lock.setPadding(0, 0, 0, Theme.dp(host, 8));
            into.addView(lock);
        }
        LinearLayout row = new LinearLayout(host);
        row.setGravity(Gravity.CENTER);
        for (int k = 1; k <= 3; k++) {
            final int kind = k;
            row.addView(card(host, kind, cur == kind, () -> pick(host, kind, 0, into, changed)));
        }
        into.addView(row);
        if (cur == Pets.DOG || cur == Pets.CAT) {
            LinearLayout sw = new LinearLayout(host);
            sw.setGravity(Gravity.CENTER);
            sw.setPadding(0, Theme.dp(host, 10), 0, 0);
            for (int i = 0; i < Pets.COLORS[cur].length; i++) {
                final int ci = i;
                TextView t = text(host, Pets.COLORS[cur][i].toUpperCase(), 10f,
                        Pets.color() == i ? Theme.BG : Theme.TEXT);
                t.setBackground(Theme.rounded(Pets.color() == i ? Theme.ACCENT : 0x26FFFFFF, 12f, host));
                t.setPadding(Theme.dp(host, 10), Theme.dp(host, 7), Theme.dp(host, 10), Theme.dp(host, 7));
                t.setClickable(true);
                t.setOnClickListener(v -> pick(host, Pets.kind(), ci, into, changed));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
                sw.addView(t, lp);
            }
            into.addView(sw);
        } else if (cur == Pets.PARROT) {
            TextView t = text(host, "The parrot rides on the wizard's shoulder.", 11f, Theme.DIM);
            t.setPadding(0, Theme.dp(host, 10), 0, 0);
            into.addView(t);
        }
    }

    private static void pick(final NovaActivity host, final int kind, final int color, final LinearLayout into,
            final Runnable changed) {
        if (kind == Pets.kind() && color == Pets.color()) {
            return;
        }
        if (Pets.locked()) {
            askPassword(host, () -> apply(host, kind, color, into, changed));
        } else {
            apply(host, kind, color, into, changed);
        }
    }

    private static void apply(NovaActivity host, int kind, int color, LinearLayout into, Runnable changed) {
        Pets.choose(kind, color);
        Sfx.play(Sfx.COIN);
        host.syncWizard();
        build(host, into, changed);
        if (changed != null) {
            changed.run();
        }
    }

    private static void askPassword(final NovaActivity host, final Runnable ok) {
        final EditText in = new EditText(host);
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        in.setHint("Password");
        in.setGravity(Gravity.CENTER);
        new AlertDialog.Builder(host)
                .setTitle("Your companion is locked")
                .setMessage("It can only be changed once a month, or with the password.")
                .setView(in)
                .setPositiveButton("Unlock", (d, w) -> {
                    if (Pets.passwordOk(in.getText().toString())) {
                        ok.run();
                    } else {
                        host.toast("Wrong password");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static TextView text(NovaActivity host, String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    /** One pet with its picture and name. */
    private static View card(final NovaActivity host, final int kind, boolean on, final Runnable tap) {
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(Theme.dp(host, 8), Theme.dp(host, 8), Theme.dp(host, 8), Theme.dp(host, 8));
        box.setBackground(Theme.rounded(on ? 0x44FFFFFF : 0x22FFFFFF, 14f, host));
        box.setClickable(true);
        box.setOnClickListener(v -> tap.run());
        final int s = Math.max(3, Math.round(host.getResources().getDisplayMetrics().density * 3f));
        View pic = new View(host) {
            private final Paint p = new Paint();

            @Override
            protected void onDraw(Canvas c) {
                int sel = Pets.kind() == kind ? Pets.color() : 0;
                if (kind == Pets.PARROT) {
                    Pets.drawParrot(c, p, (getWidth() - 6 * s) / 2f, (getHeight() - 9 * s) / 2f, s, 0);
                } else {
                    Pets.drawPet(c, p, kind, sel, (getWidth() - Pets.PW * s) / 2f, (getHeight() - Pets.PH * s) / 2f,
                            s, 0, false, false, false);
                }
            }
        };
        box.addView(pic, new LinearLayout.LayoutParams(Pets.PW * s + s * 2, 14 * s));
        TextView n = text(host, Pets.NAMES[kind].toUpperCase(), 11f, on ? Theme.ACCENT : Theme.TEXT);
        n.setLetterSpacing(0.12f);
        box.addView(n);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Theme.dp(host, 4), 0, Theme.dp(host, 4), 0);
        box.setLayoutParams(lp);
        return box;
    }

    /** The chooser in a dialog (used by the pet page and Settings). */
    static void dialog(final NovaActivity host, final Runnable changed) {
        final LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Theme.dp(host, 16), Theme.dp(host, 12), Theme.dp(host, 16), Theme.dp(host, 4));
        build(host, box, changed);
        new AlertDialog.Builder(host).setTitle("Your companion").setView(box)
                .setPositiveButton("Done", null).show();
    }
}
