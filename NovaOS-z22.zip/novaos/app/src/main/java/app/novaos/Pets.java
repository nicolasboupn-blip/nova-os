package app.novaos;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Your companion: a dog, a cat or a parrot. Dogs and cats come in four colours, the parrot rides on the wizard's
 * shoulder. The choice is locked for 30 days (or until someone types the password). Also keeps the pet's hunger and joy.
 */
final class Pets {
    static final int NONE = 0, DOG = 1, CAT = 2, PARROT = 3;
    static final String[] NAMES = {"", "Dog", "Cat", "Parrot"};
    static final String[][] COLORS = {{}, {"Brown", "Golden", "Black", "White"}, {"Orange", "Grey", "Black", "Cream"}, {"Green"}};
    private static final String PASSWORD = "260423";
    private static final int LOCK_DAYS = 30;

    // main, light, dark, eye
    private static final int[][] DOG_PAL = {
        {0xFF8B5A2B, 0xFFC89B6B, 0xFF5A3A1A, 0xFF000000},
        {0xFFE0A93B, 0xFFF5D78A, 0xFFB57B1E, 0xFF000000},
        {0xFF2B2B33, 0xFF55555F, 0xFF15151A, 0xFFFFE070},
        {0xFFF0F0F0, 0xFFFFFFFF, 0xFFB5B5BF, 0xFF000000}};
    private static final int[][] CAT_PAL = {
        {0xFFE8883A, 0xFFF7C79A, 0xFFB5601F, 0xFF000000},
        {0xFF8E96A3, 0xFFC9CED6, 0xFF5E6573, 0xFF000000},
        {0xFF2B2B33, 0xFF55555F, 0xFF15151A, 0xFFFFE070},
        {0xFFEFDFC0, 0xFFFFF5E0, 0xFFC9B48A, 0xFF000000}};

    private Pets() {}

    static int kind() {
        return Prefs.getInt("pet_kind", NONE);
    }

    static int color() {
        return Prefs.getInt("pet_color", 0);
    }

    static boolean hasBody() {
        return kind() == DOG || kind() == CAT;
    }

    static String label() {
        int k = kind();
        if (k == NONE) {
            return "No companion yet";
        }
        String c = COLORS[k].length > color() ? COLORS[k][color()] : "";
        return NAMES[k] + (c.isEmpty() || k == PARROT ? "" : " · " + c);
    }

    private static int nowMin() {
        return (int) (System.currentTimeMillis() / 60000L);
    }

    // ------------------------------------------------------------------ the lock

    static boolean locked() {
        if (kind() == NONE || Prefs.getInt("pet_lock", 0) == 0) {
            return false;
        }
        return daysLeft() > 0;
    }

    static int daysLeft() {
        int since = Prefs.getInt("pet_since", 0);
        int days = (nowMin() - since) / (60 * 24);
        return Math.max(0, LOCK_DAYS - days);
    }

    static boolean passwordOk(String s) {
        return PASSWORD.equals(s == null ? "" : s.trim());
    }

    /** Sets the companion. Once setup is done this starts the 30-day lock. */
    static void choose(int kind, int color) {
        Prefs.putInt("pet_kind", kind);
        Prefs.putInt("pet_color", color);
        if (Prefs.getInt("setup_done", 0) == 1) {
            lockNow();
        }
        Prefs.putInt("pet_food", 80);
        Prefs.putInt("pet_food_t", nowMin());
        Prefs.putInt("pet_joy", 70);
        Prefs.putInt("pet_joy_t", nowMin());
    }

    static void lockNow() {
        if (kind() != NONE) {
            Prefs.putInt("pet_lock", 1);
            Prefs.putInt("pet_since", nowMin());
        }
    }

    // ------------------------------------------------------------------ hunger and joy (0..100)

    static int food() {
        return decay("pet_food", "pet_food_t", 12);
    }

    static int joy() {
        return decay("pet_joy", "pet_joy_t", 18);
    }

    private static int decay(String v, String t, int minutesPerPoint) {
        int base = Prefs.getInt(v, 80);
        int since = Prefs.getInt(t, nowMin());
        return Math.max(0, Math.min(100, base - (nowMin() - since) / minutesPerPoint));
    }

    static boolean feed() {
        int coins = Prefs.getInt("slot_coins", 100);
        if (coins < 10) {
            return false;
        }
        Prefs.putInt("slot_coins", coins - 10);
        Prefs.putInt("pet_food", Math.min(100, food() + 35));
        Prefs.putInt("pet_food_t", nowMin());
        bumpJoy(8);
        return true;
    }

    static void bumpJoy(int by) {
        Prefs.putInt("pet_joy", Math.min(100, joy() + by));
        Prefs.putInt("pet_joy_t", nowMin());
    }

    // ------------------------------------------------------------------ drawing

    /** Size of the dog and cat sprites, in sprite pixels. */
    static final int PW = 16, PH = 13;

    private static void r(Canvas c, Paint p, float x, float y, int s, int ux, int uy, int w, int h, int col,
            boolean flip, int total) {
        int x0 = flip ? total - ux - w : ux;
        p.setColor(col);
        c.drawRect(x + x0 * s, y + uy * s, x + (x0 + w) * s, y + (uy + h) * s, p);
    }

    /** Draws a dog or cat facing right (flip = left). frame 0/1 animates the tail and legs. */
    static void drawPet(Canvas c, Paint p, int kind, int color, float x, float y, int s, int frame, boolean flip,
            boolean happy, boolean sleeping) {
        int[] pal = (kind == DOG ? DOG_PAL : CAT_PAL)[Math.max(0, Math.min(3, color))];
        int a = pal[0], b = pal[1], d = pal[2], eye = pal[3];
        int W = PW;
        p.setStyle(Paint.Style.FILL);
        int leg = frame;
        if (kind == DOG) {
            // tail
            if (frame == 0) {
                r(c, p, x, y, s, 1, 3, 2, 4, a, flip, W);
            } else {
                r(c, p, x, y, s, 0, 4, 2, 3, a, flip, W);
            }
            r(c, p, x, y, s, 2, 5, 9, 5, a, flip, W);          // body
            r(c, p, x, y, s, 3, 8, 7, 2, b, flip, W);          // belly
            r(c, p, x, y, s, 2, 10 - leg, 2, 3 + leg, a, flip, W); // back legs
            r(c, p, x, y, s, 5, 10, 2, 3 - leg, a, flip, W);
            r(c, p, x, y, s, 7, 10 - leg, 2, 3 + leg, d, flip, W); // front legs
            r(c, p, x, y, s, 9, 10, 2, 3 - leg, d, flip, W);
            r(c, p, x, y, s, 10, 2, 5, 5, a, flip, W);         // head
            r(c, p, x, y, s, 14, 4, 2, 3, b, flip, W);         // snout
            r(c, p, x, y, s, 15, 4, 1, 1, 0xFF15151A, flip, W);// nose
            r(c, p, x, y, s, 10, 1, 2, 4, d, flip, W);         // floppy ear
            r(c, p, x, y, s, 10, 6, 3, 1, 0xFFD94A4A, flip, W);// collar
            if (sleeping) {
                r(c, p, x, y, s, 12, 4, 2, 1, d, flip, W);
            } else {
                r(c, p, x, y, s, 12, 3, 1, 1, eye, flip, W);
            }
            if (happy) {
                r(c, p, x, y, s, 14, 7, 1, 2, 0xFFFF7A9A, flip, W);
            }
        } else {
            // tail curls up behind
            if (frame == 0) {
                r(c, p, x, y, s, 0, 2, 1, 6, a, flip, W);
                r(c, p, x, y, s, 1, 7, 2, 1, a, flip, W);
            } else {
                r(c, p, x, y, s, 1, 3, 1, 5, a, flip, W);
                r(c, p, x, y, s, 2, 7, 1, 1, a, flip, W);
            }
            r(c, p, x, y, s, 2, 6, 9, 4, a, flip, W);          // body
            r(c, p, x, y, s, 3, 8, 7, 2, b, flip, W);          // belly
            r(c, p, x, y, s, 4, 6, 1, 2, d, flip, W);          // stripes
            r(c, p, x, y, s, 7, 6, 1, 2, d, flip, W);
            r(c, p, x, y, s, 3, 10 - leg, 2, 3 + leg, a, flip, W);
            r(c, p, x, y, s, 6, 10, 2, 3 - leg, a, flip, W);
            r(c, p, x, y, s, 8, 10 - leg, 2, 3 + leg, b, flip, W);
            r(c, p, x, y, s, 10, 3, 5, 5, a, flip, W);        // head
            r(c, p, x, y, s, 10, 1, 1, 2, a, flip, W);        // ears
            r(c, p, x, y, s, 14, 1, 1, 2, a, flip, W);
            r(c, p, x, y, s, 11, 2, 1, 1, 0xFFFF9AAE, flip, W);
            r(c, p, x, y, s, 13, 2, 1, 1, 0xFFFF9AAE, flip, W);
            if (sleeping) {
                r(c, p, x, y, s, 11, 5, 1, 1, d, flip, W);
                r(c, p, x, y, s, 13, 5, 1, 1, d, flip, W);
            } else {
                r(c, p, x, y, s, 11, 4, 1, 2, eye, flip, W);
                r(c, p, x, y, s, 13, 4, 1, 2, eye, flip, W);
            }
            r(c, p, x, y, s, 12, 6, 1, 1, 0xFFFF7A9A, flip, W); // nose
            r(c, p, x, y, s, 10, 5, 1, 1, b, flip, W);
            r(c, p, x, y, s, 14, 5, 1, 1, b, flip, W);
            if (happy) {
                r(c, p, x, y, s, 12, 7, 1, 1, 0xFFFF7A9A, flip, W);
            }
        }
    }

    /** The parrot, 6 x 9 sprite pixels. flap = 0/1. */
    static void drawParrot(Canvas c, Paint p, float x, float y, int s, int flap) {
        p.setStyle(Paint.Style.FILL);
        r(c, p, x, y, s, 1, 3, 4, 5, 0xFF3DBE5A, false, 6);   // body
        r(c, p, x, y, s, 3, 5, 1, 3, 0xFFF2D94A, false, 6);   // belly
        r(c, p, x, y, s, 0, 4 - flap, 2, 4, 0xFF1F8A3A, false, 6); // wing
        r(c, p, x, y, s, 1, 8, 2, 1, 0xFFE0405A, false, 6);   // tail
        r(c, p, x, y, s, 2, 0, 3, 3, 0xFF3DBE5A, false, 6);   // head
        r(c, p, x, y, s, 2, 0, 3, 1, 0xFFE0405A, false, 6);   // red cap
        r(c, p, x, y, s, 3, 1, 1, 1, 0xFF000000, false, 6);   // eye
        r(c, p, x, y, s, 5, 1, 1, 2, 0xFFF29A2E, false, 6);   // beak
        r(c, p, x, y, s, 2, 9, 3, 0, 0xFFF29A2E, false, 6);
    }
}
