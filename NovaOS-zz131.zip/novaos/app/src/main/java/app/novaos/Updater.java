package app.novaos;

import android.net.Uri;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * One-tap updates. Looks at the newest NOVA release on GitHub, downloads its APK
 * and hands it to Android's installer. Android still asks you to confirm the install.
 */
final class Updater {
    static final String REPO = "nicolasboupn-blip/nova-os";
    private static final String API = "https://api.github.com/repos/" + REPO + "/releases/latest";

    private Updater() {}

    /** Checks for a newer build. Shows the result in status. Runs off the main thread. */
    static void check(final NovaActivity host, final TextView status) {
        status.setText("checking...");
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                if (!token().isEmpty()) {
                    c.setRequestProperty("Authorization", "Bearer " + token());
                }
                c.setConnectTimeout(15000);
                c.setReadTimeout(15000);
                int code = c.getResponseCode();
                if (code == 404 && token().isEmpty()) {
                    throw new Exception("GitHub says 404. If the repo is private NOVA cannot see it: add a GitHub token "
                            + "below, or use INSTALL UPDATE FROM A FILE");
                }
                if (code == 401 || code == 403 || code == 404) {
                    throw new Exception("GitHub answered " + code + " - check the token (it needs read access to the repo)");
                }
                if (code != 200) {
                    throw new Exception("GitHub answered " + code);
                }
                JSONObject rel = new JSONObject(readAll(c.getInputStream()));
                String tag = rel.optString("tag_name", "");
                final long latest = buildOf(tag);
                final int current = currentBuild(host);
                if (latest <= current) {
                    post(host, status, "up to date (build " + current + ")");
                    return;
                }

                String url = null;
                JSONArray assets = rel.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length() && url == null; i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.optString("name").endsWith(".apk")) {
                            url = token().isEmpty() ? a.getString("browser_download_url") : a.getString("url");
                        }
                    }
                }
                if (url == null) {
                    throw new Exception("no APK in " + tag);
                }

                post(host, status, "downloading build " + latest + "...");
                File dir = new File(host.getCacheDir(), "updates");
                dir.mkdirs();
                File apk = new File(dir, "nova-update.apk");
                download(url, apk);

                host.runOnUiThread(() -> {
                    status.setText("installing build " + latest + "...");
                    try {
                        Installer.install(host, new java.io.FileInputStream(apk));
                    } catch (Exception e) {
                        status.setText("update failed: " + e.getMessage());
                    }
                });
            } catch (Exception e) {
                post(host, status, "update failed: " + e.getMessage());
            }
        }).start();
    }

    private static void post(NovaActivity host, TextView status, String text) {
        host.runOnUiThread(() -> status.setText(text));
    }

    /** "nova-12" -> 12. Returns 0 if the tag has no number. */
    static long buildOf(String tag) {
        String digits = tag.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) {
            return 0L;
        }
        try {
            return Long.parseLong(digits);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** {newest build number, APK download url} from GitHub. For the automatic updater (no screen). */
    static Object[] latest() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
        c.setRequestProperty("Accept", "application/vnd.github+json");
        if (!token().isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + token());
        }
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        int code = c.getResponseCode();
        if (code != 200) {
            throw new Exception("GitHub answered " + code);
        }
        JSONObject rel = new JSONObject(readAll(c.getInputStream()));
        long latest = buildOf(rel.optString("tag_name", ""));
        JSONArray assets = rel.optJSONArray("assets");
        if (assets != null) {
            for (int i = 0; i < assets.length(); i++) {
                JSONObject a = assets.getJSONObject(i);
                if (a.optString("name").endsWith(".apk")) {
                    return new Object[] {latest, token().isEmpty() ? a.getString("browser_download_url") : a.getString("url")};
                }
            }
        }
        throw new Exception("no APK in the newest release");
    }

    static int currentBuild(android.content.Context host) {
        try {
            return host.getPackageManager().getPackageInfo(host.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream src = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = src.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        }
    }

    static String token() {
        return Prefs.getString("gh_token", "").trim();
    }

    static void download(String url, File target) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        if (!token().isEmpty()) {
            // a private repo: ask the API for the file with the token, then follow its redirect WITHOUT the token
            c.setRequestProperty("Authorization", "Bearer " + token());
            c.setRequestProperty("Accept", "application/octet-stream");
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                c = (HttpURLConnection) new URL(loc).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(60000);
            } else if (code != 200) {
                throw new Exception("download answered " + code);
            }
        } else {
            c.setInstanceFollowRedirects(true);
        }
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
    }
}
