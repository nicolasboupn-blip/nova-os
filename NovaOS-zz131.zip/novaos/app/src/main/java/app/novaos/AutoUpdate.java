package app.novaos;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;
import android.os.PowerManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * AUTO-UPDATE: every few hours NOVA asks GitHub for a newer build. If there is one it downloads it and installs it by
 * itself. On Android 12+ an app may update itself without the "Install?" screen; if the phone still wants a tap, NOVA
 * shows a notification instead. It never installs while you are using NOVA: it waits until the screen is off or you
 * are in another app.
 */
final class AutoUpdate {
    static final String K_ON = "auto_update";
    static final String K_WIFI = "auto_update_wifi";
    static final String K_EVERY = "auto_update_every";
    static final String K_LAST = "auto_update_last";
    static final String K_STATE = "auto_update_state";
    static final String K_FROM = "auto_update_from";
    static final int[] HOURS = {1, 3, 6, 12, 24};
    private static final int JOB_PERIODIC = 7713;
    private static final int JOB_NOW = 7714;
    private static final String CHANNEL = "nova_updates";
    private static volatile boolean busy;

    private AutoUpdate() {
    }

    static boolean on() {
        return Prefs.getBool(K_ON, true);
    }

    /** Sets up (or cancels) the repeating check to match the settings. Safe to call often. */
    static void schedule(Context c) {
        try {
            Prefs.init(c);
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) {
                return;
            }
            if (!on()) {
                js.cancel(JOB_PERIODIC);
                js.cancel(JOB_NOW);
                return;
            }
            long every = HOURS[Math.max(0, Math.min(HOURS.length - 1, Prefs.getInt(K_EVERY, 1)))] * 3600000L;
            JobInfo old = js.getPendingJob(JOB_PERIODIC);
            int net = Prefs.getBool(K_WIFI, true) ? JobInfo.NETWORK_TYPE_UNMETERED : JobInfo.NETWORK_TYPE_ANY;
            if (old != null && old.getIntervalMillis() == every && old.getNetworkType() == net) {
                return;
            }
            js.schedule(new JobInfo.Builder(JOB_PERIODIC, new ComponentName(c, Job.class))
                    .setRequiredNetworkType(net)
                    .setPeriodic(every)
                    .setPersisted(true)
                    .build());
        } catch (RuntimeException ignored) {
            // the phone said no: the CHECK FOR UPDATE button still works
        }
    }

    /** One check as soon as the network allows (when NOVA opens and the last check is old). */
    static void checkSoon(Context c) {
        try {
            if (!on()) {
                return;
            }
            long every = HOURS[Math.max(0, Math.min(HOURS.length - 1, Prefs.getInt(K_EVERY, 1)))] * 3600000L;
            if (System.currentTimeMillis() - lastAt() < every) {
                return;
            }
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            js.schedule(new JobInfo.Builder(JOB_NOW, new ComponentName(c, Job.class))
                    .setRequiredNetworkType(Prefs.getBool(K_WIFI, true) ? JobInfo.NETWORK_TYPE_UNMETERED
                            : JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(20000)
                    .build());
        } catch (RuntimeException ignored) {
            // later
        }
    }

    /** Called when NOVA starts: says "updated to x" once after an automatic update. */
    static void greet(NovaActivity host) {
        int from = Prefs.getInt(K_FROM, 0);
        if (from <= 0) {
            return;
        }
        int now = Updater.currentBuild(host);
        Prefs.putInt(K_FROM, 0);
        if (now > from) {
            String name = "";
            try {
                name = host.getPackageManager().getPackageInfo(host.getPackageName(), 0).versionName;
            } catch (Exception ignored) {
                // no name
            }
            host.toast("NOVA updated itself to " + name + " ✨");
        }
    }

    private static long lastAt() {
        try {
            return Long.parseLong(Prefs.getString(K_LAST, "0"));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    static String lastText() {
        long last = lastAt();
        String state = Prefs.getString(K_STATE, "");
        if (last <= 0) {
            return "Not checked yet";
        }
        return "Last check " + new java.text.SimpleDateFormat("EEE HH:mm", java.util.Locale.getDefault())
                .format(new java.util.Date(last)) + (state.isEmpty() ? "" : ": " + state);
    }

    /** True while the person is looking at NOVA, so an install now would throw them out. */
    private static boolean inUse(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return NovaActivity.visible && pm != null && pm.isInteractive();
    }

    /** The background check. Returns true when it should be tried again soon (NOVA was in use). */
    static boolean run(Context c) {
        if (busy) {
            return false;
        }
        busy = true;
        try {
            Prefs.init(c);
            Object[] rel = Updater.latest();
            long latest = (long) rel[0];
            int current = Updater.currentBuild(c);
            Prefs.putString(K_LAST, String.valueOf(System.currentTimeMillis()));
            if (latest <= current) {
                Prefs.putString(K_STATE, "up to date");
                return false;
            }
            File dir = new File(c.getCacheDir(), "updates");
            dir.mkdirs();
            File apk = new File(dir, "nova-auto-" + latest + ".apk");
            if (!apk.exists() || apk.length() < 100000) {
                Prefs.putString(K_STATE, "downloading build " + latest);
                File part = new File(dir, "nova-auto.part");
                Updater.download((String) rel[1], part);
                if (!part.renameTo(apk)) {
                    throw new Exception("could not save the download");
                }
            }
            if (inUse(c)) {
                Prefs.putString(K_STATE, "build " + latest + " ready, installs when you leave NOVA");
                return true;
            }
            Prefs.putString(K_STATE, "installing build " + latest);
            Prefs.putInt(K_FROM, current);
            install(c, apk);
            return false;
        } catch (Exception e) {
            Prefs.putString(K_STATE, "failed: " + e.getMessage());
            return false;
        } finally {
            busy = false;
        }
    }

    private static void install(Context c, File apk) throws Exception {
        if (Build.VERSION.SDK_INT >= 26 && !c.getPackageManager().canRequestPackageInstalls()) {
            Prefs.putInt(K_FROM, 0);
            Prefs.putString(K_STATE, "NOVA is not allowed to install apps (Settings > Apps > NOVA > Install unknown apps)");
            return;
        }
        PackageInstaller pi = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(c.getPackageName());
        if (Build.VERSION.SDK_INT >= 31) {
            sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        }
        int id = pi.createSession(sp);
        try (PackageInstaller.Session session = pi.openSession(id)) {
            try (InputStream in = new FileInputStream(apk); OutputStream out = session.openWrite("nova.apk", 0, apk.length())) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                session.fsync(out);
            }
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pend = PendingIntent.getBroadcast(c, 7715, new Intent(c, Result.class), flags);
            session.commit(pend.getIntentSender());
        }
    }

    private static void notifyTap(Context c, Intent confirm) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "NOVA updates",
                        NotificationManager.IMPORTANCE_DEFAULT));
            }
            confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent open = PendingIntent.getActivity(c, 7716, confirm,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL)
                    : new Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("NOVA update ready")
                    .setContentText("Tap to install the new NOVA")
                    .setContentIntent(open)
                    .setAutoCancel(true);
            nm.notify(7716, b.build());
        } catch (RuntimeException ignored) {
            // no notifications allowed
        }
    }

    /** Runs the check off the main thread. */
    public static final class Job extends JobService {
        @Override
        public boolean onStartJob(final JobParameters params) {
            new Thread(() -> {
                boolean again = run(getApplicationContext());
                if (again) {
                    // NOVA was in use: try again in a while
                    try {
                        JobScheduler js = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
                        js.schedule(new JobInfo.Builder(JOB_NOW, new ComponentName(this, Job.class))
                                .setMinimumLatency(15 * 60000L)
                                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                                .build());
                    } catch (RuntimeException ignored) {
                        // next periodic run
                    }
                }
                jobFinished(params, false);
            }, "nova-autoupdate").start();
            return true;
        }

        @Override
        public boolean onStopJob(JobParameters params) {
            return true;
        }
    }

    /** What Android says about the install. */
    public static final class Result extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            Prefs.init(c);
            int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
            if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                if (confirm == null) {
                    return;
                }
                Prefs.putString(K_STATE, "waiting for you to tap install");
                if (NovaActivity.visible) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        c.startActivity(confirm);
                        return;
                    } catch (RuntimeException ignored) {
                        // fall back to the notification
                    }
                }
                notifyTap(c, confirm);
                return;
            }
            if (status == PackageInstaller.STATUS_SUCCESS) {
                Prefs.putString(K_STATE, "updated");
            } else {
                Prefs.putInt(K_FROM, 0);
                String m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                Prefs.putString(K_STATE, "install failed" + (m == null ? "" : ": " + m));
            }
        }
    }

    /** After a phone restart or a NOVA update, set the check up again. */
    public static final class Boot extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            schedule(c);
        }
    }
}
