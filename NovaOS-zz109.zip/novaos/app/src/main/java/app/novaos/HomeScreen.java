package app.novaos;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.view.DragEvent;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Two home pages. Page one: clock, the switchable panel, your first pinned apps and the dock.
 * Page two: the rest of your pinned apps. Swipe sideways to move between them, swipe up for the app drawer,
 * long-press an empty spot to draw a gesture. After an unlock it plays a short welcome animation.
 */
final class HomeScreen extends FrameLayout {
    private int COLUMNS = Upgrades.gridCols();
    static final int PAGE_ONE_APPS = 8;

    private final NovaActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Handler introHandler = new Handler(Looper.getMainLooper());
    private final TextView battery;
    private final android.view.GestureDetector swipe;
    private final int slop;
    private ValueAnimator nameGlow;

    // tilt parallax: layers that slide a little when you tilt the phone
    private final List<View> plxViews = new ArrayList<>();
    private final List<Float> plxFactors = new ArrayList<>();
    private Parallax parallax;

    // drawing on the background
    private DrawLayer drawLayer;
    private CastleView castleView;
    private DancerView dancer;
    private final List<View> cellViews = new ArrayList<>();
    /** Edit mode: icons wiggle, and widgets can be added, moved, resized and removed. Set from Settings. */
    static boolean editing;
    /** Which page to open on after the home screen rebuilds itself (after a drag or a widget change). */
    static int restorePage;
    /** Widgets placed on the home screen, in order. */
    private final List<Widgets.Placed> placed = Widgets.load();
    // shown while an app is being dragged: remove bar at the top, page-flip strips on the edges
    private View removeZone;
    private View edgeLeft;
    private View edgeRight;
    private int flipTarget;
    /** True while an app is being dragged: both pages stay visible so either can take the drop. */
    private boolean appDrag;
    private final Runnable flip = this::doFlip;

    private void doFlip() {
        if (flipTarget != pageIndex) {
            settleTo(flipTarget, 280);
            host.buzz(15);
            showEdges();
        }
    }
    private final List<Animator> wiggles = new ArrayList<>();
    private final java.util.Random prankRnd = new java.util.Random();
    private final Runnable prank = new Runnable() {
        @Override
        public void run() {
            doPrank();
            handler.postDelayed(this, 150000 + prankRnd.nextInt(250000));
        }
    };

    /** Now and then an icon wobbles, hops, flips or shyly slides away and back. Tapping it still opens the app. */
    void prankNow() {
        doPrank(true);
    }

    private void doPrank() {
        doPrank(false);
    }

    private void doPrank(boolean force) {
        if ((!force && (!Prefs.pranks() || Saver.on() || !host.homeIdle())) || cellViews.isEmpty() || pageIndex != 0
                || drawMode || introRunning || dragging) {
            return;
        }
        final View v = cellViews.get(prankRnd.nextInt(cellViews.size()));
        if (v.getWidth() == 0 || v.getAlpha() < 0.9f || v.getParent() == null) {
            return;
        }
        Sfx.play(Sfx.BLIP);
        switch (prankRnd.nextInt(4)) {
            case 0:
                android.animation.ObjectAnimator.ofFloat(v, View.ROTATION, 0f, -14f, 14f, -10f, 10f, -4f, 0f)
                        .setDuration(900).start();
                break;
            case 1:
                v.animate().translationY(-Theme.dp(host, 26)).setDuration(220).withEndAction(() ->
                        v.animate().translationY(0f).setDuration(520)
                                .setInterpolator(new android.view.animation.BounceInterpolator()).start()).start();
                break;
            case 2:
                v.animate().rotationYBy(360f).setDuration(750).start();
                break;
            default: {
                final float side = (v.getLeft() + v.getWidth() / 2f < getWidth() / 2f ? 1 : -1) * Theme.dp(host, 54);
                v.animate().translationX(side).setDuration(260).withEndAction(() ->
                        v.postDelayed(() -> v.animate().translationX(0f).setDuration(380)
                                .setInterpolator(new android.view.animation.OvershootInterpolator()).start(), 1300))
                        .start();
                break;
            }
        }
    }
    private LinearLayout drawBar;
    private boolean drawMode;

    private LinearLayout page1;
    private LinearLayout page2;
    private StatusPanel panel;
    private final View[] pageDots = new View[2];

    // sideways paging
    private float progress;       // 0 = page one, 1 = page two, in between while dragging
    private int pageIndex;
    private float downX, downY;
    private boolean tracking;
    private boolean dragging;
    private VelocityTracker velocity;
    private ValueAnimator settle;

    // welcome animation
    private final List<View> early = new ArrayList<>();
    private final List<View> late = new ArrayList<>();
    private boolean introWanted;
    private boolean introStarted;
    private boolean introRunning;
    private TextView welcome;
    private ValueAnimator welcomeGlow;
    private ValueAnimator welcomeSpacing;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refreshBattery();
            handler.postDelayed(this, 30000);
        }
    };

    HomeScreen(final NovaActivity host) {
        super(host);
        this.host = host;
        this.slop = ViewConfiguration.get(host).getScaledTouchSlop();
        introWanted = host.takeIntro();
        setClipChildren(false);
        int side = Theme.dp(host, 24);

        // code wallpaper behind everything, typing itself at the chosen opacity
        if (Prefs.homeCode()) {
            CodeWallpaper code = new CodeWallpaper(host, true);
            code.setAlpha(Theme.wallAlpha());
            code.setPadding(side, Theme.dp(host, 44), side, 0);
            addView(code, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            plx(code, 0.7f, 1.08f);
        }
        if (Prefs.liveWall() > 0 && !Saver.on()) {
            LiveWallpaper live = new LiveWallpaper(host, Prefs.liveWall());
            addView(live, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            plx(live, 1f, 1.12f);
        }
        addView(new EdgeGlow(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        // your drawing lives here: above the wallpaper, behind the clock, panel and icons
        drawLayer = new DrawLayer(host);
        addView(drawLayer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        plx(drawLayer, 0.5f, 1f);

        if (Prefs.castle()) {
            castleView = new CastleView(host);
            addView(castleView, castleView.params());
        }
        if (Prefs.getBool("s_dancer", true)) {
            dancer = new DancerView(host);
            addView(dancer, dancer.params());
        }

        host.repo.ensureFresh();
        List<AppEntry> pinned = new ArrayList<>();
        for (String pkg : host.favs()) {
            AppEntry e = host.repo.find(pkg);
            if (e != null) {
                pinned.add(e);
            }
        }
        List<AppEntry> first = pinned.subList(0, Math.min(PAGE_ONE_APPS, pinned.size()));
        List<AppEntry> rest = pinned.size() > PAGE_ONE_APPS
                ? pinned.subList(PAGE_ONE_APPS, pinned.size()) : new ArrayList<AppEntry>();

        // ------------------------------------------------------------ page one
        page1 = new LinearLayout(host);
        page1.setOrientation(LinearLayout.VERTICAL);
        page1.setClipChildren(false);
        page1.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        addView(page1, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout status = new LinearLayout(host);
        status.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = mono(Theme.OS_NAME, 12f, Theme.ACCENT);
        name.setLetterSpacing(0.3f);
        nameGlow = Theme.glow(name);
        battery = mono("", 12f, Theme.DIM);
        status.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        status.addView(battery);
        page1.addView(status);
        late.add(status);

        // home layout: where the clock block sits (0 top, 1 middle, 2 bottom)
        int clockAt = Math.max(0, Math.min(2, Prefs.getInt("home_clock", 0)));
        if (clockAt != 0) {
            page1.addView(new View(host), new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        NovaClock clock = new NovaClock(host, 1f);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.topMargin = Theme.dp(host, 28) - clock.pad;
        clp.leftMargin = -clock.pad;
        clp.bottomMargin = -clock.pad + Theme.dp(host, 2);
        page1.addView(clock, clp);
        early.add(clock);
        plx(clock, -0.35f, 1f);

        TextClock date = new TextClock(host);
        date.setFormat12Hour("EEEE d MMMM");
        date.setFormat24Hour("EEEE d MMMM");
        date.setTextSize(15f);
        date.setTextColor(Theme.DIM);
        page1.addView(date);
        early.add(date);
        plx(date, -0.35f, 1f);

        if (NameTag.on()) {
            NameTag tag = new NameTag(host);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tlp.topMargin = Theme.dp(host, 8);
            page1.addView(tag, tlp);
            early.add(tag);
            plx(tag, -0.25f, 1f);
        }

        if (Prefs.systemPanel()) {
            panel = new StatusPanel(host);
            panel.onPage = p -> {
                int vis = StatusPanel.hidesClock(p) ? View.INVISIBLE : View.VISIBLE;
                clock.setVisibility(vis);
                date.setVisibility(vis);
            };
            panel.onPage.accept(panel.page());
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            plp.topMargin = Theme.dp(host, 22);
            page1.addView(panel, plp);
            late.add(panel);
        }
        View area1 = widgetArea(0);
        if (area1 == null) {
            page1.addView(new View(host), new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, clockAt == 2 ? 0f : 1f));
        } else {
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
            alp.topMargin = Theme.dp(host, 10);
            alp.bottomMargin = Theme.dp(host, 6);
            page1.addView(area1, alp);
        }

        if (first.isEmpty()) {
            TextView empty = mono("Long-press an app in the drawer to pin it here.", 12f, Theme.DIM);
            LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            elp.bottomMargin = Theme.dp(host, 20);
            page1.addView(empty, elp);
            late.add(empty);
        } else {
            View rows = grid(first);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = Theme.dp(host, 20);
            page1.addView(rows, rlp);
            late.add(rows);
        }
        View dock1 = dock();
        page1.addView(dock1, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        late.add(dock1);

        // ------------------------------------------------------------ page two
        page2 = new LinearLayout(host);
        page2.setOrientation(LinearLayout.VERTICAL);
        page2.setClipChildren(false);
        page2.setPadding(side, Theme.dp(host, 44), side, Theme.dp(host, 28));
        addView(page2, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView p2name = mono("PAGE 2", 12f, Theme.ACCENT);
        p2name.setLetterSpacing(0.3f);
        page2.addView(p2name);
        View area2 = widgetArea(1);
        if (area2 != null) {
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
            ap.topMargin = Theme.dp(host, 12);
            page2.addView(area2, ap);
        }
        if (rest.isEmpty()) {
            if (area2 == null) {
                TextView hint = mono("Nothing here yet.\n\nPin more than " + PAGE_ONE_APPS
                        + " apps (long-press one in the\ndrawer) and the extra ones land on this page."
                        + "\n\nWidgets: Settings > EDIT HOME.", 12f, Theme.DIM);
                hint.setGravity(Gravity.CENTER);
                page2.addView(hint, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            }
        } else {
            LinearLayout.LayoutParams gp = area2 == null
                    ? new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
                    : new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
            gp.topMargin = Theme.dp(host, area2 == null ? 24 : 8);
            gp.bottomMargin = Theme.dp(host, area2 == null ? 0 : 12);
            LinearLayout holder = new LinearLayout(host);
            holder.setOrientation(LinearLayout.VERTICAL);
            holder.setClipChildren(false);
            holder.addView(grid(rest));
            page2.addView(holder, gp);
        }
        page2.addView(dock(), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        page1.setOnDragListener((v, ev) -> pageDrop(ev, 0));
        page2.setOnDragListener((v, ev) -> pageDrop(ev, 1));

        // little page dots, top center
        LinearLayout dots = new LinearLayout(host);
        for (int i = 0; i < 2; i++) {
            pageDots[i] = new View(host);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Theme.dp(host, 5), Theme.dp(host, 5));
            dp.setMargins(Theme.dp(host, 3), 0, Theme.dp(host, 3), 0);
            dots.addView(pageDots[i], dp);
        }
        LayoutParams dlp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        dlp.topMargin = Theme.dp(host, 50);
        addView(dots, dlp);
        if (restorePage == 1) {
            pageIndex = 1;
            progress = 1f;
        }
        restorePage = 0;
        showDots();
        buildDrawBar();
        addView(new EventLayer(host), new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        if (editing) {
            addView(editBanner());
        }
        buildDragZones();

        swipe = new android.view.GestureDetector(host,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                        if (!dragging && e1 != null && e2 != null
                                && e1.getY() - e2.getY() > Theme.dp(host, 80) && Math.abs(vy) > 600
                                && Math.abs(vy) > Math.abs(vx)) {
                            host.showDrawer();
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public boolean onSingleTapUp(MotionEvent e) {
                        if (dancer != null && !drawMode && !introRunning && pageIndex == 0
                                && dancer.hit(e.getRawX(), e.getRawY())) {
                            return true;
                        }
                        if (castleView != null && !drawMode && !introRunning && pageIndex == 0
                                && castleView.pokeVisitor(e.getRawX(), e.getRawY())) {
                            return true;
                        }
                        if (castleView != null && !drawMode && !introRunning && pageIndex == 0
                                && castleView.pokeDragon(e.getRawX(), e.getRawY())) {
                            return true;
                        }
                        if (castleView != null && !drawMode && !introRunning && pageIndex == 0
                                && castleView.hit(e.getRawX(), e.getRawY())) {
                            host.castleTapped();
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        if (Prefs.drawOn() && !dragging && !introRunning) {
                            setDrawMode(true);
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onLongPress(MotionEvent e) {
                        if (!dragging && !introRunning && !drawMode) {
                            host.buzz(25);
                            host.showOverlay(new GestureLayer(host));
                        }
                    }
                });

        refreshBattery();
        if (introWanted) {
            prepareIntro();
        }
    }

    // ---------------------------------------------------------------- building blocks

    /** A 4-column grid of app icons. */
    private View grid(List<AppEntry> apps) {
        LinearLayout rows = new LinearLayout(host);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setClipChildren(false);
        LinearLayout row = null;
        int n = 0;
        for (AppEntry e : apps) {
            if (n % COLUMNS == 0) {
                row = new LinearLayout(host);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                rows.addView(row, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            }
            row.addView(cell(e), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            n++;
        }
        while (n % COLUMNS != 0) {
            row.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
            n++;
        }
        return rows;
    }

    /** Top bar in edit mode with a DONE button. */
    private View editBanner() {
        LinearLayout b = new LinearLayout(host);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        b.setPadding(Theme.dp(host, 12), Theme.dp(host, 8), Theme.dp(host, 8), Theme.dp(host, 8));
        b.addView(mono("EDIT HOME: hold & drag apps\n◀ ▶ move  ⤢ size  ⇅ page  ✕ remove", 10f, Theme.TEXT),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView add = mono("+ WIDGET", 12f, Theme.BG);
        add.setBackground(Theme.rounded(Theme.ACCENT, 12f, host));
        add.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), Theme.dp(host, 10), Theme.dp(host, 6));
        add.setClickable(true);
        add.setOnClickListener(v -> addWidget(pageIndex));
        b.addView(add);
        TextView done = mono("DONE", 12f, Theme.ACCENT);
        done.setPadding(Theme.dp(host, 10), Theme.dp(host, 6), Theme.dp(host, 6), Theme.dp(host, 6));
        done.setClickable(true);
        done.setOnClickListener(v -> {
            editing = false;
            host.showHome();
        });
        b.addView(done);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP);
        lp.topMargin = Theme.dp(host, 36);
        lp.leftMargin = lp.rightMargin = Theme.dp(host, 12);
        b.setLayoutParams(lp);
        return b;
    }

    private View dock() {
        LinearLayout dock = new LinearLayout(host);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setBackground(Theme.rounded(Theme.PANEL, 22f, host));
        dock.setPadding(Theme.dp(host, 6), Theme.dp(host, 4), Theme.dp(host, 6), Theme.dp(host, 4));
        dock.addView(dockButton("APPS", v -> host.showDrawer()), weight());
        dock.addView(dockButton("NOTES", v -> host.showNotes()), weight());
        dock.addView(dockButton("TERMINAL", v -> host.showTerminal()), weight());
        dock.addView(dockButton("SETUP", v -> host.showSettings()), weight());
        if (NovaNet.ENABLED && Upgrades.has("dock5")) {
            dock.addView(dockButton("NET", v -> NetScreen.open(host)), weight());
        }
        return dock;
    }

    private View cell(final AppEntry e) {
        LinearLayout c = new LinearLayout(host);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setClipChildren(false);
        c.setPadding(Theme.dp(host, 2), Theme.dp(host, 8), Theme.dp(host, 2), Theme.dp(host, 8));

        final ImageView icon = Prefs.holo() && !Saver.on() ? new HoloIcon(host) : new ImageView(host);
        icon.setImageDrawable(Theme.tint(host, e.icon));
        int size = Math.max(0, Math.min(2, Prefs.getInt("icon_size", 0)));
        int isz = (COLUMNS >= 5 ? 48 : 58) + new int[] {0, -10, 10}[size];
        Upgrades.shapeIcon(icon);
        c.addView(icon, new LinearLayout.LayoutParams(Theme.dp(host, isz), Theme.dp(host, isz)));

        TextView t = new TextView(host);
        t.setText(e.label);
        t.setTextSize(11f);
        t.setTextColor(Theme.TEXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Theme.dp(host, 6);
        c.addView(t, tlp);

        cellViews.add(c);
        c.setTag(e.pkg);
        c.setOnClickListener(v -> {
            if (!editing) {
                host.launch(e);
            }
        });
        c.setOnLongClickListener(v -> {
            startAppDrag(v, e);
            return true;
        });
        c.setOnDragListener((v, ev) -> {
            switch (ev.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return isNovaDrag(ev);
                case DragEvent.ACTION_DRAG_ENTERED:
                    v.animate().scaleX(1.12f).scaleY(1.12f).setDuration(120).start();
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                case DragEvent.ACTION_DRAG_ENDED:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    return true;
                case DragEvent.ACTION_DROP: {
                    String from = dragged(ev);
                    if (!from.isEmpty() && !from.equals(e.pkg)) {
                        host.moveFav(from, e.pkg);
                        rebuild(pageIndex);
                    }
                    return true;
                }
                default:
                    return true;
            }
        });
        if (editing) {
            ObjectAnimator w = ObjectAnimator.ofFloat(c, View.ROTATION, -2.5f, 2.5f);
            w.setDuration(120 + prankRnd.nextInt(60));
            w.setRepeatMode(ValueAnimator.REVERSE);
            w.setRepeatCount(ValueAnimator.INFINITE);
            w.setStartDelay(prankRnd.nextInt(150));
            w.start();
            wiggles.add(w);
        }
        // a touch makes the icon's particles burst outward
        c.setOnTouchListener((v, ev) -> {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && Prefs.touchGlow()) {
                Drawable d = icon.getDrawable();
                if (d instanceof ParticleGlow) {
                    ((ParticleGlow) d).burst();
                }
            }
            return false;
        });
        return c;
    }

    // ---------------------------------------------------------------- dragging apps

    private static boolean isNovaDrag(DragEvent ev) {
        return ev.getClipDescription() != null && "nova".contentEquals(ev.getClipDescription().getLabel());
    }

    private static String dragged(DragEvent ev) {
        if (ev.getClipData() == null || ev.getClipData().getItemCount() == 0) {
            return "";
        }
        CharSequence t = ev.getClipData().getItemAt(0).getText();
        return t == null ? "" : t.toString();
    }

    /** Long-press an app: it lifts off and follows your finger. */
    private void startAppDrag(View v, AppEntry e) {
        if (introRunning || drawMode) {
            return;
        }
        host.buzz(25);
        appDrag = true;
        page1.setVisibility(VISIBLE);
        page2.setVisibility(VISIBLE);
        showDragZones(true);
        boolean ok = v.startDragAndDrop(ClipData.newPlainText("nova", e.pkg), new View.DragShadowBuilder(v), null, 0);
        if (!ok) {
            showDragZones(false);
        }
    }

    private boolean pageDrop(DragEvent ev, int page) {
        switch (ev.getAction()) {
            case DragEvent.ACTION_DRAG_STARTED:
                return isNovaDrag(ev);
            case DragEvent.ACTION_DROP: {
                String pkg = dragged(ev);
                if (!pkg.isEmpty()) {
                    dropOnPage(page, pkg);
                }
                return true;
            }
            default:
                return true;
        }
    }

    /** Dropped on empty space: the app goes to the last spot of that page. */
    private void dropOnPage(int page, String pkg) {
        List<String> favs = host.favs();
        if (!favs.contains(pkg)) {
            return;
        }
        int idx = page == 0 ? Math.min(PAGE_ONE_APPS - 1, favs.size() - 1) : favs.size() - 1;
        host.moveFavTo(pkg, idx);
        rebuild(page);
    }

    private void buildDragZones() {
        TextView rm = mono("✕   REMOVE FROM HOME", 12f, Theme.TEXT);
        rm.setGravity(Gravity.CENTER);
        rm.setLetterSpacing(0.1f);
        rm.setBackground(Theme.rounded(0xE6B3263A, 16f, host));
        rm.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        rm.setElevation(Theme.dp(host, 8));
        rm.setVisibility(GONE);
        rm.setOnDragListener((v, ev) -> {
            switch (ev.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return isNovaDrag(ev);
                case DragEvent.ACTION_DRAG_ENTERED:
                    v.setScaleX(1.04f);
                    v.setScaleY(1.04f);
                    host.buzz(10);
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                    v.setScaleX(1f);
                    v.setScaleY(1f);
                    return true;
                case DragEvent.ACTION_DROP: {
                    AppEntry a = host.repo.find(dragged(ev));
                    if (a != null) {
                        post(() -> host.confirmUnpin(a));
                    }
                    return true;
                }
                case DragEvent.ACTION_DRAG_ENDED:
                    showDragZones(false);
                    return true;
                default:
                    return true;
            }
        });
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP);
        lp.topMargin = Theme.dp(host, 36);
        lp.leftMargin = lp.rightMargin = Theme.dp(host, 12);
        addView(rm, lp);
        removeZone = rm;
        edgeLeft = edge(Gravity.START, 0);
        edgeRight = edge(Gravity.END, 1);
    }

    /** A strip on the side of the screen: hold an app over it and the other page slides in. */
    private View edge(int gravity, final int target) {
        View z = new View(host);
        z.setBackground(Theme.rounded((Theme.ACCENT & 0xFFFFFF) | 0x40000000, 10f, host));
        z.setVisibility(GONE);
        z.setOnDragListener((v, ev) -> {
            switch (ev.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return isNovaDrag(ev);
                case DragEvent.ACTION_DRAG_ENTERED:
                    handler.removeCallbacks(flip);
                    flipTarget = target;
                    handler.postDelayed(flip, 450);
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                    handler.removeCallbacks(flip);
                    return true;
                case DragEvent.ACTION_DROP: {
                    handler.removeCallbacks(flip);
                    String pkg = dragged(ev);
                    if (!pkg.isEmpty()) {
                        dropOnPage(target, pkg);
                    }
                    return true;
                }
                case DragEvent.ACTION_DRAG_ENDED:
                    handler.removeCallbacks(flip);
                    showDragZones(false);
                    return true;
                default:
                    return true;
            }
        });
        LayoutParams lp = new LayoutParams(Theme.dp(host, 24), LayoutParams.MATCH_PARENT, gravity);
        lp.topMargin = Theme.dp(host, 120);
        lp.bottomMargin = Theme.dp(host, 120);
        addView(z, lp);
        return z;
    }

    private void showDragZones(boolean on) {
        if (removeZone == null) {
            return;
        }
        int vis = on ? VISIBLE : GONE;
        if (!on && appDrag) {
            appDrag = false;
            applyProgress();
        }
        removeZone.setVisibility(vis);
        removeZone.setScaleX(1f);
        removeZone.setScaleY(1f);
        edgeLeft.setVisibility(vis);
        edgeRight.setVisibility(vis);
        if (on) {
            removeZone.bringToFront();
            edgeLeft.bringToFront();
            edgeRight.bringToFront();
            showEdges();
        }
    }

    /** Only the strip that leads to the other page shows; both stay in place so the drag keeps reaching them. */
    private void showEdges() {
        edgeLeft.setAlpha(pageIndex == 1 ? 1f : 0f);
        edgeRight.setAlpha(pageIndex == 0 ? 1f : 0f);
    }

    /** Builds the home screen again (after a change), staying on the given page. */
    private void rebuild(int page) {
        restorePage = page;
        post(() -> host.showHome());
    }

    // ---------------------------------------------------------------- widgets on the home screen

    /** The widgets of one page in a scrolling column, or null when there are none and we are not editing. */
    private View widgetArea(final int page) {
        List<Integer> mine = new ArrayList<>();
        for (int i = 0; i < placed.size(); i++) {
            if (placed.get(i).page == page) {
                mine.add(i);
            }
        }
        if (mine.isEmpty() && !editing) {
            return null;
        }
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        int gap = Theme.dp(host, 8);
        int k = 0;
        while (k < mine.size()) {
            Widgets.Placed a = placed.get(mine.get(k));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = gap;
            if (a.size == Widgets.HALF) {
                // two half widgets in a row share it side by side
                LinearLayout r = new LinearLayout(host);
                r.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                l.rightMargin = gap / 2;
                r.addView(frame(mine.get(k)), l);
                LinearLayout.LayoutParams rr = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                rr.leftMargin = gap / 2;
                if (k + 1 < mine.size() && placed.get(mine.get(k + 1)).size == Widgets.HALF) {
                    r.addView(frame(mine.get(k + 1)), rr);
                    k += 2;
                } else {
                    r.addView(new View(host), rr);
                    k++;
                }
                col.addView(r, rowLp);
            } else {
                col.addView(frame(mine.get(k)), rowLp);
                k++;
            }
        }
        if (editing) {
            TextView add = mono("+  ADD A WIDGET HERE", 12f, Theme.ACCENT);
            add.setGravity(Gravity.CENTER);
            add.setLetterSpacing(0.1f);
            add.setBackground(Theme.rounded(0x1AFFFFFF, 18f, host));
            add.setPadding(0, Theme.dp(host, 18), 0, Theme.dp(host, 18));
            add.setClickable(true);
            Theme.ripple(add);
            add.setOnClickListener(v -> addWidget(page));
            col.addView(add, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        sv.addView(col, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        return sv;
    }

    /** One placed widget in its card, with the edit buttons on top while editing. */
    private View frame(final int index) {
        final Widgets.Placed p = placed.get(index);
        LinearLayout f = new LinearLayout(host);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setBackground(Theme.rounded(Theme.PANEL, 18f, host));
        f.setPadding(Theme.dp(host, 10), Theme.dp(host, 8), Theme.dp(host, 10), Theme.dp(host, 10));

        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = mono(Widgets.title(p.id), 9f, Theme.ACCENT);
        t.setLetterSpacing(0.15f);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        if (editing) {
            head.addView(control("◀", () -> moveWidget(index, -1)));
            head.addView(control("▶", () -> moveWidget(index, 1)));
            head.addView(control("⤢", () -> {
                p.size = (p.size + 1) % 3;
                host.toast(Widgets.title(p.id) + ": " + Widgets.SIZE_NAMES[p.size]);
                saveWidgets(p.page);
            }));
            head.addView(control("⇅", () -> {
                p.page = 1 - p.page;
                host.toast("Moved to page " + (p.page + 1));
                saveWidgets(p.page);
            }));
            head.addView(control("✕", () -> {
                placed.remove(index);
                saveWidgets(p.page);
            }));
        }
        f.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout body = new FrameLayout(host);
        body.addView(Widgets.create(host, p.id), new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, (p.id.startsWith("mine") || p.id.equals("bus") || p.id.equals("busboard")) ? LayoutParams.WRAP_CONTENT : LayoutParams.MATCH_PARENT));
        if (editing) {
            // while editing the widget itself stays still, so the buttons above are what you press
            View block = new View(host);
            block.setClickable(true);
            body.addView(block, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                (p.id.startsWith("mine") || p.id.equals("bus") || p.id.equals("busboard")) ? LinearLayout.LayoutParams.WRAP_CONTENT
                        : Theme.dp(host, p.size == Widgets.BIG ? 336 : 168));
        blp.topMargin = Theme.dp(host, 4);
        f.addView(body, blp);
        return f;
    }

    private TextView control(String glyph, final Runnable action) {
        TextView c = mono(glyph, 13f, Theme.ACCENT);
        c.setGravity(Gravity.CENTER);
        c.setPadding(Theme.dp(host, 6), Theme.dp(host, 2), Theme.dp(host, 6), Theme.dp(host, 2));
        c.setClickable(true);
        Theme.ripple(c);
        c.setOnClickListener(v -> action.run());
        return c;
    }

    /** Swaps a widget with its neighbour on the same page. */
    private void moveWidget(int index, int dir) {
        int page = placed.get(index).page;
        int j = index + dir;
        while (j >= 0 && j < placed.size() && placed.get(j).page != page) {
            j += dir;
        }
        if (j < 0 || j >= placed.size()) {
            return;
        }
        Collections.swap(placed, index, j);
        saveWidgets(page);
    }

    private void saveWidgets(int page) {
        Widgets.save(placed);
        rebuild(page);
    }

    /** Pick a widget, then its size, and it lands at the end of the page. */
    private void addWidget(final int page) {
        final String[] ids = Widgets.placeIds();
        new android.app.AlertDialog.Builder(host)
                .setTitle("Add a widget to page " + (page + 1))
                .setItems(Widgets.placeTitles(), (d, which) -> new android.app.AlertDialog.Builder(host)
                        .setTitle("Size")
                        .setItems(new String[] {"HALF  ·  half the width, two side by side",
                            "WIDE  ·  full width", "BIG  ·  full width, twice as tall"}, (d2, size) -> {
                                placed.add(new Widgets.Placed(page, ids[which], size));
                                saveWidgets(page);
                            })
                        .show())
                .show();
    }

    // ---------------------------------------------------------------- paging

    private void showDots() {
        for (int i = 0; i < pageDots.length; i++) {
            pageDots[i].setBackground(Theme.rounded(i == pageIndex ? Theme.ACCENT : 0x44FFFFFF, 3f, host));
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        applyProgress();
    }

    private void applyProgress() {
        float w = getWidth();
        // the page you are not looking at is hidden, so its widgets pause their sensors and timers
        if (!appDrag) {
            page1.setVisibility(progress >= 0.999f ? INVISIBLE : VISIBLE);
            page2.setVisibility(progress <= 0.001f ? INVISIBLE : VISIBLE);
        }
        page1.setTranslationX(-progress * w);
        page2.setTranslationX((1f - progress) * w);
        page2.setAlpha(Math.max(0f, Math.min(1f, 0.35f + progress * 0.65f)));
        if (castleView != null) {
            castleView.setTranslationX(-progress * w);
            castleView.setAlpha(Math.max(0f, 1f - progress * 1.4f));
        }
        if (dancer != null) {
            dancer.follow(-progress * w, Math.max(0f, 1f - progress * 1.4f));
        }
    }

    /** Brings the panel into view on the given page. False if there is no panel. */
    boolean panelTo(int page) {
        if (panel == null) {
            return false;
        }
        if (pageIndex != 0) {
            settleTo(0, 280);
        }
        panel.jumpTo(page);
        return true;
    }

    private void settleTo(final int target, long ms) {
        if (settle != null) {
            settle.cancel();
        }
        pageIndex = target;
        showDots();
        settle = ValueAnimator.ofFloat(progress, target);
        settle.setDuration(ms);
        settle.setInterpolator(new DecelerateInterpolator(1.5f));
        settle.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            applyProgress();
        });
        settle.start();
    }

    // ---------------------------------------------------------------- tilt parallax

    /** Registers a layer for tilt movement. factor is how far it slides (negative = the other way). */
    private void plx(View v, float factor, float scale) {
        if (!Prefs.parallax() || Saver.on()) {
            return;
        }
        plxViews.add(v);
        plxFactors.add(factor);
        if (scale != 1f) {
            v.setScaleX(scale);
            v.setScaleY(scale);
        }
    }

    private void applyTilt(float nx, float ny) {
        HoloIcon.tiltX = nx;
        HoloIcon.tiltY = ny;
        float m = Theme.dp(host, 14);
        for (int i = 0; i < plxViews.size(); i++) {
            float f = plxFactors.get(i);
            plxViews.get(i).setTranslationX(nx * m * f);
            plxViews.get(i).setTranslationY(ny * m * f);
        }
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (plxViews.isEmpty()) {
            return;
        }
        if (parallax == null) {
            parallax = new Parallax(host, this::applyTilt);
        }
        if (visibility == VISIBLE) {
            parallax.start();
        } else {
            parallax.stop();
        }
    }

    // ---------------------------------------------------------------- drawing on the background

    private void buildDrawBar() {
        drawBar = new LinearLayout(host);
        drawBar.setGravity(Gravity.CENTER);
        drawBar.setBackground(Theme.rounded(0xF0100B1E, 22f, host));
        drawBar.setPadding(Theme.dp(host, 8), Theme.dp(host, 6), Theme.dp(host, 8), Theme.dp(host, 6));
        drawBar.setElevation(Theme.dp(host, 10));
        drawBar.addView(barButton("UNDO", () -> drawLayer.undo()));
        drawBar.addView(barButton("CLEAR", () -> drawLayer.clear()));
        drawBar.addView(barButton("DONE", () -> setDrawMode(false)));
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = Theme.dp(host, 14);
        addView(drawBar, lp);
        drawBar.setVisibility(GONE);
    }

    private TextView barButton(String text, final Runnable action) {
        TextView t = mono(text, 12f, Theme.ACCENT);
        t.setLetterSpacing(0.12f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Theme.dp(host, 16), Theme.dp(host, 10), Theme.dp(host, 16), Theme.dp(host, 10));
        t.setClickable(true);
        Theme.ripple(t);
        t.setOnClickListener(v -> action.run());
        return t;
    }

    private void setDrawMode(boolean on) {
        if (drawMode == on) {
            return;
        }
        drawMode = on;
        if (on) {
            host.tip("draw");
            host.buzz(30);
            drawBar.setAlpha(0f);
            drawBar.setVisibility(VISIBLE);
            drawBar.animate().alpha(1f).setDuration(220).start();
            host.toast("Draw anywhere. Press DONE when you are finished.");
        } else {
            drawBar.animate().alpha(0f).setDuration(180).withEndAction(() -> drawBar.setVisibility(GONE)).start();
        }
    }

    private boolean insideDrawBar(MotionEvent e) {
        if (drawBar == null || drawBar.getVisibility() != VISIBLE) {
            return false;
        }
        int[] at = new int[2];
        drawBar.getLocationOnScreen(at);
        float x = e.getRawX();
        float y = e.getRawY();
        return x >= at[0] && x <= at[0] + drawBar.getWidth() && y >= at[1] && y <= at[1] + drawBar.getHeight();
    }

    private boolean insidePanel(MotionEvent e) {
        if (panel == null || panel.getWidth() == 0) {
            return false;
        }
        int[] at = new int[2];
        panel.getLocationOnScreen(at);
        float x = e.getRawX();
        float y = e.getRawY();
        return x >= at[0] && x <= at[0] + panel.getWidth() && y >= at[1] && y <= at[1] + panel.getHeight();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        if (drawMode && e.getActionMasked() == MotionEvent.ACTION_DOWN && !insideDrawBar(e)) {
            return true; // in draw mode every touch becomes a line
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (introRunning) {
                    if (waitingTap) {
                        // this tap only carries the animation on, it must not press anything underneath
                        playRest();
                        return true;
                    }
                    finishIntro();
                }
                if (settle != null) {
                    settle.cancel();
                }
                downX = e.getRawX();
                downY = e.getRawY();
                dragging = false;
                // the panel has its own sideways swipe, so it keeps touches that start on it
                tracking = !insidePanel(e);
                if (velocity != null) {
                    velocity.recycle();
                }
                velocity = VelocityTracker.obtain();
                velocity.addMovement(e);
                break;
            case MotionEvent.ACTION_MOVE:
                if (velocity != null) {
                    velocity.addMovement(e);
                }
                if (tracking && !dragging && !introRunning) {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    boolean ok = (pageIndex == 0 && dx < 0) || (pageIndex == 1 && dx > 0);
                    if (ok && Math.abs(dx) > slop * 1.5f && Math.abs(dx) > Math.abs(dy) * 1.4f) {
                        dragging = true;
                        return true;
                    }
                }
                break;
            default:
                break;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (drawMode) {
            return drawLayer.handle(e);
        }
        if (dragging) {
            if (velocity != null) {
                velocity.addMovement(e);
            }
            float w = Math.max(1f, getWidth());
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX;
                    progress = Math.max(-0.1f, Math.min(1.1f, pageIndex - dx / w));
                    applyProgress();
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float vx = 0f;
                    if (velocity != null) {
                        velocity.computeCurrentVelocity(1000);
                        vx = velocity.getXVelocity();
                    }
                    int target;
                    if (e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                        target = progress > 0.5f ? 1 : 0;
                    } else if (vx < -900) {
                        target = 1;
                    } else if (vx > 900) {
                        target = 0;
                    } else {
                        target = progress > 0.5f ? 1 : 0;
                    }
                    dragging = false;
                    settleTo(target, 280);
                    return true;
                }
                default:
                    return true;
            }
        }
        return swipe.onTouchEvent(e) || super.onTouchEvent(e);
    }

    // ---------------------------------------------------------------- welcome animation

    /** Hides everything and adds the big greeting in the middle. Plays once the screen is attached. */
    private void prepareIntro() {
        introRunning = true;
        for (View v : early) {
            v.setAlpha(0f);
        }
        float rise = Theme.dp(host, 70);
        for (View v : late) {
            v.setAlpha(0f);
            v.setTranslationY(rise);
        }
        welcome = new TextView(host);
        welcome.setText(Prefs.greeting().toUpperCase(Locale.getDefault()));
        welcome.setTypeface(Theme.clockFace());
        welcome.setTextSize(34f);
        welcome.setTextColor(Theme.TEXT);
        welcome.setLetterSpacing(0.9f);
        welcome.setAlpha(0f);
        welcomeGlow = Theme.glow(welcome);
        addView(welcome, new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    /** True while the greeting waits for a tap (hold time set to 0 in Settings). */
    private boolean waitingTap;

    /**
     * Greeting fades and settles in and stays for the time chosen in Settings (or until you tap).
     * Then the time appears and the rest rises from below, one piece after another.
     */
    private void playIntro() {
        final DecelerateInterpolator out = new DecelerateInterpolator(1.6f);

        welcome.setScaleX(1.12f);
        welcome.setScaleY(1.12f);
        welcome.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
        welcomeSpacing = ValueAnimator.ofFloat(0.9f, 0.4f);
        welcomeSpacing.setDuration(1000);
        welcomeSpacing.setInterpolator(new DecelerateInterpolator());
        welcomeSpacing.addUpdateListener(a -> welcome.setLetterSpacing((float) a.getAnimatedValue()));
        welcomeSpacing.start();

        int hold = Prefs.greetHold();
        if (hold == 0) {
            waitingTap = true; // the next tap carries on with the animation
        } else {
            introHandler.postDelayed(this::playRest, 650L + hold * 500L);
        }
    }

    /** The second half: greeting leaves, the time arrives, everything else rises in. */
    private void playRest() {
        if (!introRunning) {
            return;
        }
        waitingTap = false;
        final DecelerateInterpolator out = new DecelerateInterpolator(1.6f);

        welcome.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(350).start();

        introHandler.postDelayed(() -> {
            for (View v : early) {
                v.setPivotX(0f);
                v.setPivotY(v.getHeight() / 2f);
                v.setScaleX(0.9f);
                v.setScaleY(0.9f);
                v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(out).start();
            }
        }, 50);

        for (int i = 0; i < late.size(); i++) {
            final View v = late.get(i);
            introHandler.postDelayed(() -> v.animate().alpha(1f).translationY(0f)
                    .setDuration(560).setInterpolator(out).start(), 600L + 90L * i);
        }

        introHandler.postDelayed(() -> introRunning = false, 600L + 90L * late.size() + 600L);
    }

    /** Tap anywhere during the animation to jump straight to the finished home screen. */
    private void finishIntro() {
        introRunning = false;
        waitingTap = false;
        introHandler.removeCallbacksAndMessages(null);
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        if (welcome != null) {
            welcome.animate().cancel();
            welcome.setAlpha(0f);
        }
        for (View v : early) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setScaleX(1f);
            v.setScaleY(1f);
        }
        for (View v : late) {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setTranslationY(0f);
        }
    }

    // ---------------------------------------------------------------- bits

    private TextView mono(String text, float size, int color) {
        TextView t = new TextView(host);
        t.setText(text);
        t.setTypeface(Theme.MONO);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    }

    private TextView dockButton(String label, OnClickListener click) {
        TextView b = mono(label, 11f, Theme.TEXT);
        b.setLetterSpacing(0.12f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Theme.dp(host, 16), 0, Theme.dp(host, 16));
        b.setClickable(true);
        Theme.ripple(b);
        b.setOnClickListener(click);
        return b;
    }

    private void refreshBattery() {
        if (!Prefs.battery()) {
            battery.setText("");
            return;
        }
        int level = host.batteryLevel();
        if (level < 0) {
            battery.setText("");
            return;
        }
        battery.setText(level + "%" + (host.charging() ? " · charging" : "") + (Saver.on() ? " · eco" : ""));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!plxViews.isEmpty()) {
            if (parallax == null) {
                parallax = new Parallax(host, this::applyTilt);
            }
            parallax.start();
        }
        handler.postDelayed(tick, 30000);
        handler.postDelayed(prank, 90000 + prankRnd.nextInt(120000));
        if (introRunning && !introStarted) {
            introStarted = true;
            playIntro();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (parallax != null) {
            parallax.stop();
        }
        handler.removeCallbacksAndMessages(null);
        introHandler.removeCallbacksAndMessages(null);
        for (Animator a : wiggles) {
            a.cancel();
        }
        wiggles.clear();
        if (settle != null) {
            settle.cancel();
        }
        if (velocity != null) {
            velocity.recycle();
            velocity = null;
        }
        nameGlow.cancel();
        if (welcomeGlow != null) {
            welcomeGlow.cancel();
        }
        if (welcomeSpacing != null) {
            welcomeSpacing.cancel();
        }
        super.onDetachedFromWindow();
    }
}
