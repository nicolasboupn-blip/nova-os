package app.novaos;

import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

/** The full-screen window around a game: dark background, title, and a close button. The box it came from grows into it. */
final class GameFrame extends FrameLayout {
    private final NovaActivity host;
    private final View from;
    private final Runnable onClose;
    private boolean closing;

    GameFrame(final NovaActivity host, Game game, View from, Runnable onClose) {
        super(host);
        this.host = host;
        this.from = from;
        this.onClose = onClose;
        setBackgroundColor(Theme.BG);
        setClickable(true);
        addView(game, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextView title = new TextView(host);
        title.setText(game.title());
        title.setTypeface(Theme.MONO);
        title.setTextSize(12f);
        title.setLetterSpacing(0.3f);
        title.setTextColor(Theme.ACCENT);
        LayoutParams tp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        tp.setMargins(Theme.dp(host, 20), Theme.dp(host, 22), 0, 0);
        addView(title, tp);

        TextView close = new TextView(host);
        close.setText("✕");
        close.setTextSize(20f);
        close.setTextColor(Theme.TEXT);
        close.setGravity(Gravity.CENTER);
        close.setClickable(true);
        Theme.ripple(close);
        close.setOnClickListener(v -> shrink());
        addView(close, new LayoutParams(Theme.dp(host, 52), Theme.dp(host, 52), Gravity.TOP | Gravity.END));
    }

    /** Where the box centre sits, in this frame's own coordinates. */
    private float[] origin() {
        int[] a = new int[2];
        int[] b = new int[2];
        from.getLocationOnScreen(a);
        getLocationOnScreen(b);
        return new float[] {a[0] - b[0] + from.getWidth() / 2f, a[1] - b[1] + from.getHeight() / 2f};
    }

    void grow() {
        setAlpha(0f);
        post(() -> {
            if (from.getWidth() == 0 || getWidth() == 0) {
                setAlpha(1f);
                return;
            }
            float[] o = origin();
            setPivotX(o[0]);
            setPivotY(o[1]);
            setScaleX(from.getWidth() / (float) getWidth());
            setScaleY(from.getHeight() / (float) getHeight());
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
                    .setInterpolator(new DecelerateInterpolator(1.8f)).start();
        });
    }

    void shrink() {
        if (closing) {
            return;
        }
        closing = true;
        onClose.run();
        if (!from.isAttachedToWindow() || getWidth() == 0) {
            host.hideOverlay();
            return;
        }
        float[] o = origin();
        setPivotX(o[0]);
        setPivotY(o[1]);
        animate().alpha(0f).scaleX(from.getWidth() / (float) getWidth())
                .scaleY(from.getHeight() / (float) getHeight()).setDuration(240)
                .withEndAction(host::hideOverlay).start();
    }

    @Override
    protected void onDetachedFromWindow() {
        onClose.run();
        super.onDetachedFromWindow();
    }
}
