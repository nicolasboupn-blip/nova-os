package app.novaos;

import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * ZÜRICH BUS on the home screen: your bus routes on the real map. Pinch, drag or use + and - to zoom, and the OPEN button
 * opens the big window (add routes by hand, switch on auto-detect, see where the bus runs late).
 */
final class BusWidget extends NovaWidget {
    private final BusMapView map;
    private final TextView info;
    private boolean fitted;

    BusWidget(NovaActivity host) {
        super(host);
        FrameLayout box = new FrameLayout(host);
        map = new BusMapView(host);
        box.addView(map, new FrameLayout.LayoutParams(-1, -1));

        TextView title = text("ZÜRICH BUS", 9f, Theme.TEXT);
        title.setLetterSpacing(0.12f);
        title.setBackground(Theme.rounded(0xCC10101A, 10f, host));
        title.setPadding(dp(8), dp(5), dp(8), dp(5));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        tp.setMargins(dp(8), dp(8), 0, 0);
        box.addView(title, tp);

        TextView open = mapChip("OPEN ›", () -> BusScreen.open(host));
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        op.setMargins(0, dp(8), dp(8), 0);
        box.addView(open, op);

        LinearLayout zoom = new LinearLayout(host);
        zoom.setOrientation(VERTICAL);
        zoom.addView(mapChip("+", () -> map.zoomBy(1)), zoomLp());
        zoom.addView(mapChip("−", () -> map.zoomBy(-1)), zoomLp());
        zoom.addView(mapChip("▣", () -> map.fitAll()), zoomLp());
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        zp.setMargins(0, 0, dp(8), dp(8));
        box.addView(zoom, zp);

        addView(box, new LinearLayout.LayoutParams(-1, dp(240)));
        info = text("", 10f, Theme.DIM);
        info.setGravity(Gravity.START);
        info.setPadding(dp(2), dp(8), dp(2), 0);
        addView(info, wide());
    }

    private LinearLayout.LayoutParams zoomLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(38));
        lp.topMargin = dp(5);
        return lp;
    }

    private TextView mapChip(String s, Runnable r) {
        TextView t = chip(s, r);
        t.setTextSize(s.length() > 2 ? 11f : 16f);
        t.setTextColor(Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0xE610101A, 12f, host));
        return t;
    }

    @Override
    long tickMs() {
        return 0;
    }

    @Override
    void refresh() {
        if (PeakData.useLastKnown(host.getApplicationContext())) {
            map.setMe(PeakData.myLat, PeakData.myLon);
        }
        if (!fitted) {
            map.fitAll();
            fitted = true;
        }
        map.invalidate();
        summary();
        final List<BusData.Route> routes = BusData.routes();
        if (routes.isEmpty()) {
            return;
        }
        new Thread(() -> {
            boolean any = false;
            try {
                for (int i = 0; i < routes.size() && i < 3; i++) {
                    any |= BusData.refreshDelays(routes.get(i));
                }
            } catch (RuntimeException ignored) {
                // a route changed while we looked: try again next time
            }
            if (any) {
                ui.post(() -> {
                    map.invalidate();
                    summary();
                });
            }
        }).start();
    }

    private void summary() {
        List<BusData.Route> routes = BusData.routes();
        if (routes.isEmpty()) {
            info.setText("No routes yet. Tap OPEN, then + ROUTE, or switch on AUTO-DETECT and just ride.");
            return;
        }
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < routes.size() && i < 2; i++) {
            BusData.Route r = routes.get(i);
            if (i > 0) {
                b.append('\n');
            }
            b.append(r.name).append("  ·  ").append(Math.min(r.days.size(), BusData.CONFIRM_DAYS)).append('/')
                    .append(BusData.CONFIRM_DAYS).append(" days");
            int w = r.worstIndex();
            if (w >= 0 && r.confirmed()) {
                b.append("  ·  late at ").append(r.stops.get(w).shortName()).append(" +")
                        .append(Math.round(r.avg(w))).append(" min");
            }
        }
        if (routes.size() > 2) {
            b.append("\n+ ").append(routes.size() - 2).append(" more");
        }
        info.setText(b.toString());
    }
}
