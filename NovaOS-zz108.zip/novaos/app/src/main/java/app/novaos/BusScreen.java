package app.novaos;

import android.app.AlertDialog;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * The big ZÜRICH BUS window: the full map (pinch, drag, double tap), your routes, a way to add a route by hand and the
 * AUTO-DETECT switch. A route turns into a solid blue line after you rode it on 3 different days; where the bus is late
 * the line goes green to red.
 */
final class BusScreen extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final BusMapView map;
    private final LinearLayout list;
    private final LinearLayout sheet;
    private final TextView autoChip;
    private final TextView selInfo;

    static void open(NovaActivity host) {
        host.showOverlay(new BusScreen(host));
    }

    BusScreen(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xFF0B0B14);
        setClickable(true);

        map = new BusMapView(host);
        map.listener = this::onPick;
        addView(map, new FrameLayout.LayoutParams(-1, -1));

        // top bar
        LinearLayout top = new LinearLayout(host);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(12), dp(40), dp(12), dp(8));
        top.setBackgroundColor(0xE60B0B14);
        LinearLayout head = new LinearLayout(host);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("BUS · ZÜRICH", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(chip("CLOSE", () -> host.hideOverlay()));
        top.addView(head, new LinearLayout.LayoutParams(-1, -2));
        HorizontalScrollView hs = new HorizontalScrollView(host);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(host);
        chips.setPadding(0, dp(8), 0, 0);
        chips.addView(chip("+ ROUTE", this::newRoute));
        autoChip = chip("AUTO: OFF", this::toggleAuto);
        chips.addView(autoChip);
        chips.addView(chip("LIST", this::toggleList));
        chips.addView(chip("DARK MAP", () -> {
            map.dark = !map.dark;
            Prefs.putBool("pk_darkmap", map.dark);
            map.invalidate();
        }));
        hs.addView(chips);
        top.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // zoom buttons
        LinearLayout zoom = new LinearLayout(host);
        zoom.setOrientation(LinearLayout.VERTICAL);
        zoom.addView(round("+", () -> map.zoomBy(1)));
        zoom.addView(round("−", () -> map.zoomBy(-1)));
        zoom.addView(round("▣", () -> {
            map.focus = null;
            map.fitAll();
        }));
        zoom.addView(round("⌖", () -> {
            if (PeakData.useLastKnown(host.getApplicationContext())) {
                map.setMe(PeakData.myLat, PeakData.myLon);
                map.centerOn(PeakData.myLat, PeakData.myLon, 15);
            } else {
                host.toast("No position yet. Allow location in NOVA first");
            }
        }));
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        zp.setMargins(0, 0, dp(10), dp(60));
        addView(zoom, zp);

        // bottom sheet
        sheet = new LinearLayout(host);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(12), dp(10), dp(12), dp(12));
        sheet.setBackground(Theme.rounded(0xF20B0B14, 18f, host));
        TextView legend = text("", 9f, Theme.DIM);
        legend.setGravity(Gravity.START);
        legend.setText(legend());
        sheet.addView(legend, new LinearLayout.LayoutParams(-1, -2));
        selInfo = text("", 10f, Theme.TEXT);
        selInfo.setGravity(Gravity.START);
        selInfo.setPadding(0, dp(6), 0, dp(4));
        sheet.addView(selInfo, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(host);
        sv.setVerticalScrollBarEnabled(false);
        list = new LinearLayout(host);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        sheet.addView(sv, new LinearLayout.LayoutParams(-1, dp(170)));
        addView(sheet, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        updateAuto();
        rebuild();
        map.fitAll();
    }

    private void toggleList() {
        sheet.setVisibility(sheet.getVisibility() == VISIBLE ? GONE : VISIBLE);
    }

    private CharSequence legend() {
        SpannableStringBuilder b = new SpannableStringBuilder("LINE  ");
        int[] mins = {0, 1, 3, 5, 8};
        String[] lab = {" on time   ", " +1   ", " +3   ", " +5   ", " +8 min late"};
        for (int i = 0; i < mins.length; i++) {
            int s = b.length();
            b.append("■");
            b.setSpan(new ForegroundColorSpan(BusData.delayColor(mins[i])), s, s + 1, 0);
            b.append(lab[i]);
        }
        b.append("\ndashed = still learning (needs 3 different days)  ·  bus symbol = where you get in");
        return b;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (PeakData.useLastKnown(host.getApplicationContext())) {
            map.setMe(PeakData.myLat, PeakData.myLon);
        }
        final List<BusData.Route> routes = BusData.routes();
        new Thread(() -> {
            boolean any = false;
            try {
                for (int i = 0; i < routes.size() && i < 6; i++) {
                    any |= BusData.refreshDelays(routes.get(i));
                }
            } catch (RuntimeException ignored) {
                // a route changed while we looked: next time
            }
            if (any) {
                post(() -> {
                    map.invalidate();
                    rebuild();
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ the routes

    private void rebuild() {
        list.removeAllViews();
        List<BusData.Route> routes = BusData.routes();
        if (routes.isEmpty()) {
            TextView t = text("No routes yet. Tap + ROUTE and pick where you get on and off, or switch on AUTO and "
                    + "NOVA will ask you after a ride.", 10f, Theme.DIM);
            t.setGravity(Gravity.START);
            list.addView(t);
            return;
        }
        for (final BusData.Route r : routes) {
            LinearLayout row = new LinearLayout(host);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(10), dp(8), dp(8), dp(8));
            row.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
            TextView name = text(r.name, 11f, Theme.TEXT);
            name.setGravity(Gravity.START);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(name, new LinearLayout.LayoutParams(-1, -2));
            TextView sub = text(status(r), 9f, Theme.DIM);
            sub.setGravity(Gravity.START);
            row.addView(sub, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout acts = new LinearLayout(host);
            acts.setPadding(0, dp(6), 0, 0);
            acts.addView(chip("RODE TODAY", () -> {
                BusData.markDay(r, BusData.today());
                host.toast(r.confirmed() ? "Blue line now" : "Saved. " + Math.min(r.days.size(), 3) + " of 3 days");
                map.invalidate();
                rebuild();
            }));
            acts.addView(chip("ZOOM", () -> {
                map.focus = r;
                map.fitRoute(r);
            }));
            acts.addView(chip("✕", () -> new AlertDialog.Builder(host).setTitle("Delete this route?")
                    .setMessage(r.name)
                    .setPositiveButton("DELETE", (d, w) -> {
                        BusData.deleteRoute(r);
                        map.selRoute = null;
                        map.focus = null;
                        map.invalidate();
                        rebuild();
                    }).setNegativeButton("Cancel", null).show()));
            row.addView(acts, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.topMargin = dp(6);
            list.addView(row, lp);
        }
    }

    private String status(BusData.Route r) {
        int n = r.days.size();
        String s = Math.min(n, BusData.CONFIRM_DAYS) + "/" + BusData.CONFIRM_DAYS + " days";
        if (r.confirmed()) {
            s += "  ·  blue line";
        } else {
            int left = BusData.CONFIRM_DAYS - n;
            s += "  ·  " + left + " more day" + (left == 1 ? "" : "s") + " until it turns blue";
        }
        int w = r.worstIndex();
        if (w >= 0) {
            s += "\nlatest at " + r.stops.get(w).shortName() + ": +" + Math.round(r.avg(w)) + " min on average";
        } else {
            s += "\nno delay numbers yet (they come in while this window or the widget is open)";
        }
        return s;
    }

    private void onPick(BusData.Route r, int idx) {
        if (r == null || idx < 0 || idx >= r.stops.size()) {
            selInfo.setText("");
            return;
        }
        final BusData.Route route = r;
        final int i = idx;
        final BusData.Stop s = r.stops.get(idx);
        double a = r.avg(idx);
        final boolean board = r.boards(idx);
        selInfo.setText(s.shortName() + "  ·  " + (board ? "you get in here" : "you pass by") + "  ·  "
                + (Double.isNaN(a) ? "no delay data yet" : String.format(Locale.US, "usually +%.1f min late", a)));
        new AlertDialog.Builder(host).setTitle(s.shortName())
                .setItems(new String[] {board ? "Make it a pass-by stop" : "I get in here (bus symbol)",
                        "Remove this stop from the route"}, (d, which) -> {
                            if (which == 0) {
                                BusData.setBoarding(route, s, !board);
                            } else if (!BusData.removeStop(route, i)) {
                                host.toast("A route needs at least two stops");
                            }
                            map.selRoute = null;
                            map.selIdx = -1;
                            map.invalidate();
                            rebuild();
                        }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ adding a route by hand

    private void newRoute() {
        askStop("Where do you get ON the bus?", from -> askStop("Where do you get OFF?", to -> build(from, to)));
    }

    private void askStop(String title, final Consumer<BusData.Stop> done) {
        final EditText in = new EditText(host);
        in.setSingleLine(true);
        in.setHint("a stop name, like Bahnhof Enge");
        LinearLayout box = new LinearLayout(host);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(in, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(host).setTitle(title).setView(box)
                .setPositiveButton("SEARCH", (d, w) -> {
                    final String q = in.getText().toString().trim();
                    if (q.length() < 2) {
                        return;
                    }
                    host.toast("Searching...");
                    new Thread(() -> {
                        final List<BusData.Stop> found = BusData.searchStops(q);
                        host.runOnUiThread(() -> pickStop(title, found, done));
                    }).start();
                }).setNegativeButton("Cancel", null).show();
    }

    private void pickStop(String title, final List<BusData.Stop> found, final Consumer<BusData.Stop> done) {
        if (found.isEmpty()) {
            host.toast(BusData.lastError.isEmpty() ? "No stop found" : BusData.lastError);
            return;
        }
        int n = Math.min(found.size(), 8);
        String[] names = new String[n];
        for (int i = 0; i < n; i++) {
            names[i] = found.get(i).name;
        }
        new AlertDialog.Builder(host).setTitle(title).setItems(names, (d, which) -> done.accept(found.get(which)))
                .setNegativeButton("Cancel", null).show();
    }

    private void build(final BusData.Stop from, final BusData.Stop to) {
        host.toast("Looking up the bus line...");
        new Thread(() -> {
            final BusData.Route r = BusData.buildRoute(from, to, 0);
            host.runOnUiThread(() -> {
                if (r == null) {
                    host.toast(BusData.lastError.isEmpty() ? "No bus line found" : BusData.lastError);
                } else {
                    askDays(r);
                }
            });
        }).start();
    }

    private void askDays(final BusData.Route r) {
        new AlertDialog.Builder(host).setTitle(r.name + "\nHave you ridden this on different days already?")
                .setItems(new String[] {"Not yet", "1 day so far", "2 days so far", "3 or more (draw it blue now)"},
                        (d, which) -> {
                            BusData.Route mine = BusData.addRoute(r);
                            for (int k = 0; k < which; k++) {
                                BusData.markDay(mine, BusData.daysAgo(k));
                            }
                            map.focus = mine;
                            map.fitRoute(mine);
                            rebuild();
                            host.toast(mine.confirmed() ? "Route saved. Blue line" : "Route saved");
                            final BusData.Route fresh = mine;
                            new Thread(() -> {
                                try {
                                    if (BusData.refreshDelays(fresh)) {
                                        post(() -> {
                                            map.invalidate();
                                            rebuild();
                                        });
                                    }
                                } catch (RuntimeException ignored) {
                                    // try again next time
                                }
                            }).start();
                        }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ auto-detect

    private void updateAuto() {
        boolean on = Prefs.getBool("bus_auto", false);
        autoChip.setText(on ? "AUTO: ON" : "AUTO: OFF");
        autoChip.setTextColor(on ? Theme.BG : Theme.ACCENT);
        autoChip.setBackground(Theme.rounded(on ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
    }

    private void toggleAuto() {
        if (Prefs.getBool("bus_auto", false)) {
            Prefs.putBool("bus_auto", false);
            TripService.stop(host);
            updateAuto();
            host.toast("Auto-detect is off");
            return;
        }
        new AlertDialog.Builder(host).setTitle("Notice bus rides by itself?")
                .setMessage("NOVA checks your position every 15 seconds or so in the background (a small notification "
                        + "stays on while it runs). When you move like a bus for a few minutes it saves the ride and "
                        + "asks you next time you open NOVA. Positions stay on this phone. It needs location access, "
                        + "and uses some battery.")
                .setPositiveButton("SWITCH ON", (d, w) -> host.ask(
                        new String[] {android.Manifest.permission.ACCESS_FINE_LOCATION}, () -> {
                            Prefs.putBool("bus_auto", true);
                            boolean ok = TripService.start(host);
                            host.toast(ok ? "Auto-detect is on" : "Could not start it");
                            updateAuto();
                        }, () -> host.toast("Location was not allowed")))
                .setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ small helpers

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setClickable(true);
        t.setOnClickListener((View v) -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }

    private TextView round(String s, final Runnable r) {
        TextView t = text(s, 17f, Theme.TEXT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Theme.rounded(0xE60B0B14, 14f, host));
        t.setClickable(true);
        t.setOnClickListener((View v) -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(42), dp(42));
        p.topMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }
}
