package app.novaos;

import android.app.AlertDialog;
import android.content.ClipData;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Build your own widget. Big preview of the widget on top, the whole block list below.
 * Hold a block in the list and drag it onto the widget. In the widget: tap a block for options, hold it to move it,
 * drag it back down to the list to remove it.
 */
final class WidgetBuilder extends FrameLayout implements BackAware {
    private final NovaActivity host;
    private final ScrollView previewScroll;
    private final ScrollView paletteScroll;
    private EditArea area;
    private int slot = 1;

    WidgetBuilder(NovaActivity host) {
        super(host);
        this.host = host;
        setBackgroundColor(0xF2080614);
        setClickable(true);
        LinearLayout col = new LinearLayout(host);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(54), dp(14), dp(12));
        TextView title = text("WIDGET BUILDER", 15f, Theme.ACCENT);
        title.setLetterSpacing(0.12f);
        col.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView hint = text("Hold a block in the list and drag it onto the widget. Tap a block in the widget to edit it, "
                + "hold it to move it. Drag it back down to remove it.", 9f, Theme.DIM);
        hint.setGravity(Gravity.START);
        hint.setPadding(0, dp(6), 0, dp(8));
        col.addView(hint);

        LinearLayout row1 = new LinearLayout(host);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 1; i <= 3; i++) {
            final int s = i;
            TextView c = chip("SLOT " + i, () -> {
                slot = s;
                build(false);
            });
            c.setTag("slot" + i);
            row1.addView(c);
        }
        row1.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
        row1.addView(chip("RESET", this::reset));
        col.addView(row1);

        LinearLayout row2 = new LinearLayout(host);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        row2.setPadding(0, dp(8), 0, 0);
        row2.addView(chip("PUT ON HOME SCREEN", this::putOnHome));
        row2.addView(new View(host), new LinearLayout.LayoutParams(0, 1, 1f));
        row2.addView(chip("CLOSE", () -> host.hideOverlay()));
        col.addView(row2);

        TextView pl = text("YOUR WIDGET", 9f, Theme.DIM);
        pl.setPadding(0, dp(10), 0, dp(4));
        col.addView(pl);
        previewScroll = new ScrollView(host);
        previewScroll.setVerticalScrollBarEnabled(false);
        previewScroll.setFillViewport(true);
        previewScroll.setBackground(Theme.rounded(Theme.PANEL, 14f, host));
        col.addView(previewScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView al = text("ALL BLOCKS  ·  tap to add, hold and drag to place", 9f, Theme.DIM);
        al.setPadding(0, dp(10), 0, dp(4));
        col.addView(al);
        paletteScroll = new ScrollView(host);
        paletteScroll.setVerticalScrollBarEnabled(false);
        paletteScroll.addView(buildPalette());
        paletteScroll.setOnDragListener((v, e) -> {
            switch (e.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return "mv".equals(String.valueOf(e.getClipDescription().getLabel()));
                case DragEvent.ACTION_DRAG_ENTERED:
                    paletteScroll.setBackground(Theme.rounded(0x33FF5A5A, 12f, host));
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                case DragEvent.ACTION_DRAG_ENDED:
                    paletteScroll.setBackground(null);
                    return true;
                case DragEvent.ACTION_DROP:
                    paletteScroll.setBackground(null);
                    removeBlock(payload(e));
                    return true;
                default:
                    return true;
            }
        });
        col.addView(paletteScroll, new LinearLayout.LayoutParams(-1, 0, 1.15f));
        addView(col, new FrameLayout.LayoutParams(-1, -1));
        build(false);
    }

    // ------------------------------------------------------------------ the widget (drop target)

    /** The widget preview. Touches never reach the blocks, so tapping a block edits it instead of pressing it. */
    private final class EditArea extends FrameLayout {
        final CustomWidget cw;
        final View line;
        final GestureDetector gd;
        final List<CustomWidget.Block> blocks;

        EditArea() {
            super(WidgetBuilder.this.host);
            setPadding(dp(12), dp(10), dp(12), dp(10));
            cw = new CustomWidget(WidgetBuilder.this.host, slot);
            addView(cw, new FrameLayout.LayoutParams(-1, -2));
            line = new View(WidgetBuilder.this.host);
            line.setBackgroundColor(Theme.ACCENT);
            line.setVisibility(GONE);
            addView(line, new FrameLayout.LayoutParams(-1, dp(3)));
            cw.refresh();
            blocks = CustomWidget.load(slot);
            gd = new GestureDetector(WidgetBuilder.this.host, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    int i = indexAt(e.getY());
                    if (i >= 0) {
                        blockMenu(i);
                    }
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    int i = indexAt(e.getY());
                    if (i >= 0 && i < cw.getChildCount()) {
                        View c = cw.getChildAt(i);
                        ClipData cd = ClipData.newPlainText("mv", String.valueOf(i));
                        if (startDragAndDrop(cd, new View.DragShadowBuilder(c), null, 0)) {
                            c.setAlpha(0.25f);
                        }
                    }
                }
            });
            setOnDragListener((v, e) -> {
                switch (e.getAction()) {
                    case DragEvent.ACTION_DRAG_STARTED: {
                        String k = String.valueOf(e.getClipDescription().getLabel());
                        return "add".equals(k) || "mv".equals(k);
                    }
                    case DragEvent.ACTION_DRAG_ENTERED:
                    case DragEvent.ACTION_DRAG_LOCATION:
                        showLine(e.getY());
                        autoscroll(e.getY());
                        return true;
                    case DragEvent.ACTION_DRAG_EXITED:
                        line.setVisibility(GONE);
                        return true;
                    case DragEvent.ACTION_DROP: {
                        line.setVisibility(GONE);
                        int idx = insertAt(e.getY());
                        dropAt(String.valueOf(e.getClipDescription().getLabel()), payload(e), idx);
                        return true;
                    }
                    case DragEvent.ACTION_DRAG_ENDED:
                        line.setVisibility(GONE);
                        for (int i = 0; i < cw.getChildCount(); i++) {
                            cw.getChildAt(i).setAlpha(1f);
                        }
                        return true;
                    default:
                        return true;
                }
            });
        }

        int count() {
            return Math.min(blocks.size(), cw.getChildCount());
        }

        int indexAt(float y) {
            float cy = y - cw.getTop();
            for (int i = 0; i < count(); i++) {
                if (cy < cw.getChildAt(i).getBottom() + dp(4)) {
                    return i;
                }
            }
            return -1;
        }

        int insertAt(float y) {
            float cy = y - cw.getTop();
            int idx = 0;
            for (int i = 0; i < count(); i++) {
                View c = cw.getChildAt(i);
                if (cy > c.getTop() + c.getHeight() / 2f) {
                    idx = i + 1;
                }
            }
            return idx;
        }

        void showLine(float y) {
            int idx = insertAt(y);
            int n = count();
            float ly;
            if (n == 0) {
                ly = cw.getTop();
            } else if (idx < n) {
                ly = cw.getTop() + cw.getChildAt(idx).getTop() - dp(2);
            } else {
                ly = cw.getTop() + cw.getChildAt(n - 1).getBottom() + dp(1);
            }
            line.setTranslationY(ly);
            line.setVisibility(VISIBLE);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            gd.onTouchEvent(e);
            return true;
        }
    }

    private void autoscroll(float y) {
        float vy = y - previewScroll.getScrollY();
        if (vy < dp(36)) {
            previewScroll.scrollBy(0, -dp(10));
        } else if (vy > previewScroll.getHeight() - dp(36)) {
            previewScroll.scrollBy(0, dp(10));
        }
    }

    private static int payload(DragEvent e) {
        try {
            return Integer.parseInt(String.valueOf(e.getClipData().getItemAt(0).getText()).trim());
        } catch (RuntimeException ex) {
            return -1;
        }
    }

    private void dropAt(String kind, int value, int idx) {
        List<CustomWidget.Block> blocks = CustomWidget.load(slot);
        if ("add".equals(kind)) {
            if (value < 0 || value >= CustomWidget.TYPES.length) {
                return;
            }
            if (blocks.size() >= 30) {
                host.toast("30 blocks is the most");
                return;
            }
            CustomWidget.Block b = new CustomWidget.Block();
            b.type = value;
            CustomWidget.defaults(b);
            blocks.add(Math.max(0, Math.min(idx, blocks.size())), b);
            CustomWidget.save(slot, blocks);
            build(true);
            if (CustomWidget.hints(value) != null) {
                editBlock(blocks, b);
            }
        } else if ("mv".equals(kind)) {
            if (value < 0 || value >= blocks.size()) {
                return;
            }
            CustomWidget.Block b = blocks.remove(value);
            int to = idx > value ? idx - 1 : idx;
            blocks.add(Math.max(0, Math.min(to, blocks.size())), b);
            CustomWidget.save(slot, blocks);
            build(true);
        }
    }

    private void removeBlock(int idx) {
        List<CustomWidget.Block> blocks = CustomWidget.load(slot);
        if (idx < 0 || idx >= blocks.size()) {
            return;
        }
        blocks.remove(idx);
        CustomWidget.save(slot, blocks);
        build(true);
    }

    private void build(boolean keepScroll) {
        final int sy = keepScroll ? previewScroll.getScrollY() : 0;
        previewScroll.removeAllViews();
        area = new EditArea();
        previewScroll.addView(area, new FrameLayout.LayoutParams(-1, -2));
        previewScroll.post(() -> previewScroll.scrollTo(0, sy));
        for (int i = 1; i <= 3; i++) {
            View chipV = findViewWithTag("slot" + i);
            if (chipV instanceof TextView) {
                ((TextView) chipV).setTextColor(i == slot ? Theme.BG : Theme.ACCENT);
                chipV.setBackground(Theme.rounded(i == slot ? Theme.ACCENT : 0x22FFFFFF, 12f, host));
            }
        }
    }

    private void reset() {
        new AlertDialog.Builder(host).setTitle("Reset MY WIDGET " + slot + "?")
                .setMessage("This takes every block out of the widget.")
                .setPositiveButton("RESET", (d, w) -> {
                    CustomWidget.save(slot, new ArrayList<>());
                    build(false);
                }).setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ the block list (drag source)

    private LinearLayout buildPalette() {
        LinearLayout all = new LinearLayout(host);
        all.setOrientation(LinearLayout.VERTICAL);
        all.setPadding(0, 0, 0, dp(24));
        for (int g = 0; g < CustomWidget.GROUPS.length; g++) {
            TextView gh = text(CustomWidget.GROUPS[g], 9f, Theme.ACCENT);
            gh.setLetterSpacing(0.15f);
            gh.setPadding(dp(2), dp(10), 0, dp(4));
            all.addView(gh);
            int[] items = CustomWidget.GROUP_ITEMS[g];
            for (int i = 0; i < items.length; i += 2) {
                LinearLayout r = new LinearLayout(host);
                r.addView(item(items[i]), cell());
                if (i + 1 < items.length) {
                    r.addView(item(items[i + 1]), cell());
                } else {
                    r.addView(new View(host), cell());
                }
                all.addView(r, new LinearLayout.LayoutParams(-1, -2));
            }
        }
        return all;
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    private TextView item(final int type) {
        TextView t = text("+  " + CustomWidget.TYPES[type], 11f, Theme.TEXT);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setSingleLine(true);
        t.setPadding(dp(10), dp(11), dp(8), dp(11));
        t.setBackground(Theme.rounded(0x22FFFFFF, 10f, host));
        t.setOnClickListener(v -> dropAt("add", type, Integer.MAX_VALUE));
        t.setOnLongClickListener(v -> {
            ClipData cd = ClipData.newPlainText("add", String.valueOf(type));
            return v.startDragAndDrop(cd, new View.DragShadowBuilder(v), null, 0);
        });
        return t;
    }

    // ------------------------------------------------------------------ one block

    private void blockMenu(final int idx) {
        final List<CustomWidget.Block> blocks = CustomWidget.load(slot);
        if (idx < 0 || idx >= blocks.size()) {
            return;
        }
        final CustomWidget.Block b = blocks.get(idx);
        final List<String> names = new ArrayList<>();
        if (CustomWidget.hints(b.type) != null) {
            names.add("Edit");
        }
        names.add("Move up");
        names.add("Move down");
        names.add("Duplicate");
        names.add("Remove");
        new AlertDialog.Builder(host).setTitle(CustomWidget.TYPES[b.type])
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    String s = names.get(which);
                    if (s.equals("Edit")) {
                        editBlock(blocks, b);
                    } else if (s.equals("Move up")) {
                        move(blocks, idx, -1);
                    } else if (s.equals("Move down")) {
                        move(blocks, idx, 1);
                    } else if (s.equals("Duplicate")) {
                        if (blocks.size() >= 30) {
                            host.toast("30 blocks is the most");
                            return;
                        }
                        CustomWidget.Block copy = new CustomWidget.Block();
                        copy.type = b.type;
                        copy.a = b.a;
                        copy.b = b.b;
                        blocks.add(idx + 1, copy);
                        CustomWidget.save(slot, blocks);
                        build(true);
                    } else {
                        removeBlock(idx);
                    }
                }).show();
    }

    private void move(List<CustomWidget.Block> blocks, int idx, int d) {
        int j = idx + d;
        if (j < 0 || j >= blocks.size()) {
            return;
        }
        CustomWidget.Block b = blocks.remove(idx);
        blocks.add(j, b);
        CustomWidget.save(slot, blocks);
        build(true);
    }

    private void putOnHome() {
        final String id = "mine" + slot;
        new AlertDialog.Builder(host).setTitle("Which home page?")
                .setItems(new String[] {"Page 1", "Page 2"}, (d, page) ->
                        new AlertDialog.Builder(host).setTitle("Size")
                                .setItems(new String[] {"HALF", "WIDE (full width)", "BIG (full width, tall)"},
                                        (d2, size) -> {
                                            List<Widgets.Placed> placed = Widgets.load();
                                            placed.add(new Widgets.Placed(page, id, size));
                                            Widgets.save(placed);
                                            host.hideOverlay();
                                            host.showHome();
                                            if (Prefs.getInt(AltHome.K_LAYOUT, 0) == 0) {
                                                host.toast("MY WIDGET " + slot + " is on page " + (page + 1));
                                            } else {
                                                // the other home screens keep widgets in the WIDGETS sheet
                                                host.toast("Added. Open WIDGETS on your home screen to see it");
                                                host.root.postDelayed(() -> host.showOverlay(new WidgetsSheet(host)), 700);
                                            }
                                        }).show()).show();
    }

    private void editBlock(final List<CustomWidget.Block> blocks, final CustomWidget.Block b) {
        String[] hints = CustomWidget.hints(b.type);
        if (hints == null) {
            host.toast("Nothing to edit on this block");
            return;
        }
        final EditText a = new EditText(host);
        final EditText c = new EditText(host);
        a.setSingleLine(true);
        c.setSingleLine(true);
        a.setText(b.a);
        c.setText(b.b);
        LinearLayout box = new LinearLayout(host);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        if (hints[0] != null) {
            a.setHint(hints[0]);
            box.addView(a);
        }
        if (hints[1] != null) {
            c.setHint(hints[1]);
            box.addView(c);
        }
        new AlertDialog.Builder(host).setTitle(CustomWidget.TYPES[b.type]).setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    if (hints[0] != null) {
                        b.a = a.getText().toString().trim();
                    }
                    if (hints[1] != null) {
                        b.b = c.getText().toString().trim();
                    }
                    CustomWidget.save(slot, blocks);
                    build(true);
                }).setNegativeButton("Cancel", null).show();
    }

    @Override
    public boolean onBack() {
        host.hideOverlay();
        return true;
    }

    private int dp(float v) {
        return Theme.dp(host, v);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(host);
        t.setText(s);
        t.setTypeface(Theme.MONO);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = text(s, 11f, Theme.ACCENT);
        t.setBackground(Theme.rounded(0x22FFFFFF, 12f, host));
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.leftMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }
}
